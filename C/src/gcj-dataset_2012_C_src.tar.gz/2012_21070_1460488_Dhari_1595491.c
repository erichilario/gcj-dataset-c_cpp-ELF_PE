#include<stdio.h>
 #define MAXNVALUE 200
 main(int argc, char *argv[])
 {
   int T;
   int i,j;
   int N,S,p;
   int total;
   int maxNumOfBest;
   int max;
   int numOfSurpLeft;
   FILE *inp = fopen(argv[1],"r");
   FILE *outp = fopen(argv[2],"w");
   fscanf(inp,"%d",&T);
 
   for(i=1; i<=T; i++)
     {
       maxNumOfBest = 0;
       fscanf(inp,"%d %d %d",&N,&S,&p);
       numOfSurpLeft = S;
       for(j=1; j<=N; j++)
 	{
 	  fscanf(inp,"%d",&total);
 	  if((total % 3) == 0){
 	    max = total/3;
 	    if(max >= p)
 	      maxNumOfBest++;
 	    //try using spl power of 'surprising' triplets
 	    else if((numOfSurpLeft > 0) && (total >=3)){
 	      max = (total/3) + 1;
 	      if(max >= p){
 		maxNumOfBest++;
 		numOfSurpLeft--;
 	      }
 	    }
 	      
 	  }
 	  else if((total % 3) == 1){
 	    max = (total-1)/3 + 1;
 	    if(max >= p)
 	      maxNumOfBest++;
 	  }
 	  else{
 	    max = (total-2)/3 + 1;
 	    if(max >= p)
 	      maxNumOfBest++;
 	    //try using spl power of 'surprising' triplets
 	    else if((numOfSurpLeft > 0) && (total >= 2)){
 	      max = ((total-2)/3) + 2;
 	      if(max >= p){
 		maxNumOfBest++;
 		numOfSurpLeft--;
 	      }
 	    }
 	      
 	  }    
 	}
       fprintf(outp,"Case #%d: %d\n",i,maxNumOfBest);
       printf("%d\n",i);
     }
   fclose(inp);
   fclose(outp);
 
 }

