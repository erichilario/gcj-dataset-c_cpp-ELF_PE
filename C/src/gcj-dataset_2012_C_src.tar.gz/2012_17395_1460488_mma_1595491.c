#include <stdlib.h>
 #include <stdio.h>
 
 main()
 {
 	int N,G,S,P,t,g,c,r,x,y;
 	
 	scanf("%d", &N);
 	for (t=1; t<=N; t++) {
 		scanf("%d%d%d", &G, &S, &P);
 		c=0;
 		for(g=1; g<=G; g++) {
 			scanf("%d", &r);
 			x=r/3;
 			y=r%3;
 			switch (y) {
 			case 2:
 				x++;
 			case 0:
 				if (x>=P) {c++;}
 				else if ((r>=2) && (r<=28) && (x+1==P) && (S>0)) {c++; S--;};
 				break;
 			case 1:
 				if (x+1>=P) c++;
 				break;
 			}
 		}
 		printf ("Case #%d: %d\n", t, c);
 	}
 
 }

