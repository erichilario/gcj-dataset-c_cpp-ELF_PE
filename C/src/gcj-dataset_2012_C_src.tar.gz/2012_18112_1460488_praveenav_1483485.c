#include <stdio.h>
 #include <conio.h>
 #include <stdlib.h>
 
 int main()
 {
     int character = 0;
     int number = 0, counter = 0;
     int index = 0;
     FILE * pinFile, * poutFile;
 
     pinFile = fopen("inputfile.txt", "r");
     poutFile = fopen("outputfile.txt", "w");
 
 
     char* string = (char *)malloc(102*sizeof(char));
 
     fscanf(pinFile, "%d", &number);
     fgets(string, 102, pinFile);
 
     for(counter = 0; counter < number; counter++) {
         index = 0;
         fgets(string, 102, pinFile);
         fprintf(poutFile, "Case #%d: ", counter + 1);
         while((character = string[index++]) != '\0') {
             switch(character) {
                 case 'a': fprintf(poutFile, "y"); break;
                 case 'b': fprintf(poutFile, "h"); break;
                 case 'c': fprintf(poutFile, "e"); break;
                 case 'd': fprintf(poutFile, "s"); break;
                 case 'e': fprintf(poutFile, "o"); break;
 
                 case 'f': fprintf(poutFile, "c"); break;
                 case 'g': fprintf(poutFile, "v"); break;
                 case 'h': fprintf(poutFile, "x"); break;
                 case 'i': fprintf(poutFile, "d"); break;
                 case 'j': fprintf(poutFile, "u"); break;
 
                 case 'k': fprintf(poutFile, "i"); break;
                 case 'l': fprintf(poutFile, "g"); break;
                 case 'm': fprintf(poutFile, "l"); break;
                 case 'n': fprintf(poutFile, "b"); break;
                 case 'o': fprintf(poutFile, "k"); break;
 
                 case 'p': fprintf(poutFile, "r"); break;
                 case 'q': fprintf(poutFile, "z"); break;
                 case 'r': fprintf(poutFile, "t"); break;
                 case 's': fprintf(poutFile, "n"); break;
                 case 't': fprintf(poutFile, "w"); break;
 
                 case 'u': fprintf(poutFile, "j"); break;
                 case 'v': fprintf(poutFile, "p"); break;
                 case 'w': fprintf(poutFile, "f"); break;
                 case 'x': fprintf(poutFile, "m"); break;
                 case 'y': fprintf(poutFile, "a"); break;
 
                 case 'z': fprintf(poutFile, "q"); break;
 
                 default: fprintf(poutFile, "%c", character); break;
             }
         }
     }
 
     fclose(pinFile);
     fclose(poutFile);
 
     return 0;
 }

