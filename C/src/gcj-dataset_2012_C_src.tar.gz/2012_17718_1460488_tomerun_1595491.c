#include <stdio.h>
 #include <string.h>
 
 int N,S,p;
 int t[100];
 
 int dp[101][101];
 
 int selectMax(int a, int b) {
 	return (a < b ? b : a);
 }
 
 int solve(){
 	int i, j;
 	int ans = 0;
 	for (i = 1; i <= N; ++i) {
 		for (j = 0; j <= S; ++j) {
 			dp[i][j] = 0;
 		}
 	}
 	for (i = 0; i < N; ++i) {
 		for (j = 0; j <= S; ++j) {
 			if (t[i] % 3 == 0) {
 				// 0 0 0
 				if(t[i] >= 3*p) {
 					dp[i+1][j] = selectMax(dp[i+1][j], dp[i][j] + 1);
 				} else {
 					dp[i+1][j] = selectMax(dp[i+1][j], dp[i][j]);
 				}
 				// 2 1 0
 				if (j < S && 3 <= t[i] && t[i] <= 27) {
 					if(t[i] >= 3*p-3 ) {
 						dp[i+1][j+1] = selectMax(dp[i+1][j+1], dp[i][j] + 1);
 					} else if (t[i] >= 3) {
 						dp[i+1][j+1] = selectMax(dp[i+1][j+1], dp[i][j]);
 					}
 				}
 			} else if (t[i] % 3 == 1) {
 				// 1 0 0
 				if(t[i] >= 3*p-2) {
 					dp[i+1][j] = selectMax(dp[i+1][j], dp[i][j] + 1);
 				} else {
 					dp[i+1][j] = selectMax(dp[i+1][j], dp[i][j]);
 				}
 				// 2 2 0
 				if (j < S && 4 <= t[i] && t[i] <= 28) {
 					if(t[i] >= 3*p-2) {
 						dp[i+1][j+1] = selectMax(dp[i+1][j+1], dp[i][j] + 1);
 					} else if (t[i] >= 4) {
 						dp[i+1][j+1] = selectMax(dp[i+1][j+1], dp[i][j]);
 					}
 				}
 			} else {
 				// 1 1 0
 				if(t[i] >= 3*p-1) {
 					dp[i+1][j] = selectMax(dp[i+1][j], dp[i][j] + 1);
 				} else {
 					dp[i+1][j] = selectMax(dp[i+1][j], dp[i][j]);
 				}
 				// 2 0 0
 				if (j < S && t[i] <= 26) {
 					if(t[i] >= 3*p-4) {
 						dp[i+1][j+1] = selectMax(dp[i+1][j+1], dp[i][j] + 1);
 					} else if (t[i] >= 2) {
 						dp[i+1][j+1] = selectMax(dp[i+1][j+1], dp[i][j]);
 					}
 				}
 			}
 		}
 	}
 	return dp[N][S];
 }
 
 int main(){
 	int i,j;
 	int T;
 	scanf("%d", &T);
 	for (i = 1; i <= T; ++i) {
 		scanf("%d %d %d", &N, &S, &p);
 		for (j = 0; j < N; ++j) {
 			scanf("%d", t + j);
 		}
 		printf("Case #%d: %d\n", i, solve());
 	}
 	return 0;
 }

