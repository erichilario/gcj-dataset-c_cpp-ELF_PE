#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int read_line(FILE *fp, char *line)
 {
      char ch;
      while(1)
      {
          if( (ch = fgetc(fp)) == EOF)
              return 0;
          if( ch == '\n' )
          {
              *line++ = '\0';
              break;
          }
          if( ch == 0 )
          {
              fseek(fp,100,SEEK_CUR);
              break;
          }
          *line++ = ch;
      }
      return 1;
 }
 
 char char_transform(char c)
 {
      switch (c)
      {
             case 'a':
                 return 'y';
             case 'b':
                 return 'h';
             case 'c':
                 return 'e';
             case 'd':
                 return 's';
             case 'e':
                 return 'o';
             case 'f':
                 return 'c';
             case 'g':
                 return 'v';
             case 'h':
                 return 'x';
             case 'i':
                 return 'd';
             case 'j':
                 return 'u';
             case 'k':
                 return 'i';
             case 'l':
                 return 'g';
             case 'm':
                 return 'l';
             case 'n':
                 return 'b';
             case 'o':
                 return 'k';
             case 'p':
                 return 'r';
             case 'q':
                 return 'z';
             case 'r':
                 return 't';
             case 's':
                 return 'n';
             case 't':
                 return 'w';
             case 'u':
                 return 'j';
             case 'v':
                 return 'p';
             case 'w':
                 return 'f';
             case 'x':
                 return 'm';
             case 'y':
                 return 'a';
             case 'z':
                 return 'q';
             case ' ':
                 return ' ';
             default:
                     return c;
      }
 }
 
 int transform(FILE *fp, char *line, int n)
 {
     fprintf(fp,"Case #%d: ",n+1);
     while (*line)
     {
           fprintf(fp,"%c",char_transform(*line));
           line++;
     }
 }
 
 int main(int argc, char *argv[])
 {
     if (argc != 2)
     {
        printf("USAGE : %s <inp-filename>\n",argv[0]);
        exit(1);
     }
     FILE *fp;
     fp = fopen(argv[1],"r");
     if (fp == NULL)
     {
        printf("File not found\n");
        exit(1);
     }
     FILE *op;
     op = fopen("outfile","w");
     if (op == NULL)
     {
        printf("Output file cannot be created\n");
        exit(1);
     }
     char *line;
     int ret = 1;
 
 
     line = malloc (sizeof(char)*4096);
     ret = read_line(fp,line);
     int count = atoi(line);
     free(line);
 
     int loop = 0;    
     while(loop < count)
     {
      if (0 == ret)
      {
            printf("End of file reached. Input Violation\n");
            exit(1);
      }
      line = malloc (sizeof(char)*4096);
      memset(line,'\0',4096);
      ret = read_line(fp,line);
      //printf("Line : %s\n",line);
      transform(op,line,loop);
      free(line);
      loop++;
      if (loop != count)
         fprintf(op,"\n");
     }   
     return 0;
 }

