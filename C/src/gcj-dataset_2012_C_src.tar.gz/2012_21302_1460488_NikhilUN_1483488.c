#include<stdio.h>
 int main()
 {
 	FILE* fptr;
 	FILE* f;
 	int n;
 	int i;
 	int entry1[50];
 	int entry2[50];
 	int pos[50];
 	fptr=fopen("C-small-attempt2.in","r");
 	f=fopen("res","w");
 	fscanf(fptr,"%d",&n);
 	int count;
 	for(i=0;i<n;++i)
 	{
 		fscanf(fptr,"%d %d",&entry1[i],&entry2[i]);
 		fgetc(fptr);	
 	}
 	
 	for(i=0;i<n;++i)
 	{
 		if(entry1[i]<=9)
 			{
 			pos[i]=0;
 			}
 		else if(entry1[i]<=99)
 		{
 			pos[i]=count2(entry1[i],entry2[i]);
 		}
 		else if(entry1[i]<=999)
 		{
 			pos[i]=count3(entry1[i],entry2[i]);
 		}
 		else if(entry1[i]==1000)
 			pos[i]=0;
 	}
 	for(i=0;i<n;++i)
 	{	fprintf(f,"Case #%d: ",i+1);
 		fprintf(f,"%d",pos[i]);
 	//	printf("Case #%d:",i+1);
 		
 //	printf("%d",pos[i]);
 	       putc('\n',f);
 	}
 
 }
 int abc=0;
 int count2(int a,int b)
 {
 	abc=0;
 	int c=b-a;
 	int i;
 	int x;
 	int y;
 	int z=a;
 	//for(i=0;i<c;++i)
 	while(z<=b)
 	{
 //	if(((a%10>a/10)&&a<b)&&((a%10<b/10)||((a%10==b%10)&&(a/10<=b%10))))
 //	{
 //		abc++;
 
 	x=z%10;
 	y=(z/10)+(x*10);
 	//printf("%d\n",y);
 	if(y<=b&&y>z)
 	{	
 	abc++;
 	}
 	z++;
 	}
 	
 	
 	return abc;
 }	
 
 int count3(int a,int b)
 {
 	abc=0;
 	int x;
 	int y;
 	int i=0;
 	int r=b-a;
 	int q;
 	int m;
 	int z=a;
 	while(z<=b)
 	{
 		 q=z/100;
 		x=z%10;
 		y=z/10+x*100;
 		
 		m=(z-(q*100))*10+q;
 	if((m>z&&m<=b))//||(x!=0&&y>z&&y<=b))
 		abc++;
 	if(x!=0&&y>z&&y<=b)
 		abc++;
 	z++;	
 	}
 	
 	return abc;
 }

