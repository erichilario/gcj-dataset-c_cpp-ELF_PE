#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main(int argc, char *argv[]) {
   int cipher[26];
   int n, i, j;
   char tmp[4];
   char c;
 
   FILE *fp;
   char **ans;
 
   fp = fopen("cipher.bin", "r");
   fread(cipher, sizeof(int), 26, fp);
   fclose(fp);
 
   fp = fopen(argv[1], "r");
   if (fp == NULL) {
     printf("File not found\n");
     return 1;
   }
 
   fgets(tmp, 5, fp);
   n = atoi(tmp);
   ans = (char **) malloc(sizeof(char *)*n+2);
   for (i = 0; i < n+1; i++) {
     ans[i] = (char *) malloc(sizeof(char)*151);
     memset(ans[i], '\0', 151);
   }
 
   i = 0;
   while (!feof(fp)) {
     fgets(ans[i], 151, fp);
     i++;
   }
   i = 0;
   for (i = 0;i < n; i++) {
     for (j = 0; j < 100; j++) {
       if (ans[i][j] >= 'a' && ans[i][j] <= 'z') {
         ans[i][j] -= cipher[ans[i][j] - 97];
       } else if (ans[i][j] == '\n')
         break;
     }
   }
   for (i = 0; i < n; i++) {
     printf("Case #%d: %s", i + 1, ans[i]);
   }
 
 
   fclose(fp);
   return 0;
 }

