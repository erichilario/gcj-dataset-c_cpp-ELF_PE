#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char gr[27]="abcdefghijklmonpqrstuvwxyz";
 char op[27]="yhesocvxduiglbkrztnwjpfmaq";
 char line[102];
 
 main(int argc,char** argv)
 {
 	FILE* fpi=NULL;
 	FILE* fpo=NULL;
 
 	int n=0;
 
 	memset(line,0,sizeof(line));
 
     fpi=fopen(argv[1],"r");
     fpo=fopen("Output.txt","w");
 
 
     fscanf(fpi,"%d\n",&n); 
 
 	for (int i=0;i<n;i++)
 	{
      fgets(line,102,fpi);
 	 int index=0;
      fprintf(fpo, "Case #%d: ",i+1); 
 	 while(abs(line[index]))
 	 {
          if ((line[index] >= 'a') && (line[index] <='z'))
 		 fputc(op[line[index] -'a'],fpo);
 		 else
          fputc(line[index],fpo);	
 		 index++;
 
 	 }
 
 
 	}
 
 }

