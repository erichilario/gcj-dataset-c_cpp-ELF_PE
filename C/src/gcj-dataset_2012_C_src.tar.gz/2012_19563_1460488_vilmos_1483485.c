#include<stdio.h>
 
 int main()
 {
 FILE *fp,*fs;
 int num_of_test_cases;
 
 char input_set[]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
 char output_set[]={'y','h','e','s','o','c','v','x','d','u','i','g','l','b','k','r','z','t','n','w','j','p','f','m','a','q'};
 
 char temp;
 int i;
 int j=1;
 
 fp=fopen("A-small-attempt1.in","r");
 
 if(fp==NULL)
 printf("failure");
 
 fscanf(fp,"%d",&num_of_test_cases);
 //printf(" no is %d \n",num_of_test_cases);
 fscanf(fp,"%c",&temp);
 fs=fopen("jamoutput","w");
 
 
 while(j<=num_of_test_cases)
 {
 
 fprintf(fs,"Case #%d: ",j);
 
 //till the end of file
 while(fscanf(fp,"%c",&temp)!=EOF)
 {
 
 if(temp=='\n')
 break;
 
 if(temp==' ')
 fprintf(fs,"%c",temp);
 
 //printf("here now");
 //search in the input array for temp
 for(i=0;i<26;i++)
 {
 if(input_set[i]==temp)
 {
 fprintf(fs,"%c",output_set[i]);
 break;
 }//end of if
 }//end of for
 
 }//end of inner while
 fprintf(fs,"\n");
 j++;
 }//end of outer while
 
 
 
 return 0;
 }
 

