/*
  * T9Spell.c
  *
  *  Created on: Apr 11, 2012
  *      Author: klyap
  */
 
 #include <stdio.h>
 #include <string.h>
 
 void displayeach(FILE* output, char sentense[], int count);
 
 int main(void) {
 
 	char sentense[5000];
 	FILE* input;
 	FILE* output;
 	int line = 1;
 	int totalline;
 	int i;
 
 	setvbuf(stdout, NULL, _IONBF, 0);
 	input = fopen("A-small-attempt14.in", "r");
 	output = fopen("output.txt", "w");
 
 	fscanf(input, "%d\n", &totalline);
 
 	for (i = 0; i < totalline; i++) {
 		fgets(sentense, 5000, input);
 
 		displayeach(output, sentense, line);
 		line++;
 		fprintf(output, "\n");
 
 	}
 	return 0;
 }
 
 void displayeach(FILE* output, char sentense[], int count) {
 
 	int i = 0;
 
 	fprintf(output, "Case #%d: ", count);
 
 	for (i = 0; i < strlen(sentense); i++) {
 
 		if (sentense[i] == ' ') {
 			fprintf(output, " ");
 		} else if (sentense[i] == 'a')
 			fprintf(output, "y");
 		else if (sentense[i] == 'b')
 			fprintf(output, "h");
 		else if (sentense[i] == 'c')
 			fprintf(output, "e");
 		else if (sentense[i] == 'd')
 			fprintf(output, "s");
 		else if (sentense[i] == 'e')
 			fprintf(output, "o");
 		else if (sentense[i] == 'f')
 			fprintf(output, "c");
 		else if (sentense[i] == 'g')
 			fprintf(output, "v");
 		else if (sentense[i] == 'h')
 			fprintf(output, "x");
 		else if (sentense[i] == 'i')
 			fprintf(output, "d");
 		else if (sentense[i] == 'j')
 			fprintf(output, "u");
 		else if (sentense[i] == 'k')
 			fprintf(output, "i");
 		else if (sentense[i] == 'l')
 			fprintf(output, "g");
 		else if (sentense[i] == 'm')
 			fprintf(output, "l");
 		else if (sentense[i] == 'n')
 			fprintf(output, "b");
 		else if (sentense[i] == 'o')
 			fprintf(output, "k");
 		else if (sentense[i] == 'p')
 			fprintf(output, "r");
 		else if (sentense[i] == 'q')
 			fprintf(output, "z");
 		else if (sentense[i] == 'r')
 			fprintf(output, "t");
 		else if (sentense[i] == 's')
 			fprintf(output, "n");
 		else if (sentense[i] == 't')
 			fprintf(output, "w");
 		else if (sentense[i] == 'u')
 			fprintf(output, "j");
 		else if (sentense[i] == 'v')
 			fprintf(output, "p");
 		else if (sentense[i] == 'w')
 			fprintf(output, "f");
 		else if (sentense[i] == 'x')
 			fprintf(output, "m");
 		else if (sentense[i] == 'y')
 			fprintf(output, "a");
 		else if (sentense[i] == 'z')
 			fprintf(output, "q");
 
 	}
 
 }

