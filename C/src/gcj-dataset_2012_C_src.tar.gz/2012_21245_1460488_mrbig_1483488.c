#include <stdio.h>
 #include <stdlib.h>
 #include <malloc.h>
 #include <string.h>
 
 FILE* ouvrir_fichier_lecture ( char* _nom ) // ne pas oublier de mettre un argument pour le nom du fichier
 {
     FILE* fichier ;
     fichier = fopen ( _nom ,"r") ;
     if ( fichier == NULL )
     exit ( -1 ) ;
     return ( fichier ) ;
 } ;
 
 FILE* ouvrir_fichier_ecriture ( char* _nom ) // ne pas oublier de mettre un argument pour le nom du fichier
 {
     FILE* fichier ;
     fichier = fopen ( _nom ,"w") ;
     if ( fichier == NULL )
     exit ( -1 ) ;
     return ( fichier ) ;
 } ;
 
 void fermer_fichier ( FILE* _source_fichier ) // ferme le fihcier apres l'utilisation
 {
     fclose ( _source_fichier ) ;
 } ;
 
 int est_un_separateur ( const char _caractere ) // retourn 1 si separateur 0 sinon
 {
     if ( _caractere == ' ' || _caractere == '\n' || _caractere == '\t' )
     {
         return ( 1 ) ;
     }
     else
     {
         return ( 0 ) ;
     } ;
 } ;
 
 int est_un_chiffre ( const char _caractere ) // retourn 1 si chiffre 0 sinon
 {
     if ( ( _caractere >= '0' && _caractere <= '9' ) )
     {
         return ( 1 ) ;
     }
     else
     {
         return ( 0 ) ;
     } ;
 } ;
 // §§§§ terminé
 
 int est_une_lettre ( const char _caractere ) // retourn 1 si lettre 0 sinon
 {
     if ( ( _caractere >= 'a' && _caractere <= 'z' ) || ( _caractere >= 'A' && _caractere <= 'Z' ) || ( _caractere == '_') )
     {
         return ( 1 ) ;
     }
     else
     {
         return ( 0 ) ;
     } ;
 } ;
 
 char caractere_suivant ( FILE* _source_fichier ) // donne le caractere suivant
 {
     char caractere ;
     caractere = fgetc ( _source_fichier ) ;
     return ( caractere ) ;
 } ;
 
 void sauter_separateur ( FILE* _source_fichier ) // permmet de sauter les separateur
 {
     char caractere ;
     caractere = ' ' ;
     long p ;
     while ( est_un_separateur( caractere ) == 1 )
     {
         p = ftell ( _source_fichier ) ;
         caractere = caractere_suivant ( _source_fichier ) ;
     }
     fseek ( _source_fichier , p , SEEK_SET ) ;
 } ;
 
 long lire_fichier_nombre ( FILE* _source_fichier )  // li une variable un nom de fonciton ou un mot clé et le renvoi dans l'argument.
 {
     long position ;
     char* chaine1="" ;
     char* chaine2="" ;
     char caractere ;
     long nombre ;
     int test = 0 ;
     sauter_separateur ( _source_fichier ) ;
     chaine2 = (char*)malloc(sizeof(char)) ;
     chaine1 = (char*)malloc(sizeof(char)) ;
     sprintf ( chaine2 , "%s%s" , chaine2 , chaine1 ) ;
     while ( test == 0 )
     {
         position = ftell ( _source_fichier ) ;
         caractere = caractere_suivant ( _source_fichier ) ;
         if ( est_un_chiffre ( caractere ) == 1 || est_une_lettre ( caractere ) == 1 || caractere == '-')
         {
             chaine1 = (char*)malloc(sizeof(char)) ;
             sprintf ( chaine1 , "%c" , caractere ) ;
             sprintf ( chaine2 , "%s%s" , chaine2 , chaine1 ) ;
         }
         else
         {
             fseek ( _source_fichier , position , SEEK_SET ) ;
             test = 1 ;
         } ;
     } ;
     nombre = atol ( chaine2 ) ;
     return ( nombre ) ;
 };
 
 char * lire_fichier_chaine ( FILE* _source_fichier )  // li une variable un nom de fonciton ou un mot clé et le renvoi dans l'argument.
 {
     long position ;
     char* chaine1="" ;
     char* chaine2="" ;
     char caractere ;
     int test = 0 ;
     sauter_separateur ( _source_fichier ) ;
     chaine2 = (char*)malloc(sizeof(char)) ;
     chaine1 = (char*)malloc(sizeof(char)) ;
     sprintf ( chaine2 , "%s%s" , chaine2 , chaine1 ) ;
     while ( test == 0 )
     {
         position = ftell ( _source_fichier ) ;
         caractere = caractere_suivant ( _source_fichier ) ;
         if ( est_un_chiffre ( caractere ) == 1 || est_une_lettre ( caractere ) == 1 )
         {
             chaine1 = (char*)malloc(sizeof(char)) ;
             sprintf ( chaine1 , "%c" , caractere ) ;
             sprintf ( chaine2 , "%s%s" , chaine2 , chaine1 ) ;
         }
         else
         {
             fseek ( _source_fichier , position , SEEK_SET ) ;
             test = 1 ;
         } ;
     } ;
     return ( chaine2 ) ;
 };
 
 int lire_caractere ( char _caractere , FILE* _source_fichier ) // li le caractere donnée en argument si elle le trouve le pointeur sur le fichier avance sinon il reste a sa position originale
 {
     long position ;
     position = ftell ( _source_fichier ) ;
     if ( caractere_suivant( _source_fichier ) == _caractere )
     {
         return ( 1 ) ;
     } ;
     fseek ( _source_fichier , position , SEEK_SET ) ;
     return ( 0 ) ;
 } ;
 
 int main()
 {
     FILE* fichier_in ;
     FILE* fichier_out ;
     fichier_in = ouvrir_fichier_lecture ( "C-small-attempt2.in" ) ;
     fichier_out = ouvrir_fichier_ecriture("C-small-attempt2.out") ;
     int nombre_cas ;
     int i ;
     long a ;
     long b ;
     long x ;
     char s [500];
     char perm[500] ;
     int j , m ,k ;
     int longuer ;
     long y ;
     int r ;
     int de ;
     int po ;
     long tab[100000] ;
     nombre_cas = lire_fichier_nombre (fichier_in) ;
     lire_caractere('\n',fichier_in) ;
     for ( i=0 ; i<nombre_cas;i++)
     {
         a = lire_fichier_nombre (fichier_in) ;
         b = lire_fichier_nombre (fichier_in) ;
         lire_caractere('\n',fichier_in) ;
         r = 0 ;
         for ( x = a ; x <b ; x++ )
         {
             de =0 ;
             sprintf(s,"%d",x) ;
             longuer=0 ;
 
             while ( s[longuer]!='\0')
             {
                 longuer++ ;
             }
 
             for ( m=1;m<longuer;m++)
             {
                 k = 0 ;
                 for ( j = m ; j<longuer;j++)
                 {
                     perm[k] = s[j] ;
                     k++ ;
                 }
                 for ( j=0 ; j<m ;j++ )
                 {
                     perm[k] = s[j] ;
                     k++ ;
                 }
                 perm[k]='\0';
                 y=atoi (perm) ;
                 if ( i == 28 )
                 {
                     printf("%ld\n",y) ;
                 }
                 if ( y>x && y<=b )
                 {
                     po =0 ;
                     for ( j=0 ; j<de ; j++ )
                     {
                         if ( tab[j] == y )
                         {
                             po = 1 ;
                         }
                     }
                     if ( po != 1 )
                     {
                         tab[de] = y ;
                         de ++ ;
                         r ++ ;
                     }
                 }
             }
 s[0] ='\0' ;
 
         }
         fprintf (fichier_out , "Case #%d: ",i+1) ;
         fprintf (fichier_out , "%d",r) ;
         if ( i< nombre_cas)
         {
             fprintf (fichier_out , "\n") ;
         }
     }
     fermer_fichier ( fichier_in ) ;
     fermer_fichier(fichier_out) ;
     printf("Hello world!\n");
     return 0;
 }

