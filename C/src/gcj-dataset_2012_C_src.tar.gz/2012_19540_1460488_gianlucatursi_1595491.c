#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main(int argc, char *argv[]) {
 
 	FILE *fp = fopen("small.in", "r");
 	int row, n, p, strani;
 	int caso = 1;	
 	int ok = 0;
 	fscanf(fp,"%d", &row);
 	
 	while (row > 0) {
 		
 		fscanf(fp, "%d %d %d ", &n, &strani, &p);
 		int tmp_p = p;
 		int voti[n];
 		int i = 0;		int ok_tmp;
 		int sum = 0;
 		for (i = 0; i< n; i++) {
 			fscanf(fp, "%d ", &voti[i]);
 		}
 		i = 0;
 		ok = 0;
 		for(;i < n; i++){
 		/* ALGO  per il voto*/
 		p = tmp_p;
 		if( p != voti[i]){
 		for (; p <= 10; p++) {
 			ok_tmp = ok;		
 			if(voti[i] > p)
 				if((p+p+p) == voti[i])
 					ok++;
 				else if ((p+p+p) > voti[i]){
 				  	if((p+p+p-1) == voti[i])
 						ok++;
 					else if((p+p+p-2) == voti[i])
 							ok++;
 						  else if (strani > 0){ 
 								if ((p+p+p-3) == voti[i]){ 
 									ok++;strani--;
 								}else if ((p+p+p-4) == voti[i]){ 
 										ok++;strani--;
 									}
 							}
 				}else{
 					if((p+p+p+1) == voti[i])
 							ok++;
 					else if((p+p+p+2) == voti[i])
 							ok++;
 						  else if (strani > 0){
 								if ((p+p+p+3) == voti[i]){ 
 										ok++;strani--;
 								}else if ((p+p+p+4) == voti[i]){ 
 											ok++;strani--;
 										}	
 							}
 				}
 				
 			if(ok_tmp != ok)
 					break;
 			}// fine ciclo voto	
 		  } //if voto	
 		}//fine ciclo votiii
 		
 		printf("Case #%d: %d\n", caso, ok);
 		row--;caso++;
 	} // fine ciclo while
 	fclose(fp);	
 }

