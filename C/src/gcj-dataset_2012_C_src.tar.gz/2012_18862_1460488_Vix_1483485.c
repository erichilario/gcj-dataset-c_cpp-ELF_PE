#include<stdio.h>
 main()
 {
 FILE *fp0,*fp1;
 fp0=fopen("input.dat","r"); 		/* Input file*/
   int c, nl, i,u;
   nl = 0;
   fscanf(fp0,"%d\n",&u);
 for(i = 0; i<u;i++)
 {
   printf("Case #%d: ",i+1);
 while((c = getc(fp0)) != '\n')
     {
       if(c == 'a')
        printf("y");
    if(c == 'b')
        printf("h");
    if(c == 'c')
        printf("e");
     if(c == 'd')
        printf("s");
     if(c == 'e')
        printf("o");
     if(c == 'f')
        printf("c");
     if(c == 'g')
        printf("v");
     if(c == 'h')
        printf("x");
     if(c == 'i')
        printf("d");
     if(c == 'j')
        printf("u");
     if(c == 'k')
        printf("i");
     if(c == 'l')
        printf("g");
     if(c == 'm')
        printf("l");
     if(c == 'n')
        printf("b");
     if(c == 'o')
        printf("k");
     if(c == 'p')
        printf("r");
     if(c == 'q')
         printf("z");
     if(c == 'r')
        printf("t");
     if(c == 's')
        printf("n");
     if(c == 't')
        printf("w");
     if(c == 'u')
        printf("j");
     if(c == 'v')
        printf("p");
     if(c == 'w')
        printf("f");
     if(c == 'x')
        printf("m");
     if(c == 'y')
        printf("a");
     if(c == 'z')
        printf("q");
     if(c == '\t')
        printf("\t");
     if(c == ' ')
        printf(" ");    
     } 
 
 printf("\n");
   
 } 
   
 }

