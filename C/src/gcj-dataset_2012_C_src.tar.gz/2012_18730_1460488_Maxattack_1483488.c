#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int nbRepetitionsPossibles(int nombre,int borneMax){
   int resultat = 0,i,j,nbDigits,nbTemp;
   char *temp,*chaineDuNombre;
 
   chaineDuNombre = calloc(8,sizeof(char));
 
   sprintf(chaineDuNombre,"%d",nombre);
 
   nbDigits = strlen(chaineDuNombre);
 
   temp = calloc(nbDigits + 1,sizeof(char));
 
   for(i=0;i<nbDigits-1;i++){
     for(j=0;j<=i;j++){
       temp[nbDigits-i+j-1] = chaineDuNombre[j];
     }
 
     for(j=i+1;j<nbDigits;j++){
       temp[j-i-1] = chaineDuNombre[j];
     }
 
     nbTemp = strtoul(temp,NULL,10);
 
     if((nbTemp > nombre) && (nbTemp <= borneMax)){
       resultat++;
     }
   }
   
   free(temp);
   free(chaineDuNombre);
 
   return resultat;
 }
 
 void resoudreTest(){
   int debut,fin,i;
   int resultat;
 
   scanf("%d %d\n",&debut,&fin);
 
   resultat = 0;
 
   for(i=debut;i<fin;i++){
     resultat += nbRepetitionsPossibles(i,fin);
   }
 
   printf("%d\n",resultat);
 }
 
 int main(int argc,char **argv){
   int nbTests,i;
 
   scanf("%d\n",&nbTests);
 
   for(i=0;i<nbTests;i++){
     printf("Case #%d: ",i+1);
     resoudreTest();
   }
 
   return EXIT_SUCCESS;
 }

