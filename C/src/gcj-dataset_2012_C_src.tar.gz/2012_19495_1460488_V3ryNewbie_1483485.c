#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, const char *argv[])
 {
 	char map[] = {
 		'y', 'h', 'e', 's', 'o', 'c', 
 		'v', 'x', 'd', 'u', 'i', 'g', 
 		'l', 'b', 'k', 'r', 'z', 't', 
 		'n', 'w', 'j', 'p', 'f', 'm', 'a', 'q'
 	};
 
 	int i,j;
 
 	char line[256];
 	char buf[256];
 
 	FILE* fin = fopen("A-small-attempt3.in","r");
 	FILE* fout= fopen("A-small-attempt3.out","w");
 	int cnt = 0;
 
 	fgets(line, 256, fin);
 
 	cnt = atoi(line);
 	for(i=0; i < cnt; i++){
 		char* c = line;
 		fgets(line, 256, fin);
 		while(*c!='\n'&&*c){
 			if('a'<=*c&&*c<='z'){
 				*c = map[*c-'a'];
 			}
 			c++;
 		}
 		sprintf(buf,"Case #%d: %s",i+1,line);
 		fputs(buf, fout);
 	}
 
 	fclose(fin);
 	fclose(fout);
 	
 	return 0;
 }

