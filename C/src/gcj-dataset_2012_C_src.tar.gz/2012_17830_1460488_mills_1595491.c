#include <stdio.h>
 
 #define NMAX	100
 
 int main() {
     int		i,T,j,N,S,p,m,pge,pcor;
     int		mark[NMAX];
     scanf("%d\n",&T);
     for(i=1;i<=T;++i) {
 	scanf("%d %d %d",&N,&S,&p);
 	p+=p<<1;
 	for(j=pge=pcor=0;j<N;++j) {
 	    scanf("%d",mark+j);
 	    m = mark[j];
 	    if((m+2)>=p) {
 		++pge;
 	    } else if(m>=2 && m<=28 && (m+4)>=p ) {
 		++pcor;
 	    }
 	}
 	pcor = S > pcor ? pcor : S;
 	printf("Case #%d: %d\n",i,pge+pcor);
     }
     return 0;
 }

