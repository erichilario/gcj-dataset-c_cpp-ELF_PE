#include <stdio.h>
 #include <stdlib.h>
 
 char translation[26] = "yhesocvxduiglbkrztnwjpfmaq";
 
 int main()
 {
 	char *buffer = NULL;
 	int i, n;
 	size_t k;
 	char *s;
 	scanf("%d\n", &n);
 	for (i = 0; i < n; i++)
 	{
 		getline(&buffer, &k, stdin);
 		for (s = buffer; *s; s++)
 		{
 			if (*s >= 'a' && *s <= 'z')
 				*s = translation[*s - 'a'];
 		}
 		printf("Case #%d: %s\n", i + 1, buffer);
 		free(buffer);
 		buffer = NULL;
 	}
 	return 0;
 }

