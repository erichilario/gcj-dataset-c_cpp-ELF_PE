#include <stdio.h>
 #include <stdlib.h>
 
 int N;
 char mapping[26]={'y','h','e','s','o','c','v','x','d','u','i','g','l','b','k','r','z','t','n','w','j','p','f','m','a','q'};
 
 void solve(void);
 
 int main(void){
 	int i;
 	scanf("%d%*c",&N);
 
 	for(i=0;i<N;i++){
 		printf("Case #%d: ",i+1);
 		solve();
 	}
 
 	return 0;
 }
 
 void solve(void){
 	char string[101];
 	int i,l,c;
 
 	scanf("%[^\n]%n%*c",string,&l);
 
 	for(i=0;i<l;i++){
 		c = string[i];
 		if(c!=32)
 			printf("%c",mapping[c-97]);
 		else
 			printf(" ");
 	}
 	printf("\n");
 
 	return;
 }

