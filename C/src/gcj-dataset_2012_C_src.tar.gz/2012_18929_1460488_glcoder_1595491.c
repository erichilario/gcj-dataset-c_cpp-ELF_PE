#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 typedef int int3[3];
 
 #define SAME(i1,i2,i3) (j1[0] == j2[i1] && j1[1] == j2[i2] && j1[2] == j2[i3])
 int same(int3 j1, int3 j2) {
 	return SAME(0, 1, 2) || SAME(1, 2, 0) || SAME(1, 0, 2)
 		|| SAME(0, 2, 1) || SAME(2, 1, 0) || SAME(2, 0, 1);
 }
 
 int correct(int3 judge) {
 	if (judge[0] < 0 || judge[1] < 0 || judge[2] < 0)
 		return 0;
 	
 	const int d1 = abs(judge[0] - judge[1]),
 	          d2 = abs(judge[1] - judge[2]),
 	          d3 = abs(judge[2] - judge[0]);
 	
 	if (d1 < 2 && d2 < 2 && d3 < 2)
 		return 1;
 	
 	if (d1 < 3 && d2 < 3 && d3 < 3)
 		return 2;
 	
 	return 0;
 }
 
 #define COPY(j1,j2) {j1[0] = j2[0]; j1[1] = j2[1]; j1[2] = j2[2];}
 int permutation(int3 judge, int3 *permutations) {
 	int i = 0, j = 1, k = 0, n = 1, m = 0, count = 1, accepted = 1;
 	int3 history[10] = {{0,0,0}}; // triple eye OWL
 	
 	COPY(history[0], judge);
 	COPY(permutations[0], judge);
 	
 	while (accepted) {
 		m = n - 1;
 		do {
 			COPY(history[n], history[m]);
 		
 			++history[n][i++];
 			--history[n][j++];
 			
 			i %= 3;
 			j %= 3;
 			
 			accepted = correct(history[n]);
 			if (accepted) {
 				for (k = 0; k < n; ++k)
 					if (same(history[n], history[k]))
 						accepted = 0;
 			}
 			
 			if (accepted) {
 				COPY(permutations[count], history[n]);
 				++count;
 			}
 			
 			++n;
 		} while (i != 0);
 	}
 	
 	return count;
 }
 
 #define ACCEPTED(judge,p) (judge[0] >= p || judge[1] >= p || judge[2] >= p)
 int decomposition(int *S, int p, int score) {
 	int i, count, corrected;
 	int3 judge, permutations[10];
 	
 	judge[0] = judge[1] = judge[2] = 0;
 	for (i = 0; i < score; ++i)
 		judge[i % 3]++;
 	
 	count = permutation(judge, permutations);
 	
 	for (i = 0; i < count; ++i) {
 		corrected = correct(permutations[i]);
 		
 		if (corrected == 0 || (corrected == 2 && *S == 0) || !ACCEPTED(permutations[i], p))
 			continue;
 		
 		if (corrected == 2)
 			--*S;
 		
 		//printf("score %d = [%d %d %d][%d %d]\n", score,
 		//	permutations[i][0], permutations[i][1], permutations[i][2], *S, corrected);
 		
 		return 1;
 	}
 	
 	return 0;
 }
 
 int main() {
 	int count, N, S, p, i, score, result, n = 0;
 	
 	fscanf(stdin, "%d", &count);
 	while (count--) {
 		if (fscanf(stdin, "\n%d %d %d", &N, &S, &p) != 3)
 			continue;
 		
 		//printf("S = %d p = %d\n", S, p);
 		for (result = i = 0; i < N; ++i) {
 			fscanf(stdin, "%d", &score);
 			result += decomposition(&S, p, score);
 		}
 		
 		printf("Case #%d: %d\n", ++n, result);
 	}
 	
 	return 0;
 }

