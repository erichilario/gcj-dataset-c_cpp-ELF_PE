//Speaking in Tongues
 #include <stdio.h>
 
 int main()
 {
     int T,i,n=1;
     char ch;
     scanf ("%d%c",&T,&ch);
 
     printf ("Case #%d: ",n++);
 
     while (scanf("%c",&ch)==1)
         {
 
             if (ch == '\n')
             {
                     if(n>T) continue;
                     printf ("\nCase #%d: ",n++);
                     continue;
             }
             else if (ch == 'a') ch = 'y';
             else if (ch == 'b') ch = 'h';
             else if (ch == 'c') ch = 'e';
             else if (ch == 'd') ch = 's';
             else if (ch == 'e') ch = 'o';
             else if (ch == 'f') ch = 'c';
             else if (ch == 'g') ch = 'v';
             else if (ch == 'h') ch = 'x';
             else if (ch == 'i') ch = 'd';
             else if (ch == 'j') ch = 'u';
             else if (ch == 'k') ch = 'i';
             else if (ch == 'l') ch = 'g';
             else if (ch == 'm') ch = 'l';
             else if (ch == 'n') ch = 'b';
             else if (ch == 'o') ch = 'k';
             else if (ch == 'p') ch = 'r';
             else if (ch == 'q') ch = 'z';
             else if (ch == 'r') ch = 't';
             else if (ch == 's') ch = 'n';
             else if (ch == 't') ch = 'w';
             else if (ch == 'u') ch = 'j';
             else if (ch == 'v') ch = 'p';
             else if (ch == 'w') ch = 'f';
             else if (ch == 'x') ch = 'm';
             else if (ch == 'y') ch = 'a';
             else if (ch == 'z') ch = 'q';
             putchar(ch);
         }
         return 0;
 }
 

