/*
 google code jam
 Qualification Round 2012
 Problem b
 */
 
 #include <stdio.h>
 
 #define  MIN(x, y)  (((x)<(y)) ? (x) : (y))
 #define  MAX(x, y)  (((x)>(y)) ? (x) : (y))
 
 int main() {
         int tc, cc;
         int n, s, p, t;
         int i;
         int ans, ans_sns, ans_s, ans_ns, res;
         scanf("%d", &tc);
         for ( cc = 1; cc <= tc; ++cc ) {
                 ans_sns = ans_s = ans_ns = 0;
                 scanf("%d%d%d", &n, &s, &p);
                 for ( i = 0; i < n; ++i ) {
                         scanf("%d", &t);
                         switch( t % 3 ) {
                         case 0 : 
                                 res = t / 3;
                                 if ( 3 > t ) {
                                         if ( res >= p ) {
                                                 ++ans_ns;
                                         }
                                 }
                                 else {
                                         if ( res >= p ) {
                                                 ++ans_sns;
                                         }
                                         else if ( res + 1 >= p ) {
                                                 ++ans_s;
                                         }
                                 }
                                 break;
                         case 1 : 
                                 res = t / 3 + 1;
                                 if ( 3 > t ) {
                                         if ( res >= p ) {
                                                 ++ans_ns;
                                         }
                                 }
                                 else {
                                         if ( res >= p ) {
                                                 ++ans_sns;
                                         }
                                 }
                                 break;
                         case 2 : 
                                 res = t / 3 + 1;
                                 if ( res >= p ) {
                                         ++ans_sns;
                                 }
                                 else if ( res + 1 >= p ) {
                                         ++ans_s;
                                 }
                                 break;
                         }
                 }
 
                 ans = ans_ns + MIN(ans_s, s) + ans_sns;
                 printf("Case #%d: %d\n", cc, ans);
         }
         return 0;
 }

