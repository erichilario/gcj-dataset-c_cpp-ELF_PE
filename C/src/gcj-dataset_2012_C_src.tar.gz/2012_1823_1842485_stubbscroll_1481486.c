#include <stdio.h>
 #include <string.h>
 typedef long long ll;
 int len;
 int n;
 int d[10000],L[10000];
 int maks[10000];
 
 #define Q 100000000
 int q[Q],qs,qe;
 
 #define ABS(a) ((a)>0?(a):-(a))
 #define MAX(a,b) ((a)>(b)?(a):(b))
 int main() {
 	int cases,caseno=1,i,cur,curlen,grab,at;
 	scanf("%d",&cases);
 	while(cases--) {
 		scanf("%d",&n);
 		for(i=0;i<n;i++) scanf("%d %d",&d[i],&L[i]);
 		scanf("%d",&len);
 		memset(maks,126,sizeof(int)*n);
 		maks[0]=d[0];
 		qs=qe=0;
 		q[qe++]=0;
 		while(qs<qe) {
 			cur=q[qs++];
 			curlen=maks[cur];
 			at=d[cur];
 //			printf("at %d (pos %d), maks %d\n",cur,at,maks[cur]);
 			if(at+curlen>=len) goto yes;
 			for(i=0;i<n;i++) if(i!=cur && d[i]>=at-curlen && d[i]<=at+curlen) {
 				grab=ABS(d[i]-at);
 				if(grab>L[i]) grab=L[i];
 	//			printf("  grab vine %d (pos %d) from %d, at length %d\n",i,d[i],cur,grab);
 				if(grab<maks[i]) {
 					q[qe++]=i;
 					maks[i]=grab;
 		//			printf("  can reach %d (pos %d), maks %d\n",i,d[i],maks[i]);
 				}
 				if(d[i]+grab>=len) goto yes;
 			}
 		}
 		printf("Case #%d: NO\n",caseno++);
 		continue;
 	yes:
 //		printf("reached goal at %d\n",len);
 		printf("Case #%d: YES\n",caseno++);
 	}
 	return 0;
 }

