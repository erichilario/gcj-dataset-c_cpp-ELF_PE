#include <stdio.h>
 #include <string.h>
 
 #define true 1
 #define false 0
 
 typedef unsigned char bool;
 
 char hash[256];
 
 void initHash()
 {
   memset(hash, 0, sizeof(hash));
   
   hash[(int)'a'] = 'y';
   hash[(int)'b'] = 'h';
   hash[(int)'c'] = 'e';
   hash[(int)'d'] = 's';
   hash[(int)'e'] = 'o';
   hash[(int)'f'] = 'c';
   hash[(int)'g'] = 'v';
   hash[(int)'h'] = 'x';
   hash[(int)'i'] = 'd';
   hash[(int)'j'] = 'u';
   hash[(int)'k'] = 'i';
   hash[(int)'l'] = 'g';
   hash[(int)'m'] = 'l';
   hash[(int)'n'] = 'b';
   hash[(int)'o'] = 'k';
   hash[(int)'p'] = 'r';
   hash[(int)'q'] = 'z';
   hash[(int)'r'] = 't';
   hash[(int)'s'] = 'n';
   hash[(int)'t'] = 'w';
   hash[(int)'u'] = 'j';
   hash[(int)'v'] = 'p';
   hash[(int)'w'] = 'f';
   hash[(int)'x'] = 'm';
   hash[(int)'y'] = 'a';
   hash[(int)'z'] = 'q';
 }
 
 int main()
 {
   int T, cont = 0;
   
   initHash();
   
   scanf("%d\n", &T);
 
   while(T--)
   {
     char str[110];
     int i, size;
     
     gets(str);
     size = strlen(str);
     
     printf("Case #%d: ", ++cont);
     for(i = 0; i < size; i++)
       if(str[i] >= 'a' && str[i] <= 'z')
         putchar(hash[ (int) str[i] ]);
       else
         putchar(str[i]);
     printf("\n");
   }
   
 return 0;
 }

