#include <stdio.h>
 #include <math.h>
 
 int main() {
 	int T, S, p , N, ti, i, j;
 	int count;
 	double tmp;
 	int min;
 	scanf("%d", &T);
 	for ( i = 1; i <= T; i++ ) {
 		count = 0;
 		scanf("%d", &N);
 		scanf("%d", &S);
 		scanf("%d", &p);
 		for ( j = 0; j < N; j++ ) {
 			scanf("%d", &ti);
 			tmp = (double)ti / 3;
 			min = abs(p + (p-2)*2);
 		//	printf("------------------------%lf, %d\n", tmp, min);
 			if ( tmp > (double) (p-1) )
 				count++;
 			else if ( ti >= min && S ) {
 				count++;
 				S--;
 			}
 		}
 		printf("Case #%d: %d\n", i, count);
 	}
 	return 0;
 }

