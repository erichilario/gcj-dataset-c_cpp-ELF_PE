#include <assert.h>
 #include <math.h>
 #include <stdio.h>
 #include <stdlib.h>
 
 int N, matW, matL;
 int rads[1000];
 
 int compare(const void *a, const void *b)
 {
   int x = *(int*)a;
   int y = *(int*)b;
   return rads[y] - rads[x];
 }
 
 int main(void)
 {
   int T, t;
   scanf("%d", &T);
   for(t = 1; t <= T; t++)
   {
     scanf("%d %d %d", &N, &matW, &matL);
     int i, j;
     for(i = 0; i < N; i++)
       scanf("%d", &rads[i]);
 
     int order[1000];
     for(i = 0; i < N; i++)
       order[i] = i;
     qsort(order, N, sizeof(int), &compare);
 
     double ctrX[1000], ctrY[1000];
 
     int cur = 0;
     double left = 0;
     double right = matW;
     double bottom = 0;
     double top = matL;
     while(cur < N)
     {
       assert(left < right);
       assert(bottom < top);
       
       ctrX[cur] = left;
       ctrY[cur] = bottom;
       double lastX = ctrX[cur];
       double lastY = ctrY[cur];
       double lastR = rads[order[cur]];
       double nextLeft = left + lastR;
       double nextBottom = bottom + lastR;
       cur++;
       for( ; cur < N; cur++)
       {
         double r = rads[order[cur]];
         if(lastX + lastR + r <= right)
         {
           ctrX[cur] = lastX + lastR + r;
           ctrY[cur] = lastY;
           lastX = ctrX[cur];
           lastR = r;
         }
         else
           break;
       }
       if(cur == N)
         break;
       double r = lastR + rads[order[cur]];
       ctrX[cur] = right;
       ctrY[cur] = bottom + sqrt(r*r - (right-lastX)*(right-lastX));
       lastX = ctrX[cur];
       lastY = ctrY[cur];
       lastR = rads[order[cur]];
       double nextRight = lastX - lastR;
       cur++;
       for( ; cur < N; cur++)
       {
         double r = rads[order[cur]];
         if(lastY + lastR + r <= top)
         {
           ctrX[cur] = lastX;
           ctrY[cur] = lastY + lastR + r;
           lastY = ctrY[cur];
           lastR = r;
         }
         else
           break;
       }
       if(cur == N)
         break;
       r = lastR + rads[order[cur]];
       ctrX[cur] = right - sqrt(r*r - (top-lastY)*(top-lastY));
       ctrY[cur] = top;
       lastX = ctrX[cur];
       lastY = ctrY[cur];
       lastR = rads[order[cur]];
       double nextTop = top - lastR;
       cur++;
       for( ; cur < N; cur++)
       {
         double r = rads[order[cur]];
         if(lastX - lastR - r >= left)
         {
           ctrX[cur] = lastX - lastR - r;
           ctrY[cur] = lastY;
           lastX = ctrX[cur];
           lastR = r;
         }
         else
           break;
       }
       if(cur == N)
         break;
       r = lastR + rads[order[cur]];
       ctrX[cur] = left;
       ctrY[cur] = top - sqrt(r*r - (lastX-left)*(lastX-left));
       lastX = ctrX[cur];
       lastY = ctrY[cur];
       lastR = rads[order[cur]];
       cur++;
       for( ; cur < N; cur++)
       {
         double r = rads[order[cur]];
         if(lastY - lastR - r >= nextBottom)
         {
           ctrX[cur] = left;
           ctrY[cur] = lastY - lastR - r;
           lastY = ctrY[cur];
           lastR = r;
         }
         else
           break;
       }
 
       if(cur < N)
       {
         double r = rads[order[cur]];
         left = nextLeft + r;
         right = nextRight - r;
         bottom = nextBottom + r;
         top = nextTop - r;
       }
     }
 
     int invorder[1000];
     for(i = 0; i < N; i++)
       invorder[order[i]] = i;
 
     printf("Case #%d:", t);
     for(i = 0; i < N; i++)
       printf(" %f %f", ctrX[invorder[i]], ctrY[invorder[i]]);
     printf("\n");
   }
 
   return 0;
 }

