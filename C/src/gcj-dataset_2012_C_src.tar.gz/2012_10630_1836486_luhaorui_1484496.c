#include <stdio.h>
 #include <math.h>
 #include <stdlib.h>
 #define MACRO_N 20
 int loop(int* S, int* flag, int sum, int total, int depth){
 	int sum0, sum1, sum2;
 	if(sum==0 && total!=0){
 		return 0;
 	}
 	if(depth==MACRO_N){
 		if(sum==*S){
 			*flag=2;
 			return 0;
 		}
 		else if(sum+*S==0){
 			*flag=1;
 			return 0;
 		}
 		else {
 			return -1;
 		}
 	}
 	sum0=loop(S+1,flag+1,sum,total,depth+1);
 	if(sum0==0){
 		*flag=0;
 		return 0;
 	}
 	sum1=loop(S+1,flag+1,sum+(*S),1,depth+1);
 	if(sum1==0){
 		*flag=1;
 		return 0;
 	}
 	sum2=loop(S+1,flag+1,sum-(*S),1,depth+1);
 	if(sum2==0){
 		*flag=2;
 		return 0;
 	}
 	return -1;
 }
 
 void func(int* S, int* flag){
 	int i,ret,once;
 	for(i=0;i<MACRO_N;i++){
 		flag[i]=0;
 	}
 	ret=loop(S,flag,0,0,1);
 	if(ret==0){
 		once=0;
 		for(i=0;i<MACRO_N;i++){
 			if(flag[i]==1){
 				if(once==1)printf(" ");
 				printf("%d",S[i]);
 				once=1;
 			}
 		}
 		printf("\n");
 		once=0;
 		for(i=0;i<MACRO_N;i++){
 			if(flag[i]==2){
 				if(once==1)printf(" ");
 				printf("%d",S[i]);
 				once=1;
 			}
 		}
 		printf("\n");
 		return ;
 	}
 	printf("Impossible\n");
 }
 
 int main(void){
 	int T;
 	int N;
 	int i,j;
 	int S[MACRO_N];
 	int flag[MACRO_N];
 	int sum;
 	FILE *fd;
 	fd=fopen("input.txt","r");
 	fscanf(fd,"%d",&T);
 	for(i=1;i<=T;i++){
 		fscanf(fd,"%d",&N);
 		//get input data
 		for(j=0;j<N;j++){
 			fscanf(fd,"%d",&S[j]);
 			flag[j]=0;
 		}
 		//output function
 		printf("Case #%d:\n",i);
 		func(S,flag);
 	}
 }

