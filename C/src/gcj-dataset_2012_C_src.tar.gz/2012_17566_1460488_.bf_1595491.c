#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define true 1
 #define false 0
 
 typedef unsigned char bool;
 
 int vet[110];
 
 int main()
 {
   int T, cont = 0;
   
   scanf("%d\n", &T);
   
   while(T--)
   {
     int n, s, p;
     int i, max = 0;
     
     scanf("%d %d %d", &n, &s, &p);
     
     for(i = 0; i < n; i++)
       scanf("%d", &vet[i]);
     
     for(i = 0; i < n; i++)
       if(vet[i] >= (p*3)-2)
         max++;
       else if(s > 0 && vet[i] >= (p*3)-4)
       {
         if(vet[i] || !p)
         {
           max++;
           s--;
         }
       }
         
     printf("Case #%d: %d\n", ++cont, max);
   }
   
 return 0;
 }

