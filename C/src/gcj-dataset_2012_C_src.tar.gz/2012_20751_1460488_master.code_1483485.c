#include<string.h>
 #include<fcntl.h>
 #include <sys/types.h>
 #include <stdio.h>
 #include <unistd.h>
 #include <errno.h>
 #include <stdlib.h>
 #include <netdb.h>
 char convert(char c);
 char convert(char c)
 {
 	if(c=='a')
 		return 'y';
 	else if(c=='b')
 		return 'h';
 	else if(c=='c')
 		return 'e';
 	else if(c=='d')
 		return 's';
 	else if(c=='e')
 		return 'o';
 	else if(c=='f')
 		return 'c';
 	else if(c=='g')
 		return 'v';
 	else if(c=='h')
 		return 'x';
 	else if(c=='i')
 		return 'd';
 	else if(c=='j')
 		return 'u';
 	else if(c=='k')
 		return 'i';
 	else if(c=='l')
 		return 'g';
 	else if(c=='m')
 		return 'l';
 	else if(c=='n')
 		return 'b';
 	else if(c=='o')
 		return 'k';
 	else if(c=='p')
 		return 'r';
 	else if(c=='q')
 		return 'z';
 	else if(c=='r')
 		return 't';
 	else if(c=='s')
 		return 'n';
 	else if(c=='t')
 		return 'w';
 	else if(c=='u')
 		return 'j';
 	else if(c=='v')
 		return 'p';
 	else if(c=='w')
 		return 'f';
 	else if(c=='x')
 		return 'm';
 	else if(c=='y')
 		return 'a';
 	else if(c=='z')
 		return 'q';
 	else
 		return c;
 }
 
 int main(int argc, char *argv[])
 {
         int i,j,count=1;
         char b;
 	int fdi = open("input.txt",O_RDONLY);
         int fdo = open("output.txt",O_WRONLY|O_CREAT,0644);
         close(1);
         dup(fdo);
         close(0);
         dup(fdi);
         close(fdo);
         close(fdi);
 	scanf("%d\n",&i);        
 	for(j=0;j<i;j++)
         {
 		printf("Case #%d: ",j+1);
 		scanf("%c",&b);
 		while(b != '\n' && count!=0)
 		{                
 			//count = read(0,b,1);
 			b = convert(b);
 			printf("%c",b);
 			scanf("%c",&b);			
 			//write(1,c,1);
 		}
 		if(b=='\n') printf("\n");
         }
 
 
 return 0;
 }

