#include <stdio.h>
 #include <stdlib.h>
 
 int compare(const void * a, const void * b){
 	return *((int*)a) - *((int*)b);
 }
 int main(int argc, char * argv[]) {
 	int g_scores[100],n,N,nC,s,p,i,j,m,ti,e;
 	
 	scanf("%d",&N);
 	for(nC=1;nC<=N;nC++){
 		scanf("%d %d %d",&n,&s,&p);
 		
 		for(i=0;i<n;i++) scanf("%d",g_scores+i);
 		qsort(g_scores,n,sizeof(int),compare);
 		
 		ti = 0;
 
 		for(i=0;i<n;i++){
 			m = g_scores[i]/3;
 			e = g_scores[i]-m*3;
 			if(m>=p){
 				ti++;
 			} else if(m==p-1){
 				if(e >= 1) ti++;
 				else if(s && m > 1){
 					ti++;
 					s--;
 				}
 			} else if(m==p-2){
 				if(e>=1 && s){
 					s--;
 					ti++;
 				}
 			}
 		}
 		printf("Case #%d: %d\n",nC,ti);
 	}
 	return 0;
 }
