#include <stdio.h>
 #include <string.h>
 #include <math.h>
 #include <stdlib.h>
 //void convertInt(int n,char* store);
 //int conString(char* st);
 //void recycle(int digit,char* store,char* rec);
 int main(){
     char store[1000];
     int lower,upper;
     int num,count=1;
     scanf("%d",&num);
     while(num>0){
         scanf("%d %d",&lower,&upper);
         //printf("From %d to %d\n",lower,upper);
         printf("Case #%d: %d\n",count++,countRecycle(lower,upper));
         --num;
     }
 }
 void recy(int digit,char* store){
     int i;
     char temp;
     temp= store[0];
     for(i=0;i<digit-1;++i)
         store[i]=store[i+1];
     store[i]=temp;
     store[digit]='\0';
 }
 
 void convertInt(int n,char* store){
     int digit=getDigiNum(n);
     int i;
     for(i=digit-1;i>=0;--i)
     {
         store[i]=n%10+48;
         n/=10;
     }
     store[digit]='\0';
 }
 
 int countRecycle(int lower,int upper){
     char stLower[10];
     char stUpper[10];
     char recycle[10];
     int **paired;
     int i,j=0,count=0;
     int digit =getDigiNum(lower);
     int temp;
     int tempLower=lower;
 
     paired = (int**)malloc(sizeof(int*)*2222);
     for(i=0;i<2222;i++)
         paired[i] =(int*)malloc(sizeof(int)*2222);
 
     while(tempLower<upper){
         convertInt(tempLower,stLower);
         recy(digit,stLower);
         for(i=0;i<digit-1;++i){
             //printf("%d and %s\n",tempLower,stLower);
             temp=conString(stLower);
             if(temp>=lower&&temp<=upper&&temp!=tempLower&&noPre(temp,tempLower,paired)){
                 //printf("In: %d and %s\n",tempLower,stLower);
                 ++count;
                 paired[tempLower][temp]=1;
                 paired[temp][tempLower]=1;
             }
             recy(digit,stLower);
         }
         //printf("\n");
         tempLower++;
     }
     return count;
 }
 int noPre(int n,int temp,int** pair){
     int i=0;
     if(pair[n][temp]==0) i=1;
     return i;
 }
 int getDigiNum(int n){
     return n>0?(int)log10((double)n)+1:1;
 }
 int conString(char* st){
     return atoi(st);
 }

