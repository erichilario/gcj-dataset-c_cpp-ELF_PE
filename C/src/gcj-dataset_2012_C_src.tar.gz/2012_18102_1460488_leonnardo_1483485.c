#include <stdio.h>
 #include <string.h>
 
 int main() {
     char c;
     char caso_teste[101];
     char nosso_alfa[] = "abcdefghijklmnopqrstuvwxyz";
     char google_alfa[] = "ynficwlbkuomxsevzpdrjgthaq";
     int i = 0, n, j;
     int pos;
 
     scanf("%d\n",&n);
     while (i < n) {    
         //scanf("%[^\n]s", caso_teste);
         j = 0 ;
         do {
             scanf("%c", &c);
             caso_teste[j] = c;
             j++;
         } while (c != '\n');
         caso_teste[j-1] = '\0';
         for (j = 0; j < strlen(caso_teste); j++) {
             if (caso_teste[j] != 32) {
                 pos = strchr(google_alfa, caso_teste[j])-google_alfa;
                 caso_teste[j] = nosso_alfa[pos];
             }
         }
         printf("Case #%d: %s\n",i+1,caso_teste);
         i++;
     }
     
     return 0;
 }
 
 

