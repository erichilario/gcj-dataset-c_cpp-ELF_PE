#include <stdio.h>
 #include <stdbool.h>
 
 int points[200];
 bool insmall[200];
 
 int main(int argc, const char *argv[])
 {
 	int t;
 	int c;
 	scanf("%d", &t);
 	for (c = 0; c < t; ++c) {
 		int n;
 		scanf("%d", &n);
 		int i;
 		int sum = 0;
 		for (i = 0; i < n; ++i) {
 			scanf("%d", points + i);
 			sum += points[i];
 			insmall[i] = true;
 		}
 		double a = 2.0 * sum / n;
 		printf("Case #%d:", c + 1);
 		// find small set
 		int small_sum;
 		int smalln;
 		double smalla = a;
 		bool bigfound = false;
 		do {
 			small_sum = 0;
 			smalln = 0;
 			bigfound = false;
 			for (i = 0; i < n; ++i) {
 				if (points[i] <= smalla) {
 					small_sum += points[i];
 					smalln++;
 				} else if (insmall[i]) {
 					bigfound = true;
 					insmall[i] = false;
 				}
 			}
 			smalla = 2.0 * small_sum / smalln;
 		} while (bigfound);
 		// printf(" smalla = %f, small_sum = %d\n", smalla, small_sum);
 
 		for (i = 0; i < n; ++i) {
 			if (points[i] <= smalla) {
 				if (small_sum > 0.0) {
 					printf(" %.6f", (a - points[i]) / sum * 100.0);
 				} else {
 					// they are all 0
 					printf(" %.6f", 100.0 / smalln);
 				}
 			} else {
 				double a = (points[i] + sum) / (1.0 + smalln);
 				// printf(" $a = %f\n", a);
 				if (a > points[i]) {
 					printf(" %.6f", (a - points[i]) / sum * 100.0);
 				} else {
 					printf(" 0.000000");
 				}
 			}
 		}
 		// but small_sum may be 0
 		/*if (nzero == 0) {
 			double a = 2.0 * sum / n;
 			for (i = 0; i < n; ++i) {
 				printf(" %.6f", (a - points[i]) / sum * 100.0);
 			}
 		} else {
 			for (i = 0; i < n; ++i) {
 				if (points[i] == 0) {
 					printf(" %.6f", 100.0 / nzero);
 				} else {
 					double a = (points[i] + sum) / (1.0 + nzero);
 					if (a > points[i]) {
 						printf(" %.6f", (a - points[i]) / sum * 100.0);
 					} else {
 						printf(" 0.000000");
 					}
 				}
 			}
 		}*/
 		putchar('\n');
 	}
 	return 0;
 }

