#include <stdio.h>
 #include <math.h>
 #include <stdlib.h>
 #include <string.h>
 void rotate1(char *s, int len){
     char tmp=s[len-1];
     int i;
     for(i=len-1; i>0; i--){
         s[i]=s[i-1];
     }
     s[0]=tmp;
 }
 
 int main(int argc, char *argv[]){
     int T,A,B,i,j,k,rec,len,tmp,place;
     char *s1, *s2;
     FILE *fp;
     if(argc != 2){
         fprintf(stderr,"Error: must supply one argument [file]");
         exit(-1);
     }
     fp = fopen(argv[1],"r");
     if(fp==NULL){
         fprintf(stderr,"Error: File not found: %s",argv[1]);
         exit(-1);
     }
     fscanf(fp,"%d\n",&T);
     for(i=1; i<=T; i++){
         rec=0;
         fscanf(fp,"%d %d\n",&A,&B);
         for(j=A; j<=B; j++){
             place=-1;
             s2=malloc((int)log10(j)+2);
             sprintf(s2,"%d",j);
             len=strlen(s2);
             rotate1(s2,len);
             for(k=1;k<len;k++){
                 tmp=atoi(s2);
                 if(tmp!=j && tmp>=A && tmp <=B) rec++;
                 if(tmp==j) break;
                 rotate1(s2,len);
             }
             free(s2);
         }
         printf("Case #%d: %d\n",i,rec/2);
     }
 
     return 0;
 }

