*
 * START 2012-04-14_1059
 *
 EQU NUL TO ""
 EQU VM TO CHAR(253)
 EQU MAX TO 999999999
 *
 SOURCE.PATH = "D:\imports"
 *
 CRT "SOURCE PATH = ":SOURCE.PATH:
 CRT
 *
 INPUT.FILENAME  = "Q.C.INPUT.TXT"
 OUTPUT.FILENAME = "Q.C.OUTPUT.TXT"
 *
 * delete output file
 *
 CALL HW.OPEN("IMPORTS", F.IMPORTS, "", 1)
 DELETE F.IMPORTS, OUTPUT.FILENAME
 CLOSE F.IMPORTS
 *
 FULL.INPUT.FILENAME  = SOURCE.PATH:"\":INPUT.FILENAME
 FULL.OUTPUT.FILENAME = SOURCE.PATH:"\":OUTPUT.FILENAME
 *
 OPENSEQ FULL.INPUT.FILENAME  TO F.SOURCE ON ERROR GOSUB OPEN.ERROR ELSE ABORT
 OPENSEQ FULL.OUTPUT.FILENAME TO F.DEST   ON ERROR GOSUB OPEN.ERROR ELSE NULL
 *  CREATE F.DEST ELSE GOSUB OPEN.ERROR ; STOP
 
 *
 READSEQ INPUT.LINE FROM F.SOURCE ELSE NULL
 *
 N.CASE = INPUT.LINE
 IF NUM(N.CASE) ELSE
   CRT "CASE COUNT NOT NUMERIC - ABORT!"
   STOP
 END
 *
 I.CASE = 0
 EOF = 0
 LOOP
   READSEQ INPUT.LINE FROM F.SOURCE ELSE EOF = 1
 UNTIL EOF DO
   I.CASE = I.CASE + 1
 *  CRT I.CASE, INPUT.LINE
   GOSUB PROCESS.LINE
 REPEAT
 *
 CRT I.CASE, N.CASE
 IF I.CASE = N.CASE ELSE
   CRT "LINE COUNT MISMATCH"
 END
 *
 CLOSESEQ F.SOURCE
 CLOSESEQ F.DEST
 *
 STOP
 *
 *
 *************************************************************************
 *
 *
 *************************************************************************
 *
 PROCESS.LINE: *;*
 *
 OUT.LINE = NUL
 *
 S.RANGE = FIELD(INPUT.LINE, " ", 1)
 N.RANGE = FIELD(INPUT.LINE, " ", 2)
 *
 * length of number
 *
 N.NUMBER = LEN(S.RANGE)
 *
 RECYCLE.COUNT = 0
 *
 FOR I.RANGE = S.RANGE TO N.RANGE
   N = I.RANGE
 *
 * check pairs by shifting
 *
   PAST.LIST = NUL
   FOR I.NUMBER = 2 TO N.NUMBER
     M = N[I.NUMBER, MAX]:N[1, I.NUMBER - 1]
     BEGIN CASE
       CASE N >= M            ;* N < M
       CASE N[1, 1] = "0"     ;* N cannot start with 0
       CASE M[1, 1] = "0"     ;* M cannot start with 0
       CASE M > N.RANGE       ;* M must be <= B
       CASE 1
 *
 * eliminate duplicates
 *
         LOCATE(M, PAST.LIST, 1; P.VMC) ELSE
           RECYCLE.COUNT = RECYCLE.COUNT + 1
 *          CRT I.CASE,INPUT.LINE,N,M
           PAST.LIST<1, -1> = M
         END
     END CASE
   NEXT I.NUMBER
 NEXT I.RANGE
 FULL.OUT.LINE = "Case #":I.CASE:": ":RECYCLE.COUNT
 WRITESEQ FULL.OUT.LINE ON F.DEST ON ERROR GOSUB OPEN.ERROR ELSE NULL
 *
 RETURN
 
 
 *
 *************************************************************************
 *
 *
 OPEN.ERROR: *;*
 CRT "OPEN, CREATE, WRITE ERROR!"
 STOP
 *

