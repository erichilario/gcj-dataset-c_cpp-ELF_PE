#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 char alpha[26];
 char* goog = "ynficwlbkuomxsevzpdrjgthaq";
 char z = 'a';
 
 char search(char c) {
   for (int a = 0; a < 26; a++) {
     alpha[a] = (char)(z + a);
   }
 
   for (int i = 0; i < 26; i++) {
     if (c == goog[i]) {
       return alpha[i];
     }
   }
 }
 
 int main(int argc, char *argv[]) {
   char line[BUFSIZ];
   fgets(line, sizeof line, stdin);
   int nCases = atoi(line);
   
   for (int i = 0; i < nCases; i++) {
     printf("Case #%d: ", (i+1));
     fgets(line, sizeof line, stdin);
 
     for (int j = 0; j < strlen(line); j++) {
       if (line[j] == ' ') {
         printf(" ");
       } else if (line[j] == '\n') {
         continue;
       } else {
         printf("%c", search(line[j]));
       }
     }
     printf("\n");
   }
 }

