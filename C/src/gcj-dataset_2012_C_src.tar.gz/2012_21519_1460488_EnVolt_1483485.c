#include<stdio.h>
 #include<conio.h>
 void main()
 {
     int i,n,j;
     char a[100],b[100];
     scanf("%d",&n);
 
 gets(a);    for(j=0;j<30;j++)
     {
         gets(a);
         for(i=0;a[i]!=0;i++)
         {
         if(a[i]=='a')
         b[i]='y';
          if(a[i]=='b')
         b[i]='h';
         if(a[i]=='c')
         b[i]='e';
         if(a[i]=='d')
         b[i]='s';
         if(a[i]=='e')
         b[i]='o';
         if(a[i]=='f')
         b[i]='c';
         if(a[i]=='g')
         b[i]='v';
         if(a[i]=='h')
         b[i]='x';
         if(a[i]=='i')
         b[i]='d';
         if(a[i]=='j')
         b[i]='u';
         if(a[i]=='k')
         b[i]='i';
         if(a[i]=='l')
         b[i]='g';
         if(a[i]=='m')
         b[i]='l';
         if(a[i]=='n')
         b[i]='b';
         if(a[i]=='o')
         b[i]='k';
         if(a[i]=='p')
         b[i]='r';
         if(a[i]=='q')
         b[i]='z';
         if(a[i]=='r')
         b[i]='t';
         if(a[i]=='s')
         b[i]='n';
         if(a[i]=='t')
         b[i]='w';
         if(a[i]=='u')
         b[i]='j';
         if(a[i]=='v')
         b[i]='p';
         if(a[i]=='w')
         b[i]='f';
         if(a[i]=='x')
         b[i]='m';
         if(a[i]=='y')
         b[i]='a';
         if(a[i]=='z')
         b[i]='q';
         if(a[i]==' ')
         b[i]=' ';
         }
         b[i]=0;
 
         printf("Case #%d: ",j+1);
         puts(b);
 
     }
 
 }
 
 

