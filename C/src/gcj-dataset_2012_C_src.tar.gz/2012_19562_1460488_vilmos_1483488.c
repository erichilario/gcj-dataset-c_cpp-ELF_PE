#include<stdio.h>
 #include<math.h>
 
 int num_of_digits(int num)
 {
 int count=0;
 while(num)
 {
 count++;
 num/=10;
 }
 return count;
 }
 
 
 int rotation(int num,int n,int digits)
 {
 int power=digits-n;
 int q,r;
 q=num/(pow(10,power));
 r=num%(int)(pow(10,power));
 r=r*pow(10,n);
 r+=q;
 return r;
 }
 
 
 int main()
 {
 FILE *fp,*fs;
 int i;
 int j=1;
 int num_of_test_cases;
 int temp;
 int digits;
 int a,b;
 int k;
 int count=0;
 
 fp=fopen("C-small-attempt0.in","r");
 
 if(!fp)
 printf("failure as usual :P \n");
 
 fs=fopen("jamoutput","w");
 
 fscanf(fp,"%d",&num_of_test_cases);
 
 while(j<=num_of_test_cases)
 {
 fscanf(fp,"%d",&a);
 fscanf(fp,"%d",&b);
 
 count=0;
 digits=num_of_digits(a);
 
 for(i=a;i<b;i++)
 {
 
 for(k=1;k<=digits-1;k++)
 {
 temp=rotation(i,k,digits);
 if(temp>i && temp<=b)
 count++;
 temp=0;
 }//end of inner for
 
 
 }//end of this for
 fprintf(fs,"Case #%d: %d",j,count);
 fprintf(fs,"\n");
 
 
 
 j++;
 }//end of outer while
 
 return 0;
 }

