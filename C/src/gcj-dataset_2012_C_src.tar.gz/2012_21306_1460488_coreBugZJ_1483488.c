/*
 google code jam
 Qualification Round 2012
 Problem c
 */
 
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 #define  L  2000009
 
 void shift(char *str, int len) {
         int i;
         char tmp = str[ 0 ];
         for ( i = 1; i < len; ++i ) {
                 str[ i-1 ] = str[ i ];
         }
         str[ len-1 ] = tmp;
 }
 
 int solve(int a, int b) {
         static char used[ L ];
         char  num[ 64 ];
         int i, j, k, len, cnt, ans = 0;
 
         memset(used, 0, sizeof(used));
         for ( i = a; i <= b; ++i ) {
                 if ( used[ i ] ) {
                         continue;
                 }
 
                 itoa(i, num, 10);
                 len = strlen(num);
                 cnt = 0;
 
                 for ( j = 0; j < len; ++j ) {
                         k = atoi(num);
                         if ( ('0' != num[0]) && (a <= k) && (k <= b) && (! used[k]) ) {
                                 ++cnt;
                                 used[ k ] = 1;
                         }
                         shift(num, len);
                 }
 
                 ans += cnt * (cnt - 1) / 2;
         }
 
         return ans;
 }
 
 int main() {
         int tc, cc;
         int a, b;
         scanf("%d", &tc);
         for ( cc = 1; cc <= tc; ++cc ) {
                 scanf("%d%d", &a, &b);
                 printf("Case #%d: %d\n", cc, solve(a, b));
         }
         return 0;
 }

