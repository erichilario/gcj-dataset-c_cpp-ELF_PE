#include <stdio.h>
 #include <stdlib.h>
 #include <malloc.h>
 #include <string.h>
 
 FILE* ouvrir_fichier_lecture ( char* _nom ) // ne pas oublier de mettre un argument pour le nom du fichier
 {
     FILE* fichier ;
     fichier = fopen ( _nom ,"r") ;
     if ( fichier == NULL )
     exit ( -1 ) ;
     return ( fichier ) ;
 } ;
 
 FILE* ouvrir_fichier_ecriture ( char* _nom ) // ne pas oublier de mettre un argument pour le nom du fichier
 {
     FILE* fichier ;
     fichier = fopen ( _nom ,"w") ;
     if ( fichier == NULL )
     exit ( -1 ) ;
     return ( fichier ) ;
 } ;
 
 void fermer_fichier ( FILE* _source_fichier ) // ferme le fihcier apres l'utilisation
 {
     fclose ( _source_fichier ) ;
 } ;
 
 int est_un_separateur ( const char _caractere ) // retourn 1 si separateur 0 sinon
 {
     if ( _caractere == ' ' || _caractere == '\n' || _caractere == '\t' )
     {
         return ( 1 ) ;
     }
     else
     {
         return ( 0 ) ;
     } ;
 } ;
 
 int est_un_chiffre ( const char _caractere ) // retourn 1 si chiffre 0 sinon
 {
     if ( ( _caractere >= '0' && _caractere <= '9' ) )
     {
         return ( 1 ) ;
     }
     else
     {
         return ( 0 ) ;
     } ;
 } ;
 // §§§§ terminé
 
 int est_une_lettre ( const char _caractere ) // retourn 1 si lettre 0 sinon
 {
     if ( ( _caractere >= 'a' && _caractere <= 'z' ) || ( _caractere >= 'A' && _caractere <= 'Z' ) || ( _caractere == '_') )
     {
         return ( 1 ) ;
     }
     else
     {
         return ( 0 ) ;
     } ;
 } ;
 
 char caractere_suivant ( FILE* _source_fichier ) // donne le caractere suivant
 {
     char caractere ;
     caractere = fgetc ( _source_fichier ) ;
     return ( caractere ) ;
 } ;
 
 void sauter_separateur ( FILE* _source_fichier ) // permmet de sauter les separateur
 {
     char caractere ;
     caractere = ' ' ;
     long p ;
     while ( est_un_separateur( caractere ) == 1 )
     {
         p = ftell ( _source_fichier ) ;
         caractere = caractere_suivant ( _source_fichier ) ;
     }
     fseek ( _source_fichier , p , SEEK_SET ) ;
 } ;
 
 long lire_fichier_nombre ( FILE* _source_fichier )  // li une variable un nom de fonciton ou un mot clé et le renvoi dans l'argument.
 {
     long position ;
     char* chaine1="" ;
     char* chaine2="" ;
     char caractere ;
     long nombre ;
     int test = 0 ;
     sauter_separateur ( _source_fichier ) ;
     chaine2 = (char*)malloc(sizeof(char)) ;
     chaine1 = (char*)malloc(sizeof(char)) ;
     sprintf ( chaine2 , "%s%s" , chaine2 , chaine1 ) ;
     while ( test == 0 )
     {
         position = ftell ( _source_fichier ) ;
         caractere = caractere_suivant ( _source_fichier ) ;
         if ( est_un_chiffre ( caractere ) == 1 || est_une_lettre ( caractere ) == 1 || caractere == '-')
         {
             chaine1 = (char*)malloc(sizeof(char)) ;
             sprintf ( chaine1 , "%c" , caractere ) ;
             sprintf ( chaine2 , "%s%s" , chaine2 , chaine1 ) ;
         }
         else
         {
             fseek ( _source_fichier , position , SEEK_SET ) ;
             test = 1 ;
         } ;
     } ;
     nombre = atol ( chaine2 ) ;
     return ( nombre ) ;
 };
 
 char * lire_fichier_chaine ( FILE* _source_fichier )  // li une variable un nom de fonciton ou un mot clé et le renvoi dans l'argument.
 {
     long position ;
     char* chaine1="" ;
     char* chaine2="" ;
     char caractere ;
     int test = 0 ;
     sauter_separateur ( _source_fichier ) ;
     chaine2 = (char*)malloc(sizeof(char)) ;
     chaine1 = (char*)malloc(sizeof(char)) ;
     sprintf ( chaine2 , "%s%s" , chaine2 , chaine1 ) ;
     while ( test == 0 )
     {
         position = ftell ( _source_fichier ) ;
         caractere = caractere_suivant ( _source_fichier ) ;
         if ( est_un_chiffre ( caractere ) == 1 || est_une_lettre ( caractere ) == 1 )
         {
             chaine1 = (char*)malloc(sizeof(char)) ;
             sprintf ( chaine1 , "%c" , caractere ) ;
             sprintf ( chaine2 , "%s%s" , chaine2 , chaine1 ) ;
         }
         else
         {
             fseek ( _source_fichier , position , SEEK_SET ) ;
             test = 1 ;
         } ;
     } ;
     return ( chaine2 ) ;
 };
 
 int lire_caractere ( char _caractere , FILE* _source_fichier ) // li le caractere donnée en argument si elle le trouve le pointeur sur le fichier avance sinon il reste a sa position originale
 {
     long position ;
     position = ftell ( _source_fichier ) ;
     if ( caractere_suivant( _source_fichier ) == _caractere )
     {
         return ( 1 ) ;
     } ;
     fseek ( _source_fichier , position , SEEK_SET ) ;
     return ( 0 ) ;
 } ;
 
 
 int main()
 {
     FILE* fichier_in ;
     FILE* fichier_out ;
     fichier_in = ouvrir_fichier_lecture ( "test.in" ) ;
     fichier_out = ouvrir_fichier_ecriture("test.out") ;
     int nombre_cas ;
     nombre_cas = lire_fichier_nombre (fichier_in) ;
     lire_caractere('\n',fichier_in) ;
     int i ;
     int p ;
     int danceur ;
     int suprise ;
     int score[100] ;
     int j ;
     int min ;
     int max ;
     int nbr ;
 max = 0 ;
 nbr = 0 ;
     for (i =0 ; i<nombre_cas ; i++ )
     {
         max = 0 ;
         nbr = 0 ;
         danceur = lire_fichier_nombre (fichier_in) ;
         suprise = lire_fichier_nombre (fichier_in) ;
         p = lire_fichier_nombre (fichier_in) ;
         for (j =0 ; j<danceur ; j++ )
         {
              score[j] = lire_fichier_nombre (fichier_in) ;
         }
         lire_caractere('\n',fichier_in) ;
         min=3*p -4 ;
         for (j =0 ; j<danceur ; j++ )
         {
              if ( score[j] > min +2 )
              {
                  max ++ ;
              }
              else
              {
                  if ( score[j] >=min && score[j] >= p)
                  {
                      nbr ++ ;
                  }
              }
            if ( suprise >= nbr )
            {
                max = max + nbr ;
            }
            else{
            max = max + suprise;}
         }
     fprintf (fichier_out , "Case #%d: ",i+1) ;
         fprintf (fichier_out , "%d",max) ;
         if ( i< nombre_cas)
         {
             fprintf (fichier_out , "\n") ;
         }
 
 
 
 
 
     }
     fermer_fichier ( fichier_in ) ;
     fermer_fichier(fichier_out) ;
     printf("Hello world!\n");
     return 0;
 }

