#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int T;
 
 void solve(void);
 int rotate(int,int);
 
 int main(void){
 	int i;
 
 	scanf("%d",&T);
 
 	for(i=0;i<T;i++){
 		printf("Case #%d: ",i+1);
 		solve();
 	}
 
 	return 0;
 }
 
 void solve(void){
 	int A,B,final=0;
 	int i,tmp;
 	int ndigits;
 
 	scanf("%d%n %d",&A,&ndigits,&B);
 	ndigits--;
 
 	for(i=A;i<=B;i++){
 		tmp = i;
 		while((tmp=rotate(tmp,ndigits))!=i)
 			if(tmp > i && tmp <= B){
 				final++;}
 	}
 
 	printf("%d\n",final);
 	return;
 }
 
 int rotate(int n,int digits){
 	int resto;
 	
 	resto = n%10;
 	n = n/10;
 	for(;digits>1;digits--)
 		resto *= 10;
 	return (resto+n);
 }
 	
 

