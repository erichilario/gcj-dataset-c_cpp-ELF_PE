#include <limits.h>
 #include <stdio.h>
 
 #define MIN(x, y) ((x) < (y) ? (x) : (y))
 #define MAX(x, y) ((x) > (y) ? (x) : (y))
 
 int main(void)
 {
   int T, t;
   scanf("%d", &T);
   for(t = 1; t <= T; t++)
   {
     int N;
     scanf("%d", &N);
 
     int dists[10001], lens[10001];
     int i, j;
     for(i = 0; i < N; i++)
       scanf("%d %d", &dists[i], &lens[i]);
     scanf("%d", &dists[N]);
     lens[N] = 0;
 
     int earliest[10000];
     for(i = 0; i < N; i++)
       earliest[i] = INT_MAX;
     earliest[0] = 0;
 
     int possible = 0;
     for(i = 0; i < N; i++)
     {
       if(earliest[i] == INT_MAX)
       {
         break;
       }
 
       for(j = i+1; j <= N; j++)
       {
         int d = dists[i] - earliest[i];
         if(dists[j] - dists[i] <= d)
         {
           int newpos = MAX(dists[i], dists[j] - lens[j]);
           earliest[j] = MIN(earliest[j], newpos);
           //printf("i=%d: earliest[%d] ==> %d\n", i, j, earliest[j]);
           if(j == N)
           {
             possible = 1;
             goto done;
           }
         }
       }
     }
 
   done:
     printf("Case #%d: %s\n", t, possible ? "YES" : "NO");
   }
   
   return 0;
 }

