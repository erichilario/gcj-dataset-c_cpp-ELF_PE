#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 int cipher[26];
 
 int trans(char *a) {
 
 }
 
 int main() {
   int i, j;
   memset(cipher, '\0', 26);
   char *str[3];
   char *sample[3];
   cipher['y' - 97] = ('y' - 'a');
   cipher['e' - 97] = ('e' - 'o');
   cipher['q' - 97] = ('q' - 'z');
   /* Figured out the next one because it was the only
    * one not covered in sample data. */
   cipher['z' - 97] = ('z' - 'q');
 
   FILE *fp;
   fp = fopen("in.txt", "r");
   for (i = 0; i < 3; i++) {
     str[i] = (char *) malloc(sizeof(char)*100);
     fgets(str[i], 100, fp);
     str[i][strcspn(str[i], "\n")] = '\0';
   }
   fclose(fp);
   fp = fopen("test.txt", "r");
   for (i = 0; i < 3; i++) {
     sample[i] = (char *) malloc(sizeof(char)*100);
     fgets(sample[i], 100, fp);
     sample[i][strcspn(sample[i], "\n")] = '\0';
   }
   fclose(fp);
 
   int index;
   for (i = 0; i < 3; i++) {
     for (j = 0; j < 100; j++) {
       index = str[i][j] - 97;
       if (index < 0) {
         continue;
       } else if (cipher[index] != '\0') {
         str[i][j] -= cipher[index];
         printf("!%c %d\n", str[i][j], index);
       } else {
         cipher[index] = str[i][j] - sample[i][j];
         printf("~%c %d\n", str[i][j], index);
         str[i][j] -= cipher[index];
       }
     }
     printf("%s\n", str[i]);
     printf("%s\n", sample[i]);
     free(str[i]);
     free(sample[i]);
   }
 
   fp = fopen("cipher.bin", "wb");
   fwrite(cipher, sizeof(int), 26, fp);
 
   fclose(fp);
   return 0;
 }

