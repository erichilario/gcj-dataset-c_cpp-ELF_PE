#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 #include<stdbool.h>
 
 #define MAX_LENGTH  200
 
 void
 preprocess(char src[][MAX_LENGTH], char dst[][MAX_LENGTH], int n, char map[]);
 
 int main()
 {
 	char src[3][MAX_LENGTH] = {"ejp mysljylc kd kxveddknmc re jsicpdrysi", "rbcpc ypc rtcsra dkh wyfrepkym veddknkmkrkcd", "de kr kd eoya kw aej tysr re ujdr lkgc jv"};
 	char dst[3][MAX_LENGTH] = {"our language is impossible to understand", "there are twenty six factorial possibilities", "so it is okay if you want to just give up"};
 	char map[26];
 	int i, j;
 	//char a[][3]={{'2','5'},{'9','7'}};
 //	int flag[26];
 	int n;
 	char input[MAX_LENGTH];
 	char res[MAX_LENGTH];
 //	memset(flag, false, sizeof(flag));
 	freopen("input.txt", "r", stdin);
 	freopen("output.txt", "w", stdout);
 	preprocess(src, dst, 3, map);
 	map['q'-'a'] = 'z';
 	map['z'-'a'] = 'q';
 	/*	for( i = 0; i < 26; i++ )
 	{
 		//if(map[i] != ' ')
 		//	flag[map[i]-'a'] = true;
 		printf("%c %c\n", i+'a',  map[i]);
 	}
 	putchar('\n');
 
 for( i = 0; i< 26; i++)
 	{
 		if(flag[i] == false)
 			printf("%c ",i+'a');
 	}
 */	
 	
 	scanf("%d", &n);
 	i = 0;
 
 	getchar();
 	for( i = 0; i < n; i++ )
 	{
 		fgets(input, MAX_LENGTH-1, stdin);
 
 		for(j = 0; j < strlen(input); j++)
 		{
 			if( input[j] != ' ')
 				res[j] = map[input[j]-'a'];
 			else
 				res[j] = ' ';
 		}	
 	//	fputs(input, stdout);
 	//	printf("reach here !!%d\n", j);
 		res[j-1] = '\0';
 		printf("Case #%d: %s\n", i+1, res);
 		fflush(stdout);
 	//	fputs(res, stdout);
 	//	fputs("\n", stdout);
 	}
 	return 0;
 }
 
 void
 preprocess(char src[][MAX_LENGTH], char dst[][MAX_LENGTH], int n, char map[])
 {
 	int i, j;
 	memset(map, ' ', sizeof(map));
 	i = 0;
 	for(i = 0; i < n; i++)
 	{
 		j = 0;
 		while( src[i][j] != '\0' )
 		{
 			map[src[i][j]-'a'] = dst[i][j];	
 			j++;
 		}
 	}
 }

