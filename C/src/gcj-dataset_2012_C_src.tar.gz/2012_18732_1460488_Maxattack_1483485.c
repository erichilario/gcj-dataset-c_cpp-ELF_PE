#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct {
   char remplacant;
   char remplace;
 }CorresLettres;
 
 CorresLettres initLettre(char remplacant,char remplace){
   CorresLettres resultat;
 
   resultat.remplacant = remplacant;
   resultat.remplace = remplace;
 
   return resultat;
 }
 
 CorresLettres *initDictionnaire(){
   CorresLettres *resultat = calloc(26,sizeof(CorresLettres));
 
   resultat[0] = initLettre('a','y');
   resultat[1] = initLettre('b','h');
   resultat[2] = initLettre('c','e');
   resultat[3] = initLettre('d','s');
   resultat[4] = initLettre('e','o');
   resultat[5] = initLettre('f','c');
   resultat[6] = initLettre('g','v');
   resultat[7] = initLettre('h','x');
   resultat[8] = initLettre('i','d');
   resultat[9] = initLettre('j','u');
   resultat[10] = initLettre('k','i');
   resultat[11] = initLettre('l','g');
   resultat[12] = initLettre('m','l');
   resultat[13] = initLettre('n','b');
   resultat[14] = initLettre('o','k');
   resultat[15] = initLettre('p','r');
   resultat[16] = initLettre('q','z');
   resultat[17] = initLettre('r','t');
   resultat[18] = initLettre('s','n');
   resultat[19] = initLettre('t','w');
   resultat[20] = initLettre('u','j');
   resultat[21] = initLettre('v','p');
   resultat[22] = initLettre('w','f');
   resultat[23] = initLettre('x','m');
   resultat[24] = initLettre('y','a');
   resultat[25] = initLettre('z','q');
 
   return resultat;
 }
 
 void traduirePhrase(char *phraseATraduire){
   unsigned i = 0;
   CorresLettres *dico;
 
   dico = initDictionnaire();
 
   while(phraseATraduire[i] != '\n'){
     if(phraseATraduire[i] != ' '){
       phraseATraduire[i] = dico[phraseATraduire[i] - 'a'].remplace;
     }
     i++;
   }
 }
 
 int main(int argc,char **argv){
   unsigned nbPhrases,i;
   char **phrases;
 
   scanf("%u\n",&nbPhrases);
   
   phrases = calloc(nbPhrases,sizeof(char*));
   for(i=0;i<nbPhrases;i++){
     phrases[i] = calloc(103,sizeof(char));
     fgets(phrases[i],102,stdin); 
   }
 
   for(i=0;i<nbPhrases;i++){
     traduirePhrase(phrases[i]);
     printf("Case #%u: %s",i+1,phrases[i]);
   }
 
   return 0;
 }

