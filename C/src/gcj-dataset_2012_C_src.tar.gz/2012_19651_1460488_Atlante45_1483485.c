#include <stdio.h>
 #include <stdlib.h>
 
 char correspondance(char c){
   char *s = "yhesocvxduiglbkrztnwjpfmaq";
   
   if(' ' == c)
     return ' ';
   
   return s[c - 'a'];
 }
 
 int main(int argc, char *argv[]){
   char c = '\0';
   int i, n = 0;
   
   FILE *input = fopen(argv[1], "r");
   FILE *output = fopen("output.txt", "w");
   
   if(NULL == input || NULL == output)
     exit(EXIT_FAILURE);
   
   fscanf(input, "%d ", &n);
   
   for(i = 0; i < n; i++){
     fprintf(output, "Case #%d: ", i+1);
     
     while('\n' != (c = fgetc(input)) && EOF != c)
       fputc(correspondance(c), output);
     
     fputc('\n', output);
   }
   
   fclose(input);
   fclose(output);
 
   return EXIT_SUCCESS;
 }

