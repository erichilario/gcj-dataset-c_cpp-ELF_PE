#include <stdio.h>
 #include <limits.h>
 #include <stdlib.h>
 #include <string.h>
 #include <assert.h>
 
 typedef struct BitArray
 {
     unsigned char *m_pBits;
     int   m_nCapacity;
     int   m_nSize;
 } BitArray;
 
 void CreateBitArray(BitArray *ba, int nCapacity)
 {
     int nSize = (nCapacity + CHAR_BIT - 1) / CHAR_BIT;
     ba->m_pBits = calloc(nSize, sizeof(char));
     ba->m_nCapacity = nCapacity;
     ba->m_nSize = nSize;
 }
 
 void ResizeBitArray(BitArray *ba, int nCapacity)
 {
     int i = 0;
     int nSize = (nCapacity + CHAR_BIT - 1) / CHAR_BIT;
 
     if ( nSize <= ba->m_nSize )
         return;
 
     ba->m_pBits = realloc(ba->m_pBits, nSize * sizeof(char));
     ba->m_nCapacity = nCapacity;
 
     memset(&ba->m_pBits[ba->m_nSize], 0x00, (nSize - ba->m_nSize) * sizeof(char));
     ba->m_nSize = nSize;
 }
 
 void DestroyBitArray(BitArray *ba)
 {
     free(ba->m_pBits);
     memset(ba, 0x00, sizeof(struct BitArray));
 }
 
 int GetBit(BitArray *ba, int nPos)
 {
     unsigned char *bits = ba->m_pBits;
     bits += nPos / CHAR_BIT;
     return (*bits & (1 << (nPos % CHAR_BIT))) != 0;
 }
 
 void OnBit(BitArray *ba, int nPos)
 {
     unsigned char *bits = ba->m_pBits;
 
     bits += nPos / CHAR_BIT;
     *bits |= 1 << (nPos % CHAR_BIT);
 }
 
 void OffBit(BitArray *ba, int nPos)
 {
     unsigned char *bits = ba->m_pBits;
 
     bits += nPos / CHAR_BIT;
    *bits &= ~(1 << (nPos % CHAR_BIT));
 }
 
 void FlipBit(BitArray *ba, int nPos)
 {
     unsigned char *bits = ba->m_pBits;
     bits += nPos / CHAR_BIT;
     *bits ^= 1 << (nPos % CHAR_BIT);
 }
 
 
 
 int get_digit(int n)
 {
 	if(n==0) {return 1;}
 	else{
 		int count=0;
 		if (n<0) {n=-n;}
 		while (n>0) {count++; n/=10;}
 		return count;
 	}
 }
 
 int convert_int(int n, char *d)
 {
 	int digit;
 	digit = sprintf(d, "%d", n);
 	return digit;
 }
 
 
 check_recycle(int num_a, int num_b, int digit)
 {
 	int i,j,k;
 	int cnt = 0;
 	int index = 0;
 	int convert_num = 0;
 	int result = 0;
 	char *circular;
 	char *num;
 
 
 	if(digit < 2) return 0;
 	
 
 	circular = malloc(digit);
 	num = calloc(1, digit);
 	
 	for(k=num_a;k<=num_b;k++) {
 		convert_int(k, circular);
 		BitArray ba;
 		CreateBitArray(&ba, num_b * 10);
 
 		
 		for(i=0;i<digit;i++) {
 			for(j=i;j<digit+i;j++) {
 				//printf("%d : %d \n", j, j % digit);
 				//printf("%c", circular[j % digit]); 
 				index = j % digit;
 				num[cnt] = circular[index];
 				cnt++;
 			}
 			convert_num = atoi(num);
 			if((convert_num > k) && (convert_num >= num_a) && (convert_num <= num_b) )  {
 				if(GetBit(&ba, convert_num) != 1) {
 					OnBit(&ba, convert_num);
 		//			printf("%d %d %d %d\n", num_a, k, convert_num, num_b);
 					result++;
 				}
 			}
 			cnt = 0;
 		}
 
 		DestroyBitArray(&ba);
 	}
 	free(circular);
 	free(num);
 	return result;
 }
 
 
 int main()
 {
 	int case_no;
 	int num_m, num_a, num_b;
 	int i;
 	int digit1, digit2;
 	int result;
 
 	
 	scanf("%d", &case_no);
 	
 	for(i=0;i<case_no;i++) {
 		scanf("%d", &num_a);
 		scanf("%d", &num_b);
 
 		digit1 = get_digit(num_a);
 		result = check_recycle(num_a, num_b, digit1);
 		printf("Case #%d: %d\n", i + 1, result);
 	}
 }
 
 

