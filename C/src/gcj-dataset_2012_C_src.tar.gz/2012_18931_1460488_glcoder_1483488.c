#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char* rshift(char *buffer, size_t len) {
 	if (len < 1)
 		return;
 	
 	char t = buffer[len - 1];
 	size_t i = len;
 	
 	while (--i)
 		buffer[i] = buffer[i - 1];
 	
 	buffer[0] = t;
 	
 	return buffer;
 }
 
 int isgood(int n, int m) {
 	static char buffer[33] = {0};
 	
 	if (n >= m)
 		return 0;
 	
 	itoa(m, buffer, 10);
 	
 	size_t len, i;
 	len = i = strlen(buffer);
 	
 	while (--i)
 		if (atoi(rshift(buffer, len)) == n)
 			return 1;
 	
 	return 0;
 }
 
 int check(int A, int B) {
 	if (A > B)
 		return 0;
 	
 	int i, j, result = 0;
 	
 	for (i = A; i < B; ++i)
 		for (j = B; j > i; --j)
 			result += isgood(i, j);
 	
 	return result;
 }
 
 int main() {
 	int count, A, B, n = 0;
 	
 	fscanf(stdin, "%d", &count);
 	while (count--) {
 		if (fscanf(stdin, "\n%d %d", &A, &B) != 2)
 			continue;
 		
 		printf("Case #%d: %d\n", ++n, check(A, B));
 	}
 	
 	return 0;
 }

