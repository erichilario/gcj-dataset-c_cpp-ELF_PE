#include <stdio.h>
 
 int main(int argc, const char *argv[])
 {
 	int cases, casen=0;
 	int N, S, p, answer;
 	int tp;
 	int i;
 
 	scanf("%d\n", &cases);
 	while(casen<cases){
 		scanf("%d%d%d", &N, &S, &p);
 		answer = 0;
 		for(i=0;i<N;i++){
 			scanf("%d", &tp);
 			if(tp/3 >= p)
 				++answer;
 			else if(tp%3>0 && tp/3+1>=p)
 				++answer;
 			else if(S>0 && tp%3==0 && tp/3+1>=p && tp>0){
 				--S;
 				++answer;
 			}
 			else if(S>0 && tp%3==2 && tp/3+2>=p && tp<29){
 				--S;
 				++answer;
 			}
 		}
 		printf("Case #%d: %d\n", ++casen, answer);
 	}
 	return 0;
 }

