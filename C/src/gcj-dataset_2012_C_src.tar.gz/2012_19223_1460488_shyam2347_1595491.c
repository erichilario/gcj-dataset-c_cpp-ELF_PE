#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int read_line(FILE *fp, char *str1)
 {
      char ch;
      char *line = str1;
      while(1)
      {
          if( (ch = fgetc(fp)) == EOF)
              return 0;
          if( ch == '\n' )
          {
              *line++ = '\0';
              break;
          }
          if (ch == ' ')
          {
                 *line++ = '\0';
                 break;
                 continue;
          }
          if( ch == 0 )
          {
              break;
          }
          *line++ = ch;
      }
      return 1;
 }
 
 int process_input(FILE *fp, int *arr, int l, int sup, int p, int n)
 {
     fprintf(fp,"Case #%d: ",n+1);
     int start;
     int i = 0;
     int ret;
     int count = 0;
     int div;
     for (i=0; i<l; i++)
     {
         div = arr[i]/3;
         if (p*3 < arr[i])
         {
            count++;
         }
         else if (arr[i]%3 == 0 && div == p)
         {
            count++;
         }
         else if (div < p)
         {
              if ( arr[i] == 0)
                 continue;
              if( (p*3 - arr[i]) <= 2)
                   count++;
              else if( (p*3 - arr[i]) <= 4)
              {
                   if (sup > 0)
                   {
                      sup--;
                      count++;
                   }
              }
         }
     }
     fprintf(fp,"%d",count);
 }
 
 int main(int argc, char *argv[])
 {
     if (argc != 2)
     {
        printf("USAGE : %s <inp-filename>\n",argv[0]);
        exit(1);
     }
     FILE *fp;
     fp = fopen(argv[1],"r");
     if (fp == NULL)
     {
        printf("File not found\n");
        exit(1);
     }
     FILE *op;
     op = fopen("dance_outfile","w");
     if (op == NULL)
     {
        printf("Output file cannot be created\n");
        exit(1);
     }
     char *line;
     int ret = 1;
 
     line = malloc (sizeof(char)*4096);
     memset(line,'\0',4096);
     ret = read_line(fp,line);
     int count = atoi(line);
     free(line);
 
     int loop = 0;
     char *str1;
     int num, surprise, p;
     while(loop < count)
     {
      if (0 == ret)
      {
            printf("End of file reached. Input Violation\n");
            exit(1);
      }
      str1 = malloc (sizeof(char)*20);
      memset(str1,'\0',20);
      read_line(fp,str1);
      num = atoi(str1);
      
      memset(str1,'\0',20);
      read_line(fp,str1);
      surprise = atoi(str1);
      
      memset(str1,'\0',20);
      read_line(fp,str1);
      p = atoi(str1);
      int in_loop;
      int a[num];
      for (in_loop=0; in_loop<num; in_loop++)
      {
          memset(str1,'\0',20);
          read_line(fp,str1);
          a[in_loop] = atoi(str1);
      }
      process_input(op,a,num,surprise,p,loop);
      free(str1);
      loop++;
      if (loop != count)
         fprintf(op,"\n");
     }
     fclose(fp);
     fclose(op);
     return 0;
 }

