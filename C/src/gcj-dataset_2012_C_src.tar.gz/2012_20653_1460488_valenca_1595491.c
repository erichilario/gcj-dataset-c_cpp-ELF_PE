#include<stdio.h>
 #include<stdlib.h>
 
 int main(){
   int t,i,j,n,s,p,tmp;
   int c[100]={0};
   scanf("%d",&t);
   for(j=0;j<t;j++){
     scanf("%d %d %d",&n,&s,&p);
     if (p>1){
       for(i=0;i<n;i++){
 	scanf("%d",&tmp);
 	if(tmp>=((3*p)-2))
 	  c[j]++;
 	else if((tmp>=(3*p)-4) && s>0){
 	  c[j]++;
 	  s--;
 	}
       }
     }
     else if(p==1){
       for(i=0;i<n;i++){
 	scanf("%d",&tmp);
 	if(tmp>=1)
 	  c[j]++;
       }
     }
     else{
       for(i=0;i<n;i++){
 	scanf("%d",&tmp);
 	c[j]++;
       }
     }
   } 
   for(j=0;j<t;j++)
     printf("Case #%d: %d\n",j+1,c[j]);
   
   return 0;
   
 }

