#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int read_line(FILE *fp, char *str1, char *str2)
 {
      char ch;
      char *line = str1;
      while(1)
      {
          if( (ch = fgetc(fp)) == EOF)
              return 0;
          if( ch == '\n' )
          {
              *line++ = '\0';
              break;
          }
          if (ch == ' ')
          {
                 *line++ = '\0';
                 line = str2;
                 continue;
          }
          if( ch == 0 )
          {
              break;
          }
          *line++ = ch;
      }
      return 1;
 }
 
 int check_str(char *l, int num, int start, int end)
 {
     int len = strlen(l);
     char *new_str = malloc(sizeof(char)*(len+1));
     char *str_start = new_str;
     memset(new_str,'\0',sizeof(char)*(len+1));
     int i;
     for (i=num; i<len; i++)
     {
         *new_str = l[i];
         new_str++;
     }
     for (i=0; i<num; i++)
     {
         *new_str = l[i];
         new_str++;
     }
     *new_str = '\0';
     
     if (strcmp(l,str_start) != 0)
     {
         int num1 = atoi(str_start);
         if (num1 > atoi(l) && num1 <= end)
         {
                 return num1;
         }
     }
     return -1;
 }
 
 int match(char *l, char end_s, int start, int end)
 {
     int len = strlen(l);
     int orig = atoi(l);
     int i;
     int ret;
     int count = 0;
     for (i=1; i<len; i++)
     {
         if (l[i] <= end_s && l[i] != '0')
         {
                  ret = check_str(l,i,start,end);
                  if (ret != -1)
                  {
                      //printf("i : %d,  ret %d\n",orig,ret);
                      count++;
                  }
         }
     }
     if (count > 0)
        return count;
     else
         return -1;
 }
 
 int process_input(FILE *fp, char *str1, char *str2, int n)
 {
     fprintf(fp,"Case #%d: ",n+1);
     int start,end;
     start = atoi(str1);
     end   = atoi(str2);
     char end_s = *str2;
     int i = 0;
     int ret;
     int count = 0;
     for (i=start; i<=end; i++)
     {
         //printf("Count : %d\n",count);
          char buf[10];
          snprintf(buf,10,"%d",i);
          ret = match(buf,end_s,start,end);
          if (ret > 0)
          {
                  count += ret;
          }
     }
     fprintf(fp,"%d",count);
 }
 
 int main(int argc, char *argv[])
 {
     if (argc != 2)
     {
        printf("USAGE : %s <inp-filename>\n",argv[0]);
        exit(1);
     }
     FILE *fp;
     fp = fopen(argv[1],"r");
     if (fp == NULL)
     {
        printf("File not found\n");
        exit(1);
     }
     FILE *op;
     op = fopen("recycle_outfile","w");
     if (op == NULL)
     {
        printf("Output file cannot be created\n");
        exit(1);
     }
     char *line;
     int ret = 1;
 
     line = malloc (sizeof(char)*4096);
     memset(line,'\0',4096);
     ret = read_line(fp,line,NULL);
     int count = atoi(line);
     free(line);
 
     int loop = 0;
     char *str1, *str2;
     while(loop < count)
     {
      if (0 == ret)
      {
            printf("End of file reached. Input Violation\n");
            exit(1);
      }
      str1 = malloc (sizeof(char)*20);
      str2 = malloc (sizeof(char)*20);
      memset(str1,'\0',20);
      memset(str2,'\0',20);
      ret = read_line(fp,str1,str2);
      process_input(op,str1,str2,loop);
      free(str1);
      free(str2);
      loop++;
      if (loop != count)
         fprintf(op,"\n");
     }   
     return 0;
 }

