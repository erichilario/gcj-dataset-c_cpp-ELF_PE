#include <stdio.h>
 int check(int *x, int *y, int *r, int n){
 	int i;
 	for(i=0;i<n;i++){
 		unsigned long long dist = (unsigned long long)(x[n]-x[i])*(unsigned long long)(x[n]-x[i]);
 		dist += (unsigned long long)(y[n]-y[i])*(unsigned long long)(y[n]-y[i]);
 		if(dist < (unsigned long long)(r[n]+r[i])*(unsigned long long)(r[n]+r[i]))
 			return 0;
 	}
 	return 1;
 }
 int x[1001],y[1001],r[1001];
 int main(){
 	int t,p;
 	scanf("%d",&t);
 	for(p=1;p<=t;p++){
 		int n,w,l;
 		scanf("%d%d%d",&n,&w,&l);
 		int i;
 		for(i=0;i<n;i++)
 			scanf("%d", r+i);
 		int h=0,s=0,max=0;
 		//Place first line
 		x[0]=y[0]=0;
 		s=r[0];
 		max=r[0];
 		for(i=1;i<n;i++){
 			x[i]=s+r[i];
 			y[i]=0;
 			s+=2*r[i];
 			if(x[i]>w)break;
 			if(r[i]>max)max=r[i];
 			if(!check(x,y,r,i)){
 				fprintf(stderr, "%d WARN\n", i);
 			}
 		}
 		h=max;
 		s=r[i];
 		x[i]=0;
 		max=r[i];
 		y[i]=h+r[i];
 			if(!check(x,y,r,i)){
 				fprintf(stderr, "%d WARN\n", i);
 			}
 
 		for(i++;i<n;i++){
 			x[i]=s+r[i];
 			y[i]=h+r[i];
 			if(x[i]<=w && y[i]<=l){
 				s+=r[i];
 				if(r[i]>max)max=r[i];
 				continue;
 			}else{
 				s=0;
 				x[i]=0;
 				h+=2*max;
 				y[i]=h+r[i];
 				max=r[i];
 			}
 			if(x[i]>w || y[i]>l){
 				fprintf(stderr, "%d >_<\n", i);
 			}
 						if(!check(x,y,r,i)){
 				fprintf(stderr, "%d WARN\n",i);
 			}
 
 		}
 		printf("Case #%d: ", p);
 		for(i=0;i<n;i++)
 			printf("%d %d ",x[i],y[i]);
 		printf("\n");
 	}
 	return 0;
 }
 
 
 

