#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int main(int argc, char *argv[]){
   float i, j, T, N, S, p, y, tmp;
   
   FILE *input = fopen(argv[1], "r");
   FILE *output = fopen("output.txt", "w");
   
   if(NULL == input || NULL == output)
     exit(EXIT_FAILURE);
   
   fscanf(input, "%f ", &T);
   
   for(i = 0; i < T; i++){
     fscanf(input, "%f %f %f ", &N, &S, &p);
     y = 0;
     
     for(j = 0; j < N; j++){
       fscanf(input, "%f ", &tmp);
       
       if((tmp + 2)/3  >= p)
 	y++;
       else if((S > 0) && (tmp != 0) && ((tmp + 4)/3 >= p)){
 	y++;
 	S--;
       }
     }
     
     fprintf(output, "Case #%g: %g\n", i + 1, y);
   }
 
   fclose(input);
   fclose(output);
   
   return EXIT_SUCCESS;
 }

