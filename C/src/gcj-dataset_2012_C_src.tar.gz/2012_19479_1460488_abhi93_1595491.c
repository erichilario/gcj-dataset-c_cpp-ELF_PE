#include<stdio.h>
 
 int main(){
 	int cases,glrs,surp,best,arr[100],out_arr[100],count;
 	int i,j,min_scr,c_surp,p_surp;
 	FILE *fpi,*fpo;
 	fpi = fopen("input.in","r");
 
 	fscanf(fpi,"%d",&cases);
 	for(j=1;j<=cases;j++){
 
 		c_surp=0;p_surp=0;
 
 		fscanf(fpi,"%d %d %d",&glrs,&surp,&best);
 		count=glrs;
 
 		for(i=0;i<glrs;i++){
 			fscanf(fpi,"%d",&arr[i]);
 		}
 
 		min_scr=(best*3)-4;
 		
 		for(i=0;i<glrs;i++){
 
 			if(arr[i]<min_scr){
 				count--;
 			}
 
 			else if(arr[i]<=best*3){
 				if((best*3)-arr[i]>=3){if(best>=2)c_surp++;else count--;}
 				else if((best*3)-arr[i]==2)if(best>=2)p_surp++;
 			}
 
 			else if(arr[i]>best*3){
 				if(30-arr[i]>1)p_surp++;
 			}
 		}
 
 		if(c_surp>=surp)count-=(c_surp-surp);
 		else if(c_surp+p_surp<surp)count=0;
 		out_arr[j]=count;		
 	}
 
 	fclose(fpi);
 	fpo = fopen("out.txt","w");
 	for(i=1;i<=cases;i++)
 	fprintf(fpo,"%s%d%s%d\n","Case #",i,": ",out_arr[i]);
 	fclose(fpo);
 	return 0;
 }
