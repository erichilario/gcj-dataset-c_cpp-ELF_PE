#include <stdio.h>
 
 
 main()
 {
 	int N,t;
 	//ynficwlbkuomxsev.pdrjguha.
 	//abcdefghijklmnopqrstuvwxyz
 	char code[27]="yhesocvxduiglbkrztnwjpfmaq";
 	char c;
 
 	scanf("%d",&N);
 	t=0;
 	c=getchar();
 	while (c) {
 		if (c=='\n') {
 			if (t>0) printf("\n");
 			t++;
 			if (t>N) break;
 			printf("Case #%d: ", t);
 		}
 		else if (c==' ') putchar(' ');
 		else putchar(code[c-'a']);
 		c=getchar();
 	}
 
 }

