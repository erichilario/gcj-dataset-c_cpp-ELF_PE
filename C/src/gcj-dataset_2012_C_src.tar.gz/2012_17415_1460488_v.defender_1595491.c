#include<stdio.h>
 #include<malloc.h>
 #include<stdlib.h>
 
 struct points
 {
 	int a,b,c,t;
 	struct points *next;
 };
 typedef struct points pt;
 int main()
 {
 	int t,s,n,p,tot,sc;
 	int i,j,tt,k;
 	pt pt1[30];
 	
 	scanf("%d",&t);
 	
 	for(i=1;i<=t;i++)
 	{
 		sc=0;
 		scanf("%d %d %d",&n,&s,&p);
 		for(j=0;j<n;j++)
 		{	
 			scanf("%d",&pt1[j].t);
 			if(pt1[j].t%3==0)
 			{	
 				pt1[j].a=pt1[j].b=pt1[j].c=pt1[j].t/3;
 				if(sc<s && (pt1[j].a+2>=p) &&(pt1[j].b>1))
 					{
 						pt1[j].a+=2;
 					pt1[j].b-=2;
 					sc++;	
 					}
 				
 			}
 			else
 			{
 				pt1[j].a=pt1[j].b=pt1[j].c=pt1[j].t/3;
 				tt=t%3;
 				if(tt==1 )
 				{
                     if(sc>=s&& (pt1[j].a+2>=p)&&(pt1[j].a+2<=10) &&(pt1[j].b>1))
                     {
                              pt1[j].a+=2;
                              pt1[j].b--;
                     }
                     else
                          pt1[j].a++;
                 }
 				
 				else
 				{
 				if((pt1[j].a<p-1) &&(pt1[j].a+2>=p) && (pt1[j].a+2<=10)&& sc<s)
 				{pt1[j].a=pt1[j].a+2;sc++;}
 				else
 				{
 						pt1[j].a++;
 						pt1[j].b++;
 				}
 				
 				}
 			}
 		}
 					
 		
 	k=0;
 	for(j=0;j<n;j++)
 	if((pt1[j].a>=p) || (pt1[j].b>=p) || (pt1[j].c>=p) )
 		k++;
 		if(i!=1)
 		printf("\nCase #%d: %d",i,k);
 		else
 		printf("Case #%d: %d",i,k);
 	
 	}
 	
   	
  //  getch();
 	return 0;
 }

