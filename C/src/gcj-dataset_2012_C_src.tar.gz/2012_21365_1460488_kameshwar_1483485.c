#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 char lookup[26] = { 'y', 'h', 'e', 's', 'o', 'c', 'v', 'x', 'd', 'u', 'i', 'g', 'l', 'b', 'k', 'r', 'z', 't', 'n', 'w', 'j', 'p', 'f', 'm', 'a', 'q' };
 
 int main() {
 
 	int T, i, len, j;
 	char c[101];
 	scanf("%d", &T) ;
 	getchar();
 	for ( i = 1; i <= T; i++ ) {
 		gets(c);
 	//	scanf("%[^\n]", c);
 		len = strlen(c);
 		printf("Case #%d: ", i);
 		for ( j = 0; j < len; j++ ) {
 			switch ( c[j] ) {
 			case ' ' : putchar(c[j]);
 				break;
 			case '\n' : break;
 			default :
 				putchar(lookup[(int) c[j]-'a']);
 			}
   		} 
 		printf("\n");	
 	}
 	return 0;
 }

