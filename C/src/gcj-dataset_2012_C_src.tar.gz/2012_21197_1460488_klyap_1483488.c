/*
  * dacingwithgooglers.c
  *
  *  Created on: Apr 14, 2012
  *      Author: klyap
  */
 
 #include <string.h>
 #include <stdio.h>
 #include <math.h>
 
 void checkeach(FILE* output, int first, int second, int count);
 
 int main(void) {
 
 	FILE* input;
 	FILE* output;
 	int line = 1;
 	int totalline;
 	int i;
 	int first;
 	int second;
 
 	input = fopen("C-large.in", "r");
 	output = fopen("output.txt", "w");
 
 	fscanf(input, "%d\n", &totalline);
 
 	for (i = 0; i < totalline; i++) {
 
 		fscanf(input, "%d %d\n", &first, &second);
 		//printf("%d %d\n",first,second);
 		checkeach(output, first, second, line);
 		line++;
 	}
 
 	return 0;
 }
 
 void checkeach(FILE* output, int first, int second, int count) {
 	int i, j;
 	int remainder;
 	int walker = first;
 	int comparedigit;
 	int digitlength = 0;
 	int numberofdigit = 0;
 	int copyofwalker = walker;
 	int temporarynumber;
 	int check = 0;
 	int tempcompare;
 	int tempnum[2];
 
 	fprintf(output, "Case #%d: ", count);
 
 	while (check == 0) {
 		remainder = copyofwalker % 10;
 		copyofwalker = copyofwalker / 10;
 		if (remainder >= 0)
 			digitlength += 1;
 		if (copyofwalker == 0)
 			check = 1;
 	}
 
 	for (; walker < second; walker++) {
 		temporarynumber = walker;
 		comparedigit = walker + 1;
 		for (i = 0; i < digitlength - 1; i++) {
 			remainder = temporarynumber % 10;
 			if (remainder != 0) {
 				temporarynumber = (temporarynumber - remainder) / 10;
 				temporarynumber = temporarynumber
 						+ remainder * pow(10, (digitlength - 1));
 				tempcompare = comparedigit;
 
 				//for (j = 0; j < i; j++) {
 				//	if (temporarynumber != tempnum[i]) {
 				if (temporarynumber >= comparedigit && temporarynumber <= second
 						&& temporarynumber != walker && temporarynumber != tempnum[0]&& temporarynumber != tempnum[1]) {
 					numberofdigit++;
 				}
 
 				//	}
 				//	}
 			}
 			tempnum[i] = temporarynumber;
 			if (remainder == 0) {
 				temporarynumber = temporarynumber / 10;
 			}
 		}
 	}
 	fprintf(output, "%d\n", numberofdigit);
 }

