# include <stdio.h>
 # include <stdlib.h>
 # include <string.h>
 
 # define MaxG 100
 
 void Translate(FILE *in,FILE *out,char G[26]);
 int main(){ // main begin...
     char googlerese[26]="yhesocvxduiglbkrztnwjpfmaq";
     
     FILE*in = fopen("input.in","r");
     FILE*out = fopen("output.txt","w");
     
     if (in==NULL){ /// checks if file was opened successfully
                   printf("File Not Found - Exiting...");
                   system("pause");
                   exit(0);
                   }
     else{ // file was opened successfully
     
     Translate(in,out,googlerese);
     
     }
     
     
     fclose(in);
     fclose(out);
 system("pause");
 return 0;
 }
 
 
 void Translate(FILE *in,FILE *out, char G[26]){
      int num;
      char c;
      char sen[MaxG+1];
      int val;
      int i=1,j=0;
      fscanf(in,"%d",&num);
      
     // printf("Num is %d\n\n",num);
      fscanf(in,"%c",&c);
      
      for (i=0;i<num;i++){
          
          fprintf(out,"Case #%d: ",i+1);   
      
          
          
          fscanf(in,"%c",&c);
         //while(fgets(sen,MaxG+1, in) != NULL) {
                             
          while (c!='\n')                       
          {
                
                if (c!=' '){
                     val = c -'a';
                     fprintf(out,"%c",G[val]);
                     }
                     else {
                          fprintf(out," ");
                          }
                          
                //printf("%c",c);
                fscanf(in,"%c",&c);
                
                } // while end
          
          //printf("\n\n");
          fprintf(out,"\n");
       
          } // for end.
      
      
      
      
      
 }

