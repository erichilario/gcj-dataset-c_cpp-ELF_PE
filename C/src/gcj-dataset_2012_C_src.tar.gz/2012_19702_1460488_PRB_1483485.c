#include<stdio.h>
 
 int main()
 {
     int t=0;
     int k=1;
     char b[26]= "yhesocvxduiglbkrztnwjpfmaq";
     scanf("%d\n",&t);
     while(t>0)
     {
               char a[100];
               gets(a);
               int i;
               printf("Case #%d: ",k); 
               for(i=0;a[i]!='\0';i++)
               {
                         if(a[i]==' ')
                         printf("%c",a[i]);
                         else
                         printf("%c",b[a[i]-97]);
               }
               printf("\n");
               k++;
               t--;
     }
     getch();
  return 0;   
 }

