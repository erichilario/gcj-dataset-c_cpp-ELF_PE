/**
  * Author: Thibault Raffaillac <traf@kth.se>
  * gcc -std=gnu99 -O3 -march=native -DDEBUG
  */
 
 #ifdef DEBUG
 #define debug_printf(...) fprintf(stderr, __VA_ARGS__)
 #else
 #define debug_printf(...) ((void)0)
 #endif
 
 #include <assert.h>
 #include <ctype.h>
 #include <math.h>
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 /**
  * Solver for the unbounded knapsack problem with possibly negative profits.
  *
  * Example:
  * _ Begin with a sorted array of items with w, p, max and rate initialized
  *   (typical order is decreasing profit/weight): UKnapsack_item k[n];
  * _ Prepare the branch and bound heuristics: UKnapsack_init(k, n);
  * _ Fill a knapsack of capacity c: UKnapsack_fill(k, n, c, p, m, tol);
  *   p is the target profit (put INT_MAX to maximize, INT_MIN to minimize),
  *   m the minimal distance to p acceptable, and tol the distance below which
  *   the algorithm can stop searching. The final distance found is returned.
  *
  * The algorithm tries the maximal number first for each item, then decreases
  * it. For a given return value, the solution reported is the first found. If
  * no acceptable solution was found, m is returned and the num fields are left
  * untouched, otherwise they are all set.
  * The branch and bound approach works best with rates varying in granularity
  * (say 1, 10 and 100 rather than 9, 10 and 11). The complexity in the worst
  * case is (max+1)^n. Also, assertions are used to protect against overflow.
  */
 typedef struct UKnapsack_item {
 	long long p, max;
 	int num;
 } UKnapsack_item;
 
 int UKnapsack_comp(const void* a, const void* b) {
 	const UKnapsack_item* i = a;
 	const UKnapsack_item* j = b;
 	return (abs(j->p) - abs(i->p));
 }
 
 static inline int min(int a, int b) { return ((a < b) ? a : b); }
 
 void UKnapsack_init(UKnapsack_item* k, size_t n)
 {
 	long long max = 0;
 	for (UKnapsack_item* i = k + n - 1; i >= k; i--) {
 		i->max = max;
 		max += i->p;
 		debug_printf("%I64d: max=%I64d\n", i->p, i->max);
 	}
 }
 
 int UKnapsack_fill(UKnapsack_item* k, size_t n, long long p)
 {
 	unsigned long long m;
 	if (n == 0) {
 		debug_printf("Found!\n");
 		return (0);
 	} else {
 		debug_printf("%I64d: n=%u, p=%I64d, max=%I64d\n", k->p, n, p, k->max);
 		if (p + k->p <= k->max) {
 			if (UKnapsack_fill(k + 1, n - 1, p + k->p) == 0) {
 				k->num = 1;
 				return (0);
 			}
 		}
 		if (p - k->p >= -k->max) {
 			if (UKnapsack_fill(k + 1, n - 1, p - k->p) == 0) {
 				k->num = -1;
 				return (0);
 			}
 		}
 		if (p <= k->max && p >= -k->max) {
 			if (UKnapsack_fill(k + 1, n - 1, p) == 0) {
 				k->num = 0;
 				return (0);
 			}
 		}
 		return (1);
 	}
 }
 
 
 
 int main()
 {
 	UKnapsack_item k[20];
 	int T, t, n, i;
 	for (scanf("%d", &T), t = 1; t <= T; t++) {
 		scanf("%*d");
 		for (n = 0; n < 20; n++)
 			scanf("%I64d", &k[n].p);
 		qsort(k, 20, sizeof(*k), UKnapsack_comp);
 		UKnapsack_init(k, 20);
 		for (n = 0; n < 20 && UKnapsack_fill(k + 1 + n, 19 - n, k[n].p) != 0; n++);
 		printf("Case #%d:\n", t);
 		if (n == 20) {
 			puts("Impossible");
 		} else {
 			printf("%I64d", k[n].p);
 			for (i = n + 1; i < 20; i++) {
 				if (k[i].num > 0)
 					printf(" %I64d", k[i].p);
 			}
 			putchar('\n');
 			for (n++, i = 1; n < 20; n++) {
 				if (k[n].num < 0) {
 					if (i != 0) i = 0; else putchar(' ');
 					printf("%I64d", k[n].p);
 				}
 			}
 			putchar('\n');
 		}
 	}
 	return (EXIT_SUCCESS);
 }

