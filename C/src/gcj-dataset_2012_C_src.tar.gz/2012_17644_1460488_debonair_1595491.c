#include<stdio.h>
 int min(int a,int b)
 {
     if(a<=b)
     return a;
     return b;
 }
 int main()
 {
     int t,i,n,s,s1,s2,s3,p,e,sum,c,d,N=1;
     scanf("%d",&t);
     while(t--)
     {
         c=0;d=0;s1=s2=s3=0;
         scanf("%d%d%d",&n,&s,&p);
         int a[n];
         for(i=0;i<n;i++)
         {
             scanf("%d",&a[i]);
         }
 //        for(i=0;i<n;i++)
 //        {
 //            printf("%d\n",a[i]);
 //        }
         e=0;
         for(i=0;i<n;i++)
         {
             if(a[i]==(3*p-2)&& a[i]>0)
             {
                 s1++;
             }
             if(a[i]==(3*p-3)&&a[i]>0)
             {
                 s2++;
             }
             if(a[i]==(3*p-4)&&a[i]>0)
             {
                 s3++;
             }
         }
             sum=3*p-2;
             for(i=0;i<n;i++)
             {
             if(a[i]>sum)
             c++;
             }
             //printf("s= %d, s2+s3= %d\n",s,s2+s3);
             //printf("%d\n%d\n%d\n",c,s1,min(s,s2+s3));
             c=c+s1+min(s,s2+s3);
         printf("Case #%d: %d\n",N++,c);
     }
     return 0;
 }

