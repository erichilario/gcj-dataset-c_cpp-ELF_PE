#include<stdio.h>
 #include<conio.h>
 void main()
 {
 long c[50],A,B,p,q,q1,n,m,n1,arr[7];
 int a,T,i,len1,len2,d,e;
 FILE *fp;
 clrscr();
 scanf("%ld",&T);
 if(T<1 || T>50)
 {
 	printf("\nWrong input 1 <= T <= 50");
 	getch();
 	exit(1);
 }
 for(i=0;i<T;++i)
 {
 scanf("%ld %ld",&A,&B);
 len1=0;
 n1=A;while(n1!=0){n1/=10;len1++;}
 len2=0;
 n1=B;while(n1!=0){n1/=10;len2++;}
 if(len1!=len2)
 {
 	printf("\nWrong input Length (A) != Length(B)");
 	getch();
 	exit(1);
 }
 c[i]=0;
 q1=1;
 for(a=0;a<len1-1;++a)
 q1*=10;
 for(n=A;n<B;++n)
 {
 	e=0;
 	p=10;
 	q=q1;
 	for(a=0;a<len1-1;++a)
 	{
 		m=(n%p)*q+(n/p);
 		if(m>n && m<=B)
 		{for(d=0;d<e;++d)if(arr[d]==m)break;if(d==e){arr[e]=m;e++;c[i]++;}}
 		p*=10;
 		q/=10;
 	}
 }
 }
 fp=fopen("output1.txt","w");
 for(a=0;a<T;++a)
 fprintf(fp,"Case #%d: %ld\n",a+1,c[a]);
 fclose(fp);
 getch();
 }
 

