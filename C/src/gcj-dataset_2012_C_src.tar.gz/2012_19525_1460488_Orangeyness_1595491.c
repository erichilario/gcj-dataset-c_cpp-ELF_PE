#include <stdlib.h>
 #include <stdio.h>
 
 int main(int argc, char* argv[]) {
 	int test_case_count = 0;
 	int i, j;
 
 	scanf("%d", &test_case_count);
 	for (i = 0; i < test_case_count; i++) {
 		int result_count = 0;
 		int googler_count;
 		int suprising_count;
 		int cutoff;
 		
 		scanf("%d %d %d", &googler_count, &suprising_count, &cutoff);
 		
 		for (j = 0; j < googler_count; j++) {
 			int score;
 			scanf("%d", &score);
 			
 			if (score < cutoff) continue;
 			
 			if (score - cutoff*3 + 2 >= 0) {
 				result_count ++;
 				continue;
 				}
 				
 			if (suprising_count > 0 && score - cutoff*3 + 4 >= 0) {
 				result_count ++;
 				suprising_count --;
 				}
 			}
 			
 		printf("Case #%d: %d\n", i+1, result_count);
 		}
 	}
