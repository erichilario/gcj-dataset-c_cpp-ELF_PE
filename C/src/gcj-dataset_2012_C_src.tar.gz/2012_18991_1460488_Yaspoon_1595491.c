#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int main( int argc, char* argv[] )
 {
 	if( argc == 2 )
 	{
 		FILE* input = NULL;
 		FILE* output = NULL;
 
 		input = fopen( argv[1], "r" );
 		if( input != NULL )
 		{
 			output = fopen( "./output", "w" );
 			if( output != NULL )
 			{
 				int cases = 0;
 				int i = 0;
 				char line[102];
 				fgets( line, 102, input );
 				sscanf( line, "%d", &cases );
 				printf( "Read in cases:%d\n", cases );
 
 				for( i = 0; i < cases; i++ )
 				{
 					int googlers = 0;
 					int surprising = 0;
 					int highestScore = 0;
 					int noHighScore = 0;
 					int j = 0;
 					fscanf( input, "%d %d %d", &googlers, &surprising, &highestScore );
 					int scores[googlers];					
 					printf( "There are %d googlers, %d surprising triplets, %d highest score in this test case\n", googlers, surprising, highestScore );
 
 					for( j = 0; j < googlers; j++ )
 					{
 						fscanf( input, "%d", &scores[j] );
 					}
 
 					int minSurp = highestScore + 2 * (highestScore - 2);
 					int minNorm = highestScore + 2 * (highestScore - 1 );
 
 					for( j = 0; j < googlers; j++ )
 					{
 						if( scores[j] == 0 && highestScore != 0 )
 						{
 
 						}
 						else
 						{
 							if( scores[j] >= minNorm )
 							{
 								noHighScore++;
 							}						
 							else if( scores[j] >= minSurp && surprising > 0 )
 							{
 								noHighScore++;
 								surprising--;
 							}
 						}
 					}
 					
 					fprintf( output, "Case #%d: %d\n", i + 1, noHighScore );
 				}
 
 				fclose( output );
 			}
 			else
 			{
 				printf( "Could'nt open output for writing EXITING\n" );	
 			}
 	
 			fclose( input );
 		}
 		else
 		{
 			printf( "Could'nt open %s for reading EXITING\n", argv[1] );
 		}
 
 	}
 	else
 	{
 		printf( "Need input filename\n" );
 	}
 
 	return 0;
 }

