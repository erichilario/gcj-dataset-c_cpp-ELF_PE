#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <math.h>
 
 bool pasSurprenant(int note,int meilleureNote){
   return (note <= 3*meilleureNote) && (note >= fmax(0,3*meilleureNote - 2));
 }
 
 bool surprenant(int note,int meilleureNote){
   return (note <= 3*meilleureNote) && (note >= fmax(1,3*meilleureNote - 4));
 }
 
 bool peutLeFaireSansEtreSurprenant(int note,int minMeilleureNote){
   int i;
 
   for(i=minMeilleureNote;i<10;i++){
     if(pasSurprenant(note,i)){
       return true;
     }
   }
 
   return pasSurprenant(note,10);
 }
 
 bool peutLeFaireEnEtantSurprenant(int note,int minMeilleureNote){
   int i;
 
   for(i=minMeilleureNote;i<10;i++){
     if(surprenant(note,i)){
       return true;
     }
   }
 
   return surprenant(note,10);
 }
 
 void resoudreTest(){
   int nbDanseurs,casSurprenants,minMeilleureNote,i,resultat;
   int *tabNotes;
 
   scanf("%d",&nbDanseurs);
   scanf("%d",&casSurprenants);
   scanf("%d",&minMeilleureNote);
 
   tabNotes = calloc(nbDanseurs,sizeof(int));
 
   for(i=0;i<nbDanseurs;i++){
     scanf("%d",&tabNotes[i]);
   }
 
   resultat = 0;
 
   for(i=0;i<nbDanseurs;i++){
     if(peutLeFaireSansEtreSurprenant(tabNotes[i],minMeilleureNote)){
       resultat++;
     }else if(casSurprenants > 0){
       if(peutLeFaireEnEtantSurprenant(tabNotes[i],minMeilleureNote)){
 	resultat++;
 	casSurprenants--;
       }  
     }
   }
 
   printf("%u\n",resultat);
 }
 
 int main(int argc,char **argv){
   unsigned nbTests,i;
 
   scanf("%u\n",&nbTests);
 
   for(i=0;i<nbTests;i++){
     printf("Case #%u: ",i+1);
     resoudreTest();
   }
 
   return EXIT_SUCCESS;
 }

