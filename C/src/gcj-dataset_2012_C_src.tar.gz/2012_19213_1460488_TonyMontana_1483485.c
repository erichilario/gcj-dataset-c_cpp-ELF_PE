#include<stdio.h>
 #include<conio.h>
 void main()
 {
 char G[30][100],M[26]="yhesocvxduiglbkrztnwjpfmaq";
 int a,i,T,len;
 FILE *fp;
 clrscr();
 scanf("%d",&T);
 if(T>=1 && T<=30)
 {
 	i=0;
 	while(i<T)
 	{
 		fflush(stdin);
 		gets(G[i]);
 		fflush(stdin);
 		len=strlen(G[i]);
 		if(len<=100)
 		{
 			for(a=0;a<len;++a)
 			{
 				if(G[i][a]!=' ')
 				{
 					G[i][a]=M[G[i][a]-97];
 				}
 			}
 		 }
 		 else {printf("\nWrong input Length (G) > 100");getch();exit(1);}
 		 i++;
 	}
 }
 else {printf("\nWrong input T<1 OR T>30");getch();exit(1);}
 fp=fopen("output.txt","w");
 for(a=0;a<T;++a)
 {
 fprintf(fp,"Case #%d: %s\n",a+1,G[a]);
 }
 fclose(fp);
 getch();
 }
