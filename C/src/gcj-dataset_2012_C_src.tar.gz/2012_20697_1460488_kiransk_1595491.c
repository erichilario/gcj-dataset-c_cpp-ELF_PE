#include <stdio.h>
 #include <math.h>
 
 char done[101010];
 
 char normal[30][3];
 char surprise[30][3];
 
 int main() {
 	int i, j, a, b, c;
 	int T, S, N, p, score, y;
 
 	// prepare triplets for each possible score
 	for (i=1;i<=30;i++) {
 		for (a=10;a>=0;a--) {
 			for (b=10;b>=0;b--) {
 				for (c=10;c>=0;c--) {
 					if (a+b+c == i) {
 						if (done[a*10000+b*100+c] || done[a*10000+c*100+b] || done[b*10000+a*100+c] || done[c*10000+a*100+b] || done[b*10000+c*100+a] || done[c*10000+b*100+a] ) continue;
 						if (abs(a-b)<=1 && abs(a-c) <= 1 && abs(c-b) <= 1) {
 							done[a*10000+b*100+c] = 1;
 							normal[i][0] = a;
 							normal[i][1] = b;
 							normal[i][2] = c;
 						}
 						else if (abs(a-b)<=2 && abs(a-c) <= 2 && abs(c-b) <= 2) {
 							done[a*10000+b*100+c] = 1;
 							surprise[i][0] = a;
 							surprise[i][1] = b;
 							surprise[i][2] = c;
 						}
 					}
 				}
 			}
 		}
 	}
 
 	scanf("%d", &T);
 	for (i=0;i<T;i++) {
 		y = 0;
 		scanf("%d %d %d", &N, &S, &p);
 		for (j=0;j<N;j++) {
 			scanf("%d", &score);
 			if (normal[score][0] >= p) {
 				y++;
 			} else if (S > 0 && surprise[score][0] >= p) {
 				y++;
 				S--;
 			}
 		}
 			
 		printf("Case #%d: %d\n",i+1, y);
 	}
 
 
 }

