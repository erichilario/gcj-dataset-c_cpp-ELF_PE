#include<stdio.h>
 int main()
 {
 	FILE* fptr;
 	FILE* goof;
 	
 	int trials;
 	int i,j;
 	int googlers[100];
 	int surp[100];
 	int min[100];
 	int totscore[100][3];
 	int pos[100];
 	//int totscore2[1][50];
 	//int totscore3[2][50];
 	for(i=0;i<100;++i)
 		{
 			surp[i]=-1;
 			min[i]=-1;
 			googlers[i]=-1;
 			pos[i]=0;
 			for(j=0;j<3;++j)	
 			totscore[i][j]=-1;
 		}
 	fptr=fopen("B-small-attempt1.in","r");
 	goof=fopen("goo","w");
 	fscanf(fptr,"%d",&trials);
 	
 	for(i=0;i<trials;++i)
 	{
 		fscanf(fptr,"%d %d %d ",&googlers[i],&surp[i],&min[i]);
 		for(j=0;j<googlers[i];++j)
 		{
 			fscanf(fptr,"%d ",&totscore[i][j]);
 			
 		}
 //	for(j=0;j<googlers[i];++j)
 //		printf("%d ",totscore[i][j]);
 	}
 	for(i=0;i<trials;++i)
 	{
 		int x=min[i]*3;
 		int count=0;
 		int counts=surp[i];
 		for(j=0;j<googlers[i];++j)
 		{
 			if(x==0)
 			pos[i]++;
 			else if(x==3&&totscore[i][j]>=x-2)
 			pos[i]++;
 			else if(totscore[i][j]!=-1&&totscore[i][j]>=(x-2))//&&totscore[i][j]<=(x+2))
 			pos[i]++;
 			else if(counts!=0&&totscore[i][j]!=-1&&(totscore[i][j]<x-2&&totscore[i][j]>=x-4))//||(totscore[i][j]>(x+2)&&totscore[i][j]<=(x+4))))
 				{
 				if(x-4>0)
 				{
 				pos[i]++;
 				counts--;
 				}}
 		}
 	}
 	for(i=0;i<trials;++i)
 		{
 		fprintf(goof,"Case #%d: %d\n",i+1,pos[i]);
 		
 		}
 		
 }

