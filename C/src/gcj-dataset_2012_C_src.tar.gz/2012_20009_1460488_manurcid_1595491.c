#include <stdio.h>
 int main(){
     int TC,N,S,p,temp,counter,res;
     counter=1;
     scanf("%d\n",&TC);
     while(TC--){
         res=0;
         scanf("%d %d %d",&N,&S,&p);
         while(N--){
             scanf("%d",&temp);
             if(temp/3>=p&&temp>0){
                 res++;
             }else if(temp%3==1&&temp>0){
                 if((temp/3)+1>=p)
                     res++;
             }else if(temp%3==0&&S>0&&temp>0){
                 if((temp/3)+1>=p){
                     res++;
                     S--;
                 }
             }else if(temp%3==2&&temp>0){
                 if((temp/3)+1>=p){
                     res++;
                 }else if((temp/3)+2>=p&&S>0){
                     res++;
                     S--;
                 }
             }
            
         }
         printf("Case #%d: %d",counter++,res); 
         if(TC>=1)
             putchar('\n');
     }
     return 0;
 }
