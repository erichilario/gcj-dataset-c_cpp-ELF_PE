#include <stdio.h>
 
 int main() {
 	int T, i, j;
 	char input[10000];
 	char *mapping = "yhesocvxduiglbkrztnwjpfmaq";
 	scanf("%d\n", &T);
 	for (i=0;i<T;i++) {
 		gets(input);
 		for (j=0;input[j];j++) {
 			if (input[j] == ' ') continue;
 			input[j] = mapping[input[j]-'a'];
 		}	
 		printf("Case #%d: %s\n", i+1, input);
 	}
 	return 0;
 }

