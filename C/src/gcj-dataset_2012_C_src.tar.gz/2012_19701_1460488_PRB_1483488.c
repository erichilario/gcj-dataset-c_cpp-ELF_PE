#include<stdio.h>
 
 int permute(int a)
 {
     int b=0;
     if(a/100==0)
     {
       b=a/10+(a%10)*10;
     }
     else if(a/100!=0)
     {
          if(a%10==0)
          {
              b=a/100+(a%100)*10;
          }
          else
              b=a/10+(a%10)*100;
     }
 return(b);
 }
 
 
 int main()
 {
     int t=0;
     int k=1;
     scanf("%d\n",&t);
     
     while(t>0)
     {
               int count=0;
               int A,B;
               scanf("%d %d",&A,&B);
               printf("Case #%d: ",k);
               int i=A;
               if(A/9==0)
               {
                               count=0;
               }
               else if(A/99==0)
               {
                    for(i=A;i<B;i++)
                    {
                     if(permute(i)<=B && permute(i)>=A && i<permute(i))
                     count++;
                    }     
               }
               else
               {
                    for(i=A;i<B;i++)
                    {
                    int temp=permute(i);
                    if(temp<=B && temp>=A && i<temp)
                    {
                   //  printf("%d,%d\n",i,temp);
                     count++;
                    }
                    temp=permute(temp);
                    if(temp<=B && temp>=A && i<temp)
                    {
                    // printf("%d,%d\n",i,temp);
                     count++;
                    }
                    }     
                   
               }
 //              count=count/2;
               printf("%d\n",count);
               t--;
               k++;
     }
  return 0;   
 }

