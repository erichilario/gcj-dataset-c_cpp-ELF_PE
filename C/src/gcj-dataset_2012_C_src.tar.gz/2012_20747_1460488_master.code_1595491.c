#include<string.h>
 #include<fcntl.h>
 #include <sys/types.h>
 #include <stdio.h>
 #include <unistd.h>
 #include <errno.h>
 #include <stdlib.h>
 #include <math.h>
 #include <netdb.h>
 int t,n,s,p,count,ans=0,tempp;
 int check(int i);
 int check(int i)
 {
 	int th = 3*(tempp - 2)+1;
 	int thmin = 3*(tempp - 1);
 	if(i>thmin)
 		return 1;
 	else if(i>th && i<=thmin && count>0)
 	{	
 		count--;
 		return 1;
 	}
 	else
 		return 0;
 }
 /*int check(int i)
 {
 	int rest = i-tempp;
 	if(rest < 0)
 		return 0;
 	int rest_half = rest / 2;
 	int other_half = rest - rest_half;
 	int first = abs(tempp - rest_half);	
 	int second = abs(other_half - rest_half);
 	int third = abs(tempp - other_half);
 	//printf("ans=%d\np=%d",ans,tempp);
 	//printf(" f=%d s=%d t=%d",first,second,third);
 	//7 5 6 
 	//2 1 1	
 	if((first == 1 || first == 0))
 	{
 		if((second == 1 || second == 0))
 		{
 			if((third == 1 || third == 0))
 			{
 				return 1;
 			}
 			else if(third == 2 && count>0)
 			{
 				count--;
 				return 1;
 			}
 			else
 			{
 				if(tempp<10)
 				{
 					tempp++;
 					return check(i);
 				}
 				else
 					return 0;		
 			}
 		}
 		else if((third == 1 || third == 0 || (third == 2 && second == 0)) && second == 2 && count>0)
 		{
 			count--;
 			return 1;
 		}
 		else
 		{
 			if(tempp<10)
 			{
 				tempp++;
 				return check(i);
 			}
 			else
 				return 0;		
 		}
 	}
 	else if((second == 1 || second == 0 || (second == 2 && third == 0)) && (third == 1 || third == 0 || (third == 2 && second == 0)) && first == 2 && count>0)
 	{
 		count--;
 		return 1;
 	}
 	else
 	{
 		if(tempp<10)
 		{
 			tempp++;
 			return check(i);
 		}
 		else
 			return 0;		
 	}
 }
 */
 int main(int argc, char *argv[])
 {
         int i,j,k;
         char b;
 	int fdi = open("input.txt",O_RDONLY);
         int fdo = open("output.txt",O_WRONLY|O_CREAT,0644);
         close(1);
         dup(fdo);
         close(0);
         dup(fdi);
         close(fdo);
         close(fdi);
 	scanf("%d\n",&t);
 	for(j=0;j<t;j++)
         {
 		scanf("%d %d %d ",&n,&s,&p);
 		//printf("%d %d %d ",n,s,p);
 		tempp = p;
 		i=0;
 		ans = 0;
 		count = s;
 		printf("Case #%d: ",j+1);
 		while(i<n)
 		{                
 			scanf("%d",&k);	
 			//printf("\nk=%d ",k);
 			tempp = p;	
 			if(k>=0 && tempp==0)ans++;
 			else if(k>0 && tempp==1)ans++;
 			else if(check(k) == 1 && tempp>1) ans++;
 			i++;
 		}
 		printf("%d\n",ans);
         }
 return 0;
 }

