#include <stdio.h>
 #include <string.h>
 
 #define AQTY 	('z'-'a'+1)
 #define CHMAX	(100+3)
 #define CLUEQTY	4
 #define DEBUG	0
 
 int main() {
     int 	i,T,j;
     char 	map[AQTY],rmap[AQTY];
     char	str[CHMAX];
     char	*p,c,g;
     char	clue[4][2][CHMAX] = {
 	{"y qee",
 	 "a zoo"},
 	{"ejp mysljylc kd kxveddknmc re jsicpdrysi",
 	 "our language is impossible to understand"},
 	{"rbcpc ypc rtcsra dkh wyfrepkym veddknkmkrkcd",
 	 "there are twenty six factorial possibilities"},
 	{"de kr kd eoya kw aej tysr re ujdr lkgc jv",
 	 "so it is okay if you want to just give up"}
     };
 
     memset(map,'0',sizeof(*map)*AQTY);
     memset(rmap,'0',sizeof(*rmap)*AQTY);
     
     for(i=0;i<CLUEQTY;++i)
 	for(j=strlen(clue[i][0])-1;j>=0;--j) {
 	    p = clue[i][0]+j;
 	    g = *p;
 	    if(g>='a' && g<='z' && rmap[g-'a']=='0') {
 		rmap[g-'a'] = c = clue[i][1][j];
 		map[c-'a'] = g;
 	    }
 	}
     
     for(j=0,i=AQTY-1;i>=0;--i) 
 	if(map[i]=='0') {
 	    ++j;
 	    T = i;
 	    if(DEBUG) printf("char %c have no mapping\n",i+'a');
 	}
     if(j>1)
 	return 1;
     for(j='0',i=AQTY-1;i>=0;--i) 
 	if(rmap[i]=='0') {
 	    j = i+'a';
 	    if(DEBUG) printf("char %c have no reverse mapping\n",i+'a');
 	}
     map[T] = j;
     rmap[j-'a'] = 'a'+T;
     T=0;
     scanf("%d\n",&T);
     for(i=1;i<=T;++i) {
 	memset(str,0,sizeof(*str)*CHMAX);
 	gets(str);
 	for(j=strlen(str);j>=0;--j) {
 	    p = str+j;
 	    g = *p;
 	    if(g >= 'a' && g <= 'z') 
 		*p = rmap[g-'a'];
 	}
 	printf("Case #%d: %s\n",i,str);
     }
     return 0;
 }

