#include<stdio.h>
 #include<string.h>
 int main()
 {
     int t,i,len,n=1;
     char g[102];
     scanf("%d",&t);
     scanf("%*c");
     while(t--)
     {
 
         gets(g);
         len=strlen(g);
         for(i=0;i<len;i++)
         {
             switch(g[i])
             {
                 case 'a':g[i]='y';
                         break;
                 case 'b':g[i]='h';
                         break;
                 case 'c':g[i]='e';
                         break;
                 case 'd':g[i]='s';
                         break;
                 case 'e':g[i]='o';
                         break;
                 case 'f':g[i]='c';
                         break;
                 case 'g':g[i]='v';
                         break;
                 case 'h':g[i]='x';
                         break;
                 case 'i':g[i]='d';
                         break;
                 case 'j':g[i]='u';
                         break;
                 case 'k':g[i]='i';
                         break;
                 case 'l':g[i]='g';
                         break;
                 case 'm':g[i]='l';
                         break;
                 case 'n':g[i]='b';
                         break;
                 case 'o':g[i]='k';
                         break;
                 case 'p':g[i]='r';
                         break;
                 case 'q':g[i]='z';
                         break;
                 case 'r':g[i]='t';
                         break;
                 case 's':g[i]='n';
                         break;
                 case 't':g[i]='w';
                         break;
                 case 'u':g[i]='j';
                         break;
                 case 'v':g[i]='p';
                         break;
                 case 'w':g[i]='f';
                         break;
                 case 'x':g[i]='m';
                         break;
                 case 'y':g[i]='a';
                         break;
                 case 'z':g[i]='q';
                         break;
                 default : break;
             }
         }
         printf("Case #%d: ",n++);
         puts(g);
     }
     return 0;
 }

