#include <stdio.h>
 #include <stdlib.h>
 
 struct pair
 {
 	int x, y;
 };
 
 struct hashmap
 {
 	int size;
 	struct pair *data;
 };
 
 struct hashmap *make_map(int size)
 {
 	struct hashmap *result = malloc(sizeof(struct hashmap));
 	result->size = size;
 	result->data = calloc(size, sizeof(struct pair));
 	return result;
 }
 
 void hash(struct hashmap *map, int x, int y)
 {
 	int hash = (x + y) % map->size;
 	while (map->data[hash].x || map->data[hash].y)
 		hash++;
 	map->data[hash].x = x;
 	map->data[hash].y = y;
 }
 
 int is_hashed(struct hashmap *map, int x, int y)
 {
 	int hash = (x + y) % map->size;
 	while (1)
 	{
 		if ((map->data[hash].x == 0) && (map->data[hash].y == 0))
 			return 0;
 		if ((map->data[hash].x == x) && (map->data[hash].y == y))
 			return 1;
 		hash++;
 	}
 }
 
 void destroy_map(struct hashmap *map)
 {
 	free(map->data);
 	free(map);
 }
 
 int ifilog(int b, int x)
 {
 	int exp = 1, r = 0;
 	while (exp <= x)
 	{
 		exp *= b;
 		r++;
 	}
 	return r;
 }
 
 int ipow(int x, int y)
 {
 	int i, r = 1;
 	for (i = 0; i < y; i++)
 		r *= x;
 	return r;
 }
 
 int result(int x, int y)
 {
 	int i, j, k, l, n, m, nd, ipj, ipij, hsize, r = 0;
 	struct hashmap *visited;
 	nd = ifilog(10, y);
 	for (i = 2; i <= nd; i++)
 	{
 
 		visited = make_map(ipow(10, i)); 
 		for (j = 1; j < i; j++)
 		{
 			ipj = ipow(10, j);
 			ipij = ipow(10, i-j);
 			for (k = ipj / 10; k < ipj; k++)
 				for (l = ipij / 10; l < ipij; l++)
 				{
 					n = l * ipj + k;
 					m = k * ipij + l;
 					if ((n >= x) && (m > n) && (y >= m)
 						&& !is_hashed(visited, n, m))
 					{
 						hash(visited, n, m);
 						r++;
 					}
 				}
 		}
 		destroy_map(visited);
 	}
 	return r;
 }
 
 int main()
 {
 	int i, n, x, y;
 	scanf("%d", &n);
 	for (i = 0; i < n; i++)
 	{
 		scanf("%d %d", &x, &y);
 		printf("Case #%d: %d\n", i+1, result(x, y));
 	}
 	return 0;
 }

