#include <stdio.h>
 
 #define N 200
 
 
 int main(void)
 {
     FILE *fp;
     int t, n, count;
     double min_score, total_score, req_score;
     register int i, j;
     double score[N];
     fp=fopen("output.txt", "w");
     scanf("%d", &t);
     for(i=1; i<=t; i++)
     {
         total_score=0;
         scanf("%d", &n);
         for(j=0; j<n; j++)
         {
             scanf("%lf", &score[j]);
             total_score+=score[j];
         }
         min_score=2*total_score/n;
         count=0;
         for(j=0; j<n; j++)
         {
             if(min_score<=score[j]) { score[j]=-1; count++; }
         }
         min_score=total_score;
         for(j=0; j<n; j++)
         {
             if(score[j]!=-1) min_score+=score[j];
         }
         min_score/=(n-count);
         fprintf(fp, "Case #%d:", i);
         for(j=0; j<n; j++)
         {
             if(score[j]==-1) req_score=0;
             else req_score=((min_score-score[j])*100)/total_score;
             fprintf(fp, " %f", req_score);
         }
         fprintf(fp, "\n");
     }
     fclose(fp);
     return 0;
 }

