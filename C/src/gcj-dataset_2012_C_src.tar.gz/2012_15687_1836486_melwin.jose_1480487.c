#include <stdio.h>
 int main()
 {
         int t, n, a[200], i, j, sum;
         double c;
         scanf("%d", &t);
         for(j = 1; j <= t; j++)
         {
                 printf("Case #%d: ", j);
                 sum = 0;
                 scanf("%d", &n);
                 for(i = 0; i < n; i++)
                 {
                         scanf("%d", &a[i]);
                 }
                 for(i = 0; i < n; i++)
                         sum += a[i];
                 for(i = 0; i < n; i++)
                 {       
                         c = (100.00/n) + ((100.00/n) - ((float)a[i]/sum)*100.00);
                         if(c < 0)
                                 printf("0.000000 ");
                         else
                                 printf("%lf ", c);              
                 }       
                 printf("\n");
         }
         return 0;
 }

