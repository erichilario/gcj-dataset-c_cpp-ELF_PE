#include <stdio.h>
 #include <math.h>
 
 int main () {
 	int T, i;
 	scanf ("%d", &T);
 
 	for (i=1; i<=T; i++) {
 		float d;
 		int n, a, j;
 		scanf ("%f%d%d",&d, &n, &a);
 
 		float t[n], x[n], acc[a];
 
 		for (j=0; j<n; j++) {
 			scanf ("%f%f", &t[j], &x[j]);
 		}
 
 		for (j=0; j<a; j++)
 			scanf ("%f", &acc[j]);
 
 		printf ("Case #%d: \n", i);
 		for (j=0; j<a; j++) {
 			float time = sqrt((2.0*d)/acc[j]);
 			if (x[n-1] >= d) {
 				if (t[n-1] < time)
 					printf ("%.6f ", time);
 				else 
 					printf ("%.6f ", t[n-1]);
 			}
 			else {
 				float vel = (x[n-1] - x[n-2])/(t[n-1] - t[n-2]);
 				float rt = t[n-1] + (d - x[n-1])/vel;
 				if (rt < time)
 					printf ("%.6f ", time);
 				else
 					printf ("%.6f ", rt);
 			}
 			printf ("\n");
 		}
 	}
 	return 0;
 }

