#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 char hash[26];
 int count[26];
 
 int main(int argc, char* argv[]) {
    int test_case_count = 0;
    int i;
 
 	hash[0] = 'y';
 	hash[1] = 'h';
 	hash[2] = 'e';
 	hash[3] = 's';
 	hash[4] = 'o';
 	hash[5] = 'c';
 	hash[6] = 'v';
 	hash[7] = 'x';
 	hash[8] = 'd';
 	hash[9] = 'u';
 	hash[10] = 'i';
 	hash[11] = 'g';
 	hash[12] = 'l';
 	hash[13] = 'b';
 	hash[14] = 'k';
 	hash[15] = 'r';
 	hash[16] = 'z'; //
 	hash[17] = 't';
 	hash[18] = 'n';
 	hash[19] = 'w';
 	hash[20] = 'j';
 	hash[21] = 'p';
 	hash[22] = 'f';
 	hash[23] = 'm';
 	hash[24] = 'a'; 	
 	hash[25] = 'q'; //
    
    char buf[101];
    scanf("%d", &test_case_count);
 	gets(buf);
    for (i = 0; i < test_case_count; i++) {
 	  gets(buf);
 	  
 	  int j;
 	  for (j = 0; j < strlen(buf); j++) {
 		if (buf[j] == ' ') continue;
 		
 		buf[j] = hash[buf[j] - 'a'];
 		count[buf[j] - 'a'] ++;
 		}
 	  
 	  printf("Case #%d: %s\n", i+1, buf);
 	  
 	  }
    }
