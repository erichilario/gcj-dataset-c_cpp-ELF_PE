#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
 
 	int count=1;
 	int testcases;
 	scanf("%d",&testcases);
 	getchar();
 	int i;
 	for(i=0;i<testcases;i++)
 	{
 		char buffconv='@';
 		printf("Case #%d: ",count);
 		
 		while(buffconv!='\n')
 		{
 			scanf("%c",&buffconv);
 			switch(buffconv)
 			{
 				case 'a':
 					printf("y");
 					break;
 				case 'b':
 					printf("h");
 					break;
 				case 'c':
 					printf("e");
 					break;
 				case 'd':
 					printf("s");
 					break;
 				case 'e':
 					printf("o");
 					break;
 				case 'f':
 					printf("c");
 					break;
 				case 'g':
 					printf("v");
 					break;
 				case 'h':
 					printf("x");
 					break;
 				case 'i':
 					printf("d");
 					break;
 				case 'j':
 					printf("u");
 					break;
 				case 'k':
 					printf("i");
 					break;
 				case 'l':
 					printf("g");
 					break;
 				case 'm':
 					printf("l");
 					break;
 				case 'n':
 					printf("b");
 					break;
 				case 'o':
 					printf("k");
 					break;
 				case 'p':
 					printf("r");
 					break;
 				case 'q':
 					printf("z");
 					break;
 				case 'r':
 					printf("t");
 					break;
 				case 's':
 					printf("n");
 					break;
 				case 't':
 					printf("w");
 					break;
 				case 'u':
 					printf("j");
 					break;
 				case 'v':
 					printf("p");
 					break;
 				case 'w':
 					printf("f");
 					break;
 				case 'x':
 					printf("m");
 					break;
 				case 'y':
 					printf("a");
 					break;
 				case 'z':
 					printf("q");
 					break;
 				case ' ':
 					printf(" ");
 					break;
 				case '\n':
 					printf("\n");
 					count+=1;
 					break;
 			}
 		}
 
 	}
 	return 0;
 }

