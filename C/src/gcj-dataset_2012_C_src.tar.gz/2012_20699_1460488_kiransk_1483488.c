#include <stdio.h>
 
 int main() {
 	unsigned int T, A, B, i, j, tmp, n, m, multiple, oldm;
 	int numDigits=0, numPairs;
 	scanf("%d\n", &T);
 	for (i=0;i<T;i++) {
 		scanf("%d %d", &A, &B);
 		numPairs = numDigits = 0;
 		multiple = 1;
 		tmp = A;
 		while (tmp > 0) {numDigits++;tmp /= 10;multiple*=10;}
 		multiple = multiple/10;
 		if (A < B && numDigits > 1) {
 			for (n=A;n<=B;n++) {
 				m = n;
 				oldm = m;
 				for (j=0;j<numDigits-1;j++) {
 					m = m/10+(m%10)*multiple;
 					if (oldm == m || m < A || m <= n || m > B) continue;
 					oldm = m;
 					numPairs++;
 				}
 			}
 		}	
 		printf("Case #%d: %d\n", i+1, numPairs);
 	}
 	return 0;
 }

