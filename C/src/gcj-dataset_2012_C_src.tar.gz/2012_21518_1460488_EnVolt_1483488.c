#include<conio.h>
 int main()
 {
     int i,j,k,t,a,b,temp,digit,count,r,div,no;
     scanf("%d",&t);
     for(i=0;i<t;i++)
     {
         scanf("%d%d",&a,&b);
         count=0;
         for(j=a;j<=b;j++)
         {
             temp=j;
             digit=1;
             while(temp!=0)
             {
                 temp=temp/10;
                 digit=digit*10;
             }
             temp=j;
             for(k=10;k<=digit;k=k*10)
             {
                 r=temp%k;
                 div=temp/k;
                 no=(r*digit/k)+div;
                 if(no>j&&no<=b)
                     count++;
             }
         }
         printf("Case #%d: %d\n",i+1,count);
     }
     return 0;
 }

