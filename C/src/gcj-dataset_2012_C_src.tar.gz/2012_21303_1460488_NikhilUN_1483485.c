#include<stdio.h>
 #include<string.h>
 char letter(char );
 int main()
 {
 	FILE *fptr;
 	FILE *f;
 	char c;
 	int n;
 	int i;
 	char q;
 	int e;
 //	char s[8]="Case #";
 	
 	fptr=fopen("A-small-attempt3.in","r");
 	f=fopen("new file","w");
 	fscanf(fptr,"%d",&n);
 	fgetc(fptr);
 	for(i=0;i<n;++i)
 	{
 		e=i+1;
 		fprintf(f,"%s","Case #");
 		fprintf(f,"%d",i+1);
 		putc(':',f);
 		putc(' ',f);
 		
 		//printf("Case #%d:",i+1);
 		//puts(s,f);
 		//putc((i+1),f);
 		//putc(':',f);	
 		c=fgetc(fptr);
 		while(c!='\n')
 		{	
 			
 			q=letter(c);
 			putc(q,f);
 			//printf("%c",q);		
 			
 		c=fgetc(fptr);	
 		}
 		putc('\n',f);
 		//printf("\n");
 	}
 }
 
 char letter(char a)
 {
 	switch(a)
 	{
 		case 'a':
 			return 'y';
 			break;
 		
                 case 'b':
                         return 'h';
                         break;	
 
 		case 'c':
                         return 'e';
                         break;
                 
                 case 'd':
                         return 's';
                         break;  
 		case 'e':
                         return 'o';
                         break;
                 
                 case 'f':    
 			return 'c';
                         break;  
 		case 'g':
                         return 'v';
                         break;
                 
                 case 'h':
                         return 'x';
                         break;  
 		case 'i':
                         return 'd';
                         break;
                 
                 case 'j':
                         return 'u';
                         break;  
 		case 'k':
                         return 'i';
                         break;
                 
                 case 'l':
                         return 'g';
                         break;  
 		case 'm':
                         return 'l';
                         break;
 
                 case 'n':
                         return 'b';
                         break;
 		case 'o':
                         return 'k';
                         break;
 
                 case 'p':
                         return 'r';
                         break;
 		case 'q':
                         return 'z';
                         break;
 
                 case 'r':
                         return 't';
                         break;
 		case 's':
                         return 'n';
                         break;
 
                 case 't':
                         return 'w';
                         break;
 		case 'u':
                         return 'j';
                         break;
 
                 case 'v':
                         return 'p';
                         break;
 		case 'w':
                         return 'f';
                         break;
 
                 case 'x':
                         return 'm';
                         break;
 		case 'y':
                         return 'a';
                         break;
 
                 case 'z':
                         return 'q';
                         break;
 		case ' ':
 			return ' ';
 			break;
 		}
 }

