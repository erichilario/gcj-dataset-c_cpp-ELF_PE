#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main() {
 	char input[101], output[101], mapping[0x100], rmapping[0x100];
 	int count;
 	size_t i, length, n;
 	
 	input[100] = output[100] = 0;
 	count      = 0;
 	
 	memset(mapping,  0, 0x100);
 	memset(rmapping, 0, 0x100);
 	
 	fscanf(stdin, "%d\n", &count);
 	
 	while (count--) {
 		gets(input);
 		fscanf(stdin, "%s", output);
 		fscanf(stdin, "%s ", output);
 		gets(output);
 		
 		length = strlen(input);
 		if (strlen(output) != length) {
 			fprintf(stderr, "Something goes wrong\n");
 			continue;
 		}
 		
 		for (i = 0; i < length; ++i)
 			mapping[input[i]] = output[i];
 	}
 	
 	mapping['q'] = 'z';
 	mapping['z'] = 'q';
 	
 	fscanf(stdin, "%d\n", &count);
 	n = 0;
 	
 	while (count--) {
 		gets(input);
 		length = strlen(input);
 		
 		for (i = 0; i < length; ++i)
 			output[i] = mapping[input[i]];
 		output[i] = 0;
 		
 		printf("Case #%d: %s\n", ++n, output);
 	}
 	
 	return 0;
 }

