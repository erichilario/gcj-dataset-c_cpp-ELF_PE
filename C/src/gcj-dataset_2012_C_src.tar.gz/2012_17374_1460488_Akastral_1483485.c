#include<stdio.h>
 int main ( int argc, char *argv[])
 {
 	int getindex(char, char []);
 	int j=0,k=1;
 	FILE *fp = fopen (argv[1], "r" );
 	FILE *fp1= fopen (argv[2], "w" );
 	char a[]={"ynficwlbkuomxsevzpdrjgthaq"};
 	char b[]={"abcdefghijklmnopqrstuvwxyz"};
 //	char c[]={"lsklas alskals alskl aklsl alsdjf sdkh f sdj\n"};
 	char c[200];
 	int n=atoi(fgets(c, sizeof c, fp));
 	while (k<=n) /* read a line */
 	{
 		fgets(c,sizeof c, fp );
 		fprintf(fp1,"Case #%d: ",k);
 //		printf("Case #%d: ",k);
 		for(j=0;c[j]!='\0';j++)
 		{
 			int i=getindex(c[j],a);
 			if(i==-1)
 			{
 //				printf("%c",c[j]);
 				putc(c[j],fp1);
 			}
 			else
 			{
 //				printf("%c",b[i]);
 				putc(b[i],fp1);
 			}
 		}
 //		printf("\n");
 		k++;	
 	}
 	fclose (fp);
 	fclose(fp1);
 	return 0;
 }
 
 
 
 
 int getindex(char as,char a[])
 {
 	int m=-1,i=0;
 	for(i=0;i<26;i++)
 	{
 		if(as==a[i])
 		{
 			m=i;
 			break;
 		}
 	}
 	return m;
 }

