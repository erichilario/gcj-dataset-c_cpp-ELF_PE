#include <stdio.h>
 #include <string.h>
 char *word_table = "ynficwlbkuomxsevzpdrjgthaq";
 
 int occurence(int c)
 {
 	int i;
 	int len;
 	for(i=0;i<strlen(word_table);i++) {
 		if(c == word_table[i]) {
 			return i + 'a';
 		}
 	}
 }
 
 
 char *convert(char *str)
 {
 	char *p;
 	p = str;
 	while(*p) {
 		if(*p != ' ') {
 			*p = occurence(*p);
 		} else {
 			*p = ' ';
 		}
 		p++;
 	}
 
 }
 
 int main()
 {
 	int case_no = 0;
 	char in_buf[255];
 
 	fgets(in_buf, 255, stdin);
 	memset(in_buf, 0, 255);
 	while(fgets(in_buf, 255, stdin)) {
 		case_no++;
 		in_buf[strlen(in_buf) - 1] = '\0';
 		convert(in_buf);
 		printf("Case #%d: %s\n", case_no, in_buf);
 		memset(in_buf, 0, 255);
 	}
 
 	
 }
 
 

