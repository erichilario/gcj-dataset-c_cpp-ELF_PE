#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 int main(int argc, char *argv[]) {
   int T, N;
   int i, j, k;
   int p;
   char x[9], y[9];
 
   int q[50][2];
   int a[50];
   FILE *fp = fopen(argv[1], "r");
   if (fp == NULL) {
     printf("File not found\n");
     return 1;
   }
 
 
   fscanf(fp, "%d", &T);
   for (i = 0; i < T; i++) {
     fscanf(fp, "%d", &q[i][0]);
     fscanf(fp, "%d", &q[i][1]);
   }
 
   int e,e2,l, l2;
   int match;
   int test;
   for (i = 0; i < T; i++) {
     a[i] = 0;
     if (q[i][0] < 10) {
       printf("Case #%d: %d\n", i+1, 0);
       continue;
     }
     for (j = q[i][0]; j < q[i][1]; j++) {
       sprintf(x, "%d", j);
       //printf("%d\n", j);
       match = 0;
       l = strlen(x) - 1;
       l2 = l;
       e = (int) pow(10, l);
       for (k = j + 1; k <= q[i][1]; k++) {
         //printf("\t%d\n", k);
         for (p = 1; p <= l; p++) {
           e2 = (int)pow(10,p);
           test = k % (int)pow(10,p);
           test *= (e/(e2/10));
           l2 = (k/e2);
           if ((l2+test) == j) {
 
             a[i]++;
             break;
           }
         }
       }
     }
     printf("Case #%d: %d\n", i+1, a[i]);
   }
 
   return 0;
 }

