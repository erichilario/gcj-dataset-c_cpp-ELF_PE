#include <stdio.h>
 #include <string.h>
 #include <gmp.h>
 
 int DEB = 0;
 mpz_t S[500];
 int chosen[2][500];
 mpz_t sum[2];
 int N;
 
 int search(int pos, int pass)
 {
 	int found;
 	if (DEB)
 	{
 		int i,j;
 		gmp_printf("pos=%d,pass=%d,N=%d... %Zd/%Zd/%Zd\n", pos, pass,N,sum[0],sum[1],S[pos]);
 		for (i=0;i<2;i++)
 		{
 			for (j=0;j<N;j++)
 				printf("%d ",chosen[i][j]);
 			printf("\n");
 		}
 	}
 	if (pos == N) return 0;
 	if (pass && chosen[0][pos])
 	{
 		return search(pos + 1, pass);
 	}
 
 	mpz_t prev_sum;
 	mpz_init_set(prev_sum, sum[pass]);
 	chosen[pass][pos] = 1;
 	mpz_add(sum[pass], sum[pass], S[pos]);
 	//if (DEB) gmp_printf("pos=%d/pass=%d: SS=%Zd,%Zd... %Zd\n",pos,pass,sum[0],sum[1],prev_sum);
 	if (pass)
 	{
 		int cmpr = mpz_cmp(sum[0], sum[1]);
 		if (cmpr == 0)
 		{
 			int i,j,s;
 
 			for(i=0;i<2;i++)
 			{
 				s=0;
 				for(j=0;j<N;j++)
 				{
 					if (chosen[i][j])
 					{
 						gmp_printf("%s%Zd",s?" ":"", S[j]);
 						s=1;
 					}
 				}
 				printf("\n");
 			}
 			mpz_clear(prev_sum);
 			return 1;
 		}
 		if (cmpr < 0)
 		{
 			chosen[pass][pos] = 0;
 			mpz_set(sum[pass], prev_sum);
 			mpz_clear(prev_sum);
 			return 0;
 		}
 	}
 	
 	if (!pass) if (search(0,1)) return 1;
 	
 	found = search(pos + 1, pass);
 	
 	mpz_set(sum[pass], prev_sum);
 	mpz_clear(prev_sum);
 
 	if (found) return 1;
 
 	chosen[pass][pos] = 0;
 	return search(pos + 1, pass);
 }
 
 int main(int argc, char **argv)
 {
 	int T;
 	scanf("%d",&T);
 	int i;
 	mpz_t temp;
 	mpz_init(temp);
 	mpz_init(sum[0]);
 	mpz_init(sum[1]);
 	for(i=1;i<=T;i++)
 	{
 		scanf("%d",&N);
 		int j,k;
 		for(j=0;j<N;j++)
 		{
 			gmp_scanf("%Zd",S+j);
 			for(k=0;k<j;k++)
 			{
 				if (mpz_cmp(S[k], S[j])>0)
 				{
 					mpz_set(temp, S[k]);
 					mpz_set(S[k], S[j]);
 					mpz_set(S[j], temp);
 				}
 			}
 		}
 		if (DEB)
 		{
 			printf("S=");
 			for(j=0;j<N;j++)
 			{
 				gmp_printf("%Zd ", S[j]);
 			}
 			printf("\n");
 		}
 		printf("Case #%d:\n",i);
 		memset(chosen,0,sizeof chosen);
 		mpz_set_si(sum[0], 0);
 		mpz_set_si(sum[1], 0);
 		if (!search(0,0))
 		{
 			printf("Impossible\n");
 		}
 	}
 	return 0;
 }

