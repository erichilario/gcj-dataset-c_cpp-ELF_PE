#include<stdio.h>
 #include<string.h>
 int k,y,o;
 void compute(int x,int p)
 {
 int z=y;
 if(x==(3*p)||x==((3*p)-1)||x==((3*p)+2)||x==((3*p)-2))
 {
 	if(x==((3*p)-1))
 	{
 	if(p-1>=0)
 	k=k+1;
 	}
 	else if(x==(3*p)-2)
 	{
 	if(p-1>=0)
 	k=k+1;y=y+1;}
 	else if(p-2>=0)
 	{k=k+1;y=y+1;}
 	
 }	
 else if((x==((3*p)+3)||x==((3*p)+4)||x==((3*p)-3)||x==((3*p)-4))&&(p-2>=0))
 {y=y+1;}
 else if((x==((3*p)+1)||x==((3*p)-1))&&(p-1>=0))
 k=k+1; 
 if(p!=o)
 y=z;
 }
 int main()
 {
 int t,x,i,temp,s,n,p;
 scanf("%d",&t);
 int b[100];
 for(i=0;i<t;i++)
 {
 scanf("%d %d %d",&n,&s,&p);
 o=p;
 while(n>=1)
 {
 scanf("%d",&x);
 if(x<=((3*p)+4))
 compute(x,p);
 else
 {
 temp=(x-4)/3;
 temp++;
 while(temp>p)
 {
 compute(x,temp);
 temp--;
 }
 }
 n--;
 }
 if(y>0)
 b[i]=k+s;
 else
 b[i]=k;
 k=0;y=0;
 }
 for(i=0;i<t;i++)
 printf("Case #%d: %d\n",(i+1),b[i]);
 return 0;
 }
