#include <stdio.h>
 
 int main()
 {
 	char a[] = "yhesocvxduiglbkrztnwjpfmaq";
 	char str[105];
 	int i;
 	int j;
 	int t;
 
 	scanf ("%d", &t);
 
 	j = 1;
 	while (j <= t) {
 	getchar ();
 	scanf ("%[^\n]s", str);
 
 	printf ("Case #%d: ", j);
 	for (i= 0; str[i] != '\0'; i++) {
 		if (str[i] != ' ') {
 			putchar (a[str[i] - 97]);
 		} else {
 			putchar (' ');
 		}
 	}
 
 	putchar ('\n');
 	j++;
 	}
 
 	return 0;
 }

