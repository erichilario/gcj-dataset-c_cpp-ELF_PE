#include <stdio.h>
 
 int main()
 {
 	int n;
 	int m;
 	int k;
 	int i;
 	int p;
 	int q;
 	int a;
 	int j;
 	int t;
 
 	scanf ("%d", &t);
 
 	j = 1;
 	while (j <= t) {
 		scanf ("%d %d %d", &k, &m, &n);
 
 		i = 0;
 		p = 0;
 		q = 0;
 		while (i < k) {
 			scanf ("%d", &a);
 
 			if (a >= (3 * n - 4) && a != 0) {
 				p++;
 			}
 
 			if ((a == (3 * n - 4) || a == (3 * n - 3)) && a != 0 && a != 1) {
 				q++;
 			}
 
 			i++;
 		}
 
 		if (n == 0) {
 			p = k;
 		}
 
 		if (q > m) {
 			printf ("Case #%d: %d\n", j, p - q + m);
 		} else {
 			printf ("Case #%d: %d\n", j, p);
 		}
 
 		j++;
 	}
 
 	return 0;
 }

