#include <stdio.h>
 
 int main() {
     int T;
     int N;
     int S;
     int p;
     int pont_googler;
     int i,j;
     int resultado = 0;
     scanf("%d", &T);
     for(i = 0; i < T; i++) {
         scanf("%d %d %d", &N, &S, &p);
         for (j = 0; j < N; j++) {
             scanf("%d", &pont_googler);
             if ((3*p-3 == pont_googler || 3*p-4 == pont_googler) && S != 0 && pont_googler != 0) {
                 resultado++;
                 S--;
             }
             else if (pont_googler >= 3*p-2)
                 resultado++;
         }
         printf("Case #%d: %d\n", i+1, resultado);
         resultado = 0;
     }
 
     return 0;
 }

