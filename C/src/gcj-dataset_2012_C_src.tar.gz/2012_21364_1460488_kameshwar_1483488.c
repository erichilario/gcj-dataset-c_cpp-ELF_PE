#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 int rotate(int val, int len) {
 	int tmp;
 	len -= 1;
 	int minBit = val % 10 ;
 	tmp = val / 10;
 	tmp = minBit * pow(10, len) + tmp;
 	return tmp;
 }
 int main() {
 	int i, j; 
 	int l;
 	int T;
 	int k;
 	int count;
 	int A, B;
 	scanf("%d", &T); 
 
 	for ( l = 1; l <= T; l++ ) {
 		count = 0;
 		scanf("%d%d", &A, &B);
 		for ( i = A; i <= B; i++ ) {
 			char buf[32];
 			sprintf(buf, "%d", i);
 			int len = strlen(buf);
 			k = rotate(i, len);
 			for ( j = 0; j < len; j++ ) {
 				sprintf(buf, "%d", k);
 				if ( k > i && (strlen(buf) == len) && k <= B) {
 					count++;
 				}
 				k = rotate(k, len);
 			}
 		} 
 		printf("Case #%d: %d\n", l, count);
 	} 
 	return 0;
 }
 

