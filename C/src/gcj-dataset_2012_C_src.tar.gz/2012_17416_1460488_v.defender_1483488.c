#include<stdio.h>
 #include<stdlib.h>
 #include<malloc.h>
 #include<math.h>
 struct linklist
 {
        int n,m;
        struct linklist *next;       
 };
 typedef struct linklist ll;
 int main()
 {
     int a,b,i,m,n,j,d,flag;
     int x,k;
     ll *curr,*temp,*start=NULL;
     curr=start;
    scanf("%d",&k);
    for(x=1;x<=k;x++)	
    {
    	 scanf("%d %d",&a,&b);
    	 start=NULL;
    	 curr=start;
    for(i=a;i<=b;i++)
    {         temp=start;
                n=i;
                  j=0;
                  while(n>0)
                  {
                      n=n/10;
                      j++;  
                  }
                  n=i;
                  for(d=1;d<j;d++)
                  {	flag=0;
                         m=n%(int)pow(10,d);
                         n=n/pow(10,d);
                         m=m*pow(10,j-d)+n;
                         if(m>i && m<=b && m>=a)
                         {if(curr==NULL)
                          { curr=(ll *)malloc(sizeof(ll)); start=curr;
                            curr->m=m;
                         curr->n=i;
                          }
                         else
                         {   
                          while(temp!=NULL)
                			{
                    			if((temp->m==m && temp->n==i)|| (temp->m==i && temp->n==m))
                    			{ flag=1;
                    			break;   
                    			}                           
                    			temp=temp->next;
                			}
                			if(flag==0)
                             	{
                             	curr->next=(ll *)malloc(sizeof(ll));              
                             	curr=curr->next;
                             	curr->next=NULL;
                         
                             	curr->m=m;
                         	curr->n=i;
                         	}
                         }
                         }
                         n=i; 
                                
                  }                     
                      
     }
     
     
     for(i=0,temp=start;temp!=NULL;temp=temp->next,i++);
     printf("Case #%d: %d\n",x,i);
     }	 
  return 0;   
 }

