#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int recycle(int n, int p){
   int x = n%10;
   
   return (n - x)/10 + x*pow(10, p);
 }
 
 int main(int argc, char *argv[]){
   int i, j, n = 0, a, b, nb_r, tmp, p;
   
   FILE *input = fopen(argv[1], "r");
   FILE *output = fopen("output.txt", "w");
   
   if(NULL == input || NULL == output)
     exit(EXIT_FAILURE);
   
   fscanf(input, "%d ", &n);
   
   for(i = 0; i < n; i++){
     fscanf(input, "%d %d ", &a, &b);
     fprintf(output, "Case #%d: ", i+1);
     
     nb_r = 0;
     for(j = a; j <= b; j++){
       tmp = j;
       p = floor(log(j)/log(10));
 
       while((tmp = recycle(tmp, p)) != j)
 	if(a <= tmp && tmp <= b)
 	  nb_r++;
     }
     fprintf(output, "%d\n", nb_r/2);
   }
   
   fclose(input);
   fclose(output);
   
   return EXIT_SUCCESS;
 }
 

