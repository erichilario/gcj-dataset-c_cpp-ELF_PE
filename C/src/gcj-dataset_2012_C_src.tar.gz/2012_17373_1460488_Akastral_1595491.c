#include<stdio.h>
 int main ( int argc, char *argv[])
 {
 	int getindex(char, char []);
 	int j=0,k=1,n=0;
 	FILE *fp = fopen (argv[1], "r" );
 	FILE *fp1= fopen (argv[2], "w" );
 
 
 
 	fscanf (fp, "%d\n", &n);
 //	printf("%d",n);
 	while(k<=n)
 	{
 		int t=0,s=0,p=0,l=0,cnt=0,temp=0;
 		int tr[30];
 		fscanf (fp, "%d %d %d", &t,&s,&p);
 	//	printf("%d %d %d",t,s,p);
 		for(l=0;l<t;l++)
 		{	
 			fscanf(fp, "%d", &tr[l]);
 //			printf("%d ",tr[l]);
 		}
 //		printf("\n");
 		for(l=0;l<t;l++)
 		{
 			if(p==0)
 			{
 				cnt=cnt+1;
 				continue;
 			}
 			if(tr[l]<2*p)
 				continue;
 			if(tr[l]>=3*p)
 			{
 				cnt=cnt+1;
 				continue;
 			}
 			if(tr[l]==(3*p)-1 || tr[l]==(3*p)-2 )
 				cnt=cnt+1;
 			if(tr[l]==(3*p)-2 || tr[l]==(3*p)-3 || tr[l]==(3*p)-4)
 				temp=temp+1;
 		}
 		if(temp>s)
 			cnt=cnt+s;
 		if(temp<=s)
 			cnt=cnt+temp;
 
 		fprintf(fp1,"Case #%d: %d\n",k,cnt);
 
 		k++;
 	}	
 	fclose (fp);
 	fclose(fp1);
 	return 0;
 }

