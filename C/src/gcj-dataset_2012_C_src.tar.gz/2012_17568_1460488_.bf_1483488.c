#include <stdio.h>
 #include <string.h>
 
 #define true 1
 #define false 0
 
 typedef unsigned char bool;
 
 int getDigits(int n){
   char str_n[10+1];
   
   sprintf(str_n, "%d", n);
   
   return strlen(str_n);
 }
 
 int calc(int n, int dig, int A, int B) {
   int vet[8], p10 = 1;
   int i, k;
   int r = 0;
   
   for(i = 1; i < dig; i++)
     p10 *= 10;
   
   for(i = 0; i < dig; i++) {
     vet[i] = (n%10)*p10;
     vet[i] += n/10;
     n = vet[i];
   }
   
   for(i = 0; i < dig; i++)
     for(k = i+1; k < dig; k++)
       if(vet[i] > vet[k])
       {
         vet[i] ^= vet[k];
         vet[k] ^= vet[i];
         vet[i] ^= vet[k];
       }
   
   for(i = 0; i < dig; i++)
     if((i == 0 || vet[i] != vet[i-1]) && vet[i] >= A && vet[i] <= B && vet[i] != n)
       r++;
     
   return r;
 }
 
 int main()
 {
   int T, cont = 0;
   
   scanf("%d", &T);
   while(T--)
   {
      int A, B, dig;
      int i;
      int res = 0;
      
      scanf("%d %d", &A, &B);
      
      dig = getDigits(A);
 
      for(i = A; i <= B; i++)
        res += calc(i, dig, A, B);
      
      printf("Case #%d: %d\n", ++cont, res/2);
   }
   
 return 0;
 }

