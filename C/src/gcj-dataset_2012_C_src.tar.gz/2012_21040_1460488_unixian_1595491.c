#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int cmp_func(const void *a, const void *b)
 {
 	return(*(int *)b - *(int *)a);
 }
 
 
 //printf("point: %d quot: %d rem: %d max : %d least:%d suprise:%d result: %d\n", point, d.quot, d.rem, max, least_point, *suprise, *result);
 
 store_point(int *max_point, int point, int index)
 {
 	max_point[index] = point;
 }
 
 
 calc_points(int *max_points, int index, int suprise, int least_point)
 {
 	int i;
 	div_t d;
 	int max;
 	int p_max;
 	int point;
 	int result = 0;
 	int try;
 
 	try = suprise;
 	
 	for(i=0;i<index;i++) {
 		point = max_points[i];
 		//printf("point %d\n", point);
 		d = div(point, 3);
 		if(point < 2) {
 			max = point;
 			p_max = point;
 		} else {
 			if(d.rem == 0) {
 				max = d.quot;
 				p_max = d.quot + 1;
 			}
 			if(d.rem == 1) {
 				p_max = d.quot + 1;
 				max = d.quot + 1;
 			}
 			if(d.rem == 2) {
 				max = d.quot + 1;
 				p_max = d.quot + 2;
 			}
 		}
 
 
 		if(max < least_point && p_max >= least_point && (try > 0) ) {
 			result++;
 			//printf("pmax hit point: %d quot: %d remain: %d max_q: %d p_max_q: %d result: %d try: %d\n", point, d.quot, d.rem, max, p_max, result, try);
 			try--;
 			continue;
 		} 
 
 		if(max >= least_point) {
 			result++;
 			//printf("max hit point: %d quot: %d remain: %d max_q: %d p_max_q: %d result: %d try: %d\n", point, d.quot, d.rem, max, p_max, result, try);
 		}
 
 	}
 	return result;
 }
 
 int main( void)
 {
 
 	int i, j, k;
 	int case_no;
 	int no_dancer;
 	int no_suprise;
 	int least_point;
 	int result = 0;
 	int point;
 
 	int points[100] = {0, };
 
 	scanf("%d", &case_no);
 
 	for(i=0; i<case_no; i++) {
 		scanf("%d", &no_dancer);
 		scanf("%d", &no_suprise);
 		scanf("%d", &least_point);
 		result = 0;
 		for(j=0;j<no_dancer;j++) {
 			scanf("%d", &point);
 			store_point(points, point, j);
 		}
 
 		result = calc_points(points, no_dancer, no_suprise, least_point);
 		//printf("least point: %d suprise: %d\n", least_point, no_suprise);
 		printf("Case #%d: %d\n", i+1, result);
 		memset(points, 0, sizeof(int) * 100);
 	}
 }
 
 
 //		qsort(max_point, no_dancer, sizeof(int), cmp_func);
 

