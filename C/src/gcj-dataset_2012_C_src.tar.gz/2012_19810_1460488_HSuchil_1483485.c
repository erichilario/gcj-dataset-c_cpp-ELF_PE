#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, char * argv[]) {
 	char s[26]={'y','h','e','s','o','c','v','x','d',	'u','i','g','l','b','k','r','z','t','n','w','j','p','f','m','a','q'};
 	char in[1050];
 	int n,nC,i;
 	scanf("%d\n",&n);
 	for(nC = 1;nC<=n;nC++){
 		scanf("%[^\n]\n",in);
 		for(i=0;in[i]!='\0';i++){
 			if(in[i]!=' ')
 				in[i] = s[in[i]-'a'];
 		}
 		printf("Case #%d: %s\n",nC,in);
 	}
 	return 0;
 }
