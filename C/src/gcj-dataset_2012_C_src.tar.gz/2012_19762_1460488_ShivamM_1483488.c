#include <stdio.h>
 #include <math.h>
 
 int main()
 {
 	int a;
 	int b;
 	int i;
 	int j;
 	int k;
 	int c;
 	int n;
 	int p;
 	int q;
 	int arr[15];
 	int t;
 	int m;
 
 	scanf ("%d", &t);
 
 	m = 1;
 	while (m <= t) {
 		scanf ("%d %d", &a, &b);
 		n = log10 (a); // number of digits - 1
 
 		c = 0;
 		for (i = a; i <= b; i++) {
 			k = i;
 			q = 0;
 
 			for (j = 0; j < n; j++) {
 				while (k % 10 == 0) {
 					k = k / 10;
 					j++;
 				}
 
 				k = (k % 10) * ((int) pow (10, n)) + (k / 10);
 				if (i < k && k >= a && k <= b) {
 					for (p = 0; p < q; p++) {
 						if (arr[p] == k) {
 							break;
 						}
 					}
 
 					if (p == q) {
 						c++;
 						arr[q] = k;
 						q++;
 					}
 				}
 			}
 
 		}
 
 		printf ("Case #%d: %d\n", m, c);
 		m++;
 	}
 
 	return 0;
 }

