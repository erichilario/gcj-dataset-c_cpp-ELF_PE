#include <stdio.h>
 int main(){
     char map[26]={'y','h','e','s','o','c','v','x','d','u','i','g','l','b','k','r','z','t','n','w','j','p','f','m','a','q'};
     char input[101];
     int i,j,k=1;
     scanf("%d",&j);
     while(j>0){
     getchar();
     scanf("%[^\n]s",input);
     printf("Case #%d: ",k++);
     for(i=0;i<100&&input[i]!='\0';++i){
         if(input[i]==' ')
             printf(" ");
         else if(input[i]>='a'&&input[i]<='z')
             printf("%c",map[input[i]-97]);
     }
     printf("\n");
     --j;
     }
 }

