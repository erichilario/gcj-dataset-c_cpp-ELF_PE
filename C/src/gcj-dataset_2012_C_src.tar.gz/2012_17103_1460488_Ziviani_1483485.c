#include <stdio.h>
 
 unsigned char map[] = {'y', 'h', 'e', 's', 'o', 'c', 'v', 'x', 'd', 'u', 'i', 'g', 'l', 'b', 'k', 'r', 'z', 't', 'n', 'w', 'j', 'p', 'f', 'm', 'a', 'q'};
 unsigned char tcs[30][102];
 
 unsigned char translate(unsigned char l)
 {
     if ( l < 'a' || l > 'z' )
         return l;
 
     int index = l - 'a';
 
     return map[ index ];
 }
 
 void translateWord(unsigned char w[101])
 {
     while ( *w != '\0' ) {
 
         if ( *w == '\n' ) {
             *w = '\0';
             break;
         }
 
         *w = translate( *w );
         *w++;
     }
 }
 
 
 int main(int argc, char *argv[])
 {
     int c;
     
     int t;
 
     scanf("%d", &t);
 
     if ( t <= 0 || t > 30 )
         return 0;
 
     while((c = getchar()) != '\n' && c != EOF) ;
 
     for ( int i = 0; i < t; ++i ) {
 
         fgets ( tcs[ i ], 102, stdin );
     }
 
     for ( int i = 0; i < t; ++i ) {
 
         translateWord( tcs[ i ] ); 
 
         printf( "Case #%d: %s\n", i + 1, tcs[ i ] );
 
     }
 
     return 0;
 }

