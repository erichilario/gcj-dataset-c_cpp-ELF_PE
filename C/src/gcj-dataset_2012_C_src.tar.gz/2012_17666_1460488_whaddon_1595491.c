#include <stdio.h>
 #include <stdlib.h>
 
 int result(int n, int s, int p, int *t)
 {
 	int i, r1 = 0, r2 = 0;
 	for (i = 0; i < n; i++)
 	{
 		if (t[i] + 2 >= p * 3)
 			r1++;
 		if ((t[i] + 4 >= p * 3) && (t[i] != 0 | p != 1))
 			r2++;
 	}
 	r1 += s;
 	if (r2 < r1)
 		return r2;
 	return r1;
 }
 
 int main()
 {
 	int i, j, t, n, s, p, *ti;
 	scanf("%d", &t);
 	for (i = 0; i < t; i++)
 	{
 		scanf("%d %d %d", &n, &s, &p);
 		ti = malloc(n * sizeof(int));
 		for (j = 0; j < n; j++)
 			scanf("%d", ti + j);
 		printf("Case #%d: %d\n", i+1, result(n, s, p, ti));
 		free(ti);
 	}
 }

