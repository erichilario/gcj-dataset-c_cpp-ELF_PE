#include <stdio.h>
 #include <math.h>
 
 int main(){
 	int testn,test=1;
 	scanf("%d" , &testn);
 
 	while(testn--){
 		int i,tem,N,S,p;
 		int arr[31]={0,};
 		int sum=0;
 		scanf("%d%d%d" , &N ,&S , &p);
 		tem=N;
 
 		while(tem--){
 			int in;
 			scanf("%d" , &in);
 			arr[in]++;
 		}
 
 		for(i=30;i>=0;i--){
 			int point;
 
 			if(arr[i]==0)
 				continue;
 
 			point = floor(i/3);
 
 			if(i%3==1 || i%3==2)
 				point++;
 			if(point>=p){
 				sum += arr[i];
 				continue;
 			}
 
 			if( i!=0 && (i%3==0 || i%3==2) && point+1==p){
 				if(S>arr[i]){
 					sum+=arr[i];
 					S -= arr[i];
 				}
 				else{
 					sum += S;
 					S=0;
 				}
 			}
 		}
 
 		printf("Case #%d: %d\n" , test++ , sum);
 	}
 }

