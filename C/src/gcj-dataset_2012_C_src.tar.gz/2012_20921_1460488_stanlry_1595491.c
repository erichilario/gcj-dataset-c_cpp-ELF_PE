#include <stdio.h>
 
 int main(){
     int input=0,caNum=0,special=0,tempSp;
     int i,target=0,possible=0;
     int n[3],cases=0,num=1;
     scanf("%d",&cases);
     while(cases>0){
         scanf("%d %d %d",&caNum,&special,&target);
         tempSp=special;
         //printf("ok");
         for(i=0;i<caNum;++i){
             scanf("%d",&input);
             //printf("get it: %d",input);
             getMark(input,n);
             if(greater(n,target,&special))
                 ++possible;
         }
         printf("Case #%d: %d\n",num++,possible);
         --cases;
         possible=0;
     }
 
 }
 int greater(int* n,int target,int* special){
     if(n[2]>=target) return 1;
     else if(0&&n[2]-n[0]==1&&n[0]==n[1]&&n[0]!=0&&*special>0){
         if(n[2]+1>=target){
             n[0]-=1;
             n[2]+=1;
             (*special)--;
             return 1;
         }
     }else if(n[2]==n[0]&&n[2]==n[1]&&n[2]!=0&&*special>0){
         if(n[2]+1>=target){
             n[0]-=1;
             n[2]+=1;
             (*special)--;
             return 1;
         }
     }else if(n[2]-n[0]==1&&n[2]==n[1]&&*special>0){ //&&n[0]!=0
         if(n[2]+1>=target){
             n[0]-=1;
             n[2]+=1;
             (*special)--;
             return 1;
         }
     }
     return 0;
 }
 
 int getMark(int input,int *n){
     int i;
     i=input/3;
     n[0]=i;
     n[1]=i;
     n[2]=i;
     if(input-i*3==1) n[2]+=1;
     if(input-i*3==2){ n[2]+=1; n[1]+=1;}
     /*for(i=0;i<3;i++)
         printf("%d ",n[i]);
     printf("\n");*/
 }

