#include <stdio.h>
 #include <string.h>
 
 int main(){
 	int testn;
 	int test=1;
 	scanf("%d%*c" , &testn);
 
 	while(testn--){
 		int i;
 		char str[1000];
 		char str2[1000];
 
 		gets(str);
 
 		for(i=0;i<strlen(str);i++){
 			if(str[i]=='a')
 				str2[i]='y';
 
 			else if(str[i]=='b')
 				str2[i]='h';
 
 			else if(str[i]=='c')
 				str2[i]='e';
 
 			else if(str[i]=='d')
 				str2[i]='s';
 
 			else if(str[i]=='e')
 				str2[i]='o';
 
 			else if(str[i]=='f')
 				str2[i]='c';
 
 			else if(str[i]=='g')
 				str2[i]='v';
 
 			else if(str[i]=='h')
 				str2[i]='x';
 
 			else if(str[i]=='i')
 				str2[i]='d';
 
 			else if(str[i]=='j')
 				str2[i]='u';
 
 			else if(str[i]=='k')
 				str2[i]='i';
 
 			else if(str[i]=='l')
 				str2[i]='g';
 
 			else if(str[i]=='m')
 				str2[i]='l';
 
 			else if(str[i]=='n')
 				str2[i]='b';
 
 			else if(str[i]=='o')
 				str2[i]='k';
 
 			else if(str[i]=='p')
 				str2[i]='r';
 
 			else if(str[i]=='q')
 				str2[i]='z';
 
 			else if(str[i]=='r')
 				str2[i]='t';
 
 			else if(str[i]=='s')
 				str2[i]='n';
 
 			else if(str[i]=='t')
 				str2[i]='w';
 
 			else if(str[i]=='u')
 				str2[i]='j';
 
 			else if(str[i]=='v')
 				str2[i]='p';
 
 			else if(str[i]=='w')
 				str2[i]='f';
 
 			else if(str[i]=='x')
 				str2[i]='m';
 
 			else if(str[i]=='y')
 				str2[i]='a';
 
 			else if(str[i]=='z')
 				str2[i]='q';
 			else
 				str2[i]=str[i];
 		}
 		str2[i]='\0';
 		printf("Case #%d: %s\n" , test++ , str2);
 	}
 }

