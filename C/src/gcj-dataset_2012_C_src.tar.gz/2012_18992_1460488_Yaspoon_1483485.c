#include <stdio.h>
 #include <stdlib.h>
 
 int main( int argc, char* argv[] )
 {
 	if( argc == 2 )
 	{
 		FILE* input = NULL;
 		FILE* output = NULL;
 
 		input = fopen( argv[1], "r" );
 		if( input != NULL )
 		{
 			output = fopen( "./output", "w" );
 			if( output != NULL )
 			{
 				int cases = 0;
 				int i = 0;
 				char line[102];
 				fgets( line, 102, input );
 				sscanf( line, "%d", &cases );
 				printf( "Read in cases:%d\n", cases );
 
 				for( i = 0; i < cases; i++ )
 				{
 					fgets( line, 102, input );
 					printf( "Read in line: %s converting\n", line );
 					fprintf( output, "Case #%d: ", i + 1 );
 					int j = 0;
 					while( strncmp( &line[j], "\0", 1 ) != 0 )
 					{
 						switch( (int)line[j] )
 						{
 							case 10:
 								fprintf( output, "%c", '\n' );
 								break;	
 							case 32:
 								fprintf( output, "%c", ' ' );
 								break;	
 							case 97:
 								fprintf( output, "%c", 'y' );
 								break;
 							case 98:
 								fprintf( output, "%c", 'h' );
 								break;	
 							case 99:
 								fprintf( output, "%c", 'e' );
 								break;	
 							case 100:
 								fprintf( output, "%c", 's' );
 								break;									
 							case 101:
 								fprintf( output, "%c", 'o' );
 								break;
 							case 102:
 								fprintf( output, "%c", 'c' );
 								break;	
 							case 103:
 								fprintf( output, "%c", 'v' );
 								break;	
 							case 104:
 								fprintf( output, "%c", 'x' );
 								break;
 							case 105:
 								fprintf( output, "%c", 'd' );
 								break;
 							case 106:
 								fprintf( output, "%c", 'u' );
 								break;	
 							case 107:
 								fprintf( output, "%c", 'i' );
 								break;	
 							case 108:
 								fprintf( output, "%c", 'g' );
 								break;	
 							case 109:
 								fprintf( output, "%c", 'l' );
 								break;	
 							case 110:
 								fprintf( output, "%c", 'b' );
 								break;	
 							case 111:
 								fprintf( output, "%c", 'k' );
 								break;
 							case 112:
 								fprintf( output, "%c", 'r' );
 								break;	
 							case 113:
 								fprintf( output, "%c", 'z' );
 								break;	
 							case 114:
 								fprintf( output, "%c", 't' );
 								break;	
 							case 115:
 								fprintf( output, "%c", 'n' );
 								break;
 							case 116:
 								fprintf( output, "%c", 'w' );
 								break;			
 							case 117:
 								fprintf( output, "%c", 'j' );
 								break;
 							case 118:
 								fprintf( output, "%c", 'p' );
 								break;
 							case 119:
 								fprintf( output, "%c", 'f' );
 								break;
 							case 120:
 								fprintf( output, "%c", 'm' );
 								break;
 							case 121:
 								fprintf( output, "%c", 'a' );
 								break;
 							case 122:
 								fprintf( output, "%c", 'q' );
 								break;
 						}
 						j++;
 					}
 				}
 
 				fclose( output );
 			}
 			else
 			{
 				printf( "Could'nt open output for writing EXITING\n" );	
 			}
 	
 			fclose( input );
 		}
 		else
 		{
 			printf( "Could'nt open %s for reading EXITING\n", argv[1] );
 		}
 
 	}
 	else
 	{
 		printf( "Need input filename\n" );
 	}
 
 	return 0;
 }

