#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 FILE* fo;
 char table[26]={'y','h','e','s','o','c','v','x','d','u','i','g','l','b','k','r','z','t','n','w','j','p','f','m','a','q'};
 void process(int no)
 {
     char in[150];
     int len,i;
     gets(in);
     len=strlen(in);
     fprintf(fo,"Case #%d: ",no);
     for(i=0;i<=len-1;i++)
     {
         if(in[i]!=' ')
         {
             fprintf(fo,"%c",table[in[i]-'a']);
         }
         else
         {
             fprintf(fo," ");
         }
     }
     fprintf(fo,"\n");
 }
 int main()
 {
     int ca,i;
     char ar[3];
     fo=fopen("out.txt","w");
     scanf("%d",&ca);
     gets(ar);
     for(i=1;i<=ca;i++)
     {
         process(i);
     }
     return 0;
 }

