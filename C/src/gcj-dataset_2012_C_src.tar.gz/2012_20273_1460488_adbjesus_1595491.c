#include <stdio.h>
 #include <stdlib.h>
 
 int T;
 
 void solve(void);
 
 int main(void){
 	int i;
 
 	scanf("%d",&T);
 
 	for(i=0;i<T;i++){
 		printf("Case #%d: ",i+1);
 		solve();
 	}
 
 	return 0;
 }
 
 void solve(void){
 	int N,S,p;
 	int i;
 	int t[100];
 	int final=0;
 
 	scanf("%d %d %d",&N,&S,&p);
 
 	for(i=0;i<N;i++)
 		scanf("%d",&t[i]);
 
 	p *= 3;
 	for(i=0;i<N;i++){
 		if(t[i]>=p-4){
 			if(t[i]<p-2 && S>0 && p-4>0 && p-3>0){
 				final++;
 				S--;
 			}
 			else if(t[i]>=p-2)
 				final++;
 			else if(p==0)
 				final++;
 		}
 	}
 	printf("%d\n",final);
 	return;
 }

