#include <stdlib.h>
 #include <stdio.h>
 
 main()
 {
 	int N,A,B,t,i,j,l,m,c,r,x,y,z,f;
 	int p[10];
 	
 	scanf("%d", &N);
 	for (t=1; t<=N; t++) {
 		scanf("%d%d", &A, &B);
 		for(l=1,m=1,r=A/10;r>0;l++,m*=10,r/=10);
 		c=0;
 		p[0]=0;
 		for(i=A; i<B; i++) {
 			y=i;
 			z=0;
 			for(j=l-1;j>0;j--){
 				x=y;
 				y=x/10+m*(y%10);
 				if ((i<y) && (y<=B)) {
 					for(f=z; f>0; f--) {
 						if (y==p[f]) {
 							break;
 						}
 					}
 					if (f==0) {
 						c++;
 						p[++z]=y;
 					}
 				}
 			}
 		}
 		printf ("Case #%d: %d\n", t, c);
 	}
 
 }

