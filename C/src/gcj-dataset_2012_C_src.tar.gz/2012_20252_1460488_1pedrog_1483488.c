#include <stdio.h>
 
 int isRecycled(int n, int m){
 	int t, d, c, i, mod;
 	for(d = 0, t = n; t != 0; d++){
 		t /= 10;
 	}
 	for(mod = 1, i = 1; i < d; i++){
 		mod *= 10;
 	}
 	t = n;
 	do{
 		c = (t / mod);
 		t = c + (t * 10);
 		t = t - (c * mod * 10);
 		if(t == m){
 			return 1;
 		}
 	}
 	while(n != t);
 	return 0;
 }
 
 int main(){
 	int i, a, b, c, n, m, t;
 	scanf("%i", &t);
 	for(i = 1; i <= t; i++){
 		scanf("%i %i", &a, &b);
 		c = 0;
 		for(; a < b; a++){
 			n = a;
 			for(m = n + 1; m <= b; m++){
 				if(isRecycled(n, m)){
 					c++;
 				}
 			}
 		}
 		printf("Case #%i: %i\n", i, c);
 	}
 	return 0;
 }

