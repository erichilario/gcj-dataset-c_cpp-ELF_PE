#include <stdio.h>
 #include <stdint.h>
 #include <stdbool.h>
 
 uint64_t ar[500];
 uint64_t set1[500], set2[500];
 int index1, index2;
 
 uint64_t sum1, sum2;
 
 int n;
 
 bool found;
 
 void dfs(int i) {
 	if (found) {
 		return;
 	}
 	if (sum1 > 0 && sum1 == sum2) {
 		int j;
 		for (j = 0; j < index1; ++j) {
 			printf("%Lu ", set1[j]);
 		}
 		putchar('\n');
 		for (j = 0; j < index2; ++j) {
 			printf("%Lu ", set2[j]);
 		}
 		putchar('\n');
 		found = true;
 	} else if (i < n) {
 		// 1
 		sum1 += ar[i];
 		set1[index1++] = ar[i];
 		dfs(i + 1);
 		index1--;
 		sum1 -= ar[i];
 		// 2
 		sum2 += ar[i];
 		set2[index2++] = ar[i];
 		dfs(i + 1);
 		index2--;
 		sum2 -= ar[i];
 		// 3
 		dfs(i + 1);
 	}
 }
 
 int main(int argc, char const *argv[])
 {
 	int t;
 	scanf("%d", &t);
 	int c;
 	for (c = 0; c < t; ++c) {
 		scanf("%d", &n);
 		int i;
 		for (i = 0; i < n; ++i) {
 			scanf("%Lu", ar + i);
 		}
 		printf("Case #%d:\n", c + 1);
 		sum1 = sum2 = 0;
 		index1 = index2 = 0;
 		found = false;
 		dfs(0);
 		if (!found) {
 			puts("impossible");
 		}
 	}
 	return 0;
 }

