#include <stdio.h>
 #include <string.h>
 #include <ctype.h>
 
 int main(){
     char trans[] = {'y','h','e','s','o','c','v','x','d','u','i','g','l','b','k','r','z','t','n','w','j','p','f','m','a','q'};
     char temp;
     int TC,counter;
     counter=1;
     scanf("%d\n",&TC);
     while(TC--){
         printf("Case #%d: ",counter++);
         while((scanf("%c",&temp))!=EOF){
             if(temp=='\n'){
                 putchar('\n');
                 break;
             }
             else if(temp==' ')
                 putchar(' ');
             else
                 printf("%c",trans[temp-97]);
         }
     }
     return 0;
 }

