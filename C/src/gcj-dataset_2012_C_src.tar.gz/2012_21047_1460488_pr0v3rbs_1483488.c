#include <stdio.h>
 #include <string.h>
 
 void ia(int num,char *str){
 	int tem=10000000;
 	int index=0;
 	while(1){
 		if(num/tem!=0)
 			break;
 		tem /= 10;
 	}
 
 	while(tem!=1){
 		str[index++] = num/tem + 48;
 		num %= tem;
 		tem /= 10;
 	}
 	str[index++] = num+48;
 	str[index]='\0';
 }
 
 int check(int num ,int A , int B){
 	int i,j,len,sum=0;
 	char str[8],str2[8];
 	int sav;
 	ia(num,str);
 	len = strlen(str);
 
 	for(i=1;i<len;i++){
 		int index=0,tem;
 		for(j=i;j<len;j++)
 			str2[index++] = str[j];
 		for(j=0;j<i;j++)
 			str2[index++] = str[j];
 		str2[index]='\0';
 		tem = atoi(str2);
 		if(tem>=A && tem<=B && num<tem){
 			if(i>1 && sav==tem)
 				break;
 			sum++;
 			sav=tem;
 		}
 	}
 
 	return sum;
 }
 
 int main(){
 	int testn,test=1;
 	scanf("%d" , &testn);
 
 	while(testn--){
 		int sum=0;
 		int i,A,B;
 		scanf("%d%d" , &A , &B);
 
 		for(i=A;i<=B;i++){
 			//if(check(i,A,B)==0)
 			//	printf("%d\n" , i);
 			sum += check(i,A,B);
 		}
 
 		printf("Case #%d: %d\n" , test++ , sum);
 	}
 }

