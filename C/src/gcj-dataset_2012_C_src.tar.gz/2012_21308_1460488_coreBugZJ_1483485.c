/*
 google code jam
 Qualification Round 2012
 Problem a
 */
 #include <stdio.h>
 
 #define  LM  128
 #define  LS  109
 
 char unmap[ LM ];
 char words[ LS ];
 
 void init() {
         int i;
         char *normal = "our language is impossible to understand there are twenty six factorial possibilities so it is okay if you want to just give up";
         char *google = "ejp mysljylc kd kxveddknmc re jsicpdrysi rbcpc ypc rtcsra dkh wyfrepkym veddknkmkrkcd de kr kd eoya kw aej tysr re ujdr lkgc jv";
         for ( i = 0; i < LM; ++i ) {
                 unmap[ i ] = i;
         }
         unmap[ 'y' ] = 'a';
         unmap[ 'e' ] = 'o';
         unmap[ 'q' ] = 'z';
         while ( (*normal) && (*google) ) {
                 unmap[ *google++ ] = *normal++;
         }
         unmap[ 'z' ] = 'q';
 }
 
 int main() {
         int tc, cc;
         char *p;
 
         init();
 
         scanf("%d", &tc);
         gets(words);
         for ( cc = 1; cc <= tc; ++cc ) {
                 gets(words);
                 for ( p = words; *p; ++p ) {
                         *p = unmap[ *p ];
                 }
                 printf("Case #%d: %s\n", cc, words);
         }
         return 0;
 }

