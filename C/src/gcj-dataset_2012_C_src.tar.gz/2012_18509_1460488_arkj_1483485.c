#include <stdio.h>
 #include <string.h>
 
 char map [] = {'y','h','e','s','o','c','v','x','d','u','i','g','l','b','k','r','z','t','n','w','j','p','f','m','a','q'};
 int main()
 {
     int i,n,ch;
     scanf("%d",&n);
     getchar();
     i=0; 
     printf("Case #%d: ",++i);
     while((ch=getchar()) != EOF)
     {
         if(ch=='\n')
         {
             if (i >= n)
                 printf("%c",'\n');
             else
                printf("\nCase #%d: ",++i);
         }
         else
         {
             if(ch==' ')
             {
                 printf("%c",' ');
             }
             if(ch >='a' && ch <= 'z')
             {
                 printf("%c",map[ch-'a']);
             }
         }
     }
     return 0;
 }
 

