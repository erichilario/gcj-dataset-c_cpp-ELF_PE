#include <stdio.h>
 
 int main(int argc, const char *argv[])
 {
 	const char *googlerese = "abcdefghijklmnopqrstuvwxyz";
 	const char *plaintext =  "yhesocvxduiglbkrztnwjpfmaq";
 	char buffer[128], *p;
 	
 	int casen=0;
 	int cases;
 	scanf("%d\n", &cases);
 	while(casen<cases){
 		fgets(buffer, 128, stdin);
 		p = buffer;
 		while (*p!='\0') {
 			if(*p>='a' && *p<='z')
 				*p = plaintext[*p - 'a'];
 			p++;
 		}
 		printf("Case #%d: %s", ++casen, buffer);
 	}
 	return 0;
 }
 

