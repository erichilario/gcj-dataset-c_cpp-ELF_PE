#include<stdio.h>

int T, A;
int X, Y, Rep;
int RX, RY, Done;

int main(void)
{
        int l0, l1, l2, l3;

        scanf("%d", &T);
        for(l0 = 1; l0 <= T; l0++)
        {
                scanf("%d", &A);
                if(A == 20)
                {
                        X = Y = 2;
                        Rep = 250;
                }
                else if(A == 200)
                {
                        X = 4;
                        Y = 3;
                        Rep = 83;
                }
                Done = 0;
                for(l1 = 1; l1 <= X; l1++)
                {
                        for(l2 = 1; l2 <= Y; l2++)
                        {
                                for(l3 = 1; l3 <= Rep; l3++)
                                {
                                        printf("%d %d\n", (l1 - 1) * 3 + 2, (l2 - 1) * 3 + 2);
                                        fflush(stdout);
                                        scanf("%d %d", &RX, &RY);
                                        if(RX == 0 && RY == 0)
                                        {
                                                Done = 1;
                                                break;
                                        }
                                }
                                if(Done) break;
                        }
                        if(Done) break;
                }
        }
        return 0;
}

