#include <stdio.h>
#define fr(i,x,y) for(int i=x;i<=y;i++)
int A,mx,my;
int v[5][100];
void doit() {
    scanf("%d", &A);
    A = (A - 1) / 3 + 1;
    fr(i,0,2) fr(j,0,A-1) v[i][j]=1;
    printf("%d %d\n", 200, 500);
    fflush(stdout);
    scanf("%d%d", &mx, &my);

    int x, y;

    v[1][1] = 0;
    while (v[0][0] || v[1][0] || v[2][0]) {
        printf("%d %d\n", mx, my);
        fflush(stdout);
        scanf("%d%d", &x, &y);
        if (x == 0 && y == 0) return;
        v[x - mx + 1][y - my + 1] = 0;
    }

    fr(i, 1, A - 3){
        while (v[0][i] || v[1][i] || v[2][i])
        {

            printf("%d %d\n", mx,my+i);
            fflush(stdout);
            scanf("%d%d", &x, &y);
            if (x == 0 && y == 0) return;
            v[x - mx + 1][y - my + 1] = 0;
        }
    }
    int tt=A-2;
    while (v[0][tt] || v[1][tt] || v[2][tt] || v[0][tt+1] || v[1][tt+1] || v[2][tt+1]) {
        printf("%d %d\n", mx,my+tt-1);
        fflush(stdout);
        scanf("%d%d", &x, &y);
        if (x == 0 && y == 0) return;
        v[x - mx + 1][y - my + 1] = 0;
    }



}

int main() {


    int cas,i=0;
    scanf("%d",&cas);
    while (cas--)
    {
        doit();

    }


}


