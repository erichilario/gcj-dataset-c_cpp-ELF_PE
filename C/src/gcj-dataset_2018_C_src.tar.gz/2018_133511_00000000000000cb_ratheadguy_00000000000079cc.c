
#include<bits/stdc++.h>
using namespace std;
int main(int argc, char const *argv[])
{
 int c;
 scanf("%d",&c);
 for(int t=0;t<c;t++)
 {
  long double A;
  scanf("%Lf",&A);
  if(A>=1&&A<=sqrt(2))
  {
   long double cos=(A+sqrt(2-A*A))/2;
   long double sin=(A-sqrt(2-A*A))/2;
   printf("CASE #%d:\n",t+1);
   printf("%.15Lf %.15Lf 0\n",cos/2,sin/2);
   printf("%.15Lf %.15Lf 0\n",-1*sin/2,cos/2);
   printf("0 0 0.5\n");
  }
  else
  {
   long double sin=(A-sqrt(6-2*A*A))/3;
   long double cos=sqrt(1-sin*sin);
   long double k=sqrt(2)/4;
   printf("CASE #%d:\n",t+1);
   printf("%.15Lf %.15Lf %.15Lf\n",k,k*cos,k*sin);
   printf("%.15Lf %.15Lf %.15Lf\n",-1*k,k*cos,k*sin );
   printf("0 %.15Lf %.15Lf\n",-1*sin/2,cos/2 );
  }
 }
 return 0;
}

