#include <iostream>
#include <cmath>
#include <vector>

using namespace std;


int main() {
    size_t T;
    cin >> T;
    for (size_t t = 0; t < T; t++) {
        size_t A;
        cin >> A;
        size_t petit_cote = floor(sqrt(A));
        size_t grand_cote = petit_cote;
        while(petit_cote * grand_cote < A) {
            grand_cote++;
        }
        //On tente entre 1 et A inclus (on indice entre 0 et A-1)

        vector<vector<bool>> done(petit_cote, vector<bool>(grand_cote, false));
        bool end = false;
        for(size_t i = 0; i < petit_cote && !end; i++) {
            for(size_t j = 0; j < grand_cote && !end; j++) {
                while(!done[i][j]) {
                    size_t I = i + 1;
                    size_t J = j + 1;
                    if(I == 1) {
                        I++;
                    } else if(I == petit_cote) {
                        I--;
                    }
                    if(J == 1) {
                        J++;
                    } else if(J == grand_cote) {
                        J--;
                    }
                    cout << I << ' ' << J << endl;

                    size_t I2, J2;
                    cin >> I2 >> J2;
                    if (I2 == -1 && J2 == -1) {
                        return 0;
                    } else if (I2 == 0 && J2 == 0) {
                        end = true;
                        break;
                    } else if(1 <= I2 && I2 <= petit_cote && 1 <= J2 && J2 <= grand_cote) {
                        done[I2-1][J2-1] = true;
                    }
                }
            }
        }
    }
    return 0;
}
