#include <stdio.h>
#include <string.h>

#define N 32

typedef long long ll;

ll get_total_damage(char p[], int n) {
    int i;
    ll beam_strength = 1LL;
    ll total_damage = 0LL;
    
    for (i = 0; i < n; i++)
        if (p[i] == 'C')
            beam_strength *= 2LL;
        else
            total_damage += beam_strength;
    
    return total_damage;
}

int get_last_instruction(char c, char p[], int n) {
    int i;
    
    for (i = n-1; i >= 0; i--)
        if (p[i] == c)
            return i;
    
    return -1;
}

void swap_instruction(char p[], int x, int y) {
    char c = p[x];
    p[x] = p[y];
    p[y] = c;
}

void print_answer(int case_no, int ans) {
    if (ans == -1)
        printf("Case %d: IMPOSSIBLE\n", case_no);
    else
        printf("Case %d: %d\n", case_no, ans);
}

void solve(int case_no) {
    ll d, total_damage;
    int n, ans = -1, step = 0;
    char p[N];
    
    scanf("%lld%s", &d, p);
    n = strlen(p);
    total_damage = get_total_damage(p, n);
    
    while (total_damage > d) {
        int last_shoot = get_last_instruction('S', p, n);
        int last_charge = get_last_instruction('C', p, last_shoot);
        
        if (last_charge == -1)
            break;
        
        step++;
        swap_instruction(p, last_charge, last_charge+1);
        total_damage = get_total_damage(p, n);
    }
    
    if (total_damage <= d)
        ans = step;
    
    print_answer(case_no, ans);
}

int main(int argc, char* argv[]) {
    int i, t;
    
    scanf("%d", &t);
    for (i = 1; i <= t; i++)
        solve(i);
    
    return 0;
}

