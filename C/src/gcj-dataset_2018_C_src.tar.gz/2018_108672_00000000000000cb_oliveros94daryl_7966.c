#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


	FILE * input;
	FILE * output;
	char * line;
	size_t len = 0;
	ssize_t read;

	int row = 0;
	int prow = 0;

int isTidy(int *array1, int length);

int main(){


	int T = 0;
	unsigned long N;
	unsigned long result = 0;
	char steps[31];

	input = fopen("input.txt", "r");
 	output = fopen("output.txt", "w");

	while ((read = getline(&line, &len, input)) != -1) {
		row++;
		//T
		if(row==1){T=atoi(line); continue;};

		result = 0;
		sscanf(line, "%ld %s",&N,steps);

	
		fprintf(output,"Case #%d: ", row-1);
		
				fprintf(output,"%ld",N );
		
		fprintf(output,"\n");

    }


	fclose(input);
	fclose(output);

	return 0;
}







