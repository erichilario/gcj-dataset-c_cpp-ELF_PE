#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define  N 100000

int cmp(const void *a, const void *b)
{
	unsigned long la = *((unsigned long*)a);
	unsigned long lb = *((unsigned long*)b);

	if(la == lb) return 0;

	return 2 * (la > lb) - 1;
}

size_t solve(unsigned long *numbers, size_t count)
{
	unsigned long sorted[N];
	size_t i, j;

	/* Create a copy of the input and sort it */
	memcpy(sorted, numbers, sizeof(sorted));
	qsort(sorted, count, sizeof(*sorted), cmp);

	/* Check each unsorted number */
	for(i = 0; i < count; i++) {
		for(j = i & 1; j < count; j += 2) {
			if(numbers[i] == sorted[j]) {
				sorted[j] = -1;
				break;
			}
		}

		if(j > count)
			return i + 1;
	}

	return 0;
}

int main(int argc, char *argv[])
{
	size_t i, n;
	size_t j, count;

	unsigned long numbers[N];
	size_t   ret;

	scanf("%u", &n);

	for(i = 0; i < n; i++) {
		scanf("%u", &count);

		for(j = 0; j < count; j++)
			scanf("%lu", &numbers[j]);

		printf("Case #%d: ", i + 1);

		ret = solve(numbers, count);

		if(ret == 0)
			puts("Ok");
		else
			printf("%d\n", ret);
	}

	return EXIT_SUCCESS;
}

