#include<math.h>
#include<string.h>.
int main() {
	int t;
	scanf("%d", &t);
	for(int tt=1;tt<=t;tt++) {
		double a;
		scanf("%lf", &a);
		double theta = asin(a/sqrt(2))-M_PI/4;
		//printf("%lf\n", theta);
		printf("Case #%d:\n");
		printf("%.08f %.08f 0\n", cos(theta)/2.0, sin(theta)/2.0);
		printf("%.08f %.08f 0\n", -sin(theta)/2.0, cos(theta)/2.0);
		printf("0 0 0.5\n");
	}
}

