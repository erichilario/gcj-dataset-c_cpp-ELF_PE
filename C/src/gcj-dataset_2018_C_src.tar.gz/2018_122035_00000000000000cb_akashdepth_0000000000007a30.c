#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int A[15][15];

int max(int a,int b){

    if(a>b) return a;
    return b;
}
int main(){

    int t;
    

    scanf("%d",&t);
    while(t--){
        
        int total;
        
        scanf("%d",&total);

        int siz = ceil(sqrtf(total));
        int siz2 = siz;

        int a,b;
        siz2 = max(siz2,3);
        siz = max(siz, 3);

       


        for(int i=0;i<siz;i++)
            for(int j=0;j<siz2;j++){
                A[i][j] = 0;
            }



        for(int i=0;i<1000;i++){


            for(int r=1;r<siz-1;r++)
                for(int c=1;c<siz2-1;c++){
                    if(!(A[r][c] && A[r][c-1] && A[r][c+1] && A[r-1][c] && A[r-1][c-1] && A[r-1][c+1] && A[r+1][c] && A[r+1][c-1] && A[r+1][c+1])){
                        printf("%d %d\n",r+10,c+10);
                        fflush(stdout);
                        break;
                    }
                }

           
            scanf("%d%d",&a,&b);
            

             if(a==0 && b==0){
                break;
            }

            if(a==-1 && b== -1) exit(1);

            A[a-10][b-10] = 1;

           



        }



    }

    return 0;
}

