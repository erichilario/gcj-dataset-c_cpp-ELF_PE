#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    int a[100][10],i,xx=-1,yy=-1,x=2,y=2;
    int t,ar,j;
    cin>>t;
    while(t){
t--;
        cin>>ar;
        x=2;
        y=2;
        xx=-1;
        yy=-1;

        for(i=0;i<80;i++)
            for(j=0;j<5;j++)
        a[i][j]=0;

        while(xx!=0 && yy!=0){
            cout<<x<<" "<<y;
            cin>>xx>>yy;
            a[xx][yy]=1;

          if(a[x][y]==1 &&a[x-1][y-1]==1 && a[x][y-1]==1 && a[x+1][y-1]==1 && a[x-1][y]==1 && a[x+1][y]==1 && a[x-1][y+1]==1 && a[x][y+1]==1 && a[x+1][y+1]==1)
		{x+=3;}





        }
         }




    return 0;
}
