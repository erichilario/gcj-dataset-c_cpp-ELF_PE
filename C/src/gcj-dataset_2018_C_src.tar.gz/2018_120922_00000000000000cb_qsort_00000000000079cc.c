#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct {
	double x;
	double y;
	double z;
} point;

point rotate(point p, double sine, double cosine, int axis) {
	point r;
	switch (axis) {
		case 0:
			r.x = (p.x);
			r.y = (p.y * cosine - p.z * sine);
			r.z = (p.y * sine + p.z * sine);	
			break;
		case 1:
			r.x = (p.x * cosine - p.z * sine);
			r.y = (p.y);
			r.z = (p.x * sine + p.z * cosine);
			break;
		case 2:
			r.x = (p.x * cosine - p.y * sine);
			r.y = (p.x * sine + p.y * cosine);
			r.z = (p.z);
			break;
	}
	return r;
}

/*
double solve_quadratic(double a, double b, double c, double eps)
{
	double delta = (b*b - 4*a*c);
	if (delta < 0) return NAN;
	if (b>0) {
		return (-b - sqrt(delta))/(2*a);
	} else {
		return (-b + sqrt(delta))/(2*a);
	}
}
*/


double quadratic(double a, double b, double c, double x) {
	return a*x*x + b*x + c;
}

double derivative(double a, double b, double c, double x) {
	return 2*x*a + b;
}


double solve_quadratic(double a, double b, double c, double eps) {
	double x = 1;
	double h = quadratic(a, b, c, x) / derivative(a, b, c, x);
	while (fabs(h) > eps) {
		h = quadratic(a, b, c, x)/derivative(a, b, c, x); 
		x = x-h;
	}
	printf("%f\n", fabs(h));
	return x;
}

int main()
{
	int cases, i;
	double area, sine, cosine;
	point p1, p2, p3;
	p1.x = p2.y = p3.z = 0.5;
	p1.y = p1.z = p2.x = p2.z = p3.x = p3.y = 0.0;
	scanf("%d", &cases);
	for (i=1; i<=cases; ++i) {
		scanf("%lf", &area);
		if (area < sqrt(2)) {
			sine = solve_quadratic(2, -2*area, area*area-1, 1e-13);
			cosine = sqrt(1 - sine*sine);
			printf("%.12f, %.12f, %.12f\n", sine, cosine, sine+cosine);
			p1 = rotate(p1, sine, cosine, 2);
			p2 = rotate(p2, sine, cosine, 2);
			p3 = rotate(p3, sine, cosine, 2);	
			printf("Case #%i:\n %.12f %.12f %.12f \n %.12f %.12f %.12f \n %.12f %.12f %.12f \n", 
				i, p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, p3.x, p3.y, p3.z);
		}
	}	
}

