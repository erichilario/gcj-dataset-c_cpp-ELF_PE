/*
 * Google Code Jam Qualification Round 2018 Problem C
 * "Go, Gopher!"
 * Written by James Tai
 */

#if 1

/*
 * Analysis:
 * First, we find the width and height of the rectangle to fill. It should be at least 3 in width and 3 in height,
 * otherwise we risk digging a square outside of the rectangle.
 *
 * Then, we repeatedly look for the best spot at which to deploy the Gopher, with the best spot being the spot that has
 * the most non-dug adjacent cells. This will maximize the probability that the Gopher does something useful (digging a
 * cell rather than being an idiot). Remember that we don't want to risk the Gopher digging a cell outside of our
 * rectangle, so we must choose a tile that is not on the border of the rectangle. If the Gopher ends up being a useless
 * pile of "technology," then we simply deploy at the same position again, since the best spot will still be at the same
 * place. We repeat this until we have finished the rectangle.
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/// Perform a debugging-only operation.
#define debug(x)
/// Same as printf, but only executes if debugging is enabled, and prints to stderr instead of stdout.
#define debug_printf(...) debug(fprintf(stderr, "DEBUG: " __VA_ARGS__))
/// Debug assertion, which is only evaluated if debugging is enabled.
#define debug_assert(cond) debug(if (!(cond)) debug_printf("(!!) ASSERTION FAILED: '%s'\n", #cond))

/// Abstrcated zero-indexed position. Not the same as the one sent to or received from the judge.
struct pos {
    int row, col;
};

int deploy(struct pos *pos) {
    printf("%d %d\n", pos->row + 400, pos->col + 400);
//    debug_printf("(SEND) deploy_at:%d,%d\n", pos->row + 400, pos->col + 400);
    fflush(stdout);
    scanf("%d %d", &pos->row, &pos->col); // NOLINT
//    debug_printf("(RECV) deployed:%d,%d\n", pos->row, pos->col);
    if (pos->row == -1) exit(0);
    if (pos->row == 0) return 1;
    pos->row -= 400;
    pos->col -= 400;
    return 0;
}

struct pos getBounds(int area) {
    struct pos bounds;
    if (area <= 9) {
        bounds.row = 3;
        bounds.col = 3;
        return bounds;
    }
    while (1) {
        for (bounds.row = (int) sqrt(area); bounds.row >= 3; bounds.row--) {
            bounds.col = area / bounds.row;
            if (bounds.col * bounds.row == area) {
                return bounds;
            }
        }
        // No good factors found, increment area and try again
        area++;
    }
}

int main(void) {
    int num_cases, case_num, area, i, bestFree, totalFree, r, c, dr, dc;
    debug(int deployAttempt);
    struct pos dimensions, deploymentDimensions, bestPos, deploymentPos;
    char **grid;
    scanf("%d", &num_cases); // NOLINT
    debug_printf("RECV num_cases:%d\n", num_cases);
    for (case_num = 1; case_num <= num_cases; case_num++) {
        debug_printf("----- CASE #%d -----\n", case_num);
        scanf("%d", &area); // NOLINT
        debug_printf("RECV area:%d\n", area);
        dimensions = getBounds(area);
        debug_printf("dimensions:%d,%d\n", dimensions.row, dimensions.col);
        deploymentDimensions = dimensions;
        deploymentDimensions.col -= 2;
        deploymentDimensions.row -= 2;
        grid = malloc(sizeof(char *) * dimensions.row);
        for (i = 0; i < dimensions.row; i++) {
            grid[i] = malloc(sizeof(char) * dimensions.col);
            // Fill array with zeros
            memset(grid[i], 0, sizeof(char) * dimensions.col);
        }
        while (1) {
            debug(deployAttempt = 1);
            // Find the best position to deploy
            debug_printf("Finding best pos...\n");
            bestFree = 0;
            for (r = 1; r <= deploymentDimensions.row; r++) {
                for (c = 1; c <= deploymentDimensions.col; c++) {
                    totalFree = 9;
                    for (dr = -1; dr <= 1; dr++) {
                        for (dc = -1; dc <= 1; dc++) {
                            char value = grid[r + dr][c + dc];
                            debug_assert(value == 0 || value == 1);
                            totalFree -= value;
                        }
                    }
                    if (totalFree > bestFree) {
                        debug_printf(" -> found new best row: bestPos:%d,%d\n", bestPos.row, bestPos.col);
                        bestPos.row = r;
                        bestPos.col = c;
                        bestFree = totalFree;
                    }
                    if (totalFree == 9) {
                        debug_printf("9 free! Deploying: pos:%d,%d free:%d\n", bestPos.row, bestPos.col, bestFree);
                        goto doDeploy;
                    }
                }
            }
            debug_assert(bestFree != 0);
            debug_printf("Deploying... pos:%d,%d free:%d\n", bestPos.row, bestPos.col, bestFree);
            doDeploy:
            // Deploy it
            deploymentPos = bestPos;
            if (deploy(&deploymentPos)) {
                debug_printf("Test case ended\n");
                goto nextCase;
            }
            // If already dug, re-deploy
            if (grid[deploymentPos.row][deploymentPos.col]) {
                debug(deployAttempt++);
                goto doDeploy;
            }
            debug_printf("Deployment done after attempts:%d\n", deployAttempt);
            // Otherwise dig the cell, then continue the loop to find next cell to deploy to
            grid[deploymentPos.row][deploymentPos.col] = 1;
        }
        nextCase:
        // Deallocate grid
        for (i = 0; i < dimensions.row; i++) {
            free(grid[i]);
        }
        free(grid);
    }
}

#endif

