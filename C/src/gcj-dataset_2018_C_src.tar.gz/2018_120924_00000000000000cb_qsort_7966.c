#include <stdio.h>
#include <stdlib.h>

int main()
{
	int cases, shield, damage, i, j, k, moves, ls;
	char c, *s, *t;
	int p[30];
	scanf("%d", &cases);
	s = (char *) malloc(40 * sizeof(char));

	for (i=0; i<cases; ++i) {
		k = 0;
		for (j=0; j<30; ++j) {
			p[j] = 0;
		}
		damage = moves = ls = 0;
		scanf("%d", &shield);
		scanf("%s", s);
		t = s;
		while (*t) {
			if (*t=='S') {
				p[k]++;
				damage += (1 << k);
				ls = k;
			}
			if (*t=='C') {
				k++;
			}
			t++;
		}
		while ((damage > shield) && ls>0) {
			if (p[ls] > 0) {
				p[ls]--;
				p[ls-1]++;
				damage -= (1 << (ls-1));
				moves++;
			}
			if (p[ls] == 0) {
				ls--;
			}
		}
		if (damage <= shield) {
			printf("Case #%d: %d\n", i+1, moves);
		} else {
			printf("Case #%d: IMPOSSIBLE\n", i+1);
		}
		printf("\n");
	}
}

