#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int damage(char *instr) {
	int i;
	char c;
	int charge = 1, damage = 0;
	for (i = 0; i < strlen(instr); i++) {
		if (instr[i] == 'C') {
			charge *= 2;
		} else {
			damage += charge;
		}
	}
	
	/*
	printf("debug: instr=%s, dmg=%d\n", instr, damage);
	//*/
	
	return damage;
}

void hack(char *instr) {
	int i;
	for (i = strlen(instr) - 1; i > 0; i--) {
		if (instr[i] == 'S' && instr[i - 1] == 'C') {
			instr[i - 1] = 'S';
			instr[i] = 'C';
			return;
		}
	}
}

int minHack(int shield, char *instr) {
	int i, j, k;
	int s = 0; // shoot counter
	
	// check impossible
	for (i = 0; i < strlen(instr); i++) {
		if (instr[i] == 'S') {
			s++;
		}
	}
	if (s > shield) {
		return -1;
	}
	
	int dmg = damage(instr);
	int hackCount = 0;
	while (dmg > shield) {
		hackCount++;
		hack(instr);
		dmg = damage(instr);
	}
	
	return hackCount;
}

int main(void) {
	int t;
	scanf("%d", &t);
	
	int i, d;
	char p[100];
	for (i = 0; i < t; i++) {
		scanf("%d %s", &d, p);
		
		printf("Case #%d: ", i + 1);
		int result = minHack(d, p);
		if (result >= 0) {
			printf("%d\n", result);
		} else {
			printf("IMPOSSIBLE\n");
		}
	}
	
	return 0;
}

