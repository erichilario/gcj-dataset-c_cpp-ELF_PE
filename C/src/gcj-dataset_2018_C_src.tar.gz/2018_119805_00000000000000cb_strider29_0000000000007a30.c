#include <stdio.h>

int firstOver(int arr[100][100], int current) {
	if(arr[5][current-1]==1 && arr[5][current]==1 && arr[5][current+1]==1 
		&& arr[4][current-1]==1 && arr[4][current]==1 && arr[4][current+1]==1 
		&& arr[6][current-1]==1 && arr[6][current]==1 && arr[6][current+1]==1 )
		return 1;
	else 
		return 0;
}

int main() {
	int t;
	scanf("%d",&t);
	while(t--) {
		int a;
		scanf("%d",&a);
		int arr[100][100];
		int i,j;
		for(i=0;i<100;i++)
			for(j=0;j<100;j++)
				arr[i][j]=0;
		int current = 3;
		while(1) {
			if(!firstOver(arr,current)) {
				printf("5 %d\n",current);
			} else {
				current+=3;
				printf("5 %d\n", current);
			}
			fflush(stdout);
			int x,y;
			scanf("%d%d",&x,&y);
			if(x==0 && y==0) {
				break;
			} else {
				arr[x][y]=1;
			}
		}
	}
}
