#include <stdio.h>
#include <inttypes.h>

uint32_t calc_damage(const char* prg) {
	uint32_t damage = 0;
	uint32_t charge = 1;
	int i;
	for (i = 0; prg[i] != '\0'; i++) {
		if (prg[i] == 'C') {
			if (charge <= UINT32_MAX / 2) charge *= 2; else charge = UINT32_MAX;
		} else if (prg[i] == 'S') {
			if (damage <= UINT32_MAX - charge) damage += charge; else damage = UINT32_MAX;
		}
	}
	return damage;
}

int main(void) {
	int T, case_count;
	if (scanf("%d", &T) != 1) return 1;
	for (case_count = 1; case_count <= T; case_count++) {
		uint32_t D;
		char P[32];
		int count = 0;
		int len;
		if (scanf("%"SCNu32"%31s", &D, P) != 2) return 1;
		for (len = 0; P[len] != '\0'; len++);
		while (calc_damage(P) > D) {
			int i;
			for (i = len - 1; i > 0; i--) {
				if (P[i - 1] == 'C' && P[i] == 'S') {
					P[i - 1] = 'S';
					P[i] = 'C';
					count++;
					break;
				}
			}
			if (i <= 0) {
				count = -1;
				break;
			}
		}
		printf("Case #%d: ", case_count);
		if (count < 0) puts("IMPOSSIBLE"); else printf("%d\n", count);
	}
	return 0;
}

