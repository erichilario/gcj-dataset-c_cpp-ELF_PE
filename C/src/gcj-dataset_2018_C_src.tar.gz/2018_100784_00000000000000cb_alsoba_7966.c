#include <stdio.h>
#include <stdlib.h>
#include <string.h>
long D;
char P[31];
long N, C, S, sol;

void shift(){
	long i;
	for(i = N-1; i>0; i--){
		if(P[i]=='S' && P[i-1]=='C'){
			P[i]='C';
			P[i-1]='S';
			return;
		}
	}
}

long damage(){
	long d = 0, i, p = 1;
	for(i = 0; i<N; i++){
		if(P[i]=='C'){
			p *= 2;
		}else{
			d += p;
		}
	}
	return d;
}

void solve(){
	long i;
	scanf("%ld", &D);
	scanf("%s", P);
	N = strlen(P);
	C = 0;
	S = 0;
	sol = 0;
	for (i = 0; i<N; i++)
		if(P[i]=='S') S++;
		else C++;
	
	if(S>D){
		printf("IMPOSSIBLE\n");
		return;
	}

	while(damage()>D){
		shift();
		sol++;
	}
	printf("%ld\n", sol);
}

int main(int argc, char *argv[]){
	char kk;
	int total, i;

	scanf("%d", &total);
	scanf("%c", &kk);
	for (i = 0; i<total; i++)
	{
		printf("Case #%d: ", i+1);
		solve();
	}
	return 0;
}
