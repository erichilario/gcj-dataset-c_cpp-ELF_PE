#include <stdio.h>
#include <stdlib.h>

#define MAXLEN 35
#define S (1)
#define C (-1)
#define IMPOSSIBLE (-1)


int hack(int A[], int n, int d);
int total_dmg(int A[], int n);

int main(int argc, char *argv[]) {
	int ntests;
	scanf("%d", &ntests);
	
	int i;
	int d;
	int A[MAXLEN];
	int n;
	int c;
	int result;
	for (i=1; i<=ntests; i++) {
		scanf("%d", &d);
		n=0;
		c = getchar();
		while (1) {
			c = getchar();
			if (c == 'S') {
				A[n] = S;
				n++;
			}
			else if (c=='C') {
				A[n]=C;
				n++;
			}
			else {
				break;
			}
		}
		
		result = hack(A, n, d);
		printf("Case #%d: ", i);
		if (result == IMPOSSIBLE) {
			printf("IMPOSSIBLE\n");
		}
		else {
			printf("%d\n", result);
		}
	}
	return 0;
}


int hack(int A[], int n, int d) {
	int i;
	int no_s=0;
	for (i=0; i<n; i++) {
		no_s += (A[i]==S);
	}
	if (no_s > d) {
		return IMPOSSIBLE;
	}
	
	int hacks = 0;
	while (total_dmg(A, n) > d) {
		i=n-1;
		while (A[i] != S || A[i-1] != C) {
			i--;
		}
		A[i] = C;
		A[i-1] = S;
		hacks++;
	}
	return hacks;
}

int total_dmg(int A[], int n) {
	int dmg = 0;
	int charge = 1;
	int i;
	for (i=0; i<n; i++) {
		if (A[i] == S) {
			dmg += charge;
		}
		else {
			charge*=2;
		}
	}
	return dmg;
}
