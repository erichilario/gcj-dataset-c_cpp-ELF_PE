#include <stdio.h>
#include <stdlib.h>
typedef long long ll;
ll n;
char s[40];
void f() {
    scanf("%lld %s", &n, s);
    int i, j;
    ll sw = 0, c, sum;
    while(1) {
        c = 1, sum = 0;
        for(j=0;s[j];j++) {
            if(s[j] == 'C') c <<= 1;
            else sum += c;
        }
        if(sum <= n) break;
        for(j=strlen(s)-2;j>=0;j--) {
            if(s[j] == 'C' && s[j + 1] == 'S') {
                s[j] = 'S';
                s[j+1] = 'C';
                sw++;
                break;
            }
        }
        if(j < 0) {
            printf("IMPOSSIBLE\n");
            return;
        }
    }
    printf("%lld\n", sw);
}

int main() {
    int i;
    int T;
    scanf("%d", &T);
    for(i=0;i<T;i++) {
        printf("Case #%d: ", i + 1);
        f();
    }
    return 0;
}
