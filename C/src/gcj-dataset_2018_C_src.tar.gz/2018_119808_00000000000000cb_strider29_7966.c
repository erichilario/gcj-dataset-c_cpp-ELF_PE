#include <stdio.h>
#include <string.h>

int main() {
	int t;
	scanf("%d",&t);
	int t1 = t;
	while(t--) {
		long long int d;
		scanf("%lld",&d);
		char seq[31];
		scanf("%s",seq);
		int len = strlen(seq);
		int arr[len];
		int i;
		int cntC=0;
		int curStr=1;
		int total=0;
		for (i=0; i<len; i++) {
			if(seq[i]=='S') {
				arr[i]=curStr;
				total+=arr[i];
			} else {
				arr[i]=0;
				cntC++;
				curStr*=2;
			}
		}
		printf("Case #%d: ",t1-t);
		if (total <= d) {
			printf("0\n");
			continue;
		} 
		int moves = 0;
		for(i=len-1;i>=0;i--) {
			if (arr[i]==0) {
				int j;
				for (j=i;j<len-1;j++) {

					if (arr[j+1] == 0) {
						break;
					}		

					arr[j] = arr[j+1]/2;
					arr[j+1] = 0;
					total = total - arr[j];
					moves++;
					if (total <= d) {
						break;
					}
				}
				if (total <= d) {
					break;
				}
			}
		}
		if(i>=0) {
			printf("%d\n", moves);
		} else {
			printf("IMPOSSIBLE\n");
		}
	}
}
