#include<stdio.h>

char A[33];
int D, N, T, Ret, Curr, P;

int main(void)
{
        int l0, l1;

        scanf("%d", &T);
        for(l0 = 1; l0 <= T; l0++)
        {
                scanf("%d %s", &D, A);
                for(N = 0; A[N]; N++);

                Ret = 0;
                while(1)
                {
                        P = 1;
                        Curr = 0;
                        for(l1 = 0; l1 < N; l1++)
                        {
                                if(A[l1] == 'C') P <<= 1;
                                else Curr += P;
                        }
                        if(Curr <= D) break;
                        Ret++;
                        for(l1 = N-1; l1 >= 0; l1--)
                        {
                                if(A[l1] == 'C' && A[l1+1] == 'S')
                                {
                                        A[l1] = 'S';
                                        A[l1+1] = 'C';
                                        break;
                                }
                        }
                        if(l1 < 0)
                        {
                                Ret = -1;
                                break;
                        }
                }


                if(Ret == -1)
                {
                        printf("Case #%d: IMPOSSIBLE\n", l0);
                }
                else
                {
                        printf("Case #%d: %d\n", l0, Ret);
                }
        }

        return 0;
}

