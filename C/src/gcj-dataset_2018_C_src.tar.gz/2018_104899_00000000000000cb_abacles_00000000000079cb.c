#include <stdio.h>
#include <stdlib.h>

int compar(const void *a, const void *b)
{
  return *(int*)a - *(int*)b;
}

int check(int *l, int *r, int ll, int rl)
{
  int i;
  for(i=0;i<rl;i++)
    {
      if(l[i] > r[i])
	return i * 2;
      else if(i + 1 < ll && r[i] > l[i+1])
	return i * 2 + 1;
    }
  return -1;
}

int main()
{
  int ncases, len, left[50000], right[50000], c, llen, rlen, i;
  scanf("%d", &ncases);
  for(c=0;c<ncases;c++)
    {
      scanf("%d", &len);
      for(llen=rlen=0;llen+rlen<len;)
	{
	  scanf("%d", &left[llen++]);
	  if(llen + rlen < len)
	    scanf("%d", &right[rlen++]);
	}
      qsort(left, llen, sizeof(int), compar);
      qsort(right, rlen, sizeof(int), compar);
      i = check(left, right, llen, rlen);
      printf("Case #%d: ", c + 1);
      if(i == -1)
	printf("OK\n");
      else
	printf("%d\n", i);
    }
}

