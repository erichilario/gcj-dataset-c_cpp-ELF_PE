#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#define ERR(fmt, ...) error(__FILE__, __LINE__, fmt, ##__VA_ARGS__)
#define N (123456)
static long a[N], fst[N], scn[N];

static void error(const char *file, int line, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    fprintf(stderr, "%s:%d: ", file, line);
    vfprintf(stderr, fmt, args);
    fprintf(stderr, "\n");
    va_end(args);
    exit(2);
}

static int more(const void *pa, const void *pb) {
    const long *a, *b;
    a = (const long*)pa;
    b = (const long*)pb;
    return *a > *b;
}
static void sort(long n, long *a) {
    qsort(a, n, sizeof(a[0]), more);
}

static void dump(long n, long *a) {
    int i;
    for (i = 0; i < n; i++)
        printf("%ld ", a[i]);
    puts("");
}

static long main0() {
    long n, f, s, i;
    if (scanf("%ld", &n) != 1) ERR("scanf failed");
    for (i = 0; i < n; i++)
        if (scanf("%ld", &a[i]) != 1) ERR("scanf faild");

    i = f = s = 0;
    for (;;) {
        fst[f++] = a[i++]; if (i == n) break;
        scn[s++] = a[i++]; if (i == n) break;
    }
    if (f + s != n) ERR("f=%ld + s=%ld   !=   n=%ld", f, s, n);

    sort(f, fst);
    sort(s, scn);

    i = f = s = 0;
    for (;;) {
        a[i++] = fst[f++]; if (i == n) break;
        a[i++] = scn[s++]; if (i == n) break;
    }
    for (i = 0; i < n - 1; i++)
        if (a[i] > a[i + 1]) return i;
    return -1;
}

int main() {
    long T, index, i;
    if (scanf("%ld", &T) != 1) ERR("scanf faild");
    for (i = 0; i < T; i++) {
        index = main0();
        printf("Case #%ld: ", i + 1);
        if (index == -1) puts("OK"); else printf("%ld\n", index);
    }
}

