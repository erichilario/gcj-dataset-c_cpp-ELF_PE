#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.14159265359
double A, a;

void solve(){
	double low = -PI/4.0;
	double high = 0.0;
	double mid;
	scanf("%lf", &A);
	while(high-low > 0.00000001)
    {
        mid = (low + high)/2;
    	//printf("%lf\n", mid);
        a = cos(mid)-sin(mid);
        if(a < A){
            high = mid;
        }else {
        	low = mid;
        }
    }
    printf("%lf %lf %lf\n", 0.5*cos(mid), 0.5*sin(mid), 0.0);
    printf("%lf %lf %lf\n", -0.5*sin(mid), 0.5*cos(mid), 0.0);
    printf("%lf %lf %lf\n", 0.0,0.0,0.5);
}

int main(int argc, char *argv[]){
	char kk;
	int total, i;

	scanf("%d", &total);
	scanf("%c", &kk);
	for (i = 0; i<total; i++)
	{
		printf("Case #%d:\n", i+1);
		solve();
	}
	return 0;
}
