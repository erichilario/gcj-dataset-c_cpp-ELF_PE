#include <stdio.h>
#include <stdlib.h>
#include <assert.h>


#define TRUE 1
#define FALSE 0
#define MAX 100001
#define OK (-1)


int int_cmp(const void *a, const void *b);
int check(long int A[], int n);


int main(int argc, char *argv[]) {
	int ntests;
	assert(scanf("%d", &ntests)==1);
	
	int i, j;
	int n;
	long int A[MAX];
	long int B[MAX];
	long int C[MAX];
	int result;
	for (i=1; i<=ntests; i++) {
		scanf("%d", &n);
		for (j=0; j<n; j++) {
			if (!(j%2)) {
				scanf("%ld", A+j/2);
			}
			else {
				scanf("%ld", B+j/2);
			}
		}
		qsort(A, (n+1)/2, sizeof(long int), int_cmp);
		qsort(B, (n)/2, sizeof(long int), int_cmp);
		
		for (j=0; j<(n+1)/2; j++) {
			C[2*j] = A[j];
		}
		for (j=0; j<(n/2); j++) {
			C[2*j+1] = B[j];
		}
		result = check(C, n);
		printf("Case #%d: ", i);
		if (result == OK) {
			printf("OK\n");
		}
		else {
			printf("%d\n", result);
		}
	}
	return 0;
}



int check(long int A[], int n) {
	int i;
	for (i=0; i<n-1; i++) {
		if (A[i]>A[i+1]) {
			return i;
		}
	}
	return OK;
}


int int_cmp(const void *a, const void *b) {
	return *(int *)a - *(int *)b;
}
