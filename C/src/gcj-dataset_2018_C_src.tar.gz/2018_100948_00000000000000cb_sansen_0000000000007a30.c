#include<stdio.h>
#include<stdlib.h>
#include<math.h>

typedef long long int int64;

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define ABS(a,b) ((a)>(0)?(a):-(a))

#define POS(i,j) (((i)-1)*w+(j)-1)

void calc(int *board,int w,int h,int *x,int *y){
  int max=0;
  int i,j;
  for(i=2;i<=w-1;i++){
    for(j=2;j<=h-1;j++){
      int cnt=0;
      int a,b;
      for(a=-1;a<=1;a++){
	for(b=-1;b<=1;b++){
	  if(board[POS(i+a,j+b)]==0) cnt++;
	}
      }
      if(max<cnt){
	max=cnt;
	*x=i;
	*y=j;
      }
    }
  }
}

void func(int w,int h){
  int *board=(int *)calloc(w*h,sizeof(int));
  int x,y;
  while(1){
    calc(board,w,h,&x,&y);
    printf("%d %d\n",x,y);
    fflush(stdout);
    scanf("%d%d",&x,&y);
    if(x==0 && y==0) break;
    board[POS(x,y)]=1;
  }
  free(board);
  return;
}

void run(void){
  int t;
  scanf("%d",&t);
  int iter;
  for(iter=1;iter<=t;iter++){
    int a;
    scanf("%d",&a);
    if(a==20) func(4,5);
    else func(10,20);
  }
}

int main(void){
  run();
  return 0;
}
