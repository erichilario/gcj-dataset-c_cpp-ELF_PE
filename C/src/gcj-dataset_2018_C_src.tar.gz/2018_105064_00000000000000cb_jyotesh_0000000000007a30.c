/*Go, Gopher!*/

#include<stdio.h>
#include<string.h>

int main()
{
	char field[1000][3];
	int dr[] = { -1, -1, -1, 0, 0, 0, 1, 1, 1 };
	int dc[] = { -1, 0, 1, -1, 0, 1, -1, 0, 1 };
	int A, i, row, prepared_col, prepared_row, T;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d", &A);
		memset(field, 0, sizeof(field));
		row = 1;
		while (1)
		{
			printf("%d 2\n", row + 1);
			fflush(stdout);
			scanf("%d %d", &prepared_row, &prepared_col);
			if ((prepared_row == 0) && (prepared_col == 0))
				break;
			if ((prepared_row == -1) && (prepared_col == -1))
				return 0;
			field[prepared_row - 1][prepared_col - 1] = 1;
			for (i = 0; i < 9; i++)
				if (field[row + dr[i]][dc[i] + 1] == 0)
					break;
			if (i == 9)
				row += 3;
		}
	}
	return 0;
}
