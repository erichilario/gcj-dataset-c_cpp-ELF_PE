#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NMAX 31

int solve(int d, char p[]) {
  int len = strlen(p);
  int ct[NMAX] = {0};
  int strength[NMAX];

  strength[0] = 1;
  for (int i=1; i<NMAX; i++) {
    strength[i] = strength[i-1] * 2;
  }

  int damage=0, sindex=0;
  for (int i=0; i<len; i++) {
    if (p[i] == 'S') {
      damage += strength[sindex];
      ct[sindex]++;
    } else {
      sindex++;
    }
  }

  int rv = 0;
  for (int i=NMAX-1; i>0; i--) {
    if (damage <= d) {
      return rv;
    } else if (ct[i] > 0) {
      ct[i]--;
      ct[i-1]++;
      damage -= strength[i]/2;
      i++;
      rv++;
    }
  }

  return -1;
}

int main() {
  int n;
  scanf("%d", &n);

  int d;
  char p[NMAX];

  for (int i=0; i<n; i++) {
    scanf("%d %s", &d, p);
    printf("Case #%d: ", i+1);
    int ans = solve(d, p);
    if (ans == -1) {
      printf("IMPOSSIBLE\n");
    } else {
      printf("%d\n", ans);
    }
  }
}

