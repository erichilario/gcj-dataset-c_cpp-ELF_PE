#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
void goo(int bx,int by){
    int tag[3][3];
    memset(tag,0,sizeof(tag));
    int cnt = 9;
    while(cnt>0){
        printf("%d %d\n",bx+1,by+1);
        fflush(stdout);
        int x,y;
        scanf("%d%d",&x,&y);
        
        if(x==0&&y==0) return;
        
        if(tag[x-bx][y-by]==0){
            tag[x-bx][y-by]=1;
            --cnt;
        }
    }
    return ;
}
int main(int argc, const char * argv[]) {
    int T;
    scanf("%d",&T);
    for(int kase = 1;kase <= T; kase ++){
        int A;
        scanf("%d",&A);
        if(A==20){
            goo(10,10);
            goo(10,13);
            goo(13,10);
            goo(13,13);
        }
        else if(A==200){
            for(int i=0;i<5;i++)
                for(int j=0;j<5;j++)
                    goo(10+3*i,10+3*j);
        }
    }
    return 0;
}

