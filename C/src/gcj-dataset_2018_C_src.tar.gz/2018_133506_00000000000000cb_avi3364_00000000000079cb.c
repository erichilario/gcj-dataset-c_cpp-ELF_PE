#include<stdio.h>
void read_into_array(int arr[],int n)
{
    for(int i=0;i<n;++i)
    scanf("%d",&arr[i]);
    return;
}
void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
}
int partition (int arr[], int low, int high)
{
    int pivot = arr[high];    
    int i = (low - 1); 

    for (int j = low; j <= high- 1; j++)
    {
        if (arr[j] <= pivot)
        {
            i++;    
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}


void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}
int * tr_sort(int arr[],int n)
{
    int i=0,j=0;
    for(int j=0;j<n;++j)
    {
        for(int i=0;i<n-2;++i)
        {
        if(arr[i]>arr[i+2])
        swap(&arr[i],&arr[i+2]);
        }
    }
    return arr;

}
int compare_diff(int arr1[],int arr2[],int n)
{
    int r=-1;
    for(int i=0;i<n;++i)
    {
        if(arr1[i]==arr2[i])
        continue;
        else
       {
           r=i;
           break;
       }
    }
    return r;
}
int main()
{
    int t;
    scanf("%d",&t);
    for(int i=0;i<t;++i)
    {
        int n;
        scanf("%d",&n);
        int arr[n];
        int * s_arr;
        read_into_array(arr,n);
        int b[n];
        for(int i=0;i<n;++i)
        {
            b[i]=arr[i];
        }
        s_arr=tr_sort(arr,n);

        quickSort(b,0,n-1);
        int ans=compare_diff(b,s_arr,n);
         if(ans==-1)
         printf("Case #%d:  OK\n",i+1);
         else
         printf("Case #%d:  %d\n",i+1,ans);

    }
    return 0;
}
