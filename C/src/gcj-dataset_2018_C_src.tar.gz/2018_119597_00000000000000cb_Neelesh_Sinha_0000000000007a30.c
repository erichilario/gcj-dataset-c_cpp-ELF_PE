#include <stdio.h>

int b[1000][1000];

int main(void) {
	int t,a,x,y,cnt,maxcnt,flag,flag1,i,j,k;
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
	    scanf("%d",&a);
	    if(a==20)
	    {
	        for(j=0;j<1000;j++)
    	    {
    	        for(k=0;k<1000;k++)
    	        b[j][k]=0;
    	    }
    	    printf("500 500\n");
    	    fflush(stdout);
    	    while(1)
    	    {
    	        scanf("%d %d",&x,&y);
    	        if(x==0 && y==0)
    	        break;
    	        if(x==-1 && y==-1)
    	        {
    	            printf("500 500\n");
    	            fflush(stdout);
    	            break;
    	        }
    	        b[x][y]=1;
    	        flag=0;
    	        /*for(j=499;j<=502;j++)
    	        {
    	            for(k=499;k<=503;k++)
    	            printf("%d ",b[j][k]);
    	            printf("\n");
    	        }*/
    	        maxcnt=0;
                for(j=500;j<=501;j++)
    	        {
    	            for(k=500;k<=502;k++)
    	            {
    	                cnt=0;
    	                if(b[j-1][k-1]==0)
    	                cnt++;
    	                if(b[j-1][k]==0)
    	                cnt++;
    	                if(b[j-1][k+1]==0)
    	                cnt++;
    	                if(b[j][k-1]==0)
    	                cnt++;
    	                if(b[j][k]==0)
    	                cnt++;
    	                if(b[j][k+1]==0)
    	                cnt++;
    	                if(b[j+1][k-1]==0)
    	                cnt++;
    	                if(b[j+1][k]==0)
    	                cnt++;
    	                if(b[j+1][k+1]==0)
    	                cnt++;
    	                if(cnt>maxcnt)
    	                {
    	                    x=j;
    	                    y=k;
    	                    maxcnt=cnt;
    	                    flag=1;
    	                }
    	                //printf("%d ",cnt);
    	            }
    	        }
    	        if(flag==1)
    	        {
    	             printf("%d %d\n",x,y);
    	             fflush(stdout);
    	        }
    	        else
    	        {
    	            printf("500 500\n");
    	            fflush(stdout);
    	        }
    	    }
	    }
	    else
	    {
	        for(j=0;j<1000;j++)
    	    {
    	        for(k=0;k<1000;k++)
    	        b[j][k]=0;
    	    }
    	    printf("500 500\n");
    	    fflush(stdout);
    	    while(1)
    	    {
    	        scanf("%d %d",&x,&y);
    	        if(x==0 && y==0)
    	        break;
    	        if(x==-1 && y==-1)
    	        {
    	            printf("500 500\n");
    	            fflush(stdout);
    	            break;
    	        }
    	        b[x][y]=1;
    	        flag=0;
    	        /*for(j=499;j<=502;j++)
    	        {
    	            for(k=499;k<=503;k++)
    	            printf("%d ",b[j][k]);
    	            printf("\n");
    	        }*/
    	        maxcnt=0;
                for(j=494;j<=505;j++)
    	        {
    	            for(k=494;k<=506;k++)
    	            {
    	                cnt=0;
    	                if(b[j-1][k-1]==0)
    	                cnt++;
    	                if(b[j-1][k]==0)
    	                cnt++;
    	                if(b[j-1][k+1]==0)
    	                cnt++;
    	                if(b[j][k-1]==0)
    	                cnt++;
    	                if(b[j][k]==0)
    	                cnt++;
    	                if(b[j][k+1]==0)
    	                cnt++;
    	                if(b[j+1][k-1]==0)
    	                cnt++;
    	                if(b[j+1][k]==0)
    	                cnt++;
    	                if(b[j+1][k+1]==0)
    	                cnt++;
    	                if(cnt>maxcnt)
    	                {
    	                    x=j;
    	                    y=k;
    	                    maxcnt=cnt;
    	                    flag=1;
    	                }
    	                //printf("%d ",cnt);
    	            }
    	        }
    	        if(flag==1)
    	        {
    	             printf("%d %d\n",x,y);
    	             fflush(stdout);
    	        }
    	        else
    	        {
    	            printf("500 500\n");
    	            fflush(stdout);
    	        }
    	    }
	    }
	}
	return 0;
}

