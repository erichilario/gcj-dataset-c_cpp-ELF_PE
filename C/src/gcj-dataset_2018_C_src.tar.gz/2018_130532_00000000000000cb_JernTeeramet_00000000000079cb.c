#include<stdio.h>
#include<stdlib.h>
void merge(int arr[], int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;
    int L[n1], R[n2];
    
    for(i = 0 ; i < n1 ; i++)
        L[i] = arr[l + i];
        
    for(i = 0 ; i < n2 ; i++)
        R[i] = arr[m + i + 1];
    i = 0;
    j = 0;
    k = l;
    
    while(i < n1 && j < n2)
    {
        if(L[i] < R[j])
        {
            arr[k] = L[i];
            i++;
            k++;
        }
        else
        {
            arr[k] = R[j];
            j++;
            k++;
        }
    }
    
    while(i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }
    
    while(j < n2)
    {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void mergeSort(int arr[], int l, int r)
{
    if(l < r)
    {
        int m = (l + r)/2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}

void quickTroubleSort(int arr[], int size)
{
    int s2 = size/2;
    int s1 = size - s2;
    int arr1[s1], arr2[s2];
    
    for(int i = 0 ; i < s1 ; i++)
        arr1[i] = arr[2 * i];
        
    for(int j = 0 ; j < s2 ; j++)
        arr2[j] = arr[2 * j + 1];
        
    mergeSort(arr1, 0, s1 - 1);
    mergeSort(arr2, 0, s2 - 1);
    
    for(int i = 0 ; i < s1 ; i++)
        arr[2 * i] = arr1[i];
        
    for(int j = 0 ; j < s2 ; j++)
        arr[2 * j + 1] = arr2[j];
}

int main()
{
    int t;
    scanf("%d", &t);
    for(int i = 1 ; i <= t ; i++)
    {
        int n;
        scanf("%d", &n);
        int input[n];
        
        for(int j = 0 ; j < n ; j++)
            scanf("%d", &input[j]);
        
        quickTroubleSort(input, n);
        int is_ok = 1;
        printf("Case #%d: ", i);
        
        for(int j = 0 ; j < n - 1 ; j++)
            if(input[j] > input[j+1])
            {
                printf("%d\n", j);
                is_ok = 0;
                break;
            }
        
        if(is_ok)
            printf("OK\n");
    }
    return 0;
}
