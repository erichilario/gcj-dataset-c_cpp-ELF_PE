#include <stdio.h>
#include <string.h>

int a[30][30];
int n, t, x, y, s;

int main()
{
	scanf("%d", &t);
	for (int r = 0; r < t; r++) {
		scanf("%d", &n);
		memset(a, 0, sizeof(a));
		for (x = 3; x * x < n; x++);
		y = (n + x - 1) / x;
		s = 0;
		while (true) {
			int nx, ny, m = 10;
			for (int i = 2; i < x; i++)
				for (int j = 2; j < y; j++) {
					int cs =
						a[i - 1][j - 1] + a[i - 1][j] + a[i - 1][j + 1] +
						a[i][j - 1] + a[i][j] + a[i][j + 1] +
						a[i + 1][j - 1] + a[i + 1][j] + a[i + 1][j + 1] ;
					if (cs < m) {
						m = cs; nx = i; ny = j;
					}
				}
			printf("%d %d\n", nx, ny);
			//fprintf(stderr, "send = %d %d, ", nx, ny);
			fflush(stdout);
			scanf("%d%d", &nx, &ny);
			//fprintf(stderr, "recv = %d %d\n", nx, ny);
			if (nx == 0 && ny == 0) {
				break;
			} else if (nx == -1 && ny == -1) {
				fprintf(stderr, "fuck!\n");
				return 1;
			}
			if (a[nx][ny] == 0) {
				a[nx][ny] = 1;
			}
			s++;
		}
		//fprintf(stderr, "Total %d steps\n", s);
	}
}
