#include <stdlib.h>
#include <stdio.h>

int c (const void *p, const void *q) {
	return (*(const int *)p - *(const int *)q);
}

int main ()
{
	int cases, len, last, i, j;
	int *evens, *odds;

	scanf("%d", &cases);
	for (i=0; i<cases; ++i) {
		scanf("%d", &len);
		evens = (int *) malloc(sizeof(int)*(len/2 + len%2));
		odds = (int *) malloc(sizeof(int)*(len/2));
		for (j=0; j<len/2; ++j) {
			scanf("%d", evens+j);
			scanf("%d", odds+j);
		}
		if (len%2) scanf("%d", evens+j);
		qsort(evens, len/2+len%2, sizeof(int), &c);
		qsort(odds, len/2, sizeof(int), &c);
		last = -1;
		for (j=0; j<len-1; ++j) {
			if (j%2) {
				if (evens[j/2+1] < odds[j/2]) break;
			} else {
				if (odds[j/2] < evens[j/2]) break;
			}
		}
		if (j==len-1) printf("Case #%i: OK\n", i+1);
		else printf("Case #%i: %d\n", i+1, j);
	}
	return 0;	
}

