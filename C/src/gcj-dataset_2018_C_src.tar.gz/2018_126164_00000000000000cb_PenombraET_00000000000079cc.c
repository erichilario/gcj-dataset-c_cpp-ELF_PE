#include <stdio.h>
#include <math.h>

const double SQRT_2_LIM = 1.414213;
const double SQRT_2 = 1.4142135624;

int main(int argc, char** argv)
{
	int T;
	scanf("%d", &T);
	
	for (int i = 0; i < T; ++i)
	{
		double A;
		scanf("%lf", &A);
		
		printf("Case #%d:\n", i + 1);

		double S = sqrt(2 - A*A);
		double T = (A - S) / 4;
		double W = (A + S) / 4;

		if (A <= SQRT_2_LIM) {
			printf("0.5 0 0\n");
			
			printf("0 %.10lf %.10lf\n", T,  W);
			printf("0 %.10lf %.10lf\n", W, -T);
		}
		else {
			S = sqrt(2 - SQRT_2_LIM * SQRT_2_LIM);
			T = (SQRT_2_LIM - S) / 4;
			W = (SQRT_2_LIM + S) / 4;
			
			double P = SQRT_2 * A + sqrt(3 - A * A);
			double Q = A + SQRT_2 * sqrt(3 - A * A);
			
			printf("%.10lf %.10lf %.10lf\n",  P / 6,          0.0,  Q / 6);
			printf("%.10lf %.10lf %.10lf\n", -Q * SQRT_2 / 12, SQRT_2 / 4,    P * SQRT_2 / 12);
			printf("%.10lf %.10lf %.10lf\n",  Q * SQRT_2 / 12, SQRT_2 / 4,   -P * SQRT_2 / 12);
		}
	}
	
	return 0;
}

