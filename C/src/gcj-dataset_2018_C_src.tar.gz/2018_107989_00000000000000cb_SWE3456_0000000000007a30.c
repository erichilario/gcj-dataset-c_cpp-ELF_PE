#include <stdio.h>
 
int main(void) {
	int test_cases=0,case_index=0,cases[201][201],start=2,end=2,flag=0;
	scanf("%d",&test_cases);
	for(;case_index<test_cases;case_index++)
	{
		scanf("%d",&cases[case_index][0]);
		scanf("%d",&cases[case_index][1]);
		start=cases[case_index][0];
		end = cases[case_index][1];
		while(start <= end)
		{
			flag = 0;
			for(int i=2;i<start;i++)
			{
				if((start%i) == 0)
				{	
					flag =1;
					break;
				}
			}
			if(flag == 0 && start>2)
			{	printf("%d\n",start);}
			start++;
		}
		printf("\n");
	}
	return 0;
}
