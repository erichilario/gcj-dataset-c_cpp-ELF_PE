/*Saving The Universe Again*/

#include<stdio.h>
#include<string.h>

int main()
{
	char P[32];
	int s[32];
	int count, D, damage, i, j, length, strength, t, T;
	scanf("%d", &T);
	for (t = 1; t <= T; t++)
	{
		scanf("%d %s", &D, P);
		length = strlen(P);
		damage = 0;
		strength = 1;
		for (i = 0; i < length; i++)
		{
			if (P[i] == 'S')
				damage += strength;
			else if (P[i] == 'C')
			{
				strength <<= 1;
				s[i] = strength;
			}
		}
		count = 0;
		for (i = length - 2; (damage > D) && (i >= 0); i--)
		{
			if (P[i] == 'C')
			{
				strength = s[i];
				for (j = i + 1; (j < length) && (damage > D) && (P[j] == 'S'); j++)
				{
					P[j - 1] = 'S';
					P[j] = 'C';
					damage -= strength / 2;
					count++;
				}
			}
		}
		if (damage > D)
			printf("Case #%d: IMPOSSIBLE\n", t);
		else
			printf("Case #%d: %d\n", t, count);
	}
	return 0;
}
