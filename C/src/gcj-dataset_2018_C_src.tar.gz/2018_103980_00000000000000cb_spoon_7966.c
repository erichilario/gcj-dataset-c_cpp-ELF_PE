#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char list[31];
int ans[31];
int d;

int main(void)
{
  int n,i,j,k,l,t,cnt,o;
  // input
  scanf("%d", &n);

  for (t=1; t<=n; t++) {
    for (i=0; i<31; i++){
      ans[i] = 0;
    }
    scanf("%d %s", &d, list);

    k=0;
    for (i=0; i<strlen(list); i++) {
      if (list[i] == 'S') {
        ans[k]++;
      }
      else if (list[i] == 'C') {
        k++;
      }
    }

    k=1; o=0;
    for (i=0; i<31; i++) {
      o = o+ans[i]*k;
      k=k<<1;
    }

    printf("Case #%d: ", t);

    cnt=0; k=30;
    while (k>0){
      if (o <= d) {
        printf("%d", cnt);
        break;
      }
      if (ans[k] > 0) {
        ans[k]--;
        ans[k-1]++;
        o = o - (1<<(k-1));
        cnt++;
      }
      else {
        k--;
      }
    }

    if (k==0)
      printf("IMPOSSIBLE");

    printf("\n");
  }

  return 0;
}

