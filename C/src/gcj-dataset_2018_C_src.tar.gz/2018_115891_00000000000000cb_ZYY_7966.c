#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int T,D;
char P[40];
int ans, d, l;

int checkDamage() {
	int cur=1, total=0;
	for (int i=0; i<l; i++) {
		if (P[i]=='C')
			cur+=cur;
		else
			total+=cur;
	}

	return total;
}

int swapLast() {
	char ch;
	for (int i=l-1; i>0; i--) {
		if (P[i]=='S' && P[i-1]=='C') {
			ch=P[i];
			P[i]=P[i-1];
			P[i-1]=ch;
			return 1;
		}
	}

	return 0;
}

int main()
{
	scanf("%d", &T);
	for (int t=1; t<=T; t++) {
		scanf("%d %s", &D, P);
		l=strlen(P);
		ans=0;
		while (checkDamage()>D) {
			int ok=swapLast();
			if (ok==0) {
				ans=-1;
				break;
			}

			ans++;
		}

		if (ans>=0)
			printf("Case #%d: %d\n", t, ans);
		else
			printf("Case #%d: IMPOSSIBLE\n", t);
	}

	return 0;
}
