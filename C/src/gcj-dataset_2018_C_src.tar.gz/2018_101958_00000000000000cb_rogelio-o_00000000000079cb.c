#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

int compare( const void* a, const void* b)
{
    unsigned long int_a = * ( (unsigned long*) a );
    unsigned long int_b = * ( (unsigned long*) b );

     if ( int_a == int_b ) return 0;
     else if ( int_a < int_b ) return -1;
     else return 1;
}

unsigned long untranslateEvenIndex(unsigned long index) {
    return index * 2;
}

unsigned long untranslateOddIndex(unsigned long index) {
    return (index * 2) + 1;
}

unsigned long translateIndex(unsigned long index) {
    if(index % 2 == 0) {
        return index / 2;
    } else {
        return (index - 1) / 2;
    }
}

unsigned long indexOfFirstUnsortedElement(char *array, unsigned long arraySize) {
    unsigned long evenSize = ceil(arraySize / (double) 2);
    unsigned long evenArray[evenSize];
    unsigned long oddSize = arraySize - evenSize;
    unsigned long oddArray[oddSize];

    for(unsigned long i = 0; i < arraySize; i++) {
        unsigned long element = atoi(strtok(i == 0 ? array : NULL, " "));

        if(i % 2 == 0) {
            evenArray[translateIndex(i)] = element;
        } else {
            oddArray[translateIndex(i)] = element;
        }
    }

    qsort(evenArray, evenSize, sizeof(unsigned long), compare);
    qsort(oddArray, oddSize, sizeof(unsigned long), compare);

    for(unsigned long i = 0; i < oddSize; i++) {
        if(evenArray[i] > oddArray[i]) {
            return untranslateEvenIndex(i);
        } else if((i + 1) < evenSize && oddArray[i] > evenArray[i + 1]) {
            return untranslateOddIndex(i);
        }
    }

    return -1;
}

int main() {
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

    read = getline(&line, &len, stdin);
    int numProblems = atoi(line);

    for (int i = 1; i <= numProblems; ++i) {
        read = getline(&line, &len, stdin);
        unsigned long arraySize = atoi(strtok(line, " "));
        read = getline(&line, &len, stdin);
        char *array = line;

        unsigned long result = indexOfFirstUnsortedElement(array, arraySize);

        if(result == -1) {
            printf("Case #%d: OK\n", i);
        } else {
            printf("Case #%d: %lu\n", i, result);
        }
    }
}
