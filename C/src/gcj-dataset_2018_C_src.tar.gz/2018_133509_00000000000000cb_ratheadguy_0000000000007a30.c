#include <stdio.h>


int main() {

    int T; scanf("%d", &T);

    

    for (int id = 1; id <= T; ++id) {

        int A, flag = 0, maxx=500, maxy=500, adj[1000][1000],curr[1000][1000],currx,curry;

        for(int i=0;i<1000;i++){

            for(int j=0;j<1000;j++){

                adj[i][j]=0;

                curr[i][j]=0;

            }

        }

        scanf("%d", &A);

        while(!flag) {

            printf("%d %d\n", maxx, maxy);

            fflush(stdout);

            scanf("%d", &currx);

            scanf("%d", &curry);

            if(curr[currx][curry]!=1){

                   curr[currx][curry]=1;

                   adj[currx+1][curry]++;

                   adj[currx+1][curry+1]++;

                   adj[currx+1][curry-1]++;

                   adj[currx-1][curry]++;

                   adj[currx-1][curry+1]++;

                   adj[currx-1][curry-1]++;

                   adj[currx][curry+1]++;

                   adj[currx][curry-1]++;

            }

            if((curry==0)&&(currx==0)) flag = 1;

            else if((curry==-1)&&(currx==-1)){

                printf("ERROR");

                return 0;

            }

            else{

                int max=0,currmaxx=0,currmaxy=0;

                for(int i=0;i<1000;i++){

                    for(int j=0;j<1000;j++){

                        if(curr[i][j]!=0){

                            if((max<=adj[i][j])&&(adj[i][j]!=8)) {

                                max=adj[i][j];

                                currmaxx=i;

                                currmaxy=j;

                            }

                        }

                    }

                }

                maxx=currmaxx;

                maxy=currmaxy;

            }

        }

    }

    return 0;

}
