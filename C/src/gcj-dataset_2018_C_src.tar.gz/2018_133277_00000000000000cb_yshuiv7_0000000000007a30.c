#include <stdio.h>
#include <math.h>
#include <assert.h>
int map[1001][1001];
int main() {
	int t;
	scanf("%d", &t);
	for(int tt=1;tt<=t;tt++) {
		int a,i,j;
		scanf("%d", &a);
		if (a == 1) {
			printf("2 2\n");
			fflush(stdout);
			scanf("%d%d", &i,&j);
			assert(i == 0 && j == 0);
		}
		int tgti = ((int)sqrt(a))+1, tgtj = ((int)sqrt(a))+1;
		if (tgti < 3)
			tgti = 3;
		if (tgtj < 3)
			tgtj = 3;
		memset(map, 0, sizeof(map));
		i=j=-1;
		while(i!=0 || j!=0) {
			int x,y;
			for(x=1;x<=tgti;x++)
			for(y=1;y<=tgtj;y++) {
				if (map[x][y] == 0)
					goto out;
			}
out:
			if (x == 1)x=2;
			if (y==1)y=2;
			if (x==tgti)
				x=tgti-1;
			if(y==tgtj)
				y=tgtj-1;
			printf("%d %d\n", x, y);
			fflush(stdout);
			scanf("%d%d", &i, &j);
			map[i][j]=1;
		}
	}
}

