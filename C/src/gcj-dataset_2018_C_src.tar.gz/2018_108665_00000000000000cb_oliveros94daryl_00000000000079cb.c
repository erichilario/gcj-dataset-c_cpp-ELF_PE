#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


int main(){


	int T = 0;
	unsigned long nonesize = 0;
	unsigned long pairsize = 0;
	unsigned long size = 0;

	scanf("%d", &T);

	for(int t=1; t<=T; t++){

		scanf("%lu", &size);
		if(size%2 == 0){
			pairsize = size/2;
			nonesize = size/2;
		}else{
			pairsize = (size-1)/2;
			nonesize = (size+1)/2;
		}

		int pairs[pairsize];
		int nones[nonesize];

		//read
		for(int i=0; i<size; i++){
			if(i%2 == 0)  
				scanf("%d", &nones[i/2]);
			else 
				scanf("%d", &pairs[(i-1)/2]);
		}

		
		
		unsigned long index = 0;
		unsigned long result = 100001;
		for(index = 0; index < pairsize; index++){

			//Get minimums
				//pairs
			unsigned long pindex = index;
			unsigned long minpair = pairs[pindex];
			unsigned long minpairpos = index;
			while(pindex < pairsize){
				if(pairs[pindex] < minpair) {
					minpair = pairs[pindex];
					minpairpos = pindex;
				}
				if(index > 0)
					if(minpair == pairs[index-1])
						break;
				pindex++;
			}
			pairs[minpairpos] = pairs[index];
			pairs[index] = minpair;

			//nones
			unsigned long nindex = index;
			unsigned long minnone = nones[nindex];
			unsigned long minnonepos = index;
			while(nindex < nonesize){
				if(nones[nindex] < minnone){
					minnone = nones[nindex];
					minnonepos = nindex;
				} 
				if(index > 0)
					if(minnone == nones[index-1])
						break;
				nindex++;
			}
			nones[minnonepos] = nones[index];
			nones[index] = minnone;

		/*for(int i=0; i<pairsize; i++){
			printf("%d ", pairs[i]);
		}
		printf(" : ");
		for(int i=0; i<nonesize; i++){
			printf("%d ", nones[i]);
		}
		printf(" index %d \n", index);
		*/

			//Minimums are already switched
			//printf("\n%d < %d\n",pairs[index],nones[index]);
			if(pairs[index] < nones[index]){
				result = index*2;
				break;
			}
			if(index > 0){
				//printf("\n%d < %d\n",nones[index],pairs[index-1]);
			if(nones[index] < pairs[index-1]){
				result = (index-1)*2 + 1;
				break;
			}
			}


		}

		//final check
		if(pairsize != nonesize && result == 100001){
			//printf("\n%d < %d f\n",nones[nonesize-1],pairs[nonesize-2]);
			if(nones[nonesize-1] < pairs[nonesize-2])
				result = (nonesize-2)*2 +1;
		}

		if(result == 100001)
			printf("Case #%d: OK",t);
		else printf("Case #%d: %lu",t,result);
		/*for(int i=0; i<pairsize; i++){
			printf("%d ", pairs[i]);
		}
		printf(" : ");
		for(int i=0; i<nonesize; i++){
			printf("%d ", nones[i]);
		}*/
		printf("\n");
		
		

	} //T

	
	return 0;
}





