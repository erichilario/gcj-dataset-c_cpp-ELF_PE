#include <stdio.h>
#include <stdlib.h>

int get_int();


int icomp(const void* a, const void* b)
{
	return *((int *)a) - *((int *)b);
}

int main()
{
	int i, j;
	int n = get_int();

	for (i = 0; i < n; i++)
	{
		int m = get_int();
		int l1 = m/2;
		int l2 = l1;

		if (m%2 == 1)
		{
			l1++;
		}

		int p[l1];
		int q[l2];

		for (j = 0; j < m; j++)
		{
			if (j%2 == 0)
			{
				p[j/2] = get_int();
			}
			else
			{
				q[j/2] = get_int();
			}
		}

		qsort(p, l1, sizeof(int), icomp);
		qsort(q, l2, sizeof(int), icomp);

		/*
		printf("p: [");
		for (j = 0; j < l1; j++)
		{
			printf("%d ", p[j]);
		}
		printf("\b]\n");

		printf("q: [");
		for (j = 0; j < l2; j++)
		{
			printf("%d ", q[j]);
		}
		printf("\b]\n");
		*/

		int last = p[0];
		for (j = 1; j < m; j++)
		{
			int curr;
			if (j%2 == 0)
			{
				curr = p[j/2];
			}
			else
			{
				curr = q[j/2];
			}

			if (curr < last)
			{
				break;
			}
			last = curr;
		}
		if (j < m)
		{
			printf("Case #%d: %d\n", i + 1, j - 1);
		}
		else
		{
			printf("Case #%d: OK\n", i + 1);
		}
	}
}

int get_int()
{
	int ret = 0;
	char c  = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF)
		{
			return EOF;
		}
		if (c >= '0' && c <= '9')
		{
			sgn = 1;
			break;
		}
		if (c == '-')
		{
			c = getchar();

			if (c < '0' || c > '9')
			{
				continue;
			}

			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = (ret << 3) + (ret << 1) + c - '0';

		c = getchar();

		if (c < '0' || c > '9')
		{
			return sgn*ret;
		}
	}
}

