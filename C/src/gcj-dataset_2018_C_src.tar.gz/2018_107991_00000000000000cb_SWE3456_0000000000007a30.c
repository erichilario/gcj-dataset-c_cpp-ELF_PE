#include <stdio.h>

double dist(double a, double b, double x, double y) 
{
	return (a - x)*(a - x) + (b - y)*(b - y);
}

int main()
{
	double x1, y1, x2, y2,tx,ty;
	int N, res = 0;
	while (scanf("%d %lf %lf %lf %lf", &N, &x1, &y1, &x2, &y2) == 5)
	{
		res = 0;
		for (int i = 0; i<N; ++i) 
		{
			scanf("%lf %lf", &tx, &ty);
			if (res == 0) 
			{
				if (4.0*dist(x1,y1,tx,ty) <= dist(x2,y2,tx,ty))
				{
					printf("The gopher can escape through the hole at (%.3lf,%.3lf)\n", tx, ty);
					res = 1;
				}
			}
		}
		if (res == 0) printf("The gopher cannot escape.\n");
	}
	return 0;
}
