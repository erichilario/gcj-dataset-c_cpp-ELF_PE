#include <cstdio>

const int INF = 1000000009;

int t;

void solve(int t){
	int n;
	scanf("%d", &n);
	int a[n];
	for(int i = 0; i < n; i++){
		scanf("%d", &a[i]);
	}
	bool done = false;
	while(!done){
		done = true;
		for(int i = 0; i < n-2; i++){
			if(a[i] > a[i+2]){
				done = false;
				int tmp = a[i+2];
				a[i+2] = a[i];
				a[i] = tmp;
			}
		}
		/*
		 * for(int i = 0; i < n; i++){
			printf("%d ", a[i]);
		}
		printf("\n");
		* //*/
		//printf("pass\n");
	}
	/*
	 * for(int i = 0; i < n; i++){
		printf("%d ", a[i]);
	}
	printf("\n");
	* //*/
	for(int i = 0; i < n-1; i++){
		if(a[i] > a[i+1]){
			printf("Case #%d: %d\n", t, i);
			return;
		}
	}
	printf("Case #%d: OK\n", t);
	return;
}

int main(){
	scanf("%d", &t);
	for(int i = 0; i < t; i++){
		solve(i+1);
	}
	return 0;
}

	printf("\n");
	* //*/
	for(int i = 0; i < n-1; i++){
		if(a[i] > a[i+1]){
			printf("%d\n", i);
			return;
		}
	}
	printf("OK\n");
	return;
}

int main(){
	scanf("%d", &t);
	for(int i = 0; i < t; i++){
		solve();
	}
	return 0;
}

