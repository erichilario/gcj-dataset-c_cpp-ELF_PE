#include<stdio.h>
#include<stdlib.h>
int checkFull(int arr[3][3])
{
    int check = 1;
    for(int i = 0 ; i < 3 ; i++)
        for(int j = 0 ; j < 3 ; j++)
            if(arr[i][j] == 0)
                check = 0;
    return check;
}
int fillSquare(int x, int y)
{
    int check[3][3];
    int a, b;
    for(int i = 0 ; i < 3 ; i++)
        for(int j = 0 ; j < 3 ; j++)
            check[i][j] = 0;
    
    while(!checkFull(check))
    {
        printf("%d %d\n", x, y);
        fflush(stdout);
        scanf("%d %d", &a, &b);
        if(a == 0 && b == 0)
            return 1;
        check[a-x+1][b-y+1] = 1;
    }
    return 0;
}
int main()
{
    int a, t;
    scanf("%d", &t);
    for(int m = 0 ; m < t ; m++)
    {
        scanf("%d", &a);
        int e = 0, f = 0, temp = 0;
        while(e < 2 && temp == 0)
        {
            f = 0;
            while(f < 2 && temp ==0)
            {
                temp = fillSquare(10 + 3 * e, 10 + 3 * f);
                f++;
            }
            e++;
        }

    }
    return 0;
}
