#include <stdio.h>
#include <math.h>

int main(void) {
	int T;
	int case_count;
	double distance2 = sqrt(0.5);
	double distance2_half = distance2 / 2.0;
	if (scanf("%d", &T) != 1) return 1;
	for (case_count = 1; case_count <= T; case_count++) {
		double A;
		double A_half, A_half_sq;
		printf("Case #%d:\n", case_count);
		if (scanf("%lf", &A) != 1) return 1;
		A_half = A / 2.0;
		A_half_sq = A_half * A_half;
		if (A_half_sq <= 0.5) { /* 0.5 * 0.5 == 0.25 */
			double b = sqrt(0.5 - A_half_sq);
			printf("%.15f %.15f 0\n", (A_half - b) / 2.0, (b + A_half) / 2.0);
			printf("%.15f %.15f 0\n", (-A_half - b) / 2.0, (-b + A_half) / 2.0);
			puts("0 0 0.5");
		} else {
			double left = 0.0, right = atan(1.0); /* right = PI / 4 */
			double mid, p1, p2, area;
			int i;
			for (i = 0; i < 100; i++) {
				mid = (left + right) / 2;
				p1 = 0.5 * cos(mid);
				 p2 = distance2 * sin(mid);
				area = distance2 * (p1 * 2 + p2);
				if (area > A_half) right = mid; else left = mid;
			}
			printf("%.15f %.15f %.15f\n", distance2_half,
				distance2_half * cos(mid), distance2_half * sin(mid));
			printf("%.15f %.15f %.15f\n", -distance2_half,
				distance2_half * cos(mid), distance2_half * sin(mid));
			printf("0 %.15f %.15f\n", 0.5 * sin(mid), 0.5 * cos(mid));
		}
	}
	return 0;
}

