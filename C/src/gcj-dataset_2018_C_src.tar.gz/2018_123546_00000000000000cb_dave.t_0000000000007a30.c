#include <stdio.h>

int base_r = 0;
int base_c = 0;
int grid[400];
int phase = 0;
int width = 0;
int height = 0;
int solution_found = 0;

void hitpos(int real_r, int real_c) {
  int fake_r = real_r - base_r;
  int fake_c = real_c - base_c;
  grid[fake_r * width + fake_c] = 1;
}

int is_pos(int fake_r, int fake_c) {
  return grid[fake_r * width + fake_c];
}

void printpos(int fake_r, int fake_c) {
  int real_r = fake_r + base_r;
  int real_c = fake_c + base_c;
  printf("%d %d\n", real_r, real_c);
  fflush(stdout);
}

void hit_until(int fake_r, int fake_c, int offset_r, int offset_c) {
  int real_r;
  int real_c;
  while (!is_pos(fake_r, fake_c)) {
    printpos(fake_r + offset_r, fake_c + offset_c);
    scanf("%d", &real_r);
    scanf("%d", &real_c);
    if ((real_r == 0 && real_c == 0) || (real_r == -1 && real_c == -1)) {
      solution_found = 1;
      return;
    }
    hitpos(real_r, real_c);
  }
}


int main(void) {
  int i, j;
	int t, T;
  int A;
  int left = 0;
  int top = 0;
	scanf("%d", &T);
  for (t = 1; t <= T; t++) {
    solution_found = 0;
    for (i = 0; i < 400; ++i) {
      grid[i] = 0;
    }
    phase = 0;
    scanf("%d", &A);
    if (A == 20) {
      width = 4;
      height = 5;
      left = 2;
      top = 3;
    }
    else {
      width = 10;
      height = 20;
      left = 5;
      top = 10;
    }
    printf("20 20\n");
    fflush(stdout);
    scanf("%d", &base_r);
    scanf("%d", &base_c);
    hitpos(base_r, base_c);
    // TOP LEFT
    for (i = 0; i < left; i++) {
      for (j = 0; j < top; j++) {
        hit_until(i, j, 1, 1);
        if (solution_found) break;
      }
      if (solution_found) break;
    }
    if (solution_found) continue;
    // TOP RIGHT
    for (i = width - 1; i >= left; i--) {
      for (j = 0; j < top; j++) {
        hit_until(i, j, 1, -1);
        if (solution_found) break;
      }
      if (solution_found) break;
    }
    if (solution_found) continue;
    // BOTTOM LEFT
    for (i = 0; i < left; i++) {
      for (j = height - 1; j >= top; j--) {
        hit_until(i, j, -1, 1);
        if (solution_found) break;
      }
      if (solution_found) break;
    }
    if (solution_found) continue;
    // BOTTOM RIGHT
    for (i = width - 1; i >= left; i--) {
      for (j = height - 1; j >= top; j--) {
        hit_until(i, j, -1, -1);
        if (solution_found) break;
      }
      if (solution_found) break;
    }
    if (solution_found) continue;
  }
}

