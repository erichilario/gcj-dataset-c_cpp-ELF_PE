#include <stdio.h>
#include <string.h>

const int gridRows = 10;
const int gridCols = 20;

const int cellRows = 8;
const int cellCols = 18;

int occupacy(int* grid, int rows, int cols, int row, int col)
{
	int o = 0;
	int rl = row > 0 ? row - 1 : row, rh = row < rows - 1 ? row + 1 : row;
	int cl = col > 0 ? col - 1 : col, ch = col < cols - 1 ? col + 1 : col;

	for (int r = rl; r <= rh; ++r) {
		for (int c = cl; c <= ch; ++c) {
			o += grid[r * cols + c];
		}
	}

#if 0
	o += grid[(rp-1) * cols + cp-1];
	o += grid[(rp-1) * cols + cp  ];
	o += grid[(rp-1) * cols + cp+1];
	o += grid[(rp  ) * cols + cp-1];
	o += grid[(rp  ) * cols + cp  ];
	o += grid[(rp  ) * cols + cp+1];
	o += grid[(rp+1) * cols + cp-1];
	o += grid[(rp+1) * cols + cp  ];
	o += grid[(rp+1) * cols + cp+1];
#endif

	return o;
}

void init_cell(int* cell, int* grid, int rows, int cols)
{
	for(int r = 0;	r < rows; ++r) {
		for(int c = 0; c < cols; ++c) {
			cell[r * cols + c] = occupacy(grid, gridRows, gridCols, r + 1, c + 1);
		}
	} 
}

void pick_cell(int* cell, int rows, int cols, int* rowPick, int* colPick)
{
	int min = 9;
	int imin, jmin;
	
	for(int r = 0;	r < rows; ++r) {
		for(int c = 0; c < cols; ++c) {
			if(cell[r * cols + c] < min) {
				min = cell[r * cols + c];
				*rowPick = r;
				*colPick = c;
			}
		}
	}
}	

int main(int argc, char** argv)
{
	int T, A;
	int rPick, cPick, rCom, cCom;
	
	scanf("%d", &T);
	
	for (int t = 0; t < T; ++t) {

		scanf("%d", &A);
		printf("500 500\n");
		fflush(stdout);	

		int row, col;
		scanf("%d %d", &row, &col);
		
		int grid[gridRows][gridCols];
		memset(grid, 0, sizeof(grid));

		grid[0][0] = 1;
			
		int cell[cellRows][cellCols];
		memset(cell, 0, sizeof(cell));
		
		int rowInit = row, colInit = col;
		
		init_cell(&cell[0][0], &grid[0][0], cellRows, cellCols);
		pick_cell(&cell[0][0], cellRows, cellCols, &rPick, &cPick);
		
		rCom = rPick + rowInit + 1;
		cCom = cPick + colInit + 1;

		printf("%d %d\n", rCom, cCom);
		fflush(stdout);
		
		while(1) {
			scanf("%d %d", &row, &col);

			if (row > 0 && col > 0) {
				grid[row - rowInit][col - colInit] = 1;
				
				init_cell(&cell[0][0], &grid[0][0], cellRows, cellCols);
				pick_cell(&cell[0][0], cellRows, cellCols, &rPick, &cPick);
				
				rCom = rPick + rowInit + 1;
				cCom = cPick + colInit + 1;
				
				printf("%d %d\n", rCom, cCom);
				fflush(stdout);
			}
			else {
				break;
			}
		}
		
		if (row == -1 && col == -1)
			break;
	}
	
	return 0;
}



