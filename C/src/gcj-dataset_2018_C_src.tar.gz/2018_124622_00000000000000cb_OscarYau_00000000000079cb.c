#include <stdio.h>

unsigned long long findMin(unsigned long long list[50000], int len) {
    int i = 0;
    unsigned long long min = 0;
    int minLoc = 0;
    for(i = 0; i < len; i++) {
        if(list[i] < list[minLoc]) {
            minLoc = i;
        }
    }
    min = list[minLoc];
    list[minLoc] = 1000000001;
    return min;
}

unsigned long long findMax(unsigned long long list[50000], int len) {
    int i = 0;
    unsigned long long max = 0;
    int maxLoc = 0;
    for(i = 0; i < len; i++) {
        if(list[i] > list[maxLoc]) {
            maxLoc = i;
        }
    }
    max = list[maxLoc];
    list[maxLoc] = 0;
    return max;
}


int ha(unsigned long long oddList[50000], unsigned long long evenList[50000], int oddLen, int evenLen) {
    unsigned long long oddMin = 0;
    unsigned long long evenMin1 = 0, evenMin2 = 0;
    int i = 0;
    evenMin1 = findMin(evenList, evenLen);
    for(i = 0; i < oddLen; i++) {
        oddMin = findMin(oddList, oddLen);
        evenMin2 = findMin(evenList, evenLen);
        if(!(evenMin1 <= oddMin && oddMin <= evenMin2)) {
            if(oddMin < evenMin1 && oddMin < evenMin2) {
                return i*2;
            }
            else{
                return i*2 + 1;
            }
        }
        else {
            evenMin1 = evenMin2;
        }
    }
    if(i == oddLen) {
        return -1;
    }
}

int main() {
    int T = 0;
    unsigned long long oddList[50000], evenList[50000], temp = 0;
    int oddLen = 0, evenLen = 0;
    int N = 0;
    int i = 0, j = 0;
    int sol = 0;
    scanf("%d", &T);
    for (i = 0; i < T; i++) {
        scanf("%d", &N);
        if(N % 2 == 0) {
            oddLen = N/2;
            evenLen = N/2;
            for(j = 0; j < N/2; j++) {
                scanf("%llu", &evenList[j]);
                scanf("%llu", &oddList[j]);
            }
        }
        else {
            oddLen = N/2;
            evenLen = N/2 + 1;
            scanf("%llu", &evenList[0]);
            for(j = 0; j < N/2; j++) {
                scanf("%llu", &oddList[j]);
                scanf("%llu", &evenList[j + 1]);
            }
        }
        if(N == 3) {

        }
        sol = ha(oddList, evenList, oddLen, evenLen);
        if(sol == -1) {
            printf("Case #%d: OK\n", i + 1);
        }
        else {
            printf("Case #%d: %d\n", i + 1, sol);
        }
    }
}

