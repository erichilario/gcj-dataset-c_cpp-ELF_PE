#include <iostream>  // includes cin to read from stdin and cout to write to stdout
#include <string>
#include <sstream>
#include <ctime>
using namespace std;  // since cin and cout are both in namespace std, this saves some text

int main(int argc,char* argv[]){
    int T,ct,D,i,n,len;
	int dmg;
	char P[32];
	int B[32];

	cin >> T;
	for (ct = 1; ct <= T; ++ct) {
        cin >> D;
        cin >> P;
        len = strlen(P);
        n = 0; dmg = 0; B[0]= 1;
        for(i=0;i<strlen(P);i++){
            if(P[i]=='S'){
                n ++;
                dmg += B[i];
                B[i+1] = B[i];
			}
            else
                B[i+1] = B[i]*2;
		}
        if(n>D){
            cout << "Case #" << ct << ": IMPOSSIBLE" << endl;
            continue;
        }
        n = 0;
		while(dmg>D){
            for(i=len-1;i>0;i--){
                if(P[i]=='C')
                    continue;
                if(P[i-1]=='C'){
                    P[i] = 'C'; P[i-1] = 'S';
                    dmg = dmg - B[i] + B[i-1];
                    B[i] = B[i-1];
                    break;
                }
            }
            n++;
        }
        cout << "Case #" << ct <<  ": " <<n << endl;
    }
    return 0;
}
