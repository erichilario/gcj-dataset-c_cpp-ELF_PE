#include <stdio.h>

void swap(long long int* a, long long int* b)
{
	long long int t = *a;
	*a = *b;
	*b = t;
}

int partition(long long int a[], long long int b[], int l, int h)
{
	long long int r = a[h];   
	int i = l - 1, j; 
	for (j=l; j<=h- 1; j++)
	{
		if (a[j]<r)
		{
			i++;
			if(i!=j)
			{
				swap(&a[i], &a[j]);
				swap(&b[i], &b[j]);
			}
		}
	}
	if((i+1)!=h)
	{
		swap(&a[i + 1], &a[h]);
		swap(&b[i + 1], &b[h]);
	}
	return (i + 1);
}
void quickSort(long long int a[], long long int b[], int l, int h)
{
	if (l<h)
	{
		int p = partition(a, b, l, h);
		quickSort(a, b, l, p - 1);
		quickSort(a, b, p + 1, h);
	}
}

int main()
{
	/* code */
	int i, N;
	long long int t, t1;
	scanf("%lld", &t);
	t1=t;
	while(t--)
	{
		scanf("%d", &N);
		long long int V[N], P[N], pos=-1;
		for(i=0; i<N; i++)
		{
			scanf("%lld", &V[i]);
			P[i]=i;
		}
		quickSort(V, P, 0, N-1);
		for(i=0; i<N; i++)
		{
			if((P[i]-i)%2!=0) {pos=i; break;}
		}
		if(pos!=-1) printf("Case # %lld: %lld\n", (t1-t), pos);
		else		printf("Case # %lld: OK\n", (t1-t));
	}
	return 0;
}
