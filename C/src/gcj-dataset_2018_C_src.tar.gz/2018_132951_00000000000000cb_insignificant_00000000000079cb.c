#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

typedef uint8_t byte;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

#ifdef DEBUG
#  define debug(...) ({fprintf(stderr,__VA_ARGS__);fflush(stderr);})
#else
#  define NDEBUG
#  define debug(...)
#endif

#define swap(a,b) ({__typeof(a) _ = a;a = b;b = _;})

int compar(const void* a,const void* b)
{
	return *(int *)a - *(int *)b;
}

int main(void)
{
	u32 T;
	scanf("%u",&T);
	for(u32 t = 1;t <= T;t++)
	{
		printf("Case #%u: ",t);
		u32 N;
		scanf(" %u",&N);
		u32 n[N];
		for(u32 i = 0;i < N;i++)
			scanf(" %u",&n[i]);
		for(u32 i = 1,j = N - 1 &- 2;i < j;i += 2,j -= 2)
			swap(n[i],n[j]);
		u32 a = N + 1 >> 1,
		    b = N >> 1;
		qsort(&n[0],a,sizeof(n[0]),&compar);
		qsort(&n[a],b,sizeof(n[1]),&compar);
		for(u32 i = 0;i < N;i++)
			debug("%u ",n[i]);
		debug("\n");
		u32 i = 0,u = 0;
		do
		{
			u32 v = n[i];
			if(!(u <= v))
			{
				printf("%u\n",(i - 1 << 1) + 1);
				goto label00;
			}
			u = v;
			v = n[i + a];
			if(!(u <= v))
			{
				printf("%u\n",i << 1);
				goto label00;
			}
			u = v;
		}
		while(++i < b);
		if(i < a && !(u <= n[i]))
		{
			printf("%u\n",(i - 1 << 1) + 1);
			continue;
		}
		printf("OK\n");
label00:;
	}
	return 0;
}

/* inspired by Andy Pham */

