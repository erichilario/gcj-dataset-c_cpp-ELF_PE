#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_P_LENGTH 30

int main()
{
	int T,D,tcase,lenP;
	char P[MAX_P_LENGTH+1];

	scanf("%d", &T);
	for(tcase = 1; tcase <= T; tcase++)
	{
		int countS, i, strength, hacks, totalDamage;
		scanf("%d %s", &D, P);
		lenP = strlen(P);
		countS = 0;
		strength = 1;
		totalDamage = 0;
		for(i = 0; i < lenP; i++)
			if(P[i] == 'S')
			{
				countS++;
				totalDamage += strength;
			}
			else
				strength *= 2;
		if(countS > D)
		{
			printf("Case #%d: IMPOSSIBLE\n", tcase);
			continue;
		}
		countS = 0;
		hacks = 0;
		for(i = lenP-1; i >= 0; i--)
		{
			if(P[i] == 'C')
			{
				int s = countS;
				strength /= 2;
				while(totalDamage > D && s > 0)
				{
					totalDamage -= strength;
					s--;
					hacks++;
				}
				if(totalDamage <= D)
					break;
			}
			else
				countS++;
		}
		printf("Case #%d: %d\n", tcase, hacks);
	}
	return 0;
}

