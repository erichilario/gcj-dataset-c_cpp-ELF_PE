#include <stdio.h>
#include <string.h>

int a[101][101];
int ur[101][202], uc[101][202];

int themax(int i, int j, int n) {
  if (i >= n) return 0;
  int v = a[i][j] + n;
  int ni = i;
  int nj = j + 1;
  if (nj >= n) {
    ni = i + 1;
    nj = 0;
  }
  int ans = 1 + themax(ni, nj, n);
  if (!(ur[i][v] || uc[j][v])) {
    ur[i][v] = 1;
    uc[j][v] = 1;
    int othans = themax(ni, nj, n);
    ur[i][v] = 0;
    uc[j][v] = 0;
    if (othans < ans) {
      ans = othans;
    }
  }
  return ans;
}

int main(void) {
  int t, n;
  scanf("%d", &t);
  for (int it = 1; it <= t; ++it) {
    scanf("%d", &n);
    memset(ur, 0, sizeof(ur));
    memset(uc, 0, sizeof(uc));
    for (int i = 0; i < n; ++i) {
      for (int j = 0; j < n; ++j) {
        scanf("%d", &a[i][j]);
      }
    }
    printf("Case #%d: ", it);
    printf("%d\n", themax(0, 0, n));
  }
  return 0;
}

