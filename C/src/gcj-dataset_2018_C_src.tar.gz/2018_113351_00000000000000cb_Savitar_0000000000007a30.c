#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

struct POINT{
    int i;
    int j;
    int done;
};

typedef struct POINT P;

int search(P point, P* V, int N);
int compose3x3square(int top_left_vertex_I, int top_left_vertex_J);
int compose27(int i, int j);

int main(){

    int T, A;

    scanf("%d", &T);

    int t = 0; 
    for(t = 0; t < T; t++){
        scanf("%d", &A);

        if(A == 10){
            compose27(50, 50);            
        }else{
            int w = 0; 
            for(w = 0; w < 8; w++){
                int r;
                r = compose27(50, 50+(w*9));
                if(!r){
                    break;
                }
            }
        }
    }

    return 0;
}

int search(P point, P* V, int N){
    int h = 0; 
    for(h = 0; h < N; h++){
        if(V[h].i == point.i && V[h].j == point.j && !V[h].done){
            V[h].done = 1;
            return h;
        }
    }

    return -1;
}

int compose3x3square(int top_left_vertex_I, int top_left_vertex_J){
    P start; 
    start.i = top_left_vertex_I; //angolo in alto a sx del rettangolo
    start.j = top_left_vertex_J; 
    start.done = 0;

    P missing[10];
    int completed = 0; 
    int k = 0;
    int w = 0;
    int index = 0;
    for(w = 0; w < 3; w++){
        for(k = 0; k < 3; k++){
            missing[index].i = start.i+w;
            missing[index].j = start.j+k;
            missing[index].done = 0;
            index++;
        }
    }


    do{
        printf("%d %d\n", (start.i+1), (start.j+1));
                         
        int res1, res2;
        fflush(stdin);
        fflush(stdout);
        fflush(stderr);
        scanf("%d%d", &res1, &res2);
        if((res1 != 0 && res2 != 0) && (res1 != -1 && res2 != -1)){
            P point;
            point.i = res1;
            point.j = res2;
            int searchIndex = search(point, missing, 10);
            if(searchIndex != -1){
                completed++;
            }
        }else{
            return 0;
        }

    }while(completed < 9);
    return 1;
}

int compose27(int i, int j){
    int r1, r2, r3;
    
    r1 = compose3x3square(i, j);
    if(r1){
        r2 = compose3x3square(i, j+3);
        if(r2){
            r3 = compose3x3square(i, j+6);
        }
    }

    return (r1 && r2 && r3);
    
}
