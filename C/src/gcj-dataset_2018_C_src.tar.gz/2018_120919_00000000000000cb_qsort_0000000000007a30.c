#include <stdio.h>

int main() {
	int scores[7][6];
	int claim[7][6];
	int cases, i, j, k, size, tk, tj, max, done;
	scanf("%d", &cases);
	for (i=1; i<=cases; ++i) {
		scanf("%d", &size);		
		for(j=1; j<=5; ++j) {
			for (k=1; k<=4; ++k) {
				scores[j][k] = 9;
				claim[j][k] = 0;
			}
		}
		done = 0;
		while (!done) {
			tk = tj = max = 0;
			for(j=2; j<=4; ++j) {
				for (k=2; k<=3; ++k) {
					if (scores[j][k] >= max) {
						tk = k; tj = j; max=scores[j][k];
					} 
				}
			}
			printf("%d %d\n", tj, tk);
			fflush(stdout);
			scanf("%d %d", &j, &k);
			if (j==0 && k==0) done=1;
			if (j==-1 && k==-1) done=1;
			if (!claim[j][k]) {
			scores[j-1][k-1]--; scores[j-1][k]--; scores[j-1][k+1]--;
			scores[j][k-1]--; scores[j][k]--; scores[j][k+1]--;
			scores[j+1][k-1]--; scores[j+1][k]--; scores[j+1][k+1]--;
			claim[j][k] = 1;
			}	
		}
		
	}
	return 0;
}

