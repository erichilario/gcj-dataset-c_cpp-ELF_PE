#include <stdio.h>
int sum(char *in) {
	int ret = 0;
	int curr = 1;
	for(int i=0; in[i]; i++) {
		if (in[i] == 'S')
			ret += curr;
		else
			curr*=2;
	}
	return ret;
}
int main() {
	int n;
	scanf("%d\n", &n);
	for(int t=1; t<=n;t++) {
		char s[31];
		int d;
		scanf("%d %s\n", &d, s);
		int sc=0;
		for(int i=0; s[i]; i++) {
			if (s[i] == 'S')
				sc++;
		}
		if (sc > d) {
			printf("Case #%d: IMPOSSIBLE\n", t);
			continue;
		}
		int ans = 0;
		while(sum(s) > d) {
			int cand=-1;
			for(int i =1 ; s[i]; i++) {
				if (s[i]=='S' && s[i-1]=='C')
					cand=i;
			}
			s[cand]='C';
			s[cand-1]='S';
			ans++;
		}
		printf("Case #%d: %d\n", t, ans);
	}
}

