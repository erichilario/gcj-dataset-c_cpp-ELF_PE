#include<stdio.h>
int t, a, ch[3][3];
int A, B;
void go(int sx, int sy, int chx, int chy) {
	int zz=0,i=0,j=0,nm=0;
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++) {
			ch[i][j] = 0;
		}
	}
	for (zz=1;;zz++) {
		int z = 0, lx, ly;
		printf("%d %d\n", sx + chx, sy + chy);
		fflush(stdout);
		scanf("%d%d", &lx,&ly);
		if (ch[lx - sx - chx + 1][sy + chy - ly + 1] == 0) {
			ch[lx - sx - chx + 1][sy + chy - ly + 1] = 1;
			nm++;
		}
		if (nm == 9) { return; }
		if (lx == 0 && ly == 0) { return; }
		if (z == 0) { break; }
	}
	return;
}
int main() {
	scanf("%d%d", &t, &a);
	while (t--) {
		if (a == 20) {
			printf("%d %d\n", 50, 50);
			fflush(stdout);
			scanf("%d%d", &A, &B);
			int inita = A, initb = B;
			int i, j;
			go(inita-1, initb-1, 2, 3);
			go(inita-1, initb-1, 2, 6);
			go(inita-1, initb-1, 2, 2);
		}
		else {//a==200
			printf("%d %d\n", 50, 50);
			fflush(stdout);
			scanf("%d%d",&A,&B);
			int inita = A, initb = B;
			int i;
			for (i = 1; i <= 22; i++) {
				go(inita - 1, initb - 1, 2, i * 3);
			}
			go(inita - 1, initb - 1, 2, 2);
		}
	}
}
