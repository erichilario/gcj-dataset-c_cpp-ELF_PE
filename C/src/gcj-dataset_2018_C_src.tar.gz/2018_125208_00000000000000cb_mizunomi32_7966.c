#include<stdio.h>
#include <string.h>

int main(){
	int t,d,p;
	int i,j;
	int c;
	int x;
	int ans;
	int f;
	char buf[32];
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d %s",&d,buf);
		//printf("d is %d\n",d);
		c = 1;
		x = 0;
		ans = 0;
		f = 0;
		while(1){
			for(j=0;j<strlen(buf);j++){
                        	if(buf[j]=='C'){
                                	c*=2;
                        	}else{
                                	x+=c;
                       	 	}
                	}
		//	printf("x is %d\n",x);
			if(d >= x){
				printf("Case #%d: %d\n",i+1,ans);
				break;
			}else if(f){
				printf("Case #%d: IMPOSSIBLE\n",i+1);
				break;
			}
			c = 1;
			x = 0;
			for(j=strlen(buf);j>0;j--){
				if(buf[j]=='S' && buf[j-1]=='C'){
					buf[j]='C';
					buf[j-1]='S';
					break;
				}
				if(j==1){
				f =1;
				}
			}
			ans++;
		}
		
	}
	return 0;
}

