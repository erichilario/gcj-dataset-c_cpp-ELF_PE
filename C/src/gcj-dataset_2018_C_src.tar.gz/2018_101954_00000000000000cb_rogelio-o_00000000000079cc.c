#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define PI 3.14159265
#define MAX_RADIANS 45 * PI / 180

void rotate(long double result[8][3], long double ship[8][3], long double rotationMatrix[3][3]) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 3; j++) {
            result[i][j] = 0;
            for (int k = 0; k < 3; k++) {
                result[i][j] += ship[i][k] * rotationMatrix[k][j];
            }
        }
    }
} 

void rotateZ(long double result[8][3], long double ship[8][3], long double angle) {
    long double rotationMatrix[3][3] = {
        {cos(angle), -sin(angle), 0},
        {sin(angle), cos(angle), 0},
        {0, 0, 1}
    };

    rotate(result, ship, rotationMatrix);
}

void rotateX(long double result[8][3], long double ship[8][3], long double angle) {
    long double rotationMatrix[3][3] = {
        {1, 0, 0},
        {0, cos(angle), -sin(angle)},
        {0, sin(angle), cos(angle)}
    };

    rotate(result, ship, rotationMatrix);
}

void setFacesOfShip(long double faces[3][3], long double ship[8][3]) {
    faces[0][0] = (ship[1][0] + ship[4][0]) / 2;
    faces[0][1] = (ship[1][1] + ship[4][1]) / 2;
    faces[0][2] = (ship[1][2] + ship[4][2]) / 2;

    faces[1][0] = (ship[2][0] + ship[1][0]) / 2;
    faces[1][1] = (ship[2][1] + ship[1][1]) / 2;
    faces[1][2] = (ship[2][2] + ship[1][2]) / 2;

    faces[2][0] = (ship[2][0] + ship[4][0]) / 2;
    faces[2][1] = (ship[2][1] + ship[4][1]) / 2;
    faces[2][2] = (ship[2][2] + ship[4][2]) / 2;
}

long double calculateRectangleArea(long double ship[8][3]) {
    long double minX = ship[2][0];
    long double maxX = ship[4][0];
    long double minZ = ship[0][2];
    long double maxZ = ship[1][2];
    
    return fabsl((maxX - minX) * (maxZ - minZ));
}

long double calculareTriangleArea(long double b, long double h) {
    return b * h / 2;
}

long double calculateHexagonalArea(long double ship[8][3]) {
    long double area = 1.4142135624;

    area += calculareTriangleArea(fabsl(ship[4][0] - ship[2][0]), fabsl(ship[4][2] - ship[6][2]));
    area += calculareTriangleArea(fabsl(ship[5][0] - ship[3][0]), fabsl(ship[1][2] - ship[5][2]));

    return area;
}

int isValidArea(long double currentArea, long double area) {
    return currentArea > (area - pow(10, -6)) && currentArea < (area + pow(10, -6)) ? 1 : 0;
}

void findRotationForArea(long double faces[3][3], long double area) {
    long double ship[8][3] = {
        {0.5, 0.5, 0.5},
        {0.5, 0.5, -0.5},
        {-0.5, 0.5, 0.5},
        {-0.5, 0.5, -0.5},
        {0.5, -0.5, 0.5},
        {0.5, -0.5, -0.5},
        {-0.5, -0.5, 0.5},
        {-0.5, -0.5, -0.5}
    };

    long double currentArea = calculateRectangleArea(ship);
    long double currentShip[8][3];
    memcpy(currentShip, ship, sizeof(ship));
    if(area > currentArea) {
        long double superiorAngle = MAX_RADIANS;
        long double inferiorAngle = 0;
        long double angle = MAX_RADIANS;

        if(area <= 1.4142135624) {
            do {
                long double newAngle = inferiorAngle + ((superiorAngle - inferiorAngle) / 2);
                if(angle == newAngle) {
                    break;
                }
                angle = newAngle;
                rotateZ(currentShip, ship, -angle);
                currentArea = calculateRectangleArea(currentShip);

                if(isValidArea(currentArea, area)) {
                    break;
                } else if(currentArea > area) {
                    superiorAngle = angle;
                } else {
                    inferiorAngle = angle;
                }
            } while(angle <= MAX_RADIANS && angle >= 0);
        } else {
            superiorAngle = MAX_RADIANS;
            inferiorAngle = 0;
            angle = MAX_RADIANS;

            rotateZ(currentShip, ship, -angle);
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 3; j++) {
                    ship[i][j] = currentShip[i][j];
                }
            }

            do {
                long double newAngle = inferiorAngle + ((superiorAngle - inferiorAngle) / 2);
                if(angle == newAngle) {
                    break;
                }
                angle = newAngle;
                rotateX(currentShip, ship, -angle);
                currentArea = calculateHexagonalArea(currentShip);

                if(isValidArea(currentArea, area)) {
                    break;
                } else if(currentArea > area) {
                    superiorAngle = angle;
                } else {
                    inferiorAngle = angle;
                }
            } while(angle <= MAX_RADIANS && angle >= 0);
        }
    }

    setFacesOfShip(faces, currentShip);
}

int main() {
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

    read = getline(&line, &len, stdin);
    int numProblems = atoi(line);

    for (int i = 1; i <= numProblems; ++i) {
        read = getline(&line, &len, stdin);
        long double area = atof(line);
        
        long double faces[3][3];
        findRotationForArea(faces, area);

        printf("Case #%d:\n", i);
        for(int e = 0; e < 3; e++) {
            printf("%.*Le %.*Le %.*Le\n", 10, faces[e][0], 10, faces[e][1], 10, faces[e][2]);
        }
    }

    return 0;
}
