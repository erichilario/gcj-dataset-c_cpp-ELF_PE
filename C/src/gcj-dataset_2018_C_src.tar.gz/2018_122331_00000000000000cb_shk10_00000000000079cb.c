#include<stdio.h>

#define Get getchar()
int getInt() { int a=0,s=1; char c=0; while(c<33) c=Get; if(c=='-') {s=-1; c=Get;} while(c>33) {a=(a<<3)+(a<<1)+c-'0'; c=Get;} return a*s; }

int A[100005], B[50005], C[50005], N;

int compare(const void *a, const void *b) {
    return *(int*) a < *(int*) b ? -1 : 1;
}

int solve() {
    int second = N>>1;
    int i, first = second + (N&1);
    for(i=0; i<first; i++)
        B[i] = A[i<<1];
    for(i=0; i<second; i++)
        C[i] = A[(i<<1)+1];
    qsort(B, first, sizeof(int), compare);
    qsort(C, second, sizeof(int), compare);
    for(i=0; i<first; i++)
        A[i<<1] = B[i];
    for(i=0; i<second; i++)
        A[(i<<1)+1] = C[i];
    for(i=0; i<N-1; i++)
        if(A[i]>A[i+1])
            return i;
    return -1;
}

int main() {
    int cas, T=getInt();
    for(cas=1; cas<=T; cas++) {
        N=getInt();
        int i; for(i=0;i<N;i++) A[i]=getInt();
        int res = solve();
        if(res==-1)
            printf("Case #%d: OK\n", cas);
        else
            printf("Case #%d: %d\n", cas, res);
    }
    return 0;
}
