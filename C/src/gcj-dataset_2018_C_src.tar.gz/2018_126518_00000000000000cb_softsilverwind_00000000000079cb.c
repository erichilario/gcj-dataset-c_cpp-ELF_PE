#include <stdio.h>
#include <stdlib.h>

void trouble_sort(int *array, int size)
{
	int done = 0;
	while (!done)
	{
		done = 1;

		for (int i = 0; i < size - 2; ++i)
			if (array[i] > array[i+2])
			{
				done = 0;
				int temp = array[i];
				array[i] = array[i+2];
				array[i+2] = temp;
			}
	}
}

int is_sorted(int *array, int size)
{
	for (int i = 0; i < size - 1; ++i)
		if (array[i] > array[i+1])
			return i;

	return -1;
}

int array[100002];

int main()
{
	int n;

	scanf("%d", &n);

	for (int i = 0; i < n; ++i)
	{
		int elems;
		scanf("%d", &elems);

		for (int j = 0; j < elems; ++j)
			scanf("%d", &array[j]);

		trouble_sort(array, elems);
		int ret = is_sorted(array, elems);

		printf("Case #%d: ", i+1);

		if (ret == -1)
			printf("OK\n");
		else
			printf("%d\n", ret);
	}

	return 0;
}


