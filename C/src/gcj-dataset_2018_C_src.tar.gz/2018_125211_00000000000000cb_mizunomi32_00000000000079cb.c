#include<stdio.h>
#include <stdlib.h>
int t,n;
int* TroubleSort(int *L){
	int f = 0;
	int i;
	int tmp;
	while (!f){
		f = 1;
		for(i=0;i<n-2;i++){
			if(L[i] > L[i+2]){
				f = 0;
				tmp = L[i];
				L[i] = L[i+2];
				L[i+2] = tmp;
			}
		}
	}
	return L;

}
void check(int *L){
	int i;
	for(i=0;i<n-1;i++){
		if(L[i]>L[i+1]){
			printf("%d\n",i);
			return;
		}
	}
	printf("OK\n");
	return;
	
}
int main(){
	
	int *v;
	int i,j;

	v = (int *)malloc(sizeof(int)*100000);		
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d",&n);
		for(j=0;j<n;j++){
			scanf("%d",&v[j]);
		}
		//for(j=0;j<n;j++){
                //        printf("%d",v[j]);
                //}
		//printf("\n");
		v = TroubleSort(v);
		//for(j=0;j<n;j++){
                //        printf("%d",v[j]);
		//}
		printf("Case #%d: ",i+1);
		check(v);

	}
	free(v);		
	return 0;
}

