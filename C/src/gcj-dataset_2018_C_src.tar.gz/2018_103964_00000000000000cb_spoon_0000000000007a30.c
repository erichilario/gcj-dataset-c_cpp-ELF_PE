#include <stdio.h>

int main(void)
{
  int t,a,i,j,x,y;

  scanf("%d", &t);
  for (int c=1; c<=t; c++) {
    scanf("%d", &a);
    if (a==20) {
      while (1) {
        for (i=2; i<=3; i++) {
          for (j=2; j<=4; j++) {
            printf("%d %d\n", i, j);
            fflush(stdout);
            scanf("%d %d", &x, &y);
            if (x==0 && y==0)
              break;
          }
          if (x==0 && y==0)
            break;
        }
        if (x==0 && y==0)
          break;
      }
    }
    else {
      while (1) {
        for (i=2; i<=9; i++) {
          for (j=2; j<=19; j++) {
            printf("%d %d", i, j);
            fflush(stdout);
            scanf("%d %d", &x, &y);
            if (x==0 && y==0)
              break;
          }
          if (x==0 && y==0)
            break;
        }
        if (x==0 && y==0)
          break;
      }
    }
  }

  return 0;
}

