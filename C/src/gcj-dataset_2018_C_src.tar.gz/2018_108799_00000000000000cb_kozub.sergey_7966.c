
#include <bits/stdc++.h>
using namespace std;

int damage(string S)
{
    int D = 0, C = 1;
    for (char ch : S)
        if (ch == 'C') C *= 2;
        else D += C;
    return D;
}

int solve(int D, string S)
{
    unordered_set<string> visited;
    visited.insert(S);
    vector<string> check(1, S);
    int step = 0;
    while (check.size()) {
        vector<string> next;
        for (string s : check) {
            auto d = damage(s);
            if (d <= D)
                return step;
            for (int i = 1; i < (int)s.size(); i++) {
                string t = s;
                std::swap(t[i - 1], t[i]);
                if (!visited.count(t)) {
                    visited.insert(t);
                    next.push_back(t);
                }
            }
        }
        check = next;
        step++;
    }
    return -1;
}

int main()
{
    int T, D;
    string S;
    cin >> T;
    for (int t = 0; t < T; t++) {
        cin >> D >> S;
        int res = solve(D, S);
        if (res >= 0)
            cout << res << endl;
        else
            cout << "IMPOSSIBLE" << endl;
    }
    return 0;
}

