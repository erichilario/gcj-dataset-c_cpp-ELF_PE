#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

typedef uint8_t byte;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

#ifdef DEBUG
#  define debug(...) ({fprintf(stderr,__VA_ARGS__);fflush(stderr);})
#else
#  define NDEBUG
#  define debug(...)
#endif

int main(void)
{
	u32 T;
	scanf("%u",&T);
	for(u32 t = 1;t <= T;t++)
	{
		printf("Case #%u: ",t);
		u32 D;
		scanf(" %u",&D);
		byte p[32],*n = p;
		scanf(" %s",p);
		u32 m[30] = {0};
		u32 k = 0;
		do
			if(*n == 'C')
				k++;
			else
				m[k]++;
		while(*++n);
		u32 w = 0;
		for(u32 i = 0;i <= k;i++)
			w += m[i] << i;
		if(w <= D)
		{
			printf("0\n");
			continue;
		}
		if(n - p - k > D)
		{
			printf("IMPOSSIBLE\n");
			continue;
		}
		w -= D;
		k = 0;
		u32 i = 29;
		do
		{
			while(m[i] == 0)
				i--;
			k++;
			u32 a = 1 << i - 1;
			if(a >= w)
				break;
			w -= a;
			m[i]--;
			m[i - 1]++;
		}
		while(1);
		printf("%u\n",k);
	}
	return 0;
}

/* inspired by Andy Pham */

