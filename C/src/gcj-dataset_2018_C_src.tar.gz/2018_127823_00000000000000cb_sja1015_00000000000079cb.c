#include<stdio.h>
#include<algorithm>
int Data[100001], Sorted[100001],Even[100001],Odd[100001];
int DoubleSort[100001];
void Process(int Num_Case)
{
	int N,OddCount=0,EvenCount=0;
	scanf("%d", &N);
	for (int i = 0; i < N; i++)
	{
		scanf("%d", &Data[i]);
		Sorted[i] = Data[i];
		if (i % 2)
			Odd[OddCount++] = Data[i];
		else
			Even[EvenCount++] = Data[i];
	}
	std::stable_sort(Data, Data + N);
	std::stable_sort(Odd, Odd + OddCount);
	std::stable_sort(Even, Even + EvenCount);

	for (int i = 0; i < OddCount; i++)
	{
		DoubleSort[i * 2 + 1] = Odd[i];
		DoubleSort[i * 2] = Even[i];
	}
	if (N % 2)
		DoubleSort[N - 1] = Even[EvenCount - 1];
	for (int i = 0; i < N; i++)
		if (Data[i] != DoubleSort[i])
		{
			printf("Case #%d: %d\n", Num_Case, i);
			return;
		}
	printf("Case #%d: OK\n",Num_Case);
}
int main()
{
	int T;
	scanf("%d", &T);
	for (int i = 0; i < T; i++)
		Process(i+1);
	return 0;
}
