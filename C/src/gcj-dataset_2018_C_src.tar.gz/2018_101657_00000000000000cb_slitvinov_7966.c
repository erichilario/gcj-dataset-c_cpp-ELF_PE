#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

void error(const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    fprintf(stderr, "error: ");
    vfprintf(stderr, fmt, args);
    fprintf(stderr, "\n");
    va_end(args);
    exit(2);
}

int count(const char *s) {
    long ans, strength;
    for (ans = 0, strength = 1; *s != '\0'; s++) {
        switch (*s) {
        case 'C':
            strength *= 2;
            break;
        case 'S':
            ans += strength;
            break;
        default:
            error("wrong symbol: %d", *s);
        }
    }
    return ans;
}

void swap0(char *s, long i, long j) {
    char t;
    t = s[i]; s[i] = s[j]; s[j] = t;
}

enum {SWAP_YES, SWAP_NO};
int swap(char *s) {
    long n, i, j;
    n = strlen(s);
    for (i = n - 2; i >= 0; i--) {
        j = i + 1;
        if (s[i] == 'C' && s[j] == 'S') {
            swap0(s, i, j);
            return SWAP_YES;
        }
    }
    return SWAP_NO;
}

long main0() {
    long d, ans;
    char s[8192];
    if (scanf("%ld %s", &d, s) != 2) error("scanf failed");
    ans = 0;
    for (;;) {
        if (count(s) <= d) return ans;
        if (swap(s) == SWAP_NO) return -1;
        ans++;
    }
}

int main() {
    long T, i, ans;
    if (scanf("%ld", &T) != 1) error("scanf failed");
    for (i = 0; i < T; i++) {
        ans = main0();
        printf("Case #%ld: ", i + 1);
        if (ans == -1) puts("IMPOSSIBLE");
        else printf("%ld\n", ans);
    }
}

