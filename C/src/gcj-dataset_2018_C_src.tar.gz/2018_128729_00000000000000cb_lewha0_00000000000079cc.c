#include<stdio.h>
#include<math.h>

int T;
long double A;

int main(void)
{
        int l0, l1;
        long double left, right, x, s;

        scanf("%d", &T);
        for(l0 = 1; l0 <= T; l0++)
        {
                scanf("%Lf", &A);

                left = 0;
                right = 0.78539816339744830961566084581988;
                for(l1 = 0; l1 < 1000; l1++)
                {
                        x = (left + right) / 2.0;
                        s = cos(x) + sin(x);
                        if(s < A) left = x;
                        else right = x;
                }
                printf("Case #%d:\n", l0);
                printf("%.12Lf %.12Lf 0\n", sinl(x)*0.5, cosl(x)*0.5);
                printf("%.12Lf %.12Lf 0\n", cosl(x)*0.5, -sinl(x)*0.5);
                printf("0 0 0.5\n");
        }

        return 0;
}

