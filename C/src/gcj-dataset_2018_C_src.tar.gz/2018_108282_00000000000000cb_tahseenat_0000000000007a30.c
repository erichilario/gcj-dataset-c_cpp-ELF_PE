void main()
{
    int x,y,xi,yi,ar[1000][10],i,j,k,a,t;
    scanf("%d",&t);
    while(t>0)
    {
        t--;
        scanf("%d",&a);
        xi=-1;
        yi=-1;
        x=2;
        y=2;

        while(xi!=0 && yi!=0)
        {
            printf("%d %d\n",x,y);
            scanf("%d %d",&xi,&yi);
            ar[xi][yi]=1;
            if(ar[x][y]==1 &&ar[x-1][y-1]==1 && ar[x][y-1]==1 && ar[x+1][y-1]==1 && ar[x-1][y]==1 && ar[x+1][y]==1 && ar[x-1][y+1]==1 && ar[x][y+1]==1 && ar[x+1][y+1]==1)
            {
                x=x+3;
                printf("%d %d\n",x,y);
            }
        }

    }
}

