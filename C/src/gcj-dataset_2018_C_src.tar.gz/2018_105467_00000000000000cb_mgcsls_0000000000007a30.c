#include <stdio.h>
#include <stdlib.h>

#define HORI 100
#define VERT 100
#define TRUE 1
#define FALSE 0


void go_gopher(int up, int down, int left, int right);


int main(int argc, char *argv[]) {
	int ntests;
	scanf("%d", &ntests);
	
	int i;
	int area;
	int up, down, left, right;
	up = 5;
	left = 5;
	for (i=1; i<=ntests; i++) {		
		scanf("%d", &area);
		if (area == 20) {
			down = 9;
			right = 10;
		}
		else if (area == 200) {
			down = 25;
			right = 15;
		}
		else {
			printf(":(\n");
			return 0;
		}
		
		go_gopher(up, down, left, right);
		
	}
	
	return 0;
}


void go_gopher(int up, int down, int left, int right) {
	int j, k;
	int x, y;	
	
	int soil[HORI][VERT];
	for (j=0; j<HORI; j++) {
		for (k=0; k<VERT; k++) {
			soil[j][k] = FALSE;
		}
	}
	
	for (j=left; j<right-2; j++) {
		for (k=up; k<down-2; k++) {
			while (!(soil[j][k])) {
				printf("%d %d\n", j+1, k+1);
				fflush(stdout);				
				scanf("%d %d", &x, &y);
				if (x==0 && y==0) {
					return;
				}
				if (x==-1 && y==-1) {
					exit(EXIT_FAILURE);
				}
				soil[x][y] = TRUE;
			}
		}
	}
	
	for (j=left; j<right-2; j++) {
		while (!(soil[j][down-2]) || !(soil[j][down-1])) {
			printf("%d %d\n", j+1, down - 2);
			fflush(stdout);
			scanf("%d %d", &x, &y);
			if (x==0 && y==0) {
				return;
			}
			if (x==-1 && y==-1) {
				exit(EXIT_FAILURE);
			}
			soil[x][y] = TRUE;
		}
	}
		
	for (k=up; k<down-2; k++) {
		while (!(soil[right-2][k]) || !(soil[right-1][k])) {
			printf("%d %d\n", right-2, k+1);
			fflush(stdout);
			scanf("%d %d", &x, &y);
			if (x==0 && y==0) {
				return;
			}
			if (x==-1 && y==-1) {
				exit(EXIT_FAILURE);
			}
			soil[x][y] = TRUE;
		}
	}
	
	while (1) {
		printf("%d %d\n", right-2, down-2);
		fflush(stdout);
		scanf("%d %d", &x, &y);
		if (x==0 && y==0) {
			return;
		}
		if (x==-1 && y==-1) {
			exit(EXIT_FAILURE);
		}
	}
}

