#include <stdio.h>
#include <string.h>

__int64 score(char* p) {
	__int64 dam = 0;
	__int64 c = 1;

	while (*p) {
		if ( *p == 'C') c *= 2; else dam += c;
		p += 1;
	}

	return dam;
}

int main() {
	int N;
	char *P = new char[40];
	scanf("%d", &N);

	for (int i = 1; i <= N; ++i) {
		int D;
		scanf("%d %s", &D, P);

		int len = strlen(P);

		__int64 dam = score(P);
		int iter = 0;

		while (dam > D) {
			bool hasS = false;
			int pos = len;

			for (int j = len - 1; j >= 0; --j) {
				if (P[j] == 'S') hasS = true;
				if (hasS && P[j] == 'C') {
					pos = j;
					break;
				}
			}

			if (pos == len) {
				iter = -1; break; // not possible
			}

			iter += 1;
			char tmp = P[pos];
			P[pos] = P[pos + 1];
			P[pos + 1] = tmp;

			dam = score(P);
		}

		printf("Case #%d: ", i);
		if (iter == -1) {
			printf("IMPOSSIBLE\n");
		}
		else {
			printf("%d\n", iter);
		}

	}

	delete[] P;

	return 0;
}
