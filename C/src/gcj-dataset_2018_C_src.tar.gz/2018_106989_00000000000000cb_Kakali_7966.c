#include <stdio.h>

int get_int()
{
	int ret = 0;
	char c  = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF)
		{
			return EOF;
		}
		if (c >= '0' && c <= '9')
		{
			sgn = 1;
			break;
		}
		if (c == '-')
		{
			c = getchar();

			if (c < '0' || c > '9')
			{
				continue;
			}

			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = (ret << 3) + (ret << 1) + c - '0';

		c = getchar();

		if (c < '0' || c > '9')
		{
			return sgn*ret;
		}
	}
}

typedef struct
{
	int cc;
	int sc;
} par;

int calc_dmg(char* s)
{
	int d = 1;
	int ret = 0;

	int i = 0;
	while (s[i] != '\0')
	{
		if (s[i] == 'C')
		{
			d = d << 1;
		}
		else
		{
			ret += d;
		
		}
		i++;
	}

	return ret;
}

int main()
{
	int i, j, k, l;
	int n = get_int();

	for (i = 0; i < n; i++)
	{
		int d = get_int();

		char c = getchar();
		char p[32];
		j = 0;
		while (c != 10)
		{
			p[j++] = c;
			c = getchar();
		}

		p[j] = '\0';

		int o = calc_dmg(p);

		l = 0;
		while (d - o < 0)
		{
			for (k = 0; k < j; k++)
			{
				if (p[k] == 'C')
				{
					break;
				}
			}
			for (k = k + 1; k < j; k++)
			{
				if (p[k] == 'S')
				{
					break;
				}
			}
			if (k >= j)
			{
				break;
			}
			char temp = p[k];
			p[k] = p[k - 1];
			p[k - 1] = temp;

			l++;
			o = calc_dmg(p);
		}
		if (d - o < 0)
		{
			printf("Case #%d: IMPOSSIBLE\n", i + 1);
		}
		else
		{
			printf("Case #%d: %d\n", i + 1, l);
		}
	}
}

