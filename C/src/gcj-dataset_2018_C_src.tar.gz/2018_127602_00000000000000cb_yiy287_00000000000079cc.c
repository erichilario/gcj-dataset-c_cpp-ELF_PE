#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main(void) {
	const double SQRT2 = 1.41421356237;
	const double PI = 3.14159265359;
	const double PI_2 = PI / 2;
	const double PI_4 = PI / 4;
	int t;
	double a, b, c;
	scanf("%d", &t);
	
	for (int t1 = 0; t1 < t; t1++) {
		printf("Case #%d:\n", t1 + 1);
		
		scanf("%lf", &a);
		//printf("a = %.10lf\n", a);
		
		a = asin(a / SQRT2) - PI_4;
		//printf("theta = %.10lf rad\n", a);
		
		b = a,
		c = PI_2 - a;
		
		printf("0 %.10lf %.10lf\n", -0.5 * cos(b), 0.5 * sin(b)); // first point
		printf("0 %.10lf %.10lf\n", 0.5 * sin(b), 0.5 * cos(b)); // second point
		printf("-0.5 0 0\n"); // third point
	}

	return 0;	
}

