#include<stdio.h>
#include<stdlib.h>
#include<strings.h>

void swap(int* a, int* b)
{
    long int t = *a;
    *a = *b;
    *b = t;
}
int partition (long int arr[], int low, int high)
{
    int pivot = arr[high];    // pivot
    int i = (low - 1);  // Index of smaller element
 
    for (int j = low; j <= high- 1; j++)
    {
        
        if (arr[j] <= pivot)
        {
            i++;    
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}
 

void quickSort(long int arr[], int low, int high)
{
    if (low < high)
    {
        
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void triple_sort(long int a[],long int b[],int n)
{   
	int p;
	for(int i=0;i<n;i++) b[i]=a[i];

	for(int i=0;i<n-2;i++)
	{
		if(a[i]>a[i+2])
		{
			int p=a[i];
			a[i]=a[i+2];
			a[i+2]=p;
		}
	}
   

	for(int i=0;i<n;i++)
	{
		if(a[i]==b[i]) p=1;
		else {p=0; break;}
	}

	if(p==0) triple_sort(a,b,n);
	else return;
		
}




int main()
{
	int t,n,j,pointer=0,flag=0;
	
	scanf("%d",&t);
	for(int i=0;i<t;i++)
	{ flag=0;
        scanf("%d\n",&n);
        long int a[n],b[n],c[n];
        for(int q=0;q<n;q++)
        {
        	scanf("%ld",&a[q]);
        	c[q]=a[q];
        }


        triple_sort(a,b,n);
        quickSort(c,0,n-1);
        for(j=0;j<n;j++)
        {
        	if(c[j]==b[j]) continue;
        	else {flag=1;break;}
        }

        
        if(flag==0) printf("Case #%d: OK\n",i+1);
        else printf("Case #%d: %d\n",i+1,j);

	}

}
