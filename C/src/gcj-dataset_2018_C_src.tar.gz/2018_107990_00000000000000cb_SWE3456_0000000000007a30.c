#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int getSol(float aX, float aY, float bX, float bY, float caveLocX, float caveLocY){
    float vecAX = caveLocX - aX;
	float vecAY = caveLocY - aY;

	float vecBX = caveLocX - bX;
	float vecBY = caveLocY - bY;

	float scalA = sqrt((vecAX*vecAX)+(vecAY*vecAY));
	float scalB = sqrt((vecBX*vecBX)+(vecBY*vecBY));

	//printf("scalA : %f scalB : %f", scalA, scalB);
	if(scalA*2 < scalB) return 1;
	else return 0;
}

int main(){
	int size=0;
	int caveSize = 0;
	int i = 0;
	int j = 0;
	float caveX, caveY;
	float aniAX, aniAY, aniBX, aniBY;
	int solResult;

	scanf("%d", &size);
	
	for(i = 0 ; i < size ; i++){
		scanf("%d", &caveSize);
		if(caveSize==-1) break;

		scanf("%f", &aniAX);
		scanf("%f", &aniAY);
		scanf("%f", &aniBX);
		scanf("%f", &aniBY);

		for(j = 0 ; j < caveSize ; j++){
			scanf("%f", &caveX);
			scanf("%f", &caveY);

			solResult = getSol(aniAX, aniAY, aniBX, aniBY, caveX, caveY);
			if(solResult==1){
				printf("Case #%d :(%0.3f,%0.3f)\n", j+1, caveX, caveY);
				break;
			}else if(solResult==0 && j==caveSize-1){
				printf("Case #%d :", j+1);
				break;
			}
		}
	}
	return 0;
}
