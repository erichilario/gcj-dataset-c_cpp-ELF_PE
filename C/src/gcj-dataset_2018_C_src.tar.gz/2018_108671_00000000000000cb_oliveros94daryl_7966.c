#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

unsigned long calcDmg(char* atk, unsigned long size);

int main(){


	int T = 0;
	unsigned long N;
	char attack[31];

	scanf("%d", &T);

	for(int t=1; t<=T; t++){

		int changes = 0;
		int saved = 0;

		scanf("%lu %s", &N, attack);
		if(calcDmg(attack, strlen(attack)) <= N) saved = 1;
		for(int i=0; i < strlen(attack)-1 && saved == 0 ; i++){
			if(attack[i] == 'C' && attack[i+1] == 'S'){
				changes++;
				attack[i] = 'S';
				attack[i+1] = 'C';
				//printf("%s %d\n",attack, calcDmg(attack, strlen(attack)));
				if(calcDmg(attack, strlen(attack)) <= N) saved = 1;
				i = i-2;
				if(i<0)i=0;
			}

		}


		if(saved == 1)
			printf("Case #%d: %d\n",t,changes);
		else
			printf("Case #%d: IMPOSSIBLE\n",t);
		

	};

	
	return 0;
}


unsigned long calcDmg(char* atk, unsigned long size){

	int result = 0;
	int dmg = 1;
	for(int x=0; x<size; x++)
		if(atk[x] == 'S') result = result + dmg;
		else dmg = dmg*2;
	
	return result;

}





