#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int *find1(int *x,int *y,int z)
{
	int *i=x;
	while(i<y)
	{
		if(*i == z) 
		{
			return i;
			break;
		}
	}
	return y;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t>0)
    {
        t--;
        int a;
        scanf("%d",&a);
        int x,y,r=0,p,q,t=9,w=0;
        unsigned long int s[1000];
        printf("500 500\n");
        fflush(stdout);
        scanf("%d %d",&x,&y);
        s[0]=1000*x+y;
        w=1;
        while(p!=0 || q!=0)
        {
            int k,l;
            k=(rand()%(3))-1;
            k *= r;
            l=(rand()%(3))-1;
            l *= r;
            printf("%d %d\n",x+k,y+l);
            fflush(stdout);
            scanf("%d %d",&p,&q);
            if(find1(s,s+w,1000*p+q)==s+w)
            {
                s[w]=1000*p+q;
                w++;
            }
            if(w==t)
            {
                r++;
                t+=pow(2*r+3,2)-pow(2*r+1,2);
            }
        }
    }
    return 0;
}

