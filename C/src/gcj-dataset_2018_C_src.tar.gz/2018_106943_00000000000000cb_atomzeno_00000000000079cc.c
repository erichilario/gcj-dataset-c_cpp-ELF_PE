#include<stdio.h>
#include<math.h>
using namespace std;
int main() {
	int t, tt;
	double A, B = (double)sqrt(2);
	scanf("%d", &t);
	for (tt = 1; tt <= t; tt++) {
		scanf("%lf", &A);
		double C, D;
		printf("Case #%d\n", tt);
		if (((double)2.00000000000 - A * A) < 2e-6) {
			printf("0.3535533905932738 0.3535533905932738 0\n-0.3535533905932738 0.3535533905932738 0\n0 0 0.5\n");
		}
		else {
			C = (A + sqrt((double)2.000000000 - A * A)) / ((double)4.000000000);
			D = (A - sqrt((double)2.000000000 - A * A)) / ((double)4.000000000);
			printf("%.10lf %.10lf 0\n", C, D);
			D = D - D - D;
			printf("%.10lf %.10lf 0\n", D, C);
			printf("0 0 0.5\n");
		}
	}
}
