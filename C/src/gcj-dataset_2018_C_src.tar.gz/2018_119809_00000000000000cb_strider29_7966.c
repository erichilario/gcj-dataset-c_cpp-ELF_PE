#include <stdio.h>
#include <string.h>

int main() {
	int t;
	scanf("%d",&t);
	int t1 = t;
	while(t--) {
		long long int d;
		scanf("%lld",&d);
		char seq[31];
		scanf("%s",seq);
		int len = strlen(seq);
		int arr[len];
		int i;
		long long int posofc=-1;
		for(i=0;i<len;i++) {
			if(seq[i]=='C') {
				arr[i]=2;
				posofc = i;
			}
			else
				arr[i]=1;
		}
		if (posofc == -1) {
			if (len <= d) {
				printf("Case #%d: 0\n", t1-t);
			} else {
				printf("Case #%d: IMPOSSIBLE\n", t1-t);
			}
		} else {
			long long int reqPosOfC = ((3*len - d - 3)/2) ;
			if (reqPosOfC < 0) {
				printf("Case #%d: 0\n", t1-t);
			} else if (reqPosOfC >= len) {
				printf("Case #%d: IMPOSSIBLE\n", t1-t);
			} else if (posofc >= reqPosOfC){
				printf("Case #%d: 0\n", t1-t);
			} else {
				printf("Case #%d: %lld\n", t1-t, reqPosOfC - posofc);
			}
		}
	}
}
