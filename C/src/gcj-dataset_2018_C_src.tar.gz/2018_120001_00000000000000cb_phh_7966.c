#include <stdio.h>
#include <string.h>

int compute_damage(char *command) {
        int c = 1, s = 0;
        int len = strlen(command);
        for(int i=0; i < len; i++) {
                if(command[i] == 'S')
                        s+=c;
                else if(command[i] == 'C')
                        c*=2;
        }
        return s;
}

int main() {
        int N;
        scanf("%d\n", &N);
        for(int i=0; i<N; i++) {
                char P[31];
                int D;
                scanf("%d %s\n", &D, P);
                int len = strlen(P);
                int changes = 0;
                while(compute_damage(P) > D) {
                        changes++;
                        int maxDelta = 0;
                        int maxDeltaI = 0;
                        int originalScore = compute_damage(P);
                        for(int i=0; i<(len-1); i++) {
                                char currentP[31];
                                strcpy(currentP, P);
                                if(currentP[i] == 'C' && currentP[i+1] == 'S') {
                                        currentP[i] = 'S';
                                        currentP[i+1] = 'C';
                                        int delta = originalScore - compute_damage(currentP);
                                        if(delta > maxDelta) {
                                                maxDelta = delta;
                                                maxDeltaI = i;
                                        }
                                }
                        }
                        if(maxDelta == 0)
                                break;
                        P[maxDeltaI] = 'S';
                        P[maxDeltaI+1] = 'C';
                }
                if(compute_damage(P) <= D)
                        printf("Case #%d: %d\n", i+1, changes);
                else
                        printf("Case #%d: IMPOSSIBLE\n", i+1);
        }
}
