#include <stdio.h>
#include <string.h>
#include <stdbool.h>

bool F[1000][1000];

bool done(int x, int y);

int main() {
	setbuf(stdout, NULL);
	int T, A, x, y, k;
	scanf("%d", &T);
	for (int t=1; t<=T; t++) {
		scanf("%d", &A);
		memset(F, 0, sizeof(F));
		k = 20;
		done(10, k);
		while (scanf("%d %d", &x, &y) > 0) {
			F[x][y] = true;
			if (x == 0 && y == 0)
				break;
			if (x == -1 && y == -1)
				return 0;
			while (done(10, k))
				k += 3;
		}
	}
	return 0;
}

bool done(int x, int y) {
	int dx[9] = {0, 0, 1, 1, 1, 0, -1, -1, -1};
	int dy[9] = {0, 1, 1, 0, -1, -1, -1, 0, 1};
	for (int i=0; i<9; i++)
		for (int j=0; j<9; j++)
			if (!F[x+dx[i]][y+dy[j]]) {
				printf("%d %d\n", x, y);
				return false;
			}
	return true;
}

