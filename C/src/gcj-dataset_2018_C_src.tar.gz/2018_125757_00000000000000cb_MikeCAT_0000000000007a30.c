#include <stdio.h>
#include <math.h>

int main(void) {
	int T;
	int case_count;
	if (scanf("%d", &T) != 1) return 1;
	for (case_count = 1; case_count <= T; case_count++) {
		int A;
		int I_in, J_in;
		int width, height;
		char board[200][200] = {{0}};
		if (scanf("%d", &A) != 1) return 1;
		width = height = (int)sqrt(A);
		while (width * height < A) width++;
		if (width < 3) width = 3;
		if (height < 3) height = 3;
		for (;;) {
			int i, j, imax = 1, jmax = 1, scoremax = -1;
			for (i = 1; i + 1 < height; i++) {
				for (j = 1; j + 1 < width; j++) {
					int score = 0, k, l;
					for (k = -1; k <= 1; k++) {
						for (l = -1; l <= 1; l++) {
							if (!board[i + k][j + l]) score++;
						}
					}
					if (score > scoremax) {
						imax = i;
						jmax = j;
						scoremax = score;
					}
				}
			}
			printf("%d %d\n", imax + 500, jmax + 500);
			fflush(stdout);
			if (scanf("%d%d", &I_in, &J_in) != 2) return 1;
			if (I_in <= 0 || J_in <= 0) break;
			if (500 <= I_in && I_in < 500 + height && 500 <= J_in && J_in < 500 + width) {
				board[I_in - 500][J_in - 500] = 1;
			}
		}
	}
	return 0;
}

