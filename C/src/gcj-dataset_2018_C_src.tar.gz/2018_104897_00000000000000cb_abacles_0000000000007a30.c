#include <stdio.h>
#include <string.h>

int min(int a, int b) { return a < b ? a : b; }
int max(int a, int b) { return a > b ? a : b; }

int main()
{
  int ncases, size, height = 5, width = 4, x, y, ax, ay, c;
  char orchard[5][40], done;
  for(c=0,scanf("%d", &ncases);c<ncases;c++)
    {
      memset(orchard, 0, sizeof orchard);
      for(x=0;x<width;x++)
	for(y=0;y<height;y++)
	  orchard[y][x] = 0;
      scanf("%d", &size);
      if(size == 200)
	width = 40;
      for(done=0,y=0;y<height && !done;y++)
	{
	  for(x=0;x<width && !done;x++)
	    {
	      while(!orchard[y][x])
		{
		  printf("%d %d\n", 1+max(min(y, height-2), 1),
			 1+max(min(x, width-2), 1));
		  fflush(stdout);
		  scanf("%d %d", &ay, &ax);
		  if(ax == -1 && ay == -1)
		    return 0;
		  else if(!ax && !ay)
		    {
		      done = 1;
		      break;
		    }
		  orchard[ay-1][ax-1] = 1;
		}
	    }
	}
    }
}

