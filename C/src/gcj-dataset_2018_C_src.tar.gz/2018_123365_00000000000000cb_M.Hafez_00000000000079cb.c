// #include <stdio.h>
//
// int main() {
//   int t, tc = 0;
//   int n, i;
//   int arr[100010];
//   scanf("%d", &t);
//   while(t--) {
//     scanf("%d", &n);
//     for(i = 0; i < n; ++i) {
//       scanf("%d", &arr[i]);
//     }
//     if(arr[1] < arr[0] && arr[1] < arr[2]) {
//       printf("Case #%d: 1\n", ++tc);
//     }
//     else if(arr[n-2] > arr[n-1] && arr[n-2] > arr[n-3]) {
//       printf("Case #%d: %d\n", ++tc, n-2);
//     }
//     else {
//       for(i = 2; i < n-1; ++i) {
//         if(arr[i] >= arr[i-2]) {
//           if(arr[i] < arr[i-1] && arr[i] > arr[i+1]) {
//             printf("Case #%d: %d\n", ++tc, i-1);
//           }
//           else if(arr[i])
//         }
//
//       }
//
//       printf("Case #1: OK\n");
//     }
//   }
//   return 0;
// }

#include <stdio.h>

int main() {
  int t, tc = 0;
  int i, n;
  int arr[100010];
  int done;
  scanf("%d", &t);
  while(t--) {
    scanf("%d", &n);
    for(i = 0; i < n; ++i) {
      scanf("%d", &arr[i]);
    }
    done = 0;
    while(!done) {
      done = 1;
      for(i = 0; i < n - 2; ++i) {
        if(arr[i] > arr[i+2]) {
          arr[i] += arr[i+2];
          arr[i+2] = arr[i] - arr[i+2];
          arr[i] -= arr[i+2];
          done = 0;
        }
      }
    }
    for(i = 0; i < n-1; ++i) {
      if(arr[i] > arr[i+1]) {
        break;
      }
    }
    if(i < n-1) {
      printf("Case #%d: %d\n", ++tc, i);
    }
    else {
      printf("Case #%d: OK\n", ++tc);
    }
  }
  return 0;
}

