#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
using namespace std;

int A[105][105];
int ori[105][105];
int ban[205];

int max(int a, int b){ return a > b ? a : b; }

int main(){
    int T;
    scanf("%d", &T);
    for(int tc=0; tc<T; tc++){
        int N;
        scanf("%d", &N);
        for(int i=1; i<=N; i++) for(int j=1; j<=N; j++) scanf("%d", &ori[i][j]);
        int res = 1e9;
        for(int bit=0; bit<(1<<(N*N)); bit++){
            for(int i=1; i<=N; i++) for(int j=1; j<=N; j++) A[i][j] = ori[i][j];
            int tmp = bit;
            for(int i=1; i<=N; i++){
                for(int j=1; j<=N; j++){
                    if(bit&1){
                        vector<int> allowed;
                        for(int x=100-N; x<=100+N; x++) ban[x] = 0;
                        for(int x=1; x<=N; x++){
                            if(x < i) ban[A[x][j]+100] = 1;
                            if(x < j) ban[A[i][x]+100] = 1;
                        }
                        for(int x=100-N; x<=100+N; x++){
                            if(x == 100 || ban[x]) continue;
                            allowed.push_back(x-100);
                        }
                        int x = rand()%allowed.size();
                        A[i][j] = allowed[x];
                    }
                    bit >>= 1;
                }
            }
            int valid = 1;
            for(int i=1; i<=N; i++){
                for(int j=1; j<=N; j++){
                    for(int x=1; x<=N; x++){
                        if(x != i && A[x][j] == A[i][j]) valid = 0;
                        if(x != j && A[i][x] == A[i][j]) valid = 0;
                    }
                }
            }
            if(valid) res = min(res, __builtin_popcount(tmp));
            bit = tmp;
        }
        printf("Case #%d: %d\n", tc+1, res);
    }
    return 0;
}

