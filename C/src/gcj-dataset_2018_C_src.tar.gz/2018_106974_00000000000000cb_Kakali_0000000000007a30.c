#include <stdio.h>
#include <stdlib.h>

int get_int();

int main()
{
	int ii, i, j;
	int n = get_int();
	//FILE* out4 = fopen("out4", "w");

	for (ii = 0; ii < n; ii++)
	{
		fflush(stdout);
		int a = get_int();
		if (a != 200)
		{
			a = 5;
		}
		else
		{
			a = 15;
		}

		int f[a][a];

		for (i = 0; i < a; i++)
		{
			for (j = 0; j < a; j++)
			{
				f[i][j] = 0;
			}
		}

		//fprintf(out4, "%d\n", n);

		fprintf(stdout, "500 500\n");
		fflush(stdout);
		int x = get_int();
		int y = get_int();

		f[x - 500][y - 500] = 1;

		while (1)
		{
			int max_score = -1;
			int max_loc_x = -1;
			int max_loc_y = -1;
			for (i = 1; i < a - 1; i++)
			{
				for (j = 1; j < a - 1; j++)
				{
					int tmp = f[i - 1][j - 1] + f[i - 1][j + 0] + f[i - 1][j + 1] +
						      f[i + 0][j - 1] + f[i + 0][j + 0] + f[i + 0][j + 1] +
					       	  f[i + 1][j - 1] + f[i + 1][j + 0] + f[i + 1][j + 1];

					tmp = 9 - tmp;

					if (tmp > max_score)
					{
						max_score = tmp;
						max_loc_x = i;
						max_loc_y = j;
					}
				}
			}

			//fprintf(out4, "~mx %d\n", max_loc_x);
			//fprintf(out4, "~my %d\n", max_loc_y);
			//fprintf(out4, "~ms %d\n", max_score);

			//fprintf(out4, "~\n");
			for (i = 0; i < a; i++)
			{
				for (j = 0; j < a; j++)
				{
					//fprintf(out4, "%d ", f[i][j]);
				}
				//fprintf(out4, "\n");
			}

			printf("%d %d\n", max_loc_x + 500, max_loc_y + 500);
			fflush(stdout);

			x = get_int();
			y = get_int();

			//fprintf(out4, "~x %d\n", x);
			//fprintf(out4, "~y %d\n", y);

			if (x == 0 && y == 0)
			{
				break;
			}

			f[x - 500][y - 500] = 1;
		}
	}
	//fclose(out4);
}

int get_int()
{
	int ret = 0;
	char c  = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF)
		{
			return EOF;
		}
		if (c >= '0' && c <= '9')
		{
			sgn = 1;
			break;
		}
		if (c == '-')
		{
			c = getchar();

			if (c < '0' || c > '9')
			{
				continue;
			}

			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = (ret << 3) + (ret << 1) + c - '0';

		c = getchar();

		if (c < '0' || c > '9')
		{
			return sgn*ret;
		}
	}
}

