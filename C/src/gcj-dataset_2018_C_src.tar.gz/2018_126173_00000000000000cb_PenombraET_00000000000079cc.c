#include <stdio.h>
#include <math.h>


int main()
{
	double F = sqrt(2);

	int T;
	scanf("%d", &T);
	
	for (int i = 0; i < T; ++i)
	{
		double A;
		scanf("%lf", &A);
		
		double v = asin(A / F);
		
		printf("0.5 0 0\n");
		printf("0 %.10lf %.10lf\n", 0.5 * cos(v + M_PI_4), 0.5 * sin(v + M_PI_4));
		printf("0 %.10lf %.10lf\n", 0.5 * cos(v - M_PI_4), 0.5 * sin(v - M_PI_4));
	}

	return 0;
}

