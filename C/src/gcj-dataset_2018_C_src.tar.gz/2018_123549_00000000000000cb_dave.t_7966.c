#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>

int damage(char *P, int plen) {
  int curD = 0;
  int c = 0;
  for (int p = 0; p < plen; ++p) {
    if (P[p] == 'S') {
      curD = curD + (1 << c);
    } else {
      ++c;
    }
  }
  return curD;
}

int main(void) {

  int t, T;
  int D;
  int p;
  char P[31];
  scanf("%d",&T);

  for (t=1; t <= T; t++) {
    printf("Case #%d: ", t);
    scanf("%d", &D);
    scanf("%s", P);
    int plen = strlen(P);
    int nums = 0;
    for (p = 0; p < plen; ++p) {
      if (P[p] == 'S') nums++;
    }
    if (nums > D) {
      printf("IMPOSSIBLE\n");
      continue;
    }
    int curD = damage(P, plen);
    //printf("initial: %d, %d\n", curD, D); 
    int swaps = 0;
    while (curD > D) {
      //printf("%d, %d\n", curD, D);      
      p = plen - 1;
      while (P[p] == 'C') {
        --p;
      }
      while (P[p - 1] == 'S') {
        --p;
      }
      P[p - 1] = 'S';
      P[p] = 'C';
      swaps++;
      curD = damage(P, plen);
    }  
    printf("%d\n", swaps);
  }
}
