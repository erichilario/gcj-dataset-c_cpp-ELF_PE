#include <stdio.h>
int main()
{
    int x,y,xx,yy,a[100][10],i,j,k,area,t;
    scanf("%d",&t);
    while(t>0)
    {
        t--;
        scanf("%d",&area);
        xx=-1;
        yy=-1;
        x=2;
        y=2;
        for(i=0;i<90;i++)
            for(j=0;j<5;j++)
            a[i][j]=0;
        while(xx!=0 && yy!=0)
        {
            printf("%d %d\n",x,y);
            fflush(stdout);
            scanf("%d %d",&xx,&yy);
            a[xx][yy]=1;
            if(a[x][y]==1 &&a[x-1][y-1]==1 && a[x][y-1]==1 && a[x+1][y-1]==1 && a[x-1][y]==1 && a[x+1][y]==1 && a[x-1][y+1]==1 && a[x][y+1]==1 && a[x+1][y+1]==1)
            {
                x=x+3;
            }
        }
    }
    return 0;
}
