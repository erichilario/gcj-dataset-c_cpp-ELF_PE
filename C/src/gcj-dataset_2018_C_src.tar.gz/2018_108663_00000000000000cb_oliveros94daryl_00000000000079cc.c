#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define PI 3.14159265

int main(){


	int T = 0;
	double A = 0;
	double angle = 0;

	scanf("%d", &T);

	for(int t=1; t<=T; t++){

		//read
		scanf("%lf", &A);
	
		for(double alfa=0 ; alfa <= PI/2 ; alfa = alfa + (PI/180000)){
			double area = cos((PI/4) - alfa)*sqrt(2);
			//printf("%lf : %lf\n",alfa, area);
			if( (A-0.0000001) < area && (area < (A+0.0000001))){
				angle = alfa;
				break;
			}
		}

		printf("Case #%d:\n",t);
		printf("%.7lf %.7lf 0\n", cos(angle)/2,-sin(angle)/2);
		printf("%.7lf %.7lf 0\n", sin(angle)/2,cos(angle)/2);
		printf("0 0 0.5\n");

	} //T

	
	return 0;
}







