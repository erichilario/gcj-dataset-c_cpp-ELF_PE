#include <stdio.h>
#include <stdlib.h>

int main(int argc,char *argv[])
        {
        unsigned int num_tests,t;
        unsigned int size;
        unsigned long long num,last_num;
        int ok,i;

        scanf("%d\n",&num_tests);
        for(t=0;t<num_tests;t++)
                {
                if(scanf(" %d",&size)==1)
                        {
                        ok=-1;
                        for(i=0;i<size;i++)
                                {
                                scanf(" %ld",&num)
                                if((ok==-1)&&(i>0))
                                        {
                                        if(num<last_num)
                                                {
                                                ok=i-1;
                                                }
                                        }
                                last_num=num;
                                }
                        if((size>4)&&(ok!=-1))
                                {
                                ok=-1;
                                }

                        if(ok<0)
                                {
                                printf("Case #%d: OK\n",t+1);
                                }
                        else
                                {
                                printf("Case #%d: %d\n",t+1,ok);
                                }
                        }
                }
        }

