#include <stdio.h>
#include <stdlib.h>

int cmpfunc(const void *a, const void *b) {
  return (*(int *)a - *(int *)b);
}

int solve(size_t n, int *v) {
  size_t k_odd = n / 2;
  size_t k_even;
  if (n % 2 == 0) {
    k_even = n / 2;
  } else {
    k_even = (n / 2) + 1;
  }

  int v_even[k_even];
  int v_odd[k_odd];

  size_t i_even = 0; size_t i_odd = 0;
  for (size_t i = 0; i < n; i++) {
    if (i % 2 == 0) {
      v_even[i_even] = v[i];
      i_even++;
    } else {
      if (i_odd < k_odd) {
        v_odd[i_odd] = v[i];
        i_odd++;
      }
    }
  }

  qsort(v_even, k_even, sizeof(int), cmpfunc);
  qsort(v_odd, k_odd, sizeof(int), cmpfunc);

  i_even = 0; i_odd = 0;
  for (size_t i = 0; i < n; i++) {
    if (i % 2 == 0) {
      v[i] = v_even[i_even];
      i_even++;
    } else {
      if (i_odd < k_odd) {
        v[i] = v_odd[i_odd];
        i_odd++;
      }
    }
  }

  for (size_t i = 0; i < n - 1; i++) {
    if (v[i] > v[i+1]) return i;
  }
  return -1;
}

int main() {
  int t;
  scanf("%d", &t);
  for (int i = 0; i < t; i++) {
    size_t n;
    int v[n];
    scanf("%zd", &n);
    for(int j = 0; j<n; j++) {
      scanf("%d", &v[j]);
    }

    int result = solve(n, v);
    if (result == -1) {
      printf("Case #%d: OK\n", i + 1);
    } else {
      printf("Case #%d: %d\n", i + 1, result);
    }
  }
}

