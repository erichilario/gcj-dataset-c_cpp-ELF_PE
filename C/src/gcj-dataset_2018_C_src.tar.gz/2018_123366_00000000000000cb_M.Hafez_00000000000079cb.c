#include <stdio.h>

int main() {
  int t, tc = 0;
  int n, i;
  int arr[100010];
  scanf("%d", &t);
  while(t--) {
    scanf("%d", &n);
    for(i = 0; i < n; ++i) {
      scanf("%d", &arr[i]);
    }
    if(arr[1] < arr[0] && arr[1] < arr[2]) {
      printf("Case #%d: 1\n", ++tc);
    }
    else if(arr[n-2] > arr[n-1] && arr[n-2] > arr[n-3]) {
      printf("Case #%d: %d\n", ++tc, n-2);
    }
    else {
      printf("Case #1: OK\n");
    }
  }
  return 0;
}

