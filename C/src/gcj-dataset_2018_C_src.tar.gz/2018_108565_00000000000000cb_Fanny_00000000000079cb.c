

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>



#define N 100000 + 10
int nums[N];

void my_sort(int *nums, int start, int end) {
    if (start >= end) {
        return ;
    }
    int i = start, j = end;
    int key = nums[start];
    while(i < j) {
        while(i < j && nums[j] >= key) {
            j -= 2;
        }
        nums[i] = nums[j];
        while(i < j && nums[i] <= key) {
            i += 2;
        }
        nums[j] = nums[i];
    }
    nums[i] = key;
    my_sort(nums, start, i - 2);
    my_sort(nums, i + 2, end);
}


int main(int argc, const char * argv[]) {
    
    
    
    if (freopen("test.txt","r",stdin) == NULL) {
        printf("error...");
    }
    
//    test();
    
    int t;
    scanf("%d", &t);
    for (int i = 0; i < t; i++) {
        int n;
        scanf("%d", &n);
        for (int j = 0; j < n; j++) {
            scanf("%d", &(nums[j]));
        }
        
        my_sort(nums, 0, n - 1 - (n % 2 ? 0 : 1));
        my_sort(nums, 1, n - 1 - (n % 2 ? 1 : 0));
        
        int k = 0;
        for (k = 0; k < n - 1; k++) {
            if (nums[k] > nums[k + 1]) {
                break;
            }
        }
        
        if (k == n - 1) {
            printf("Case #%d: OK\n", i + 1);
        } else {
            printf("Case #%d: %d\n", i + 1, k);
        }
    }
    
   
    return 0;
}

