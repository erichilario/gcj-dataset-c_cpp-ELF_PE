#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define true 1
#define false 0

typedef unsigned char bool;

char buf[12 * 200000];

int compare (const void * a, const void * b)
{
    return ( *(int*)a - *(int*)b );
}

int parse_buf(int *vet)
{
    int i, k, size = strlen(buf);

    for( ; size > 0 && (buf[size-1] < '0' || buf[size-1] > '9'); size--) ;

    for(i = 0, k = 0; i < size; i++, k++)
    {
        vet[k] = 0;
        while(i < size && (buf[i] < '0' || buf[i] > '9'))
            i++;

        while(i < size && buf[i] >= '0' && buf[i] <= '9')
        {
            vet[k] *= 10;
            vet[k] += buf[i] - '0';
            i++;
        }

        /*printf("%d %d\n", k, vet[k]);*/
    }

    return k;
}

int main()
{
    int T, cont = 0;
    
    scanf("%d\n", &T);
    
    while(T--)
    {
        int N, N_even = 0, N_odd = 0;
        int vet[200000], vet_even[200000], vet_odd[200000];
        int i;
        
        scanf("%d\n", &N);
        
        memset(buf, 0, sizeof(buf));
        fgets(buf, sizeof(buf)-1, stdin);
        
        if(parse_buf(vet) != N)
            N = 1/0;
        
        for(i = 0; i < N; i++)
            if(i & 1)
                vet_odd[N_odd++] = vet[i];
            else
                vet_even[N_even++] = vet[i];
            
        qsort(vet_odd, N_odd, sizeof(int), compare);
        qsort(vet_even, N_even, sizeof(int), compare);
        
        for(i = 0, N_odd = 0, N_even = 0; i < N; i++)
            if(i & 1)
                vet[i] = vet_odd[N_odd++];
            else
                vet[i] = vet_even[N_even++];
            
        /*for(i = 0; i < N; i++)
            printf("%d ", vet[i]);
        printf("\n");*/

        for(i = 0; i < N-1; i++)
            if(vet[i] > vet[i+1])
                break ;
            
        if(i == N-1)
            printf("Case #%d: OK\n", ++cont);
        else
            printf("Case #%d: %d\n", ++cont, i);
    }
    
    
    return 0;
}

