//set many funcs template
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#include<time.h>
#define inf 1072114514
#define llinf 4154118101919364364
#define mod 1000000007
#define pi 3.1415926535897932384

int max(int a,int b){if(a>b){return a;}return b;}
int min(int a,int b){if(a<b){return a;}return b;}
int zt(int a,int b){return max(a,b)-min(a,b);}
int round(int a,int b){if((a%b)*2 >= b){return (a/b)+1;}return a/b;}
int ceil(int a,int b){if(a%b==0){return a/b;}return (a/b)+1;}
int gcd(int a,int b){int c;while(b!=0){c=a%b;a=b;b=c;}return a;}
int lcm(int a,int b){int c=gcd(a,b);a/=c;return a*b;}
int nCr(int a,int b){int i,r=1;for(i=1;i<=b;i++){r*=(a+1-i);r/=i;}return r;}
int nHr(int a,int b){return nCr(a+b-1,b);}
int fact(int a){int i,r=1;for(i=1;i<=a;i++){r*=i;}return r;}
int pow(int a,int b){int i,r=1;for(i=1;i<=b;i++){r*=a;}return r;}
long long llmax(long long a,long long b){if(a>b){return a;}return b;}
long long llmin(long long a,long long b){if(a<b){return a;}return b;}
long long llzt(long long a,long long b){return llmax(a,b)-llmin(a,b);}
long long llround(long long a,long long b){if((a%b)*2 >= b){return (a/b)+1;}return a/b;}
long long llceil(long long a,long long b){if(a%b==0){return a/b;}return (a/b)+1;}
long long llgcd(long long a,long long b){long long c;while(b!=0){c=a%b;a=b;b=c;}return a;}
long long lllcm(long long a,long long b){long long c=llgcd(a,b);a/=c;return a*b;}
long long llnCr(long long a,long long b){long long i,r=1;for(i=1;i<=b;i++){r*=(a+1-i);r/=i;}return r;}
long long llnHr(long long a,long long b){return llnCr(a+b-1,b);}
long long llfact(long long a){long long i,r=1;for(i=1;i<=a;i++){r*=i;}return r;}
long long llpow(long long a,long long b){long long i,r=1;for(i=1;i<=b;i++){r*=a;}return r;}
double dbmax(double a,double b){if(a>b){return a;}return b;}
double dbmin(double a,double b){if(a<b){return a;}return b;}
double dbzt(double a,double b){return dbmax(a,b)-dbmin(a,b);}
int sortfncsj(const void *a,const void *b){if(*(int *)a>*(int *)b){return 1;}if(*(int *)a==*(int *)b){return 0;}return -1;}
int sortfnckj(const void *a,const void *b){if(*(int *)a<*(int *)b){return 1;}if(*(int *)a==*(int *)b){return 0;}return -1;}
int llsortfncsj(const void *a,const void *b){if(*(long long *)a>*(long long *)b){return 1;}if(*(long long *)a==*(long long *)b){return 0;}return -1;}
int llsortfnckj(const void *a,const void *b){if(*(long long *)a<*(long long *)b){return 1;}if(*(long long *)a==*(long long *)b){return 0;}return -1;}
int dbsortfncsj(const void *a,const void *b){if(*(double *)a>*(double *)b){return 1;}if(*(double *)a==*(double *)b){return 0;}return -1;}
int dbsortfnckj(const void *a,const void *b){if(*(double *)a<*(double *)b){return 1;}if(*(double *)a==*(double *)b){return 0;}return -1;}
int strsortfncsj(const void *a,const void *b){return strcmp((char *)a,(char *)b);}
int strsortfnckj(const void *a,const void *b){return strcmp((char *)b,(char *)a);}

int a[128][128],n,res;
void rep(int pd,int cc,bool fl[128][128]){
    int i,j,x,y,f=0,d[256]={0};
    bool nfl[128][128];
    //printf("<%d %d %d>\n",pd,cc,n*n);
    if(pd==n*n){
        for(i=0;i<n;i++){
            for(j=0;j<n;j++){if(fl[i][j]==0){d[a[i][j]]++;if(d[a[i][j]]>1){return;}}}
            for(j=0;j<n;j++){if(fl[i][j]==0){d[a[i][j]]--;}}
        }
        for(j=0;j<n;j++){
            for(i=0;i<n;i++){if(fl[i][j]==0){d[a[i][j]]++;if(d[a[i][j]]>1){return;}}}
            for(i=0;i<n;i++){if(fl[i][j]==0){d[a[i][j]]--;}}
        }
        res=min(res,cc);return;
    }
    x=pd/n;y=pd%n;
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){nfl[i][j]=fl[i][j];}
    }
    for(i=0;i<n;i++){
        if(fl[x][i]==1 || i==y){continue;}
        if(a[x][i]==a[x][y]){f=1;}
    }
    for(i=0;i<n;i++){
        if(fl[i][y]==1 || i==x){continue;}
        if(a[i][y]==a[x][y]){f=1;}
    }
    rep(pd+1,cc,nfl);
    if(f){
        nfl[x][y]=1;
        rep(pd+1,cc+1,nfl);
    }
}

int main(void){
    int i,j,m,k,b,c,w,r=0,l,t;
    double d;
    char s[262144];
    bool st[128][128]={0};
    scanf("%d",&t);
    //l=strlen(s);
    for(i=1;i<=t;i++){
        scanf("%d",&n);res=inf;
        for(j=0;j<n;j++){
            for(k=0;k<n;k++){scanf("%d",&a[j][k]);a[j][k]+=n;}
        }
        rep(0,0,st);
        printf("Case #%d: %d\n",i,res);
    }
    //qsort(a,n,sizeof(int),sortfncsj);
    //printf("%d\n",r);
    return 0;
}
