#include<stdio.h>
#include<stdlib.h>
#include<strings.h>

void triple_sort(long int a[],long int b[],int n)
{   
	int p;
	for(int i=0;i<n;i++) b[i]=a[i];

	for(int i=0;i<n-2;i++)
	{
		if(a[i]>a[i+2])
		{
			int p=a[i];
			a[i]=a[i+2];
			a[i+2]=p;
		}
	}
	
	

	for(int i=0;i<n;i++)
	{
		if(a[i]==b[i]) p=1;
		else {p=0; break;}
	}


	if(p==0) triple_sort(a,b,n);
	else return;
		
}

int compare_function(const void *a,const void *b) {
int *x = (int *) a;
int *y = (int *) b;
return *x - *y;
}


int main()
{
	int t,n,j,pointer=0,flag=0;
	
	scanf("%d",&t);
	for(int i=0;i<t;i++)
	{
        scanf("%d\n",&n);
        long int a[n],b[n];
        long  int c[n];
        for(int q=0;q<n;q++)
        {
        	scanf("%ld",&a[q]);
        }
    for(int i=0;i<n;++i)
    {
        c[i]=a[i];
    }

        triple_sort(a,b,n);
        qsort(c,n,sizeof(long int),compare_function);
        for(j=0;j<n;j++)
        {
        	if(c[j]==b[j]) continue;
        	else {flag=1;pointer=i;break;}
        }
        
        if(flag==0) printf("Case #%d: OK\n",pointer+1);
        else printf("Case #%d: %d\n",pointer+1,j);

	}

}
