using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProblemTroubleSort {
    class Program {
        static void Main(string[] args) {
            int T;
            int N;
            int[] V;
            int j;
            bool done;
            int temp;

            T = int.Parse(Console.ReadLine());
            for (int t = 0; t < T; t++) {
                N = int.Parse(Console.ReadLine());
                V = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

                done = false;
                while (!done) {
                    done = true;
                    for (int i = 0; i < V.Length - 2; i++) {
                        if (V[i] > V[i + 2]) {
                            done = false;
                            temp = V[i];
                            V[i] = V[i + 2];
                            V[i + 2] = temp;
                        }
                    }
                }

                done = true;
                for (j=0; j < V.Length - 1; j++) {
                    if(V[j] > V[j + 1]) {
                        done = false;
                        break;
                    }
                }

                if (done)
                    Console.WriteLine("Case #{0}: {1}", t + 1, "OK");
                else
                    Console.WriteLine("Case #{0}: {1}", t + 1, j);
            }
        }
    }
}

