#include <stdio.h>

char ans[101];

int main(void) {
  int t, c, b[100];
  scanf("%d", &t);
  for (int it = 1; it <= t; ++it) {
    scanf("%d", &c);
    int zum = 0;
    for (int i = 0; i < c; ++i) {
      scanf("%d", &b[i]);
      zum += b[i];
    }
    printf("Case #%d: ", it);
    if (b[0] == 0 || b[c - 1] == 0 || zum != c) {
      printf("IMPOSSIBLE\n");
    } else {
      int impossible = 0;
      int lef = 0;
      int reqdepth = 0;
      for (int i = 0; i < c; ++i) {
        int rig = lef + b[i];
        if (lef < rig && i < lef) {
          impossible = 1;
          break;
        } else if (lef < rig) {
          int depth = 0;
          while (lef < i) {
            ans[lef++] = '\\';
            ++depth;
          }
          if (reqdepth < depth) reqdepth = depth;
          ans[lef++] = '.';
          depth = 0;
          while (lef < rig) {
            ans[lef++] = '/';
            ++depth;
          }
          if (reqdepth < depth) reqdepth = depth;
        }
      }
      if (impossible || lef != c) {
        printf("IMPOSSIBLE\n");
      } else {
        printf("%d\n", reqdepth + 1);
        ans[c] = 0;
        for (int i = 0; i < reqdepth; ++i) {
          puts(ans);
        }
        for (int i = 0; i < c; ++i) {
          printf(".");
        }
        printf("\n");
      }
    }
  }
  return 0;
}

