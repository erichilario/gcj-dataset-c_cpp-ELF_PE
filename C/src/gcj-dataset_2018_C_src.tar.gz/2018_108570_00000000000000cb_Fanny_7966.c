
#include <stdio.h>
#include <string.h>

#define s_len 10000

int main(int argc, const char * argv[]) {
    int t;
    scanf("%d", &t);
    for (int i = 0; i < t; i++) {
        long long d;
        scanf("%lld", &d);
        char s[s_len];
        scanf("%s", s);
        long long d_total = 0;
        long long c_value = 1;
        for (int j = 0; j < strlen(s); j++) {
            if (s[j] == 'S') {
                d_total += c_value;
            } else {
                c_value *= 2;
            }
        }
        
        printf("%d %d\n", d_total, c_value);
        if (d_total <= d) {
            printf("Case #%d: 0\n", i + 1);
            break;
        }
        if (d_total > d && c_value == 1) {
            printf("Case #%d: IMPOSSIBLE\n", i + 1);
            break;
        }
        
        int top = 0;
        
        long long j = strlen(s) - 1;
        long long res_count = 0;
        while (j >= 0) {
            if (s[j] == 'C' && top == 0) {
                j--;
                c_value /= 2;
            } else if (s[j] == 'C' && top != 0) {
                int flag = 0;
                for (int k = 0; k < top; k++) {
                    s[j++] = 'S';
                    d_total -= (c_value - c_value / 2);
                    res_count++;
                    if (d_total <= d) {
                        flag = 1;
                        break;
                    }
                }
                if (flag) {
                    break;
                }
                c_value /= 2;
                j--;
            } else {
                while (s[j] == 'S') {
                    top++;
                    j--;
                }
            }
        }
        if (j < 0) {
            printf("Case #%d: IMPOSSIBLE\n", i + 1);
        } else {
            printf("Case #%d: %lld\n", i + 1, res_count);
        }
    }
    return 0;
}

