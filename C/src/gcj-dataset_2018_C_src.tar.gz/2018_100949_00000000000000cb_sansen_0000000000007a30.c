#include<stdio.h>
#include<stdlib.h>
#include<math.h>

typedef long long int int64;

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define ABS(a,b) ((a)>(0)?(a):-(a))

#define POS(i,j) (((i)-1)*w+(j)-1)

int calc(int *board,int w,int h,int *x,int *y){
  int max=0;
  int i,j;
  for(i=2;i<=w-1;i++){
    for(j=2;j<=h-1;j++){
      int cnt=0;
      int a,b;
      for(a=i-1;a<=i+1;a++){
	for(b=j-1;b<=j+1;b++){
	  if(board[POS(a,b)]==0) cnt++;
	}
      }
      if(max<cnt){
	max=cnt;
	*x=i;
	*y=j;
      }
    }
  }
  return max>0;
}

void func(int w,int h){
  int *board=(int *)calloc(w*h,sizeof(int));
  int x,y;
  while(calc(board,w,h,&x,&y)){
    printf("%d %d\n",x,y);
    fflush(stdout);
    scanf("%d%d",&x,&y);
    board[POS(x,y)]=1;
  }
  free(board);
}

void run(void){
  int t;
  scanf("%d",&t);
  int iter;
  for(iter=1;iter<=t;iter++){
    int a;
    scanf("%d",&a);
    if(a==20) func(4,5);
    else func(10,20);
  }
}

int main(void){
  run();
  return 0;
}

