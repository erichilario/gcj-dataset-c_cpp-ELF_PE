#include<stdio.h>
#include<string.h>
#define lli long long int
int t,a,i,j,x,y,ar[1001][1001],n,k,fl;
main()
{
	scanf("%d",&t);
       	while(t--)
       	{
		scanf("%d",&a);
		x=2;
		y=2;
		fl=0;
		for(n=0;n<1000;n++)
		{
			if(fl==0 || x<=y)
			{
				printf("2 %d\n",x);
      				fflush(stdout);
				ar[2][x]=1;
			}	
			else
			{
				printf("2 %d\n",y);
      				fflush(stdout);
				ar[2][y]=1;
			}
			scanf("%d%d",&i,&j);
			if(i==3 && fl==0)
			fl=1;
			if(i==0 && j==0)
			break;
			if(i==-1 && j==-1)
			break;
			ar[i][j]=1;
			for(k=2;k<=998;k++)
			{
				if(ar[3][k]==0)
				{
					y=k;
					break;
				}
			}
			for(k=2;k<=998;k++)
			{
				if(ar[2][k]==0)
				{
					x=k;
					break;
				}
			}
		}
		if(i==-1 && j==-1)
			break;
		memset(ar, 0, sizeof(ar));
       	}
}

