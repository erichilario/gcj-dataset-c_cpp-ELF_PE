#include<stdio.h>
#include<stdlib.h>
#include<math.h>

typedef long long int int64;

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define ABS(a,b) ((a)>(0)?(a):-(a))

double func(double theta){
  const double s2=sqrt(2);
  return s2*cos(M_PI/4-theta);
}

void run(void){
  int t;
  scanf("%d",&t);
  int iter;
  for(iter=1;iter<=t;iter++){
    double a;
    scanf("%lf",&a);
    double l=0;
    double r=M_PI/4;
    int k;
    for(k=0;k<100;k++){
      double m=(l+r)/2;
      if(func(m)>=a){
	r=m;
      } else {
	l=m;
      }
    }
    printf("Case #%d:\n",iter);
    printf("%.9lf %.9lf 0\n",0.5*cos(l),0.5*sin(l));
    printf("%.9lf %.9lf 0\n",-0.5*sin(l),0.5*cos(l));
    printf("0 0 0.5\n");
  }
}

int main(void){
  run();
  return 0;
}

