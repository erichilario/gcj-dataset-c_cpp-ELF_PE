#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char status;
    int farmedSur;
} farm;

int mapReset(farm map[13][23]) {
    int i, j;
    for(i = 1; i < 13; i++) {
        for(j = 1; j < 23; j++) {
            map[i][j].status = 'O';
            map[i][j].farmedSur = 0;
        }
    }
    return 0;
}

int addSur(farm map[13][23], int inR, int inC) {
    map[inR - 1][inC - 1].farmedSur += 1;
    map[inR - 1][inC].farmedSur += 1;
    map[inR - 1][inC + 1].farmedSur += 1;
    map[inR][inC - 1].farmedSur += 1;
    map[inR][inC + 1].farmedSur += 1;
    map[inR + 1][inC - 1].farmedSur += 1;
    map[inR + 1][inC].farmedSur += 1;
    map[inR + 1][inC + 1].farmedSur += 1;
    return 0;
}

int receiveIn(farm map[13][23]) {
    int inR, inC;
    scanf("%d %d", &inR, &inC);
    if(inR > 0 && inC > 0) {
        map[inR][inC].status = '#';
        addSur(map, inR, inC);
    }
    else {
        exit(0);
    }
    return 0;
}

int interact(farm map[13][23], int target, int A) {
    int done = 0;
    int i, j;
    if(A == 20) {
        while(done == 0) {
            done = 1;
            for(i = 3; i < 5; i++) {
                for(j = 3; j < 6; j++) {
                    if(map[i][j].farmedSur == target) {
                        done = 0;
                        printf("%d %d", i, j);
                        fflush(stdout);
                        receiveIn(map);
                    }
                }
            }
        }
    }
    else if(A == 200) {
        while(done == 0) {
            done = 1;
            for(i = 3; i < 11; i++) {
                for(j = 3; j < 21; j++) {
                    if(map[i][j].farmedSur == target) {
                        done = 0;
                        printf("%d %d", i, j);
                        fflush(stdout);
                        receiveIn(map);
                    }
                }
            }
        }
    }
    return 0;
}
int main() {
    int T = 0;
    int A = 0;
    int i = 0, j = 0;
    int inR = 0, inC = 0;
    int outR = 0, outC = 0;
    farm map[13][23];
    for(i = 0; i < 13; i++) {
        map[i][0].status = 'X';
    }
    for(i = 0; i < 23; i++) {
        map[0][i].status = 'X';
    }
    scanf("%d", &T);
    for(i = 0; i < T; i++) {
        scanf("%d", &A);
        mapReset(map);
        for(j = 0; j < 8; j++) {
            interact(map, j, A);
        }
    }
}

