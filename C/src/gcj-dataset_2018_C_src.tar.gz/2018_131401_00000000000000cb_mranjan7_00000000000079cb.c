#include <stdio.h>

int main(void)
{
	void TroubleSort(int L[],int l);
	int T;
	scanf("%d",&T);
	for(int i = 0;i < T;i++)
	{
		int N;
		scanf("%d",&N);
		int V[N];
		for(int j = 0;j < N;j++)
		{
			scanf("%d",&V[j]);
		}
		TroubleSort(V,N);
		int isOK = 1;
		int index = - 1;
		for(int j = 0;j < N-1;j++)
		{
			if(V[j]>V[j+1])
			{
				isOK = 0;
				index = j;
				break;
			}
		}
		if(isOK)
		{
			printf("Case #%d: OK\n",(i+1));	
		}
		else
		{
			printf("Case #%d: %d\n",(i+1),index);
		}
	}
}
void TroubleSort(int L[],int l)
{
	int done = 0;
	while(!done)
	{
		done = 1;
		for(int i = 0;i < l-2;i++)
		{
			if(L[i] > L[i+2])
			{
				done = 0;
				int temp = L[i];
				L[i] = L[i+2];
				L[i+2] = temp;
			}
		}
	}
}


