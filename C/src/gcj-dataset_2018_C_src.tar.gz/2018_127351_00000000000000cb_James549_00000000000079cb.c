/*
 * Google Code Jam Qualification Round 2018 Problem B
 * "Trouble Sort"
 * Written by James Tai
 */

#if 1

/*
 * Analysis:
 * I have no clue.
 */

#include <stdlib.h>
#include <stdio.h>

// Dedicated integer reader

#define buffer_size 1048576 // 1 MiB

char buffer[buffer_size];
char *maxChar = buffer;
char *curChar = buffer;

static inline char next_char() {
    if (curChar == maxChar) {
        // Refill buffer
        size_t read = fread(buffer, 1, buffer_size, stdin);
        maxChar = buffer + read;
        curChar = buffer;
    }
    return *curChar++;
}

int next_int() {
    char c;
    do {
        c = next_char();
    } while ((c < '0' || c > '9') && (c != '-'));
    // Get sign
    int sign = 1;
    if (c == '-') {
        sign = -1;
        c = next_char();
    }
    // Compute number
    int num = 0;
    do {
        num = (num * 10) + (c - '0');
        c = next_char();
    } while (c >= '0' && c <= '9');
    // Return number
    return num * sign;
}

// Code

static inline void trouble_sort(int size, int *array) {
    size -= 2;
    register int done, tmp, i, ip2;
    do {
        done = 1;
        for (i = 0; i < size; i++) {
            ip2 = i + 2;
            if (array[i] > array[ip2]) {
                done = 0;
                tmp = array[i];
                array[i] = array[ip2];
                array[ip2] = tmp;
            }
        }
    } while (!done);
}

int main(void) {
    int num_cases = next_int();
    for (int case_num = 1; case_num <= num_cases; case_num++) {
        printf("Case #%d: ", case_num);
        int size = next_int();
        int *array = malloc(sizeof(int) * size);
        for (int i = 0; i < size; i++) {
            array[i] = next_int();
        }
        // Process array
        trouble_sort(size, array);
        for (int i = 0; i < size - 1; i++) {
            if (array[i] > array[i + 1]) {
                printf("%d\n", i);
                goto nextCase;
            }
        }
        printf("OK\n");
        nextCase:;
    }
}

#endif

