#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


int main(){


	int T = 0;
	unsigned long nonesize = 0;
	unsigned long pairsize = 0;
	unsigned long size = 0;

	scanf("%d", &T);

	for(int t=1; t<=T; t++){

		scanf("%lu", &size);
		unsigned long numbers[size];
		unsigned long result = 0;

		//read
		for(int i=0; i<size; i++)
				scanf("%lu", &numbers[i]);
		
		//Sort
		int finished = 0;
		while(finished == 0){
			finished = 1;
			for(int i=0; i < size - 2; i++)
				if(numbers[i] > numbers[i+2]){
					finished = 0;
					unsigned long aux = numbers[i];
					numbers[i] = numbers[i+2];
					numbers[i+2] = aux;
				}
		}

		//Check if wrong
		for(int i=0; i<size-1; i++)
			if(numbers[i] > numbers[i+1]){
				result = i;
				break;
			}
		
		if(result == 0)
			printf("Case #%d: OK",t);
		else printf("Case #%d: %lu",t,result);
		printf("\n");


	} //T

	
	return 0;
}





