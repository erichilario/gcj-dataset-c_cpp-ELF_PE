#include <stdio.h>
#include <algorithm>
using namespace std;

int odd[100001];
int even[100001];
int ans[100001];
int n,t;

bool compare(int &a, int &b) {
  return a >= b;
}

int main(void)
{
  int i,j,k,c;

  scanf("%d", &t);

  for (c=1; c<=t; c++) {
    scanf("%d", &n);
    for (i=0; i<n; i++) {
      if (i%2) {
        scanf("%d",&odd[i/2]);
      }
      else {
        scanf("%d",&even[i/2]);
      }
    }

    sort(odd, odd+n/2, compare);
    sort(even, even+n/2+n%2, compare);

    for (i=0; i<n; i++) {
      if (i%2) {
        ans[i] = odd[i/2];
      }
      else {
        ans[i] = even[i/2];
      }
    }

    for (i=1; i<n; i++) {
      if (ans[i] > ans[i-1]) {
        break;
      }
    }

    printf("Case #%d: ", c);

    if (i==n)
      printf("OK\n");
    else
      printf("%d\n", i);
  }
}

