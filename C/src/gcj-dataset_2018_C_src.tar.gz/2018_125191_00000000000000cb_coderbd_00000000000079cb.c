#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define N 100005

int a[N], b[N];

int compare(const void* x, const void* y) {
    return ( *(int*)x - *(int*)y );
}

void trouble_sort(int a[], int n) {
    int i, t, done = 0;
    
    while (!done) {
        done = 1;
        for (i = 0; i < n-2; i++)
            if (a[i] > a[i+2]) {
                done = 0;
                t = a[i];
                a[i] = a[i+2];
                a[i+2] = t;
            }
    }
}

void print_answer(int case_no, int ans) {
    if (ans == -1)
        printf("Case #%d: OK\n", case_no);
    else
        printf("Case #%d: %d\n", case_no, ans);
}

void print_array(int a[], int n) {
    int i;
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    putchar('\n');
}

void solve(int case_no) {
    int i, n, ans = -1;
    
    scanf("%d", &n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    
    memcpy(b, a, sizeof(int) * n);
    trouble_sort(a, n);
    qsort(b, n, sizeof(int), compare);
    
    for (i = 0; i < n; i++)
        if (a[i] != b[i]) {
            ans = i;
            break;
        }
    
    print_array(a, n);
    print_array(b, n);
    
    print_answer(case_no, ans);
}

int main(int argc, char* argv[]) {
    int i, t;
    
    scanf("%d", &t);
    for (i = 1; i <= t; i++)
        solve(i);
    
    return 0;
}

