
#include <bits/stdc++.h>
using namespace std;

long long damage(string S)
{
    long long D = 0, C = 1;
    for (char ch : S)
        if (ch == 'C') C *= 2;
        else D += C;
    return D;
}

int solve(long long D, string S)
{
    unordered_set<string> visited;
    visited.insert(S);
    vector<string> check(1, S);
    int step = 0;
    while (check.size()) {
        vector<string> next;
        for (string s : check) {
            auto d = damage(s);
            if (d <= D)
                return step;
            char buf[31];
            for (int i = 1; i < (int)s.size(); i++) {
                strcpy(buf, s.c_str());
                char c0 = s[i - 1], c1 = s[i];
                buf[i - 1] = c1, buf[i] = c0;
                string test(buf);
                if (!visited.count(test))
                    next.push_back(test);
            }
        }
        check = next;
        step++;
    }
    return -1;
}

int main()
{
    int T;
    long long D;
    string S;
    cin >> T;
    for (int t = 0; t < T; t++) {
        cin >> D >> S;
        int res = solve(D, S);
        if (res >= 0)
            cout << res << endl;
        else
            cout << "IMPOSSIBLE" << endl;
    }
    return 0;
}

