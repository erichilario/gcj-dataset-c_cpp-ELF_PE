#include <stdio.h>

int dp[505][505];

int max(int a, int b){ return a > b ? a : b; }

int main(){
    int T;
    scanf("%d", &T);
    
    int R = 500, B = 500;
    for(int i=0; i<=R; i++){
        for(int j=i; j<=B; j++){
            if(i == 0 && j == 0) continue;
            // this juggler is going to have i reds and j blues
            for(int a=R; a>=i; a--){
                for(int b=B; b>=j; b--){
                    dp[a][b] = max(dp[a][b], dp[a-i][b-j]+1);
                }
            }
            // this juggler is going to have j reds and i blues (i != j)
            if(i == j) continue;
            for(int a=R; a>=j; a--){
                for(int b=B; b>=i; b--){
                    dp[a][b] = max(dp[a][b], dp[a-j][b-i]+1);
                }
            }
        }
    }
    
    for(int tc=0; tc<T; tc++){
        int R, B;
        scanf("%d%d", &R, &B);
        if(R > B){
            int tmp = R;
            R = B;
            B = tmp;
        }
        printf("Case #%d: %d\n", tc+1, dp[R][B]);
    }
    return 0;
}

