#include <stdio.h>

int v[10000];
int n;

void solve() {
	int i,done=0,t;
	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("%d",&v[i]);
	while(!done) {
		done=1;
		for(i=0;i<n-2;i++) {
			if(v[i]>v[i+2]) {
				t=v[i];
				v[i]=v[i+2];
				v[i+2]=t;
				done=0;
			}
		}
	}
	for(i=0;i<n-1;i++) if(v[i]>v[i+1]) {
		printf("%d\n",i);
		return;
	}
	puts("OK");
}

int main() {
	int cases,caseno=1;
	scanf("%d",&cases);
	while(cases--) {
		printf("Case #%d: ",caseno++);
		solve();
	}
	return 0;
}

