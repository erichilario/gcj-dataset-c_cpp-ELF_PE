
#include <stdio.h>

int prog[35];
int proglen;
int D;
int shoot_count;
int damage;

void readstuff(void) {
    char buf[35];
    int i,p2;
    shoot_count=0;
    damage=0;
    scanf("%d %s",&D,buf);
    p2=0;
    for (i=0; buf[i]; i++) {
        if (buf[i]=='C') {p2++; prog[i]=-1;}
        else {
            prog[i]=p2;
            shoot_count++;
            damage+=(1<<p2);
        }
    }
    proglen=i;
}

void save_universe(int case_num) {
    int hacks=0;
    int i;
    printf("Case #%d: ",case_num);
    readstuff();
    if (shoot_count>D) {printf("IMPOSSIBLE\n");return;}
    while (damage>D) {
        for (i=proglen-1;i>0;i--) {
            if (prog[i-1]==-1 && prog[i]>=0) break;
        }
        prog[i-1]=prog[i]-1;
        prog[i]=-1;
        damage-=(1<<prog[i-1]);
        hacks++;
    }
    printf("%d\n",hacks);
}

int main(int argc, char **argv) {
    int i,T;
    scanf("%d", &T);
    for (i=1;i<=T;i++) 
        save_universe(i);
    return 0;
}
