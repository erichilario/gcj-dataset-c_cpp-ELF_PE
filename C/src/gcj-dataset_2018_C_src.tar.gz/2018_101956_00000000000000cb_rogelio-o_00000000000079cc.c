#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define PI 3.14159265

void rotate(double result[8][3], double ship[8][3], double rotationMatrix[3][3]) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 3; j++) {
            result[i][j] = 0;
            for (int k = 0; k < 3; k++) {
                result[i][j] += ship[i][k] * rotationMatrix[k][j];
            }
        }
    }
} 

void rotateZ(double result[8][3], double ship[8][3], double angle) {
    double rotationMatrix[3][3] = {
        {cos(angle), -sin(angle), 0},
        {sin(angle), cos(angle), 0},
        {0, 0, 1}
    };

    rotate(result, ship, rotationMatrix);
}

void rotateX(double result[8][3], double ship[8][3], double angle) {
    double rotationMatrix[3][3] = {
        {1, 0, 0},
        {0, cos(angle), -sin(angle)},
        {0, sin(angle), cos(angle)}
    };

    rotate(result, ship, rotationMatrix);
}

void setFacesOfShip(double faces[3][3], double ship[8][3]) {
    faces[0][0] = (ship[1][0] + ship[4][0]) / 2;
    faces[0][1] = (ship[1][1] + ship[4][1]) / 2;
    faces[0][2] = (ship[1][2] + ship[4][2]) / 2;

    faces[1][0] = (ship[2][0] + ship[1][0]) / 2;
    faces[1][1] = (ship[2][1] + ship[1][1]) / 2;
    faces[1][2] = (ship[2][2] + ship[1][2]) / 2;

    faces[2][0] = (ship[2][0] + ship[4][0]) / 2;
    faces[2][1] = (ship[2][1] + ship[4][1]) / 2;
    faces[2][2] = (ship[2][2] + ship[4][2]) / 2;
}

double calculateRectangleArea(double ship[8][3]) {
    double minX = ship[2][0];
    double maxX = ship[4][0];
    double minZ = ship[0][2];
    double maxZ = ship[1][2];
    
    return fabs((maxX - minX) * (maxZ - minZ));
}

double calculareTriangleArea(double b, double h) {
    return b * h / 2;
}

double calculateHexagonalArea(double ship[8][3]) {
    double area = 1.4142135624;

    area += calculareTriangleArea(fabs(ship[4][0] - ship[2][0]), fabs(ship[4][2] - ship[6][2]));
    area += calculareTriangleArea(fabs(ship[5][0] - ship[3][0]), fabs(ship[1][2] - ship[5][2]));

    return area;
}

int isValidArea(double currentArea, double area) {
    return currentArea > (area - pow(10, -6)) && currentArea < (area + pow(10, -6)) ? 1 : 0;
}

void findRotationForArea(double faces[3][3], double area) {
    double ship[8][3] = {
        {0.5, 0.5, 0.5},
        {0.5, 0.5, -0.5},
        {-0.5, 0.5, 0.5},
        {-0.5, 0.5, -0.5},
        {0.5, -0.5, 0.5},
        {0.5, -0.5, -0.5},
        {-0.5, -0.5, 0.5},
        {-0.5, -0.5, -0.5}
    };

    double currentArea = calculateRectangleArea(ship);
    double currentShip[8][3];
    memcpy(currentShip, ship, sizeof(ship));
    if(area > currentArea) {
        double angle = 45 * PI / 180;

        while(angle <= 45 * PI / 180) {
            rotateZ(currentShip, ship, -angle);
            currentArea = calculateRectangleArea(currentShip);

            if(isValidArea(currentArea, area)) {
                break;
            } else if(currentArea > area) {
                angle -= angle / 2;
            } else {
                angle += angle / 2;
            }
        }

        if(angle > 45 * PI / 180) {
            angle = 45 * PI / 180;
            rotateZ(currentShip, ship, -angle);
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 3; j++) {
                    ship[i][j] = currentShip[i][j];
                }
            }

            while(angle <= 45 * PI / 180) {
                rotateX(currentShip, ship, -angle);
                currentArea = calculateHexagonalArea(currentShip);

                if(isValidArea(currentArea, area)) {
                    break;
                } else if(currentArea > area) {
                    angle -= angle / 2;
                } else {
                    angle += angle / 2;
                }
            }
        }
    }

    setFacesOfShip(faces, currentShip);
}

int main() {
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

    read = getline(&line, &len, stdin);
    int numProblems = atoi(line);

    for (int i = 1; i <= numProblems; ++i) {
        read = getline(&line, &len, stdin);
        double area = atof(line);
        
        double faces[3][3];
        findRotationForArea(faces, area);

        printf("Case #%d:\n", i);
        for(int e = 0; e < 3; e++) {
            printf("%.*e %.*e %.*e\n", 10, faces[e][0], 10, faces[e][1], 10, faces[e][2]);
        }
    }

    return 0;
}
