#define _USE_MATH_DEFINES

#include <stdio.h>
#include <string.h>
#include <math.h>

void rot(double *vect, double sin_phi, double cos_phi) {
	// Applies a rotation, first along x, than along z (same angle)
	double x, y, z;
	y = cos_phi * vect[1] - sin_phi * vect[2];
	z = sin_phi * vect[1] + cos_phi * vect[2];
	vect[1] = y;
	vect[2] = z;
	x = cos_phi * vect[0] - sin_phi * vect[1];
	y = sin_phi * vect[0] + cos_phi * vect[1];
	vect[0] = x;
	vect[1] = y;
}

double projected_face_area(double *a, double *b, double *c) {
	double u_x = b[0] - a[0];
	double u_z = b[2] - a[2];
	double v_x = c[0] - a[0];
	double v_z = c[2] - a[2];
	double rv = u_x * v_z - u_z * v_x;
	return (rv >= 0.)? rv : -rv;
}

double shadow_area(double phi) {
	double vppp[3];
	double vmpp[3];
	double vpmp[3];
	double vppm[3];
	double sin_phi = sin(phi);
	double cos_phi = cos(phi);

	for (int i = 0; i < 3; ++i) {
		vppp[i] = .5;
		vppm[i] = .5;
		vpmp[i] = .5;
		vmpp[i] = .5;
	}

	vmpp[0] = -.5;
	vpmp[1] = -.5;
	vppm[2] = -.5;

	rot(vppp, sin_phi, cos_phi);
	rot(vmpp, sin_phi, cos_phi);
	rot(vpmp, sin_phi, cos_phi);
	rot(vppm, sin_phi, cos_phi);

	return
		projected_face_area(vppp, vmpp, vpmp)
		+ projected_face_area(vppp, vpmp, vppm)
		+ projected_face_area(vppp, vppm, vmpp);
}

void print_rotated_coords(double phi, double x, double y, double z) {
	double v[3];
	v[0] = x;
	v[1] = y;
	v[2] = z;
	rot(v, sin(phi), cos(phi));
	printf("%.16f %.16f %.16f\n", v[0], v[1], v[2]);
}

void solve_test_case(int n, double a) {
	double phi = M_PI / 8.;
	double phi_step = M_PI / 16;
	for (int i = 0; i < 50; ++i) {
		phi += (shadow_area(phi) < a)? phi_step : -phi_step;
		phi_step /= 2.;
	}
	printf("Case #%d:\n", n);
	print_rotated_coords(phi, .5, 0., 0.);
	print_rotated_coords(phi, 0., .5, 0.);
	print_rotated_coords(phi, 0., 0., .5);
}

int main(void) {
	int n_test_cases;
	scanf("%d", &n_test_cases);
	for (int i = 0; i < n_test_cases; ++i) {
		double a;
		scanf("%lf", &a);
		solve_test_case(i+1, a);
	}
	return 0;
}

