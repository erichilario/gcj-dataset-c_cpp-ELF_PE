#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char map[1000][1000];
int solved;
int minx,miny,maxx,maxy;

int getx,gety;

void send(int i,int j) {
//	fprintf(stderr,"try %d %d\n",i,j);
	printf("%d %d\n",i,j);fflush(stdout);
/*	getx=i-1+rand()%3;
	gety=j-1+rand()%3;
	for(i=minx;i<=maxx;i++) {
		for(j=miny;j<=maxy;j++) printf("%c",map[i][j]?'#':'.');
		printf("\n");
	}
	for(i=minx;i<=maxx;i++) for(j=miny;j<=maxy;j++) if(!map[i][j]) return;
	getx=0; gety=0;*/
}

void update() {
	int a,b;
	scanf("%d %d",&a,&b);
//	fprintf(stderr,"got %d %d\n",a,b);
/*	a=getx; b=gety; printf("filled %d %d\n",a,b);*/
	if(a==0 && b==0) { solved=1; return; }
	if(a==-1 && b==-1) exit(0);
	map[a][b]=1;
/*	for(int j=miny;j<=maxy;j++) {
		for(int i=minx;i<=maxx;i++) fprintf(stderr,"%c",map[i][j]?'#':'.');
		fprintf(stderr,"\n");
	}*/
}

void fill(int x,int y) {
	int x2=x,y2=y;
	if(solved) return;
	if(x2==minx) x2++;
	if(x2==maxx) x2--;
	if(y2==miny) y2++;
	if(y2==maxy) y2--;
	while(!map[x][y]) {
		if(solved==1) return;
		send(x2,y2);
		update();
	}
}

void solve() {
	int A,z,i,j;
	int x1,y1,x2,y2;
	scanf("%d",&A);
	for(z=3;z*z<A;z++);
	minx=miny=x1=y1=1;
	maxx=maxy=x2=y2=1+z-1;
	memset(map,0,sizeof(map));
	solved=0;
	/* shotgun phase */
	for(i=x1+1;i<x2;i++) for(j=y1+1;j<y2;j++) {
		if(solved) return;
		send(i,j);
		update();
	}
	/* fill in missing border cells */
	for(i=x1;i<=x2;i++) {
		if(solved) return;
		fill(i,y1);
		fill(i,y2);
	}
	for(j=y1;j<=y2;j++) {
		if(solved) return;
		fill(x1,j);
		fill(x2,j);
	}
	/* fill in missing interior */
	for(i=x1+1;i<x2;i++) for(j=y1+1;j<y2;j++) {
		if(solved) return;
		fill(i,j);
	}
}

int main() {
	int T;
	scanf("%d",&T);
	while(T--) solve();
	return 0;
}

