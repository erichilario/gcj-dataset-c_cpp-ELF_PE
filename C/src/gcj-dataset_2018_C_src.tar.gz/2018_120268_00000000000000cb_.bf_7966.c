#include <stdio.h>
#include <string.h>

#define true 1
#define false 0

typedef unsigned char bool;

int getSum(const char *str, int size)
{
    int i, k, sum = 0;
    for(i = 0, k = 1; i < size; i++)
        if(str[i] == 'C')
            k *= 2;
        else
            sum += k;
        
    return sum;
}

int getC(const char *str, int size)
{
    int i;
    for(i = size-1; i >= 0; i--)
        if(str[i] != 'C')
            for( --i ; i >= 0; i--)
                if(str[i] == 'C')
                    return i;
                
    return i;
}

int main()
{
    int T, cont = 0;
    
    scanf("%d\n", &T);
    
    while(T--)
    {
        int D;
        char str[64];
        int i, size, sum, c;
        
        scanf("%d %s\n", &D, str);
        
        size = (int )strlen(str);
        
        sum = getSum(str, size);
        c = getC(str, size);
            
        for(i = 0; sum > D && c >= 0; i++)
        {
            str[c] = 'S';
            str[c+1] = 'C';
            
            sum = getSum(str, size);
            c = getC(str, size);
        }
        
        if(sum <= D)
            printf("Case #%d: %d\n", ++cont, i);
        else
            printf("Case #%d: %s\n", ++cont, "IMPOSSIBLE");
    }
    
    
    return 0;
}

