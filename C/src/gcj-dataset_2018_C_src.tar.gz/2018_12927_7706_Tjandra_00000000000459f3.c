#include<stdio.h>
#include<stdlib.h>
typedef double d;
typedef unsigned u;
typedef long long unsigned llu;
u M[555][555],O[555][555],t,S[555];
u F(u x,u y)
{
	if(!x)return S[y];
	if(O[x][y]==1)return M[x][y];
	O[x][y]=1;
	u i,j,k,m=F(x-1,y);
	for(j=i=1;i<=x&&j<=y;)
	{
		k=i+F(x-i,y-j);
		if(m<k)m=k;
		j+=++i;
	}
	return M[x][y]=m;
}
int main()
{
	u T,i,j,k,z,r;
	for(i=j=1;i<555;i+=++j)S[i]=j;
	for(i=0;++i<555;)if(!S[i])S[i]=S[i-1];
	for(scanf("%u",&T);t++<T;)
	{
		scanf("%u%u",&i,&j);
		for(r=0,k=-1;++k<=i;)
		{
			z=S[k]+F(i-k,j);
			if(r<z)r=z;
		}
		printf("Case #%u: %u\n",t,r);
	}
	return 0;
}
