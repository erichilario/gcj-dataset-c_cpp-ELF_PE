#include <cstdio>

int A,mx,my;
int v[7][7];
void doit(){
    scanf("%d",&A);
    fr(i,0,4)fr(j,0,4) v[i][j]=1;
    printf("%d %d\n",500,500);
    fflush(stdout);
    scanf("%d%d",&mx,&my);

    int x,y;

    v[2][2]=0;
    while (v[0][0]||v[0][1]||v[1][0]||v[0][2]){
        printf("%d %d\n",mx-1,my-1);
        fflush(stdout);
        scanf("%d%d",&x,&y);
        if (x==0 && y==0) return;
        v[x-mx+2][y-my+2]=0;
    }

    while (v[0][3]||v[0][4]||v[1][4]||v[2][4]){
        printf("%d %d\n",mx-1,my+1);
        fflush(stdout);
        scanf("%d%d",&x,&y);
        if (x==0 && y==0) return;
        v[x-mx+2][y-my+2]=0;
    }

    while (v[2][0]||v[3][0]||v[4][0]||v[4][1]){
        printf("%d %d\n",mx+1,my-1);
        fflush(stdout);
        scanf("%d%d",&x,&y);
        if (x==0 && y==0) return;
        v[x-mx+2][y-my+2]=0;
    }

    while (v[3][4]||v[4][2]||v[4][3]||v[4][4]){
        printf("%d %d\n",mx+1,my+1);
        fflush(stdout);
        scanf("%d%d",&x,&y);
        if (x==0 && y==0) return;
        v[x-mx+2][y-my+2]=0;
    }

    int tt=0;
    fr(i,1,3)fr(j,1,3) tt+=v[i][j];
    while (tt){
        printf("%d %d\n",mx,my);
        fflush(stdout);
        scanf("%d%d",&x,&y);
        if (x==0 && y==0) return;
        if (v[x-mx+2][y-my+2]){
            v[x-mx+2][y-my+2]=0;
            tt--;
        }
    }
}

int main() {


     int cas,i=0;
     scanf("%d",&cas);
     while (cas--)
     {
             //printf("Case #%d: ",++i);
             doit();

     }


}


