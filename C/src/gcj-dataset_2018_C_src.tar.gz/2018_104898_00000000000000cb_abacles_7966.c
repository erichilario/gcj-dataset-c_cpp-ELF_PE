#include <stdio.h>

int main()
{
  int ncases, shield, mindmg, dmg, cost, c, i, j, k;
  char prog[31], foo;
  scanf("%d", &ncases);
  for(c=0;c<ncases;c++)
    {
      scanf("%d%c", &shield, &foo);
      for(i=mindmg=dmg=0,j=1;(prog[i]=getchar())!='\n';i++)
	{
	  if(prog[i] == 'S')
	    {
	      mindmg++;
	      dmg += j;
	    }
	  else
	    j *= 2;
	}
      prog[i] = 0;
      printf("Case #%d: ", c + 1);
      if(mindmg > shield)
	printf("IMPOSSIBLE\n");
      else
	{
	  for(cost=0;dmg>shield;cost++)
	    {
	      for(k=0,j=i-1;j>0;j--)
		{
		  if(prog[j] == 'S' && prog[j-1] == 'C')
		    break;
		  else if(prog[j] == 'C')
		    k++;
		}
	      prog[j] = 'C';
	      prog[j-1] = 'S';
	      dmg -= (1 << (i-mindmg-k-1));
	    }
	  printf("%d\n", cost);
	}
    }
}

