#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define max(X,Y) ((X)>(Y)?(X):(Y))
#define min(X,Y) ((X)<(Y)?(X):(Y))

int main()
{
	int T, tcase, unpreparedCount;
	char isPrepared[20][20];
	char unpreparedNeighbours[20][20];
	scanf("%d", &T);
	for(tcase = 1; tcase <= T; tcase++)
	{
		int A, I, J, targetI, targetJ, i, j, N, M;
		scanf("%d", &A);
		for(N=3; N*N < A; N++)
			;
		M = A/N;
		if( M*N < A )
			M++;
		if( M < 3 )
			M = 3;
		//fprintf(stderr,"A: %d\n", A);
		//fprintf(stderr,"Will try to fill a (%d x %d)-grid.\n", M, N);
		unpreparedCount = N*M;
		for(i = 1; i <= N; i++)
			for(j = 1; j <= M; j++)
				isPrepared[i][j] = 0;
		for(i = 2; i <= N-1; i++)
			for(j = 2; j <= M-1; j++)
				unpreparedNeighbours[i][j] = 9;
		targetI = targetJ = 2;
		while(1)
		{
			printf("%d %d\n", targetI, targetJ);
			fflush(stdout);
			scanf("%d %d", &I, &J);
			if(I == 0 && J == 0)	// testcase solved
				break;
			if(I == -1 && J == -1)	// fail
				return 0;
			if(!isPrepared[I][J])
			{
				isPrepared[I][J] = 1;
				unpreparedCount--;
				for(i = max(2,I-1); i <= min(N-1,I+1); i++)
					for(j = max(2,J-1); j <= min(M-1,J+1); j++)
						unpreparedNeighbours[i][j]--;
				for(i = 2; i <= N-1; i++)
					for(j = 2; j <= M-1; j++)
						if( unpreparedNeighbours[i][j] > unpreparedNeighbours[targetI][targetJ] )
						{
							targetI = i;
							targetJ = j;
						}
			}
		}
	}
	return 0;
}

