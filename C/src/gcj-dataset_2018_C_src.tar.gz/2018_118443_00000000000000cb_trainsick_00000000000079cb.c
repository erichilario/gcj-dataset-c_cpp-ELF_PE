
#include <stdio.h>
#include <stdlib.h>

/*
trouble sort just sorts odd and even indexed 
numbers into separate sequences
*/

int *data;
int *alt;
int N;
int tosort;

void readstuff(void) {
    int i,even,odd,v;
    scanf("%d", &N);
    data=malloc(N*sizeof(int));
    alt=malloc(N*sizeof(int));
    even=0;
    odd=(N+1)/2;
    for (i=0;i<N;i++) {
        scanf("%d",&v);
        if (i & 1) data[odd++]=v;
        else data[even++]=v;
    }
}

void merge(int *a, int an, int *b, int bn, int *c) {
    while (an>0 && bn>0) {
        if (*a <= *b) {
            *c++ = *a++;
            an--;
        } else {
            *c++ = *b++;
            bn--;
        }
    }
    if (an==0) {an=bn; a=b;}
    while (an>0) {
        *c++= *a++;
        an--;
    }
}

void cp(int *src, int *dst, int n) {
    int i;
    for (i=0;i<n;i++) dst[i]=src[i];
}

int sort(int n) {
    int a,b;
    if (n<=1) return tosort++;
    a=sort(n/2);
    b=sort(n-n/2);
    merge(data+a,n/2,data+b,n-n/2,alt);
    cp(alt,data+a,n);
    return a;
}

void trouble(int casenum) {
    int i;
    int even,odd, v;
    readstuff();
    tosort=0;
    sort((N+1)/2);
    tosort=(N+1)/2;
    sort(N/2);
    merge(data+0, (N+1)/2, data+(N+1)/2, N/2, alt);
    even=0;odd=(N+1)/2;
    for (i=0;i<N;i++) {
        if (i & 1) v=data[odd++];
        else v=data[even++];
        if (v!=alt[i]) break;
    }
    printf("Case #%d: ",casenum);
    if (i==N) printf("OK\n");
    else printf("%d\n",i);
    free(data);
    free(alt);
}

int main(int argc, char ** argv) {
    int T,i;
    scanf("%d", &T);
    for (i=1;i<=T;i++)
        trouble(i);
    return 0;
}
