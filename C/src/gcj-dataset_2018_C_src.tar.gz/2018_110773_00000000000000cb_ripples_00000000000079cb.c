#include <stdio.h>

const int MAX_N = 10e5;

int data[MAX_N];

void trouble_sort(int data[], int n) {
    int done = 0;
    while (!done) {
        done = 1;
        for (int i = 0; i < n - 2; ++i) {
            if (data[i] > data[i + 2]) {
                done = 0;
                int t = data[i];
                data[i] = data[i + 2];
                data[i + 2] = t;
            }
        }
    }
}

int do_once() {
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf("%d", data + i);
    }
    trouble_sort(data, n);
    for (int i = 0; i < n - 1; ++i) {
        if (data[i] > data[i + 1]) {
            return i;
        }
    }
    return -1;
}

int main() {
    int num_test;
    scanf("%d", &num_test);
    for (int test_case = 1; test_case <= num_test; ++test_case) {
        int ans = do_once();
        if (ans >= 0) {
            printf("Case #%d: %d\n", test_case, ans);
        } else {
            printf("Case #%d: OK\n", test_case);
        }
    }
    return 0;
}

