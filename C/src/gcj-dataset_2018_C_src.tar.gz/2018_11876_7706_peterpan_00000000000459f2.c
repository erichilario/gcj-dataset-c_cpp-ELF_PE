#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define min(X,Y) ((X)<(Y)?(X):(Y))
#define max(X,Y) ((X)>(Y)?(X):(Y))
#define MAXC 101

int main()
{
	int T,tcase, B[MAXC];
	char board[MAXC+1][MAXC+1];


	scanf("%d", &T);
	for(tcase = 1; tcase <= T; tcase++)
	{
		int C, i, rows, row, pos;
		scanf("%d", &C);
		for(i = 0; i < C; i++)
		{
			scanf("%d", B+i);
			for(row = 0; row < C+1; row++)
				board[row][i] = '.';
		}
		for(row = 0; row < C+1; row++)
			board[row][C] = 0;
		if(!B[0] || !B[C-1])
		{
			printf("Case #%d: IMPOSSIBLE\n", tcase);
			continue;
		}
		pos = 0;
		rows = 1;
		for(i = 0; i < C; i++)
		{
			if(!B[i])
				continue;
			int finalCol = pos + B[i] - 1;
			int height = 1 + max(abs(finalCol - i), abs(pos - i));
			rows = max(rows, height);
			if(pos < i)
			{
				int j;
				for(row = 0, j = pos; j < i; j++, row++)
					board[row][j] = '\\';
			}
			if(finalCol > i)
			{
				int j;
				for(row = 0, j = finalCol; j > i; j--, row++)
					board[row][j] = '/';
			}
			pos = finalCol + 1;
		}
		printf("Case #%d: %d\n", tcase, rows);
		for(i = 0; i < rows; i++)
			printf("%s\n", board[i]);
	}
	return 0;
}
