#include <stdio.h>
#include <string.h>

int swap_beam(char* s, int len);
int get_beam(char* s, int len);

int main() {
    int T;
    int D;
    char P[30];
    

    int t;
    scanf("%d", &T);
    for (t = 1; t <= T; t++) {
        scanf("%d %s", &D, P);
        int len = strlen(P);
        int cnt = 0;

        int beam = get_beam(P, len);
        
        while (1) {
            if (beam <= D) {
                printf("Case #%d: %d\n", t, cnt);
                break;
            } else {
                if (!swap_beam(P, len)) {
                    printf("Case #%d: IMPOSSIBLE\n", t);
                    break;
                }
                beam = get_beam(P, len);
            }
            cnt++;
        }

    }
}

int swap_beam(char* s, int len) {
    int l;
    for (l = len - 1; l > 0; l--) {
        if (s[l] == 'S' && s[l - 1] == 'C') {
            s[l] = 'C';
            s[l - 1] = 'S';
            return 1;
        }
    }
    return 0;
}

int get_beam(char* s, int len) {
    int l;
    int power = 1;
    int sum = 0;
    
    for (l = 0; l < len; l++) {
        if (s[l] == 'C') {
            power *= 2;
        } else {
            sum+=power;
        }
    }
    return sum;
}
