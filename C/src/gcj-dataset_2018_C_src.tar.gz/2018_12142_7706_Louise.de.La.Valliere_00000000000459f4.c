#include <stdbool.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
	int T;
	scanf("%d", &T);

	for (int iT = 1; iT <= T; ++iT)
	{
		int R, C;
		scanf("%d%d ", &R, &C);

		char grid[20][21];
		for (int i = 0; i < R; ++i)
			gets(grid[i]);

		int answer = 0;
		for (int hori = 0; hori <= R; ++hori)
		for (int vert = 0; vert <= C; ++vert)
		for (int colors = 0; colors < 16; ++colors)
		{
			bool visited[20][20];
			memset(visited, 0, R * sizeof visited[0]);

			for (int i = 0; i < R; ++i)
			for (int j = 0; j < C; ++j)
			if (!visited[i][j])
			{
				visited[i][j] = true;
				if ((grid[i][j] == 'W') != (colors >> ((i < hori) | (j < vert) << 1) & 1))
					continue;

				struct coord { char i, j; } queue[20 * 20], *queue_head = queue, *queue_tail = queue + 1;
				queue[0] = (struct coord) { i, j };

				while (queue_head < queue_tail)
				{
					struct coord p = *queue_head++;
					if (p.i && !visited[p.i-1][p.j])
					{
						visited[p.i-1][p.j] = true;
						if ((grid[p.i-1][p.j] == 'W') == (colors >> ((p.i-1 < hori) | (p.j < vert) << 1) & 1))
							*queue_tail++ = (struct coord) { p.i-1, p.j };
					}
					if (p.j && !visited[p.i][p.j-1])
					{
						visited[p.i][p.j-1] = true;
						if ((grid[p.i][p.j-1] == 'W') == (colors >> ((p.i < hori) | (p.j-1 < vert) << 1) & 1))
							*queue_tail++ = (struct coord) { p.i, p.j-1 };
					}
					if (p.i+1 < R && !visited[p.i+1][p.j])
					{
						visited[p.i+1][p.j] = true;
						if ((grid[p.i+1][p.j] == 'W') == (colors >> ((p.i+1 < hori) | (p.j < vert) << 1) & 1))
							*queue_tail++ = (struct coord) { p.i+1, p.j };
					}
					if (p.j+1 < C && !visited[p.i][p.j+1])
					{
						visited[p.i][p.j+1] = true;
						if ((grid[p.i][p.j+1] == 'W') == (colors >> ((p.i < hori) | (p.j+1 < vert) << 1) & 1))
							*queue_tail++ = (struct coord) { p.i, p.j+1 };
					}
				}

				if (queue_tail - queue > answer)
					answer = queue_tail - queue;
			}
		}

		printf("Case #%d: %d\n", iT, answer);
	}
}

