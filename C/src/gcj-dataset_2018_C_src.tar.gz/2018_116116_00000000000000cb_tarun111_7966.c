#include <stdio.h>
#include <string.h>

char seq[31];
int len;

int score()
{
    int s = 0;
    int mul = 1;
    for (int i = 0; i < len; i++) {
        if (seq[i] == 'S') {
            s += mul;
        } else {
            mul <<= 1;
        }
    }
    
    return s;
}

int move()
{
    int i, pos = -1;
    for (i = 0; i < len - 1; i++) {
        if (seq[i] == 'C' && seq[i+1] == 'S') {
            pos = i;
        }
    }
    
    if (pos == -1) return 0;
    
    seq[pos] ^= seq[pos+1] ^= seq[pos] ^= seq[pos+1];
    
    return 1;
}

int solve(int threshold)
{
    int movements = 0;
    
    len = strlen(seq);
    
    while (score() > threshold) {
        if (!move()) return -1;
        movements++;
    }
    
    return movements;
}

int main()
{
    int cases, ii, threshold, ans;
    scanf("%d", &cases);
    
    for (ii = 1; ii <= cases; ii++) {
        scanf("%d %s", &threshold, seq);
        printf("Case #%d: ", ii);
        ans = solve(threshold);
        if (ans == -1) {
            puts("IMPOSSIBLE");
        } else {
            printf("%d\n", ans);
        }
    }
    
    return 0;
}
