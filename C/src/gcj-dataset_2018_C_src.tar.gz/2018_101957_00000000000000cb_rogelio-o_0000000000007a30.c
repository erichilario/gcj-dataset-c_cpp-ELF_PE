#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdarg.h>

typedef struct {
   int i;
   int j;
} Coordinates;

#define DEBUG 0

void debugMessage(const char *message, ...) {
    if(DEBUG) {
        va_list args;
        va_start (args, message);
        vfprintf (stderr, message, args);
        va_end (args);
    }
}

Coordinates getNextUndeployedCell(int numRows, int numColumns, unsigned short soid[][numColumns]) {
    for(int i = 0; i < numRows; i++) {
        for(int j = 0; j < numColumns; j++) {
            if(!soid[i][j]) {
                Coordinates result = { i, j };
                return result;
            }
        }
    }

    Coordinates result = { 0, 0 };
    return result;
}

int avoidEdges(int index, int size) {
    if(index == 0) {
        return index + 1;
    } else if(index == (size - 1)) {
        return index - 1;
    } else {
        return index;
    }
}

int normalizeMovement(int index) {
    return index + 1;
}

int unnormalizeMovement(int index) {
    return index - 1;
}

void debugPrintSoid(int numRows, int numColumns, unsigned short soid[][numColumns]) {
    if(DEBUG) {
        for (int i = 0; i < numRows; i++) {
            for(int j = 0; j < numColumns; j++) {
                fprintf(stderr, "%d ", soid[i][j]);
            }
            fprintf(stderr, "\n");
        }
    }
}

int main() {
    int numProblems;
    int error = 0;
    scanf("%d", &numProblems);

    for(int problemIndex = 0; problemIndex < numProblems; problemIndex++) {
        if(error) {
            break;
        }

        int area;
        scanf("%d", &area);

        int numColumns = floor(sqrt((double) area));
        int numRows = pow(numColumns, 2) == area ? numColumns : numColumns + 1;
        debugMessage("Sizes: %d %d\n", numRows, numColumns);
        unsigned short soid[numRows][numColumns];
        memset(soid, 0, sizeof(unsigned short) * numRows * numColumns);
        int nextI = 0, nextJ = 0;

        while(1 == 1) {
            debugMessage("Movement: %d %d\n", nextI, nextJ);
            int iGoIn = avoidEdges(nextI, numRows);
            int jGoIn = avoidEdges(nextJ, numColumns);
            debugMessage("Movement without edges: %d %d\n", iGoIn, jGoIn);
            iGoIn = normalizeMovement(iGoIn);
            jGoIn = normalizeMovement(jGoIn);
            printf("%d %d\n", iGoIn, jGoIn);
            fflush(stdout);

            int iGoOut, jGoOut;
            scanf("%d %d", &iGoOut, &jGoOut);

            if(iGoOut == -1 && jGoOut == -1) {
                error = 1;
                debugMessage("Error in problem %d.", problemIndex);
                break;
            } else if(iGoOut == 0 && jGoOut == 0) {
                debugMessage("Problem %d completed successfully.", problemIndex);
                break;
            } else {
                iGoOut = unnormalizeMovement(iGoOut); 
                jGoOut = unnormalizeMovement(jGoOut);

                debugMessage("Movement done: %d %d\n", iGoOut, jGoOut);
                soid[iGoOut][jGoOut] = 1;

                debugPrintSoid(numRows, numColumns, soid);

                if(nextI == iGoOut && nextJ == jGoOut) {
                    Coordinates nextCoordinates = getNextUndeployedCell(numRows, numColumns, soid);
                    nextI = nextCoordinates.i;
                    nextJ = nextCoordinates.j;
                }
            }
        }
    }

    return 0;
}
