#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 1005

void mark(int xf, int yf, int field[N][N], int neighbor[N][N], int* total) {
  if (field[xf][yf] == 0) {
    field[xf][yf] = 1;
    (*total)++;
    for (int j=-1; j<=1; j++) {
      for (int k=-1; k<=1; k++) {
        neighbor[xf+j][yf+k]++;
      }
    }
  }
}

int solve(int a) {
  int h = (int) sqrt((double)a)+1;
  int hh = h*h;
  int hh0 = hh;

  int field[N][N]={0};
  int neighbor[N][N]={0};

  while(1) {
    for (int x=2; x<h; x++) {
      for (int y=2; y<h; y++) {
        if (neighbor[x][y] > hh*9/hh0+1) {
          continue;
        }

        printf("%d %d\n", x, y);

        int xf, yf;
        scanf("%d %d", &xf, &yf);

        if (xf==0 && yf==0) {
          return 0;
        }
        mark(xf, yf, field, neighbor, &hh);
      }
    }
  }
}

int main() {
  setbuf(stdout, NULL);
  int nt;
  scanf("%d", &nt);

  for (int i=0; i<nt; i++) {
    int a;
    scanf("%d", &a);

    solve(a);
  }
}

