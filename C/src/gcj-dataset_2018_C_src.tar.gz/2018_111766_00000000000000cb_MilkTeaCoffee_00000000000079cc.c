#include <stdio.h>  // includes cin to read from stdin and cout to write to stdout
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <math.h>

#define PI 3.141592653589793238462643383279502884197169399375105820974944592

int main(int argc,char* argv[]){
    int T,ct;
	long double A,sqrt2;
	long double theta;
	long double x,y,z;

	sqrt2 = sqrt((long double)2.0);

	fscanf(stdin,"%d",&T);
	for (ct = 1; ct <= T; ++ct) {
		fscanf(stdin,"%lf",&A);
//		printf("A: %.6lf\n",A);

//		theta = acos(A/sqrt2);
//		printf("theta: %.6lf\n",theta);
		
		//cos(\theta) = A/sqrt{2}
		//sin(\theta) = sqrt{2-A^2}/sqrt{2}

		//cos(\pi/4 - \theta)
		//= cos(\pi/4)cos(\theta) + sin(\pi/4)sin(\theta)
		//= 1/sqrt{2} * (A/sqrt{2}) + 1/sqrt{2} sqrt{2-A^2}/sqrt{2}
		//= (A + sqrt{2-A^2})/2

		//sin(\pi/4 - \theta)
		//= sin(\pi/4)cos(\theta) - cos(\pi/4)sin(\theta)
		//= 1/sqrt{2} A/sqrt{2} - 1/sqrt{2} sqrt{2-A^2}/sqrt{2}
		//= (A - sqrt{2-A^2})/2

		//x = cos(PI/4.0 - theta)/2;
		x = (A + sqrt(((long double)2) - A*A))/4;
		y = 0;
		//z = -sin(PI/4.0 - theta)/2;
		z = -(A - sqrt(((long double)2) - A*A))/4;

		printf("Case #%d:\n",ct);
		printf("%.6lf %.6lf %.6lf\n",x,y,z);
		printf("0 0.5 0\n");

		//cos(\pi/4 + \theta)
		//= cos(\pi/4)cos(\theta) - sin(\pi/4)sin(\theta)
		//= 1/sqrt{2} A/sqrt{2} - 1/sqrt{2} sqrt{2-A^2}/sqrt{2}
		//= (A - sqrt{2-A^2})/2

		//sin(\pi/4 + \theta)
		//= sin(\pi/4)cos(\theta) + cos(\pi/4)sin(\theta)
		//= 1/sqrt{2} A/sqrt{2} + 1/sqrt{2} sqrt{2-A^2}/sqrt{2}
		//= (A + sqrt{2-A^2})/2

		//x = cos(\pi/4 + theta)/2;
		x = (A - sqrt(((long double)2) - A*A))/4;
		y = 0;
		//z = sin(PI/4.0 + theta)/2;
		z = (A + sqrt(((long double)2) - A*A))/4;
		printf("%.6lf %.6lf %.6lf\n",x,y,z);
		
	}
    return 0;
}
