#include <stdio.h>

#define DEBUG 0

long int nm;
int t = 0;
int n = 0;
int stage = 1;
long int ary[100000];
int ary_len = 0;
int ax = 0;
int ok = 0;

void worker(long int);

int main() {
  while(t == 0 || t > stage - 1) {
    scanf("%ld", &nm);
    worker(nm);
  }
  return 0;
}

void worker(long int number) {
  if (t == 0) {
    t = number;
    if (DEBUG) {
      printf("read T %i\n", t);
    };
  } else if (n == 0) {
    n = number;
    if (DEBUG) {
      printf("read N %i\n", n);
    };
  } else {
    if (DEBUG) {
      printf("read number %lu\n", number);
    };
    ary[ary_len++] = number;
    if (n == ary_len) {
      int done = 0;
      int i = 0;
      do {
        done = 1;
        for(i = 0; i < ary_len-2; i++) {
          if (ary[i] > ary[i+2]) {
            done = 0;
            ax = ary[i];
            ary[i] = ary[i+2];
            ary[i+2] = ax;
          }
        }
      } while(done == 0);
      ok = 1;
      for(int i = 0; i < ary_len-1; i++) {
        if (ary[i] > ary[i+1]) {
          printf("Case #%i: %i\n", stage, i);
          ok = 0;
          break;
        }
      }
      if (ok == 1) {
        printf("Case #%i: OK\n", stage);
      }
      n = 0;
      ary_len = 0;
      stage++;
    }
  }
}

