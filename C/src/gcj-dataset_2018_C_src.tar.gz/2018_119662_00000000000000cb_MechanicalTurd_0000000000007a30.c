#include <stdio.h>

static int T, A;

int main() {
	scanf("%d", &T);
	for (int t = 1; t <= T; t++) {
		scanf("%d", &A);
		for (int x = 2; A > 0; x += 3, A -= 9) {
			for (int cells = 0, r, c; cells != 511; ) {
				printf("2 %d\n", x);
				fflush(stdout);
				scanf("%d %d", &r, &c);
				if (r == 0)
					break;
				int i = (r - 1) * 3 + c - x + 1;
				cells |= 1 << i;
			}
		}
	}
	return 0;
}

