#include<stdio.h>
#include<stdlib.h>
int check(int arr[], int n)
{
	 if (n == 0 || n == 1)
	        return -1;

	    for (int i = 1; i < n; i++)

	        // Unsorted pair found
	        if (arr[i-1] > arr[i])
	            return i-1;

	    // No unsorted pair found
	    return -1;
}
void main()
{
	int t,n;
	int i;
	printf("enter no of test cases\n");
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		printf("enter size of number\n");
		scanf("%d",&n);
		int *a=(int *)malloc(sizeof(int )*n);
		printf("enter numbers\n");
		for(int j=0;j<n;j++)
			scanf("%d",&a[j]);
		for(int j=0;j<n;j++)
			printf("%d\t",a[j]);
		for(int k=0;k<=n/3;k++)
		{
			int p=0,q=2,m;
			for( m=0;m<n;m++)
			{
				if(a[p]>a[q]&&q<n)
				{
					int temp=a[p];
					a[p]=a[q];
					a[q]=temp;
				}
				p++;
				q++;

			}
		}
		int z=check(a,n);
					if(z==-1)
						printf("Case #%d: OK",t);

					else	printf("Case #%d:%d",t,z);

	}
}


