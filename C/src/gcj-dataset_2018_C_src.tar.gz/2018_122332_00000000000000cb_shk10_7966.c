#include<stdio.h>
#include<string.h>

int D;
char S[32];

int solve() {
    int i, j, swap = 0, move = 0, total = 0, l = strlen(S), p = 0;
    for(i=0; i<l; i++)
        if(S[i]=='C')
            p++;
        else
            total += (1<<p);
    if(total <= D) return 0;
    for(i=l-1; i>=0; i--)
        if(S[i]=='C') {
            for(j=i+1; j<l-move; j++) {
                total -= 1<<(p-1);
                swap++;
                if(total <= D)
                    return swap;
            }
            move++;
            p--;
        }
    return -1;
}

int main() {
    int T,cas;
    scanf("%d", &T);
    for(cas=1; cas<=T; cas++) {
        scanf("%d%s",&D,S);
        int res = solve();
        if(res==-1)
            printf("Case #%d: IMPOSSIBLE\n", cas);
        else
            printf("Case #%d: %d\n", cas, res);
    }
    return 0;
}
