#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define P 100

size_t getScore(char *program)
{
	size_t score;
	size_t charges;

	charges = 1;
	score   = 0;

	while(1) {
		switch(program[0]) {
			case 'S':
				score += charges;
				break;

			case 'C':
				charges *= 2;
				break;

			default:
				return score;
		}

		program++;
	}
}

int solve(unsigned long shield, char *program)
{
	size_t i;
	size_t count;
	size_t size;

	count = 0;
	size  = strlen(program);

	/* Determine if doable */
	for(i = 0; i < size; i++)
		if(program[i] == 'S')
			count++;

	/* If robot shoot more than shield, it's impossible */
	if(count > shield)
		return -1;

	/* Trim leftmost shoots : they cannot be avoided */
	count = strspn(program, "S");
	program += count;
	size    -= count;
	shield  -= count;

	assert(program[0] == 'C');

	/* Trim rightmost charges : they are useless */
	while(size > 0 && program[size - 1] == 'C')
		size--;

	assert(size == 0 || program[size - 1] == 'S');
	program[size] = 0;

	/* The best move is to swap the rightmost C with the next S */
	count = 0;
	while(getScore(program) > shield) {
		char *right;

		right = strrchr(program, 'C');
		assert(right[0] == 'C');
		assert(right[1] == 'S');

		right[0] = 'S';
		right[1] = 'C';

		/* If rightmost, trim it */
		if(right[2] == 0)
			right[1] = 0;

		count++;
	}

	return count;
}

int main(int argc, char *argv[])
{
	size_t   i, n;

	unsigned long shield;
	char     program[P + 1];
	int      ret;

	scanf("%lu", &n);

	for(i = 0; i < n; i++) {
		scanf("%lu %s", &shield, program);

		printf("Case #%lu: ", i + 1);

		ret = solve(shield, program);

		if(ret >= 0)
			printf("%d\n", ret);
		else
			puts("IMPOSSIBLE");
	}

	return EXIT_SUCCESS;
}

