#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main(void) {
	
	/*
	FILE *debug;
	debug = fopen("debug.txt", "w");
	
	fprintf(debug, "main function started.\n");
	//*/
	
	int t;
	int i, j;
	scanf("%d", &t);
	
	
	for (i = 0; i < t; i++) {
		int a;
		scanf("%d", &a);
		
		int garden[10][100];
		
		if (a == 20) {
			// 3 * 7 ( == 21 )
			
			int neighbor[5];
			memset(garden, 0, sizeof(garden));
			memset(neighbor, 0, sizeof(neighbor));
			
			while(1) {
				int min = neighbor[0];
				int minIdx = 0;
				for (j = 0; j < 5; j++) {
					if (neighbor[j] < min) {
						min = neighbor[j];
						minIdx = j;
					}
				}
				
				printf("%d %d\n", 2, minIdx + 2);
				fflush(stdout);
				
				int actualX, actualY;
				scanf("%d %d", &actualX, &actualY);
				
				/*
				for (j = 1; j < 4; j++) {
					for (int k = 1; k < 8; k++) {
						fprintf(debug, "%c", (garden[j][k] ? '#': '.'));
					}
					fprintf(debug, "\n");
				}
				fprintf(debug, " ");
				for (j = 0; j < 5; j++) {
					fprintf(debug, "%d", neighbor[j]);
				}
				fprintf(debug, " \n");
				fprintf(debug, "out: %d %d; ", 2, minIdx + 2);
				fprintf(debug, "in: %d %d\n", actualX, actualY);
				//*/
				
				if (actualX == 0 || actualX == -1) {
					break;	
				} else {
					if (!garden[actualX][actualY]) {
						garden[actualX][actualY] = 1;
						for (j = 0; j < 5; j++) {
							if (abs(actualY - j - 2) <= 1) {
								neighbor[j]++;
							}
						}
					}
				}
			}	
			
		} else { 
			// a == 200
			// 3 * 67 ( == 201)
			
			int neighbor[65];
			memset(garden, 0, sizeof(garden));
			memset(neighbor, 0, sizeof(neighbor));
			
			while(1) {
				int min = neighbor[0];
				int minIdx = 0;
				for (j = 0; j < 65; j++) {
					if (neighbor[j] < min) {
						min = neighbor[j];
						minIdx = j;
					}
				}
				
				printf("%d %d\n", 2, minIdx + 2);
				fflush(stdout);
				
				int actualX, actualY;
				scanf("%d %d", &actualX, &actualY);
				
				/*
				for (j = 1; j < 4; j++) {
					for (int k = 1; k < 68; k++) {
						fprintf(debug, "%c", (garden[j][k] ? '#': '.'));
					}
					fprintf(debug, "\n");
				}
				fprintf(debug, " ");
				for (j = 0; j < 65; j++) {
					fprintf(debug, "%d", neighbor[j]);
				}
				fprintf(debug, " \n");
				fprintf(debug, "out: %d %d; ", 2, minIdx + 2);
				fprintf(debug, "in: %d %d\n", actualX, actualY);
				//*/
				
				if (actualX == 0 || actualX == -1) {
					break;	
				} else {
					if (!garden[actualX][actualY]) {
						garden[actualX][actualY] = 1;
						for (j = 0; j < 65; j++) {
							if (abs(actualY - j - 2) <= 1) {
								neighbor[j]++;
							}
						}
					}
				}
			}	
		}
	}
	
	//fclose(debug);
	
	return 0;
}

