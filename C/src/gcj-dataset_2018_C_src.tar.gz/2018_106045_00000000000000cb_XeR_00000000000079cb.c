#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define  N 100000

int cmp(const void *a, const void *b)
{
	unsigned long la = *((unsigned long*)a);
	unsigned long lb = *((unsigned long*)b);

	if(la == lb) return 0;

	return 2 * (la > lb) - 1;
}

ssize_t solve(unsigned long *numbers, size_t count)
{
	unsigned long even[N / 2];
	unsigned long odd[N / 2];

	size_t i;

	for(i = 0; i < count; i++) {
		if(i % 2) odd[i / 2]  = numbers[i];
		else      even[i / 2] = numbers[i];
	}

	qsort(even, count / 2 + (count % 2), sizeof(*even), cmp);
	qsort(odd,  count / 2,               sizeof(*odd), cmp);

	/* Stack is usually limited to 8 MB, so let's reuse numbers */
	qsort(numbers, count, sizeof(*numbers), cmp);

	for(i = 0; i < count; i++) {
		if(i % 2) {
			if(odd[i / 2] != numbers[i])
				return i;
		} else {
			if(even[i / 2] != numbers[i])
				return i;
		}
	}

	return -1;
}

int main(int argc, char *argv[])
{
	size_t i, n;
	size_t j, count;

	unsigned long numbers[N];
	ssize_t   ret;

	scanf("%u", &n);

	for(i = 0; i < n; i++) {
		scanf("%u", &count);

		for(j = 0; j < count; j++)
			scanf("%lu", &numbers[j]);

		printf("Case #%d: ", i + 1);

		ret = solve(numbers, count);

		if(ret == -1)
			puts("Ok");
		else
			printf("%d\n", ret);
	}

	return EXIT_SUCCESS;
}

