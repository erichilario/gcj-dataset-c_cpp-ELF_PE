#include <stdio.h>

int orchard[1000][1000];
int A;
int main(void)
{
	int isCellComplete(int r,int c);
	int isComplete();
	int T;
	scanf("%d",&T);
	int x,y;
	for(int i = 0;i < T;i++)
	{
		scanf("%d",&A);
		for(int j = 0;j < 1000;j++)
		{
			for(int k = 0;k < 1000;k++)
			{
				orchard[j][k] = 0;
			}
		}
		int row = 400;
		int column = 2;
		int isDone = 0;
		while(!isDone)
		{

			if(isCellComplete(row,column))
			{
				column = column +3;
			}

			printf("%d %d\n",row,column);
			fflush(stdout);
			scanf("%d %d",&x,&y);
			if(x == -1 && y == -1)
			{
				return 0;
			}
			else if( x == 0 && y == 0)
			{
				isDone = 1;
			}
			orchard[x][y] = 1;
		}

	}

}
int isCellComplete(int r,int c)
{
	if(orchard[r][c] == 1 && orchard[r][c-1] == 1 && orchard[r-1][c-1] == 1 && orchard[r-1][c] == 1 && orchard[r-1][c+1] == 1 && orchard[r][c+1] == 1 && orchard[r+1][c+1] == 1 && orchard[r+1][c] ==1 && orchard[r+1][c-1] == 1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}



