#include<stdio.h>
#include<stdlib.h>
typedef double d;
typedef unsigned u;
typedef long long unsigned llu;
int M[111];u C[111];
char ans[111][111];
int main()
{
	u T,t=0,n,i,r,j,x;int m;
	for(scanf("%u",&T);t++<T;)
	{
		scanf("%u",&n);r=m=0;
		for(i=-1;++i<n;C[i]=x)
		{
			scanf("%u",&x);
			m+=x-1;
			M[i]=m;
			if(r<(j=m<0?-m:m))r=j;
		}
		printf("Case #%u: ",t);
		if(!*C||!C[n-1]||M[n-1])
			goto imp;
		for(++r,i=-1;++i<r;ans[i][n]='\0')
			for(j=-1;++j<n;)ans[i][j]='.';
		printf("%u\n",r);
		for(i=-1;++i<n;)
		{
			m=M[i];
			if(m<0)
			{
				m=-m;
				for(j=-1;++j<(u)m;)
				{
					ans[j][i]='\\';
				}
			}
			else if(m>0)
			{
				for(j=-1;++j<(u)m;)
				{
					ans[j][i+1]='/';
				}
			}
		}
		for(i=-1;++i<r;)printf("%s\n",ans[i]);
		continue;
		imp:;
		printf("IMPOSSIBLE\n");
	}
	return 0;
}
