#include <stdio.h>
#include <math.h>

typedef struct {
    double x;
    double y;
    double z;
} point;

int main() {
    int T = 0;
    int i = 0;
    double A = 0.0;
    double theta = 0.0, thi = 0.0;
    point px, py, pz;
    scanf("%d", &T);
    for(i = 0; i < T; i++) {
        theta = 0.0;
        thi = 0.0;
        px.x = 0.5;
        px.y = px.z = 0;
        py.y = 0.5;
        py.x = py.z = 0;
        pz.z = 0.5;
        pz.x = pz.y = 0;
        scanf("%lf", &A);

        if( A < sqrt(2)) {
            theta = (double) asin(A * A - 1) / 2;
            px.x = 0.5 * cos(theta);
            px.y = 0.5 * sin(theta);
            py.x = -0.5 * sin(theta);
            py.y = 0.5 * cos(theta);
            printf("Case #%d:\n", i + 1);
            printf("THETA = %lf\n", theta);
            printf("%lf %lf %lf\n", px.x, px.y, px.z);
            printf("%lf %lf %lf\n", py.x, py.y, py.z);
            printf("%lf %lf %lf\n", pz.x, pz.y, pz.z);
        }
        else if( A > sqrt(2)) {
            theta = M_PI / 4;
            thi = (double) asin((double) (A * A -2) / 2) / 2;
            px.x = 0.5 * cos(theta);
            px.y = 0.5 * sin(theta) * cos(thi);
            px.z = 0.5 * sin(theta) * sin(thi);
            py.x = -0.5 * sin(theta);
            py.y = 0.5 * cos(theta) * cos(thi);
            py.z = 0.5 * cos(theta) * sin(thi);
            pz.x = 0.0;
            pz.y = -0.5 * sin(thi);
            pz.z = 0.5 * cos(thi);
            printf("Case #%d:\n", i + 1);
            printf("THETA = %lf\n", theta);
            printf("THI = %lf\n", thi);
            printf("%lf %lf %lf\n", px.x, px.y, px.z);
            printf("%lf %lf %lf\n", py.x, py.y, py.z);
            printf("%lf %lf %lf\n", pz.x, pz.y, pz.z);
        }
    }
    return 0;
}

