#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int check(char a[],int n,int d)
{   
	int cnt=0,power=1;
	
for(int i=0;i<n;i++)
{
	if(a[i]=='C') power*=2;
	else cnt+=power;
}
	
	if(cnt<=d) return 1;
	else return 0;
}

void swap(char a[],int i,int j)
{
    int p=a[i];
    a[i]=a[j];
    a[j]=p;
}

int hack(char a[],int n,int d,int ans)
{   
	int flag;
	if(check(a,n,d)) return ans;
    if(!check(a,n,d))
    {
        for(int i=n-1;i>-1;i--)
        {
        	if(a[n-1]=='C') return (hack(a,n-1,d,ans));
        	if(a[n-1]=='S' && a[n-2]=='C')
        	{
        	   swap(a,n-1,n-2);
               ans++;
               if(check(a,n,d)) {return ans;}
               else return (hack(a,n-1,d,ans));
            }
            if(a[n-1]=='S' && a[n-2]=='S')
            {
            	for(int i=n-3;i>-1;i--)
            	{
            		if(a[i]=='C')
                    {
            		    swap(a,i,i+1);
                        ans++;
                        if(check(a,n,d)) {return ans;}
                    }
            	}
            }

        }
    }
}

int impossible(char a[],int n,int d)
{
	int count=0;
	for(int i=0;i<n;i++)
	{
		if(a[i]=='S') count++;
	}
	if(d<count) return 1;
	else return 0;
}

int main()
{
	int n,d;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
         scanf("%d",&d);
         char a[30];
         scanf("%s\n",a);
         int l=strlen(a);
         if(!impossible(a,l,d))
         {
         	int ans=hack(a,l,d,0);
         	printf("Case #%d: %d\n",i+1,ans);
         }
         else printf("Case #%d: IMPOSSIBLE\n",i+1);
    }	
		return 0;
}
