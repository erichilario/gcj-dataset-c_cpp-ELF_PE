#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI (3.141592653589793)
#define EPS 0.000000001

typedef struct {
	double x, y, z;
} coords_t;


double area1(double theta);
void get_centres1(coords_t *p1, coords_t *p2, coords_t *p3, double theta);
double area2(double theta);
void get_centres2(coords_t *p1, coords_t *p2, coords_t *p3, double theta);
void print_coords(coords_t *coords);

double arctan(double theta);

int main(int argc, char *argv[]) {
	int ntests;
	scanf("%d", &ntests);
	
	int i;
	double area;
	double diff;
	double theta_lo, theta_hi, theta_mid;
	coords_t p1, p2, p3;
	for (i=1; i<=ntests; i++) {
		scanf("%lf", &area);
		theta_lo = 0;
		theta_hi = PI/4;
		theta_mid = PI/8;
		if (area <= sqrt(2)+EPS) {
			while (fabs((diff = area1(theta_mid) - area)) > EPS) {
				if (diff < 0) {
					theta_hi = theta_mid;
				}
				else {
					theta_lo = theta_mid;
				}
				theta_mid = (theta_hi+theta_lo)/2;
			}
			get_centres1(&p1, &p2, &p3, theta_mid);
			printf("Case #%d:\n", i);
			print_coords(&p1);
			print_coords(&p2);
			print_coords(&p3);
		}
		else {
			theta_hi = arctan(1.0/sqrt(2));
			theta_mid = theta_hi/2;
			while (fabs((diff = area2(theta_mid) - area)) > EPS) {
				if (diff > 0) {
					theta_hi = theta_mid;
				}
				else {
					theta_lo = theta_mid;
				}
				theta_mid = (theta_hi+theta_lo)/2;
			}
			get_centres2(&p1, &p2, &p3, theta_mid);
			printf("Case #%d:\n", i);
			print_coords(&p1);
			print_coords(&p2);
			print_coords(&p3);
		}
	}
	
			
	return 0;
}


double area1(double theta) {
	return sqrt(2) * cos(theta);
}


void get_centres1(coords_t *p1, coords_t *p2, coords_t *p3, double theta) {
	p1->x = 0.5;
	p1->y = 0.0;
	p1->z = 0.0;
	
	p2->z = 0.5*cos(PI/4 + theta);
	p2->y = 0.5*sin(PI/4 + theta);
	p2->x = 0;
	
	p3->z = -0.5*cos(PI/4 - theta);
	p3->y = 0.5*sin(PI/4 - theta);
	p3->x = 0;
}


double area2(double theta) {
	coords_t p1, p2, p3;
	get_centres2(&p1, &p2, &p3, theta);
	
	double area = 0.0;
	area += 2*(p1.x+p3.x-p2.x) * (p1.z+p3.z-p2.z - (-p1.z+p3.z-p2.z));
	area += (p1.x+p3.x-p2.x) * ((p1.z+p3.z+p2.z)-(p1.z+p3.z-p2.z));
	area += (p1.x+p3.x-p2.x) * ((-p1.z+p3.z-p2.z)-(-p1.z-p3.z-p2.z));
	return area;
}


void get_centres2(coords_t *p1, coords_t *p2, coords_t *p3, double theta) {
	p1->z = 0.5*cos(theta);
	p1->y = 0.5 *sin(theta);
	p1->x = 0;
	
	p2->z = sin(theta)/(2*sqrt(2));
	p2->y = -cos(theta)/(2*sqrt(2));;
	p2->x = -1.0/(2*sqrt(2));
	
	p3->z = sin(theta)/(2*sqrt(2));
	p3->y = cos(theta)/(2*sqrt(2));
	p3->x = 1.0/(2*sqrt(2));
}


void print_coords(coords_t *coords) {
	printf("%.12f %.12f %.12f\n", coords->x, coords->y, coords->z);
}


double arctan(double theta) {
	double hi =PI/4, lo=0, mid=PI/8;
	while (fabs(tan(mid) - theta)>EPS) {
		if (tan(mid) >theta) {
			hi=mid;
		}
		else {
			lo=mid;
		}
		mid = (hi+lo)/2;
	}
	return mid;
}
