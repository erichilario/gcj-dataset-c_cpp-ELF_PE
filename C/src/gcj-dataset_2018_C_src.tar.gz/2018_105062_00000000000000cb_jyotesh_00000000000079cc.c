/*Cubic UFO*/

#include<stdio.h>
#include<math.h>

int main()
{
	const double root2 = sqrt(2.0);
	double A, phi, theta;
	int t, T;
	scanf("%d", &T);
	for (t = 1; t <= T; t++)
	{
		scanf("%lf", &A);
		printf("Case #%d:\n", t);
		if (A <= root2)
		{
			theta = 0.5 * asin(A * A - 1.0);
			printf("%lf %lf %lf\n", 0.5, 0.0, 0.0);
			printf("%lf %lf %lf\n", 0.0, 0.5 * cos(theta), 0.5 * sin(theta));
			printf("%lf %lf %lf\n", 0.0, -0.5 * sin(theta), 0.5 * cos(theta));
		}
		else
		{
			phi = asin((-1.0 * A + sqrt(6.0 - 2.0 * A * A)) / 3.0);
			printf("%lf %lf %lf\n", 0.5 * cos(phi), 0.5 * root2 * sin(phi), -0.5 * root2 * sin(phi));
			printf("%lf %lf %lf\n", 0.0, 0.5 * root2, 0.5 * root2);
			printf("%lf %lf %lf\n", 0.5 * sin(phi), -0.5 * root2 * cos(phi), 0.5 * root2 * cos(phi));
		}
	}
	return 0;
}
