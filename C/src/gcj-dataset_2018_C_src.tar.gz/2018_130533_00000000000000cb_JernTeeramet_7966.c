#include<stdio.h>
#include<string.h>
int damage(char str[])
{
    int l = strlen(str);
    int dmg = 1, result = 0;
    for(int i = 0 ; i < l ; i++)
    {
        if(str[i] == 'C') dmg *= 2;
        else result += dmg;
    }
    return result;
}
int min_damage(char str[])
{
    int l = strlen(str);
    int result = 0;
    for(int i = 0 ; i < l ; i++)
        if(str[i] == 'S') result += 1;
    return result;
}
int main()
{
    int t, d, counter, index;
    char p[30];
    scanf("%d", &t);
    for(int i = 1 ; i <= t ; i++)
    {
        scanf("%d %s", &d, p);
        printf("Case #%d: ", i);
        if(min_damage(p) > d)
            printf("IMPOSSIBLE\n");
        else
        {
            counter = 0;
            while(damage(p) > d)
            {
                for(int j = strlen(p) - 1; j > 0 ; j--)
                {
                    if(p[j] == 'S' && p[j-1] == 'C')
                    {
                        p[j] = 'C';
                        p[j-1] = 'S';
                        counter++;
                        break;
                    }
                }
            }
            printf("%d\n", counter);
        }
    }
    return 0;
}
