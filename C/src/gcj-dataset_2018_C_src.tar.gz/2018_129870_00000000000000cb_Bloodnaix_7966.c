#include <fstream>
#include <iostream>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include <cmath>
#include <memory.h>
#include <string>
#include <vector>
using namespace std;

int score(string s)
{
    int res = 0, power = 1;
    for(int i=0; i < s.size(); ++i)
    {
        if(s[i] == 'S')
        {
            res += power;
        }else // C
        {
            power *= 2;
        }
    }
    return res;
}

bool can_do_better(string s)
{
    for(int i = 1; i < s.size(); ++i)
    {
        if(s[i-1] == 'C' && s[i] == 'S')
        {
            return true;
        }
    }
    return false;
}

int main()
{

    int T;
    cin >> T;
    int d;
    string s;
    for(int t = 0; t < T; ++t)
    {
        cout << "Case #" << t+1 << ": ";
        cin >> d >> s;
        int dmg, counter = 0;
        while(true)
        {
            dmg = score(s);
            if(dmg <= d)
            {
                break;
            }
            if(!can_do_better(s))
            {
                counter = -1;
                break;
            }

            for(int i = s.size()-1; i > 0; --i)
            {
                if(s[i-1] == 'C' && s[i] == 'S')
                {
                    s[i-1] = 'S';
                    s[i] = 'C';
                    break;
                }
            }
            counter++;
        }
        if(counter < 0)
        {
            cout << "IMPOSSIBLE" << endl;
        }else
        {
            cout << counter << endl;
        }

    }
    return 0;
}


