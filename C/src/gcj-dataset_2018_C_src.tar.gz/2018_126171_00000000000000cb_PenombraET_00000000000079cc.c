#include <stdio.h>
#include <math.h>

const double F = 1.414213562;

int main(int argc, char** argv)
{
	int T;
	scanf("%d", &T);
	
	for (int i = 0; i < T; ++i)
	{
		double A;
		scanf("%lf", &A);
		printf("Case #%d:\n", i+1);
		printf("0.5 0 0\n");

		double S = sqrt(2 - A*A);
		printf("0 %.10lf %.10lf\n", (double) 1/4 * (A - S),  (double) 1/4 * (A + S));
		printf("0 %.10lf %.10lf\n", (double) 1/4 * (A + S), -(double) 1/4 * (A - S));
	}

	return 0;
}

