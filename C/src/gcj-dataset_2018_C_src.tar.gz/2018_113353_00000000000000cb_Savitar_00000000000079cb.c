#include <bits/stdc++.h>
using namespace std;

int main(){

    int T, N;

    cin >> T;

    int t = 0; 

    for(t = 0; t < T; t++){
        cin >> N; 

        vector<int> firstCC; 
        vector<int> secondCC;

        int i = 0; 
        int x;
        for(i = 0; i < N; i++){
            cin >> x; 
            if( i%2 == 0 ){
                firstCC.push_back(x);
            }else{
                secondCC.push_back(x);
            }
        }

        sort(firstCC.begin(), firstCC.end());
        sort(secondCC.begin(), secondCC.end());
        
        int k = 0; 
        int j = 0;
        int error = 0;
        int prev = firstCC[0];
        k = 1; 
        int current;
        for(i = 1; i < N; i++){
            if(i%2 == 0){
                current = firstCC[k];
                k++;
            }else{
                current = secondCC[j];
                j++;
            }
            if(prev > current){
                cout << "Case #" << (t+1) << ": " << (i-1) << "\n";
                error = 1;
                break;
            }

            prev = current;
        }

        if(!error){
            cout << "Case #" << (t+1) << ": OK\n";
        }

    }

    return 0;
}
