/*
 * Google Code Jam Qualification Round 2018 Problem D
 * "Cubic UFO"
 * Written by James Tai
 */

#if 1

/*
 * Analysis:
 * I have no clue.
 */

#include <math.h>
#include <stdio.h>

int main(void) {
    // I HAVE ABSOLUTELY NO IDEA WHAT I AM DOING
    int num_cases;
    scanf("%d", &num_cases); // NOLINT
    for (int case_num = 1; case_num <= num_cases; case_num++) {
        printf("Case #%d:\n", case_num);
        double x;
        scanf("%lf", &x); // NOLINT
        double v = x / sqrt(2.0);
        if (x <= 1.0 || v > 1.0) {
            // Whatever
            printf("0.5 0 0\n0 0.5 0\n0 0 0.5\n");
        } else {
            double t = M_PI / 4.0 - acos(v);
            printf("%.15lf %.15lf 0\n", 0.5 * sin(t), 0.5 * cos(t));
            printf("%.15lf %.15lf 0\n", -0.5 * cos(t), 0.5 * sin(t));
            printf("0 0 0.5\n");
        }
    }
}

#endif

