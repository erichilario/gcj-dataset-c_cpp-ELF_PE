#include <stdio.h>
#include <string.h>

int swap_most_right_cs(char *program) {
  int program_length = strlen(program);
  int i = program_length - 1; // last program instruction
  while (i > 0)
  {
    if (program[i - 1] == 'C' && program[i] == 'S') {
      program[i - 1] = 'S';
      program[i] = 'C';
      return 1;
    } else {
      i--;
    }
  }
  return 0;
}

int calculate_robot_damage(char *program)
{
  int total_damage = 0;
  int current_damage = 1;
  size_t i = 0;
  while (program[i] != '\0') {
    if (program[i] == 'S') {
      total_damage += current_damage;
    } else {
      current_damage *= 2;
    }
    i++;
  }
  return total_damage;
}

int solve(int max_damage, char *program)
{
  int swaps_done = -1;
  do
  {
    swaps_done++;
    int damage = calculate_robot_damage(program);
    if (max_damage >= damage) {
      return swaps_done;
    }
  } while (swap_most_right_cs(program));
  return -1;
}

int main()
{
  int t;
  scanf("%d", &t);
  for (int i = 0; i < t; i++) {
    char program[40];
    int d;
    scanf("%d %s", &d, program);
    int x = solve(d, program);
    if (x == -1)
    {
      printf("Case #%d: IMPOSSIBLE\n", i + 1);
    }
    else
    {
      printf("Case #%d: %d\n", i + 1, x);
    }
  }
}

