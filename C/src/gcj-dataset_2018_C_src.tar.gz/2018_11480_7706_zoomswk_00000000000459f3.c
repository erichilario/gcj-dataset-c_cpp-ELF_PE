#include <stdio.h>

int dp[505][505];

int max(int a, int b){ return a > b ? a : b; }

int main(){
    int T;
    scanf("%d", &T);
    
    int R = 50, B = 50;
    for(int i=0; i<=R; i++){
        for(int j=0; j<=B; j++){
            if(i == 0 && j == 0) continue;
            // this juggler is going to have i reds and j blues
            for(int a=R-i; a>=0; a--){
                for(int b=B-j; b>=0; b--){
                    dp[a+i][b+j] = max(dp[a+i][b+j], dp[a][b]+1);
                }
            }
        }
    }
    
    for(int tc=0; tc<T; tc++){
        int R, B;
        scanf("%d%d", &R, &B);
        printf("Case #%d: %d\n", tc+1, dp[R][B]);
    }
    return 0;
}

