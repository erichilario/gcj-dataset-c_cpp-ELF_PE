//submitted by Ujjwal9
#include<bits/stdc++.h>
#define ll long long
#define mod 1000000007
#define pb push_back
#define fi first
#define se second
#define fr(i,s,e) for(i=s;i<e;i++)
#define ms(arr,val) memset(arr,val,sizeof(arr))
using namespace std;
const int mxn=1e5;
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
  int t=1,tt=1;
  cin>>t;
    while(t--){
        ll d,n,i,ans=0,j;
        cin>>d;
        string s;
        cin>>s;
        n=s.size();
        ll sum=0;
        ll p[n];
        p[0]=1;
        if(s[0]=='C')
            p[0]=2;
        else
        sum+=1;
        fr(i,1,n)
        {
            if(s[i]=='C')
                p[i]=p[i-1]*2;
            else
            {
                p[i]=p[i-1];
                sum+=p[i];
            }
        }
        i=n-1;
        while(1)
        {
            if(sum<=d||i<0)
                break;
            if(s[i]=='S')
            {
                if(i-1>=0&&s[i-1]=='C')
                {
                    s[i]='C';
                    s[i-1]='S';
                    sum=sum-p[i]+p[i]/2;
                    p[i-1]=p[i]/2;
                    ans++;
                    if(i+1<n)
                    i++;
                    continue;
                }
            }
             i--;
        }
        cout<<"Case #"<<tt++<<": ";
        if(sum<=d)
            cout<<ans<<"\n";
        else
            cout<<"IMPOSSIBLE\n";


    }
  return 0;
  }
