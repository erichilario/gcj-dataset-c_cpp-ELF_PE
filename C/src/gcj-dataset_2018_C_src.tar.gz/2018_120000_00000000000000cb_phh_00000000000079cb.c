#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int cmpfnc(const void *a, const void *b) {
	return *(int*)a - *(int*)b;
}

int main() {
	int T;
	scanf("%d\n", &T);
	for(int i=0; i<T; i++) {
		int N;
		scanf("%d\n", &N);

		/*
		BURP Read array
		*/
		int arrayOddLen = N/2;
		int *arrayOdd = malloc(sizeof(int) * arrayOddLen);
		int arrayEvenLen = (N+1)/2;
		int *arrayEven = malloc(sizeof(int) * arrayEvenLen);
		size_t bufferLen = 10*N;
		char *buffer = malloc(bufferLen);
		getline(&buffer, &bufferLen, stdin);
		char *pos = buffer;

		for(int i=0; i<N; i++) {
			char *nextPos = index(pos, ' ');
			if(nextPos) nextPos[0] = 0;
			int v = atoi(pos);
			if( (i%2) == 0)
				arrayEven[i/2] = v;
			else
				arrayOdd[i/2] = v;
			pos = nextPos;
			if(!pos) break;
			pos++;
		}

		// Apply "Trouble sort"
		int failAt = -1;
		qsort(arrayOdd, arrayOddLen, sizeof(int), cmpfnc);
		qsort(arrayEven, arrayEvenLen, sizeof(int), cmpfnc);
		for(int i=0; i<arrayOddLen; i++) {
			//arrayOdd is +1 compared to arrayEven
			if(arrayOdd[i] < arrayEven[i]) {
				failAt = 2*i;
				break;
			}
			if((i+1) < arrayEvenLen && arrayEven[i+1] < arrayOdd[i]) {
				failAt = 2*i+1;
				break;
			}
		}
		if(failAt == -1) {
			printf("Case #%d: OK\n", i);
		} else {
			printf("Case #%d: %d\n", i, failAt);
		}
		free(buffer);
		free(arrayOdd);
		free(arrayEven);
	}
}

