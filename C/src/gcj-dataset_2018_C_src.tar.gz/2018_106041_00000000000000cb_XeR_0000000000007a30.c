#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define NDEBUG 1

void debugMap(char **map, size_t w, size_t h)
{
	size_t x, y;

	for(x = 0; x < w; x++) {
		for(y = 0; y < h; y++)
			fputc('0' + map[x][y], stderr);
		fputc('\n', stderr);
	}
}

int complete(char **cells, size_t w, size_t h)
{
	size_t x, y;

	for(x = 0; x < w; x++)
		for(y = 0; y < h; y++)
			if(cells[x][y] == 0)
				return 0;

	return 1;
}

void findBest(char **map, size_t w, size_t h, size_t *x, size_t *y)
{
	size_t i, j;

	*x = 1;
	*y = 1;

	for(i = 1; i < w - 1; i++) {
		for(j = 1; j < h - 1; j++) {
			if(map[i][j] < map[*x][*y]) {
				*x = i;
				*y = j;
			}
		}
	}
}

void updateMap(char **map, size_t w, size_t h, size_t x, size_t y)
{
	inline void increase(ssize_t x, ssize_t y)
	{
		if(x < 0 || x == w) return;
		if(y < 0 || y == h) return;
		map[x][y]++;
	}

	increase(x - 1, y - 1); increase(x, y - 1); increase(x + 1, y - 1);
	increase(x - 1, y    ); increase(x, y    ); increase(x + 1, y    );
	increase(x - 1, y + 1); increase(x, y + 1); increase(x + 1, y + 1);
}

int play(char **cells, char **map, size_t w, size_t h)
{
	ssize_t x, y;

	while(!complete(cells, w, h)) {
		findBest(map, w, h, &x, &y);

#ifndef NDEBUG
		fprintf(stderr, "(%ld, %ld) -> ", x + 1, y + 1);
#endif
		printf("%ld %ld\n", x + 1, y + 1);
		fflush(stdout);

		scanf("%ld %ld", &x, &y);
#ifndef NDEBUG
		fprintf(stderr, "(%ld, %ld)\n", x, y);
#endif

		if(x == 0 && y == 0)
			return EXIT_SUCCESS;

		if(x < 0 || y < 0)
			return EXIT_FAILURE;

		x--;
		y--;
		if(cells[x][y] == 0) {
			cells[x][y] = 1;
			updateMap(map, w, h, x, y);
		}

#ifndef NDEBUG
		fprintf(stderr, "--- cells ---\n");
		debugMap(cells, w, h);

		fprintf(stderr, "--- map ---\n");
		debugMap(map, w, h);
#endif
	}

	scanf("%ld %ld\n", &x, &y);
	if(x != 0 || y != 0)
		return EXIT_FAILURE;

	return EXIT_SUCCESS;
}

int test(size_t area)
{
	size_t  h, w;
	ssize_t i, j;
	int     ret;

	char **cells, **map;

	h = sqrt(area);
	w = (area + h - 1) / h;

#ifndef NDEBUG
	fprintf(stderr, "[%lu, %lu]\n", h, w);
#endif

	/* Allocates map */
	cells = calloc(w, sizeof(char*));
	map   = calloc(w, sizeof(char*));
	for(i = 0; i < w; i++) {
		cells[i] = calloc(h, sizeof(char));
		memset(cells[i], 0, h * sizeof(char));

		map[i] = calloc(h, sizeof(char));
		memset(map[i],  0, h * sizeof(char));
	}

	ret = play(cells, map, w, h);

	/* Free */
	for(i = 0; i < h; i++) {
		free(cells[i]);
		free(map[i]);
	}
	free(cells);
	free(map);

	return ret;
}

int main(int argc, char *argv[])
{
	size_t i, n;
	size_t area;
	int    ret;

	scanf("%lu", &n);

	for(i = 0; i < n; i++) {
		scanf("%lu", &area);

		if(EXIT_SUCCESS != (ret = test(area)))
			break;
	}

	return ret;
}

