#include <stdio.h>

int N;
int V[100000];

int solve_guchoku(void) {
	int done = 0;
	int i;
	while (!done) {
		done = 1;
		for (i = 0; i < N - 2; i++) {
			if (V[i] > V[i + 2]) {
				int t;
				done = 0;
				t = V[i];
				V[i] = V[i + 2];
				V[i + 2] = t;
			}
		}
	}
	for (i = 0; i + 1 < N; i++) {
		if (V[i] > V[i + 1]) return i;
	}
	return -1;
}

int main(void) {
	int T;
	int case_count;
	if (scanf("%d", &T) != 1) return 1;
	for (case_count = 1; case_count <= T; case_count++) {
		int i;
		int answer;
		if (scanf("%d", &N) != 1) return 1;
		for (i = 0; i < N; i++) {
			if (scanf("%d", &V[i]) != 1) return 1;
		}
		answer = solve_guchoku();
		printf("Case #%d: ", case_count);
		if (answer < 0) puts("OK"); else printf("%d\n", answer);
	}
	return 0;
}

/*

-----
3
5
5 4 3 2 1
5
4 5 3 2 1
5
4 3 5 2 1
-----

5 4 3 2 1
3 4 5 2 1
3 2 5 4 1
3 2 1 4 5
1 2 3 4 5

4 5 3 2 1
3 5 4 2 1
3 2 4 5 1
3 2 1 5 4
1 2 3 5 4

4 3 5 2 1
4 2 5 3 1
4 2 1 3 5
1 2 4 3 5

# of larger numbers before each numbers
0 1 2 3 4
0 0 2 3 4
0 1 0 3 4

5 6 8 4 3 -> 0 0 0 3 4
8 9 7 -> 0 0 2

*/

