#include <stdio.h>
#include <string.h>

char s[50];
int d,n;

int damage() {
	int c=1,i,tot=0;
	for(i=0;i<n;i++) {
		if(s[i]=='S') tot+=c;
		else c+=c;
	}
	return tot;
}

void solve() {
	int hack=0,i;
	scanf("%d %s",&d,s);
	n=strlen(s);
	while(d<damage()) {
		for(i=n-2;i>=0;i--) if(s[i]=='C' && s[i+1]=='S') {
			hack++;
			s[i]='S';
			s[i+1]='C';
			goto done;
		}
		puts("IMPOSSIBLE");
		return;
	done:;
	}
	printf("%d\n",hack);
}


int main() {
	int cases,caseno=1;
	scanf("%d",&cases);
	while(cases--) {
		printf("Case #%d: ",caseno++);
		solve();
	}
	return 0;
}

