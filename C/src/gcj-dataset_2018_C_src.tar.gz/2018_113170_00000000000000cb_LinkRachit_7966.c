#include <string>
#include <iostream>

int D;
std::string P;
const int maxvalue = 30;
int AT[maxvalue];
int lengthValue;

int FirstFunction()
{
    for(int i = lengthValue - 2 ; i >= 0; i--)
        if(AT[i] == 0 && AT[i+1] != 0)
            return i;
    return -1;
}

int CountValueTimes(int SumPlusPower, int Sheild, int CountValue)
{
    if(SumPlusPower <= Sheild)
        return CountValue;

    int index = FirstFunction();
    if(index == -1) return -1;
    std::swap(AT[index], AT[index + 1]);
    AT[index] /= 2;
    return CountValueTimes(SumPlusPower - AT[index], Sheild, CountValue + 1);
}

int main()
{
    int TC;
    std::cin >> TC;
    for(int tc = 1; tc <= TC ; tc++)
    {
        std::cin >> D >> P;
        lengthValue = (int)P.length();
        int power = 1;
        int SumPlusPower = 0;
        for(int i = 0 ;i < lengthValue ; i++)
        {
            if(P[i] == 'C')
            {
                power *= 2;
                AT[i] = 0;
            }
            else
            {
                AT[i] = power;
                SumPlusPower += power;
            }
        }
        int ans = CountValueTimes(SumPlusPower, D, 0);
        if(ans == -1)
            std::cout << "Case #" << tc << ": IMPOSSIBLE" << std::endl;
        else
            std::cout << "Case #" << tc << ": " << ans << std::endl;
    }
    return 0;
}

