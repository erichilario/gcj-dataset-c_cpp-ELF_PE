#include<stdio.h>
#include<stdlib.h>
#include<math.h>

typedef long long int int64;

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define ABS(a,b) ((a)>(0)?(a):-(a))

int slen(char *s){
  int i=0;
  while(s[i]!='\0') i++;
  return i;
}

int64 damage(char *s,int n){
  int64 d=1;
  int64 sum=0;
  int i;
  for(i=0;i<n;i++){
    if(s[i]=='C'){
      d*=2;
    } else {
      sum+=d;
    }
  }
  return sum;
}

void run(void){
  int t;
  scanf("%d",&t);
  for(;t>0;t--){
    int64 d;
    char s[32];
    scanf("%lld%s",&d,s);
    int p=slen(s);
    int k=0;
    while(damage(s,p)>d){
      int i;
      for(i=p-2;i>=0;i--){
	if(s[i]=='C' && s[i+1]=='S'){
	  k++;
	  char swap=s[i];
	  s[i]=s[i+1];
	  s[i+1]=swap;
	  break;
	}
      }
      if(i<0) break;
    }
    if(damage(s,p)<=d){
      printf("%d\n",k);
    } else {
      printf("IMPOSSIBLE\n");
    }
  }
}

int main(void){
  run();
  return 0;
}

