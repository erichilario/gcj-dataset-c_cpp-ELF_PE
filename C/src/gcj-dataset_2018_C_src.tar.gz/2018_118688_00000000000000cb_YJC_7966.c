#include <stdio.h>

#define MAXLEN 35

int solve(int D, char P[]) {
	int len = 0;
	int damage = 1, totDamage = 0;
	int cLen = 0, cPos[MAXLEN], cLev[MAXLEN];

	// count len & totDamage & cLen & cPos[] & cLev[]
	int minSum = 0;
	for (; P[len] != '\0'; ++len) {
		if (P[len] == 'C') {
			cPos[cLen] = len;
			cLev[cLen] = damage;
			damage <<= 1;
			++cLen;
		} else { // P[len] == 'S'
			totDamage += damage;
			++minSum;
		}
	}
	cPos[cLen] = len;
	cLev[cLen] = 0;

	// check if possible
	if (minSum > D) {
		return -1;
	}

	/* printf("totDamage = %d\tD = %d\n", totDamage, D); */
	/* for (int i = cLen - 1; i >= 0; --i) { */
	/* 	printf("%d%c", cPos[i], "\t\n"[i == 0]); */
	/* } */
	/* for (int i = cLen - 1; i >= 0; --i) { */
	/* 	printf("%d%c", cLev[i], "\t\n"[i == 0]); */
	/* } */

	// calculate minimal swap
	int totSwap = 0;
	int diff = totDamage - D;
	diff = (diff > 0)? diff : 0;
	for (int i = cLen - 1; i >= 0; --i) {
		int maxDefense = cLev[i] * (cPos[i + 1] - cPos[i] - 1);
		if (maxDefense >= diff) {
			totSwap += (diff / cLev[i]) + (diff % cLev[i] != 0);
			return totSwap;
		} else {
			diff -= maxDefense;
			totSwap += cPos[i + 1] - cPos[i] - 1;
			cPos[i] = cPos[i + 1] - 1;
		}
	}

	return totSwap;
}

int main () {
	int T;
	scanf("%d", &T);

	int D;
	char P[MAXLEN];
	for (int t = 1; t <= T; ++t) {
		scanf("%d", &D);
		scanf("%s", P);

		int ret = solve(D, P);

		if (ret == -1) {
			printf("Case #%d: IMPOSSIBLE\n", t);
		} else {
			printf("Case #%d: %d\n", t, ret);
		}
	}
	return 0;
}

