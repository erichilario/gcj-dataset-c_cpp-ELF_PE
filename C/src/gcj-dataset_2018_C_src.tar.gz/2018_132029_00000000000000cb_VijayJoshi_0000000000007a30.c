#include<stdio.h>
#define LIMIT 1000

int solve() {
     int A,i=2,j=2,I,J,k,l,flag,m,count=0,required;
     char f[1002][1002]={0};
     scanf("%d",&A);
     k=-1;l=-1;
     while(1) {
         for(m=0;m<9;m++) { 
             fflush(stdin);
             fflush(stdout);
             printf("%d %d\n",i,j);
             fflush(stdin);
             fflush(stdout);
             scanf("%d%d",&I,&J);
             if(I==-1 && J==-1)
               return -1;
             if(I==0 && J==0)
               return 0;
             f[I][J]=1;
             if(f[k][l]==1)
               break; 
         }
         flag=0;
         for(k=i-1;k<=(i+1);k++)
              for(l=1;l<=3;l++)
                if(f[k][l]==0) {
                  flag=1;
                  break;
                }
         if(flag==0) {
            count+=9;
            if(A>count) {
               required=A-count;
               if(required>6)
                  i+=3;
               else if(required<=6 && required>3)
                  i+=2;
               else
                  i++;
            }
            else
              return -1;
         }
     }
     return 0;
}
int main() {
    int T,t;
    scanf("%d",&T);
    while(T--) {
       t=solve();
       if(t==-1)
         break;
    }
    return 0;
}

