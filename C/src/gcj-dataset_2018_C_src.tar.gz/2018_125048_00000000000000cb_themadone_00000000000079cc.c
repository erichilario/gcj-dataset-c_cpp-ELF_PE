#include <stdio.h>
#include <math.h>

#define deg2rad(X) (((X)/180)*M_PI)
#define rad2deg(X) (((X)*180)/M_PI)

void rotate(long double x,long double y,long double z,long double angx,long double angz)
    {
    long double rx,ry,rz,rx2,rz2;

    rx=cosl(angx)*x-sinl(angx)*y;
    ry=sinl(angx)*x+cosl(angx)*y;
    rz=z;

    rx2=cos(deg2rad(angz))*rx+sin(deg2rad(angz))*rz;
    rz2=sin(deg2rad(angz))*rx+cos(deg2rad(angz))*rz;

    printf("%.16llf %.16llf %.16llf\n",rx2,ry,rz2);
    }

int main(int argc,char *argv[])
    {
    unsigned int num_tests,t;
    long double shadow;
    long double angx,angz,fortyfive;
    long double h=sqrt(0.5*0.5+0.5*0.5);
    fortyfive=asinl(0.5/h);

    scanf("%d\n",&num_tests);
    for(t=0;t<num_tests;t++)
        {
        if(scanf("%llf\n",&shadow)==1)
            {
            printf("Case #%d:\n",t+1);
            angx=asinl(shadow/(h*2.0));
            angx -= fortyfive;

            rotate(0.5, 0.0, 0.0, angx, angz);
            rotate(0.0, 0.5, 0.0, angx, angz);
            rotate(0.0, 0.0, 0.5, angx, angz);
            }
        }
    }

