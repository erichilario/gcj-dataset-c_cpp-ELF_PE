#include <stdio.h>
#include <stdlib.h>

int main(int argc,char *argv[])
    {
    unsigned int num_tests,t;
    unsigned int size;
    unsigned long long *nums;
    int ok,i;

    scanf("%d",&num_tests);
    for(t=0;t<num_tests;t++)
        {
        if(scanf(" %d",&size)==1)
            {
            ok=-1;
            nums=malloc(sizeof(unsigned long long)*size);
            for(i=0;i<size;i++)
                {
                scanf(" %ld",&nums[i]);
                if((ok==-1)&&(i>0))
                    {
                    if(nums[i]<nums[i-1])
                        {
                        ok=i-1;
                        }
                    }
                }
            if((size>4)&&(ok!=-1))
                {
                int done=0;
                ok=-1;
                while(!done)
                    {
                    done=1;
                    ok=-1;
                    for(i=0;i<size-1;i++)
                        {
                        if(i<size-2)
                            {
                            if(nums[i] > nums[i+2])
                                {
                                unsigned long long tmp=nums[i];
                                nums[i]=nums[i+2];
                                nums[i+2]=tmp;
                                done=0;
                                }
                            }
                        if(nums[i] > nums[i+1])
                            {
                            ok=i;
                            }
                        }
                    }
                    }

            if(ok<0)
                {
                printf("Case #%d: OK\n",t+1);
                }
            else
                {
                printf("Case #%d: %d\n",t+1,ok);
                }
            free(nums);
            }
        }
    }

