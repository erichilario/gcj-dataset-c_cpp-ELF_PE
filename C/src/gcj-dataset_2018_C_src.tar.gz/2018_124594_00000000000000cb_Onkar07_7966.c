#include <stdio.h>
#include<string.h>
int main(void) {
	
        int i,D,strength=1,n,k,Y,j,m,C,s,X,l;
        char T[100],swap;
        scanf("%d",&n);
        for(i=1;i<=n;i++)
        {
		C=0;
            scanf("%d",&D);
            scanf("%s",&T);
            for(j=0;j<strlen(T);j++)
            {
		for(k=0;k<strlen(T);k++)
		{
			Y=0;s=strength;
			for(m=0;m<strlen(T);m++)
           	 	{
			
                    	if(T[m]=='C')
                    	 s=2*s;
		    	else if(T[m]=='S')
			Y=Y+s;
			}
		if(Y>D)
		{	
		  if(T[k]=='C' && T[k+1]=='S')
                    {
                        swap=T[k];
                        T[k]=T[k+1];
                        T[k+1]=swap;
                        C++; 
                    }
		}
	 	}
	}
            
           if(Y>D)
            {
                printf("Impossible");
            }
		else
            {
                printf("CASE #%d=%d",i,C);
            }
        }
        

	return 0;
}
