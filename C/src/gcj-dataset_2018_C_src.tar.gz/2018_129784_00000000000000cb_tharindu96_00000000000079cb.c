#include <stdio.h>
#include <stdlib.h>

typedef unsigned int uint;
typedef unsigned long ulong;

void quicksort(ulong *arr, ulong *l, ulong *r);

void dispArray(ulong *arr, ulong size)
{
    for(ulong i = 0; i < size; i++)
    {
        printf("%lu, ", arr[i]);
    }
    printf("\n");
}

int solve(ulong *A1, ulong N1, ulong *A2, ulong N2, ulong *ret);

int main()
{
    // ulong arr[] = {
    //     5, 2, 3, 10, 4, 5, 6, 7
    // };
    // ulong size = 8;

    // dispArray(arr, size);
    // qsort(arr, &arr[0], &arr[size-1]);
    // dispArray(arr, size);

    uint T, t;
    int r;
    ulong N, N1, N2, tmp, i, j;
    ulong *A1;
    ulong *A2;

    scanf("%d", &T);
    for(t = 0; t < T; t++) {

        scanf("%lu", &N);
        N2 = N / 2;
        N1 = N - N2;
        A1 = (ulong*)malloc(sizeof(ulong)*N1);
        A2 = (ulong*)malloc(sizeof(ulong)*N2);
        for(i = 0; i < N; i++) {
            scanf("%lu", &tmp);
            j = i / 2;
            if(i % 2 == 0) {
                A1[j] = tmp;
            } else {
                A2[j] = tmp;
            }
        }

        r = solve(A1, N1, A2, N2, &tmp);

        printf("Case #%d: ", t+1);
        if(r == 0)
            printf("%lu", tmp);
        else
            printf("OK");
        printf("\n");


        free(A1);
        free(A2);
    }

    return 0;
}

void swap(ulong *a, ulong *b)
{
    ulong t = *a;
    *a = *b;
    *b = t;
}

void quicksort(ulong *arr, ulong *l, ulong *r)
{
    ulong *pivot = r;
    ulong *ll, *rr;
    ll = l;
    rr = r;
    r--;
    while(l <= r) {
        if(*l < *pivot) {
            l++;
            continue;
        }
        if(*r >= *pivot) {
            r--;
            continue;
        }
        swap(l, r);
        l++;
        r--;
    }
    swap(l, pivot);
    if(ll < l - 1)
        quicksort(arr, ll, l - 1);
    if(l + 1 < rr)
        quicksort(arr, l + 1, rr);
}

int solve(ulong *A1, ulong N1, ulong *A2, ulong N2, ulong *ret)
{

    quicksort(A1, A1, &A1[N1-1]);
    quicksort(A2, A2, &A2[N2-1]);

    for(ulong i = 0; i < N2; i++) {
        if(A1[i] > A2[i]) {
            *ret = i * 2;
            return 0;
        }
        if(N1 > i + 1 && A2[i] > A1[i+1]) {
            *ret = i * 2 + 1;
            return 0;
        }
    }

    return 1;
}
