
#include <stdio.h>
#include <math.h>

#define ROOT_EIGHTH (0.7071067811865476/2.0)

#define Pi 3.141592653589793

#define MAX_C2 1.7320508
#define MAX_C2_THETA  35.2643887

#define MAX_C1 (0.7071067811865476*2.0)
#define MAX_C1_THETA 45.0

double c1[]={0.0,0.0,0.5,
             0.5,0.0,0.0,
             0.0,0.5,0.0};

double c2[]={0.5,0.0,0.0,
             0.0, ROOT_EIGHTH, ROOT_EIGHTH,
             0.0, ROOT_EIGHTH, - ROOT_EIGHTH};

double c[9];

double rhomb[8];

void calc_rhombus(int a) {
    int b,cc;
    int i;
    double x,y;
    b=(a+1) % 3;
    cc=(a+2) % 3;
    a*=3;
    b*=3;cc*=3;
    for (i=0;i<4;i++) {
        rhomb[2*i]=c[a];
        rhomb[2*i+1]=c[a+1];
        x=c[b];
        y=c[b+1];
        if (i & 1) {
            rhomb[2*i]+=x;
            rhomb[2*i+1]+=y;
        } else {
            rhomb[2*i]-=x;
            rhomb[2*i+1]-=y;
        }
        x=c[cc];
        y=c[cc+1];
        if (i & 2) {
            rhomb[2*i]+=x;
            rhomb[2*i+1]+=y;
        } else {
            rhomb[2*i]-=x;
            rhomb[2*i+1]-=y;
        }
        
    }
}

double area_rhombus(void) {
    double a=0.0;
    a+=(rhomb[2]-rhomb[0])*(rhomb[3]+rhomb[1]);
    a+=(rhomb[6]-rhomb[2])*(rhomb[7]+rhomb[3]);
    a-=(rhomb[4]-rhomb[0])*(rhomb[5]+rhomb[1]);
    a-=(rhomb[6]-rhomb[4])*(rhomb[7]+rhomb[5]);
    if (a<0.0) a=-a;
    a*=0.5;
    return a;
}

double area(double theta, double *cc) {
    double *dd=c;
    int i;
    double a=0.0;
    theta=Pi/180.0*theta;
    for (i=0;i<3;i++) {
        dd[1]=cc[1]; // y unchanged
        dd[2]=cc[2]*cos(theta)+cc[0]*sin(theta);
        dd[0]=cc[0]*cos(theta)-cc[2]*sin(theta);
        cc+=3;
        dd+=3;
    }
    for (i=0;i<3;i++) {
        calc_rhombus(i);
        a+=area_rhombus();
    }
    return a;
}

void bisect(double *cc, double b, double A) {
    double a=0.0;
    double m;
    int i;
    for (i=0;i<30;i++) {
        m=(a+b)*0.5;
        if (area(m, cc)<A) a=m;
        else b=m;
    }
} 

void ufo(int casenum) {
    double A;
    scanf("%lf", &A);
    if (A>=MAX_C1) {
        bisect(c2,MAX_C2_THETA,A);
    } else {
        bisect(c1,MAX_C1_THETA,A);
    }
    printf("Case #%d:\n",casenum);
    printf("%.6f %.6f %.6f\n", c[0],c[1],c[2]);
    printf("%.6f %.6f %.6f\n", c[3],c[4],c[5]);
    printf("%.6f %.6f %.6f\n", c[6],c[7],c[8]);
}

int main(int argc, char **argv) {
    int i,T;
    scanf("%d", &T);
    for (i=1;i<=T;i++) {
        ufo(i);
    }
}

/*
int main(int argc, char **argv) {
    int i;
    double th,m,mth,aa;
    for (i=0; i<50; i+=1) {
        printf("area %d -> %.3f\n", i, area(1.0*i, c2));
        if (i==0) {
            printf("45 coords %.3f %.3f %.3f ;; %.3f %.3f %.3f ;; %.3f %.3f %.3f \n",
                    c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7], c[8]);
        }
    }
    printf("rt 1/8 = %.3f\n", ROOT_EIGHTH);
    m=-1.0; mth=-1.0;
    for (th=35.0;th<=36.0;th+=0.0000001) {
        aa=area(th,c2);
        if (aa>m) {m=aa;mth=th;}
    }
    printf("max at %.7f is %.7f\n",m,mth);
    return 0;
}
*/

