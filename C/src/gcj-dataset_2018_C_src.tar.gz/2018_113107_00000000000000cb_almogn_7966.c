#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <utility>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <time.h>
using namespace std;
#define forr(i,a,b,c) for(int i=a;i<b;i+=c)
#define fori(i,n) forr(i,0,n,1)
#define forn(i,n) forr(i,1,n,1)
#define fort(i,m,n) forr(i,m,n,1)
#define forin(i,arr) fori(i,arr.size())
#define into(i) cin >> i;
#define def(i) int i; into(i)
#define deft(t,i) t i; into(i)
#define defn def(n)
#define defp def(p)
#define defm def(m)
#define defk def(k)
#define defa def(a)
#define defb def(b)
#define defc def(c)
#define defd def(d)
#define vec(a) vector<a>
#define co cout <<
#define cas(p) co "Case #" << p+1 <<": ";
#define el << endl;
#define ex return 0; 
#define qii queue<int>
#define sti stack<int>
#define dei deque<int>
#define con continue;
#define br break;
#define out(i) co i <<' ';
#define outv(a,n) fori(iere,n){out(a[iere])} co "" el;
#define maxi 1000000013
#define mod %1000000007;
typedef vector<int> veci;
typedef long long lol;
typedef vector<lol> vecl;
#define table(name,n,m) vector<veci> name(n,veci (m));
#define tablel(name,n,m) vector<vecl> name(n,vecl (m));
typedef pair<int, int> point;
typedef pair<point, int> poin;
lol gcd(lol a, lol b) { 
	if (b==0) {
		return a;
	}
	return gcd(b, a%b);
}

int main() {
    ios::sync_with_stdio(false);
    defp
    fori(k,p){
        cas(k)
        defd deft(string,line)
        int n=line.size();
        int man=1;
        int sum=0;
        int count=0;
        veci a(n);
        fori(i,n){
            if(line[i]=='C'){
                man*=2;
            }else{
                a[i]=man;
                sum+=a[i];
            }
        }
        int i=n-1;
        int j=i;
        while(i>=0&&sum>d){
            if(j==n-1 || a[j]!=0){
                i--;
                j=i;
            }else{
                if(a[j+1]==0){
                    j++;
                    con
                }
                a[j]=a[j+1]/2;
                a[j+1]=0;
                count++;
                sum-= a[j];
                j++;
            }
        }
        if(sum<=d){
            co count el
        }else{
            co "IMPOSSIBLE" el
        }
    }
    ex
}
