#include <stdio.h>
#include <stdlib.h>

int comp (const void * elem1, const void * elem2) 
{
    int f = *((int*)elem1);
    int s = *((int*)elem2);
    if (f > s) return  1;
    if (f < s) return -1;
    return 0;
}

int main(int argc, char* argv[]) 
{	
	int T, N, even, odd, evenIndex = 0, oddIndex = 0, found = 0; 
	scanf("%d",&T);
	for(int t = 0; t < T; t++){
		printf("Case #%d: ",t+1);
		scanf("%d",&N);
		
		if (N % 2 == 0){
			even = N / 2;
			odd = N / 2;
		}
		else{
			even = (N + 1)/2;
			odd = (N - 1)/2;
		}
		
		int x[even], y[odd];
		
		for(int i = 0; i < N; i++){
			if (i % 2 == 0){
				scanf("%d", &x[evenIndex]);
				evenIndex++;
			}
			if (i % 2 == 1){
				scanf("%d", &y[oddIndex]);
				oddIndex++;
			}
		}	
    	qsort (x, sizeof(x)/sizeof(*x), sizeof(*x), comp);
    	qsort (y, sizeof(y)/sizeof(*y), sizeof(*y), comp);

/*		for (int i = 0 ; i < even ; i++){
        	printf ("%d ", x[i]);
		}
		printf("\n");
		for (int i = 0 ; i < odd ; i++){
        	printf ("%d ", y[i]);
        }
		printf("\n");
*/
		for (int i = 0; i < odd; i++){
			if (x[i] > y[i]){
				printf("%d\n", 2*i);
				found = 1;
				break;
			}
			if (i != odd - 1 || even > odd){	
				if (y[i] > x[i+1]){
					printf("%d\n", 2*i+1);
					found = 1;
					break;
				}
			}
		}
		if (found == 0){
			printf("OK\n");
		}
	}
    return 0;
}

