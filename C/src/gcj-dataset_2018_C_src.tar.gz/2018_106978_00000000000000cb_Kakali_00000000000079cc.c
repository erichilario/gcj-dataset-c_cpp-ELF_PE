#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double get_double();
int get_int();

typedef struct
{
	double x;
	double y;
	double z;
} tri;

tri rotate_z(tri p, double rad)
{
	tri ret;

	double c = cos(rad);
	double s = sin(rad);

	ret.x = p.x*c - p.y*s;
	ret.y = p.x*s + p.y*c;
	ret.z = p.z;

	return ret;
}

tri rotate_y(tri p, double rad)
{
	tri ret;

	double c = cos(rad);
	double s = sin(rad);

	ret.x = p.x*c + p.z*s;
	ret.y = p.y;
	ret.z = -p.x*s + p.z*c;

	return ret;
}

tri rotate_x(tri p, double rad)
{
	tri ret;

	double c = cos(rad);
	double s = sin(rad);

	ret.x = p.x;
	ret.y = p.y*c - p.z*s;
	ret.z = p.y*s + p.z*c;

	return ret;
}


tri rotate(tri p, double rad)
{
	tri ret;
	ret = rotate_z(p, rad);
	ret = rotate_x(ret, rad);

	return ret;
}

double area(tri a, tri b, tri c)
{
	double det1 = c.z - b.z;
	double det2 = c.z - a.z;
	double det3 = b.z - a.z;

	double detf = a.x*det1 - b.x*det2 + c.x*det3;

	return fabs(4.0*detf);
}



int main()
{
	int i;
	int n = get_int();

	for (i = 0; i < n; i++)
	{
		double t = get_double();

		tri p1, p2, p3;

		p1.x = 0.5;
		p1.y = 0.0;
		p1.z = 0.0;

		p2.x = 0.0;
		p2.y = 0.5;
		p2.z = 0.0;

		p3.x = 0.0;
		p3.y = 0.0;
		p3.z = 0.5;

		p1 = rotate_y(p1, M_PI/4.0);
		p2 = rotate_y(p2, M_PI/4.0);
		p3 = rotate_y(p3, M_PI/4.0);

		double a = area(p1, p2, p3);

		double rad = 0.95436;
		rad /= 2;
		int dbr = 0;
		while (fabs(t - a) > 1e-6)
		{
			if (dbr == -1)
			{
				break;
			}
			dbr++;

			if (t > a)
			{
				p1 = rotate_z(p1, rad);
				p2 = rotate_z(p2, rad);
				p3 = rotate_z(p3, rad);
			}
			else
			{
				p1 = rotate_z(p1, -rad);
				p2 = rotate_z(p2, -rad);
				p3 = rotate_z(p3, -rad);
			}
			a = area(p1, p2, p3);
			//printf("%.4f vs. %.4f theta = %.4f\n", a, t, rad);
			rad /= 2;
		}

		printf("Case #%d:\n", i + 1);
		printf("%.10f %.10f %.10f\n", p1.x, p1.y, p1.z);
		printf("%.10f %.10f %.10f\n", p2.x, p2.y, p2.z);
		printf("%.10f %.10f %.10f\n", p3.x, p3.y, p3.z);
		//printf("~~%.10f\n", p1.x*p1.x + p1.y*p1.y + p1.z*p1.z);
		//printf("~~%.10f\n", p2.x*p2.x + p2.y*p2.y + p2.z*p2.z);
		//printf("~~%.10f\n", p3.x*p3.x + p3.y*p3.y + p3.z*p3.z);
	}
}

int get_int()
{
	int ret = 0;
	char c  = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF)
		{
			return EOF;
		}
		if (c >= '0' && c <= '9')
		{
			sgn = 1;
			break;
		}
		if (c == '-')
		{
			c = getchar();

			if (c < '0' || c > '9')
			{
				continue;
			}

			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = (ret << 3) + (ret << 1) + c - '0';

		c = getchar();

		if (c < '0' || c > '9')
		{
			return sgn*ret;
		}
	}
}

double get_double()
{
	double ret = 0;
	char c     = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF)
		{
			return EOF;
		}
		if (c >= '0' && c <= '9')
		{
			sgn = 1;
			break;
		}
		if (c == '-')
		{
			c = getchar();

			if (c < '0' || c > '9')
			{
				continue;
			}

			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = ret*10 + c - '0';

		c = getchar();

		if (c == '.')
		{
			double pos = 0.1;

			c = getchar();
			while (c >= '0' && c <= '9')
			{
				ret += pos*(c - '0');
				pos /= 10;
				c = getchar();
			}

			return sgn*ret;
		}
		else if (c < '0' || c > '9')
		{
			return sgn*ret;
		}
	}
}

