#include<stdio.h>

int main()
{
    int t;
    scanf("%d",&t);
    while(t--){
        int a;
        scanf("%d",&a);
        int arr[1001][1001];
        for(int i = 0; i < 1001; i++){
            for(int j = 0; j < 1001; j++){
                arr[i][j] = 0;
            }
        }
        int x = 500, y = 500, f = 2, z = 0;
        while(x != 0 && y!= 0){
            int rx, ry;
            fflush(stdout);
            fprintf(stdout, "%d %d\n", x, y);
            fflush(stdout);
            scanf("%d%d", &rx, &ry);
            z++;
            if(rx == 0 && ry == 0)break;
            if(rx == -1 && ry == -1)return 0;
            arr[rx][ry] = 1;
            int flag = 1;
            for(int i = 0; i < 3; i++){
                for(int j = 0; j < 3; j++){
                    if(arr[x-1+i][y+1-j] != 1){
                        flag = 0;
                        break;
                    }
                }
            }
            if(flag){
                x += f;
                if(x >= 1000){
                    x = 500-2;
                    f = -2;
                }
            }
            if(z == 1001)break;
        }
    }
    return 0;
}
