#include<stdio.h>
int t, a, mp[4][71];
int A, B;
void init() {
	int i, j;
	for (i = 1; i <= 3; i++) {
		for (j = 1; j <= 70; j++) {
			mp[i][j] = 0;
		}
	}
}
void chk(int x, int y, int x1, int y1) {
	mp[x1 - x + 1][y1 - y + 1] = 1;
}
void go(int sx, int sy, int chx, int chy) {
	int i, j, zz=0;
	for (;;) {
		int z = 0, lx, ly;
		printf("%d\n%d\n", sx + chx, sy + chy);
		fflush(stdout);
		scanf("%d%d", &lx,&ly);
		mp[lx - sx][ly - sy] = 1;
		for (i = -1; i <= 1; i++) {
			for (j = -1; j <= 1; j++) {
				if (mp[i + chx][j + chy] == 0) {
					z = 1;
				}
			}
		}
		if (z == 0) { break; }
	}
	return;
}
int main() {
	scanf("%d%d", &t, &a);
	while (t--) {
		init();
		if (a == 20) {
			printf("%d\n%d\n", 50, 50);
			fflush(stdout);
			scanf("%d %d", &A, &B);
			int inita = A, initb = B;
			mp[1][1] = 1;
			int i, j;
			go(inita-1, initb-1, 2, 3);
			go(inita-1, initb-1, 2, 6);
			go(inita-1, initb-1, 2, 2);
		}
		else {//a==200
			printf("%d\n%d\n", 50, 50);
			fflush(stdout);
			scanf("%d %d",&A,&B);
			int inita = A, initb = B;
			mp[1][1] = 1;
			int i;
			for (i = 1; i <= 22; i++) {
				go(inita - 1, initb - 1, 2, i * 3);
			}
			go(inita - 1, initb - 1, 2, 2);
		}
	}
}
