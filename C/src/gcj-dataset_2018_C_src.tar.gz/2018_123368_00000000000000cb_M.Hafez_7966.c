#include <stdio.h>
#include <string.h>

long long int calculate_damage(char* p) {
  int i;
  long long int total_damage = 0, current_power = 1;

  for(i = 0; p[i]; ++i) {
    if(p[i] == 'S') {
      total_damage += current_power;
    }
    else { // if (p[i] == 'C')
      current_power *= 2;
    }
  }

  return total_damage;
}
int main() {
  int t, i, answer, tc = 0;
  long long int defense, total_damage;

  char p[50];

  scanf("%d", &t);
  while(t--) {
    scanf("%lld %s", &defense, p);

    total_damage = calculate_damage(p);

    answer = 0;
    while(total_damage > defense) {
      i = strlen(p) - 1;
      while(i > -1 && p[i] == 'C') {
        --i;
      }
      while(i > -1 && p[i] == 'S') {
        --i;
      }
      if(i > -1) {
        p[i] = 'S';
        p[i+1] = 'C';
        total_damage = calculate_damage(p);
        ++answer;
      }
      else {
        answer = -1;
        break;
      }
    }
    if (answer > -1) {
      printf("Case #%d: %d\n", ++tc, answer);
    }
    else {
      printf("Case #%d: IMPOSSIBLE\n", ++tc);
    }
  }
  return 0;
}

