#include <stdlib.h>
#include <stdio.h>
int comp(const void *a, const void *b) { return *(int *)a - *(int *)b; }
int main() {
	int T;
	scanf("%d", &T);
	for (int t = 1; t <= T; t++) {
		int N;
		scanf("%d", &N);
		int *V[2];
		V[0] = malloc((N / 2 + N % 2) * sizeof(int));
		V[1] = malloc(N / 2 * sizeof(int));
		int flipflop = 0;
		for (int i = 0; i < N; i++) { scanf("%d", V[flipflop] + i / 2); flipflop = !flipflop; }
		qsort(V[0], N / 2 + N % 2, sizeof(int), comp);
		qsort(V[1], N / 2, sizeof(int), comp);
		flipflop = 0;
		int found = 0;
		for (int i = 0; i < N - 1; i++) {
			if (V[flipflop][i / 2] > V[!flipflop][(i + 1) / 2]) {
				printf("Case #%d: %d\n", t, i);
				found = 1;
				break;
			}
			flipflop = !flipflop;
		}
		if (!found) printf("Case #%d: OK\n", t);
	}
	return 0;
}
