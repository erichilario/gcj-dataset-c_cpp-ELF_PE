#include<iostream>
#include<vector>
#include<string>
#include<queue>
#include<algorithm>
#include<cmath>
#include<cstring>
#define ll long long
using namespace std;
bool flag[3][3];
int main()
{
	int t, a;
	cin >> t;
	while (t--)
	{
		cin >> a;
		int r = sqrt(a / 9) + 1,midi = 2, midj = 2, pi, pj;
		for (int i = 0; i != r; ++i)
		{
			for (int j = 0; j != r; ++j)
			{
				int left = 9;
				memset(flag, 0, sizeof(flag));
				while (left)
				{
					cout << midi << " " << midj << endl;
					cin >> pi >> pj;
					if (pi == 0 && pj == 0)
						break;
					if (!flag[pi - midi + 1][pj - midj + 1])
					{
						--left;
						flag[pi - midi + 1][pj - midj + 1] = 1;
					}
				}
				if (pi == 0 && pj == 0)
					break;
				midj += 3;
			}
			if (pi == 0 && pj == 0)
				break;
			midi += 3;
		}
	}
	//system("pause");
	return 0;
}
