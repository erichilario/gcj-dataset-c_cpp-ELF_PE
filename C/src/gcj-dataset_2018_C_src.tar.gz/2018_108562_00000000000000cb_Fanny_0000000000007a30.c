
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>


int matrix[1001][1001];


int main(int argc, const char * argv[]) {
    
    
    
//    if (freopen("test.txt","r",stdin) == NULL) {
//        printf("error...");
//    }
//
//    test();
  
    
    int t;
    scanf("%d", &t);
    
    for (int i = 0; i < t; i++) {
        int a;
        scanf("%d", &a);
        if (a % 3) {
            a += (3 - a % 3);
        }
        memset(matrix, 0, sizeof(int) * 1001 * 1001);
        int height = a / 3;
        int base_x = 2, base_y = 500;
        int row = 0;
        while (row < height) {
            int col;
            for (col = 0; col < 3; col++) {
                if(matrix[base_x + row][base_y + col] == 0) {
                    break;
                }
            }
            if (col == 3) {
                row++;
                continue;
            }
            if (row == 0) {
                printf("%d %d\n", base_x + 1, base_y + 1);
            } else if (row == height - 1) {
                printf("%d %d\n", base_x + row - 2, base_y + 1);
            } else {
                printf("%d %d\n", base_x + row, base_y + 1);
            }
            fflush(stdout);
            int new_x, new_y;
            scanf("%d %d", &new_x, &new_y);
            if (new_x == 0 && new_y == 0) {
                break;
            } else {
                matrix[new_x][new_y] = 1;
            }
        }
    }
    return 0;
}
