#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int check(char *p,int j,int l)
{
	int i,k=1,m=0;
	for(i=0;i<l;i++)
	{

		if(p[i]<p[k])
		{
			int temp=p[i];
			p[i]=p[k];
			p[k]=temp;
			m++;
		}
		k++;
	}
	if(m==0)
		return 0;
	else
		return m;

}
void save_universe(int T,int *D,char *p)
{
	int k;
	for(k=0;k<T;k++)
	{
		int i;
		int j=D[i];
		int c;
		int len=strlen(p)+1;
		for(i=0;i<len;i++)
		{
			if(p[i]=='S')
				c++;
			if(c>j)
        	{
        	   printf("IMPOSSIBLE");
           	   break;
        	}
    	}
    	int f=check(&p,j,len);
    	printf("Case #%d:%d",T,f);
	}
}
void main()
{
	char p[30]="CSSCS";
	int T=6;
	int D[6]={3,4,3,7,2,5};
	save_universe(T,&D,&p);

}


