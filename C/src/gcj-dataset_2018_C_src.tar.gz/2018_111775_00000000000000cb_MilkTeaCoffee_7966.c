#include <stdio.h>  // includes cin to read from stdin and cout to write to stdout
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

int main(int argc,char* argv[]){
    int T,ct,D,i,n,len;
	int dmg;
	char P[32];
	int B[32];

	fscanf(stdin,"%d",&T);
	for (ct = 1; ct <= T; ++ct) {
		fscanf(stdin,"%d",&D);
		fscanf(stdin,"%s",P);
		len = strlen(P);

		n = 0; dmg = 0; B[0]= 1;
		for(i=0;i<strlen(P);i++){
			if(P[i]=='S'){
				n ++;
				dmg += B[i];
				B[i+1] = B[i];
			}
			else
				B[i+1] = B[i]*2;
		}
		if(n>D){
			printf("Case #%d: IMPOSSIBLE\n",ct);
			continue;
		}

		n = 0;
		while(dmg>D){
			for(i=len-1;i>0;i--){
				if(P[i]=='C')
					continue;
				if(P[i-1]=='C'){
					P[i] = 'C'; P[i-1] = 'S';
					dmg = dmg - B[i] + B[i-1];
					B[i] = B[i-1];
					break;
				}
			}
			n++;
		}
		printf("Case #%d: %d\n",ct,n);
	}
    
    return 0;
}
