#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define PI 3.14159265

int main(){


	int T = 0;
	double A = 0;
	double angle = 0;

	scanf("%d", &T);

	for(int t=1; t<=T; t++){

		//read
		scanf("%lf", &A);
	
		/*for(double alfa=0 ; alfa <= PI/2 ; alfa = alfa + (PI/18000)){
			double area = (cos((PI/4) - alfa)*sqrt(2));
			
			if( (A-0.0000005) < area && (area < (A+0.0000005))){
				angle = alfa;
				break;
			}
		}*/

		angle = PI/4 - acos(A/sqrt(2));

		//printf("%.7lf : %.7lf\n",angle, cos((PI/4) - angle)*sqrt(2));
		printf("Case #%d:\n",t);
		printf("%.7lf %.7lf 0\n", cos(angle)/2,-sin(angle)/2);
		printf("%.7lf %.7lf 0\n", sin(angle)/2,cos(angle)/2);
		printf("0 0 0.5\n");

	} //T

	
	return 0;
}







