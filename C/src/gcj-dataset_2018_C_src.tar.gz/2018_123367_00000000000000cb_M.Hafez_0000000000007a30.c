#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

int main() {
  int t, a, b;
  int i, j;
  char **grid;
  scanf("%d", &t);
  while(t--) {
    scanf("%d", &a);
    a = (int)sqrt(a);
    b = a + 1;
    grid = (char **) malloc((a+1) * sizeof(char*));
    for(i = 0; i < a; ++i) {
      grid[i] = (char*) malloc((b+1) * sizeof(char));
      memset(grid[i], 'U', (b+1) * sizeof(char));
      grid[i][b] = 0;
    }
    i = j = 2;
    while(i > 0 && j > 0 && i < a && j < b) {
      printf("%d %d\n", i, j);
      fflush(stdout);
      scanf("%d %d", &i , &j);
      if(i == -1 && j == -1) return -1;
      if(i == 0 && j == 0) break;
      --i; --j;
      grid[i][j] = 'P';
      // for(i = 0; i < a; ++i) {
      //   fprintf(stderr, "%s\n", grid[i]);
      // }
      // fprintf(stderr, "================================\n");
      // fflush(stderr);
      i = 0;
      while(i < a) {
        j = 0;
        while(j < b) {
          // fprintf(stderr, "grid[%d][%d]=%c\n", i, j, grid[i][j]);
          // fflush(stderr);
          if(grid[i][j] == 'U') {
            break;
          }
          ++j;
        }
        // fprintf(stderr, "second check grid[%d][%d]=%c\n", i, j, grid[i][j]);
        // fflush(stderr);
        if(grid[i][j] == 'U') {
          break;
        }
        else {
          ++i;
        }
      }
      ++i;
      ++j;
      if(i == 1) ++i;
      if(j == 1) ++j;
      if(i == a) --i;
      if(j == b) --j;
    }
    // fprintf(stderr, "grid[%d][%d]=%c, i = %d, j = %d\n", 1, 0, grid[1][0], i, j);
    // fprintf(stderr, "end of case\n");
    // fflush(stderr);
  }
  return 0;
}

