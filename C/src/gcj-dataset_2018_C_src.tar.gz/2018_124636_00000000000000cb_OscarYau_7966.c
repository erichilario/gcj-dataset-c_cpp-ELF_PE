#include <stdio.h>

typedef struct {
    unsigned long long maxDmg;
    char attk[31];
} robot;

unsigned long long dmgCal(char code[31], int len) {
    int i = 0;
    unsigned long long totalDmg = 0;
    unsigned long long stg = 1;
    for(i = 0; i < len; i++) {
        if(code[i] == 'C') {
            stg = stg * 2;
        }
        else if(code[i] == 'S') {
            totalDmg += stg;
        }
    }
    return totalDmg;
}

int hack(char code[31], int len) {
    int i = 0;
    for(i = len - 1; i > 0; i--) {
        if(code[i] == 'S') {
            if(code[i-1] == 'C') {
                code[i] = 'C';
                code[i-1] = 'S';
                return 0;
            }
        }
    }
    return -1;
}

int strlen(char code[31]) {
    int i = 0;
    for(i = 0; i < 31; i++) {
        if(code[i] == 0) {
            return i;
        }
    }
    return 30;
}

int main() {
    int T = 0;
    int i = 0, j = 0, len = 0, q = 0;
    unsigned long long D = 0;
    unsigned long long count = 0;
    scanf("%d", &T);
    for (i = 0; i < T; i++) {
        robot prog;
        prog.maxDmg = 0;
        q = 0;
        count = 0;
        for(j = 0; j < 31; j++) {
            prog.attk[j] = 0;
        }
        scanf("%llu %s", &prog.maxDmg, prog.attk);
        len = strlen(prog.attk);
        while(dmgCal(prog.attk, len) > prog.maxDmg) {

            if((q = hack(prog.attk, len)) == -1) {
                printf("Case #%d: IMPOSSIBLE\n", i + 1);
                break;
            }
            count++;
        }
        if(q != -1) {
            printf("Case #%i: %llu\n", i+1, count);
        }
    }
    return 0;
}

