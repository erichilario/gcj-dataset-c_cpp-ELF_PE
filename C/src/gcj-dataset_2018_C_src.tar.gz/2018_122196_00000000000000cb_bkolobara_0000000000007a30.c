#include<stdio.h>
#include<stdlib.h>

char o[30][30];

int is_completed(int i, int j) {
  return o[i-1][j-1] && o[i-1][j-0] && o[i-1][j+1] &&
         o[i-0][j-1] && o[i-0][j-0] && o[i-0][j+1] &&
         o[i+1][j-1] && o[i+1][j-0] && o[i+1][j+1];
}

void zero_out(int n, int m) {
  for(int i=0; i<n; i++) {
    for(int j=0; j<m; j++) {
      o[i][j] = 0;
    }
  }
}

void print_out(int n, int m) {
  for(int i=0; i<n; i++) {
    for(int j=0; j<m; j++) {
      int x = o[i][j];
      fprintf(stderr, "%d ", x);
    }
    fprintf(stderr, "\n");
  }
}

void walk(int n, int m) {
  int tries = 0;
  for(int i=1; i<n-1; i+=3) {
    for(int j=1; j<m-1; j+=3) {
      while(1) {
        tries++;
        if (tries == 1001){
          exit(3);
        }

        printf("%d %d\n", i+1, j+1);
        fflush(stdout);
        int i_, j_;
        scanf("%d %d", &i_, &j_);
        if (i_ == -1) {
          exit(4);
        }
        if (i_ == 0) {
          goto out;
        }
        o[i_-1][j_-1] = 1;
        if(is_completed(i, j)) {
          break;
        }
      }
    }
    
  }
  out: return;
}

int main() {
  int t, A;
  scanf("%d", &t);
  for (int i = 0; i < t; i++) {
    scanf("%d", &A);
    if (A == 20) {
      walk(10, 10);
      zero_out(10, 10);
    } else {
      walk(30, 30);
      zero_out(30, 30);
    }
  }
}
