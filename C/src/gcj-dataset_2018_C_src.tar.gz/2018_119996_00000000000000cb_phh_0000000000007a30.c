#include <stdio.h>
#include <math.h>
#include <string.h>

static int lastSize = 9;
static int h, w;
int count_square(int *array, int i, int j) {
	int c = 0;
	for(int I=-1; I < 2; I++) {
		for(int J=-1; J < 2; J++) {
			int newI = i + I;
			int newJ = j + J;
			if(!array[newI+100*newJ])
				c++;
		}
	}
	return c;
}

int find_next(int *array, int size) {
	int max = 0;
	int maxRes = 0;
	for(int i=1; i< ( w-1); i++) {
		for(int j=1; j< (h-1); j++) {
			int r = count_square(array, i, j);
			if(r == lastSize) return i + j*100;
		}
	}
	return 0;
}

int decide_next(int *array) {
	do {
		int ret = find_next(array, lastSize);
		if(ret == 0) {
			//fprintf(stderr, "Retrying with not as big size %d\n", lastSize);
		} else {
			return ret;
		}
	} while(lastSize--);
	fprintf(stderr, "HEHO\n");
	return -1;
}

int main() {
	int T;
	scanf("%d\n", &T);
	for(int i=0; i<T; i++) {
		lastSize = 9;
		int array[100*100];
		bzero(array, sizeof(array));
		int A;
		scanf("%d", &A);

		if(A > 72) {
			h = 12;
			w = (A+11)/12;
		} else {
			h = 3;
			w = (A+2)/3;
		}

		while(1) {
			int r = decide_next(array);
			int sendI = r % 100;
			int sendJ = r / 100;
			printf("%d %d\n", sendI+1, sendJ+1);
			fflush(stdout);

			int i, j;
			scanf("%d %d", &i, &j);
			if(i == 0 && j == 0) break;
			if(i == -1 && j == -1) return -1;
			i--;
			j--;
			array[i + 100*j] = 1;
		}
	}
}

