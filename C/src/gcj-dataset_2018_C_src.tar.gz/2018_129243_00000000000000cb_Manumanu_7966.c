#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */

int main() {
   
    int t, D;
    string inp;
    cin>>t;
    for (int i = 0;i<t;i++){
        cin>>D>>inp;
        int lenstr = inp.length();
        int arr[lenstr];
        for (int e = 0;e<lenstr;e++){
            arr[e] = -1;
        }
        int value = 1;int sum = 0;
        for (int e = 0;e<lenstr;e++){
            if (inp[e] == 'C'){
                value*=2;
            }
            else{
                arr[e] = value;
                sum+=value;
            }
        }
        int swaps = 0;bool toBreak= false;
        cout<<"Case #"<<i+1<<": ";
        for (int j = 0;j<lenstr;j++){
            if (toBreak){
                break;
            }
            for (int e= lenstr-1;e>0;e--){
                if (sum<=D){
                    cout<<swaps<<endl;
                    toBreak= true;
                    break;
                }
                if (inp[e] == 'S' && inp[e-1]=='C'){
                    //swap

                    swaps++;
                    inp[e] = 'C';
                    inp[e-1] = 'S';
                    arr[e-1] = arr[e]/2;
                    sum-= arr[e]/2;
                    arr[e] = -1;
                    if (sum<=D){
                        cout<<swaps<<endl;
                        toBreak= true;
                        break;
                    }

                }
            }
            
        }
        if (sum>D){
                 cout<<"IMPOSSIBLE"<<endl;
            }
    }
    return 0;
}
