#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int cmp(int* a, int* b)
{
    return *a - *b;
}

int map[30][30];

int main()
{
    int i,j,k;
    int x,y;
    int quit;
    int a;
    int ii,jj,kk;
    int now;
    int max;
    int res;
    int len;
    int count=0;
    int n,c,s,d;
    char line[1000];
    int ss[100];
    int ans;
    int sum;
    int end;

    scanf("%d", &kk);

    for(ii = 1; ii <= kk; ii++)
    {
        end = 0;
        memset(map, 0, sizeof(map));
        scanf("%d", &a);
        while(end != 1)
        {
            quit = 0;
            if(a == 20)
            {
                for(i = 0; i < 4; i++)
                {
                    for(j = 0; j < 5; j++)
                    {
                        if(map[i][j] == 0)
                        {
                            quit = 1;
                        }
                        if(quit)
                            break;
                    }
                    if(quit)
                        break;
                }
                if(i == 3)
                    i--;
                if(j == 4)
                    j--;
            }
            else if(a == 200)
            {
                for(i = 0; i < 20; i++)
                {
                    for(j = 0; j < 10; j++)
                    {
                        if(map[i][j] == 0)
                        {
                            quit = 1;
                        }
                        if(quit)
                            break;
                    }
                    if(quit)
                        break;
                }
                if(i == 19)
                    i--;
                if(j == 9)
                    j--;
            }
            if(i == 0)
                i++;
            if(j == 0)
                j++;

            //fprintf(stderr, "%d %d\n", i+1, j+1);
            printf("%d %d\n", i+1, j+1);
            fflush(stdout);

            scanf("%d %d", &x, &y);
            //fprintf(stderr, "%d %d\n", x, y);
            if(x == 0 && y == 0)
                end = 1;
            else
            {
                map[x-1][y-1] = 1;
            }
        }
    }
}

