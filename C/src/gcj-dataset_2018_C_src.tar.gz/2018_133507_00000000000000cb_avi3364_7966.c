#include <stdio.h>
#include<string.h>
int cnt;
int cnt1;

int check(long long int d,char arr[])
{
    int len;
    len=strlen(arr);
    int a=1,d1=0;
    for(int q=0;q<len;q++)
    {
        if(arr[q]=='C')
            a=2*a;
        else
            d1=d1+a;
    }
    if(d1>d)
        return 0;
    else
        return 1;
}

void foo(long long int d,char arr[])
{
    
        if(check(d,arr))
            return;
        int len=strlen(arr);
        for(int q=(len-1);q>=0;q--)
        {
            if((arr[q]=='C')&&(arr[q-1]=='C'))
                continue;
            else if((arr[q]=='S')&&(arr[q-1]=='C'))
            {
                char x=arr[q];
                arr[q]=arr[q-1];
                arr[q-1]=x;
                cnt++;
            }
            else
            {
                continue;
            }
            if(check(d,arr))
                return;
        }
        foo(d,arr);
    
}

int impossible(char arr[],long long int d)
{
    int len=strlen(arr);
    int p=0;
    for(int q=0;q<len;q++)
    {
        if(arr[q]=='S')
            p++;
        else
            continue;
    }
    if(d<p)
        return 1;
    else
        return 0;
}


int main(void) {
	int t;
	long long int d;
	char arr[30];
	scanf("%d",&t);
	for(int q=0;q<t;q++)
	{
	    cnt=0;cnt1=0;
	    scanf("%lld",&d);
	    scanf("%s",arr);
	    if(impossible(arr,d)==1)
	        printf("Case #%d: IMPOSSIBLE\n",q+1);
	   else
	   {
	        foo(d,arr);
	        printf("Case #%d: %d\n",q+1,cnt);
	   }
	}
	return 0;
}


