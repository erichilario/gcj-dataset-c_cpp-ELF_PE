#include<stdio.h>
void solve(int t) {
     long long int D,valOfS=1,tot_damage=0,ans=0,diff,reduced;
     int i,noOfS=0,noOfC=0,len,j,shifted,end;
     char P[35],temp;
     scanf("%lld%s",&D,P);
     for(i=0;P[i]!='\0';i++) {
       if(P[i]=='S') {
         noOfS++;
         tot_damage+=valOfS;
       } 
       else {
         noOfC++;
         valOfS=valOfS<<1;
       }
     }
     len=i;
     if(tot_damage<=D) {
        printf("Case #%d: 0\n",t);
        return;
     }
     if(noOfC==0 || noOfS>D) {
        printf("Case #%d: IMPOSSIBLE\n",t);        
        return;
     }

     diff=tot_damage-D;
     end=len-1;
     while(diff>0) {
         i=end;
         j=0;
         while(i>=0 && P[i]=='C') {
            i--;            
            valOfS>>=1;
         }
         while(i>=0 && P[i]=='S') {
            j++;
            i--;
         }
         
         reduced=(valOfS*j)>>1;
         if(reduced<=diff) {
            ans+=j;            
            valOfS>>=1;
            tot_damage-=reduced;
            diff=tot_damage-D;
            temp=P[end];
            P[end]=P[i];
            P[i]=temp;
         }   
         else {
              ans+=(diff*2/valOfS);
              diff=0;
         }
         end--;
     }
     
     printf("Case #%d: %lld\n",t,ans);
}
int main() {
    int T,t;
    scanf("%d",&T);
    for(t=1;t<=T;t++)               
        solve(t);
    return 0;
}

