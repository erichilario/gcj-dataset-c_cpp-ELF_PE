#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define P 100

size_t getScore(char *program, size_t size)
{
	size_t score;
	size_t i;

	score = 0;

	for(i = 0; i < size; i++) {
		if(program[size - 1 - i] == 'C')
			score *= 2;

		if(program[size - 1 - i] == 'S')
			score += 1;
	}

	return score;
}

int solve(unsigned long shield, char *program)
{
	size_t i;
	size_t count;
	size_t size;

	count = 0;
	size  = strlen(program);

	/* Determine if doable */
	for(i = 0; i < size; i++)
		if(program[i] == 'S')
			count++;

	/* If robot shoot more than shield, it's impossible */
	if(count > shield)
		return -1;

	/* Trim leftmost shoots : they cannot be avoided */
	while(size > 0 && program[0] == 'S') {
		program++;
		size--;
		shield--;
	}

	/* Trim rightmost charges : they are useless */
	while(size > 0 && program[size - 1] == 'C')
		size--;

	program[size] = 0;

	/* The best move is to swap the rightmost C with the next S */
	count = 0;
	while(getScore(program, size) > shield) {
		char *right;

		right = strrchr(program, 'C');
		right[0] = 'S';
		right[1] = 'C';

		if(right[2] == 0) {
			right[1] = 0;
			size--;
		}

		count++;
	}

	return count;
}

int main(int argc, char *argv[])
{
	size_t   i, n;

	unsigned long shield;
	char     program[P + 1];
	int      ret;

	scanf("%u", &n);

	for(i = 0; i < n; i++) {
		scanf("%u %s", &shield, program);

		printf("Case #%d: ", i + 1);

		ret = solve(shield, program);

		if(ret >= 0)
			printf("%d\n", ret);
		else
			puts("IMPOSSIBLE");
	}

	return EXIT_SUCCESS;
}

