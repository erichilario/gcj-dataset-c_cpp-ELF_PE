#include <stdio.h>
#include<string.h>
int cnt;
int cnt1;

int check(long long int d,char arr[])
{
    int len;
    len=strlen(arr);
    int a=1,d1=0;
    for(int q=0;q<len;q++)
    {
        if(arr[q]=='C')
            a=2*a;
        else
            d1=d1+a;
    }
    if(d1>d)
        return 0;
    else
        return 1;
}

void foo(long long int d,char arr[],char arr1[],int ex,int q1)
{
    if(check(d,arr1)==1)
    {
        if(cnt==0)
        {
            cnt=cnt1;
            cnt1=0;
            return;
        }
        if(cnt1<cnt)
        {
            cnt=cnt1;
            cnt1=0;
            return;
        }
        return;
    }
    else
    {
        int len=strlen(arr);
        for(int q=q1;q<(len-1);q++)
        {
            if(cnt1==0)
                strcpy(arr1,arr);
            if(arr1[q]==arr1[q+1]){
               ex=q; continue;}
            else
            {
                char z=arr1[q];
                arr1[q]=arr1[q+1];
                arr1[q+1]=z;
                cnt1++;
                q1++;
                if(ex>0){
                    q1=ex;ex=0;}
                foo(d,arr,arr1,ex,q1);
            }
        }
    }
}

int impossible(char arr[],long long int d)
{
    int len=strlen(arr);
    int p=0;
    for(int q=0;q<len;q++)
    {
        if(arr[q]=='S')
            p++;
        else
            continue;
    }
    if(d<p)
        return 1;
    else
        return 0;
}

void app(char arr[])
{
    int len=strlen(arr);
    for(int q=(len-1);q>=0;q--)
    {
        if(arr[q]=='C')
            arr[q]='\0';
        else if(arr[q]=='S')
            return;
        else
            continue;
    }
}

int main(void) {
	int t;
	long long int d;
	char arr[30];
	char arr1[30];
	scanf("%d",&t);
	for(int q=0;q<t;q++)
	{
	    cnt=0;cnt1=0;
	    scanf("%lld",&d);
	    scanf("%s",arr);
	    app(arr);
	    strcpy(arr1,arr);
	    if(impossible(arr,d)==1)
	        printf("Case #%d: IMPOSSIBLE\n",q+1);
	   else
	   {
	        foo(d,arr,arr1,0,0);
	        printf("Case #%d: %d\n",q+1,cnt);
	   }
	}
	return 0;
}


