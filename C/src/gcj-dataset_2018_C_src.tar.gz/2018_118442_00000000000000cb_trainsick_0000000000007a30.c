
#include <stdio.h>
#include <stdlib.h>

#define INTERACTIVE
/* TODO
 Keep perimeter out of priorityqueue
*/


typedef struct plot {
    struct plot *next, *prev;
    int x, y;
    int score;
    int basescore;
    int used;
} plot;

//#define WD 3
//#define HT 3


//#define WD 5
//#define HT 4

//#define WD 20
//#define HT 10

#define MAXWD 25
#define MAXHT 25

int A=9,WD,HT;

#define MAXPRI 900

plot priqueue[MAXPRI+1];
int toppriority;

plot garden[MAXHT][MAXWD];

unsigned int seed=12345;

void randomize(void) {
    FILE *fp;
    fp=fopen("/dev/urandom","r");
    fread(&seed, 1, sizeof(unsigned int), fp);
    fclose(fp);
}

void initqueue(void) {
    int i;
    plot *q;
    for (i=0;i<MAXPRI+1;i++) {
        q=priqueue+i;
        q->next=q->prev=q;
    }
}

void initgarden(void) {
    int x,y;
    int dx,dy;
    int count;
    plot *q, *p, *n;
    for (y=0;y<HT;y++) {
        for (x=0;x<WD;x++) {
            count=0;
            for (dy=y-1; dy<=y+1; dy++) {
                for (dx=x-1; dx<=x+1; dx++) {
                    if (dx>0 && dx<WD-1 && dy>0 && dy<HT-1) count++;
                }
            }
            garden[y][x].basescore=100/count;
            garden[y][x].y=y;
            garden[y][x].x=x;
        }
    }
    for (y=0;y<HT;y++) {
        for (x=0;x<WD;x++) {
            garden[y][x].score=0;
            for (dy=y-1; dy<=y+1; dy++) {
                for (dx=x-1; dx<=x+1; dx++) {
                    if (dx>=0 && dx<WD && dy>=0 && dy<HT) {
                        garden[y][x].score+=garden[dy][dx].basescore;
                    }
                }
            }
            if (x==0 || y==0 || x==WD-1 || y==HT-1) garden[y][x].score=0;
            if (garden[y][x].score>MAXPRI) {
                fprintf(stderr,"score %d is too big\n", garden[y][x].score);
                exit(-1);
            }
            garden[y][x].used=0;
            if (garden[y][x].score>0) {
                q=&(garden[y][x]);
                p=&(priqueue[garden[y][x].score]);
                n=p->next;
                q->prev=p;
                q->next=n;
                p->next=q;
                n->prev=q;
            }
            if (garden[y][x].score>toppriority) toppriority=garden[y][x].score;
        }
    }
}

int myrandom(int n) {
    seed=seed*69069+1;
    return (int)(1.0*n*seed/(65536.0*65536.0));
}

#ifdef INTERACTIVE
void request(int x, int y, int *retx, int *rety) {
    int x2,y2;
    printf("%d %d\n",x+10,y+10);
    fflush(stdout);
    scanf("%d %d",&x2, &y2);
    *retx=x2-10;
    *rety=y2-10;
}
#else
void request(int x, int y, int *retx, int *rety) {
    *retx=x-1+myrandom(3);
    *rety=y-1+myrandom(3);
    printf("request: want (%d,%d) got (%d,%d)\n",x,y,*retx, *rety);
}
#endif

void updatequeue(void) {
    while (toppriority>=0 && priqueue[toppriority].next==&(priqueue[toppriority]))
        toppriority--;
}

void fillin(int x, int y) {
    int dx,dy,base;
    plot *p,*q,*n;
    if (garden[y][x].score== -1) return;
    if (garden[y][x].used) return;
    
    garden[y][x].used=1;
    base=garden[y][x].basescore;
    for (dy=y-1;dy<=y+1;dy++) {
        for (dx=x-1; dx<=x+1; dx++) {
            if (dx<0 || dy<0 || dx>=WD || dy>=HT) continue;
            if (garden[dy][dx].score<= 0) continue;
            q=&(garden[dy][dx]);
            p=q->prev;
            n=q->next;
            p->next=n;
            n->prev=p;
            //if (x==dx && y==dy) {garden[dy][dx].score=-1; continue;}
            q->score-=base;
            if (q->score<=0) continue;
            p=&(priqueue[q->score]);
            n=p->next;
            q->prev=p;
            q->next=n;
            p->next=q;
            n->prev=q;
        }
    }
}

void calc_wd_ht(void) {
    int h;
    HT=0;
    while (!HT) {
        for (h=3;h*h<=A;h++) {
            if (A % h==0) {WD=A/h; HT=h;} 
        }
        A++;
    }
#ifndef INTERACTIVE
    printf("wd=%d ht=%d\n",WD,HT);
#endif
}

void gardening(void) {
    int numberrequests=0;
    int x, y;
    plot *q;
    calc_wd_ht();
    initqueue();
    initgarden();
    while (toppriority>0) {
        q=priqueue[toppriority].next;
        request(q->x, q->y, &x, &y);
        if (x==-10 && y==-10) break;
        if (x==-11 || y==-11) exit(-1);
        fillin(x,y);
        updatequeue();
        numberrequests++;
    }
#ifndef INTERACTIVE
    printf("%d\n",numberrequests);
#endif
}

#ifdef INTERACTIVE
int main(int argc, char **argv) {
    int i,T;
    //randomize();
    scanf("%d",&T);
    for (i=1;i<=T;i++) {
        scanf("%d",&A);
        gardening();
    }
    return 0;
}
#else
int main(int argc, char **argv) {
    randomize();
    gardening();
    return 0;
}
#endif

