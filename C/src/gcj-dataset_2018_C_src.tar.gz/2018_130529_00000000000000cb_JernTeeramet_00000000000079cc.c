#include <stdio.h>
#include <algorithm>
#include <vector>
#include <math.h>
using namespace std;

int main(){
    int T;
    scanf("%d", &T);
    for(int tc=1; tc<=T; tc++){
        double A;
        scanf("%lf", &A);
        long double theta = asinl((long double)A*A-1)/2;
        printf("Case #%d:\n", tc);
        double sinTheta = sinl(theta);
        double cosTheta = cosl(theta);
        printf("%.10lf %.10lf 0\n", -sinTheta/2, cosTheta/2);
        printf("%.10lf %.10lf 0\n", cosTheta/2, sinTheta/2);
        printf("0 0 0.5\n");
    }
    return 0;
}
