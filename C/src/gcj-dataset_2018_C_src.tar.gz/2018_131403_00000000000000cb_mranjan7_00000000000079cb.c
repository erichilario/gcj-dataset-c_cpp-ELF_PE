#include <stdio.h>

int main(void)
{
	void quick_sort(int A[],int p,int r);
	int partition(int A[],int p,int r);
	void print(int a[],int l);
	void counting_sort(int A[],int B[],int k,int l);
	void copy(int A[],int B[],int l);

	int T;
	scanf("%d",&T);
	for(int i = 0;i < T;i++)
	{
		int N;
		scanf("%d",&N);
		int V[N];
		for(int j = 0;j < N;j++)
		{
			scanf("%d",&V[j]);
		}
		if(N%2 == 0)
		{
			int V1[N/2];
			int V2[N/2];
			int index = 0;
			for(int j = 0;j < N/2;j++)
			{
				V1[j] = V[index];
				index = index +2;
			}
			index = 1;
			for(int j = 0;j < N/2;j++)
			{
				V2[j] = V[index];
				index = index + 2;
			}
			//print(V1,N/2);
			//print(V2,N/2);
			//quick_sort(V1,0,N/2-1);
			//quick_sort(V2,0,N/2-1);
			int B1[N/2];
			int B2[N/2];
			counting_sort(V1,B1,10,N/2);
			counting_sort(V2,B2,10,N/2);
			copy(V1,B1,N/2);
			copy(V2,B2,N/2);
			//print(V1,N/2);
			//print(V2,N/2);
			int V3[N];
			index = 0;
			for(int j = 0;j < N/2;j++)
			{
				V3[index] = V1[j];
				index = index + 2;
			}
			index = 1;
			for(int j = 0;j < N/2;j++)
			{
				V3[index] = V2[j];
				index = index + 2;
			}
			int isOK = 1;
			index = - 1;
			for(int j = 0;j < N-1;j++)
			{
				if(V3[j]>V3[j+1])
				{
					isOK = 0;
					index = j;
					break;
				}
			}
			if(isOK)
			{
				printf("Case #%d: OK\n",(i+1));	
			}
			else
			{
				printf("Case #%d: %d\n",(i+1),index);
			}

		}
		else
		{
			int V1[N/2+1];
			int V2[N/2];
			int index = 0;
			for(int j = 0;j < N/2+1;j++)
			{
				V1[j] = V[index];
				index = index +2;
			}
			index = 1;
			for(int j = 0;j < N/2;j++)
			{
				V2[j] = V[index];
				index = index + 2;
			}
			//print(V1,N/2+1);
			//print(V2,N/2);

			//quick_sort(V1,0,N/2);
			//quick_sort(V2,0,N/2-1);
			int B1[N/2+1];
			int B2[N/2];
			counting_sort(V1,B1,10,N/2+1);
			counting_sort(V2,B2,10,N/2);
			copy(V1,B1,N/2+1);
			copy(V2,B2,N/2);

			//print(V1,N/2+1);
			//print(V2,N/2);
			int V3[N];
			index = 0;
			for(int j = 0;j < N/2+1;j++)
			{
				V3[index] = V1[j];
				index = index + 2;
			}
			index = 1;
			for(int j = 0;j < N/2;j++)
			{
				V3[index] = V2[j];
				index = index + 2;
			}
			int isOK = 1;
			index = - 1;
			for(int j = 0;j < N-1;j++)
			{
				if(V3[j]>V3[j+1])
				{
					isOK = 0;
					index = j;
					break;
				}
			}
			if(isOK)
			{
				printf("Case #%d: OK\n",(i+1));	
			}
			else
			{
				printf("Case #%d: %d\n",(i+1),index);
			}

		}
	}
}
void quick_sort(int A[],int p,int r)
{
	if(p<r)
	{
		int q = partition(A,p,r);
		quick_sort(A,p,q-1);
		quick_sort(A,q+1,r);
	}
}

int partition(int A[],int p,int r)
{
	int x = A[r];
	int i = p-1;
	for(int j = p;j<r;j++)
	{
		if(A[j]<=x)
		{
			i = i+1;
			int temp =A[i];
			A[i]=A[j];
			A[j]=temp;
		}
	}
	i = i+1;
	int temp = A[r];
	A[r] = A[i];
	A[i] = temp;
	return i;
}
void print(int a[],int l)
{
	for(int i=0;i<l;i++)
	{
		printf("%i ",a[i]);
	}
	printf("\n");
}

void counting_sort(int A[],int B[],int k,int l)
{
	int C[k];
	for(int i=0;i<k;i++)
	{
		C[i] = 0;
	}
	for(int i=0;i<l;i++)
	{
		C[A[i]]=C[A[i]]+1;
	}
	//print(C,k);
	for(int i=1;i<k;i++)
	{
		C[i] = C[i]+C[i-1];
	}
	//print(C,k);
	for(int i = l-1;i>=0;i--)
	{
		//print(B,l);
		//print(C,k);
		B[C[A[i]]-1]=A[i];
		C[A[i]]=C[A[i]]-1;
	}
}

void copy(int A[],int B[],int l)
{
	for(int i = 0;i < l;i++)
	{
		A[i] = B[i];
	}
}

