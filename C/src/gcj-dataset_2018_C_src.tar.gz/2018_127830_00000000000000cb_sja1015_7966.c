#include<stdio.h>
#include<string.h>
int N;
char string[101];

struct AA {
	char str[101];
	int change_number;
}Queue[1000001];

void Process(int D,int M,int head,int tail,int Answer,int index)
{
	int i, j,temp=1,total=0;
	Queue[0].change_number = 0;
	strcpy(Queue[0].str, string);

	for (head = 0; head < tail; head++)
	{
		temp = 1; total = 0;
		for (i = 0; i < M; i++)
		{
			if (Queue[head].str[i] == 'S')
			{
				if (total > D)
					continue;
				total += temp;
			}
			else
			{
				if (temp > D)
					continue;
				temp *= 2;
			}
		}
		if (total <= D)
		{
			if (Queue[head].change_number <= Answer)
				Answer = Queue[head].change_number;
			continue;
		}
		for(i=0;i<M;i++)
			if(Queue[head].str[i]=='C')
				for(j=i+1;j<M;j++)
					if (Queue[head].str[j] == 'S')
					{
						strcpy(Queue[tail].str, Queue[head].str);
						Queue[tail].str[i] = 'S';
						Queue[tail].str[j] = 'C';
						Queue[tail].change_number = Queue[head].change_number + (j - i);
						tail++;
					}
	}
	if (Answer == 0x7fffffff)
	{
		printf("Case #%d: IMPOSSIBLE\n",index);
		return;
	}
	printf("Case #%d: %d\n", index,Answer);
}
void Input(int index)
{
	int i,D;
	for (i = 0; i < 100; i++)
		string[i] = 0;
	scanf("%d %s", &D, string);
	Process(D,strlen(string),0,1,0x7fffffff,index);
}
int main()
{
	int i;
	scanf("%d", &N);
	for (i = 0; i < N; i++)
		Input(i+1);
	return 0;
}
