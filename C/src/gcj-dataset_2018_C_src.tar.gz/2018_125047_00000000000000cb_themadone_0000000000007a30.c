#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define HEIGHT 32
#define WIDTH 32
#define gridloc(X,Y) ((X)+((Y)*WIDTH))

int main(int argc,char *argv[])
    {
    unsigned int num_tests,t;
    unsigned int size,curr;
    int x,y,rx,ry,cx,cy,top,left,bottom,right;
    unsigned int count;
    char grid[WIDTH*HEIGHT];

    scanf("%u",&num_tests);
    for(t=0;t<num_tests;t++)
        {
        scanf(" %u",&size);
//        fprintf(stderr,"target = %d\n",size);
        cx=WIDTH/2;
        cy=HEIGHT/2;
        curr=0;
        top=left=bottom=right=-1;
        memset(grid,0,sizeof(char)*WIDTH*HEIGHT);
//        fprintf(stderr,"==== %d\n",size);
        for(count=0;count<1000;count++)
            {
            if(curr > size)
                {
                for(x=left;x<=right;x++)
                    {
                    for(y=top;y<=bottom;y++)
                        {
                        if(grid[gridloc(x,y)]==0)
                            {
                            break;
                            }
                        }
                    if((y<=bottom)&&(grid[gridloc(x,y)]==0))
                        {
                        break;
                        }
                    }
                if((x==left)||(x<2))
                    {
                    x++;
                    }
                else if(x==right)
                    {
                    x--;
                    }
                if((y==top)||(y<2))
                    {
                    y++;
                    }
                else if(y==bottom)
                    {
                    y--;
                    }
                x += 100;
                y += 100;
                }
            else if(right==-1)
                {
                x=cx+100;
                y=cy+100;
                }
            else
                {
                if(bottom-top>right-left)
                    {
                    x=right+100;
                    y=cy+100;
                    }
                else
                    {
                    x=cx+100;
                    y=bottom+100;
                    }
                }

            printf("%d %d\n",x,y); fflush(stdout);
            scanf(" %d %d",&rx,&ry);
            if((rx==-1)||(ry==-1))
                {
                exit(0);
                }
            else if((rx==0)&&(ry==0))
                {
                break;
                }
            rx -= 100;
            ry -= 100;
//            fprintf(stderr,"--- %d %d %d %d %d %d\n",cx,cy,x-100,y-100,rx,ry);
            if((left==-1)||(rx<left))
                {
                left=rx;
                }
            if((right==-1)||(rx>right))
                {
                right=rx;
                }
            if((top==-1)||(ry<top))
                {
                top=ry;
                }
            if((bottom==-1)||(ry>bottom))
                {
                bottom=ry;
                }
            grid[gridloc(rx,ry)]=1;
            cx=(right+left)/2;
            cy=(top+bottom)/2;
            curr=(right-left+1)*(bottom-top+1);
//            fprintf(stderr,"%d %d %d %d = %d\n",left,top,right,bottom,curr);
            }
/*        for(y=top;y<=bottom;y++)
            {
            for(x=left;x<=right;x++)
                {
                fprintf(stderr,"%c",(grid[gridloc(x,y)] ? 'X' : ' '));
                }
            fprintf(stderr,"\n");
            }*/
        }
    }

