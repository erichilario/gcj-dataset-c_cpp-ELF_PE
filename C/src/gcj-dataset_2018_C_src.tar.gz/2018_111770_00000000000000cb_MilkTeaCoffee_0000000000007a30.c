#include <stdio.h>  // includes cin to read from stdin and cout to write to stdout
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

int cmp(const void *a,const void *b){
	return *(int *)a - *(int *)b;
}

int main(int argc,char* argv[]){
    int T,ct,A,k,n;
	int x,y,i,j,x0,y0;
	char G[100][100];

	fscanf(stdin,"%d",&T);
	for (ct = 1; ct <= T; ++ct) {
		fscanf(stdin,"%d",&A);
		for(i=0;i<100;i++)
			for(j=0;j<100;j++)
				G[i][j] = 0;

		n = 0;
		x0 = 11; y0 = 11;
		for(k=0;k<=64;k++){
			while(G[10][y0-1+k]==0 || G[11][y0-1+k]==0 || G[12][y0-1+k]==0){
				printf("%d %d\n",11,y0+k);
				fflush(stdout);
				fscanf(stdin,"%d %d",&x,&y);
				n++;
				if((x==-1&&y==-1)||(n==1000))
					exit(-1);
				
				if(x==0 && y==0)
					break;
				else 
					G[x][y] = 1;
			}
			if(x==0 && y==0)
				break;
		}
		if(x==0 && y==0)
			continue;
		

		while(G[10][75]==0 || G[11][75]==0 || G[12][75]==0){
			printf("%d %d\n",11,75);
			fflush(stdout);
			fscanf(stdin,"%d %d",&x,&y);
			n++;
			if((x==-1&&y==-1)||(n==1000))
				exit(-1);
		
			if(x==0 && y==0)
				break;
			else 
				G[x][y] = 1;
		}
		if(x==0 && y==0)
			continue;

		while(G[10][76]==0 || G[11][76]==0 || G[12][76]==0){
			printf("%d %d\n",11,75);
			fflush(stdout);
			fscanf(stdin,"%d %d",&x,&y);
			n++;
			if((x==-1&&y==-1)||(n==1000))
				exit(-1);
		
			if(x==0 && y==0)
				break;
			else 
				G[x][y] = 1;
		}
		if(x==0 && y==0)
			continue;
	}
    return 0;
}
