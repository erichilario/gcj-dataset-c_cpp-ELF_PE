#pragma warning(disable:4996)
#include<stdio.h>
int t, a;
int A, B;
void go(int sx, int sy, int chx, int chy) {
	int zz=0;
	for (zz=1;zz<34;zz++) {
		int z = 0, lx, ly;
		printf("%d %d\n", sx + chx, sy + chy);
		fflush(stdout);
		scanf("%d%d", &lx,&ly);
		if (z == 0) { break; }
	}
	return;
}
int main() {
	scanf("%d%d", &t, &a);
	while (t--) {
		if (a == 20) {
			printf("%d %d\n", 50, 50);
			fflush(stdout);
			scanf("%d%d", &A, &B);
			int inita = A, initb = B;
			int i, j;
			go(inita-1, initb-1, 2, 3);
			go(inita-1, initb-1, 2, 6);
			go(inita-1, initb-1, 2, 2);
		}
		else {//a==200
			printf("%d %d\n", 50, 50);
			fflush(stdout);
			scanf("%d%d",&A,&B);
			int inita = A, initb = B;
			int i;
			for (i = 1; i <= 22; i++) {
				go(inita - 1, initb - 1, 2, i * 3);
			}
			go(inita - 1, initb - 1, 2, 2);
		}
	}
}
