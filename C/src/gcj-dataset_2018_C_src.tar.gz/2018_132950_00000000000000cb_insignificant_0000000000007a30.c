#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

typedef uint8_t byte;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

#ifdef DEBUG
#  define debug(...) ({fprintf(stderr,__VA_ARGS__);fflush(stderr);})
#else
#  define NDEBUG
#  define debug(...)
#endif

int main(void)
{
	u32 T;
	scanf("%u",&T);
	do
	{
		u32 A;
		scanf("%u",&A);
		static const u32 x = 100,
		                 y = 100;
		if(A == 20)
		{
			for(u32 i = 0;i < 250;i++)
			{
				printf("%u %u\n",x + 1,y + 1);
				fflush(stdout);
				scanf(" %*[^\n]%*c");
			}
			for(u32 i = 0;i < 250;i++)
			{
				printf("%u %u\n",x + 3,y + 1);
				fflush(stdout);
				scanf(" %*[^\n]%*c");
			}
			for(u32 i = 0;i < 250;i++)
			{
				printf("%u %u\n",x + 1,y + 2);
				fflush(stdout);
				scanf(" %*[^\n]%*c");
			}
			for(u32 i = 0;i < 250;i++)
			{
				printf("%u %u\n",x + 3,y + 2);
				fflush(stdout);
				u32 u,v;
				scanf(" %u %u",&u,&v);
				if(u == 0 && v == 0)
					break;
			}
		}
		else
		{
			u32 X = x + 20,Y = y + 10;
			for(u32 i = y + 1,k;i < Y - 1;i += 3)
			{
				k = 0;
				debug("fill row\n");
				for(u32 j = x + 1;j < X - 2;j++)
				{
					debug("fill col\n");
					while((k & 7) != 7)
					{
						printf("%u %u\n",j,i);
						fflush(stdout);
						u32 u,v;
						scanf(" %u %u",&u,&v);
						k |= 1 << (u + 1 - j) * 3 + (v + 1 - i);
					}
					k >>= 3;
				}
				debug("finish row\n");
				do
				{
					printf("%u %u\n",X - 2,i);
					fflush(stdout);
					u32 u,v;
					scanf(" %u %u",&u,&v);
					k |= 1 << (u + 3 - X) * 3 + (v + 1 - i);
				}
				while(k != (1 << 9) - 1);
			}
			if(Y % 3 != 0)
			{
				debug("remaining row\n");
				u32 m = (1 << Y % 3) - 1;
				m = m | m << 3 | m << 6;
				u32 k = 0;
				for(u32 i = x + 1;i < X - 2;i++)
				{
					while((k & 7) != 7)
					{
						printf("%u %u\n",i,Y - 2);
						fflush(stdout);
						u32 u,v;
						scanf(" %u %u",&u,&v);
						k |= 1 << (u + 1 - i) * 3 + (v + 3 - Y);
					}
					k = (k | m) >> 3;
				}
				debug("final corner\n");
				do
				{
					printf("%u %u\n",X - 2,Y - 2);
					fflush(stdout);
					u32 u,v;
					scanf(" %u %u",&u,&v);
					if(u == 0 && v == 0)
						break;
				}
				while(1);
			}

		}
	}
	while(--T);
	return 0;
}

/* inspired by Andy Pham */

