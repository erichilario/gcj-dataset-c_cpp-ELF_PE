#include <iostream>
#include <cmath>

using namespace std;

double area(double alpha) {
    return M_SQRT2 * cos(M_PI_4 - alpha);
}

double prec = 1e-8;

int main() {
    cout.precision(15);

    size_t T;
    cin >> T;
    for(size_t t = 1; t <= T; t++) {
        double A;
        cin >> A;

        double min = 0;
        double max = M_PI / 4;
        double target = (max + min) / 2;
        double target_area = area(target);
        while(abs(target_area - A) > prec) {
            if(A >= target_area) {
                min = target;
            } else {
                max = target;
            }
            target = (max + min) / 2;
            target_area = area(target);
        }
        cout << "Case #" << t << ":\n";
        cout <<  cos(target) / 2 << ' ' << sin(target) / 2 << " 0\n";
        cout << -sin(target) /2 << ' ' << cos(target) /2 << " 0\n";
        cout << "0 0 0.5" << endl;
    }
    return 0;
}

