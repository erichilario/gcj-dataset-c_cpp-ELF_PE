#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main(void) {
	//fprintf(stderr, "main function started\n");
	
	int t;
	int i, j;
	scanf("%d", &t);
	
	
	for (i = 0; i < t; i++) {
		int a;
		scanf("%d", &a);
		
		int garden[10][100];
		
		if (a == 20) {
			// 3 * 7 ( == 21 )
			
			int neighbor[5];
			memset(garden, 0, sizeof(garden));
			memset(neighbor, 0, sizeof(neighbor));
			
			while(1) {
				int min = neighbor[0];
				int minIdx = 0;
				for (j = 0; j < 5; j++) {
					if (neighbor[j] < min) {
						min = neighbor[j];
						minIdx = j;
					}
				}
				
				printf("%d %d\n", 2, minIdx + 1);
				fflush(stdout);
				
				int actualX, actualY;
				scanf("%d %d", &actualX, &actualY);
				
				if (actualX == 0 && actualY == 0) {
					break;	
				} else {
					if (!garden[actualX][actualY]) {
						garden[actualX][actualY] = 1;
						for (j = 0; j < 5; j++) {
							if (abs(actualY - j - 1) <= 1) {
								neighbor[j]++;
							}
						}
					}
				}
			}	
			
		} else { 
			// a == 200
			// 3 * 67 ( == 201)
		}
	}
	
	return 0;
}

