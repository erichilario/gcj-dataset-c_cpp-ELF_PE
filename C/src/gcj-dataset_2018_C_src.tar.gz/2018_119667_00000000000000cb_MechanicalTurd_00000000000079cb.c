#include <stdio.h>
#include <stdlib.h>

static inline int comp(const void *a, const void *b) { return *(int *)a - *(int *)b; }

static int V[2][50000];

int main() {
	int T, N;
	scanf("%d", &T);
	for (int t = 1; t <= T; t++) {
		scanf("%d", &N);
		for (int n = 0; n < N; n++)
			scanf("%d", &V[n % 2][n / 2]);
		qsort(V[0], (N + 1) / 2, sizeof(int), comp);
		qsort(V[1], N / 2, sizeof(int), comp);
		int n;
		for (n = 0; n < N - 1; n++) {
			int a = V[n % 2][n / 2];
			int b = V[(n + 1) % 2][(n + 1) / 2];
			if (a > b)
				break;
		}
		if (n == N - 1)
			printf("Case #%d: OK\n", t);
		else
			printf("Case #%d: %d\n", t, n);
	}
	return 0;
}

