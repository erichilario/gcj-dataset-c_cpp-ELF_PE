#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int cmp(int* a, int* b)
{
    return *a - *b;
}

int odd[100000];
int even[100000];
int main()
{
    int i,j,k;
    int ii,jj,kk;
    int now;
    int max;
    int res;
    int len;
    int count=0;
    int n;
    int ans;
    int last;

    scanf("%d", &kk);

    for(ii = 1; ii <= kk; ii++)
    {
        scanf("%d", &n);

        for(i = 0; i < n; i++)
        {
            if(i % 2 == 0)
                scanf("%d", &even[i/2]);
            else
                scanf("%d", &odd[i/2]);
        }
        qsort(even, n/2+n%2, sizeof(int), cmp);
        qsort(odd, n/2, sizeof(int), cmp);
        ans = -1;
        
        for(i = 0; i < n; i++)
        {
            if(i > 0)
            {
                if(i % 2 == 0)
                {
                    if(even[i/2] < last)
                        ans = i;
                }
                else
                {
                    if(odd[i/2] < last)
                        ans = i;
                }
            }

            if(i % 2 == 0)
                last = even[i/2];
            else
                last = odd[i/2];
        }

        if(ans == -1)
            printf("Case #%d: OK\n", ii);
        else
            printf("Case #%d: %d\n", ii, ans-1);
    }
}

