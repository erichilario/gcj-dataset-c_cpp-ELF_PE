#include <stdio.h>

int main(void)
{
	void quick_sort(int A[],int p,int r);
	int partition(int A[],int p,int r);
	void print(int a[],int l);

	int T;
	scanf("%d",&T);
	for(int i = 0;i < T;i++)
	{
		int N;
		scanf("%d",&N);
		int V[N];
		for(int j = 0;j < N;j++)
		{
			scanf("%d",&V[j]);
		}
		if(N%2 == 0)
		{
			int V1[N/2];
			int V2[N/2];
			int index = 0;
			for(int j = 0;j < N/2;j++)
			{
				V1[j] = V[index];
				index = index +2;
			}
			index = 1;
			for(int j = 0;j < N/2;j++)
			{
				V2[j] = V[index];
				index = index + 2;
			}
			quick_sort(V1,0,N/2);
			quick_sort(V2,0,N/2);
			int isOK = 1;
			index = 0;
			for(int j = 0;j < N/2-1;j++)
			{
				if(V1[j]>V2[j])
				{
					isOK = 0;
					break;
				}
				index++;
				if(V2[j]>V1[j+1])
				{
					isOK = 0;
					break;
				}
				index++;
			}
			if(isOK)
			{
				printf("Case #%d: OK\n",(i+1));	
			}
			else
			{
				printf("Case #%d: %d\n",(i+1),index);
			}

		}
		else
		{
			int V1[N/2+1];
			int V2[N/2];
			int index = 0;
			for(int j = 0;j < N/2+1;j++)
			{
				V1[j] = V[index];
				index = index +2;
			}
			index = 1;
			for(int j = 0;j < N/2;j++)
			{
				V2[j] = V[index];
				index = index + 2;
			}
			//print(V1,N/2+1);
			//print(V2,N/2);

			quick_sort(V1,0,N/2);
			quick_sort(V2,0,N/2-1);
			int isOK = 1;
			index = 0;
			for(int j = 0;j < N/2;j++)
			{
				if(V1[j]>V2[j])
				{
					isOK = 0;
					break;
				}
				index++;
				if(V2[j]>V1[j+1])
				{
					isOK = 0;
					break;
				}
				index++;
			}
			//print(V1,N/2+1);
			//print(V2,N/2);
			if(isOK)
			{
				printf("Case #%d: OK\n",(i+1));	
			}
			else
			{
				printf("Case #%d: %d\n",(i+1),index);
			}
		}
	}
}
void quick_sort(int A[],int p,int r)
{
	if(p<r)
	{
		int q = partition(A,p,r);
		quick_sort(A,p,q-1);
		quick_sort(A,q+1,r);
	}
}

int partition(int A[],int p,int r)
{
	int x = A[r];
	int i = p-1;
	for(int j = p;j<r;j++)
	{
		if(A[j]<=x)
		{
			i = i+1;
			int temp =A[i];
			A[i]=A[j];
			A[j]=temp;
		}
	}
	i = i+1;
	int temp = A[r];
	A[r] = A[i];
	A[i] = temp;
	return i;
}
void print(int a[],int l)
{
	for(int i=0;i<l;i++)
	{
		printf("%i ",a[i]);
	}
	printf("\n");
}


