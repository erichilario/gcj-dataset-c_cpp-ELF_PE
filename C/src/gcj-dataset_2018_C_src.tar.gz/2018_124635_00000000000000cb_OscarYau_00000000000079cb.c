#include <stdio.h>

int main() {
    int T = 0;
    unsigned long long numList[100000], temp = 0;
    int N = 0;
    int i = 0, j = 0;
    int done = 0;
    scanf("%d", &T);
    for (i = 0; i < T; i++) {
        scanf("%d", &N);
        done = 0;
        for(j = 0; j < N; j++) {
            scanf("%llu", &numList[j]);
        }

        while(done == 0) {
            done = 1;
            for(j = 0; j < N - 2; j++) {
                if(numList[j] > numList[j+2]) {
                    done = 0;
                    temp = numList[j];
                    numList[j] = numList[j+2];
                    numList[j+2] = temp;
                }
            }
        }

        for(j = 0; j< N-1; j++) {
            if(numList[j] > numList[j+1]) {
                printf("Case #%d: %d\n", i +1, j);
                break;
            }
        }
        if(j == N-1) {
             printf("Case #%d: OK\n", i+1);
        }
    }
}

