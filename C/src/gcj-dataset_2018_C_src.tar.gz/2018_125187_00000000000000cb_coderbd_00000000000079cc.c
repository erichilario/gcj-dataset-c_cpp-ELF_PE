#include <stdio.h>
#include <math.h>

#define N 1000
#define PI 3.1415926536

double get_angle(double a) {
    int i;
    double low, mid, high, sum, PI_h, PI_q;
    
    PI_h = PI / 2;
    PI_q = PI / 4;
    low = 0.0;
    high = PI_q;
    for (i = 0; i < N; i++) {
        mid = (low + high) / 2.0;
        sum = cos(mid) + cos(PI_h-mid);
        if (sum < a)
            low = mid;
        else if (sum > a)
            high = mid;
    }
    
    return mid;
}

void solve(int case_no) {
    double area, angle;
    double p1_x, p1_y, p1_z;
    double p2_x, p2_y, p2_z;
    double p3_x, p3_y, p3_z;
    
    scanf("%lf", &area);
    angle = get_angle(area);
    
    p1_x = 0.5 * cos(angle);
    p1_y = 0.5 * sin(angle);
    p1_z = 0;
    
    p2_x = -0.5 * sin(angle);
    p2_y = 0.5 * cos(angle);
    p2_z = 0;
    
    p3_x = 0.0;
    p3_y = 0.0;
    p3_z = 0.5;
    
    printf("Case #%d:\n", case_no);
    printf("%.16f %.16f %.16f\n", p1_x, p1_y, p1_z);
    printf("%.16f %.16f %.16f\n", p2_x, p2_y, p2_z);
    printf("%.16f %.16f %.16f\n", p3_x, p3_y, p3_z);
}

int main(int argc, char* argv[]) {
    int i, t;
    
    scanf("%d", &t);
    for (i = 1; i <= t; i++)
        solve(i);
    
    return 0;
}

