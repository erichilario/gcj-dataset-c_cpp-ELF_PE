#include <stdio.h>  // includes cin to read from stdin and cout to write to stdout
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

int cmp(const void *a,const void *b){
	return *(int *)a - *(int *)b;
}

int main(int argc,char* argv[]){
    int T,ct,N,i,n,fail;
	int dmg;
	int arr[2][50000],len[2];

	fscanf(stdin,"%d",&T);
	for (ct = 1; ct <= T; ++ct) {
		fscanf(stdin,"%d",&N);

		len[0] = 0; len[1] = 0;
		for(i=0;i<N;i++){
			if(i%2==0)
				fscanf(stdin,"%d",&arr[0][len[0]++]);
			else
				fscanf(stdin,"%d",&arr[1][len[1]++]);
		}

		qsort(arr[0],len[0],sizeof(int),cmp);
		qsort(arr[1],len[1],sizeof(int),cmp);

		fail = 0;
		for(i=0;i<N-1;i++){
			if(i%2==0){
				if(arr[0][i/2]>arr[1][i/2]){
					fail = 1;
					break;
				}
			}
			else {
				if(arr[1][i/2]>arr[0][(i+1)/2]){
					fail = 1;
					break;
				}
			}
		}
		
		if(!fail)
			printf("Case #%d: OK\n",ct);
		else
			printf("Case #%d: %d\n",ct,i);
	}
    return 0;
}
