
#include <stdio.h>
#include <string.h>
#include <math.h>

#define eps 0.000001

int main(int argc, const char * argv[]) {
    int t;
    scanf("%d", &t);
    
    for (int i = 0; i < t; i++) {
        printf("Case #%d:\n", i + 1);
        double low = 0.0;
        double high = atan(1.0);
        double result = 1.0;
        double mid = 0.0;
        double target;
        scanf("%lf", &target);
        while(fabs(target - result) >= eps) {
            if (target < result) {
                high = mid;
                mid -= (high - low) / 2;
                result = sin(mid) + cos(mid);
            } else {
                
                low = mid;
                mid += (high - low) / 2;
                result = sin(mid) + cos(mid);
            }
        }
        double cos_num = cos(mid);
        double sin_num = sin(mid);
        printf("%.8lf %.8lf %.8lf\n", 0.5 * cos_num, 0.5 * sin_num, 0.0);
        printf("%.8lf %.8lf %.8lf\n", -0.5 * sin_num, 0.5 * cos_num, 0.0);
        printf("%.8lf %.8lf %.8lf\n", 0.0, 0.0, 0.5);
        
    }
    return 0;
}

