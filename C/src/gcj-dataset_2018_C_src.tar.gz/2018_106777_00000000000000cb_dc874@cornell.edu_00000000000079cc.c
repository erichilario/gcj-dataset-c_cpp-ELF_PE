
#include <iostream>
#include <cstdio>
#include <cstring>  
#include <string>
#include <cstdlib>
#include <cmath>
#include <cctype>
#include <ctime>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <cassert>
#include <bitset>
#define LD long double
#define LL long long 
using namespace std;
int n,m,cnt=0;
double area;
double alpha, beta;
double pi=acos(-1.0);
struct point3D
{
	double x,y,z;
	point3D(double _x=0, double _y=0, double _z=0):x(_x), y(_y), z(_z) {}
}A,B,C;
void print(point3D A)
{
	printf("%.10f %.10f %.10f\n",A.x, A.y, A.z);
}
struct point
{
	double x,y;
	point(double _x=0, double _y=0):x(_x), y(_y) {}
	point rotate(const double ang) 
	{ 
		return point(cos(ang) * x - sin(ang) * y, cos(ang) * y + sin(ang) * x);
	}
};
point3D rotate3D(point3D A, double alpha, double beta)
{
	point B=point(A.z, A.y).rotate(-alpha);
	point3D A2=point3D(A.x, B.y, B.x);
	B=point(A2.y, A2.x).rotate(-beta);
	return point3D(B.y, B.x, A2.z);
}
void work(int idx )
{
	scanf("%lf", &area);
	if (area<=sqrt(2.0))
	{
		alpha=pi/4-acos(area/sqrt(2.0));
		beta=0;
	}
	else 
	{
		alpha=pi/4;
		double l=0, r=2*atan(1.0/(sqrt(2.0)+sqrt(3.0)));
		while (abs(r-l)>1e-8)
		{
			double mid=(l+r)/2;
			double A=sqrt(2.0)*cos(mid)+sin(mid);
			if (A>area) r=mid;
			else l=mid;
		}
		beta=l;
	}
	//printf("%f %f\n",alpha, beta);
	A=point3D(0.5, 0, 0);
	B=point3D(0, 0.5, 0);
	C=point3D(0, 0, 0.5);
	A=rotate3D(A, alpha, beta);
	B=rotate3D(B, alpha, beta);
	C=rotate3D(C, alpha, beta);
	
	printf("Case #%d:\n",idx);
	print(A);
	print(B);
	print(C);
}
int main() 
{
	//print();
	int T=1;
	scanf("%d",&T);
	for (int i=1;i<=T;++i)
    {
        work(i);
    }
    return 0;
}



