#include <stdio.h>
#include <string.h>

int main(int argc, char** argv)
{
	char program[30];
	
	int T, D, S;
	scanf("%d", &T);
	
	for (int t = 0; t < T; ++t)
	{
		int Scount = 0;
		int Cposition = -1;
		
		scanf("%d", &D);
		scanf("%s", program);
		
		int len = strlen(program);

		for (int step = 0; step < len; ++step) {
			if (program[step] == 'S')
				Scount++;
			else if (program[step] == 'C')
				Cposition = step;
		}	
		
		if (Scount > D) {
			printf("Case #%d: IMPOSSIBLE\n", t + 1);
		}
		else {
			printf("Case #%d: %d\n", t + 1, 2 * len - D - Cposition - 2);
		}				
	}
	
	return 0;
}

