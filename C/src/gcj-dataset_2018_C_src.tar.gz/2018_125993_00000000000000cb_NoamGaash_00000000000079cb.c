// reading from stdin

process.stdin.resume();
process.stdin.setEncoding('utf8');

var buffer = "";

process.stdin.on('data', function(chunk) {
    buffer+=chunk;

});

process.stdin.on('end', function() {
    buffer.trim().split('\n').forEach(processLine);
});



// parsing input

var tCase = -1;
function processLine(line){
	tCase++;
	if(tCase===0) return;
	if(tCase%2 == 1){
		return;
	}
    console.log("Case #"+(tCase/2)+": "+solveTestCase(line.trim()));
}

// solve

function solveTestCase(caseline){
	caseline = caseline.split(" ").map(x=>+x);
	tripleSort(caseline);
	for(var i=0; i<caseline.length-1; i++){
		if(caseline[i]>caseline[i+1])
			return i;
	}
	return "OK";
}


function tripleSort(arr){
	var done=false;
	while(!done){
		done=true;
		for (var i = 0; i < arr.length-2; i++)
        	if(arr[i] > arr[i+2]){
				done = false;
				var temp = arr[i+2];
				arr[i+2] = arr[i];
				arr[i] = temp;
			}
		
	}
}

