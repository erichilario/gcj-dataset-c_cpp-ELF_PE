#include <stdio.h>
#include <stdlib.h>

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

int main() {
  int t, tc = 0;
  int n, i;
  int even[50050], odd[50050];
  int result[100010];
  scanf("%d", &t);

  while(t--) {
    scanf("%d", &n);
    for(i = 0; i < n; ++i) {
      if(i%2 == 0) {
        scanf("%d", &even[i/2]);
      }
      else {
        scanf("%d", &odd[i/2]);
      }
    }
    qsort(even, n/2 + n%2, sizeof(int), cmpfunc);
    qsort(odd, n/2, sizeof(int), cmpfunc);
    for(i = 0; i < n; ++i) {
      if(i%2 == 0) {
        result[i] = even[i/2];
      }
      else {
        result[i] = odd[i/2];
      }
    }
    for(i = 0; i < n-1; ++i) {
      if(result[i] > result[i+1]) {
        break;
      }
    }
    if(i < n-1) {
      printf("Case #%d: %d\n", ++tc, i);
    }
    else {
      printf("Case #%d: OK\n", ++tc);
    }
  }
}
// int main() {
//   int t, tc = 0;
//   int n, i;
//   int min_even, min_odd;
//   int max_even, max_odd;
//   int valid;
//
//   int arr[100010];
//
//   scanf("%d", &t);
//
//   while(t--) {
//     scanf("%d", &n);
//     min_even = min_odd = 1 << 31;
//     max_even = max_odd = 0;
//     for(i = 0; i < n; ++i) {
//       scanf("%d", &arr[i]);
//       if(i%2 == 0) {
//         if(arr[i] > max_even) {
//           max_even = arr[i];
//         }
//         if(arr[i] < min_even) {
//           min_even = arr[i];
//         }
//       }
//       else {
//         if(arr[i] > max_odd) {
//           max_odd = arr[i];
//         }
//         if(arr[i] < min_odd) {
//           min_odd = arr[i];
//         }
//       }
//     }
//
//     valid = 1;
//     if(n%2 == 0) {
//       if(min_odd < min_even) {
//         valid = 0;
//         i = 1;
//       }
//       else if(max_even > max_odd) {
//         valid = 0;
//         i = n-2;
//       }
//     }
//     else {
//       if(min_odd < min_even) {
//         valid = 0;
//         i = 1;
//       }
//       else if(max_odd > max_even) {
//         valid = 0;
//         i = n-2;
//       }
//     }
//     if(valid) {
//       printf("Case #%d: OK\n", ++tc);
//     }
//     else {
//       printf("Case #%d: %d\n", ++tc, i);
//     }
//   }
//   return 0;
// }

// #include <stdio.h>
//
// int main() {
//   int t, tc = 0;
//   int i, n;
//   int arr[100010];
//   int done;
//   scanf("%d", &t);
//   while(t--) {
//     scanf("%d", &n);
//     for(i = 0; i < n; ++i) {
//       scanf("%d", &arr[i]);
//     }
//     done = 0;
//     while(!done) {
//       done = 1;
//       for(i = 0; i < n - 2; ++i) {
//         if(arr[i] > arr[i+2]) {
//           arr[i] += arr[i+2];
//           arr[i+2] = arr[i] - arr[i+2];
//           arr[i] -= arr[i+2];
//           done = 0;
//         }
//       }
//     }
//     for(i = 0; i < n-1; ++i) {
//       if(arr[i] > arr[i+1]) {
//         break;
//       }
//     }
//     if(i < n-1) {
//       printf("Case #%d: %d\n", ++tc, i);
//     }
//     else {
//       printf("Case #%d: OK\n", ++tc);
//     }
//   }
//   return 0;
// }

