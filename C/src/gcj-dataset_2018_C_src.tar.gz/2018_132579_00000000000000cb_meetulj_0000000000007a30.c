#include <stdio.h>
#include <math.h>
#include <stdlib.h>


void main()
{
//FILE* han2=fopen("meetul.txt","w");

int T = 0, A = 0;

int** arr = (int**)malloc(sizeof(int*)*1000);
int i, j;
for (i = 0; i < 1000; i++) {
	arr[i] = (int*)malloc(sizeof(int)*1000);
	for (j = 0; j < 1000; j++)
		arr[i][j] = 0;
}

scanf("%d", &T);

int t = 0;
for (t = 0; t < T; t++) {
scanf("%d", &A);

int N = sqrt(A);
while(A%N != 0)
	N--;

int M = A/N;
	
	if(N<3)
		N=3;
	if(M<3)
		M=3;
	
int maxi=N-1;
int maxj=M-1;
	
	//origin
int oi=2;
int oj=2;
	
	//current center
int ci=oi;
int cj=oj;
	
//fprintf(han2, "Before array\n"); fflush(han2);
//int** arr = (int**)malloc(sizeof(int*)*(N+1));
int i, j;
for (i = 0; i <= N; i++) {
//	arr[i] = (int*)malloc(sizeof(int)*(M+1));
	for (j = 0; j <= M; j++)
		arr[i][j] = 0;
}
//memcpy(arr, sizeof(int)*1000*1000, 0);

int totalAttempts=0;
//fprintf(han2,"T: %d;\nA: %d;\nN: %d; M: %d;\n", T, A, N, M);
//fflush(han2);
int done = 0;
	do
	{
	
		while(!(arr[ci-1][cj-1] && arr[ci-1][cj] && arr[ci-1][cj+1] && arr[ci][cj-1] && arr[ci][cj] && arr[ci][cj+1] && arr[ci+1][cj-1] && arr[ci+1][cj] && arr[ci+1][cj+1]))
		{
		//	fprintf(han2, "before echo\n");
			//fflush(han2);
			printf("%d %d\n", ci, cj);
			fflush(stdout);
		//	fprintf(han2, "after echo\n");
		//	fprintf(han2, "before scanf\n");
		//	fflush(han2);

			scanf("%d %d", &i, &j);
			
			if (!i && !j) {
				done = 1;
				break;
			}
		//	else if (i == -1 || j == -1) {
		//		exit(1);
		//	}
		//	fprintf(han2, "after scanf\n");
		//	fflush(han2);
		//	fprintf(han2, "I: %d, j: %d\n", i, j);
		//	fflush(han2);
			arr[i][j]=1;
			totalAttempts++;
		//	fprintf(han2,"ci:%d, cj: %d, totalAttempts: %d\n\n\n", ci, cj, totalAttempts);
		//	fflush(han2);
		}
		
		if (done)
			break;
				
		//(han2,"ci:%d, cj: %d, totalAttempts: %d\n\n\n", ci, cj, totalAttempts);
		
		if (ci == maxi && cj == maxj)
			break;
		if(ci+3 < N)
			ci=ci+3;
		else if(ci+2 < N)
			ci=ci+2;
		else if(ci+1 < N)
			ci=ci+1;
		else
		{
			ci=oi;
			if(cj+3 < M)
				cj=cj+3;
			else if(cj+2 < M)
				cj=cj+2;
			else if(cj+1 < M)
				cj=cj+1;
		}
	}while(1);	

	//file_put_contents("meetul.txt","T: ".T.";\nA: ".A.";\nN: N; M: M;\nTotal Attempts: totalAttempts;\n Values: ".print_r(arr, true));
//	for (i = 0; i <= N; i++) {
//		free(arr[i]);
//	}
//	free(arr);
}
	//fclose(han2);

}
