#include <iostream>
#include <cstdio>
#include <map>
#include <set>
using namespace std;

int main() {
    int T;
    scanf("%d", &T);
    for (int t = 0; t<T; t++) {
        int A;
        scanf("%d", &A);
        bool b[6][100];
        int cnt[100];
        memset(b,0,sizeof(b));
        memset(cnt,0,sizeof(cnt));
        map<int, set<int> > m;
        int x=2, y=2, i=-1, j=-1, sx=-1, sy = -1;
        printf("%d %d\n", x, y);
        fflush(stdout);
        scanf("%d%d", &i, &j);
        while (i!=0 || j!=0) {
            if (!b[i][j]) {
                b[i][j] = true;
                if (sx==-1) {
                    sx = i;
                    sy = j;
                    set<int> s;
                    for (int yi = sy+1; yi<sy+A/3; yi++) {
                        s.insert(yi);
                    }
                    m[0] = s;
                }
                
                for (int yi = max(sy+1, j-1); yi<min(j+2, sy+A/3); yi++) {
                    if (m[cnt[yi]].find(yi) != m[cnt[yi]].end()) {
                        m[cnt[yi]].erase(yi);
                        if (m[cnt[yi]].empty()) {
                            m.erase(cnt[yi]);
                        }
                    }
                    cnt[yi]++;
                    m[cnt[yi]].insert(yi);
                }
            }
            int next = *(m.begin()->second.begin());
            printf("%d %d\n", sx+1, next);
            fflush(stdout);
            scanf("%d%d", &i, &j);
        }
    }
    return 0;
}

