#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int cmp(int* a, int* b)
{
    return *a - *b;
}

int main()
{
    int i,j,k;
    int ii,jj,kk;
    int now;
    int max;
    int res;
    int len;
    int count=0;
    int n,c,s,d;
    char line[1000];
    int ss[100];
    int ans;
    int sum;

    scanf("%d", &kk);

    for(ii = 1; ii <= kk; ii++)
    {
        scanf("%d %s", &d, line);

        c = 0;
        s = 0;
        ans = 0;
        memset(ss, -1, sizeof(ss));
        for(i = 0; i < strlen(line); i++)
        {
            if(line[i] == 'C')
                c++;
            else if(line[i] == 'S')
                ss[s++] = c;
        }

        if(s > d)
            printf("Case #%d: IMPOSSIBLE\n", ii);
        else
        {
            sum = 0;
            for(i = 0; i < s; i++)
            {
                sum += (1 << ss[i]);
            }
            while(sum > d)
            {
                ans++;
                sum -= (1 << (ss[s-1]-1));
                ss[s-1]--;

                qsort(ss, s, sizeof(int), cmp);
            }
            printf("Case #%d: %d\n", ii,ans);
        }
    }
}

