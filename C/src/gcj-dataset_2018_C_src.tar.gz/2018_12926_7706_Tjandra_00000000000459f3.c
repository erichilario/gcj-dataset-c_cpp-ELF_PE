#include<stdio.h>
#include<stdlib.h>
typedef double d;
typedef unsigned u;
typedef long long unsigned llu;
u M[555][555][555],O[555][555][555],t,S[555];
u F(u x,u y,u a)
{
	if(!x||!a)return S[y];
	if(O[x][y][a]==1)return M[x][y][a];
	O[x][y][a]=1;
	u i,j,k,m=F(x,y,a-1);
	for(j=0,i=1;a*i<=x&&j<=y;)
	{
		k=i+F(x-a*i,y-j,a-1);
		if(m<k)m=k;
		j+=i++;
	}
	return M[x][y][a]=m;
}
int main()
{
	u T,i,j;
	for(i=j=1;i<555;i+=++j)S[i]=j;
	for(i=0;++i<555;)if(!S[i])S[i]=S[i-1];
	for(scanf("%u",&T);t++<T;)
	{
		scanf("%u%u",&i,&j);
		printf("Case #%u: %u\n",t,F(i,j,i));
	}
	return 0;
}
