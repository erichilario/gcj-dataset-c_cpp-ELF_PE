#include <stdio.h>
#include <string.h>

static char stages[32];

int main() {
	int T, D;
	scanf("%d", &T);
	for (int t = 1; t <= T; t++) {
		scanf("%d ", &D);
		memset(stages, 0, 32);
		int stage = 0;
		int damage = 0;
		int c;
		while ((c = getchar()) != '\n') {
			if (c == 'S') {
				stages[stage]++;
				damage += 1 << stage;
			} else {
				stage++;
			}
		}
		int hack = 0;
		while (damage > D) {
			while (stages[stage] == 0)
				stage--;
			if (stage == 0)
				break;
			stages[stage]--;
			stages[stage - 1]++;
			damage -= 1 << (stage - 1);
			hack++;
		}
		if (damage > D)
			printf("Case #%d: IMPOSSIBLE\n", t);
		else
			printf("Case #%d: %d\n", t, hack);
	}
	return 0;
}

