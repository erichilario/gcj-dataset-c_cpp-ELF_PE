#include <stdio.h>

unsigned int damcount,charcount;

unsigned long long calc_damage(char *pattern)
        {
        unsigned long long power;
        unsigned long long damage;
        char *pos;

        power=1;
        damage=0;
        damcount=charcount=0;
        for(pos=pattern;*pos!='\0';pos++)
                {
                if(*pos=='C')
                        {
                        power *= 2;
                        charcount++;
                        }
                else if(*pos=='S')
                        {
                        damage += power;
                        damcount++;
                        }
                }
        return damage;
        }

int main(int argc,char *argv[])
        {
        unsigned int num_tests,t;
        unsigned long long result;
        unsigned long long target;
        char pattern[31];
        unsigned long long damage;

        scanf("%d\n",&num_tests);
        for(t=0;t<num_tests;t++)
                {
                result=0;
                if(scanf("%lu %s\n",&target,pattern)==2)
                        {
                        char *pos;
                        damage=calc_damage(pattern);
                        if(damage<=target)
                                {
                                result = 1;
                                }
                        else if(damcount>target)
                                {
                                }
                        else
                                {
                                result ++;
                                for(pos=pattern+damcount+charcount-2;(pos>=pattern)&&(damage>target);)
                                        {
                                        if((*pos=='C')&&(*(pos+1)=='S'))
                                                {
                                                result++;
                                                *pos='S';
                                                *(pos+1)='C';
                                                if(*(pos+2)!='\0')
                                                        {
                                                        pos++;
                                                        }
                                                damage=calc_damage(pattern);
                                                }
                                        else
                                                {
                                                pos--;
                                                }
                                        }
                                }
                        }
                if(result==0)
                        {
                        printf("Case #%d: IMPOSSIBLE\n",t+1);
                        }
                else
                        {
                        printf("Case #%d: %d\n",t+1,result-1);
                        }
                }
        }

