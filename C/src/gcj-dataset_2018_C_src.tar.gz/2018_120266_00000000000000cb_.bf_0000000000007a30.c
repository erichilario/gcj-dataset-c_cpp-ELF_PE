#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define true 1
#define false 0

typedef unsigned char bool;

int grid[5][5], sumGrid;

void zeroGrid()
{
    int i, k;
    for(i = 1; i <= 3; i++)
        for(k = 1; k <= 3; k++)
            grid[i][k] = 0;
}

void setGridValue(int l, int c, int value)
{
    if(l == 0)
        l = 3;
    if(grid[l][c] != value)
    {
        grid[l][c]++;
        sumGrid++;
    }
}

int main()
{
    int T;
    scanf("%d", &T);
    /*fprintf(stderr, "%d\n", T);*/
    
    while(T--)
    {
        int a, turns = 0;
        int center_l, center_c;
        int value;

        scanf("%d", &a);
        /*fprintf(stderr, "%d\n", a);*/
        
        zeroGrid();
        
        if(a < 9)
            a = 9;
        if(a%9 != 0)
            a += 9 - a%9;
        
        center_l = 2, center_c = 2;
        
        value = 1;
        sumGrid = 0;

        while(true)
        {
            /*int i, k;
            for(i = 1; i <= 3; i++, fprintf(stderr, "\n"))
                for(k = 1; k <= 3; k++)
                    fprintf(stderr, "%d ", grid[i][k]);
            fflush(stderr);*/
            
            int l, c;
            printf("%d %d\n", center_l, center_c);
            fflush(stdout);
            
            scanf("%d %d", &l, &c);
            /*fprintf(stderr, "%d %d\n", l, c);*/
            
            if(l == -1 && c == -1)
            {
                exit(1);
            }
            else if(l == 0 && c == 0)
            {
                break ;
            }
            else
            {
                setGridValue(l%3, c, value);
            }
            
            turns++;
            if(sumGrid == value*9)
            {
                center_l += 3;
                value++;
                /*fprintf(stderr, "Turns: %d\n", turns);*/
            }
        }
    }
    
    return 0;
}

