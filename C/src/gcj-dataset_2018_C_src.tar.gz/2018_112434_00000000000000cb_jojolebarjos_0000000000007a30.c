
#include <string.h>
#include <stdio.h>

int main(int argc, char* argv[]) {
  int T, t, A, i, j, ii, jj, c, mi, mj, m;
  char O[5][40];
  scanf("%d", &T);
  for (t = 1; t <= T; ++t) {
    scanf("%d", &A);
    memset(O, 0, 200);
    for (;;) {
      mi = mj = 1;
      m = 0;
      for (i = 1; i < 4; ++i)
        for (j = 1; j < A / 5 - 1; ++j) {
          c = 0;
          for (ii = -1; ii <= 1; ++ii)
            for (jj = -1; jj <= 1; ++jj)
              if (O[i + ii][j + jj] == 0)
                ++c;
          if (c > m) {
            mi = i;
            mj = j;
            m = c;
          }
        }
      printf("%d %d\n", mi + 1, mj + 1);
      fflush(stdout);
      scanf("%d%d", &i, &j);
      if (i == -1 && j == -1)
        return -1;
      if (i == 0 && j == 0)
        break;
      O[i - 1][j - 1] = 1;
    }
  }
  return 0;
}

