/*Cubic UFO*/

#include<stdio.h>
#include<math.h>

int main()
{
	const double root2 = sqrt(2.0);
	double A, theta;
	int t, T;
	scanf("%d", &T);
	for (t = 1; t <= T; t++)
	{
		scanf("%lf", &A);
		printf("Case #%d:\n", t);
		if (A <= root2)
		{
			theta = 0.5 * asin(A * A - 1.0);
			printf("0.5 0 0\n");
			printf("0 %lf %lf\n", 0.5 * cos(theta), 0.5 * sin(theta));
			printf("0 %lf %lf\n", -0.5 * sin(theta), 0.5 * cos(theta));
		}
	}
	return 0;
}
