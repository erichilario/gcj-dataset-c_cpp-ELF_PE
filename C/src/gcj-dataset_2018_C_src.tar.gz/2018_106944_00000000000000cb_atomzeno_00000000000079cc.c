#include<stdio.h>
#include<math.h>
//#pragma warning(disable:4996)
using namespace std;

int main() {
	int t, tt;
	double A, B=(double)sqrt(2);
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	scanf("%d", &t);
	for (tt = 1; tt <= t;tt++) {
		scanf("%lf", &A);
		if (A <= B) {
			double C, D;
			C = (double)sin(asin(A*A - 1) / ((double)2.0));
			C = C / ((double)2.00000000);
			D = (double)cos(asin(A*A - 1) / ((double)2.0));
			D = D / ((double)2.00000000);
			printf("%Lf %Lf 0\n", C, D);
			D = D - D - D;
			printf("%Lf %Lf 0\n", D, C);
			printf("0 0 0.5\n");
		}
	}
}
