#include <stdio.h>

bool map[4][70];
bool check[23];

int main(void)
{
  int t,a,i,j,k,x,y;

  scanf("%d", &t);
  for (int c=1; c<=t; c++) {
    scanf("%d", &a);
    if (a==20) {
      while (1) {
        for (i=2; i<=3; i++) {
          for (j=2; j<=4; j++) {
            printf("%d %d\n", i, j);
            fflush(stdout);
            scanf("%d %d", &x, &y);
            if (x==0 && y==0)
              break;
          }
          if (x==0 && y==0)
            break;
        }
        if (x==0 && y==0)
          break;
      }
    }
    else {
      for (i=0; i<4; i++)
        for (j=0; j<70; j++)
          map[i][j] = false;
      for (i=0; i<23; i++)
        check[i] = false;

      while (1) {
        for (i=2; i<=68; i=i+3) {
          if (check[i/3])
            continue;

          printf("2 %d\n", i);
          fflush(stdout);
          scanf("%d %d", &x, &y);
          map[x][y] = true;
          if (x==0 && y==0)
            break;
        }
        if (x==0 && y==0)
          break;
          
        for (i=2; i<=68; i=i+3) {
          for (j=-1; j<=1; j++) {
            for (k=-1; k<=1; k++){
              if (map[2+j][i+k] == false)
                break;
            }
            if (k!=2)
              break;
          }
          if (j==2)
            check[i/3] = true;
        }
      }
    }
  }

  return 0;
}

