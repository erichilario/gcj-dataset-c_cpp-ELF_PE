#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int solve(char*, int);
int el(int, int);

int main(int argc, char** argv){
    int T, D;
    scanf("%d", &T);
    int t = 0; 
    for(int t = 0; t < T; t++){
        scanf("%d", &D);

        char program[30];
        scanf("%s", program);
        int res = solve(program, D);

        if(res == -1){
            printf("Case #%d: IMPOSSIBLE\n", (t+1));
        }else{
            printf("Case #%d: %d\n", (t+1), res);
        }
        
    }

    return 0;

}

int solve(char* program, int D){
    int actual_length = strlen(program);

    int total_damage = 0;
    int current_power = 1;

    int i = 0;
    int C_count = 0;
    for(i = 0; i < actual_length; i++){
        if(program[i] == 'S'){
            total_damage+=current_power;
        }else{
            C_count++;
            current_power+=current_power;
        }
    }

    if(total_damage <= D){
        return 0;
    }else{ 
        int swap_count = 0;
        
        for(i = (actual_length-1); i >= 0; i--){
            if(program[i] == 'C'){
                int j = i;
                while(total_damage > D && (j+1) <= (actual_length - 1) && program[j+1] == 'S'){
                    char aux = program[j];
                    program[j] = program[j+1];
                    program[j+1] = aux;
                    j = j+1; 
                    swap_count++;
                    total_damage = total_damage - (el(2, C_count-1)); 
                }
                C_count--;
            }
        }

        if(total_damage > D){
            return -1;
        }else{
            return swap_count;
        }

    }

}

int el(int a, int b){
    if(b == 0){ return 1;}
    
    int aux = a; 
    b--;
    
    while(b > 0){
        aux = aux * a;
        b--;
    }

    return aux;
}
