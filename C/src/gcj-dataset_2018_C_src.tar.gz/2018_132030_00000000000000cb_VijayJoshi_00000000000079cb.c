#include<stdio.h>
#include<stdlib.h>
#define MAX 50001

int comparator(const void * a, const void * b) {
   return ( *(long long int*)a - *(long long int*)b );
}

void solve(int t) {
     long long int even[MAX],odd[MAX],N,i,j,x,ans=0,odd_i=0,even_i=0,odd_l,even_l;
     
     scanf("%lld",&N);
     for(i=0;i<N;i++) {
       scanf("%lld",&x);
       if(i&1)
         even[even_i++]=x;
       else
         odd[odd_i++]=x;
     }

     odd_l=odd_i;
     even_l=even_i;
          
     qsort(odd,odd_l,sizeof(long long int),comparator);
     qsort(even,even_l,sizeof(long long int),comparator);
     
     ans=-1;
     for(i=0;i<even_l;i++) {
        if(odd[i]>even[i]) {
           ans=i<<1;
           break;
        }
        if((i+1)<odd_l) {
           if(odd[i+1]<even[i]) {
               ans=(i<<1)+1;
               break;
           }
        }           
     }
     if(ans!=-1)
       printf("Case #%d: %lld\n",t,ans);
     else
       printf("Case #%d: OK\n",t,ans);
}
int main() {
    int T,t;
    scanf("%d",&T);
    for(t=1;t<=T;t++)               
        solve(t);
    return 0;
}

