#include <stdio.h>
#include <stdlib.h>

int get_int();

int main()
{
	int i, j;
	int n = get_int();

	for (i = 0; i < n; i++)
	{
		int a = get_int();
		if (a == 20)
		{
			a = 5;
		}
		else
		{
			a = 15;
		}

		int f[a][a];

		for (i = 0; i < a; i++)
		{
			for (j = 0; j < a; j++)
			{
				f[i][j] = 0;
			}
		}

		printf("10 10\n");
		int x, y;
		int x0 = get_int();
		int y0 = get_int();

		f[0][0] = 1;

		while (1)
		{
			int max_score = -1;
			int max_loc_x = -1;
			int max_loc_y = -1;
			for (i = 1; i < a - 1; i++)
			{
				for (j = 1; j < a - 1; j++)
				{
					int tmp = f[i - 1][j - 1] + f[i - 1][j + 0] + f[i - 1][j + 1] +
						      f[i + 0][j - 1] + f[i + 0][j + 0] + f[i + 0][j + 1] +
					       	  f[i + 1][j - 1] + f[i + 1][j + 0] + f[i + 1][j + 1];

					tmp = 9 - tmp;

					if (tmp > max_score)
					{
						max_score = tmp;
						max_loc_x = i;
						max_loc_y = j;
					}
				}
			}
			if (!max_score)
			{
				break;
			}
			//printf("~%d\n", max_loc_x);
			//printf("~%d\n", max_loc_y);
			//printf("~%d\n", max_score);

			//printf("~\n");
			//for (i = 0; i < a; i++)
			//{
				//for (j = 0; j < a; j++)
				//{
					//printf("%d ", f[i][j]);
				//}
				//putchar(10);
			//}

			printf("%d %d\n", max_loc_x + x0, max_loc_y + y0);
			x = get_int();
			y = get_int();

			f[x - x0][y - y0] = 1;
		}
	}
}

int get_int()
{
	int ret = 0;
	char c  = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF)
		{
			return EOF;
		}
		if (c >= '0' && c <= '9')
		{
			sgn = 1;
			break;
		}
		if (c == '-')
		{
			c = getchar();

			if (c < '0' || c > '9')
			{
				continue;
			}

			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = (ret << 3) + (ret << 1) + c - '0';

		c = getchar();

		if (c < '0' || c > '9')
		{
			return sgn*ret;
		}
	}
}

