#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

void troubleSort(int *arr, int n) {
	int flag = 0;
	while (!flag) {
		flag = 1;
		for (int i = 0; i < n - 2; i++) {
			if (arr[i] > arr[i + 2]) {
				flag = 0;
				int tmp = arr[i];
				arr[i] = arr[i + 2];
				arr[i + 2] = tmp;
			}
		}
	}
	
	return;
}

int main(void) {
	int t;
	scanf("%d", &t);
	
	int i;
	for (i = 0; i < t; i++) {
		int n;
		scanf("%d", &n);
		
		int arr[n];
		int j;
		for (j = 0; j < n; j++) {
			scanf("%d", &arr[j]);
		}
		
		printf("Case #%d: ", i + 1);
		
		// check trouble sort
		troubleSort(arr, n);
		for (j = 0; j < n - 1; j++) {
			if (arr[j] > arr[j + 1]) {
				printf("%d\n", j);
				break;
			}
		}
		if (j >= n - 1) {
			printf("OK\n");
		}
	}
	
	return 0;
}

