#include<stdio.h>
#include<stdlib.h>
#include<math.h>

typedef long long int int64;

#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define ABS(a,b) ((a)>(0)?(a):-(a))

void msort(int *a,int n,int *merge){
  if(n<=1) return;
  int m=n/2;
  msort(a,m,merge);
  msort(a+m,n-m,merge);
  int i=0;
  int j=m;
  int k=0;
  while(i<m && j<n){
    if(a[i]<=a[j]){
      merge[k++]=a[i++];
    } else {
      merge[k++]=a[j++];
    }
  }
  while(i<m) merge[k++]=a[i++];
  while(j<n) merge[k++]=a[j++];
  for(i=0;i<n;i++){
    a[i]=merge[i];
  }
  return;
}

void run(void){
  int t;
  scanf("%d",&t);
  int *a=(int *)malloc(sizeof(int)*100000);
  int *odd=(int *)malloc(sizeof(int)*50000);
  int *even=(int *)malloc(sizeof(int)*50000);
  int iter;
  for(iter=1;iter<=t;iter++){
    int n;
    scanf("%d",&n);
    int i;
    for(i=0;i<n;i++){
      scanf("%d",a+i);
    }
    for(i=0;i<n;i+=2){
      even[i/2]=a[i];
    }
    for(i=1;i<n;i+=2){
      odd[i/2]=a[i];
    }
    msort(even,n-n/2,a);
    msort(odd,n/2,a);
    for(i=0;i<n;i+=2){
      a[i]=even[i/2];
    }
    for(i=1;i<n;i+=2){
      a[i]=odd[i/2];
    }
    for(i=0;i+1<n;i++){
      if(a[i]>a[i+1]) break;
    }
    printf("Case #%d: ",iter);
    if(i+1<n){
      printf("%d\n",i);
    } else {
      printf("OK\n");
    }
  }
}

int main(void){
  run();
  return 0;
}

