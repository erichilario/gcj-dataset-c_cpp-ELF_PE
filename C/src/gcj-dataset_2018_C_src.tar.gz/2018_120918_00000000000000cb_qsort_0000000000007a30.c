#include <stdio.h>

int main() {
	int scores[22][12];
	int claim[22][12];
	int cases, i, j, k, size, tk, tj, max, done;
	int jlimit, klimit;
	scanf("%d", &cases);
	for (i=1; i<=cases; ++i) {
		scanf("%d", &size);		
		if (size == 200) {
			jlimit = 20; klimit = 10;
		}
		else {
			jlimit = 5; klimit = 4;
		}
		for(j=1; j<=jlimit; ++j) {
			for (k=1; k<=klimit; ++k) {
				scores[j][k] = 9;
				claim[j][k] = 0;
			}
		}
		done = 0;
		while (!done) {
			tk = tj = max = 0;
			for(j=2; j<=jlimit-1; ++j) {
				for (k=2; k<=klimit-1; ++k) {
					if (scores[j][k] >= max) {
						tk = k; tj = j; max=scores[j][k];
					} 
				}
			}
			printf("%d %d\n", tj, tk);
			fflush(stdout);
			scanf("%d %d", &j, &k);
			if (j==0 && k==0) done=1;
			if (j==-1 && k==-1) done=1;
			if (!claim[j][k]) {
			scores[j-1][k-1]--; scores[j-1][k]--; scores[j-1][k+1]--;
			scores[j][k-1]--; scores[j][k]--; scores[j][k+1]--;
			scores[j+1][k-1]--; scores[j+1][k]--; scores[j+1][k+1]--;
			claim[j][k] = 1;
			}	
		}
		
	}
	return 0;
}

