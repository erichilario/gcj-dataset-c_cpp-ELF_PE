#include <iostream>
#include <algorithm>
#include <string>
#include <string.h>
#include <queue>
#include <map>
#include <utility>
#include<math.h>
#include <iomanip>
#include<vector>
#define ll long long
#define ull unsigned long long
#include<numeric>
#include <map>
#include <stdio.h>
using namespace std;


int main()
{
    std::ios::sync_with_stdio(false);
    int T;cin>>T;
    double long A;
    double long Diameter=sqrt(2.0)/2.0;
    double angle=0;
    double long x,y;
    cout<<fixed<<setprecision(16);
    for(int t=1;t<=T;t++){
        cin>>A;
        angle=acos((A/2.0)/Diameter);


        if((A - 1.414213)<1e-5 && (A - 1.414213)>-1e-5)
            angle = (double long) int(angle*1000)/1000;


        angle+= acos(-1)/4 ;
        cout<<angle<<endl;
        x=0.5*cos(angle);
        y=0.5*sin(angle);
        cout<<"Case #"<<t<<":\n";
        cout<<x<<" "<<y<<" "<<0<<"\n";
        cout<<-y<<" "<<x<<" "<<0<<"\n";
        cout<<0<<" "<<0<<" "<<0.5<<"\n";

    }
    return 0;
}

