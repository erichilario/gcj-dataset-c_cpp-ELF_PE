#include <stdbool.h>
#include <stdio.h>

int main(void)
{
	int T;
	scanf("%d", &T);
	for (int iT = 1; iT <= T; ++iT)
	{
		int N;
		scanf("%d", &N);

		int A[100][100];
		for (int i = 0; i < N; ++i)
		for (int j = 0; j < N; ++j)
			scanf("%d", &A[i][j]);

		int answer = N * N;
		for (int mask = 0; mask < (1 << N*N); ++mask)
		{
			bool bad = false;
			for (int i = 0; i < N; ++i)
			for (int j = 0; j < N; ++j)
			{
				if (mask & 1 << i * N + j)
					continue;
				for (int i2 = 0; i2 < N; ++i2)
				{
					if (i2 == i || mask & 1 << i2 * N + j)
						continue;
					if (A[i][j] == A[i2][j])
					{
						bad = true;
						break;
					}
				}
				for (int j2 = 0; j2 < N; ++j2)
				{
					if (j2 == j || mask & 1 << i * N + j2)
						continue;
					if (A[i][j] == A[i][j2])
					{
						bad = true;
						break;
					}
				}
				if (bad)
					break;
			}
			if (!bad)
			{
				int popc = __builtin_popcount(mask);
				if (popc < answer)
					answer = popc;
			}
		}
		printf("Case #%d: %d\n", iT, answer);
	}
}

