#include <stdio.h>

int main(void)
{
	long long int getDamage(char P[]);
	int getInversion(char P[]);
	int T;
	scanf("%d",&T);
	for(int i = 0;i < T;i++)
	{
		long long int D;
		char P[35];
		scanf("%lli %s",&D,P);
		int hacks = 0;
		while(getDamage(P) > D && getInversion(P) != -1)
		{
			int index = getInversion(P);
			char temp = P[index];
			P[index] = P[index+1];
			P[index+1] = temp;
			hacks += 1;
		}
		if(getDamage(P) > D)
		{
			printf("Case #%d: IMPOSSIBLE\n",(i+1));
		}
		else
		{
			printf("Case #%d: %d\n",(i+1),hacks);
		}


	}
}



long long int getDamage(char P[])
{
	long long int damage = 0;
	long long int charge = 1;
	for(int i = 0;P[i] != '\0';i++)
	{
		if(P[i] == 'C')
		{
			charge *= 2;
		}
		else
		{
			damage += charge;
		}
	}
	return damage;
}

int getInversion(char P[])
{
	int inversion = -1;
	for(int i = 0;P[i] != '\0';i++)
	{
		if(P[i] == 'C' && P[i+1] == 'S')
		{
			inversion = i;
			break;
		}
	}
	return inversion;
}

