#include <stdio.h>
#include <stdlib.h>

#define SIZE 100000

static int v_odd[SIZE], v_even[SIZE];

static int cmp(const void *a, const void *b)
{
    int x = *(const int *) a, y = *(const int *) b;

    return x - y;
}

int main(void)
{
    int t, i, j, n, n_odd, n_even, ok;

    scanf("%d", &t);

    for (i = 1; i <= t; i++) {
        scanf("%d", &n);
        n_odd = n_even = 0;

        for (j = 0; j < n; j++) {
            if (j & 1) {
                scanf("%d", &v_odd[n_odd++]);
            } else {
                scanf("%d", &v_even[n_even++]);
            }
        }

        qsort(v_odd, n_odd, sizeof v_odd[0], cmp);
        qsort(v_even, n_even, sizeof v_even[0], cmp);

        ok = 1;
        for (j = 0; ok && j < n_odd; j++) {
            if (v_even[j] > v_odd[j]) {
                printf("Case #%d: %d\n", i, 2 * j);
                ok = 0;
            } else if (j + 1 < n_even && v_even[j + 1] < v_odd[j]) {
                printf("Case #%d: %d\n", i, 2 * j + 1);
                ok = 0;
            }
        }

        if (ok) {
            printf("Case #%d: OK\n", i);
        }
    }

    return 0;
}

