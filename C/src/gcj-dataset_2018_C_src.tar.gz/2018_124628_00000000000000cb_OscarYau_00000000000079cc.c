#include <stdio.h>
#include <math.h>

typedef struct {
    double x;
    double y;
    double z;
} point;

int main() {
    int T = 0;
    int i = 0;
    double g = 0.0;
    double A = 0.0;
    double theta = 0.0, thi = 0.0;
    double sintheta = 0.0, costheta = 0.0;
    double cal = 0.0;
    point px, py, pz;
    scanf("%d", &T);
    for(i = 0; i < T; i++) {
        theta = 0.0;
        thi = 0.0;
        px.x = 0.5;
        px.y = px.z = 0;
        py.y = 0.5;
        py.x = py.z = 0;
        pz.z = 0.5;
        pz.x = pz.y = 0;
        scanf("%lf", &A);

        if( A < sqrt(2)) {
            /*
            for(g = 0.0; g < M_PI /2; g+=0.00000001) {
                cal = cos(g) + sin(g) - A;
                if(fabs(cal) < 0.00000001) {
                    theta = g;
                    break;
                }
            }
            */
            sintheta = sqrt((1-A*sqrt(2-A*A))/2);
            costheta = sqrt((A*sqrt(2-A*A)+1)/2);
            px.x = 0.5 * costheta;
            px.y = 0.5 * sintheta;
            py.x = -0.5 * sintheta;
            py.y = 0.5 * costheta;
            printf("Case #%d:\n", i + 1);
            printf("%lf %.15lf %.15lf\n", px.x, px.y, px.z);
            printf("%.15lf %.15lf %.15lf\n", py.x, py.y, py.z);
            printf("%.15lf %.15lf %.15lf\n", pz.x, pz.y, pz.z);
        }
        else if( A > sqrt(2)) {
            theta = M_PI / 4;
            for(g = 0.0; g < M_PI /2; g+=0.00000001) {
                cal = sqrt(2)*cos(g)+sin(g) - A;
                if(fabs(cal) < 0.00000001) {
                    thi = g;
                    break;
                }
            }
            px.x = 0.5 * sqrt(2) / 2;
            px.y = 0.5 * sqrt(2) / 2 * cos(thi);
            px.z = 0.5 * sqrt(2) / 2 * sin(thi);
            py.x = -0.5 * sqrt(2) / 2;
            py.y = 0.5 * sqrt(2) / 2 * cos(thi);
            py.z = 0.5 * sqrt(2) / 2 * sin(thi);
            pz.x = 0.0;
            pz.y = -0.5 * sin(thi);
            pz.z = 0.5 * cos(thi);
            printf("Case #%d:\n", i + 1);
            printf("%.15lf %.15lf %.15lf\n", px.x, px.y, px.z);
            printf("%.15lf %.15lf %.15lf\n", py.x, py.y, py.z);
            printf("%.15lf %.15lf %.15lf\n", pz.x, pz.y, pz.z);
        }
    }
    return 0;
}

