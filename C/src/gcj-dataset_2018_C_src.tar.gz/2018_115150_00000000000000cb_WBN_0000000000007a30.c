#include <stdio.h>
#include <stdlib.h>

int map [1005][1005];

int CalculateBox(int i, int j){

    int x, y, sum = 0;

    for(x = i - 1; x <= i + 1; x++){
        for(y = j - 1; y <= j + 1; y++)
            sum += map [x][y];
    }

    return sum;

}

int main()
{
    int T, A, inI, inJ, outI, outJ, i, j, minI, maxI, minJ, maxJ, bigI, min;

    scanf ("%d", &T);

    for(bigI = 1; bigI <= T; bigI++){

        scanf ("%d", &A);

        for(i = 0; i <= 1002; i++)
            for(j = 0; j <= 1002; j++)
                map [i][j] = 0;

        outI = outJ = 500;

        minI = 1001;
        maxI = 0;
        minJ = 1001;
        maxJ = 0;

        while(1){

            printf ("%d %d\n", outI, outJ);
            fflush (stdout);
            scanf ("%d %d", &inI, &inJ);
            if(inI == 0 && inJ == 0)
                break;
            ///if(inI == -1 && inJ == -1)
            ///    break;

            map [inI][inJ] = 1;///0-not Ready 1- Prepared

            if(inI > maxI)
                maxI = inI;
            if(inI < minI)
                minI = inI;
            if(inJ > maxJ)
                maxJ = inJ;
            if(inJ < minJ)
                minJ = inJ;

            min = 10;

            if((maxI - minI + 1) * (maxJ - minJ + 1) >= A){

                for(i = minI + 1; i <= maxI - 1; i++){
                    for(j = minJ + 1; j <= maxJ - 1; j++){

                        if(CalculateBox (i, j) < min){
                            outI = i;
                            outJ = j;
                            min = CalculateBox (i, j);
                        }

                    }
                }

            }

            else{

                for(i = minI; i <= maxI; i++){
                    for(j = minJ; j <= maxJ; j++){

                        if(CalculateBox (i, j) < min){
                            outI = i;
                            outJ = j;
                            min = CalculateBox (i, j);
                        }

                    }
                }
            }

        }

    }

    return 0;
}

