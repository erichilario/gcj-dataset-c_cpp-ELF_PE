#include <stdio.h>
#include <stdlib.h>
#define BSIZE 1<<15
#define MAXN 100000

long readLong() 
{
	static char buffer[BSIZE];
	static long bpos = 0L, bsize = 0L;
	long d = 0L, x = 0L;
	char c;

	while (1)  {
		if (bpos >= bsize) {
			bpos = 0;
			if (feof(stdin)) return x;
			bsize = fread(buffer, 1, BSIZE, stdin);
		}
		c = buffer[bpos++];
		if (c >= '0' && c <= '9') { x = x*10 + (c-'0'); d = 1; }
		else if (d == 1) return x;
	}
	return -1;
}

int cmpLong(const void * a, const void * b)
{
	const long * aa = a, * bb = b;
	return *aa - *bb;
}

int main()
{
	int T,tcase;
	long N, Veven[MAXN/2+2], Vodd[MAXN/2+2];
	scanf("%d", &T);
	for(tcase = 1; tcase <= T; tcase++)
	{
		long i, index;
		N = readLong();
		for(i = 0; i < N-1; i+=2)
		{
			Veven[i>>1] = readLong();
			Vodd[i>>1] = readLong();
		}
		if(i < N)
			Veven[i>>1] = readLong();
		qsort(Veven, (N+1)/2, sizeof(long), cmpLong);
		qsort(Vodd, N/2, sizeof(long), cmpLong);
		for(i = 0; i < (N+1)/2; i++)
			printf("%ld ",Veven[i]);
		printf("\n");
		for(i = 0; i < N/2; i++)
			printf("%ld ",Vodd[i]);
		printf("\n");
		index = -1;
		for(i = 0; i < N-2; i+=2)
		{
			if( Veven[i>>1] > Vodd[i>>1] )
			{
				index = i;
				break;
			}
			if( Vodd[i>>1] > Veven[1 + (i>>1)] )
			{
				index = i+1;
				break;
			}
		}
		if(index < 0 && i == N-2)
			if( Veven[i>>1] > Vodd[i>>1] )
				index = i;

		if(index >= 0)
			printf("Case #%d: %ld\n", tcase, index);
		else
			printf("Case #%d: OK\n", tcase);
	}
	return 0;
}

