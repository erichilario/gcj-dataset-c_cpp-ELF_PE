#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

#define rad2deg(x) (x * 180 / M_PI)

void magic(long double *a, long double t)
{
	long double c = cosl(t);
	long double s = sinl(t);
	long double n[] = {
		    c,    -s,  0,
		c * s, c * c, -s,
		s * s, c * s,  c,
	};

	long double tmp[9];
	size_t i, j;

	/* tmp = n * a */
	for(i = 0; i < 9; i++) {
		tmp[i] = 0;

		for(j = 0; j < 3; j++)
			tmp[i] += n[3 * (i / 3) + j] * a[3 * j + i % 3];
	}

	/* a = tmp */
	for(i = 0; i < 9; i++)
		a[i] = tmp[i];
}

void solve(double area, long double matrix[9])
{
	long double root;
	long double theta;
	size_t i;

	assert(1 <= area && area <= 2);

	/* theta = pitch and yaw angle */
	root  = sqrtl(area);
	theta = acosl(root / sqrt(2)) - M_PI / 4;

	/* Set matrix to id(0.5) */
	for(i = 0; i < 9; i++)
		matrix[i] = 0;

	matrix[0] = matrix[4] = matrix[8] = 0.5;

	magic(matrix, theta);
}

int main(int argc, char *argv[])
{
	size_t i, n;
	double area;
	long double points[] = {
		0.5, 0.0, 0.0,
		0.0, 0.5, 0.0,
		0.0, 0.0, 0.5,
	};

	scanf("%lu", &n);

	for(i = 0; i < n; i++) {
		scanf("%lg", &area);
		printf("Case #%lu:\n", i + 1);

		solve(area, points);
		printf("%.15Lg %.15Lg %.15Lg\n", points[0], points[1], points[2]);
		printf("%.15Lg %.15Lg %.15Lg\n", points[3], points[4], points[5]);
		printf("%.15Lg %.15Lg %.15Lg\n", points[6], points[7], points[8]);
	}

	return EXIT_SUCCESS;
}

