#include <stdio.h>
#include <string.h>

int swap_most_right_cs(char *program)
{
  size_t program_length = strlen(program);
  size_t i = program_length - 1; // last program instruction
  while (i > 0)
  {
    if (program[i - 1] == 'C' && program[i] == 'S')
    {
      program[i - 1] = 'S';
      program[i] = 'C';
      return 1;
    }
    else
    {
      i--;
    }
  }
  return 0;
}

u_int64_t calculate_robot_damage(char *program)
{
  u_int64_t total_damage = 0;
  u_int64_t current_damage = 1;
  size_t i = 0;
  while (program[i] != '\0')
  {
    if (program[i] == 'S')
    {
      total_damage += current_damage;
    }
    else
    {
      current_damage *= 2;
    }
    i++;
  }
  return total_damage;
}

int64_t solve(u_int64_t max_damage, char *program)
{
  int64_t swaps_done = -1;
  do
  {
    swaps_done++;
    u_int64_t damage = calculate_robot_damage(program);
    if (max_damage >= damage)
    {
      return swaps_done;
    }
  } while (swap_most_right_cs(program));
  return -1;
}

int main()
{
  int t;
  scanf("%d", &t);
  for (int i = 0; i < t; i++)
  {
    char program[40];
    u_int64_t d;
    scanf("%llu %s", &d, program);
    int64_t x = solve(d, program);
    if (x == -1)
    {
      printf("Case #%d: IMPOSSIBLE\n", i + 1);
    }
    else
    {
      printf("Case #%d: %lld\n", i + 1, x);
    }
  }
}

