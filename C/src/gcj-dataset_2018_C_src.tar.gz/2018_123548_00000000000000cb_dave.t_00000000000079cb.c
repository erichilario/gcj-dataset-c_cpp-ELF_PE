#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>

int cmp(const void *a, const void *b) {
  return *(const int *)a - *(const int *)b;
}

int trouble_slow(int a[], int N) {
  int done = 0;
  while (!done) {
    done = 1;
    for (int i = 0; i < N - 2; ++i) {
      if (a[i] > a[i + 2]) {
        done = 0;
        int temp = a[i];
        a[i] = a[i + 2];
        a[i + 2] = temp;
      }
    }
  }
  int fail = -1;
  for (int n = 0; n < N - 1; ++n) {
    if (a[n] > a[n+1]) {
      return n;
    }
  }
  return fail;
}

int trouble_fast(int even[], int odd[], int N) {
  int num_odd = N / 2;
  int num_even = N - num_odd;
  qsort(even, num_even, sizeof(int), cmp);
  qsort(odd, num_odd, sizeof(int), cmp);
  int fail = -1;
  for (int n = 0; n < N - 1; ++n) {
    if (n % 2) {
      if (odd[n / 2] > even[(n / 2) + 1]) return n;
    } else {
      if (even[n / 2] > odd[n / 2]) return n;
    }
  }
  return fail;
}

int main(void) {
  int a[100001];
  int odd[50001];
  int even[50001];
  int t, T;
  int n = 0;
  int N = 0;
  scanf("%d",&T);
  for (t = 1; t <= T; t++) {
    printf("Case #%d: ", t);
    assert(scanf("%d", &N) == 1);
    for (n = 0; n < N; ++n) {
      assert(scanf("%d", &a[n]) == 1);
      if (n % 2) {
        odd[n / 2] = a[n];        
      } else {
        even[n / 2] = a[n];
      }
    }
    int fail = trouble_fast(even, odd, N);
    if (fail == -1) {
      printf("OK\n");
    } else {
      printf("%d\n", fail);
    }
  }
}


