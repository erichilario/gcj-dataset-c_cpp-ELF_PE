//#include "stdafx.h"
#include <iostream>
#include <unordered_map>
#include <string>
#include <utility>
#include <algorithm>
#include <cstring>
#include <vector>
#include <queue>
using namespace std;
typedef long long ll;
string s;

bool count_damage(ll d) {
	ll mul = 1, damage = 0;
	for (int i = 0; i < s.length(); i++) {
		if (s[i] == 'C') {
			mul *= 2;
		}
		if (s[i] == 'S') {
			damage += mul;
			if (damage > d)
				return false;
		}
	}
	return true;
}

bool change() {
	for (int i = s.length() - 1; i > 0; i--) {
		if (s[i] == 'S' && s[i - 1] == 'C') {
			s[i - 1] = 'S';
			s[i] = 'C';
			return true;
		}
	}
	return false;
}


int main() {
	int n = 0, d = 0;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> d;
		cin >> s;
		int counter = 0;
		bool fl = true;
		while (!count_damage(d) && fl) {
			fl = change();
			counter++;
		}
		cout << "Case #" << i << ": ";
		if (!fl) {
			cout << "IMPOSSIBLE" << '\n';
		}
		else {
			cout << counter << '\n';
		}
	}
}
