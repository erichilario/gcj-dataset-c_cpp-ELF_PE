#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{

    int T, D, bigI, l, i, c, s, j, sum, pow [35], cNum [35];
    char P [35];

    pow [0] = 1;
    for(i = 1; i <= 30; i++)
        pow [i] = 2 * pow [i - 1];

    scanf ("%d", &T);

    for(bigI = 1; bigI <= T; bigI++){

        scanf ("%d ", &D);
        scanf ("%s", P);
        printf ("Case #%d: ", bigI);

        l = strlen (P);
        c = s = sum = 0;

        for(i = 0; i < l; i++){

            if(P[i] == 'C'){
                c++;
                cNum [i] = c;
            }
            else{
                cNum [i] = cNum [i - 1];
                sum += pow [c];
                s++;
            }

        }

        if(s > D)
            printf("IMPOSSIBLE\n");

        else{

            for(i = 0;;i++){

                if(sum <= D)
                    break;

                for(j = l - 1;;j--){

                    if(P [j] == 'S' && P [j - 1] == 'C'){
                        P [j] = 'C';
                        P [j - 1] = 'S';
                        cNum [j - 1]--;
                        sum -= pow [cNum [j - 1]];
                        break;
                    }

                }

            }
            printf("%d\n", i);

        }

    }

    return 0;
}

