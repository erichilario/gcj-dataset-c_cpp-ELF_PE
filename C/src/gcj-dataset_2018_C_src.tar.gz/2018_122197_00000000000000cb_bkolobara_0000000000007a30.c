#include<stdio.h>

char o[10][20];

int is_completed(int i, int j) {
  return o[i-1][j-1] && o[i-1][j-0] && o[i-1][j+1] &&
         o[i-0][j-1] && o[i-0][j-0] && o[i-0][j+1] &&
         o[i+1][j-1] && o[i+1][j-0] && o[i+1][j+1];
}

void zero_out() {
  for(int i=0; i<10; i++) {
    for(int j=0; j<20; j++) {
      o[i][j] = 0;
    }
  }
}

void walk(int n, int m) {
  for(int i=1; i<n-1; i++) {
    for(int j=1; j<m-1; j++) {
      while(1) {
        printf("%d %d\n", i+1, j+1);
        int i_, j_;
        scanf("%d %d", &i_, &j_);
        if (i_ == -1 || i_ == 0) goto out;
        o[i_-1][j_-1] = 1;
        if(is_completed(i, j)) {
          break;
        }
      }
    }
  }
  out: return;
}

int main() {
  int t;
  scanf("%d", &t);
  for (int i = 0; i < t; i++) {
    int A;
    scanf("%d", &A);
    if (A == 20) {
      walk(4, 5);
    } else {
      walk(10, 20);
    }
  }
}
