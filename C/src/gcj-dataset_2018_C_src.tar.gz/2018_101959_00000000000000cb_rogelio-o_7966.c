#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void removeStringTrailingNewline(char *str) {
  if (str == NULL)
    return;
  int length = strlen(str);
  if (str[length-1] == '\n')
    str[length-1]  = '\0';
}

int minNumHacksToSurvive(unsigned long shield, char *program, int programSize) {
    unsigned long dammage = 0;
    unsigned long maxStrength = 1;
    int maxStrengthIndex = -1;
    int numHacks = 0;

    // Find initial values
    unsigned long nextMaxStrength = 1;
    int nextMaxStrengthIndex = -1;
    for(int i = 0; i < programSize; i++) {
        if(program[i] == 'S') {
            maxStrength = nextMaxStrength;
            maxStrengthIndex = nextMaxStrengthIndex;

            dammage += maxStrength;
        } else {
            nextMaxStrength = nextMaxStrength * 2;
            nextMaxStrengthIndex = i;
        }
    }

    //printf("Dammage: %lu\nMax strength: %lu\nMax Strength Index: %d\n", dammage, maxStrength, maxStrengthIndex);

    // Calculate min hacks
    if(dammage > 0) {
        while(maxStrengthIndex > -1) {
            if(shield >= dammage) {
                break;
            }

            if(maxStrengthIndex + 1 < programSize && program[maxStrengthIndex + 1] == 'S') {
                char aux = program[maxStrengthIndex + 1];
                program[maxStrengthIndex + 1] = program[maxStrengthIndex];
                program[maxStrengthIndex] = aux;

                maxStrengthIndex++;
                dammage -= maxStrength / 2;
                numHacks++;
            } else {
                maxStrength = maxStrength / 2;

                do {
                    maxStrengthIndex--;
                    if(program[maxStrengthIndex] == 'C') {
                        break;
                    }
                } while(maxStrengthIndex > -1);
            }
        }
    }
    
    if(shield >= dammage) {
        return numHacks;
    } else {
        return -1;
    }
}

int main() {
    char * line = NULL;
    size_t len = 0;
    ssize_t read;

    read = getline(&line, &len, stdin);
    int numProblems = atoi(line);

    for (int i = 1; i <= numProblems; ++i) {
        read = getline(&line, &len, stdin);
        unsigned long shield = atoi(strtok(line, " "));
        char *program = strtok(NULL, " ");
        removeStringTrailingNewline(program);
        int programSize = strlen(program);
        
        int result = minNumHacksToSurvive(shield, program, programSize);

        if(result == -1) {
            printf("Case #%d: IMPOSSIBLE\n", i);
        } else {
            printf("Case #%d: %d\n", i, result);
        }
    }
}
