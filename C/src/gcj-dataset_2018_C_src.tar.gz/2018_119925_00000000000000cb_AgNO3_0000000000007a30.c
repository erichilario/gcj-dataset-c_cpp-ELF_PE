#include<stdio.h>

int main()
{
    int t;
    scanf("%d",&t);
    while(t--){
        int a;
        scanf("%d",&a);
        int x = 500, y =  500, i = 0;
        while(x != 0 && y!= 0){
            int rx, ry;
            fflush(stderr);
            fprintf(stderr, "%d %d\n", x, y);
            fflush(stderr);
            scanf("%d%d", &rx, &ry);
            int dx = x - rx;
            int dy = y - ry;
            x = rx - dx;
            y = ry - dy;
            i++;
            if(x == -1 && y == -1)break;
            if(i == 1001)break;
        }
    }
    return 0;
}
