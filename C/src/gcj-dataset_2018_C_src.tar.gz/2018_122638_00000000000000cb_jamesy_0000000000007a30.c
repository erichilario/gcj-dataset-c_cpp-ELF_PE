#include <stdio.h>
#include <string.h>

int orchard[4][1001];

void resetOrchard(){
	for(int j = 1; j <= 1000; j++){
		for(int i = 1; i <= 3; i++){
			orchard[i][j] = 0;
		}
	}
}

int main(){
	int numtests;
	int A;
	scanf("%d", &numtests);
	int col, i, j;
	int conGuess;
	for(int k = 0; k < numtests; k++){
		scanf("%d", &A);
		A = A/3;
		resetOrchard();
		col = 2;
		conGuess = 1;
		while(conGuess){
			if(col < A && orchard[1][col-1] && orchard[2][col-1] && orchard[3][col-1]){
				col++;
			}
			printf("2 %d\n", col);
			fflush(stdout);
			scanf("%d %d", &i, &j);
			if(i == -1 && j == -1){
				return 0;
			}
			if(i == 0 && j == 0){
				conGuess = 0;
			}
			orchard[i][j] = 1;
		}
	}
	return 0;
}

