#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define PI 3.14159265
struct objCoords{

	int rating;
	int dug;

};

typedef struct objCoords coord;

coord new_coord(){
	coord ret;
	ret.rating = 0;
	ret.dug = 0;

	return ret;
}

void print_grid(coord** grid, int rows, int cols){
	printf("\n\n");
	for(int j=0; j<rows; j++){
		for(int i=0; i<cols; i++)
			printf("%d ",grid[j][i].dug);
		printf(" : ");
		for(int i=0; i<cols; i++)
			printf("%d ",grid[j][i].rating);

		printf("\n");
	}
	printf("\n\n");

}

int random2(){
	int r = rand()%3;
	r = r - 1;
	return r;
}

int main(){


	int T = 0;
	int A = 0;
	int I,J;
	int IR,JR;
	


	scanf("%d", &T);
	//srand(time(NULL));
	//setbuf(stdout, NULL);
	for(int t=1; t<=T; t++){

		//read A
		scanf("%d", &A);
		//A = 20;
		//calc dimensions
		int rows = 0;
		int cols = 0;
		int breakk = 0;
		int minarea = 200;
		for(int i=3; i<67 && breakk == 0; i++)
			for(int j=3; i*j<=200 && breakk == 0; j++)
				if(i*j == A){
					breakk = 1;
					rows = j;
					cols = i;
					minarea = A;
				}else if(i*j >= A && minarea > i*j){
					minarea = i*j;
					rows = j;
					cols = i;
				}
		//set grid
		coord** grid;
		grid = malloc(rows * sizeof(coord*));
		for(int i=0; i<rows; i++)
			grid[i] = malloc(cols*sizeof(coord)); 

		for(int i=0; i<cols; i++)
			for(int j=0; j<rows; j++)
				grid[j][i] = new_coord();
		
		IR = 1; JR = 1;	
		while( !(IR==-1 && JR==-1) && !(IR == 0 && JR == 0) ){

			//printf("\n random %d \n", rand() %3);
			//print_grid(grid, rows, cols);

			//look for lowest rating
			int lowest_rating = 9;
			I=1;J=1;
			for(int i=1; i<cols-1; i++)
				for(int j=1; j<rows-1; j++)
					if(grid[j][i].rating < lowest_rating){
						lowest_rating = grid[j][i].rating;
						I = i;
						J = j;
					}


			//send
			printf("%d %d\n",I+1,J+1);
			fflush(stdout);
			
			
			//read response
			scanf("%d %d", &IR, &JR);
			

			//IR = I+1 + random2();
			//JR = J+1 + random2();

			//check if done
			/*int done = 1;
			for(int i=0; i<cols; i++)
				for (int j = 0; j < rows; j++)
					if(grid[j][i].dug == 0) done = 0;
			if(done == 1){
				IR = 0;
				JR = 0;
			}*/
				
			if(IR==-1 && JR==-1){
				return 0;
			}else if(IR == 0 && JR == 0){
				break;
			}

			//printf(" : %d %d",IR,JR);

			if(grid[JR-1][IR-1].dug == 0)
			for(int i=IR-2; i < IR+1; i++)
				for(int j=JR-2; j < JR+1; j++)
					if(i >= 0 && j >= 0 && i < cols && j < rows)
						grid[j][i].rating++;
			grid[JR-1][IR-1].dug = 1;

		}
	


		//printf("Area %d %d",cols,rows);		
		

	} //T

	
	return 0;
}







