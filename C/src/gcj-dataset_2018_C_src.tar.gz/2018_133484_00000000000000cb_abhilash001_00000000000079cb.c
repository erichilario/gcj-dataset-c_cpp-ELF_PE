#include <stdio.h>

void swap(long long int* a, long long int* b)
{
	long long int t = *a;
	*a = *b;
	*b = t;
}

void sort(long long int L[], int n)
{
	int done = 0, i;
	while(!done)
	{
		done = 1;
		for(i = 0; i < n-2; i++)
		{
			if(L[i] > L[i+2])
			{
				done = 0;
				swap(&L[i], &L[i+2]);
			}
		}
	}
}

int main()
{
	/* code */
	int i, N;
	long long int t, t1;
	scanf("%lld", &t);
	t1=t;
	while(t--)
	{
		scanf("%d", &N);
		long long int V[N], pos=-1;
		for(i=0; i<N; i++)
			scanf("%lld", &V[i]);
		sort(V, N);
		for(i=0; i<N-1; i++)
		{
			if(V[i]>V[i+1]) {pos=i; break;}
		}
		if(pos!=-1) printf("Case #%lld: %lld\n", (t1-t), pos);
		else		printf("Case #%lld: OK\n", (t1-t));
	}
	return 0;
}
