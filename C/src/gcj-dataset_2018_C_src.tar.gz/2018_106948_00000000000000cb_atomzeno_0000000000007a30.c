#include<stdio.h>
int t, a, ch[3][3];
int A, B;
void go(int sx, int sy, int chx, int chy) {
	int zz=0,i=0,j=0,nm=0;
	for (zz=1;zz<100;zz++) {
		int z = 0, lx, ly;
		printf("%d %d\n", sx + chx, sy + chy);
		fflush(stdout);
		scanf("%d%d", &lx,&ly);
		if (lx == 0 && ly == 0) { return; }
	}
	return;
}
int main() {
	scanf("%d%d", &t, &a);
	for (int gg = 0; gg < t;gg++) {
		if (a == 20) {
			printf("%d %d\n", 50, 50);
			fflush(stdout);
			scanf("%d%d", &A, &B);
			int inita = A, initb = B;
			int i, j;
			go(inita-1, initb-1, 2, 3);
			go(inita-1, initb-1, 2, 6);
			go(inita-1, initb-1, 2, 2);
		}
		else {//a==200
			printf("%d %d\n", 50, 50);
			fflush(stdout);
			scanf("%d%d",&A,&B);
			int inita = A, initb = B;
			int i;
			for (i = 1; i <= 22; i++) {
				go(inita - 1, initb - 1, 2, i * 3);
			}
			go(inita - 1, initb - 1, 2, 2);
		}
	}
	return 0;
}
