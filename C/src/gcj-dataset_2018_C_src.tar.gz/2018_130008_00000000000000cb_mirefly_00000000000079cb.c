#include <stdio.h>
#include <stdlib.h>


int greater(const void * a, const void * b) {
  return (*(long*)a - *(long*)b);
}

int iscorrect(long * odd, long * even, int n) {

  int m = n/2 - ((n+1)%2);
  for (int i=0; i<m; i++) {
    if (*(even+i) < *(odd+i)) {
      return i*2;
    }

    if (*(even+i) > *(odd+i+1)) {
      return i*2+1;
    }
  }

  if (n%2 == 0) {
    if (*(even+n/2-1) < *(odd+n/2-1)) {
      return n-2;
    }
  }

  return -1;
}

int main() {

  int nt;
  scanf("%d", &nt);

  for (int i=0; i<nt; i++) {
    int n;
    scanf("%d", &n);
    long *even;
    long *odd;

    even = (long *) malloc(n/2*sizeof(long));
    odd = (long *) malloc((n-(n/2))*sizeof(long));

    for (int j=0; j<n; j++) {
      if ((j+1)%2 == 1) {
        scanf("%ld", (odd+j/2));
      } else {
        scanf("%ld", (even+j/2));
      }
    }

    qsort(even, n/2, sizeof(long), greater);
    qsort(odd, n-n/2, sizeof(long), greater);

    printf("Case #%d: ", i+1);
    int ans = iscorrect(odd, even, n);
    if (ans == -1) {
      printf("OK\n");
    } else {
      printf("%d\n", ans);
    }

    free(even);
    free(odd);
  }
}

