#include <stdio.h>
#include <math.h>

double pi;

/* rotate around 1 axis */
void case1(double A) {
	double lo=0,hi=pi/4,mid;
	double x1,y1,x2,y2,a;
	int i;
	for(i=0;i<1000;i++) {
		mid=(lo+hi)*.5;
		x1=-0.5; x2=0.5;
		y1=-0.5*sin(mid)-0.5*cos(mid);
		y2=0.5*sin(mid)+0.5*cos(mid);
		a=(x2-x1)*(y2-y1);
//		printf("%f %f\n",mid,a);
		if(a>A) hi=mid;
		else lo=mid;
	}
	printf("%.10f %.10f 0\n",0.5*cos(mid),-0.5*sin(mid));
	printf("%.10f %.10f 0\n",0.5*sin(mid),0.5*cos(mid));
	puts("0 0 0.5");
}

void case2(double A) {
	printf("error");
}

void solve() {
	double A;
	scanf("%lf",&A);
	if(A<=sqrt(2)) case1(A);
	else case2(A);
}

int main() {
	int T,no=1;
	scanf("%d",&T);
	pi=2*acos(0);
	while(T--) {
		printf("Case #%d:\n",no++);
		solve();
	}
	return 0;
}

