

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>



#define N 100000 + 10
int nums[N];

void my_sort(int *nums, int start, int end) {
//    printf("%d %d\n", start, end);
    if (start >= end) {
        return ;
    }
    int i = start, j = end;
    int key = nums[start];
    while(i < j) {
        while(i < j && nums[j] >= key) {
            j -= 2;
        }
        nums[i] = nums[j];
        while(i < j && nums[i] <= key) {
            i += 2;
        }
        nums[j] = nums[i];
    }
    nums[i] = key;
    my_sort(nums, start, i - 2);
    my_sort(nums, i + 2, end);
}

//int check(int *nums, int len) {
//    for (int i = 0; i < len - 2; i += 2) {
//        if (nums[i] > nums[i + 2]) {
//            return -1;
//        }
//    }
//    return 1;
//}
//
void show(int *nums, int stride, int len) {
    for (int i = 0; i < len; i += stride) {
        printf("%d ", nums[i]);
    }
    printf("\n");
}
//
//
//void test() {
//    srand((unsigned int)time(NULL));
//    int t = rand() % 10;
//    int n = rand() % 100;
//    for (int i = 0; i < t; i++) {
//        int nums[101];
//        for (int j = 0; j < n; j++) {
//            nums[j] = rand() % 100;
//        }
//        my_sort(nums, 0, n - (n % 2 ? 1 : 0));
////        show(nums, 1, n);
////        show(nums, 2, n);
//
//        if (check(nums, n) == -1) {
//            printf("wrong!\n");
//        }
//    }
//}





void bubble_sort(int *nums, int len) {
    for (int i = 0; i < len - 1; i++) {
        int flag = 1;
        for (int j = i; j < len - 1; j++) {
            if (nums[j] > nums[j + 1]) {
                int t = nums[j];
                nums[j] = nums[j + 1];
                nums[j + 1] = t;
                flag = 0;
            }
        }
        if (flag) {
            break;
        }
    }
}

void triple_sort(int *nums, int len) {
    while(1) {
        int flag = 1;
        for (int j = 0; j < len - 2; j++) {
            if (nums[j] > nums[j + 2]) {
                int t = nums[j];
                nums[j] = nums[j + 2];
                nums[j + 2] = t;
                flag = 0;
                
//                show(nums, 1, len);
            }
        }
        if (flag) {
            break;
        }
    }
}




int main(int argc, const char * argv[]) {
    
    
    
//    if (freopen("test.txt","r",stdin) == NULL) {
//        printf("error...");
//    }
//
//    test();
    
    int t;
    scanf("%d", &t);
    for (int i = 0; i < t; i++) {
        int n;
        scanf("%d", &n);
        for (int j = 0; j < n; j++) {
            scanf("%d", &(nums[j]));
        }
        
//        show(nums, 1, n);
        
        triple_sort(nums, n);
        
        
//        show(nums, 1, n);
        
        int k = 0;
        for (k = 0; k < n - 1; k++) {
            if (nums[k] > nums[k + 1]) {
                break;
            }
        }
        
        if (k == n - 1) {
            printf("Case #%d: OK\n", i + 1);
        } else {
            printf("Case #%d: %d\n", i + 1, k);
        }
    }
    
    
    
    
    
    
    
    
    
    
    return 0;
}

