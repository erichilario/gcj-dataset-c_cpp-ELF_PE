/*
  * b.c
  *
  *  Created on: 22/05/2011
  *      Author: schester
  */
 
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <limits.h>
 
 int main(int argc, char **argv) {
 
     int i,j,n,t,d,counter;
     double maxtime;
     double minc[200],maxc[200];
     double min,max;
     double range1,range2;
     double thisc,thisv;
     double c[200], v[200];
     double c2[200], v2[200];
     int map[200];
     double newc[200], newv[200];
 int totv;
 
     scanf("%d\n",&t);
     for(i=0;i<t;i++){
 
     	maxtime=0;
     	counter =0;
     	totv=0;
         scanf("%d %d\n",&n,&d);
         for(j=0;j<n;j++){
         	scanf("%lf %lf\n",&thisc,&thisv);
         	c[j]=thisc;
         	v[j]=thisv;
         	c2[j]=thisc;
         	v2[j]=thisv;
         	totv+=thisc;
        // 	printf("%f %f\n",c[j],v[j]);
 
         }
     	//printf("\n %d\n",d);
         min = c[0];
         int change=0;
         for(j=0;j<(n-1);j++){
         	range1 = ((v[j]-1)*d)*0.5;
         	range2 = ((v[j+1]-1)*d)*0.5;
         //	printf("%f %f\n",range1,range2);
         	max=c[j];
                if(range1+c[j]>(c[j+1]-range2)){
             	   max=c[j+1];
             	   c[j+1]=(c[j]+c[j+1])*0.5;
             	   v[j+1]=v[j]+v[j+1];
             	   change=1;
             	   map[j]=counter;
                } else {
             	   map[j]=counter;
             	   change=0;
             	   newc[counter]=c[j];
             	   newv[counter]=v[j];
             	   minc[counter]=min;
             	   maxc[counter]=max;
             	   min=c[j+1];
             	   counter++;
                }
 
         }
         if(change==0){
         	max=c[j];
         }
                     	   newc[counter]=c[j];
                     	   newv[counter]=v[j];
                     	   minc[counter]=min;
                     	   maxc[counter]=max;
                     	   counter++;
 
                     	   int j2=0;
                     	   int cum=0;
         for(j=0;j<counter;j++){
         	//printf("\n%f %f %f %f\n",newc[j],newv[j],minc[j],maxc[j]);
         	range1=((newv[j]-1)*d)*0.5;
         	min = newc[j]-range1;
         	max = newc[j]+range1;
         	while(map[j2]=j && j2<n){
 
         	if((c2[j2]-(min+d*cum))>maxtime){
         		maxtime=(c2[j2]-(min+d*cum));
 			}
         	if(((max-(d*(totv-(cum+v2[j2]))))-maxc[j])>maxtime){
         	    maxtime=((max-(d*(totv-(cum+v2[j2]))))-maxc[j]);
         	}
         	cum+=v2[j2];
         	j2++;
         	}
         }
 
         printf("Case #%d: %10.10f\n",i+1,maxtime);
 
 
     }
 
 }

