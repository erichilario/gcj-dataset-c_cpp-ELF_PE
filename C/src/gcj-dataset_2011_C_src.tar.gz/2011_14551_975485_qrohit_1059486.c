#include<stdio.h>
 #define INT_MAX 1000001
 
 int t,i,n,j,min=INT_MAX,k,sum,xor;
 int main(){
 	scanf("%d",&t);
 	for(i=1;i<=t;i++){
 	xor=0;
 	sum=0;
 	min=INT_MAX;
 	
 		scanf("%d",&n);
 		for(j=0;j<n;j++){
 			scanf("%d",&k);
 			if(k<min)min=k;
 			xor^=k;
 			sum+=k;
 		}
 		if(xor)
 			printf("Case #%d: NO\n",i);
 		else printf("Case #%d: %d\n",i,sum-min);
 				
 			
 	}
 
 
 }

