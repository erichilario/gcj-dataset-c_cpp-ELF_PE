/*
  *  allYourBase.c
  *  
  *
  *  Created by Jason Tseng on 11-01-25.
  *  Copyright 2011 none. All rights reserved.
  *
  */
 
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 #include <ctype.h>
 
 
 int main (int argc, char *argv[]){
 	int numOfCase;
 	
 	
 	if (argc < 2) {
 		fprintf(stderr, "no filename given\n");
 		exit(1);
 	}
 	FILE *theFile = fopen(argv[1], "r");
 	if(theFile == NULL){
 		fprintf(stderr, "error while loading file\n");
 		return 1;
 	}
 	
 	fscanf(theFile, "%d", &numOfCase);
 //	printf("%d\n", numOfCase);
 
 	int i;
 	int j;
 	int k;
 	
 	
 	for (i = 1; i<= numOfCase; i++) {
 		
 		int pass = 0;
 		int n;
 		int pd;
 		int pg;
 		
 		
 		fscanf(theFile, "%d", &n);
 		char** originalA = (char**) malloc(n*sizeof(char*));
 		double** originalD = (double**) malloc(n*sizeof(double*));
 		double* wp = (double*) malloc(n*sizeof(double));
 		double* theOwp = (double*) malloc(n*sizeof(double));
 		double* theOowp = (double*) malloc(n*sizeof(double));
 		int teamPlayed;
 		for (j=0; j<n; j++) {
 			originalA[j] = (char*) malloc(n*sizeof(char));
 			originalD[j] = (double*) malloc(n*sizeof(double));
 			wp[j] = 0;
 			teamPlayed = 0;
 			
 			
 			for (k=0; k<n; k++) {
 				fscanf(theFile, "%1s", &(originalA[j][k]));
 				if (originalA[j][k] != '.') {
 					wp[j] += originalA[j][k] - 48;
 					teamPlayed++;
 				}
 			}
 			wp[j] = wp[j]/teamPlayed;
 			for (k=0; k<n; k++) {
 				if (originalA[j][k] != '.' && teamPlayed > 1) {
 	//				printf("%f:", wp[j]*teamPlayed);
 	//				printf("%d:", originalA[j][k] - 48);
 					originalD[j][k] = (wp[j]*teamPlayed - (originalA[j][k] - 48))/(teamPlayed-1);
 	//				printf("%f\n", originalD[j][k]);
 				}else {
 					originalD[j][k] = -1;
 				}
 
 			}
 			
 			
 			
 		}
 		for (j=0; j<n; j++) {
 			double owp = 0;
 			int team = 0;
 			for (k=0; k<n; k++) {
 				if (originalD[k][j] >= 0) {
 					owp += originalD[k][j];
 					team++;
 				}
 			}
 			double owpResult;
 			if (team != 0) {
 				owpResult = owp/team;
 			}else {
 				owpResult = -1;
 			}
 			theOwp[j] = owpResult;
 			for (k=0; k<n; k++) {
 				if (originalD[k][j] >= 0) {
 					originalD[k][j] = owpResult;
 				}
 			}
 
 		}
 		
 		
 		for (j=0; j<n; j++) {
 			double oowp = 0;
 			int team = 0;
 			for (k=0; k<n; k++) {
 				if (originalD[j][k] >= 0) {
 					oowp += originalD[j][k];
 					team++;
 				}
 			}
 			double oowpResult;
 			if (team != 0) {
 				oowpResult = oowp/team;
 			}else {
 				oowpResult = -1;
 			}
 			theOowp[j] = oowpResult;
 			
 			
 		}
 
 		printf("Case #%d:\n", i);
 		for (j=0; j<n; j++) {
 			
 			for (k=0; k<n; k++) {
 	//			printf("%.2f  ", originalD[j][k]);
 			}
 	//		printf("%f ", wp[j]);
 			
 			printf("%.8f", .25*wp[j] + .5*theOwp[j] + .25*theOowp[j]);
 			printf("\n");
 			free(originalA[j]);
 			
 		}
 		free(originalA);
 		
 	//	printf("Case #%d: %s\n", i, pass == 1 ? "Possible" : "Broken");
 		/*
 		if (theAnd != 0) {
 			printf("Case #%d: Possible\n", i);
 		}else {
 			printf("Case #%d: Broken\n", );
 		}
 */
 		
 	}
 	
 	return 0;
 }
