#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 //./p1 <input >output
 main()
 {
 	int T,N;
 	int i,j,k;
 
 	scanf("%d",&T);
 	for(i=0;i<T;i++)
 	{
 		double wCnt[100]={0},Cnt[100]={0},WP[100]={0},OWP[100]={0},OOWP[100]={0};
 		double fWP2[100][100]={0};
 		char result[100][100]={0};
 
 		scanf("%d",&N);
 		
 		for(j=0;j<N;j++)
 		{
 			scanf("\n");
 			for(k=0;k<N;k++)
 			{
 				scanf("%c",&result[j][k]);
 				//WP
 				switch (result[j][k])
 				{
 					case '.':
 						break;
 					case '1':
 						wCnt[j]++;
 					case '0':
 						Cnt[j]++;
 						break;
 				}
 			}
 			WP[j]=wCnt[j]/Cnt[j];
 		}
 
 		for(j=0;j<N;j++)
 		{
 			double W=wCnt[j],C=Cnt[j];
 			double OWPU=0;
 			for(k=0;k<N;k++)
 			{
 				switch (result[j][k])
 				{
 					case '.':
 						fWP2[j][k]=W/C;
 						break;
 					case '1':
 						fWP2[j][k]=(W-1)/(C-1);
 						break;
 					case '0':
 						fWP2[j][k]=(W)/(C-1);
 						break;
 				}
 			}
 		}
 
 
 		for(j=0;j<N;j++)
 		{
 			double C=Cnt[j];
 			double OWPU=0;
 			for(k=0;k<N;k++)
 			{
 				switch (result[j][k])
 				{
 					case '.':
 						break;
 					default:
 						OWPU+=fWP2[k][j];
 						break;
 				}
 			}
 			OWP[j]=OWPU/C;
 		}
 
 		for(j=0;j<N;j++)
 		{
 			double C=Cnt[j];
 			double OOWPU=0;
 			for(k=0;k<N;k++)
 			{
 				switch (result[j][k])
 				{
 					case '.':
 						break;
 					default:
 						OOWPU+=OWP[k];
 						break;
 				}
 			}
 			OOWP[j]=OOWPU/C;
 		}
 
 
 		printf("Case #%d:\n",i+1);
 		for(j=0;j<N;j++)
 		{
 			printf("%lf\n",0.25*WP[j]+0.5*OWP[j]+0.25*OOWP[j]);
 		}
 
 	}
 }

