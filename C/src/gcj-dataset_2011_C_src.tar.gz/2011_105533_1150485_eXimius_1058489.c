#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
 int T,t,C,c,D,P,V,v,min_p,max_p,max_v;
 double ret,ret_min;
 
 	scanf("%d",&T);
 
 	for (t = 1; t <= T; t++)
 	{
 		scanf("%d %d",&C,&D);
 
 		v = 0;
 		min_p = 100001;
 		max_p = -100001;
 		max_v = 0;
 		for (c = 0; c < C; c++)
 		{
 			scanf("%d %d",&P,&V);
 			v += V;
 			if (min_p > P) min_p = P;
 			if (max_p < P) max_p = P;
 			if (max_v < V) max_v = V;
 		}
 
 	ret = (double) ((v-1)*D-max_p+min_p)/2;
 	ret_min = (double) (max_v-1)*D/2;
 	if (ret < ret_min) ret = ret_min;
 
 		printf("Case #%d: %.1f\n",t,ret);
 	}
 
     return 0;
 }

