#include <stdio.h>
 
 int main ()
 {
 	int t, index = 0, n, count;
 	double sum;
 	scanf("%d", &t);
 	
 	while (t--)
 	{
 		index++;
 		scanf("%d", &n);
 		fgetc(stdin);
 		
 		char s[n][n];
 		double rpi[n], wp[n], owp[n], oowp[n];
 		int played[n], won[n];
 		
 		for (int i=0; i<n; i++)
 		{
 			for (int j=0; j<n; j++)
 				s[i][j] = fgetc(stdin);
 			fgetc(stdin);
 		}
 		
 		for (int i=0; i<n; i++)
 		{
 			played[i] = won[i] = 0;
 			for (int j=0; j<n; j++)
 			{
 				if (s[i][j] == '1')
 				{
 					won[i]++;
 					played[i]++;
 				}
 				
 				else if (s[i][j] == '0')
 					played[i]++;
 			}
 			
 			wp[i] = ((double)won[i])/played[i];
 		}
 		
 		for (int i=0; i<n; i++)
 		{
 			sum = 0.0;
 			for (int j=0; j<n; j++)
 			{
 				if (j == i || s[j][i] == '.')
 					continue;
 				
 				if (s[j][i] == '1')
 					sum += ((float)(won[j]-1))/(played[j]-1);
 				else if (s[j][i] == '0')
 					sum += ((float)won[j])/(played[j]-1);
 				else
 					sum += ((float)won[j])/played[j];
 			}
 			
 			owp[i] = sum/played[i];
 		}
 		
 		for (int i=0; i<n; i++)
 		{
 			sum = 0.0;
 			for (int j=0; j<n; j++)
 			{
 				if (j ==  i || s[i][j] == '.')
 					continue;
 				sum += owp[j];
 			}
 			oowp[i] = sum/played[i];
 		}
 		
 		for (int i=0; i<n; i++)
 			rpi[i] = 0.25 * wp[i] + 0.5 * owp[i] + 0.25 * oowp[i];
 		
 		
 		printf("Case #%d:\n", index);
 		for (int i=0; i<n; i++)
 		{
 			printf("%lf\n", rpi[i]);
 		}
 	}	
 	return 0;
 }
 

