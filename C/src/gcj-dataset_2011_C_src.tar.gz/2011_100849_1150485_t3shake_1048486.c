#include <stdio.h>
 #include <stdlib.h>
 
 #define NN 100
 
 int main()
 {
   int T, N;
   int i, j, k;
   char m[NN][NN];
   double WP[NN], OWP[NN], OOWP[NN];
   double WPT[NN][NN], OWPT[NN][NN];
   int n, w, nd, wd;
   double wp;
 
   scanf("%d", &T);
 
   for (i = 0; i < T; i++) {
     scanf("%d", &N);
     for (j = 0; j < N; j++)
       for (k = 0; k < N; k++)
 	scanf(" %c ", &m[j][k]);
 
     for (j = 0; j < N; j++) {
       n = w = 0;
       for (k = 0; k < N; k++) {
 	if (m[j][k] == '1' || m[j][k] == '0' ) n++;
 	if (m[j][k] == '1') w++;
       }
       WP[j] = (double)w/n;
       for (k = 0; k < N; k++) {
 	nd = wd = 0;
 	if (m[j][k] == '1' || m[j][k] == '0' ) nd = 1;
 	if (m[j][k] == '1') wd = 1;
 	WPT[j][k] = (double)(w-wd)/(n-nd);
       }
     }
     for (j = 0; j < N; j++) {
       n = wp = 0;
       for (k = 0; k < N; k++) {
 	if (m[j][k] != '.') {
 	  n++;
 	  wp += WPT[k][j];
 	}
       }
       OWP[j] = wp/n;
     }
     for (j = 0; j < N; j++) {
       n = wp = 0;
       for (k = 0; k < N; k++) {
 	if (m[j][k] != '.') {
 	  n++;
 	  wp += OWP[k];
 	}
       }
       OOWP[j] = wp/n;
     }
 
     printf("Case #%d:\n", i+1);
     for (j = 0; j < N; j++)
       printf("%.12g\n", 0.25*WP[j]+0.5*OWP[j]+0.25*OOWP[j]);
   }
 
   return 0;
 }

