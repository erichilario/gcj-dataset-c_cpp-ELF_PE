#include<stdio.h>
 #include<stdlib.h>
 
 typedef struct X{
 	int p,v,min,max;
 }X;
 
 X* arr;
 
 int main()
 {
 	int t,c,d,i,j,k,p,total_v;
 	int x,y,*pos;
 	double Time;
 	char ch;
 	FILE *fin,*fout;
 	fin =fopen("input.txt","r");
 	fout=fopen("output.txt","w");
 	fscanf(fin,"%d",&t);
 	for(i=0;i<t;i++)
 	{	
 		fscanf(fin,"%c",&ch);
 		total_v=0;Time=0;
 		fscanf(fin,"%d %d",&c,&d);
 		arr=(X *)malloc(c*sizeof(X));
 		for(j=0;j<c;j++)
 		{
 			fscanf(fin,"%c",&ch);
 			arr[j].min=total_v;
 			fscanf(fin,"%d %d",&arr[j].p,&arr[j].v);
 			total_v+=arr[j].v;
 			arr[j].max=total_v;
 		}
 		
 
 		pos=(int *)malloc(total_v*sizeof(int));
 		for(k=0;k<c;k++)
 		{
 			for(p=arr[k].min;p<arr[k].max;p++)
 				pos[p]=arr[k].p;
 		}
 		
 		for(j=1;j<total_v;j++)
 		{
 			x=pos[j];y=pos[j-1];
 			if(x-y<d)
 				Time+=(double)((double)(d-(x-y))/2);
 		}
 		fprintf(fout,"Case #%d: %lf\n",i+1,Time);
 	}
 }

