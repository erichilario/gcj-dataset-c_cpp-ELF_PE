#include <stdlib.h>
 #include <stdio.h>
 #include <math.h>
 
 #define MAX 100
 #define MAXS 100
 #define TRUE 1
 #define FALSE 0
 
 int main(int argc, char *argv[]) {
 
     // Input Variables
     int testcases = 0;
     int N;
     char input_string[MAXS];
 
     // Program Variables
     int i = 0;
     int j = 0;
     int k = 0;
     int l = 0;
 
     scanf("%d", &testcases);
     for (i = 0; i < testcases; i++) {
       scanf("%d", &N);
       int results[N][N];
       for (j = 0; j < N; j++) {
         for (k=0; k< N; k++) {
           scanf("%1s", input_string);
           if (input_string[0] != '.') {
             results[j][k] = atoi(&input_string[0]);
           } else {
             results[j][k] = -1;
           }
         }
       }
       float WP[N];
       for (j = 0; j < N; j++) {
         float numgames = 0;
         float numwins = 0;
         for (k=0; k< N; k++) {
           if(results[j][k] == 1) {
             numgames++;
             numwins++;
           } else if (results[j][k] == 0)  {
             numgames++;
           }
         }
         WP[j] = numwins / numgames;
       }
       float OWPRES[N][N];
       for (l = 0; l < N; l++) { 
         for (j = 0; j < N; j++) {
           float numgames = 0;
           float numwins = 0;
           if (j == l) continue;
           for (k=0; k< N; k++) {
             if (k == l) continue;
             if (results[l][j] == -1) continue;
             if(results[j][k] == 1) {
               numgames++;
               numwins++;
             } else if (results[j][k] == 0)  {
               numgames++;
             }
           }
           if (numgames == 0) {
               OWPRES[l][j] = -1;
           } else {
             OWPRES[l][j] = numwins / numgames;
           }
         }
       }
       float OWP[N];
       for (l = 0; l < N; l++) { 
         float num = 0;
         float total = 0;
         for (j = 0; j < N; j++) {
             if (l != j) {
               if((OWPRES[l][j] <= 1) && (OWPRES[l][j] >= 0)) {
                 num++;
                 total += OWPRES[l][j];
               }
             }
         }
         OWP[l] = total / num;
       }
       float OOWP[N];
       for (j = 0; j < N; j++) { 
         float num = 0;
         float total = 0;
         for (l = 0; l < N; l++) {
           if(l != j) { 
             if(results[j][l] != -1) {
               total += OWP[l];
               num++;
             }
           }
         }
         OOWP[j] = total / num;
       }
       printf("Case #%d:\n", i+1);
       for (j = 0; j < N; j++) {  
          printf("%f\n", 0.25* WP[j] + 0.5*OWP[j] + 0.25*OOWP[j]); 
       }
       
     }
     return 0;
 
 }
 
 

