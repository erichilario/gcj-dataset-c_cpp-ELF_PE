#include <stdio.h>
 #include <stdlib.h>
 
 #define WIN		1
 #define LOSE	0
 #define NOPLAY	2
 
 int main()
 {
 	FILE *INT;
 	INT = stdin;
 	
 	int Team[100][100];
 	double WP[100];
 	double OWP[100];
 	double OOWP[100];
 	
 	double win[100];
 	double play[100];
 	
 	int NumofTestCase;
 	int TestCaseIndex;
 	
 	int NumofTeam;
 	int row, column;
 	
 	// WP
 	double win_count;
 	double play_count;
 	
 	// OWP
 	double SumOfWP;
 	// OOWP
 	double SumOfOWP;
 	
 	double RPI;
 	
 	char buf[100];
 	
 	// Read Input Data
 	fscanf(INT,"%d",&NumofTestCase);
 	for (TestCaseIndex = 0; TestCaseIndex < NumofTestCase; TestCaseIndex++) {
 		fscanf(INT,"%d",&NumofTeam);
 		
 		for (row = 0; row < NumofTeam; row++) {
 			WP[row]		= 0;
 			win[row]	= 0;
 			play[row]	= 0;
 			
 			fscanf(INT,"%s",buf);			
 			for (column = 0; column < NumofTeam; column++) {
 				if (buf[column] == '.') { // No play
 					Team[row][column] = NOPLAY;
 				} else if (buf[column] == '1') {
 					Team[row][column] = WIN;
 					win[row]++;
 					play[row]++;
 				} else if (buf[column] == '0') {
 					Team[row][column] = LOSE;
 					play[row]++;
 				}
 			}
 			// Culculate WP
 			WP[row] = win[row]/play[row];
 			//printf("WP:%lf\n",WP[row]);
 			
 		}
 		
 		// Culculate OWP
 		for (row = 0; row < NumofTeam; row++) {
 			SumOfWP		= 0; 
 			play_count	= 0;
 			for (column = 0; column < NumofTeam; column++) {
 				// Do play
 				if (Team[row][column] == WIN) {
 					SumOfWP += (win[column])/(play[column]-1);
 				} else if (Team[row][column] == LOSE){
 					SumOfWP += (win[column]-1)/(play[column]-1);
 				}
 
 			}
 			OWP[row] = SumOfWP/play[row];
 			//printf("OWP:%lf\n",OWP[row]);
 		}
 		
 		// Culculate OOWP
 		for (row = 0; row < NumofTeam; row++) {
 			SumOfOWP	= 0; 
 			play_count	= 0;
 			for (column = 0; column < NumofTeam; column++) {
 				// Do play
 				if (Team[row][column] != 2) {
 					SumOfOWP += OWP[column];
 					play_count++;
 				}
 			}
 			OOWP[row] = SumOfOWP/play_count;
 			//printf("OOWP:%lf\n",OOWP[row]);
 		}
 		
 		printf("Case #%d:\n",TestCaseIndex+1);				
 		for (row = 0 ; row < NumofTeam; row++) {
 			// Diplay the RPI result
 			RPI = 0.25*WP[row] + 0.5*OWP[row] + 0.25*OOWP[row];
 			printf("%0.12lf\n",RPI);
 		}
 	}
 }
