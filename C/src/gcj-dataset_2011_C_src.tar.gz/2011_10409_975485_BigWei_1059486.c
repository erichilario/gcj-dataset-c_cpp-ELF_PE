#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 int N;
 int cmp(const void *a , const void * b){
 		if(*(int*)a > *(int*)b)
 			return 1;
 		return -1;
 }
 int ok(int index,int NUM[]){
 	int i;
 	int XOR_FRONT;
 	int XOR_BACK;
 	XOR_FRONT=NUM[index];
 	for(i=index+1;i<N;i++)
 		XOR_BACK^=NUM[i];
 	if(XOR_BACK == XOR_FRONT)
 		return 1;
 return 0;
 }
 int main(){
 	int n;
 	int NUM[3000];
 	int i,j,k;
 	int XOR_SUM=0;
 	int ans;
 	scanf("%d",&n);
 	for(i=0;i<n;i++){
 		XOR_SUM=0;
 		ans=0;
 		memset(NUM,0,sizeof(NUM));
 		scanf("%d",&N);
 		for(j=0; j<N;j++){
 			scanf("%d",&NUM[j]);
 			XOR_SUM ^= NUM[j];
 			ans+=NUM[j];
 		}
 		printf("Case #%d: ",i+1);
 		if(XOR_SUM!=0)
 			printf("NO\n");
 		else{
 			qsort(NUM,N,sizeof(int),cmp);
 			for(j=0;j<N;j++){
 				if(ok(j,NUM)){
 					ans-=NUM[j];
 					break;
 				}
 
 			}
 			printf("%d\n",ans);		
 
 		}
 
 	}
 
 }

