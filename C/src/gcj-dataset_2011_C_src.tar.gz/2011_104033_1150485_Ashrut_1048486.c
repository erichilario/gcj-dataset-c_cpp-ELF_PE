#include<stdio.h>
 #include<string.h>
 #include<math.h>
 #define MAX 110
 int main()
 {
 	int test,caseno,N,n,compcount[MAX],i,j;
 	char arr[MAX][MAX],temp[MAX];
 	double wins,count,avwp,avowp,wincount[MAX];
 	scanf("%d",&test);
 	for(caseno=1;caseno<=test;caseno++)
 	{
 		double wp[MAX]={0},owp[MAX]={0},oowp[MAX]={0};
 		scanf("%d",&n);
 		for(i=0;i<n;i++)
 		{
 			scanf("%s",temp);
 			for(j=0;j<n;j++)
 				arr[i][j]=temp[j];
 		}
 		for(i=0;i<n;i++)
 		{
 			count=0;
 			wins=0;
 			for(j=0;j<n;j++)
 			{
 				if(arr[i][j]!='.')
 				{
 					count++;
 					if(arr[i][j]=='1')
 						wins++;
 				}
 			}
 			if(count==0)
 				wp[i]=0;
 			else
 				wp[i]=wins/count;
 			wincount[i]=wins;
 			compcount[i]=count;
 		}
 		for(i=0;i<n;i++)
 		{
 			avwp=0;
 			count=0;
 			for(j=0;j<n;j++)
 			{
 				if(arr[i][j]!='.')
 				{
 					count++;
 					if(arr[i][j]=='1')
 					{avwp+=(wincount[j])/(compcount[j]-1);}
 					else
 						avwp+=(wincount[j]-1)/(compcount[j]-1);
 				}
 			}
 			owp[i]=avwp/count;
 		}
 		for(i=0;i<n;i++)
 		{
 			avowp=count=0;
 			for(j=0;j<n;j++)
 			{
 				if(arr[i][j]!='.')
 				{
 					count++;
 					avowp+=owp[j];
 				}
 			}
 			oowp[i]=avowp/count;
 		}
 		printf("Case #%d:\n",caseno);
 		for(i=0;i<n;i++)
 		printf("%.12lf\n",0.25 * wp[i] + 0.50 * owp[i] + 0.25 * oowp[i]);
 	}
 	return 0;
 }

