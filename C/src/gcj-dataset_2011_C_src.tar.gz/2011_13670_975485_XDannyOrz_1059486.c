#include <stdio.h>
 
 int main() {
 
 	int T, i, N, j;
 	int sum;
 	int min;
 	int flag;
 	int a;
 	int b;
 	scanf("%d", &T);
 
 	for (i = 1; i <= T; i++) {
 		min = 0;
 		sum = 0;	
 		flag = 1;
 		scanf("%d", &N);
 		scanf("%d", &a);
 		sum = a;
 		min = a;
 		for (j = 1; j < N; j++) {
 			scanf("%d", &b);
 			sum = sum + b;
 			if (b < min)
 				min = b;
 			a = a ^ b;
 		
 		}
 		if (a != 0)
 			flag = 0;
 		if (flag == 1)
 			printf("Case #%d: %d\n", i, sum - min);
 		else
 			printf("Case #%d: NO\n", i);
 	}
 	return 0;
 }

