#include <stdio.h>
 #include <stdlib.h>
 
 int main () {
 	int i, j, k, l, m, n, o, p, r, q, s, t;
 	int vet[32];
 	
 	scanf(" %d ", &t);
 	for (s = 1; s <= t; s++) {
 		for (i = 0; i < 32; i++) {
 			vet[i] = 0;	
 		}
 		
 		scanf(" %d ", &n);
 		i = 0;
 		j = 10000000;
 		while (n--) {
 			scanf(" %d ", &k);
 
 			i = i + k;
 			if (k < j) {
 				j = k;	
 			}
 
 			l = 0;
 			while(k > 0) {
 				m = k%2;
 				vet[l] = (vet[l] + m)%2;
 				l++;
 				k = k/2;
 			}
 		}
 		for (m = 0; m < 32; m++) {
 			if (vet[m] == 1) {
 				break;	
 			}	
 		}
 		if (m != 32) {
 			printf("Case #%d: NO\n", s);	
 		} else {
 			printf("Case #%d: %d\n", s, i-j);	
 		}
 	}
 
 	return 0;	
 }

