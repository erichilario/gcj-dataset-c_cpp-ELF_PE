#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct {
     int enable, opposer;
 } opposeList;
 
 typedef struct {
     int enable;
     unsigned short noOfRows;
     int list[8][2];
 } combinationList;
 
 int main(int argc, char** argv) {
     FILE *inp, *out;
     inp = fopen("./B-small-attempt0.in", "rb");
     out = fopen("./output.txt", "w");
     int testCases, C, D, N, testCount = 0;
     char *inputString = NULL;
     fscanf(inp, "%d", &testCases);
     while (testCases) {
         combinationList *combination = NULL;
         fscanf(inp, "%d", &C);
         if (C) {
             combination = (combinationList *) calloc(26, sizeof (combinationList));
             while (C) {
                 char ch[4];
                 fgetc(inp);
                 fscanf(inp, "%s", ch);
                 if (combination[ch[0] - 'A'].enable != -1) {
                     combination[ch[0] - 'A'].enable = -1;
                     combination[ch[0] - 'A'].noOfRows = 0;
                 }
                 combination[ch[0] - 'A'].noOfRows++;
                 combination[ch[0] - 'A'].list[combination[ch[0] - 'A'].noOfRows - 1][0] = ch[1] - 'A';
                 combination[ch[0] - 'A'].list[combination[ch[0] - 'A'].noOfRows - 1][1] = ch[2] - 'A';
                 if (combination[ch[1] - 'A'].enable != -1) {
                     combination[ch[1] - 'A'].enable = -1;
                     combination[ch[1] - 'A'].noOfRows = 0;
                 }
                 combination[ch[1] - 'A'].noOfRows++;
                 combination[ch[1] - 'A'].list[combination[ch[1] - 'A'].noOfRows - 1][0] = ch[0] - 'A';
                 combination[ch[1] - 'A'].list[combination[ch[1] - 'A'].noOfRows - 1][1] = ch[2] - 'A';
                 C--;
             }
         }
         fgetc(inp);
         opposeList *oppose = NULL;
         fscanf(inp, "%d", &D);
         if (D) {
             oppose = (opposeList *) calloc(26, sizeof (opposeList));
             while (D) {
                 char ch[3];
                 fgetc(inp);
                 fscanf(inp, "%s", ch);
                 oppose[ch[0] - 'A'].enable = -1;
                 oppose[ch[0] - 'A'].opposer = ch[1] - 'A';
                 oppose[ch[1] - 'A'].enable = -1;
                 oppose[ch[1] - 'A'].opposer = ch[0] - 'A';
                 D--;
             }
         }
         fgetc(inp);
         fscanf(inp, "%d", &N);
         fgetc(inp);
         inputString = (char *) calloc(N + 1, 1);
         fscanf(inp, "%s", inputString);
         char outString[N];
         int outIndex = 0;
         for (int i = 0; i < N; i++) {
             outString[outIndex] = inputString[i];
             if (!outIndex) {
                 outIndex++;
                 continue;
             }
 comb:
             if (combination) {
                 if (combination[outString[outIndex] - 'A'].enable == -1) {
                     for (int j = 0; j < combination[outString[outIndex] - 'A'].noOfRows; j++) {
                         if (combination[outString[outIndex] - 'A'].list[j][0] == (outString[outIndex - 1] - 'A')) {
                             outIndex--;
                             outString[outIndex] = combination[outString[outIndex] - 'A'].list[j][1] + 'A';
                             if (outIndex)
                                 goto comb;
                         }
                     }
                 }
             }
             if (oppose) {
                 if (oppose[outString[outIndex] - 'A'].enable == -1) {
                     char ch = oppose[outString[outIndex] - 'A'].opposer + 'A';
                     for (int j = outIndex - 1; j >= 0; j--) {
                         if (outString[j] == ch) {
                             outIndex = -1;
                             break;
                         }
                     }
                 }
             }
             outIndex++;
         }
         fprintf(out, "Case #%d: [", ++testCount);
         for(int i = 0; i < outIndex; i++) {
             fprintf(out, "%c", outString[i]);
             if(i != outIndex - 1)
                 fprintf(out, ", ");
         }
         fprintf(out, "]\n");
         testCases--;
         if (combination)
             free(combination);
         if (oppose)
             free(oppose);
         if (inputString)
             free(inputString);
     }
     return (EXIT_SUCCESS);
 }
