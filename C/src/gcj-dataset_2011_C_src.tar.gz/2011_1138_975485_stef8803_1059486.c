#include <stdio.h>
 
 int v[1001];
 
 void go(int nr){
 	int n,i,x,sum=0,sum2=0;
 	scanf("%d",&n);
 	int min=2000000;
 	for(i=0;i<n;++i){
 		scanf("%d",&x);
 		if(min>x)
 			min = x;
 		v[i]=x;
 		sum ^= x;
 		sum2+=x;
 	}
 	if(sum)
 		printf("Case #%d: NO\n",nr);
 	else
 		printf("Case #%d: %d\n",nr,sum2-min);
 	fflush(stdout);
 }
 
 int main(){
 	int T,i;
 	scanf("%d",&T);
 	for(i=1;i<=T;++i){
 		go(i);
 	}
 	return 0;
 }

