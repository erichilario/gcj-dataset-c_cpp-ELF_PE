#include<stdio.h>
 #include<conio.h>
 #include<stdlib.h>
 struct test
 {
  char test[250];
 }t[100];
 int or[100][2],bl[100][2];
 int stack[20]={0};
 int top=-1;
 
 int pre(char a)
 {
  int m=0;
   switch(a)
   {
 	case '0': m=0; break;
 	case '1': m=1; break;
 	case '2': m=2; break;
 	case '3': m=3; break;
 	case '4': m=4; break;
 	case '5': m=5; break;
 	case '6': m=6; break;
 	case '7': m=7; break;
 	case '8': m=8; break;
 	case '9': m=9; break;
   }
  return m;
 }
 
 int cal(char a[])
 {
  int i=0,j=0,k=0,no_of_button=0,last=0,no=0,temp1=0,temp2=0,x=0,y=0;
 Z: no_of_button=no_of_button*10+pre(a[i]);
  if(a[i+1]>='0' && a[i+1]<='9')
  {
   i++;
   goto Z;
  }
  while(no<no_of_button && a[i]!='\0')
  {
   x=0; y=0;temp1=0;temp2=0;
   if(a[i]=='O')
   {
       i+=2;
       X:temp1=temp1*10+pre(a[i]);
 	if(a[i+1]!='\0')
 	{if((a[i+1]>='0' && a[i+1]<='9'))
 	{
 	  i++;
 	  goto X;
 	}}
       or[j][0]=temp1;
 
       if(j-1<0)
       {	y=temp1;}
       else
       {
 	y=or[j-1][0]-or[j][0]+1+or[j-1][1];
 	if(or[j][0]>or[j-1][0])
 		y=or[j][0]-or[j-1][0]+1+or[j-1][1];
 
       }
 
       if(last==0 || last==1)
       {  or[j][1]=y; }
       else
       {
 	if(y==bl[k-1][1])
 	   or[j][1]=y+1;
 	else if( y<bl[k-1][1])
 	   or[j][1]=max(y,bl[k-1][1])+1;
 	else
 	   or[j][1]=y;
       }
 
 
       i++;
       j++;
       last=1;
        no++;
   }
   else if(a[i]=='B')
   {
       i+=2;
       Y:temp2=temp2*10+pre(a[i]);
 	if(a[i+1]!='\0')
 	{if((a[i+1]>='0' && a[i+1]<='9'))
 	{
 	  i++;
 	  goto Y;
 	}}
       bl[k][0]=temp2;
       if(k-1<0)
       { y=temp2; }
       else
       {
 	y=bl[k-1][0]-bl[k][0]+1+bl[k-1][1];
 	if(bl[k][0]>bl[k-1][0])
 		y=bl[k][0]-bl[k-1][0]+1+bl[k-1][1];
       }
 
       if(last==0 || last==2)
       { 	bl[k][1]=y;}
       else
       {
 	if(y==or[j-1][1])
 	   bl[k][1]=y+1;
 	else if(y<or[j-1][1])
 	   bl[k][1]=max(y,or[j-1][1])+1;
 	else
 	   bl[k][1]=y;	 		
       }
       i++;
       k++;
       last=2;
        no++;
   }
   else
    i++;
 
  }
  x=bl[k-1][1];
 
  if(or[j-1][1]>bl[k-1][1] && j>=0)
   x=or[j-1][1];
 
  return x;
 }
 
 int main()
 {
  int i=0,test,te;
  clrscr();
  
  scanf("%d",&te);
  
  while(te--)
  {
   fflush(stdin);
   gets(t[i].test);
   top++;
   stack[top]=cal(t[i].test);
   i++;
  }
  i=0;
  
  while(i<=top)
  {
   printf("Case #%d: %d",i+1,stack[i]);
   i++;
   printf("\n");
  }
  getch();
  return 0;
 }
