#include <stdio.h>      //#include myheader.h
 
 int main(){
 
   /* print out a message */
   printf("Hello World,\n\t and you!\n");
 
   return 0;
 }

