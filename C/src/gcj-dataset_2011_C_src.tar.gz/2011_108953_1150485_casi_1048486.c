#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 
 int main(){
     FILE * pFile;
     FILE * pOutFile;
     
     pFile = fopen("A-small-attempt0.in", "r");
     pOutFile = fopen("A-small.out", "w");
     
     int case_num;
     int loop;
     
     loop = 1;
     
     fscanf(pFile, "%d", &case_num);
      //fprintf(pOutFile, "%d\n", case_num);
     //fprintf(pOutFile, "%d", case_num);
     while(loop <= case_num){
                int n = 0;
                fscanf(pFile, "%d", &n);
                //fprintf(pOutFile, "%d\n", n);
                char temp[10];
                int k = 10;
                //getline(&temp, &k, pFile);
                //fscanf(pFile, "%s", temp);
                
                int win[101][101];
                int count_num[101];
                
                           
                int i = 0;
                int r = 0;
                int c = 0;
                
                for(r = 0; r < n; r++){
                      char* line = (char*)malloc(sizeof(char)*(n+1));
                      //int leng = 101;
                      fscanf(pFile, "%s", line);
                      //fprintf(pOutFile, "%s\n", line);
                      //getline(&line, &leng, pFile);
                      c = 0;
                      
                      for(c = 0; c < n; c++){
                            if(line[c] == '.')
                                       win[r][c] = -1;
                            else if(line[c] == '0')
                                 win[r][c] = 0;
                            else if(line[c] == '1')
                                 win[r][c] = 1;
                      }
                      
                      //r++;
                      //fprintf(pOutFile, "%s\n", line);
                      //fprintf(pOutFile, "isaac%d\n",r);
                      //fscanf(pFile, "%s", temp);
                      //fscanf(pFile, "%s", line);
                }
                
                //fprintf(pOutFile, "23%d\n", r);
                int j;
                
                j = 0;
                
                
                      
                double wp[101];
                      
                for(r = 0; r < n; r++){
                      int sum = 0;
                      int count = 0;
                      c = 0;
                      for(c = 0; c < n; c++){
                            if(win[r][c] == -1){
                                       continue;
                                       }
                            else if(win[r][c] == 0)
                                 sum = sum + win[r][c];
                            else if(win[r][c] == 1)
                                 sum = sum + win[r][c];
                            count++;
                      }
                      count_num[r] = count;
                      wp[r] = sum * 1.0 / count;
                }
                
                //for(i = 0; i < n; i++)
               //       fprintf(pOutFile, "%lf\n", wp[i]);
                
                double owp[101];
                
                //int i = 0;
                for(r = 0; r < n; r++){
                      double sum = 0;
                      int count = 0;
                      c = 0;
                      for(c = 0; c < n; c++){
                            if(win[r][c] == -1)
                                       continue;
                            else if(win[r][c] == 0)
                                 sum = sum + (wp[c] * count_num[c] - 1) / (count_num[c] - 1);
                            else if(win[r][c] == 1)
                                 sum = sum + (wp[c] * count_num[c]) / (count_num[c] - 1);
                            count++;
                      }
                      
                      owp[r] = sum / count;
                }
                
               // for(i = 0; i < n; i++)
               //       fprintf(pOutFile, "%lf\n", owp[i]);
                
                double oowp[101];
                
                //int i = 0;
                for(r = 0; r < n; r++){
                      double sum = 0;
                      int count = 0;
                      for(c = 0; c < n; c++){
                            if(win[r][c] == -1)
                                       continue;
                            else if(win[r][c] == 0)
                                 sum = sum + owp[c];
                            else if(win[r][c] == 1)
                                 sum = sum + owp[c];
                            count++;
                      }
                      
                      oowp[r] = sum / count;
                }
                
               // for(i = 0; i < n; i++)
               //       fprintf(pOutFile, "%lf\n", oowp[i]);
                
                fprintf(pOutFile, "Case #%d:\n", loop);
                
                for(r = 0; r < n; r++)
                      fprintf(pOutFile, "%g\n", 0.25 * wp[r] + 0.50 * owp[r] + 0.25 * oowp[r]);
                
                loop++;
     }
     
     fclose(pFile);
     fclose(pOutFile);
     //return 0;
 
     return 0;
 }

