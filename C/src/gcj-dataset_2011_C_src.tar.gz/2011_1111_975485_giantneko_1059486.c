#include <stdio.h>
 
 #define MAXVAL 1000001
 
 enum _bool {
 	_true = 1,
 	_false = 0
 };
 
 void
 resolve(int * array, int n, enum _bool * res, int * ans) {
 	int min = MAXVAL, sum = 0, i, cur = 0;
 	
 	for(i = 0; i < n; i++) {
 		cur ^= array[i];
 		sum += array[i];
 		if (min > array[i]) {
 			min = array[i];
 		}
 	}
 
 	if (cur == 0) {
 		*res = _true;
 		*ans = sum - min;
 	} else {
 		*res = _false;
 		*ans = 0;
 	}
 
 	return;
 }
 
 int
 main () {
 	int i, j, l, m, n, k;
 	char buf[4012];
 	char * tok;
 	int array[101];
 	int ans;
 	enum _bool res;
 
 	fgets(buf, sizeof(buf), stdin);
 	l = strtol(buf, NULL, 10);
 
 	for (i = 1; i <= l; i++) {
 		printf("Case #%i: ", i);
 
 		fgets(buf, sizeof(buf), stdin);
 		n = strtol(buf, NULL, 10);
 
 		fgets(buf, sizeof(buf), stdin);
 		tok = (char*)strtok(buf, " ");
 		for (j = 0; j < n; j++) {
 			array[j] = strtol(tok, NULL, 10);
 			tok = (char*)strtok(NULL, " ");
 		}
 		(void)resolve(array, n, &res, &ans);
 		if (res == _false) {
 			printf("NO");
 		} else {
 			printf("%d", ans);
 		}
 		printf("\n");
 	}
 	return 0;
 }
