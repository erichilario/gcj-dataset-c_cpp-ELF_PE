#include<stdio.h>
 
 
 int main()
 {
     FILE *fpread;
     FILE *fpwrite;
     FILE *fdebug;
 
     int no_tcs = 0;
     int teams;
   
     int array[105][105],count = 0;
     char temp[105];
     double wp1[105],owp1[105],oowp1[105],rip[105];
     int i = 0 ,l = 0,m = 0, n = 0,k = 0;
     int x,y;
     double wp,owp,oowp; int nog[105],ntemp; // 1- 49 : .- 46 : 0 : 48
                             //  x=p-48;
     int second_i = 0,flag = 0;
     fpread = fopen("hosa.txt","r");
     fpwrite = fopen("innond.txt","w");
     fdebug = fopen("debugg.txt","w");
     fscanf(fpread,"%d",&no_tcs);
     
     for( i = 0;i < no_tcs; i++)
     {  fprintf(fpwrite,"Case #%d:\n",i+1);
         fprintf(fdebug,"Case #%d: ",i+1);
        fscanf(fpread,"%d",&teams);  
        for(l = 0;l < teams;l++)
        { 
           fscanf(fpread,"%s",temp);  
           fprintf(fdebug,"%s \n ",temp);
          for(m = 0;m < teams;m++)
          {
             array[l][m] = temp[m] - 48 ;
              fprintf(fdebug,"%d ",array[l][m]);
          }
          fprintf(fdebug,"\n ");
        } 
 
          for( n = 0 ; n < teams ; n++)
       {  fprintf(fdebug,"n %d \n",n);
          owp1[n] = 0.0; count = 0;
         for(l = 0;l < teams;l++)
        {  if(n == l)
           continue;
           fprintf(fdebug,"l %d \n",l);
            ntemp= 0.0;owp =0.0;
           if( array[l][n] == -2 )
           continue;
          count++;
          for(m = 0;m < teams;m++)
          {
             if( array[l][m] == 0 || array[l][m] == 1)
             ntemp++;
              if((array[l][m] == 1) && (m !=n) )
              {
               owp = owp + 1;fprintf(fdebug,"m %d  owptemp  %lf  ntemp %d",m,owp,ntemp);
              } 
           }owp1[n] = owp1[n] + owp/(ntemp - 1);
             fprintf(fdebug," %d owp  %lf \n",n,owp1[n]);
         }
            owp1[n] = owp1[n]/count;fprintf(fdebug,"final %d owp  %lf \n",n,owp1[n]);	
        }
        //finding wp
         for(l = 0;l < teams;l++)
        { nog[l]= 0.0;wp = 0;oowp1[l] = 0.0; 
          for(m = 0;m < teams;m++)
          { if( array[l][m] == 0 || array[l][m] == 1)
             nog[l]++;
             if(array[l][m] == 1 )
             wp = wp + 1;
             if((l != m) && (array[l][m] != -2))
             oowp1[l] = oowp1[l] + owp1[m];
          }
           wp1[l] = wp/nog[l];
           oowp1[l] = oowp1[l]/nog[l];
           fprintf(fdebug,"wwwwwwpppppp  %lf \n",wp1[l]);
           fprintf(fdebug,"oowp  %lf \n",oowp1[l]);
           
  
        }
        for(l = 0 ; l < teams; l++)
        {
         rip[l]= 0.25 * wp1[l] + 0.50 * owp1[l] + 0.25 * oowp1[l];
         fprintf(fpwrite,"%lf \n",rip[l]);
  
        }
      
     }
     fclose(fpread);
     fclose(fpwrite);
     fclose(fdebug);
 }
 

