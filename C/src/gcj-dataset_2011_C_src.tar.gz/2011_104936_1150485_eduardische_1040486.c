#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #define MAXN 2005
 
 struct node
 {
 	int a, b;	
 };
 
 struct cnode
 {
 	int cnt;
 	int a[MAXN];	
 };
 
 
 int main ()
 {
 	int T, iT;
 	scanf("%d",&T);
 	static struct node a[MAXN];
 	static char b[MAXN][MAXN];
 	static int p[MAXN][MAXN];
 	static struct cnode c[MAXN];
 	static int num[MAXN];
 	static char b2[MAXN];
 	int cc;
 	for (iT = 0; iT < T; iT++)
 	{
 		int N, M;
 		scanf("%d %d",&N,&M);
 		int i;
 		for (i = 0; i < M; i++)
 		{
 			scanf("%d",&(a[i].a));
 			(a[i].a)--;
 		}
 		for (i = 0; i < M; i++)
 		{
 			scanf("%d",&(a[i].b));
 			(a[i].b)--;
 		}
 		memset(b,0,sizeof(b));
 		for (i = 0; i < M; i++)
 		{
 			b[a[i].a][a[i].b] = 1;
 			b[a[i].b][a[i].a] = 1;
 		}
 		for (i = 0; i < N; i++)
 		{
 			b[i][(i-1+N) % N] = 1;
 			b[i][(i+1) % N] = 1;
 		}
 		int j;
 		for (i = 0; i < N; i++)
 		{
 			for (j = 0; j < N; j++)
 			{
 				p[i][j] = -1;
 			}
 		}
 		int k, last;
 		for (i = 0; i < N; i++)
 		{
 			last = (i-1+N) % N;
 			j = (i+1) % N;
 			while (j != last)
 			{
 				k = j;
 				do
 				{
 					k = (k+1) % N;
 				} while (b[i][k] == 0);
 				p[j][i] = k;
 				j = k;
 			}
 		}
 		cc = 0;
 		int totalmin = N;
 		for (i = 0; i < N; i++)
 		{
 			for (j = 0; j < N; j++)
 			{
 				if (p[i][j] != -1)
 				{
 					c[cc].cnt = 0;
 					int x, y, z;
 					x = i; y = j;
 					do
 					{
 						c[cc].a[c[cc].cnt] = x;
 						(c[cc].cnt)++;
 						z = p[x][y];
 						p[x][y] = -1;
 						x = y;
 						y = z;
 					} while ((x != i) || (y != j));
 					if (c[cc].cnt < totalmin) totalmin = c[cc].cnt;
 					cc++;
 				}
 			}
 		}
 
 		for (i = 0; i < N; i++) num[i] = -1;
 		for (i = 0; i < cc; i++)
 		{	
 			int minw = -1;
 			int min = MAXN;
 			for (j = 0; j < cc; j++)
 			{
 				if (c[j].cnt < min)
 				{
 					min = c[j].cnt;
 					minw = j;
 				}
 			}
 			//Now let's use minw cycle
 			memset(b2,0,sizeof(b2));
 			for (j = 0; j < c[minw].cnt; j++)
 			{
 				if (num[c[minw].a[j]] != -1)
 				{
 					b2[num[c[minw].a[j]]] = 1;
 				}
 			}
 			k = 0;
 			for (j = 0; j < c[minw].cnt; j++)
 			{
 				if (num[c[minw].a[j]] == -1)
 				{
 					while ((k < (totalmin-1)) && (b2[k] == 1)) k++;
 					num[c[minw].a[j]] = k;
 					b2[k] = 1;
 				}
 			}			
 			c[minw].cnt = MAXN;
 		}
 
 		printf("Case #%d: %d\n",iT+1,totalmin);
 		for (i = 0; i < N; i++)
 		{
 			if (i) printf(" ");
 			printf("%d",num[i]+1);
 		}
 		printf("\n");
 	}
 	return 0;
 }

