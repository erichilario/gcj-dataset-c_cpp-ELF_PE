#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 FILE *fin,*fout;
 int map[26][26];
 int T,C,D,N;
 char stack[101];
 int flush[26][26];
 int inStack[26];
 int top;
 
 void initial(){
     int i,j;
     top = -1;
     for(i = 0 ; i < 26 ; ++i){
         for(j = 0 ; j < 26 ; ++j){
             map[i][j] = -1;
             flush[i][j] = 0;
         }
         inStack[i] = 0;
     }
 }
 
 void doFlush(){
     int i,flag = 0;
     if(top < 1) return;
     for(i = 0 ; i < 26 ; ++i)
         if(flush[stack[top]-'A'][i] == 1){
             if(stack[top]-'A' == i && inStack[i] > 1){
                 flag = 1;
                 break;
             }
             if(stack[top]-'A' != i && inStack[i] > 0){
                 flag = 1;
                 break;
             }
         }
     if(flag == 1){
         for(i = 0 ; i < 26 ; ++i) inStack[i] = 0;
         top = -1;
     }
 }
 
 void reduce(){
     int replace = map[stack[top]-'A'][stack[top-1]-'A'];
     if(top < 1) return;
     if(replace == -1) return;
     inStack[stack[top]-'A']--;
     inStack[stack[top-1]-'A']--;
     stack[--top] = replace+'A';
     inStack[replace]++;
     reduce();
 }
 
 void work(int num){
     int i,j;
     char temp[200];
     initial();
     fscanf(fin,"%d",&C);
     for(i = 0 ; i < C ; ++i){
         fscanf(fin,"%s",temp);
         map[temp[0]-'A'][temp[1]-'A'] = temp[2]-'A';
         map[temp[1]-'A'][temp[0]-'A'] = temp[2]-'A';
     }
     fscanf(fin,"%d",&D);
     for(i = 0 ; i < D ; ++i){
         fscanf(fin,"%s",temp);
         flush[temp[0]-'A'][temp[1]-'A'] = 1;
         flush[temp[1]-'A'][temp[0]-'A'] = 1;
     }
     fscanf(fin,"%d %s",&N,temp);
     for(i = 0 ; i < N ; ++i){
         stack[++top] = temp[i];
         inStack[stack[top]-'A']++;
         if(top > 0){
             reduce();
             doFlush();
         }
     }
     fprintf(fout,"Case #%d: [",num);
     for(i = 0 ; i < top ; ++i){
         fprintf(fout,"%c, ",stack[i]);
     }
     if(top != -1) fprintf(fout,"%c]\n",stack[top]);
     else fprintf(fout,"]\n");
 }
 
 int main(){
     fin = fopen("Magicka.in","r");
     fout = fopen("Magicka.out","w");
     int i;
     fscanf(fin,"%d",&T);
     for(i = 0 ; i < T ; ++i)
         work(i+1);
     return 0;
 }

