#include <stdio.h>
 #include <math.h>
 
 int arr[11000];
 int cur = 0;
 
 void main() {
     int ntests, nsteps;
     int t1=1, t2=1, free = 0, tot = 0;
     int i, j, k, t, d, last = -1;
     char c;
 
     scanf("%d", &ntests);
     for (k = 0; k < ntests; k++) {
         free = 0; last = -1; t1 = 1; t2 = 1; tot = 0;
         scanf("%d", &nsteps);
         for (i = 0; i < nsteps; i++) {
             do {
                 scanf("%c", &c);
             } while(c == ' ');
             scanf("%d", &d);
             if (c == 'O') {
                 if (last != 2) {
                     tot += (abs(d-t1) + 1); 
                     free -= (abs(d-t1) + 1);
                     //printf("hello1\n");
                 }
                 else {
                     free *= -1;
                     t = (abs(d-t1) + 1);
                     if (t <= free) {
                         tot++; free = -1;
                         //printf("hello2\n");
                     }
                     else {
                         tot += (t-free); free -= t;
                         //printf("hello3\n");
                     }
                 }
                 last = 1;
                 t1 = d;
             }
             else {
                 if (last != 1) {
                     tot += (abs(d-t2) + 1); 
                     free -= (abs(d-t2) + 1);
                     //printf("hello4\n");
                 }
                 else {
                     free *= -1;
                     t = (abs(d-t2) + 1);
                     if (t <= free) {
                         tot++; free = -1;
                         //printf("hello5\n");
                     }
                     else {
                         tot += (t-free); free -= t;
                         //printf("hello6\n");
                     }
                 }
                 last = 2;
                 t2 = d;
             }
         }
         printf("Case #%d: %d\n", k+1, tot);
     }
 }

