#include <stdio.h>
 
 #define MAX_BUTTONS 100
 
 int solveCase(void);
 void zeroArray(int arr[]);
 
 int solveCase(void)
 {
 	int numButtons;
 	int seconds = 0;
 	int seqB[MAX_BUTTONS];
 	int seqO[MAX_BUTTONS];
 	char seqButtons[MAX_BUTTONS + 1];
 	int b = 0;
 	int buttons = 0;
 	int o = 0; // array indexes
 	int posO = 1;
 	int posB = 1;
 	char tempChar;
 	int tempInt;
 	int i;
 	
 	// blank arrays
 	zeroArray(seqB);
 	zeroArray(seqO);
 	scanf("%d", &numButtons);
 	
 	for (i = 0; i < numButtons; i++)
 	{
 		tempChar = 'Z';
 		while (tempChar != 'B' && tempChar != 'O')
 		{
 			scanf("%c", &tempChar);
 		}
 		scanf("%d", &tempInt);
 		if (tempChar == 'B')
 		{
 			seqB[b] = tempInt;
 			b++;
 		} else {
 			seqO[o] = tempInt;
 			o++;
 		}
 		seqButtons[buttons] = tempChar;
 		buttons++;
 	}
 	seqButtons[buttons] = 'F';
 	b = o = buttons = 0;
 	
 	while (seqButtons[buttons] != 'F')
 	{
 		int movedB = 1;
 		int movedO = 1;
 		// move B
 		if (posB == seqB[b])
 		{
 			movedB = 0;
 		} else if (posB < seqB[b])
 		{
 			posB++;
 		} else {
 			posB--;
 		}
 		// move O
 		if (posO == seqO[o])
 		{
 			movedO = 0;
 		} else if (posO < seqO[o])
 		{
 			posO++;
 		} else {
 			posO--;
 		}
 		
 		if (seqButtons[buttons] == 'B')
 		{
 			if (!movedB)
 			{
 				buttons++;
 				b++;
 			}
 		} else {
 			if (!movedO)
 			{
 				buttons++;
 				o++;
 			}
 		}
 		seconds++;
 	}
 	
 	return seconds;
 }
 
 void zeroArray(int arr[])
 {
 	int i;
 	for (i = 0; i < MAX_BUTTONS; i++)
 	{
 		arr[i] = 0;
 	}
 }
 
 int main(int argc, char * argv[])
 {
 	int testCases;
 	int i;
 	
 	scanf("%d", &testCases);
 	
 	for (i = 1; i <= testCases; i++)
 	{
 		int result;
 		result = solveCase();
 		printf("Case #%d: %d\n", i, result);
 	}
 	
 	return 0;
 }

