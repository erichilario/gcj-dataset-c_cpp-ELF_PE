#include <stdio.h>
 #include <stdlib.h>
 #include <sys/types.h>
 #include <sys/stat.h>
 #include <fcntl.h>
 
 typedef struct{
     char base_element_1;
     char base_element_2;
     char combine;
 } combined;
 
 typedef struct{
     combined tab[40];
     int length;
 }c;
 
 typedef struct{
     char base_element_1;
     char base_element_2;
 }opposed;
 
 typedef struct{
     opposed tab[30];
     int length;
 }o;
 
 typedef struct{
     char tab[100];
     int length;
 }chaine;
 
 chaine chaine_init;
 chaine chaine_final;
 
 o opposition;
 c combination;
 
 #define line_max 1000
 
 int readLine(char* tab, int fd)
 {
 
     int i=0;
     read(fd, &tab[i], 1);
     while(tab[i] != '\n' && tab[i] != '\0')
         read(fd, &tab[++i], 1);
     tab[i] = '\0';
     return --i;
 }
 
 void parseLine(char* line, int length)
 {
     int pos = 0;
 
     /* Combinaisons */
     char nombre[4]; for(int k=0; k<4; ++k) nombre[k] = '\0';
     for(int i=0; line[pos] != ' '; ++pos, ++i)
         nombre[i] = line[pos];
     int nb = atoi(nombre);
 
     ++pos; // On saute l'espace.
 
     combination.length = nb;
     for(int i=0; i<nb; ++i)
     {
         combination.tab[i].base_element_1 = line[pos++];
         combination.tab[i].base_element_2 = line[pos++];
         combination.tab[i].combine = line[pos++];
         ++pos; // espace
     }
     printf("\n");
     /* Opposition */
     for(int k=0; k<4; ++k) nombre[k] = '\0';
     for(int i=0; line[pos] != ' '; ++pos, ++i)
         nombre[i] = line[pos];
     nb = atoi(nombre);
 
     ++pos; // on saute l'espace.
 
     opposition.length = nb;
     for(int i=0; i<nb; ++i)
     {
         opposition.tab[i].base_element_1 = line[pos++];
         opposition.tab[i].base_element_2 = line[pos++];
         ++pos; // espace
     }
     /* Chaine d'invocation */
     for(int k=0; k<4; ++k) nombre[k] = '\0';
     for(int i=0; line[pos] != ' '; ++pos, ++i)
         nombre[i] = line[pos];
     nb = atoi(nombre);
 
     ++pos; //espace
 
     chaine_init.length = nb;
     for(int i=0; i<nb; ++i)
     {
         chaine_init.tab[i] = line[pos++];
     }
     chaine_init.tab[nb] = '\0';
 }
 void oppose(void)
 {
     if(chaine_final.length <= 1) return ;
 
     char elem = chaine_final.tab[chaine_final.length - 1] ;
     int end=1;
     for(int i=0; i < opposition.length && end; ++i)
     {
         char elemO1 = opposition.tab[i].base_element_1;
         char elemO2 = opposition.tab[i].base_element_2;
 
         if(elemO1 == elem || elemO2 == elem)
         {
             char elemRemain = (elemO1 == elem) ? elemO2 : elemO1 ;
 
             for(int j=0; j<chaine_final.length-1 && end; ++j)
             {
                 if(chaine_final.tab[j] == elemRemain)
                 {
                     chaine_final.length = 0;
                     end = 0;
                 }
             }
         }
     }
 }
 void combine(void)
 {
     if(chaine_final.length <= 1) return;
 
     char elem1 = chaine_final.tab[chaine_final.length-1] ;
     char elem2 = chaine_final.tab[chaine_final.length-2] ;
 
     for(int i=0; i<combination.length; ++i)
     {
         if((combination.tab[i].base_element_1 == elem1 &&   combination.tab[i].base_element_2 == elem2) ||
            (combination.tab[i].base_element_1 == elem2 &&   combination.tab[i].base_element_2 == elem1))
         {
             chaine_final.length -= 2;
             chaine_final.tab[chaine_final.length++] = combination.tab[i].combine ;
             combine();
             break;
         }
     }
 }
 void getchaine(void)
 {
     printf("Chaine initial : %s\n", chaine_init.tab);
     for(int i=0;  i< chaine_init.length; ++i)
     {
         chaine_final.tab[chaine_final.length++] = chaine_init.tab[i] ;
         combine();
         oppose();
     }
     chaine_final.tab[chaine_final.length] = '\0' ;
 }
 
 void writeOutput(int fd,int num)
 {
     char prefixe[7] = {'C','a','s','e',' ','#','\0'};
     write(fd, prefixe, 6);
     char numero[5] = {'\0','\0','\0','\0','\0'};
     sprintf(numero, "%d", num);
     int i;
     for(i=0; i<5 && numero[i] != '\0'; ++i) write(fd, &numero[i], 1);
     char prefixe2[3] = {':', ' ', '\0'};
     write(fd, prefixe2, 2);
 
     char parenth1 = '[';
     char parenth2 = ']';
 
     write(fd, &parenth1, 1);
 
     for(i=0; i < chaine_final.length - 1; ++i)
     {
         char separator[3] = {',', ' ','\0'};
         write(fd, &chaine_final.tab[i], 1);
         write(fd, separator, 2);
     }
     if(i<chaine_final.length)
         write(fd, &chaine_final.tab[i], 1 );
     write(fd, &parenth2, 1);
     char retourLigne = '\n';
     write(fd, &retourLigne, 1);
 }
 
 int main(int argc, char* argv[])
 {
     /* Ouverture du fichier d'input */
     if(argc != 2)
         exit(EXIT_FAILURE);
 
     int fd = open(argv[1], O_RDONLY);
     if(fd == -1){ printf("openning failed");
         exit(EXIT_FAILURE);
     }
 
     int fd_output = creat("output", S_IRWXU);
 
     char one_line[line_max] ;
     readLine(one_line, fd);
     int nb_cases = atoi(one_line);
 
     for(int i=0; i < nb_cases; ++i)
     {
         int len = readLine(one_line, fd);
         parseLine(one_line, len);
         getchaine();
         writeOutput(fd_output, i+1);
         chaine_final.length = 0;
         chaine_init.length = 0;
         opposition.length = 0;
         combination.length = 0;
     }
 }

