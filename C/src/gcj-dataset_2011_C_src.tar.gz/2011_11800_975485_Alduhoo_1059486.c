#include <stdio.h>
 
 #define MAX_CANDY 1000
 
 int patSum(int arr[], int begin, int end);
 int seanSum(int arr[], int begin, int end);
 
 int patSum(int arr[], int begin, int end)
 {
 	int sum = 0;
 	int i;
 	
 	for (i = begin; i <= end; i++)
 	{
 		sum = sum ^ arr[i];
 	}
 	
 	return sum;
 }
 
 int seanSum(int arr[], int begin, int end)
 {
 	int sum = 0;
 	int i;
 	
 	for (i = begin; i <= end; i++)
 	{
 		sum = sum + arr[i];
 	}
 	
 	return sum;
 }
 
 void zeroArray(int arr[])
 {
 	int i;
 	for (i = 0; i < MAX_CANDY; i++)
 	{
 		arr[i] = 0;
 	}
 }
 
 int solveCandy(void)
 {
 	int numCandy;
 	int candy[MAX_CANDY];
 	int i;
 	int half = 0;
 	int result = 0;
 	
 	scanf("%d", &numCandy);
 	zeroArray(candy);
 	
 	for (i = 0; i < numCandy; i++)
 	{
 		scanf("%d", (candy + i));
 	}
 	
 	while (half <= numCandy - 2)
 	{
 		int val1, val2;
 		val1 = patSum(candy, 0, half);
 		val2 = patSum(candy, half + 1, numCandy - 1);
 		
 		if (val1 == val2)
 		{
 			int v1, v2;
 			v1 = seanSum(candy, 0, half);
 			v2 = seanSum(candy, half + 1, numCandy - 1);
 			if (v1 > result)
 			{
 				result = v1;
 			}
 			if (v2 > result)
 			{
 				result = v2;
 			}
 		}
 		half++;
 	}
 	
 	return result;
 }
 
 int main(int agrc, char * argv[])
 {
 	int testCases;
 	int i;
 	
 	scanf("%d", &testCases);
 	
 	for (i = 1; i <= testCases; i++)
 	{
 		int result = solveCandy();
 		printf("Case #%d: ", i);
 		if (result)
 		{
 			printf("%d", result);
 		} else {
 			printf("NO");
 		}
 		printf("\n");
 	}
 	
 	return 0;
 }

