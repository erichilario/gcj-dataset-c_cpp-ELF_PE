#include <stdio.h>
 #include <strings.h>
 
 int main(int argc,char *argv[])
 {
 	int t;
 	scanf("%d\n",&t);
 	//printf("t:%d\n",t);
 
 	int i;
 	for(i=0;i<t;i++)
 	{
 		int n;
 		scanf("%d\n",&n);
 		//printf("n:%d\n",n);
 
 		char tab[n][n];
 		int j,k;
 
 		for(j=0;j<n;j++)
 		{
 			for(k=0;k<n;k++)
 			{
 				scanf("%c",&tab[j][k]);
 				//printf("%c",tab[j][k]);
 			}
 			scanf("\n");
 			//printf("\n");
 		}
 
 		printf("Case #%d:\n",i+1);
 
 		double wp[n],owp[n],no[n];
 		bzero(wp,sizeof(wp));
 		bzero(owp,sizeof(owp));
 		bzero(no,sizeof(no));
 		for(j=0;j<n;j++)
 		{
 			int w=0,l=0;
 			for(k=0;k<n;k++)
 			{
 				if(tab[j][k]=='1')
 				{
 					w++;
 					int m;
 					int wo=0,lo=0;
 					for(m=0;m<n;m++)
 					{
 						if(m==j)
 						{
 							continue;
 						}
 						if(tab[k][m]=='1')
 						{
 							wo++;
 						}
 						else if(tab[k][m]=='0')
 						{
 							lo++;
 						}
 					}
 					owp[j]+=(double)wo/(float)(wo+lo);
 					no[j]++;
 				}
 				else if(tab[j][k]=='0')
 				{
 					l++;
 					int m;
 					int wo=0,lo=0;
 					for(m=0;m<n;m++)
 					{
 						if(m==j)
 						{
 							continue;
 						}
 						if(tab[k][m]=='1')
 						{
 							wo++;
 						}
 						else if(tab[k][m]=='0')
 						{
 							lo++;
 						}
 					}
 					owp[j]+=(double)wo/(float)(wo+lo);
 					no[j]++;
 				}
 
 			}
 			wp[j]=(double)w/(float)(w+l);
 			owp[j]/=(double)no[j];	
 		}
 
 		double oowp[n];
 		bzero(oowp,sizeof(oowp));
 		for(j=0;j<n;j++)
 		{
 			for(k=0;k<n;k++)
 			{
 				if(tab[j][k]=='1'||tab[j][k]=='0')
 				{
 					oowp[j]+=owp[k];
 				}
 			}
 			oowp[j]/=(double)no[j];
 			printf("%.12lf\n",0.25*wp[j]+0.5*owp[j]+0.25*oowp[j]);
 		}
 	}
 }

