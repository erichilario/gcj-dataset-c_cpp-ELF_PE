#include<stdio.h>
 int main()
 {
     int t,t1,i,n,z,s,val,min;
     int a[100];
     freopen("1.in","r",stdin);
 	freopen("2.txt","w",stdout);
 	
     scanf("%d",&t);
         for(t1=1;t1<=t;t1++)
         {
 
             scanf("%d",&n);
             for(i=1;i<=n;i++)
                 scanf("%d",&a[i]);
                 
                 
                 s=a[1];
                 val=a[1];
                 min=a[1];
             for(i=2;i<=n;i++)
             {
                 s+=a[i];
                 val^=a[i];
                 if(a[i]<min)
                 min=a[i];
                 
             }
             
             s-=min;
             if(val==0) printf("Case #%d: %d\n",t1,s);
             else printf("Case #%d: NO\n",t1);
 
         }
 return 0;
 }

