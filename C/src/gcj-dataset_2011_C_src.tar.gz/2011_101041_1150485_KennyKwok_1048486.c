#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 #include <map>
 #include <vector>
 #include <algorithm>
 using namespace std;
 
 #define FGETS(s,n,p)		{ s[0] = 0; fgets(s,n,p); }
 #define FOR(i,a,b)		for (int i(a), _b(b); i <= _b; ++i)
 #define FORD(i,a,b)		for (int i(a), _b(b); i >= _b; --i)
 #define REP(i,n)		for (int i(0), _n(n); i < _n; ++i)
 #define REPD(i,n)		for (int i((n)-1); i >= 0; --i)
 #define FILL(a,c)		memset(a,c,sizeof(a))
 
 #define SQPOS(n,i,j)		POS((n),(n),(i),(j))
 #define POS(mx,my,x,y)		((x)*(my)+(y))
 #define POS3D(mx,my,mz,x,y,z)	((x)*(my)*(mz)+POS((my),(mz),(y),(z)))
 #define INSIDE(i,min,max)	((min)<=(i)&&(i)<(max))
 #define REMIN(v,n)		{ if ((n)<(v)) { (v)=(n); } }
 #define REMAX(v,n)		{ if ((n)>(v)) { (v)=(n); } }
 #define SWAP(a,b)		((a)^=((b)^=((a)^=(b))))
 
 #define MIN(a,b)		((a)<(b)?(a):(b))
 #define MAX(a,b)		((a)>(b)?(a):(b))
 #define	EPS			1e-11	// 1e-6
 
 #define POW2(n)			(1<<(n))
 #define HASBIT(v,bit)		(((v)&POW2(bit))!=0)
 
 typedef unsigned long long	ull;
 typedef long long		ll;
 
 template<typename T> void remin(T& a, const T& b) { if (b < a) a = b; }
 template<typename T> void remax(T& a, const T& b) { if (b > a) a = b; }
 template<typename T> T abs(T x) { return x < 0 ? -x : x; }
 template<typename T> T sqr(T x) { return x*x; }
 template<class T> T cross(T x0, T y0, T x1, T y1, T x2, T y2)
 { return (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0); }
 
 int ccw(double x0, double y0, double x1, double y1, double x2, double y2)
 { double t = cross(x0, y0, x1, y1, x2, y2); return (fabs(t) <= EPS? 0: (t < 0? -1: 1)); }
 bool line_intersect(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4)
 { return (	ccw(x1, y1, x2, y2, x3, y3)*ccw(x1, y1, x2, y2, x4, y4) < 0 &&
 		ccw(x3, y3, x4, y4, x1, y1)*ccw(x3, y3, x4, y4, x2, y2) < 0); }
 int sscanf_ilist(char *s, int n_size, int *n)
 {
 	int nz = 0, pos = 0, len = 0;
 	for (nz = 0; nz < n_size; nz++, pos += len)
 	{
 		n[nz] = -1; sscanf(s+pos, "%d%n", n+nz, &len);
 		if (n[nz] == -1) break;
 	}
 	return nz;
 }
 
 
 // Main Program (Start Here)
 int main(int argc, char *argv[])
 {
 	char buf[4096];
 	FILE *in = stdin;
 	int T;
 
 	FGETS(buf, 4096, in);
 	sscanf(buf, "%d", &T);
 	REP(c,T)
 	{
 int N;
 char line[101][101];
 double wp[101][101], owp[101][101];//, OOWP[101][101];
 
 //	Data preparaion put here
 FGETS(buf, 255, in);
 sscanf(buf, "%d", &N);
 
 REP(i,N)
 {
 FGETS(line[i], 255, in);
 //printf("L:%s\n", line[i]);
 }
 
 REP(i,N)
 REP(j,N)
 wp[i][j] = owp[i][j] = 0.0;
 
 // Cal wp
 REP(i,N)
 {
 	REP(j,N)
 	{
 		double win = 0, tot = 0;
 		REP(k,N)
 		{
 			if (j==k) continue;
 			if (line[i][k] == '.') continue;
 			if (line[i][k] == '1') win++;
 			tot++;
 		}
 		wp[i][j] = win/tot; 
 	}
 }
 
 double WP[101];
 double OWP[101];
 double OOWP[101];
 REP(i,N)
 WP[i] = OWP[i] = OOWP[i] = 0;
 
 REP(i,N)
 {
 	double win = 0, tot = 0;
 	REP(j,N)
 	{
 		if (line[i][j] == '.') continue;
 		if (line[i][j] == '1') win++;
 		tot++;
 	}
 	WP[i] = win/tot;
 }
 
 REP(i,N)
 {
 	double sum = 0.0, count = 0;
 	REP(j,N)
 	{
 		if (line[i][j] == '.') continue;
 		sum += wp[j][i];
 		count++;
 	}
 	OWP[i] = sum/count;
 //printf("OWP[%d] = %lf\n", i, OOWP[i]);
 }
 
 REP(i,N)
 {
 	double sum = 0.0, count = 0;
 	REP(j,N)
 	{
 		if (line[i][j] == '.') continue;
 		sum += OWP[j];
 		count++;
 	}
 //printf("OOWP[%d] = %lf\n", i, OOWP[i]);
 	OOWP[i] = sum/count;
 }
 
 
 
 		printf("Case #%d: ", c+1);
 //	Result Calculation/Display put here
 printf("\n");
 REP(i,N)
 {
 printf("%.10lf\n", 0.25*WP[i] + 0.5*OWP[i] + 0.25*OOWP[i]);
 }
 	}
 	return 0;
 }

