#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     int T;
     int iT;
     double WP[102];
     double OWP[102];
     double OOWP[102];
     int n;
     int i,j;
     int w;
     int t;
     char s[128][128];
     double S[128][128];
 
     scanf("%d", &T);
     for(iT=0; iT<T; iT++){
         scanf("%d", &n);
         for (i=0; i<n; i++){
             w=0;
             t=0;
             scanf("%s", &s[i]);
             for (j=0; j<n; j++){
                 if (s[i][j]=='1') w++;
                 if (s[i][j]=='0') t++;
             }
             t+=w;
             WP[i] = (double)w/(double)t;
         }
 
         for (i=0;i<n;i++){
             t=0;
             w=0;
             for(j=0; j<n; j++) {
                 if (s[i][j]=='1') w++;
                 if (s[i][j]=='0') t++;
             }
             t+=w;
             for(j=0; j<n; j++){
                 S[i][j] = 0;
                 if (s[i][j]=='1') S[i][j] = (double)(w-1)/(double)(t-1);
                 if (s[i][j]=='0') S[i][j] = (double)(w)/(double)(t-1);
             }
         }
 
         for (i=0; i<n; i++){
             OWP[i] = 0.0;
             t=0;
             for (j=0; j<n; j++){
                 if(s[i][j]=='1') { t++; OWP[i] += S[j][i];  }
                 if(s[i][j]=='0') { t++; OWP[i] += S[j][i];  }
             }
             OWP[i] /= t;
         }
 
         for (i=0; i<n; i++){
             OOWP[i] = 0.0;
             t = 0;
             for (j=0; j<n; j++){
                 if (s[i][j]=='0') { t++; OOWP[i] += OWP[j]; }
                 if (s[i][j]=='1') { t++; OOWP[i] += OWP[j]; }
             }
             OOWP[i] /= t;
         }
         printf("Case #%d:\n", iT+1);
         for (i=0; i<n; i++)
         printf("%.12lf\n", 0.25*WP[i] + 0.5*OWP[i] + 0.25*OOWP[i]);
     }
     return 0;
 }

