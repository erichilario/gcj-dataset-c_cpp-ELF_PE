#include <stdio.h>
 
 int m[100][100]={0,},cnt,t;
 double w[100],o_w[100],oo_w[100];
 double wp,sum;
 
 main(a,b,c,d,e)
 {
 	char ch;
 	int avg_cnt,play,win,lose;
 	FILE *fp;
 
 	fp = fopen("output.txt","wt");
 
 	for(scanf("%d",&cnt);cnt;cnt--)
 	{
 		for(c=0,scanf("%d%*c",&a);c<a;c++,scanf("%*c"))
 		{
 			play = win = 0;
 			for(d=0;d<a;d++)
 			{
 				scanf("%c",&ch);
 				if(ch == '.')
 					m[c][d] = -1;
 				else if(ch == '1')
 				{
 					m[c][d] = 1;
 					win++;
 					play++;
 				}
 				else if(ch == '0')
 				{
 					m[c][d] = 0;
 					play++;
 				}
 			}
 			w[c]=(double)win/play;
 		}
 
 		/*
 		for(c=0;c<a;c++)
 		{
 		for(d=0;d<a;d++)
 		{
 		printf("%d ",m[c][d]);
 		}
 		printf("%lf",w[c]);
 		puts("");
 		}
 		*/
 
 		for(c=0;c<a;c++)
 		{
 			sum = 0;
 			avg_cnt = 0;
 			for(d=0;d<a;d++)
 			{
 				if(m[c][d] != -1)
 				{				
 					avg_cnt++;
 					play = win = 0;
 					for(e=0;e<a;e++)
 					{
 						if(e == c) continue;
 						if(m[d][e] == 1)					
 						{
 							play++;
 							win++;
 						}
 						else if(m[d][e] == 0)
 						{
 							play++;
 						}
 					}
 					if(play) 
 					{
 						sum += (double)win/play;			
 						//printf("%d %lf %lf\n",c,(double)win/play,sum);
 					}
 				}
 
 			}
 			if(avg_cnt)
 				o_w[c] = sum/avg_cnt;
 			else
 				o_w[c] = 0;
 		}
 
 		for(c=0;c<a;c++)
 		{
 			sum = 0;
 			avg_cnt = 0;
 			for(d=0;d<a;d++)
 			{
 				if(m[c][d] != -1)
 				{
 					avg_cnt++;
 					sum += o_w[d];
 				}
 			}
 			if(avg_cnt)
 				oo_w[c] = sum/avg_cnt;
 			else
 				oo_w[c] = 0;
 		}
 
 
 		printf("Case #%d:\n",++t);
 		fprintf(fp,"Case #%d:\n",t);
 		for(c=0;c<a;c++)
 		{
 			printf("%.12lf\n",(0.25*w[c])+(0.5*o_w[c])+(0.25*oo_w[c]));
 			fprintf(fp,"%.12lf\n",(0.25*w[c])+(0.5*o_w[c])+(0.25*oo_w[c]));
 		}	
 	}	
 	fclose(fp);	
 }
