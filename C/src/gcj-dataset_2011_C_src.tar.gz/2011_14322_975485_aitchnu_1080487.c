#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 int main()
 {
 	int t,temp=1;
 	scanf("%d",&t);
 	while(temp<=t)
 	{
 		int n,i,tt=0,poso=1,posb=1,timeb=0,timeo=0,btn,st=0;
 		char bot[5];
 		scanf("%d",&n);
 //		printf("n=%d\n",n);
 		for(i=0;i<n;i++)
 		{
 			scanf("%s",bot);
 //			printf("bot=%s\n",bot);
 			scanf("%d",&btn);
 //			printf("btn=%d\n",btn);
 			if(strcmp(bot,"O")==0)
 			{
 				st=abs(btn-poso)+1-timeo;
 				if(st<=0)
 				{
 					st=1;
 				}
 				poso=btn;
 				timeo=0;
 				timeb=timeb+st;
 				tt=tt+st;
 //				printf("O -- > st=%d pos=%d tt=%d\n",st,poso,tt);
 			}
 			else
 			{
 				st=abs(btn-posb)+1-timeb;
 				if(st<=0)
 				{
 					st=1;
 				}
 				posb=btn;
 				timeb=0;
 				timeo=timeo+st;
 				tt=tt+st;
 //				printf("B -- > st=%d pos=%d tt=%d\n",st,posb,tt);
 			}
 		}
 		printf("Case #%d: %d\n",temp,tt);
 		temp++;
 	}
 	return 0;
 }
 

