/*
  * a.c
  *
  *  Created on: 22/05/2011
  *      Author: schester
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 
 int main(int argc, char **argv) {
 
     int i,j,n,k,t;
     char c;
     double currentwins,currentplayed;
     double currentowp,currentoowp;
     char games[100][100];
     double wn[100],pn[100],wp[100],owp[100],oowp[100];
 
 
     scanf("%d\n",&t);
     for(i=0;i<t;i++){
 
 
         scanf("%d\n",&n);
         for(j=0;j<n;j++){
         	currentwins=0;
         	currentplayed=0;
 
         	for(k=0;k<n;k++){
         		scanf("%c",&c);
         		if(c=='1'){
         			currentwins++;
         			currentplayed++;
         		} else if(c=='0'){
         			currentplayed++;
         		}
         		games[j][k]=c;
         	}
         	wn[j]=currentwins;
         	pn[j]=currentplayed;
         	wp[j]=currentwins/currentplayed;
         	scanf("\n");
         }
         for(j=0;j<n;j++){
         	currentowp=0;
         	for(k=0;k<n;k++){
         		if(games[j][k]=='1'){
         			currentowp+=(wn[k])/(pn[k]-1);
         		} else if(games[j][k]=='0'){
         			currentowp+=(wn[k]-1)/(pn[k]-1);
         		}
         	}
         	owp[j]=currentowp/pn[j];
         }
 
         for(j=0;j<n;j++){
                	currentoowp=0;
                	for(k=0;k<n;k++){
                		if(games[j][k]=='.'){
                		} else {
                			currentoowp+=owp[k];
                		}
                	}
           	oowp[j]=currentoowp/pn[j];
         }
 
         scanf("\n");
         printf("Case #%d: \n",i+1);
         for(j=0;j<n;j++){
         	/*printf("%f\n",wp[j]);
         	printf("%f\n",owp[j]);
         	printf("%f\n",oowp[j]);
 */
         	printf("%0.10f\n",0.25*wp[j]+0.5*owp[j]+0.25*oowp[j]);
         }
 
 
     }
 
 }

