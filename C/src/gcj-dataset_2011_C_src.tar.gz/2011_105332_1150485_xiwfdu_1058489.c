#include <stdio.h>
 //n points (n-1)d/2 
 
 int main(){
   int tk,ti,i,j,c,d;
   int p[200],v[200];
   double t[200],m[200];
   double tmax,ans;
   scanf("%d",&tk);
 
   for(ti=1;ti<=tk;ti++){
     printf("Case #%d: ",ti);
     scanf("%d %d",&c,&d);
     tmax=0;
     for(i=0;i<c;i++){
       scanf("%d %d",&p[i],&v[i]);
       t[i]=(v[i]-1.0)*d/2;
       if (t[i]>tmax)
 	tmax=t[i];
       m[0]=0;
       if (i>0)
 	m[i]=d-(p[i]-t[i]-p[i-1]-t[i-1])+m[i-1];
       if (m[i]<0) m[i]=0;
     }
     ans=tmax;
     if (m[c-1]>tmax) ans+=0.5*(m[c-1]-tmax);
     printf("%.12f\n",ans);
   }
     
 
   return 0;
 }

