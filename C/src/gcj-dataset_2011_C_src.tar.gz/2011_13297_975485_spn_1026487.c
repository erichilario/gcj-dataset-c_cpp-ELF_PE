#include<stdio.h>
 #include <math.h>
 #include <stdlib.h>
 #include <string.h>
 #include <sys/stat.h>
 #include<unistd.h>
 #include<errno.h>
 
 
 char C[37][3];
 char D[29][2];
 char N[101];
 char OUT[101];
 
 unsigned int out_len =0U;
 
 unsigned int combine=0;
 unsigned int opposite=0;
 unsigned int base=0;
 
 unsigned int opp_found=0;
 
 FILE *fin, *fout;
 
 void dbg_print()
 {
   int j;
 
   for(j=0;j<combine;++j)
    {
      printf("%s", C[j]);
    }
  
   
    for(j=0;j<opposite;++j)
    {
      printf("%s", D[j]);
    }
    
    for(j=0;j<base; ++j)
    {
      printf("%c", N[j]);
    }
 }
 
 void check_opp()
 {
    int i,j,k;
    int found =0;
    int found_0 = 0, found_1 = 0;
  
    for(i=0;i<opposite;++i)
    {
      found =0;
      found_0 = 0; 
      found_1 = 0;
      
      for(j=0;j<out_len;++j)
      {
 //printf("= OUT: %c, D: %c\n",OUT[j],D[i][found]);
         if ((found_0 == 0) && (OUT[j] == D[i][0]))
         {
 //printf("= out: %c, D: %c\n",OUT[j],D[i][found]);
           found++;
           found_0 = 1;
         }
 
         else if ((found_1 == 0) && (OUT[j] == D[i][1]))
         {
            found++;
            found_1 = 1;
         }
         else
         {}
 
         if(found == 2)
         {
 //printf("\nopp - %s, found: %s\n",OUT, D[i]);
            out_len = 0;
            found = 3;
            break;
         }
      }
      if(found == 3)
         break;
    }
 }
 
 void check_comb()
 {
   int i,j,k;
   int found =0;  
   int found_0 = 0, found_1 = 0;
 
   for(i=0;i<combine;++i)
   {
     found =0;
     found_0 = 0; 
     found_1 = 0;
 
     for(j=1; j<=2;++j)
     {
       if((found_0 == 0) && (OUT[out_len-j] == C[i][0]))
       {
          found++;
          found_0 = 1;
       }
 
       else if((found_1 == 0) && (OUT[out_len-j] == C[i][1]))
       {
         found++;
         found_1 = 1;
       }
       else
       {}
 
       if(found == 2)
       {
         out_len--;
         found = 3;
         OUT[out_len-1] = C[i][2];
 //printf("\nout: %s\n",OUT);
         break;
       }
     }
     
     if(found == 3)
        break;
   }
 }
 
 
 void Load()
 {
    int i, j,k;
    unsigned int tmp,inter;
    char c;
    int flag=0;
   
    combine =0;
    base =0;
    opposite =0;
    out_len = 0U;
    opp_found =0;
 
 
    (void)memset(&N[0], 0, sizeof(N));
    (void)memset(&OUT[0], 0, sizeof(OUT));
 
 
    fscanf(fin,"%u", &combine);
 
    for(j=0;j<combine;++j)
    {
      fscanf(fin,"%s", C[j]);
    }
  
    fscanf(fin,"%u", &opposite);
 
    for(j=0;j<opposite;++j)
    {
      fscanf(fin,"%s", D[j]);
    }
    
    fscanf(fin,"%u", &base);
 
    fscanf(fin,"%s", &N[0]);
 
    for(i=0;i<base;++i)
    {
       //printf("%c",N[i]);
       OUT[out_len++] = N[i];
     
       if(out_len >= 2)
       {
         check_comb();
         check_opp();
       }
       
    }
 
 //   dbg_print();
  
    check_comb();
    check_opp();
 
    printf("[");
    fprintf(fout,"[");
    for(j=0;j<out_len; ++j)
    {
      printf("%c", OUT[j]);
      fprintf(fout,"%c", OUT[j]);
      if(j != out_len -1)
      {
        printf(", ");
        fprintf(fout,", ");
      }
    }
    printf("]");
    fprintf(fout,"]");
    // printf("%s",OUT);
  
    //fprintf(fout,"%lu\n",sum);
    //printf("%lu",sum);
 }
 
 
 
 void Solve()
 {
    unsigned int i,j,st=0,cur_index=0,k;
    
    //printf("%llu",amount);
    //fprintf(fout,"%llu\n",amount);
 }
 
 /*
 void Solve()
 {
   int i;
   printf("\n%llu %llu %u\n",R,K,N);
   for(i=0;i<N;++i)
   {
      printf("%llu ",groups[i]);
   }
 } */
 
 int main()
 {
         //FILE *fin,*fout;
         fin = fopen("B.txt","r");
         if(fin == NULL)
            printf("\nERROR - opening input file\n");
         fout = fopen("output","w");
         if(fout == NULL)
            printf("\nERROR - opening output file\n");
   
 	int nt, it;
         nt = 0;
 
 	fscanf(fin,"%d", &nt);
 
 	for (it = 0; it < nt; it++)
 	{
 		printf("Case #%d: ", it + 1);
                 fprintf(fout,"Case #%d: ",it+1);
 		Load();
 		Solve();
 		printf("\n");
                 fprintf(fout,"\n");
 	}
         fprintf(fout,"\n");
         fclose(fin);
         fclose(fout);
 	return 0;
 }

