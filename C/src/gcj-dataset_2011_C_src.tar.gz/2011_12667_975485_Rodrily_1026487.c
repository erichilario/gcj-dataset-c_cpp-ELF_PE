#include <stdio.h>
 #include <stdlib.h>
 #include<math.h>
 
 int main()
 {
 
     //Alocao dinmica
     //vet = (int*)malloc(4);
     //free(vet);
 
     //Leitura Linha Quebrada
     //fscanf(input, "%[^\n]", line);
 
     //Leitura Espao
     //fscanf(input, "%[^' ']", line);
 
     //Escrita Arquivo
     //fprintf(output, "Case #%i: OFF\n", i);
 
     //Converso Inteiro
     //varN = atoi(line);
 
     FILE *input, *output;
     input = fopen("B-large.in","r");
     output = fopen("B-large.out","w+");
 
     char line[100];
 
     int varT;
     int numComb, numLimp, tamEntrada, tamResp = 0;
     char vetComb[36][3], vetLimp[28][2], vetEntrada[100], vetResposta[200];
 
     fscanf(input, "%[^\n]", line);
     varT = atoi(line);
     fgetc(input);
 
     int i = 1;
     while(i <= varT){
         printf("\n\n%i\n", i);
 
         fscanf(input, "%[^' ']", line);
         numComb = atoi(line);
         fgetc(input);
         //printf("%i\n", numComb);
 
         int j = 0;
         while(j < numComb){
             fscanf(input, "%[^' ']", line);
             vetComb[j][0] = line[0];
             vetComb[j][1] = line[1];
             vetComb[j][2] = line[2];
             fgetc(input);
             j++;
         }
 
         fscanf(input, "%[^' ']", line);
         numLimp = atoi(line);
         fgetc(input);
 
         j = 0;
         while(j < numLimp){
             fscanf(input, "%[^' ']", line);
             vetLimp[j][0] = line[0];
             vetLimp[j][1] = line[1];
             fgetc(input);
             j++;
         }
 
         fscanf(input, "%[^' ']", line);
         tamEntrada = atoi(line);
         fgetc(input);
 
         fscanf(input, "%[^\n]", line);
         fgetc(input);
             printf("%i", i);
 
         j = 0;
         while(j < tamEntrada){
             vetEntrada[j] = line[j];
             j++;
         }
             printf("%i", i);
         j = 1;
 
         vetResposta[0] = vetEntrada[0];
         int numElementsResp = 1;
         while(j < tamEntrada){
             vetResposta[numElementsResp] = vetEntrada[j];
             numElementsResp++;
             int y = 0;
             //printf("%i\n", j);
             while(y < numComb){
 
                 if(vetResposta[numElementsResp - 1] == vetComb[y][0] && vetResposta[numElementsResp - 2] == vetComb[y][1] || vetResposta[numElementsResp - 1] == vetComb[y][1] && vetResposta[numElementsResp - 2] == vetComb[y][0]){
                     vetResposta[numElementsResp - 1] = '1';
                     vetResposta[numElementsResp - 2] = '1';
                     vetResposta[numElementsResp] = vetComb[y][2];
                     numElementsResp++;
                     break;
                 }
 
                 y++;
             }
             y = 0;
             while(y < numLimp){
                 int element = -1;
                 int found = 0;
 
                 if(vetResposta[numElementsResp - 1] == vetLimp[y][0]){
                     element = 1;
                 }
                 if(vetResposta[numElementsResp - 1] == vetLimp[y][1]){
                     element = 0;
                 }
                 if(element >= 0){
                     int x = numElementsResp - 2;
                     while(x >= 0){
                         if(vetResposta[x] == vetLimp[y][element]){
                             int l = 0;
                             while(l < numElementsResp){
                                 vetResposta[l] = '1';
                                 l++;
                             }
                             found = 1;
                             break;
                         }
                         x--;
                     }
                     if(found == 1)
                         break;
                 }
                 y++;
             }
             j++;
         }
         int mf = 0;
         int haveElement = 0;
         while(mf < numElementsResp){
             if(vetResposta[mf] != '1'){
                 fprintf(output, "Case #%i: [%c", i, vetResposta[mf]);
                 haveElement = 1;
                 mf++;
                 break;
             }
             mf++;
         }
 
         while(mf < numElementsResp){
             if(vetResposta[mf] != '1')
                 fprintf(output,", %c", vetResposta[mf]);
             mf++;
         }
         if(haveElement == 1)
             fprintf(output, "]\n");
         else
             fprintf(output, "Case #%i: []\n", i);
         i++;
     }
 
     fclose(input);
     fclose(output);
     return 0;
 }

