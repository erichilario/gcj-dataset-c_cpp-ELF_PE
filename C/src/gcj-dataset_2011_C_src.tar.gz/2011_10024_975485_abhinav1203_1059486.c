#include<stdio.h>
 int a[1005];
 int main()
 {
   int t,i,n,xor,sum,min,j;
   scanf("%d",&t);
   for(j=1;j<=t;j++)
     {
       scanf("%d",&n);
       xor=0;
       sum=0;
       min=1e9;
       for(i=0;i<n;i++)
 	{
 	  scanf("%d",&a[i]);
 	  xor^=a[i];
 	  sum+=a[i];
 	  if(a[i]<min)
 	    min=a[i];
 	}
       printf("Case #%d: ",j);
       if(xor==0)
 	printf("%d\n",sum-min);
       else
 	printf("NO\n");
     }
   return 0;
 }

