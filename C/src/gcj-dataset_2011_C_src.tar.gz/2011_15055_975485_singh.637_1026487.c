#include<stdio.h>
 #include<conio.h>
 struct 
 {
  char test[80];
 }t[100];
 
 struct 
 {
  char out[150];
 }o[100];
 int top=-1;
 
 int pre(char a)
 {
  int m=0;
   switch(a)
   {
 	case '0': m=0; break;
 	case '1': m=1; break;
 	case '2': m=2; break;
 	case '3': m=3; break;
 	case '4': m=4; break;
 	case '5': m=5; break;
 	case '6': m=6; break;
 	case '7': m=7; break;
 	case '8': m=8; break;
 	case '9': m=9; break;
   }
  return m;
 }
 
 int identify(char p)
 {
  int result=-1;
  switch(p)
  {
   case 'A': result=1; break;
   case 'B': result=2; break;
   case 'C': result=3; break;
   case 'D': result=4; break;
   case 'E': result=5; break;
   case 'F': result=6; break;
   case 'G': result=7; break;
   case 'H': result=8; break;
   case 'I': result=9; break;
   case 'J': result=10; break;
   case 'K': result=11; break;
   case 'L': result=12; break;
   case 'M': result=13; break;
   case 'N': result=14; break;
   case 'O': result=15; break;
   case 'P': result=16; break;
   case 'Q': result=17; break;
   case 'R': result=18; break;
   case 'S': result=19; break;
   case 'T': result=20; break;
   case 'U': result=21; break;
   case 'V': result=22; break;
   case 'W': result=23; break;
   case 'X': result=24; break;
   case 'Y': result=25; break;
   case 'Z': result=26; break;
  }
  return(result);
 }
 
 void cal(char f[])
 {
  int i=0,b=-1,x=0, j=0,n=0,y=0;
  int a[27]={0};
  int dx[27]={0};
  int c[2][2]={0};
  if(f[0]=='1')
  {
   b=2;
   dx[identify(f[b])]=1;
   dx[identify(f[b+1])]=1;
   dx[identify(f[b+2])]=1;
   i=6;
  }
  else
  {
   b=-1;
   i=2;
  }
  if(f[i]=='1')
  {
   c[0][0]=identify(f[i+2]);
   c[0][1]=identify(f[i+3]);
   a[c[0][0]]=1;
   a[c[0][1]]=1;
   dx[c[0][0]]=1;
   dx[c[0][1]]=1;
   i=i+5;
  }
  else
  {
   i=i+2;
   c[0][0]=-1;
  }
  I:n=n*10+pre(f[i]);
  if(f[i+1]>='0' && f[i+1]<='9')
  {
   i++;
   goto I;
  }
  i=i+2;
  o[top].out[0]='[';
  j++;
  while(f[i]!='\0')
  {
   x=identify(f[i]);
   a[x]=a[x]+1;
   o[top].out[j]=f[i];
   o[top].out[++j]=',';
   y=identify(o[top].out[j-3]);
   if((j-2)>=1 && dx[x]==1 && dx[y]==1 && ((o[top].out[j-1]==f[b] && o[top].out[j-3]==f[b+1]) || (o[top].out[j-3]==f[b] && o[top].out[j-1]==f[b+1])))
   {
         a[x]-=1;
 	a[y]-=1;
 	o[top].out[j-3]=f[b+2];
 	y=identify(f[b+2]);
         a[y]+=1;
 	j-=2;
   }
   else if(c[0][0]!=-1)
   {
    if(a[c[0][0]]>1 && a[c[0][1]]>1)
    {
 	a[c[0][0]]=0;
 	a[c[0][1]]=0;
 	o[top].out[1]='\0';
 	j=0;
    }
   }
   j++;
   i++;
  }
 
 
    if(j==1)
    {
      o[top].out[j]=']';
      j=2;
    }
    else
     o[top].out[j-1]=']';
  o[top].out[j]='\0';
 }
 
 int main()
 {
  int i=0,te=0;
  scanf("%d",&te);
  while(te--)
  {
   fflush(stdin);
   gets(t[i].test);
   top++;
   cal(t[i].test);
 
   i++;
  }
 
   i=0;
  
  while(i<=top)
  {
   printf("Case #%d: %s",i+1,o[i].out);
   i++;
   printf("\n");
   getch();
  }
  return 0;
 }
