#include<stdio.h>
 #include<limits.h>
 int main()
 {
 	int t,i,j,total,to,min,n,a[1000];
 	scanf("%d",&t);
 	for(j=1;j<=t;j++)
 	{
 		scanf("%d",&n);
 		total=0;
 		min=INT_MAX;
 		to=0;
 		for(i=0;i<n;i++)
 		{
 			scanf("%d",&a[i]);
 			total^=a[i];
 			to+=a[i];
 			if(a[i]<min)
 				min=a[i];
 		}
 		if(total!=0)
 			printf("Case #%d: NO\n",j);
 		else
 			printf("Case #%d: %d\n",j,to-min);
 	}
 	return 0;
 }

