#include <assert.h>
 #include <stdio.h>
 #include <string.h>
 
 int games[100][100], wins[100][100];
 int total_games[100], total_wins[100];
 double owp[100], oowp[100];
 
 int main()
 {
 	int t;
 	scanf("%i", &t);
 	for (int test = 1; test <= t; test++)
 	{
 		memset(games, 0, sizeof(games));
 		memset(wins, 0, sizeof(wins));
 		int n;
 		scanf("%i\n", &n);
 		for (int i = 0; i < n; i++)
 		{
 			for (int j = 0; j < n; j++)
 			{
 				char c = getchar();
 				if (c == '0' || c == '1')
 				{
 					games[i][j]++;
 					if (c == '1')
 						wins[i][j]++;
 				}
 				else
 					assert(c == '.');
 			}
 			scanf("\n");
 		}
 
 		// WP = toal_wins / total_games
 		for (int i = 0; i < n; i++)
 		{
 			total_wins[i] = total_games[i] = 0;
 			for (int j = 0; j < n; j++)
 			{
 				if (j != n)
 				{
 					total_wins[i] += wins[i][j];
 					total_games[i] += games[i][j];
 				}
 			}
 		}
 
 		// OWP
 		for (int i = 0; i < n; i++)
 		{
 			int count = 0;
 			owp[i] = 0;
 			for (int j = 0; j < n; j++)
 			{
 				if (i != j && games[j][i])
 				{
 					count++;
 					owp[i] += (double) (total_wins[j] - wins[j][i]) / (total_games[j] - games[j][i]);
 				}
 			}
 			owp[i] /= count;
 		}
 
 		// OOWP
 		for (int i = 0; i < n; i++)
 		{
 			int count = 0;
 			oowp[i] = 0;
 			for (int j = 0; j < n; j++)
 			{
 				if (i != j && games[j][i])
 				{
 					count++;
 					oowp[i] += owp[j];
 				}
 			}
 			oowp[i] /= count;
 		}
 
 		// RPI
 		printf("Case #%i:\n", test);
 		for (int i = 0; i < n; i++)
 		{
 			printf("%.6lf\n", 0.25 * ((double) total_wins[i] / total_games[i]) + 0.50 * owp[i] + 0.25 * oowp[i]);
 		}
 	}
 	return 0;
 }

