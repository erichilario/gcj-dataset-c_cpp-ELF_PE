#include <stdio.h>
 #include <stdlib.h>
 //#include "bot_trust.h"
 #include "magicka.h"
 
 int main (int argc, const char * argv[]) {
 	//solve_bot_trust();
 	solve_magicka();
     return 0;
 }

