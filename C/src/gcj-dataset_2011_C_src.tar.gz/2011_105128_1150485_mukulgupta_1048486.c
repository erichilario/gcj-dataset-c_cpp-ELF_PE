#include<stdio.h>
 
 #define WIN 0
 #define LOSS 1
 #define TOTAL 2
 #define WP 0
 #define OP 1
 #define OOP 2
 
 int main()
 {
  int t,i,n,j,k;
  double card[400][10];
  double score[400][10],temp,r;
  char a[400][400];
  FILE *fp,*fp2;
  fp=fopen("PA.in","r");
  fp2=fopen("PA.out","w");
  fscanf(fp,"%d",&t);
  for (i=1;i<=t;i++)   
  {temp=0;
  fscanf(fp,"%d",&n);
  for (j=1;j<=n;j++)
  fscanf(fp," %s",a[j]);
  for (j=1;j<=100;j++)
  for (k=0;k<=4;k++)
  card[j][k]=0;
  for (j=1;j<=n;j++)
  {
  for (k=0;k<n;k++)
  {
  if (a[j][k]=='1')
  {card[j][WIN]++;
   card[j][TOTAL]++;   
  }
  if (a[j][k]=='0')
  {card[j][LOSS]++;
   card[j][TOTAL]++;   
 }
  }
 // printf("%lf %lf %lf\n",card[j][WIN],card[j][LOSS],card[j][TOTAL]);
  score[j][WP]=((double)card[j][WIN])/((double)card[j][TOTAL]);
  }
  
  for (j=1;j<=n;j++)
  {temp=0;
  r=0;
  for (k=0;k<n;k++)
  {    
  if (a[j][k]=='0' || a[j][k]=='1')
                   {r++;
                   if (a[k+1][j-1]=='1')
                   temp+=((double)(card[k+1][WIN]-1))/((double)(card[k+1][TOTAL]-1));
                   else
                   temp+=((double)(card[k+1][WIN]))/((double)(card[k+1][TOTAL]-1));
                   }    
       }   
  score[j][OP]=temp/r;        
  }
   for (j=1;j<=n;j++)
  {temp=0;
  r=0;
  for (k=0;k<n;k++)
  {    
  if (a[j][k]=='0' || a[j][k]=='1')
                   {r++;
                   temp+=score[k+1][OP];
                   }    
       }   
  score[j][OOP]=temp/r;        
  }
  fprintf(fp2,"Case #%d:\n",i);   
  for (j=1;j<=n;j++)
  {
   fprintf(fp2,"%lf\n",0.25*score[j][WP]+0.5*score[j][OP]+0.25*score[j][OOP]);       
  }      
 }   
 
  return 0;   
 }

