#include<stdio.h>
 
 int main() {
     int t,cs,n,i,j,coutr;
     double rpi[200],wp[200],owp[200],oowp[200],temp;
     char arr[200][200];
     scanf("%d",&t);
     for(cs=1;cs<=t;cs++)
     {
                 int ctr[200]={0},total[200]={0};         
                 printf("Case #%d:\n",cs);
                 scanf("%d",&n);
                 for(i=0;i<n;i++)
                          scanf("%s",&arr[i]);
                          
                          
                 for(i=0;i<n;i++)
                  {
                          for(j=0;j<n;j++)
                           {
                                     if(arr[i][j]=='1') ctr[i]++;
                                     if(arr[i][j]!='.') total[i]++;
                           }
                  }
                                                        
                for(i=0;i<n;i++)  
                        wp[i]=(double)ctr[i]/(double)total[i];
                        
                        
                 for(j=0;j<n;j++)
                  {
                          temp=0.0; coutr=0;       
                         for(i=0;i<n;i++)
                          {
                                    if(i==j) continue;
                                    if(arr[i][j]=='0') { temp+=(double)ctr[i]/(double)(total[i]-1); coutr++; }
                               else if(arr[i][j]=='1') { temp+=(double)(ctr[i]-1)/(double)(total[i]-1); coutr++; }
                               }
                               owp[j]=temp/(double)coutr;
                               }
                               
                   for(j=0;j<n;j++)
                    {
                              temp=0.0; coutr=0;      
                              for(i=0;i<n;i++)
                               {
                                     if(i==j) continue;          
                                     if(arr[i][j]!='.')   { temp+=owp[i]; coutr++; }
                                     }
                                     oowp[j]=temp/(double)coutr;
                                     }
                                     
                                     
                   for(i=0;i<n;i++)
                    {
                                    rpi[i]=(0.25*wp[i])+(0.50*owp[i])+(0.25*oowp[i]);
                                    printf("%f\n",rpi[i]);
                                    }
                   }  
                    return 0;
 }                                                                               
                                                                                                
     

