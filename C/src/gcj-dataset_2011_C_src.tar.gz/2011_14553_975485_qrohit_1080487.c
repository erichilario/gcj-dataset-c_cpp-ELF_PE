#include<stdio.h>
 int or[100];
 int bl[100];
 char orbl[100];
 
 int main(){
 	int l,t,n,i,count,b,o,omove,bmove,j,k;
 	scanf("%d",&t);
 	for(l=1;l<=t;l++){
 		count=0;
 		b=1;o=1;
 		scanf("%d",&n);
 		for(i=0,j=0,k=0;i<n;i++){
 			char c;
 			scanf("%c%c",&c,&orbl[i]);
 			if(orbl[i]=='O')
 				scanf("%d",&or[j++]);
 			else scanf("%d",&bl[k++]);
 		}
 		
 		
 		for(i=0,j=0,k=0;i<n;i++){
 			switch(orbl[i]){
 				case 'O':
 					omove=abs(or[j]-o)+1;
 					if(abs(bl[k]-b)>=omove){
 						if((bl[k]-b) >0)b+=omove;
 						else b-=omove;
 					}
 					else {
 						b=bl[k];
 					}
 					o=or[j];
 					j++;
 					count+=omove;
 					
 					omove=0;
 					break;
 				case 'B':
 					bmove=abs(bl[k]-b)+1;
 					if(abs(or[j]-o)>=bmove){
 						if((or[j]-o) >0)o+=bmove;
 						else o-=bmove;
 					}
 					else {
 						o=or[j];
 					}
 					
 					b=bl[k];
 					k++;
 					count+=bmove;
 					bmove=0;
 					break;
 				default: 
 				//printf("not possible %c\n",orbl[i]);
 				break;
 			}
 		}
 		printf("Case #%d: %d\n",l,count);
 	}
 	return 0;
 }

