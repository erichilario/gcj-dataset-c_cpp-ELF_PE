#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main(){
 	int i, j, k, l, m, n, o, p, r, q, s, t, c, d, fc, fd;
 	char com[40][5], opp[30][5], str[105], out[105];
 	
 	scanf(" %d ", &t);
 	for (s = 1; s <= t; s++) {
 		scanf(" %d ", &c);
 		for (i = 0; i < c; i++) {
 			scanf(" %s ", com[i]);
 		}
 		scanf(" %d ", &d);
 		for (i = 0; i < d; i++) {
 			scanf(" %s ", opp[i]);	
 		}
 		scanf(" %d ", &r);
 		scanf(" %s ", str);
 
 		o = 1;
 		out[0] = str[0];
 		for (i = 1; i < r; i++) {
 			fc = 0;
 			fd = 0;
 			for (k = 0; k < c; k++) {
 				if ((com[k][0] == str[i] && com[k][1] == out[o-1]) ||
 				    (com[k][1] == str[i] && com[k][0] == out[o-1])) {
 					fc = 1;
 					break;
 				}
 			}
 			if (fc) {
 				out[o-1] = com[k][2];
 			} else {
 				for (j = 0; j < o; j++) {
 					for (k = 0; k < d; k++) {
 						if ((opp[k][0] == str[i] && opp[k][1] == out[j]) ||
 				    		(opp[k][1] == str[i] && opp[k][0] == out[j])) {
 							fd = 1;
 							break;		
 						}
 					}
 					if (fd) {
 						o = 0;
 						break;
 					}
 				}
 				if (!fd) {
 					out[o++] = str[i];
 				}
 			}
 		}
 	
 		printf("Case #%d: [", s);
 		if (o != 0) {
 			printf("%c", out[0]);
 		}
 		for (i = 1; i < o; i++) {
 			printf(", %c", out[i]);
 		}
 		printf("]\n");
 	}
 	
 	return 0;	
 }

