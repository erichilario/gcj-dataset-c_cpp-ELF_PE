#include<stdio.h>
 
 int main(){
     int T,n,a,i,j,k,temp,count;
     int arr[11];
     scanf("%d",&T);
     for(i=0;i<T;i++){
                      count=0;
                      scanf("%d",&n);
                      for(j=1;j<=n;j++){
                                        scanf("%d",&arr[j]);
                      }
                      for(j=1;j<=n;j++){
                                        if(arr[j]!=j)count++;
                                    /*if(arr[j]==j)continue;
                                    else{
                                        for(k=1;k<=n;k++){
                                                          if(arr[k]==j){
                                                                        temp=arr[j];
                                                                        arr[j]=arr[k];
                                                                        arr[k]=temp;
                                                                        count+=2;
                                                                        break;
                                                          }
                                        }
                                    }*/
                      }
                      printf("Case #%d: %d.000000\n",i+1,count);
     }
 }

