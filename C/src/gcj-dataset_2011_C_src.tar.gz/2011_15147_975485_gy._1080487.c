#include<stdio.h>
 #include<stdlib.h>
 
 int main() {
 	int N,i,n,o1,ot,b1,bt,cs=0,r,t,t1;
 	char s[4];
 	for(scanf("%d",&N);N--;) {
 		o1=b1=1,ot=bt=1,r=0;
 		for(scanf("%d",&n);n--;) {
 			scanf("%s %d",s,&t);
 			if (s[0]=='O') {
 				t1=ot+abs(o1-t);
 				if (t1<r) r=r+1; else r=t1+1;
 				o1=t,ot=r;
 			} else {
 				t1=bt+abs(b1-t);
 				if (t1<r) r=r+1; else r=t1+1;
 				b1=t,bt=r;
 			}
 		}
 		printf("Case #%d: %d\n",++cs,r-1);
 	}
 	return 0;
 }

