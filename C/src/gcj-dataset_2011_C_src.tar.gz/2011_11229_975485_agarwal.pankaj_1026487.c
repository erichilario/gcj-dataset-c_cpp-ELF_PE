#include<stdio.h>
 int main()
 {
 	int i,chk,d,t,t1,p,q,c,r,n,b[100];
 	char comb[100],rem[100],inp[100],a[100];
 
 
 	freopen("11.in","r",stdin);
 	freopen("4.in","w",stdout);	
 	scanf("%d",&t);
 	for(t1=1;t1<=t;t1++)
 	{
 		scanf("%d",&c);
 		//for(i=1;i<=c;i++)
 		if(c!=0)		
 		scanf("%s",comb);
 
 		scanf("%d",&d);
 		
 		if(d!=0)
 		scanf("%s",rem);
 
 		scanf("%d",&n);
 		scanf("%s",inp);
 
 			
 		for(i=0;i<=99;i++)
 		{
 			a[i]='\0';
 			b[i]=0;
 		}
 
 		p=1;
 		a[p]=inp[0];
 		q=p;
 		b[inp[0]-'A']=1;
 		for(i=1;i<n;i++)
 		{
 			b[inp[i]-'A']=1;
 			chk=0;		
 			if(c==1)
 			{
 				
 				if(a[q]!='\0')
 				if((comb[0]==inp[i] && comb[1]==a[q])||(comb[1]==inp[i] && comb[0]==a[q]))
 				{
 					a[q]=comb[2];
 					chk=1;
 				}
 					
 				
 			}
 			
 			if(d==1 && chk==0)			
 			{
 				if(b[rem[0]-'A']==1 && b[rem[1]-'A']==1)
 				{
 					q++;
 					p=q;
 					b[rem[0]-'A']=0;
 					b[rem[1]-'A']=0;
 					chk=1;
 
 					
 				}
 			}
 			
 			if(chk==0)
 			{
 				if(a[q]!='\0')
 				{
 					a[q+1]=inp[i];
 					q++;
 				}
 				else a[q]=inp[i];
 			}
 
 			//printf("%d %d\n",p,q);
 
 		}
 
 		
 		printf("Case #%d: [",t1);
 		if(a[p]!='\0') printf("%c",a[p]);
 		for(i=p+1;i<=q;i++)
 		printf(", %c",a[i]);
 
 		printf("]\n");
 			
 			
 
 	}
 return 0;
 }

