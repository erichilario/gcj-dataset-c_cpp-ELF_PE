#include<stdio.h>
 #include<stdlib.h>
 #include<ctype.h>
 #include<string.h>
 
 
 int zetai(int a,int b){if(a-b>=0)return a-b;else return b-a;}
 
 int main(){
   
  
 
   int num;
   scanf("%d",&num);
   
   int i,j=0;
   int dis[num];int oaf,baf=0;
   int bp,op=1;
   
   for(i=0;i<num;i++)dis[i]=0;
 
 
   for(i=0;i<num;i++){
     int len;
     scanf("%d",&len);
     int suji;
     char c;
     oaf=0;baf=0;
     bp=1;op=1;
     c=getchar();
 
     for(j=0;j<len;j++){
 
       if((c=getchar())=='B'){
 	c=getchar();
 	scanf("%d",&suji);
 	if(zetai(suji,bp)<=baf){dis[i];bp=suji;baf=0;oaf++;}
 	else{
 	  dis[i]=dis[i]+zetai(suji,bp)-baf+1;
 	  oaf=oaf+zetai(suji,bp)-baf+1;
 	  baf=0;bp=suji;
 }
 	
 	}
 	
       else {
 	  c=getchar();scanf("%d",&suji);
 	  if(zetai(suji,op)<=oaf){dis[i]++;op=suji;oaf=0;baf++;}
 	  else{
 	    dis[i]=dis[i]+zetai(suji,op)-oaf+1;baf=baf+zetai(suji,op)-oaf+1;op=suji;oaf=0;
 }
 	 }
 	c=getchar();
 	    
     }
     
 
   
 
     
     
 
   }
   for(i=0;i<num;i++){	printf("Case #%d: %d\n",i+1,dis[i]);}
 
   return 0;
 
 
 
 
 }

