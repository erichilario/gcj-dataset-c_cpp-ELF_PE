#include<stdio.h>
 #include<string.h>
 
 int main()
 {
 
    int T,N;
    double wp[100],owp[100],oowp[100],rip[100],num1[100],num0[100];
 	char teams[100][100];
     double tempoowp,curwp,curn0,curn1,curowp,totowp;
    int i,j,k,l,p,ip1,ip2;
 
    scanf("%d",&T);
    for(i=0;i<T;i++)
 	{
 		scanf("%d",&N);
 		for(ip1=0;ip1<N;ip1++)
 		{
 			scanf("%s",teams[ip1]);
 			num0[ip1]=0;num1[ip1]=0;
 		}
 	
 		for(k=0;k<N;k++)
 		{
 			for(l=0;l<N;l++)
 			{
 				 if(teams[k][l]=='0')
 					{ num0[k]++;}
 			 	 else if(teams[k][l]=='1')
 					{num1[k]++;}
 			}
 			wp[k]=num1[k]/(num1[k]+num0[k]);
 		}
 		
 		for(k=0;k<N;k++)
 		{ totowp=0;
 			for(l=0;l<N;l++)
 			{       
 				if(k!=l && teams[k][l]!='.')
 				{
 					curwp=wp[l];
 					curn0=num0[l];
 					curn1=num1[l];
 					if(teams[k][l]=='0')
 					{ curn1--;
 					}
 					else if(teams[k][l]=='1')
 					{curn0--;	
 					}
 					curwp=curn1/(curn1+curn0);
 					totowp=totowp+curwp;
 				}
 			}
 			owp[k]=totowp/(num0[k]+num1[k]);
 		}
 
              for(k=0;k<N;k++)
 		{    tempoowp=0;
 			for(l=0;l<N;l++)
 			{
 				if(teams[k][l]!='.')
 				{
 					tempoowp=tempoowp+owp[l];
 				}
 			}
 			oowp[k]=tempoowp/(num0[k]+num1[k]);
 		}
 		printf("Case #%d:\n",i+1);
 		for(p=0;p<N;p++)
 		{
 			rip[p]=0.25*wp[p]+0.5*owp[p]+0.25*oowp[p];
 		        	printf("%lf\n",rip[p]);
 		}
 }
 return 0;
 }
 				
 
 				
    

