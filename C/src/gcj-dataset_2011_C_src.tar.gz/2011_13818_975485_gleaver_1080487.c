#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct instruction{
   int button;
   struct instruction * next;
 }Instruction;
 
 Instruction * new_Instruction(int position){
   Instruction * i = malloc(sizeof(Instruction));
   i->button = position;
   i->next = NULL;
 }
 
 typedef struct robot{
   int button;
   Instruction * instructions;
   Instruction * last;
   int active;
   int next_button;
 }Robot;
 
 Robot * new_Robot(void){
   Robot * r;
   r = malloc(sizeof(Robot));
   r->button = 1;
   r->instructions = NULL;
   r->last = NULL;
   r->active = 0;
   r->next_button = -1;
   return r;
 }
 
 void add_instruction(Robot * r,Instruction * i){
   if(r->instructions == NULL){
     r->instructions = i;
     r->last = i;
     r->next_button = i->button;
   }else{
     r->last->next = i;
     r->last = i;
   }
 }
 
 int finished(Robot * r){
   return r->instructions == NULL;
 }
 
 int next_button(Robot * r){
   if(r->instructions == NULL)
     return -1;
   return r->instructions->button;
 }
 
 void press_button(Robot * r){
   Instruction * i;
   i = r->instructions;
   r->instructions = r->instructions->next;
   if(i != NULL)
     free(i);
   r->next_button = next_button(r);
 }
 
 void destroy_Robot(Robot * r){
   if(r != NULL)
     free(r);
 }
 
 int step(Robot * r){
   if(finished(r)){
     // Stay still
 //    printf("Stay at button %d\n",r->button);
     return 0;
   }
   if(r->next_button > r->button){
     // Step forward
     r->button++;
 //    printf("Move to button %d\n",r->button);
   }else if(r->next_button < r->button){
     // Step back
     r->button--;
 //    printf("Move to button %d\n",r->button);
   }else{
     if(r->active){
       // Press button
 //      printf("Press button %d\n",r->button);
       press_button(r);
       return 1;
     }else{
       // Stay still
 //      printf("Stay at button %d\n",r->button);
     }
   }
   return 0;
 }
 
 int main(int argc,const char *argv[]){
   int T,N;
   int time;
   Robot * order[100];
   int i,j,d,p;
   char r;
   Instruction * inst;
   Robot * orange;
   Robot * blue;
   scanf("%d\n",&T);
   for(i = 0; i < T; i++){
 //    printf("Case %d\n",i+1);
     orange = new_Robot();
     blue = new_Robot();
     /* Read Instructions */
     scanf("%d",&N);
     for(j = 0; j < N; j++){
       scanf(" %c %d",&r,&d);
       inst = new_Instruction(d);
       if(r == 'O'){
         order[j] = orange;
         add_instruction(orange,inst);
       }else{
         order[j] = blue;
         add_instruction(blue,inst);
       }
     }
 
     /* Press Buttons! */
     time = 0;
     j = 0;
     order[j]->active = 1;
     while(!finished(orange) || !finished(blue)){
 //      printf("Orange:\n");
       p = step(orange);
 //      printf("Blue:\n");
       p |= step(blue);
       time++;
       if(p){
         if(j < N)
           order[j]->active = 0;
         if(j+1 < N)
           order[++j]->active = 1;
       }
     }
     printf("Case #%d: %d\n",i+1,time);
     destroy_Robot(orange);
     destroy_Robot(blue);
   }
   return 0;
 }

