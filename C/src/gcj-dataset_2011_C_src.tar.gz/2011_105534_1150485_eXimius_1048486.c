#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
 char str[101],tab[100][100];
 int T,t,N,n,i,j,cnt,cnt2;
 double WP[100],OWP_[100],OWP[100],OOWP[100];
 
 	scanf("%d",&T);
 
 	for (t = 1; t <= T; t++)
 	{
 		scanf("%d",&N);
 
 		for (n = 0; n < N; n++)
 		{
 			scanf("%s",str);
 			for (i = 0; i < N; i++)
 			{
 				tab[n][i] = str[i];
 			}
 		}
 //WP
 		for (n = 0; n < N; n++)
 		{
 			WP[n] = 0;
 			cnt = 0;
 			for (i = 0; i < N; i++)
 			{
 				if (tab[n][i] == '1') {WP[n]++; cnt++;}
 				else if (tab[n][i] == '0') {cnt++;}
 			}
 			WP[n] /= cnt;
 		}
 //OWP
 
 		for (n = 0; n < N; n++)
 		{
 			OWP[n] = 0;
 			OWP_[n] = 0;
 			cnt2 = 0;
 			for (i = 0; i < N; i++)
 			{
 				if (tab[n][i] != '.')
 				{
 //WP of opponent played vs i
 					OWP_[i] = 0;
 					cnt = 0;
 					for (j = 0; j < N; j++)
 					{
 						if (j != n && tab[i][j] == '1') {OWP_[i]++; cnt++;}
 						else if (j != n && tab[i][j] == '0') {cnt++;}
 					}
 					if (cnt > 0) {OWP_[i] /= cnt; cnt2++;}
 					OWP[n] += OWP_[i];
 				}
 			}
 			OWP[n] /= cnt2;
 		}
 
 //OOWP
 		for (n = 0; n < N; n++)
 		{
 			OOWP[n] = 0;
 			cnt = 0;
 			for (i = 0; i < N; i++)
 			{
 				if (tab[n][i] != '.')
 				{
 					OOWP[n] += OWP[i];
 					cnt++;
 				}
 			}
 			OOWP[n] /= cnt;
 		}
 
 		printf("Case #%d:\n",t);
 		for (n = 0; n < N; n++) printf("%.12f\n",0.25 * WP[n] + 0.5 * OWP[n] + 0.25 * OOWP[n]);
 	}
 
     return 0;
 }

