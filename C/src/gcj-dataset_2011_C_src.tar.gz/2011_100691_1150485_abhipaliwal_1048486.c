#include<stdio.h>
 
 int main()
 {
 	int n,p;
 	char c;
 	scanf("%d",&p);
 	int k,i;
 	for(k=0;k<p;k++)
 	{
 
 		scanf("%d",&n);
 		int j;
 		double wp[n],owp[n],oowp[n];
 		int y[n],t[n];
 		char s[n][n+1];
 		for(j=0;j<n;j++)
 		{
 			y[j]=t[j]=0;
 			scanf("%s",&s[j][0]);
 			oowp[j]=wp[j]=owp[j]=0.0;
 //			puts(s[j]);
 		}
 	
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<n;j++)
 			{
 				if(s[i][j]!='.')
 				{
 					t[i]++;
 					wp[i]+=s[i][j]-48;
 				}	
 			}
 //			printf("%d %f\n",i+1,wp[i]/t[i]);
 		}
 //		puts("owp");
 		for(i=0;i<n;i++)
 		{
 			int x=0;
 			for(j=0;j<n;j++)
 			{
 				if(s[i][j]!='.')
 				{
 					owp[i]+=(wp[j]-s[j][i]+48)/(t[j]-1);
 					x++;
 				}
 			
 			}
 			owp[i]/=x;
 //			printf("%d %f\n",i+1,owp[i]);
 		}
 		printf("Case #%d:\n",k+1);
 		for(i=0;i<n;i++)
 		{
 			int x=0;
 			for(j=0;j<n;j++)
 			{
 				if(s[i][j]!='.')
 				{
 					x++;
 					oowp[i]+=owp[j];
 				}
 			}
 			oowp[i]/=x;
 			printf("%.12f\n",0.25*(oowp[i]+wp[i]/t[i])+0.5*owp[i]);
 		}
 	}
 	return 0;
 }

