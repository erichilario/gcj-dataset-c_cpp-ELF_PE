#include <stdio.h>
 #include <assert.h>
 
 
 #define MAXVAL 1000001
 #define MAXBUTTON 1000
 
 int
 op(int * array, int nr_array) {
 	int n, i, d;
 	int cur = 1;
 	int cost = 0;
 
 	for (i = 0; i < nr_array; i++) {
 		fprintf(stderr, "%d ", array[i]);
 		d = array[i] - cur;
 		if (d < 0) {
 			d = -d;
 		}
 		cost += d + 1;
 		cur = array[i];
 	}
 	fprintf(stderr, "\n");
 	return cost;
 }
 
 void
 resolve(int * input, int n, int * ans) {
 	int cur_orange = 1, cur_blue = 1;
 	int cost_orange = 0, cost_blue = 0;
 	int d, cost;
 
 	int i;
 
 	for (i = 0; i < 2 * n; i = i + 2) {
 		assert(input[i] == (int)'O' || input[i] == (int)'B');
 
 		if(input[i] == (int)'O') {
 			d = input[i+1] - cur_orange;
 			if(d < 0) d = -d;
 
 			if(cost_blue > cost_orange + d) {
 				cost_orange = cost_blue;
 			} else {
 				cost_orange = cost_orange + d;
 			}
 			cost_orange += 1; // cost of pushing button;
 			cur_orange = input[i+1];
 			cost = cost_orange;
 		} else {
 			d = input[i+1] - cur_blue;
 			if(d < 0) d = -d;
 			if(cost_orange > cost_blue + d) {
 				cost_blue = cost_orange;
 			} else {
 				cost_blue = cost_blue + d;
 			}
 			cost_blue += 1; // cost of pushing button;
 			cur_blue = input[i+1];
 			cost = cost_blue;
 		}
 	}
 	*ans = cost;
 	return;
 }
 
 int
 main () {
 	int i, j, l, m, n, k;
 	char buf[4096 * 2];
 	int input[4096];
 
 	fgets(buf, sizeof(buf), stdin);
 	l = strtol(buf, NULL, 10);
 
 	for (i = 1; i <= l; i++) {
 		char * bot, * tok,  * str_button;
 		int button, ans;
 
 		fgets(buf, sizeof(buf), stdin);
 
 		tok = (char*)strtok(buf, " ");
 		n = strtol(tok, NULL, 10);
 
 		bot = (char*)strtok(NULL, " ");
 		for (j = 0; j < n; j++) {
 			str_button = (char*)strtok(NULL, " ");
 			button = strtol(str_button, NULL, 10);
 
 			input[j * 2] = (int)*bot;
 			input[j * 2 + 1] = button;
 
 			bot = (char*)strtok(NULL, " ");
 		}
 
 
 		printf("Case #%i: ", i);
 		ans = 0;
 		(void)resolve(input, n, &ans);
 		printf("%d", ans);
 
 		printf("\n");
 	}
 	return 0;
 }

