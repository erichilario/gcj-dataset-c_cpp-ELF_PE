#include <stdlib.h>
 #include <stdio.h>
 
 #define MAX_TEAMS 100
 
 #define NOT_PLAYED 0
 #define VICTORY 1
 #define DEFEAT 2
 
 double calcWP(int tab[MAX_TEAMS][MAX_TEAMS], int j, int nb)
 {
 	int k;
 	int played = 0;
 	int won = 0;
 	for(k = 0; k < nb; k++)
 	{
 		switch(tab[j][k])
 		{
 			case NOT_PLAYED:
 				break;
 			case VICTORY:
 				played++;
 				won++;
 				break;
 			case DEFEAT:
 				played++;
 				break;
 		}
 	}
 	return (won*1.0)/played;
 }
 
 double calcOWP(int tab[MAX_TEAMS][MAX_TEAMS], int j, int nb)
 {
 	int k, l;
 	int owp_p = 0;
 	int played, won;
 	double owp = 0;
 	for(k = 0; k < nb; k++)
 	{
 		played = 0;
 		won = 0;
 		//Est-ce que notre quipe a jou contre l'quipe 'k' ?
 		if (tab[j][k] != NOT_PLAYED)
 		{
 			//Oui, donc elle va faire partie du calcul.
 			for(l = 0; l < nb; l++)
 			{
 				if (l != j)
 				{
 					switch(tab[k][l])
 					{
 						case NOT_PLAYED:
 							break;
 						case VICTORY:
 							played++;
 							won++;
 							break;
 						case DEFEAT:
 							played++;
 							break;
 					}
 				}
 			}
 			owp+=(won*1.0)/played;
 			owp_p++;
 		}
 	}
 	return (owp/owp_p);
 }
 
 int main(void)
 {
 	FILE *f_in, *f_out;
 	if (!(f_in = fopen("A.in", "r")))
 	{
 		printf("ERROR: no input file.\n");
 		return EXIT_FAILURE;
 	}
 	f_out = fopen("A.out", "w+");
 	//Dclarations.
 	char ch = '\n';
 	int i, j, k, n;
 	int nb_teams, nb;
 	double ootmp;
 	int tab_teams[MAX_TEAMS][MAX_TEAMS];
 	double tab_wp[MAX_TEAMS];
 	double tab_owp[MAX_TEAMS];
 	double tab_oowp[MAX_TEAMS];
 	double rpi[MAX_TEAMS];
 	fscanf(f_in, "%d\n", &n);
 	for(i = 0; i < n; i++)
 	{
 		fprintf(f_out, "Case #%d:\n", i+1);
 		//Lecture du nombre d'quipes.
 		fscanf(f_in, "%d\n", &nb_teams);
 		//Maintenant remplissons "tab_teams" avec les donnes.
 		for(j = 0; j < nb_teams; j++)
 		{
 			for(k = 0; k < nb_teams; k++)
 			{
 				while(ch == '\n') fscanf(f_in, "%c", &ch);
 				switch(ch)
 				{
 					case '.':
 						tab_teams[j][k] = NOT_PLAYED;
 						break;
 					case '0':
 						tab_teams[j][k] = DEFEAT;
 						break;
 					case '1':
 						tab_teams[j][k] = VICTORY;
 						break;
 				}
 				ch = '\n';
 			}
 		}
 		//Maintenant, il va falloir faire les calculs.
 		//Calcul des WP.
 		for(j = 0; j < nb_teams; j++)
 		{
 			tab_wp[j] = calcWP(tab_teams, j, nb_teams);
 		}
 		//Calcul des OWP.
 		for(j = 0; j < nb_teams; j++)
 		{
 			tab_owp[j] = calcOWP(tab_teams, j, nb_teams);
 		}
 		//Calcul des OOWP.
 		for(j = 0; j < nb_teams; j++)
 		{
 			nb = 0;
 			ootmp = 0;
 			for(k = 0; k < nb_teams; k++)
 			{
 				if (tab_teams[j][k] != NOT_PLAYED)
 				{
 					nb++;
 					ootmp+=tab_owp[k];
 				}
 			}
 			tab_oowp[j] = ootmp/nb;
 		}
 		//Calcul du RPI.
 		for(j = 0; j < nb_teams; j++)
 		{
 			rpi[j] = 0.25*tab_wp[j] + 0.5*tab_owp[j] + 0.25*tab_oowp[j];
 		}
 		//Affichage dans la sortie des RPI.
 		for(j = 0; j < nb_teams; j++)
 		{
 			fprintf(f_out, "%.12g\n", rpi[j]);
 		}
 	}
 	fclose(f_in);
 	fclose(f_out);
 	return EXIT_SUCCESS;
 }

