#include<stdlib.h>
 #include<stdio.h>
 #include<string.h>
 
 char score[101][101];
 double wp[101][2];
 double owp[101];
 double oowp[101];
 
 double wpx[101][101];
 
 int main(int argc, char *argv[]){
 	FILE *in = fopen(argv[1],"r");
 	stdin = in;
 	int i,t,n,j,k,l,count;
 	char line[101];
 	double rpi;
 	scanf("%d",&t);
 	for(i=1;i<=t;i++){
 		scanf("%d",&n);
 		for(j=0;j<n;j++){
 			scanf("%s",score[j]);
 //			printf("%s\n",score[j]);
 			wp[j][0] = 0;
 			wp[j][1] = 0;
 			for(k=0;k<strlen(score[j]);k++){
 				if(score[j][k]=='1'){
 					wp[j][0]++;
 					wpx[j][k]=2;
 				}else if(score[j][k]=='0'){
 					wpx[j][k]=1;
 				}else
 					wpx[j][k]=0;
 				
 				if(score[j][k]=='1' || score[j][k]=='0')
 					wp[j][1]++;
 			}
 			if(wp[j][1]>0)
 				wp[j][0] = wp[j][0]/wp[j][1];
 //			printf("wp[%d][0] = %f\n",j,wp[j][0]);
 		}
 //		printf("wp\n");
 		for(j=0;j<n;j++){
 			owp[j] = 0;
 			count=0;
 			for(k=0;k<strlen(score[j]);k++){
 				if(score[j][k]!='.'){
 					if(wpx[k][j]>0){
 						if(wp[k][1]>0){
 //							printf("+= (%f-%f)/%f\n",wp[k][0]*wp[k][1],wpx[k][j]-1,wp[k][1]-1);
 							owp[j] += (wp[k][0]*wp[k][1]-(wpx[k][j]-1))/(wp[k][1]-1);							
 						}
 						count++;
 					}
 				}
 			}
 			if(count>0)
 				owp[j] = owp[j]/(double)count;
 //			printf("owp[%d] = %f\n",j,owp[j]);
 		}
 //		printf("owp\n");
 		for(j=0;j<n;j++){
 			oowp[j] = 0;
 			count=0;
 			for(k=0;k<strlen(score[j]);k++){
 				if(score[j][k]!='.'){
 					oowp[j]+= owp[k];
 				}
 				if(score[j][k]=='1' || score[j][k]=='0')count++;
 			}
 			if(count>0)
 				oowp[j] = oowp[j]/(double)count;
 		}
 //		printf("oowp\n");
 		printf("Case #%d:\n",i);
 		for(j=0;j<n;j++){
 			rpi = ((double)0.25)*wp[j][0]+((double)0.5)*owp[j]+((double)0.25)*oowp[j];
 			printf("%.6lf\n",rpi);
 		}
 		
 	}
 	fclose(in);
 	return 0;
 }

