#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #define N 110
 int t;
 int n;
 
 char tab[N][N];
 double wp[N];
 double owp[N];
 double oowp[N];
 double rpi[N];
 int w[N];
 int l[N];
 
 void input()
 {
      int i;
      scanf("%d", &n);
      for(i = 0; i < n ;i++){
             scanf("%s", &tab[i]);
      }
 }
 
 void solve()
 {
      int i;
      int j;
      int wn, ln;
      double sum;
      int num;
      for(i = 0; i < n; i++) {
            wn = ln = 0;
            for(j = 0; j < n; j++) {
                  if(tab[i][j] == '1') wn++;
                  else if(tab[i][j] == '0') ln++;      
            }
            w[i] = wn;
            l[i] = ln;
            wp[i] = ((double)1000000.0 * wn )/ (wn + ln);
      }
      for(i = 0; i < n; i++) {
            sum = 0;
            num = 0;
            for(j = 0; j < n; j++) {
                  if(tab[i][j] == '0') {
                               num++;
                               sum += ((double)1000000.0 * (w[j]-1) )/ (w[j] + l[j] - 1);    
                  } else if(tab[i][j] == '1') {
                               num++;
                               sum += ((double)1000000.0 * (w[j]) )/ (w[j] + l[j] - 1);
                  }
            }
            owp[i] = sum / num;
      }
      
      for(i = 0; i < n; i++) {
            sum = 0;
            num = 0;
            for(j = 0; j < n; j++) {
                  if(tab[i][j] != '.') {
                               num++;
                               sum += owp[j];             
                  }
            }
            oowp[i] = sum / num;
      }
      for(i = 0; i < n; i++) rpi[i] = 0.25 * wp[i] + 0.5*owp[i] + 0.25 * oowp[i];
 }
 int main()
 {
     int i;
     int j;
 //   freopen("in","r",stdin);freopen("out","w",stdout);
    scanf("%d", &t);
     for(i = 1; i <= t; i++) {
           input();
           solve();
           printf("Case #%d:\n", i);
           for(j = 0; j < n; j++)printf("%lf\n", rpi[j]/1000000);
     }
 //    system("pause");
     return 0;
 }

