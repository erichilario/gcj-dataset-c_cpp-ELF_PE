#include <stdio.h>
 #include <stdlib.h>
 #include<math.h>
 
 int compare (const void * a, const void * b)
 {
   return ( *(int*)a - *(int*)b );
 }
 
 
 int main()
 {
 
     //Alocao dinmica
     //vet = (int*)malloc(4);
     //free(vet);
 
     //Leitura Linha Quebrada
     //fscanf(input, "%[^\n]", line);
 
     //Leitura Espao
     //fscanf(input, "%[^' ']", line);
 
     //Escrita Arquivo
     //fprintf(output, "Case #%i: OFF\n", i);
 
     //Converso Inteiro
     //varN = atoi(line);
 
     FILE *input, *output;
     input = fopen("D-small-attempt0.in","r");
     output = fopen("D-small-attempt0.out","w+");
 
     char line[100];
 
     int varT, numElementos;
     int vetOriginal[10], vetOrganizado[10], vetTerminado[10];
 
     fscanf(input, "%[^\n]", line);
     varT = atoi(line);
     fgetc(input);
 
     int i = 1;
     while(i <= varT){
         printf("\n\n%i\n", i);
 
         fscanf(input, "%[^\n]", line);
         numElementos = atoi(line);
         fgetc(input);
 
         int j = 0;
         while(j < numElementos - 1){
             fscanf(input, "%[^' ']", line);
             vetOriginal[j] = atoi(line);
             vetOrganizado[j] = atoi(line);
             vetTerminado[j] = 0;
             fgetc(input);
             j++;
         }
 
         fscanf(input, "%[^\n]", line);
         vetOriginal[numElementos - 1] = atoi(line);
         vetOrganizado[numElementos - 1] = atoi(line);
         vetTerminado[numElementos - 1] = 0;
         fgetc(input);
         qsort(vetOrganizado, numElementos, sizeof(int), compare);
 
 
         int vetOk = 0;
         int numIntera = 2;
         float resultado = 0;
         while(vetOk == 0){
             vetOk = 1;
             int x = 0;
             while(x < numElementos){
                 if(vetOriginal[x] == vetOrganizado[x] || vetTerminado[x] == 1){
                     vetTerminado[x] = 1;
                     x++;
                     continue;
                 }
                 else{
                     vetOk = 0;
                     int points[1000];
                     points[0] = x;
                     int lastPoint = 0;
                     int z = 0;
                     while(z < numIntera){
                         int w = 0;
                         while(w < numElementos){
                             if(vetOriginal[points[lastPoint]] == vetOrganizado[w]){
                                 lastPoint++;
                                 points[lastPoint] = w;
                                 break;
                             }
                             w++;
                         }
                         z++;
                     }
                     if(points[0] == points[lastPoint]){
                         resultado += numIntera;
                         int g = 0;
                         while(g <= lastPoint){
                             vetTerminado[points[g]] = 1;
                             g++;
                         }
                     }
                 }
                 x++;
             }
             numIntera++;
         }
 
 
         fprintf(output,"Case #%i: %.6f\n", i, resultado);
         i++;
     }
 
     fclose(input);
     fclose(output);
     return 0;
 }

