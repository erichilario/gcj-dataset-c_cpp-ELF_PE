/* 
  * File:   main.c
  * Author: dhruba
  *
  * Created on May 21, 2011, 9:23 PM
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 /*
  * 
  */
 int main(int argc, char** argv) {
     FILE *in, *out;
     in = fopen("./A-small-attempt0.in", "r");
     out = fopen("./output", "w");
     int test, teams, caseNum = 1;
     fscanf(in, "%d", &test);
     while (test) {
         fscanf(in, "%d", &teams);
         char table[teams][teams];
         for (int i = 0; i < teams; i++)
             fscanf(in, "%s", table[i]);
         long double wp[teams], owp[teams], oowp[teams],played[teams], won[teams];
         for (int i = 0; i < teams; i++) {
             long double win = 0, game = 0;
             for (int j = 0; j < teams; j++) {
                 if (i == j)
                     continue;
                 if (table[i][j] == '1')
                     win++;
                 if (table[i][j] != '.')
                     game++;
             }
             played[i] = game;
             won[i] = win;
             wp[i] = win / game;
         }
         for (int i = 0; i < teams; i++) {
             long double sum = 0, count = 0;
             for (int j = 0; j < teams; j++) {
                 if (i == j)
                     continue;
                 if (table[j][i] != '.') {
                     count++;
                     if (table[j][i] == '0')
                         sum += won[j] / (played[j] - 1);
                     else
                         sum += (won[j] - 1) / (played[j] - 1);
                 }
             }
             owp[i] = sum / count;
         }
         for (int i = 0; i < teams; i++) {
             long double sum = 0, count = 0;
             for (int j = 0; j < teams; j++) {
                 if (i == j)
                     continue;
                 if (table[j][i] != '.') {
                     count++;
                     sum += owp[j];
                 }
             }
             oowp[i] = sum / count;
         }
         fprintf(out, "Case #%d:\n", caseNum);
         for (int i = 0; i < teams; i++)
             fprintf(out, "%Lf\n", ((0.25 * wp[i])+(0.50 * owp[i])+(0.25 * oowp[i])));
         caseNum++;
         test--;
     }
     fclose(in);
     fclose(out);
     return (EXIT_SUCCESS);
 }
