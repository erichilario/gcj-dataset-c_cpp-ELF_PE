#include <stdio.h>
 
 
 void main()
 {
 	int cases,N,PD,PG;
 	int k,m,n,j,l,i;
 
 	char score[102][102];
 	double WP[102];
 	double OWP[102];
 	double OOWP[102];
 	double RIP[102];
 
 	double pWP[102][102];
 	double pOWP[102][102];
 	double wins;
 	double games;
 	double WP_sum,OWP_sum;
 	double count;
 	
 	scanf("%d",&cases);
 
 	
 	for(j=0;j<cases;j++)
 	{
 		scanf("%d",&N);
 		for(i=0;i<N;i++)
 		{
 			scanf("%s",score[i]);
 		}
 
 		
 		for(i=0;i<N;i++)
 		{
 			games=0;
 			wins=0;
 			for(k=0;k<N;k++)
 			{
 				if(score[i][k]=='1')
 				{
 					games++;
 					wins++;
 				}
 				else if(score[i][k]=='0')
 				{
 					games++;
 				}
 			}
 			WP[i]=wins/games;
 			for(k=0;k<N;k++)
 			{
 				if(score[i][k]=='1')
 				{
 					pWP[i][k]=(wins-1)/(games-1);
 				}
 				else if(score[i][k]=='0')
 				{
 					pWP[i][k]=(wins)/(games-1);
 				}
 				else
 				{
 					pWP[i][k]=wins/games;
 				}
 			}
 		}
 
 		for(i=0;i<N;i++)
 		{
 			WP_sum=0;
 			count=0;
 			for(k=0;k<N;k++)
 			{
 				if(score[i][k]=='1' || score[i][k]=='0')
 				{
 					WP_sum+=pWP[k][i];
 					count++;
 				}
 				
 			}
 			OWP[i]=WP_sum/count;
 		}
 
 		for(i=0;i<N;i++)
 		{
 			OWP_sum=0;
 			count=0;
 			for(k=0;k<N;k++)
 			{
 				if(score[i][k]=='1' || score[i][k]=='0')
 				{
 					OWP_sum+=OWP[k];
 					count++;
 				}
 				
 			}
 			OOWP[i]=OWP_sum/count;
 			RIP[i]=0.25*WP[i]+0.5*OWP[i]+0.25*OOWP[i];
 			
 		}
 
 		
 		
 		
 		printf("Case #%d:\n",j+1);
 		for(i=0;i<N;i++)
 		{
 			printf("%.7f\n",RIP[i]);
 		}
 		
 		
 	}
 	
 	
 }

