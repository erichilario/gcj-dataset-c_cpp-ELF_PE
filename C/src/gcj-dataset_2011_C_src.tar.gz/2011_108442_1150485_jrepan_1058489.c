#include <assert.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 
 int p[1000000];
 
 int cmp(const void *a, const void *b)
 {
 	return *(int*) a - *(int*) b;
 }
 
 int main()
 {
 	int t;
 	scanf("%i", &t);
 	for (int test = 1; test <= t; test++)
 	{
 		int c, d;
 		double time;
 		int size = 0;
 
 		scanf("%i %i", &c, &d);
 		for (int i = 0; i < c; i++)
 		{
 			int a, v;
 			scanf("%i %i", &a, &v);
 			for (int j = 0; j < v; j++)
 			{
 				p[size + j] = a;
 			}
 			size += v;
 		}
 		qsort(p, size, sizeof(int), cmp);
 
 		int ltime = 0;
 		int rtime = 0;
 		int left = 1;
 		int right = size - 2;
 
 		if (size == 1)
 			time = 0;
 		else if (size == 2)
 			time = (d - (p[1] - p[0])) / 2.0;
 		else {
 		while (left < right)
 		{
 			int *time, *index, dindex;
 			if (ltime < rtime)
 			{
 				time = &ltime;
 				index = &left;
 				dindex = 1;
 			}
 			else
 			{
 				time = &rtime;
 				index = &right;
 				dindex = -1;
 			}
 			int dtime = d - abs(p[*index] - p[*index - dindex]);
 			if (dtime > 0)
 				*time += dtime;
 			*index += dindex;
 		}
 		assert(left == right);
 
 		if (ltime > rtime)
 		{
 			time = ltime;
 			p[left + 1] += ltime - rtime;
 		}
 		else
 		{
 			time = rtime;
 			p[left - 1] -= rtime - ltime;
 		}
 		int a = d - (p[left] - p[left - 1]);
 		int b = d - (p[left + 1] - p[left]);
 		int s, v;
 		if (a > b)
 		{
 			s = a;
 			v = b;
 		}
 		else
 		{
 			s = b;
 			v = a;
 		}
 		if (v > 0)
 			s -= v;
 		if (v > 0)
 			time += v;
 		if (s > 0)
 			time += s / 2.0;
 		}
 
 		printf("Case #%i: %.6lf\n", test, time);
 	}
 	return 0;
 }
 //todo: väiksed juhud (size == 1; 2)

