#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 
 int nextpos[100], lenpos;
 char nextrobot[100];
 int nextposO[100], nextposB[100];
 int lennxtO, lennxtB;
 
 int T, N;
 
 int main() {
     int i, j, curO, curB, curposO, curposB, cur;
     int numcase;
     scanf("%d", &T);
     for(numcase=1; numcase <= T; numcase ++){
         curO = curB = lennxtO = lennxtB = 0;
         curposO = curposB = 1;
         cur = 0;
         scanf("%d", &lenpos);
         for(i=0; i<lenpos; i++){
             char robot;
             int pos;
             scanf(" %c %d", &robot, &pos);
             nextpos[i] = pos, nextrobot[i] = robot;
             if (robot == 'O') nextposO[lennxtO++] = pos;
             else nextposB[lennxtB++] = pos;
         }
         int ans;
         bool Omoved, Bmoved;
         for (ans=0; curO < lennxtO || curB < lennxtB; ans ++) {
             Omoved = Bmoved = false;
 #ifdef DEBUG
             printf("step %d\n", ans);
 #endif
             if (curO < lennxtO && curposO != nextposO[curO]) {
                 Omoved = true;
                 if (curposO < nextposO[curO]) curposO ++;
                 else curposO --;
 #ifdef DEBUG
                 printf("O moved to %d\n", curposO);
 #endif
             }
             if (curB < lennxtB && curposB != nextposB[curB]) {
                 Bmoved = true;
                 if (curposB < nextposB[curB]) curposB ++;
                 else curposB --;
 #ifdef DEBUG
                 printf("B moved to %d\n", curposB);
 #endif
             }
             if (nextrobot[cur] == 'O' && curposO == nextpos[cur] &&
                 !Omoved) {
 #ifdef DEBUG
                 printf("O pressed the button\n");
 #endif
                 curO ++;
                 cur ++;
                 continue;
             }
             if (nextrobot[cur] == 'B' && curposB == nextpos[cur] &&
                  !Bmoved) {
 #ifdef DEBUG
                 printf("B pressed the button\n");
 #endif
                 curB ++;
                 cur ++;
                 continue;
             }
         }
         printf("Case #%d: %d\n", numcase, ans);
     }
     return 0;
 }

