/*
 			       Anubhav Garg
 			    ---Google Code Jam 2011
 			    ---Read large data
 */
 
 
 #include<stdio.h>
 #include<conio.h>
 
 
 
 int main()
 {
 
  int i=0;
  int j=0;
 
  char str[10]=""; /* Used for reading only short length lines */
 
  FILE *f1;
  int test_case=0;
  FILE *f2=NULL;
 
 
 	char answer[100+2]="";
 	char rplc[108+2];
 	char vnsh[56+2];
 	char rplc2[108+2];
 	char vnsh2[56+2];    /* don't understand why this has to be
 				inside main not inside for */
 
  f2=fopen("h:\\b.out","w");
 
  clrscr();
 
  f1=fopen("h:\\A.in","r");
 	  //read a file
 
  fgets(str,6,f1);
  *(str+strlen(str)-1)='\0';
  test_case=atoi(str);
 
 
 
  for(i=0;i<test_case;i++)
  {
 
 
 	int k=0;
 	int l=0;
 
 	char result[100]="";
 	int ch=0;
 	int t=0;
 
 	char *tp1=NULL;
 	char tp2[1000];
 
 
 	char the_string[100+2];
 
 	int no_of_replace=0;
 	int no_of_vanish=0;
 
 
 
 	int ansl=0;
 	char *pt=NULL;
 	int got_it=0;
 	int w=0;
 
 
 	char *occr= NULL;
 	char pair_char='\0';
 	char *pt_start=NULL;
 
 
 
 	memset(the_string,'\0',sizeof(the_string));
 	memset(rplc,'\0',sizeof(rplc));
 	memset(vnsh,'\0',sizeof(vnsh));
 	memset(rplc2,'\0',sizeof(rplc2));
 	memset(vnsh2,'\0',sizeof(vnsh2));
 	memset(answer,'\0',sizeof(answer));
 
 	/* read replace*/
 	memset(tp2 ,'\0',sizeof(tp2));
 	tp1=tp2;
 
 	while ((ch=fgetc(f1))!=' ')
 		*tp1++=(char)ch;
 
 	*tp1='\0';
 	no_of_replace=atoi(tp2);
 
 
 	for(t=0;t<no_of_replace;t++)
 	{
 		memset(tp2,'\0',sizeof(tp2));
 		tp1=tp2;
 
 		while ((ch=fgetc(f1))!=' ')
 			*tp1++=ch;
 
 		*tp1='\0';
 		strncpy(rplc+t*3,tp2,3);
 
 
 		rplc2[t*3]  =  rplc [t*3+1];
 		rplc2[t*3+1]=  rplc [t*3];
 		rplc2[t*3+2]=  rplc [t*3+2];
 
 	}
 
 
 	/* read vanish*/
 	memset(tp2 ,'\0',sizeof(tp2));
 	tp1=tp2;
 
 	while ((ch=fgetc(f1))!=' ')
 		*tp1++=ch;
 
 	*tp1='\0';
 	no_of_vanish=atoi(tp2);
 
 
 	for(t=0;t<no_of_vanish;t++)
 	{
 		memset(tp2,'\0',sizeof(tp2));
 		tp1=tp2;
 
 		while ((ch=fgetc(f1))!=' ')
 			*tp1++=ch;
 
 		*tp1='\0';
 		strncpy(vnsh+t*2,tp2,2);
 		strrev(tp2);
 		strncpy(vnsh2+t*2,tp2,2);
 	}
 
 
 
 	/* read
 	the string */
 	while ((ch=fgetc(f1))!=' ')
 		;
 
 	memset(tp2 ,'\0',sizeof(tp2));
 	tp1=tp2;
 
 	while ((ch=fgetc(f1))!='\n')
 		*tp1++=ch;
 
 	*tp1='\0';
 	strncpy(the_string,tp2,sizeof(tp2));
 
 
 
 	/*strcpy(answer,the_string);*/
        /*
 	printf("\nreplace <%d> <%s> <%s> <%s>",no_of_replace,rplc,rplc2,the_string);
 	printf("\nvanish <%d> <%s> <%s> <%s>",no_of_vanish,vnsh,vnsh2,answer);
 	 */
 
 
 
 
 	/* --- START ---*/
 
 
 	for(j=0,w=0;j<strlen(the_string);j++,w++)
 	{
 
 		answer[w]=the_string[j];
 		pt=answer+w;
 		ansl=strlen(answer);
 
 		got_it=0;
 
 		for(k=0;k<no_of_replace && (ansl>1);k+=3)
 		{
 			if(strncmp(pt-1,rplc+k,2)==0)
 			{
 				*(pt-1)= rplc[k+2];
 				got_it=1;
 
 				w-=1;
 				*pt='\0';
 				break;
 
 			}
 
 		}
 		if(got_it==1)
 			continue;
 
 
 
 		for(k=0;k<no_of_replace && (ansl>1);k+=3)
 		{
 			if(strncmp(pt-1,rplc2+k,2)==0)
 			{
 
 				*(pt-1)= rplc2[k+2];
 				got_it=1;
 				w-=1;
 				*pt='\0';
 				break;
 
 			}
 
 		}
 		if(got_it==1)
 			continue;
 
 
 
 
 			k=0;
 
 		occr=strchr(vnsh+k++,*pt);
 
 		while(*occr)
 		{
 
 		       if((occr - vnsh) %2)
 			       pair_char=*(occr-1);
 		       else
 			       pair_char=*(occr+1);
 
 
 
 		       if(strchr(answer,pair_char))
 		       {
 				w=-1;
 
 				memset(answer,'\0',sizeof(answer));
 				got_it=1;
 				break;
 		       }
 		       occr=strchr(vnsh+k++,*pt);
 
 		}
 
 		if(got_it==1)
 			continue;
 
 
 
 	}
 
 
 
 
 
 
 	sprintf(result,"Case #%d: [",i+1);
 
 	for(j=0;j<strlen(answer);j++)
 	{
 		char unit[3]="";
 		if(strlen(answer)==1)
 
 			sprintf(unit,"%c",answer[j]);
 		else
 		if(j==0)
 			sprintf(unit,"%c,",answer[j]);
 		else
 		if((strlen(answer)-j) ==1)
 			sprintf(unit," %c",answer[j]);
 		else
 			sprintf(unit," %c,",answer[j]);
 		strcat(result,unit);
 	}
 
 	result[ strlen(result)]=']';
 	result[strlen(result)]='\n';
 	result[strlen(result)]='\0';
 
 
 
 	fprintf(f2,result);
 
 
  }
 
 
  return 0;
 
 }
