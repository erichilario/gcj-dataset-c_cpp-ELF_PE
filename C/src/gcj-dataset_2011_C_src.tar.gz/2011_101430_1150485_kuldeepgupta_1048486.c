#include<stdio.h>
 int main()
 {
 int t,l=0;
 freopen("input.txt","r",stdin);
 
 freopen("out.txt","w",stdout);
 scanf("%d",&t);
 while(++l<=t)
 {
 printf("Case #%d:\n",l);
 int n,i,j,tot[102]={0},win[102]={0};
 
 scanf("%d",&n);
 char a[n+1][n+1];
  double wp[n+1];
 for(i=0;i<n;i++)
 {
 
 scanf("%s",a[i]);
 for(j=0;j<n;j++)
 {
 if(a[i][j]=='.')continue;
 else if(a[i][j]=='1'){tot[i]++;win[i]++;}
 else if(a[i][j]=='0'){tot[i]++;}
 }
 wp[i]=(double)win[i]/tot[i];
 //printf("%lf\n",wp[i]);
 
 }
  double owp[n+1];
 for(i=0;i<n;i++)
 {  int ca=0;double sum=0.0;
     for(j=0;j<n;j++)
     {
        if(a[i][j]!='.'){ca++;
 
        if(a[i][j]=='1'){sum+=(double)win[j]/(tot[j]-1);}
       else if(a[i][j]=='0'){sum+=(double)(win[j]-1)/(tot[j]-1);}
 
        }
     }
     owp[i]=(double)sum/ca;
 //printf("%lf\n",owp[i]);
 
     }
 
 
 double oowp[n+1],rpi[n+1];
 for(i=0;i<n;i++)
 {  int ca=0;double sum=0.0;
     for(j=0;j<n;j++)
     {
        if(a[i][j]!='.'){ca++;sum+=owp[j];}
     }
     oowp[i]=(double)sum/ca;
   //  printf("%lf\n",oowp[i]);
 
     rpi[i]=0.25*wp[i]+0.5*owp[i]+0.25*oowp[i];
     printf("%lf\n",rpi[i]);
     }
 
 }
 
 return 0;
 }

