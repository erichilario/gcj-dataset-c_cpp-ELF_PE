#include <stdio.h>
 #include <stdlib.h>
 #include<math.h>
 
 int compare (const void * a, const void * b)
 {
   return ( *(int*)a - *(int*)b );
 }
 
 
 int main()
 {
 
     //Alocao dinmica
     //vet = (int*)malloc(4);
     //free(vet);
 
     //Leitura Linha Quebrada
     //fscanf(input, "%[^\n]", line);
 
     //Leitura Espao
     //fscanf(input, "%[^' ']", line);
 
     //Escrita Arquivo
     //fprintf(output, "Case #%i: OFF\n", i);
 
     //Converso Inteiro
     //varN = atoi(line);
 
     FILE *input, *output;
     input = fopen("A-small-attempt5.in","r");
     output = fopen("A-small-attempt5.out","w+");
 
     char line[100];
 
     int varT, varN, vetColors[100], vetButtons[100];
 
     fscanf(input, "%[^\n]", line);
     varT = atoi(line);
     fgetc(input);
 
     int i = 1;
     while(i <= varT){
         printf("\n\n%i\n", i);
 
         fscanf(input, "%[^' ']", line);
         varN = atoi(line);
         fgetc(input);
 
         int j = 0;
         while(j < varN - 1){
             fscanf(input, "%[^' ']", line);
             if(line[0] == 'B')
                 vetColors[j] = 1;
             else
                 vetColors[j] = 0;
             fgetc(input);
 
             fscanf(input, "%[^' ']", line);
             vetButtons[j] = atoi(line);
             fgetc(input);
             j++;
         }
 
         fscanf(input, "%[^' ']", line);
         if(line[0] == 'B')
             vetColors[j] = 1;
         else
             vetColors[j] = 0;
         fgetc(input);
 
         fscanf(input, "%[^\n]", line);
         vetButtons[varN-1] = atoi(line);
         fgetc(input);
 
 
         j=0;
         int pointVetorB = -1;
         int positionB = 1;
         int destineB = 0;
         int waitB = 0;
         int pushButtonB = 0;
 
         int pointVetorO = -1;
         int positionO = 1;
         int destineO = 0;
         int waitO = 0;
         int pushButtonO = 0;
 
         int nextButtonB = -1;
         int nextButtonO = -1;
 
         int desconto = 0;
         while(1){
             j++;
             if(waitB == 0){
                 if(pushButtonB == 1 || pointVetorB == -1){
                     pushButtonB = 0;
                     int x = pointVetorB + 1;
                     while(x < varN){
                         if(vetColors[x] == 1){
                             pointVetorB = x;
                             break;
                         }
                         x++;
                     }
                     if(x == varN)
                         waitB = 1;
                 }
                 if(waitB == 0){
                     if(positionB < vetButtons[pointVetorB])
                         positionB++;
                     else{
                         if(positionB > vetButtons[pointVetorB]){
                             positionB--;
                         }
                         else
                             if(pointVetorB < pointVetorO || (pointVetorB < nextButtonO && pushButtonO == 1) || pointVetorB == 0 || waitO){
                                 pushButtonB = 1;
                                 int x = pointVetorB + 1;
 
                                 while(x < varN){
                                     if(vetColors[x] == 1){
                                         break;
                                     }
                                     x++;
                                 }
                                 nextButtonB = x;
                                 if(x == varN){
                                     waitB = 1;
                                 }
                             }
                     }
                 }
 
             }
 
             if(waitO == 0){
                 if(pushButtonO == 1 || pointVetorO == -1){
                     pushButtonO = 0;
                     int x = pointVetorO + 1;
                     while(x < varN){
                         if(vetColors[x] == 0){
                             pointVetorO = x;
                             break;
                         }
                         x++;
                     }
                     if(x == varN)
                         waitO = 1;
                 }
                 if(waitO == 0){
                     if(positionO < vetButtons[pointVetorO])
                         positionO++;
                     else if(positionO > vetButtons[pointVetorO]){
                         positionO--;
                     }
                     else
                         if(pointVetorO < pointVetorB || pointVetorO == 0 || (waitB && pushButtonB == 0)){
                             pushButtonO = 1;
 
                             int x = pointVetorO + 1;
                             while(x < varN){
                                 if(vetColors[x] == 0){
                                     break;
                                 }
                                 x++;
                             }
                             nextButtonO = x;
                             if(x == varN){
                                 waitO = 1;
                             }
                         }
                         if(waitB && pushButtonB == 1)
                             pushButtonB = 0;
                 }
 
             }
             if(waitB==1 && waitO==1)
                 break;
         }
 
         /*int y = 1;
         int test = vetColors[0];
         while(y < varN){
             if(vetColors[y] != test){
                 desconto++;
                 test = vetColors[y];
             }
             y++;
         }*/
 
         printf("%i\n\n", desconto);
         fprintf(output,"Case #%i: %i\n",i, j - desconto);
         i++;
     }
 
     fclose(input);
     fclose(output);
     return 0;
 }

