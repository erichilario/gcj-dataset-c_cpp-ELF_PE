#include<stdio.h>
 
 int main(){
     int T,n,a,i,j,k,temp,count;
     
     scanf("%d",&T);
     for(i=0;i<T;i++){
                      count=0;
                      scanf("%d",&n);
                      for(j=1;j<=n;j++){
                                        scanf("%d",&a);
                                        if(a!=j)count++;
                      }
            
            
                      printf("Case #%d: %d.000000\n",i+1,count);
     }
 }

