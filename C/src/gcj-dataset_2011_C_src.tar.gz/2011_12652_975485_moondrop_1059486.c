#include <stdlib.h>
 #include <stdio.h>
 
 int main() {
 	int T, t, N, C[15], i, j;
 	int a, b, c, value;
 	
 	scanf("%d", &T);	
 	for (t = 1; t <= T; t++) {
 		scanf("%d", &N);
 		for (i = 0; i < N; i++) {
 			scanf("%d", C+i);
 		}
 		for (i = (1 << N) - 2, value = 0; i > 0; i--) {
 			for (a = b = c = j = 0; j < N; j++) {
 				if (i & (1 << j)) {
 					a ^= C[j];
 					c += C[j];
 				} else {
 					b ^= C[j];
 				}
 			}
 			if (a == b) value = value > c ? value : c;
 		}
 		printf("Case #%d: ", t);
 		if (value) {
 			printf("%d\n", value);
 		} else {
 			puts("NO");
 		}
 	}
 	return 0;
 }
