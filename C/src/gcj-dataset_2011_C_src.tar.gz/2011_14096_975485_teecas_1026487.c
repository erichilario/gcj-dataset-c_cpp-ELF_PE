/*
  *  magicka.c
  *  GoogleCodeJam2011
  *
  *  Created by Vinicius Tosta Ribeiro on 07/05/11.
  *  Copyright 2011 __MyCompanyName__. All rights reserved.
  *
  */
 
 #include "magicka.h"
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 FILE* read_input_m(char name[]) {
 	FILE* arq;
 	char path[100];
 	
 	strcat(path, "/Users/vribeiro/Documents/GoogleCodeJam2011/");
 	strcat(path, name);
 	
 	arq = fopen(path, "r");
 	
 	return arq;
 }
 
 void solve_m(FILE *input) {
 	FILE *out;
 	
 	char element_list[100];
 	char invoke[100];
 	char combinations[3][36];
 	char opposed[2][28];
 	int T, C, D, N;
 	int i, j, k, l, z, w, y;
 	char cmb[3], opp[2];
 	
 	out = fopen("/Users/vribeiro/Desktop/B-large.out.txt", "w");
 	
 	fscanf(input, "%d", &T);
 	
 	for (i = 0; i < T; i++) {
 		fscanf(input, "%d", &C);
 		
 		for (k = 0; k < C; k++) {
 			fscanf(input, "%s", cmb);
 			combinations[0][k] = cmb[0];
 			combinations[1][k] = cmb[1];
 			combinations[2][k] = cmb[2];
 		}
 		fscanf(input, "%d", &D);
 		for (k = 0; k < D; k++) {
 			fscanf(input, "%s", opp);
 			opposed[0][k] = opp[0];
 			opposed[1][k] = opp[1];
 		}
 		
 		fscanf(input, "%d", &N);
 		
 		fscanf(input, "%s", invoke);
 		
 		for (j = 0; j < 100; j++) {
 			element_list[j] = '\0';
 		}
 		j = 0;
 		for (k = 0; k < N; k++) {
 			element_list[j] = invoke[k];
 			j++;
 			
 			if (j > 1) {
 				// check if a combination can be made
 				for (l = 0; l < C; l++) {
 					if ((combinations[0][l] == element_list[j-1] && combinations[1][l] == element_list[j-2]) ||
 						(combinations[1][l] == element_list[j-1] && combinations[0][l] == element_list[j-2])) {
 						element_list[j-2] = combinations[2][l];
 						element_list[j-1] = '\0';
 						j = j - 1;
 						break;
 					}
 				}
 				
 				// check if there are opposing elements
 				for (z = 0; z < j; z++) {
 					for (w = z+1; w < j; w++) {
 						for (l = 0; l < D; l++) {
 							if ((opposed[0][l] == element_list[z] && opposed[1][l] == element_list[w]) ||
 								(opposed[1][l] == element_list[z] && opposed[0][l] == element_list[w])) {
 								// clear the elements list
 								for (y = j-1; y >= 0; y--) {
 									element_list[y] = '\0';
 								}
 								j = 0;
 								break;
 							}
 						}
 					}
 				}
 			}
 		}
 		
 		fprintf(out, "Case #%d: [", i+1);
 		if (j >= 1) {
 			for (k = 0; k < j-1; k++) {
 				fprintf(out, "%c, ", element_list[k]);
 			}
 			fprintf(out, "%c]\n", element_list[k]);
 		}
 		else {
 			fprintf(out, "]\n");
 		}
 
 	}
 	
 }
 
 void solve_magicka() {
 	FILE *input;
 	input = read_input_m("B-large.in");
 	if (input != NULL) {
 		solve_m(input);
 		fclose(input);
 	}
 }

