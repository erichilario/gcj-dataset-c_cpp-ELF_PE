#include<stdio.h>
 
 int main()
 {
 	register int i, j, k, m;
 	int t, c, d, n;
 	char combine[36][2],nbase[36], opposed[28][2], aux[100];
 	
 	scanf ( "%d" , &t );
 	
 	for ( i = 1; i <= t; i++ )
 	{
 		scanf ( "%d" , &c );
 		for ( j = 0; j < c; j++ )
 		{
 			scanf ( "%s" , aux );
 			
 			combine[j][0] = aux[0];
 			combine[j][1] = aux[1];
 			nbase[j] = aux[2];
 		}
 		
 		scanf ( "%d" , &d );
 		for ( j = 0; j < d; j++ )
 		{
 			scanf ( "%s" , aux );
 			
 			opposed[j][0] = aux[0];
 			opposed[j][1] = aux[1];
 		}
 		
 		scanf ( "%d" , &n );
 		scanf ( " %c" , &aux[0]);
 		
 		j = 1;
 		while ( --n )
 		{
 			scanf ( " %c" , &aux[j] );
 			
 			if ( j > 0 )
 			{
 				for ( k = 0; k < c; k++ )
 					if ( aux[j-1] == combine[k][0] && aux[j] == combine[k][1] || aux[j-1] == combine[k][1] && aux[j] == combine[k][0] )
 					{
 						aux[j-1] = nbase[k];
 						break;
 					}
 			
 				if ( k == c )
 				{
 					for ( m = 1; m <= j; m++ )
 					{
 						for ( k = 0; k < d; k++ )
 							if ( aux[j-m] == opposed[k][0] && aux[j] == opposed[k][1] || aux[j-m] == opposed[k][1] && aux[j] == opposed[k][0] )
 							{
 								m = j;
 								j = 0;
 								break;
 							}
 					}
 					if ( k < d ) continue;
 				}
 				else
 					continue;
 			}
 			j++;
 		}
 		
 		printf ( "Case #%d: [" , i );
 		for ( k = 0; k < j; k++ )
 			if ( k ) printf ( ", %c" , aux[k] );	
 			else printf ( "%c" , aux[k] );
 		printf ( "]\n" );
 	}
 	
 	return 0;
 }

