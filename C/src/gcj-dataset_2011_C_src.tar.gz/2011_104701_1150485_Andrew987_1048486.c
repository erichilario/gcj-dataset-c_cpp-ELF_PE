#include <stdio.h>
 #include <stdlib.h>
 
 int main(){
 	int T =0;
 	int N =0;
 	int sum[100];
 	
 
 	 double rpi [100];
 	double wp [100];
 	double owp [100];
 	double oowp [100];
 	char wins;
 	long int intWins [100][100];
 	char* pEnd= NULL;
  	FILE* file = fopen("C:\\Users\\Barbie\\Codejam\\A-small-attempt0.in", "r");
 	FILE* file2 = fopen("C:\\Users\\Barbie\\Codejam\\output.txt", "w");
 	fscanf(file, "%d", &T);
 	
 	for(int i=1; i<=T; i++){
 		fscanf(file, "%d", &N);
 		
 		for(int j=0; j<(N); j++){
 			for(int k=0; k<(N); k++){
 				wins = getc(file);
 				if ((wins != '0') && (wins != '1') && (wins != '.')) wins = getc(file);
 				if (wins == '.') wins='2';
 				intWins[j][k] = strtoul(&wins, &pEnd,10);
 				
 			}
 			
 		}
 		for(int j=0; j<(N); j++){
 			rpi[j] = 0;	
 			wp[j] = 0;
 			owp[j] = 0;
 			oowp[j] = 0;
 			sum[j] = 0;
 			
 		}
 		for(int j=0; j<(N); j++){
 			for(int k=0; k<(N); k++){
 				if(intWins[j][k] != 2){
 					wp[j] += intWins[j][k];
 					sum[j] += 1;
 				}
 			}
 			
 		}
 		
 		for(int j=0; j<(N); j++){
 			for(int k=0; k<(N); k++){
 				if((j != k)){
 					if(intWins[k][j] != 2){	
 						owp[j] += ((wp[k] - intWins[k][j])/(sum[k]-1));
 						
 					}
 				}
 				
 			}
 		}
 		
 		for(int j=0; j<(N); j++){
 			for(int k=0; k<(N); k++){
 				if((j != k)){
 					if(intWins[k][j] != 2){	
 						oowp[j] += (owp[k])/sum[k];
 					}
 				}
 				
 			}
 		}
 		
 		
 		for(int j=0; j<(N); j++){
 			rpi[j]=(0.25*wp[j] + 0.5*owp[j] + 0.25*oowp[j])/sum[j];
 			
 		}
 		fprintf(file2,"Case #%d:\n",i);
 		for(int j=0; j<(N); j++){
 			fprintf(file2,"%.12f\n",rpi[j]);
 			
 		}
 		
 		
 	}
 	fclose(file);
 	fclose(file2);
 	return 0;
 }
