#include <stdio.h>
 #include <stdlib.h>
 
 #define BUFLEN 100
 
 #define SMALL
 
 #ifdef SMALL
  #define MAXDS 10
 #endif
 #ifdef LARGE
  #define MAXDS 100
 #endif
 
 int main ( void ) {
    int  i, j, k, h, C, D, T, N;
    char buffer[BUFLEN];
    char dataset[MAXDS][MAXDS];
    double WP[MAXDS];
    double OWP[MAXDS];
    double OOWP[MAXDS];
    double RPI[MAXDS];
    double tmp;
 
    fgets(buffer,BUFLEN,stdin);
    sscanf(buffer," %i ",&T);
 
    for ( i=0; i<T; i++ ) {
       fgets(buffer,BUFLEN,stdin);
       sscanf(buffer," %i ",&N);
       for ( j=0; j<N; j++ ) {
          fgets(buffer,BUFLEN,stdin);
          for ( k=0; k<N; k++ ) {
             dataset[j][k] = buffer[k];
          }
       }
 
       /* WP */
       for ( j=0; j<N; j++ ) WP[j] = 0.0;
       for ( j=0; j<N; j++ ) {
          C = 0;
          for ( k=0; k<N; k++ ) {
             if ( dataset[j][k] == '1' ) {
                WP[j] += 1.0;
                C ++;
             }
             else if ( dataset[j][k] == '0' ) C ++;
          }
          WP[j] /= C;
       }
 
       /* OWP */
       for ( j=0; j<N; j++ ) OWP[j] = 0.0;
       for ( j=0; j<N; j++ ) {
          D = 0;
          for ( k=0; k<N; k ++ ) {
             if ( dataset[j][k] == '.' ) continue;
             C = 0;
             tmp = 0.0;
             for ( h=0; h<N; h++ ) {
                if ( h == j ) continue;
                if ( dataset[k][h] == '1' ) {
                   tmp += 1.0;
                   C ++;
                }
                else if ( dataset[k][h] == '0' ) C ++;
             }
             tmp /= C;
             OWP[j] += tmp;
             D ++;
          }
          OWP[j] /= D;
       }
 
       /* OOWP */
       for ( j=0; j<N; j++ ) OOWP[j] = 0.0;
       for ( j=0; j<N; j++ ) {
          C = 0;
          for ( k=0; k<N; k++ ) {
             if ( dataset[j][k] == '.' ) continue;
             OOWP[j] += OWP[k];
             C ++;
          }
          OOWP[j] /= C;
       }
 
       /* RPI */
       for ( j=0; j<N; j++ ) {
          RPI[j] = 0.25*WP[j] + 0.50*OWP[j] + 0.25*OOWP[j];
       }
 
       /* Print */
       printf("Case #%i:\n",i+1);
       for ( j=0; j<N; j++ ) {
          printf("%.12g\n",RPI[j]);
       }
    }
    return 0;
 }

