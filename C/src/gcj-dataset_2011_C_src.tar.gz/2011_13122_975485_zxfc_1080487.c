#include<stdio.h>
 #include<math.h>
 #include<string.h>
 #define max(a,b) ((a>b)?a:b)
 #define lim 112
 
 int pr[lim],input[lim][lim],n,current,sO,sB;
 
 void solve(int p, int xi, int xin, int yi, int yin){
 	int dx,dy;
 	if(p>=n)return;
 	if(xin>=sB)
 		dx=0;
 	else
 	   dx=abs(input[0][xin]-xi)+1;
 	if(yin>=sO)
 		dy=0;
 	else
 	   dy=abs(input[1][yin]-yi)+1;
 
 	if(!pr[p]){//priority of x
 		if(dx>=dy){
 			current+=dx;
 			solve(p+1,input[0][xin],xin+1,input[1][yin],yin);
 		}
 		else{
 			current+=dx;
 			if(input[1][yin]<yi)dx=(dx)*(-1);
 			solve(p+1,input[0][xin],xin+1,yi+dx,yin);
 		}
 	}
 	else{
 		if(dy>=dx){
 			current+=dy;
 			solve(p+1,input[0][xin],xin,input[1][yin],yin+1);
 		}
 		else{
 			current+=dy;
 			if(input[0][xin]<xi)dy=(dy)*(-1);
 			solve(p+1,xi+dy,xin,input[1][yin],yin+1);
 		}
 
 	}
 
 }
 
 int main(){
 	int t,i,j,v;
 	char c;
 	scanf("%d",&t);
 
 	for(i=1;i<=t;i++){
 		current=0;
 		memset(pr,0,sizeof(pr));
 		memset(input,0,sizeof(input));
 
 		scanf(" %d",&n);
 		sB=sO=0;
 		
 
 		for(j=0;j<n;j++){
 			scanf(" %c %d",&c,&v);
 			if(c=='B'){
 				input[0][sB++]=v;
 				pr[j]=0;
 			}
 			if(c=='O'){
 				input[1][sO++]=v;
 				pr[j]=1;
 			}
 		}
 
 		solve(0,1,0,1,0);
 		
 
 		printf("Case #%d: %d\n",i,current);
 	}
 	
 	return 0;
 }
 			

