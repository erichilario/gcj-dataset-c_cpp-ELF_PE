#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 void main(){
 
 
 FILE *fp,*fpo;
 int c,i,j,k,linecase,switch_no,switch_pos_o=1,switch_pos_b=1;
 int omat[101][2],bmat[101][2],total_task,task_done=0;
 int ocount=1,bcount=1,task[101],task_count=1;
 int madsearch,oloc=1,bloc=1,found;
 long unsigned int time_count=0;
 char t,o_or_b,dummy,king;
 char head[] = "Case #";
 clrscr();
 fp = fopen("d:/c_pro/Input.in","r");
 fpo = fopen("d:/c_pro/Output.out","w");
 fscanf(fp,"%d\n",&c);
 printf("%d\n",c);
 for (k=1;k<=c;k++){
     fscanf(fp,"%d",&linecase);
     for(j=1;j<=linecase;j++){
 	fscanf(fp,"%c%c",&dummy,&o_or_b);
 	fscanf(fp,"%c%d",&dummy,&switch_no);
 	if(o_or_b=='O'){
 	    omat[ocount][1]=j;
 	    omat[ocount++][2]=switch_no;
 	}
 	if(o_or_b=='B'){
 	    bmat[bcount][1]=j;
 	    bmat[bcount++][2]=switch_no;
 	}
     }
     ocount--;bcount--;//tasks assigned to orage and blue robot
     total_task=j-1;
     //search for minimum task remaining in bot arrays
     printf("total task: %d\t ocount %d bcount %d\n",total_task,ocount,bcount);
     while(total_task!=task_done){
 	for(i=1;i<=ocount;i++){
 	    madsearch=1;found=0;
 	    if(omat[i][1]==task_count){
 //		king='O';
 		switch_pos_o=omat[i][2];
 		    while(((omat[i][1]+madsearch)<=total_task)&&found==0){
 			for(j=1;j<=bcount;j++){
 			    if(bmat[j][1]==omat[i][1]+madsearch){
 				switch_pos_b=bmat[j][2];
 				madsearch=1;
 				found=1;
 				break;
 			    }
 			}
 			madsearch++;
 		    }
 		if(switch_pos_o==oloc){
 		    time_count++;
 		    if(switch_pos_b>bloc){
 			bloc++;
 		    }
 		    if(switch_pos_b<bloc){
 			bloc--;
 		    }
 		}
 		while(switch_pos_o<oloc){
 		    oloc--;
 		    time_count++;
 		    if(switch_pos_b>bloc){
 			bloc++;
 		    }
 		    if(switch_pos_b<bloc){
 			bloc--;
 		    }
 		    if(oloc==switch_pos_o){
 			time_count++;
 			if(switch_pos_b>bloc){
 			    bloc++;
 			}
 			if(switch_pos_b<bloc){
 			    bloc--;
 			}
 		    }
 		}
 		while(switch_pos_o>oloc){
 		    oloc++;
 		    time_count++;
 		    if(switch_pos_b>bloc){
 			bloc++;
 		    }
 		    if(switch_pos_b<bloc){
 			bloc--;
 		    }
 		    if(oloc==switch_pos_o){
 			time_count++;
 			if(switch_pos_b>bloc){
 			    bloc++;
 			}
 			if(switch_pos_b<bloc){
 			    bloc--;
 			}
 		    }
 		}
 		//printf("%d %d %c",switch_pos_o,switch_pos_b,king);
 	    task_count++;
 	    task_done=task_count-1;
 	    }
 	    printf("task done: %d\ttime so far %d\n",task_done,time_count);
 	    printf("o_location %d b_location %d\n",oloc,bloc);
 	}
 
 	for(i=1;i<=bcount;i++){
 	    madsearch=1;found=0;
 	    if(bmat[i][1]==task_count){
 //		king='B';
 		switch_pos_b=bmat[i][2];
 		while(((bmat[i][1]+madsearch)<=total_task)&&found==0){
 			for(j=1;j<=ocount;j++){
 			    if(omat[j][1]==bmat[i][1]+madsearch){
 				switch_pos_o=omat[j][2];
 				madsearch=1;
 				found=1;
 				break;
 			    }
 			}
 			madsearch++;
 		    }
 		if(switch_pos_b==bloc){
 		    time_count++;
 		    if(switch_pos_o>oloc){
 			oloc++;
 		    }
 		    if(switch_pos_o<oloc){
 			oloc--;
 		    }
 		}
 		while(switch_pos_b<bloc){
 		    bloc--;
 		    time_count++;
 		    if(switch_pos_o>oloc){
 			oloc++;
 		    }
 		    if(switch_pos_o<oloc){
 			oloc--;
 		    }
 		    if(bloc==switch_pos_b){
 			time_count++;
 			if(switch_pos_o>oloc){
 			oloc++;
 		    }
 		    if(switch_pos_o<oloc){
 			oloc--;
 		    }
 		    }
 		}
 		while(switch_pos_b>bloc){
 		    bloc++;
 		    time_count++;
 		    if(switch_pos_o>oloc){
 			oloc++;
 		    }
 		    if(switch_pos_o<oloc){
 			oloc--;
 		    }
 		    if(bloc==switch_pos_b){
 			time_count++;
 			if(switch_pos_o>oloc){
 			oloc++;
 		    }
 		    if(switch_pos_o<oloc){
 			oloc--;
 		    }
 		    }
 		}
 		//printf("%d %d %c",switch_pos_o,switch_pos_b,king);
 	    task_count++;
 	    task_done=task_count-1;
 	    }
 	    printf("task done: %d\ttime so far %d\n",task_done,time_count);
 	    printf("o_location %d b_location %d\n",oloc,bloc);
 	}
     }
     printf("%d\n",time_count);
     fprintf(fpo,"%s%d%c%c%lu%c",head,k,':',' ',time_count,'\n');
     time_count=0;
     switch_pos_o=1;
     switch_pos_b=1;
     oloc=1;
     bloc=1;
     task_count=1;
     ocount=1;
     bcount=1;
     task_done=0;
     }
    // printf("%c %d",omat[1][1],omat[1][2]);
 //printf("\n%d\n%d %c",c,i,t);
 
 getch();
 }
