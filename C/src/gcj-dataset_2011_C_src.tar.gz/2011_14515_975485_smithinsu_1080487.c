#include<stdio.h>
 int main()
 {
 	int t,n,i,a[1000],b[1000],c[1000],f;
 	char c1;
 	scanf("%d",&t);
 	for(f=1;f<=t;f++)
 	{
 		scanf("%d",&n);
 		getchar();
 		for(i=0;i<n;)
 		{
 			c1=getchar();
 			if(c1=='O')
 			{
 				a[i]=0;
 				scanf("%d",&b[i]);
 				i++;
 			}
 			else if(c1=='B')
 			{
 				a[i]=1;
 				scanf("%d",&c[i]);
 				i++;
 			}
 		}
 		int curo=1,curb=1,ans=0,preb=0,preo=0,temp;
 		for(i=0;i<n;i++)
 		{
 			if(a[i]==0)
 			{
 				temp=abs(b[i]-curo)+1-preo;
 				if(temp<1)
 					temp=1;
 				preb+=temp;
 				ans+=temp;
 				preo=0;
 				curo=b[i];
 			}
 			else
 			{
 				temp=abs(c[i]-curb)+1-preb;
 				if(temp<1)
 					temp=1;
 				preo+=temp;
 				ans+=temp;
 				preb=0;
 				curb=c[i];
 			}
 //			printf("%d %d\n",i,ans);
 		}
 		printf("Case #%d: %d\n",f,ans);
 	}
 	return 0;
 }

