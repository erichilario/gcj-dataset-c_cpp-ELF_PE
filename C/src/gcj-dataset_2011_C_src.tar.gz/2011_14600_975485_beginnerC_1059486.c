#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int get_fp_num(FILE *);
 void set_bit(int);
 
 int info_bit[20];
 
 int main(void){
 	FILE *fp,*fw;
 	int T,N,C;
 	int i,j;
 	__int64 total;
 	int min,result;
 
 	fp = fopen("C-small-attempt1.in","r");
 	fw = fopen("C-small-attempt1.out","w");
 	
 	T = get_fp_num(fp);
 	
 	for(i=1;i<=T;i++){
 		N=get_fp_num(fp);
 		total=result=0;
 		min = 1000001;
 		memset(info_bit,0,sizeof(info_bit));
 		for(j=0;j<N;j++){
 			C=get_fp_num(fp);
 			set_bit(C);
 			total+=C;
 			if(min > C)	min=C;
 		}
 
 		for(j=0;j<20;j++){
 			if(info_bit[j]%2 !=0){
 				result=1;
 				break;
 			}
 		}
 		if(result==1)  fprintf(fw,"Case #%d: NO\n",i);
 		else  fprintf(fw,"Case #%d: %I64d\n",i,(__int64)(total-min));
 	}
 	fclose(fp);
 	fclose(fw);
 	
 	return 0;
 }
 
 int get_fp_num(FILE *a)
 {
   int k=0,j=0;
   char temp[10];
   while(1){
     temp[k] = fgetc(a);	
     if(temp[k] == 10)	{
       temp[k+1]=0;
 	  return atoi(temp);
 	}	
     if(temp[k] == 32){
       temp[k+1]=0;
 	  return atoi(temp);
 	}
     k++;
   }
 }
 
 void set_bit(int a){
 	int i=0;
 	
 	while(a>0){
 		info_bit[i] += a%2;
 		a/=2;
 		i++;
 	}
 
 }
