#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int
 main(void)
 {
 	int test;
 	int n;
 	int i;
 	int ans;
 	int cnt;
 	int time, timeb, timeo;
 	int cur, curb, curo;
 	char who[2];
 
 	scanf("%d", &test);
 	cnt = 0;
 	while (test--) {
 		scanf("%d", &n);
 
 		curb = 1;
 		curo = 1;
 		timeb = 0;
 		timeo = 0;
 		ans = 0;
 
 		for (i = 0; i < n; ++i) {
 			scanf("%s%d", who, &cur);
 			if (who[0] == 'B') {
 				time = abs(cur - curb) - timeb + 1;
 				if (time <= 0)
 					time = 1;
 				ans += time;
 				timeo += time;
 				timeb = 0;
 				curb = cur;
 			} else {
 				time = abs(cur - curo) - timeo + 1;
 				if (time <= 0)
 					time = 1;
 				ans += time;
 				timeb += time;
 				timeo = 0;
 				curo = cur;
 			}
 		}
 
 		printf("Case #%d: %d\n", ++cnt, ans);
 	}
 
 	return 0;
 }
 
 
 
 
 #if 0
 			count(w[O], w[O][co-1], co), 
 					count(w[B], w[B][cb-1], cb), count(w[O], 2, co);
 			ans = max(count(w[O], w[O][co-1], co), 
 					count(w[B], w[B][cb-1], cb) 
 					+ count(w[O], 2, co));
 			
 			/* 简单抽象出一个容易实现的方法，让上层的设计更加容易进行，这一点是一个真理，这就是合理抽象的强大之处 */
 #endif
 

