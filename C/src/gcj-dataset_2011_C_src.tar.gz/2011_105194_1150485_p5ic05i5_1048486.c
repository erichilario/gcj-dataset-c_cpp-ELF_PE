#include <stdio.h>
 #include <string.h>
 
 char games[100][100];
 char op[100][100];
 
 int pg[100];
 int wg[100];
 
 double wp[100];
 double owp[100];
 double oowp[100];
 
 int main() {
 	char c;
 	int i, j, k, l, n, t, ops, x = 1;
 	scanf("%d\n", &t);
 	while ( t-- ) {
 		scanf("%d\n", &n);
 		for ( i = 0 ; i < n ; ++i ) {
 			for ( j = 0 ; j < n ; ++j ) 
 				scanf("%c", &games[i][j]);
 			scanf("\n");
 		}
 		
 		memset(pg, 0, n * sizeof(int));
 		memset(wg, 0, n * sizeof(int));
 		
 		for ( i = 0 ; i < n ; ++i ) {
 			for ( j = 0 ; j < n ; ++j ) {
 				switch (games[i][j]) {
 				case '0':
 					op[i][j] = 1;
 					pg[i]++;
 					break;
 				case '1':
 					op[i][j] = 1;
 					pg[i]++;
 					wg[i]++;
 					break;
 				case '.':
 					op[i][j] = 0;
 					break;
 				}
 			}
 			wp[i] = (double) wg[i] / (double) pg[i];
 		}
 		
 		for ( i = 0 ; i < n ; ++i ) {
 			ops = 0;
 			owp[i] = 0.0;
 			for ( j = 0 ; j < n ; ++j ) {
 				if ( op[i][j] ) {
 					ops++;
 					wg[0] = pg[0] = 0;
 					for ( k = 0 ; k < n ; ++k ) {
 						if ( k != i ) {
 							switch (games[j][k]) {
 							case '0':
 								pg[0]++;
 								break;
 							case '1':
 								pg[0]++;
 								wg[0]++;
 								break;
 							case '.':
 								break;
 							}
 						}
 					}
 					owp[i] += (double) wg[0] / (double) pg[0];
 				}
 			}
 			owp[i] /= (double) (ops);
 		}
 
 		for ( i = 0 ; i < n ; ++i ) {
 			ops = oowp[i] = 0;
 			for ( j = 0 ; j < n ; ++j )
 				if ( op[i][j] )
 					oowp[i] += owp[j], ops++;
 			oowp[i] /= (double) (ops);
 		}
 		
 		printf("Case #%d:\n", x++);
 		for ( i = 0 ; i < n ; ++i )
 			printf("%lf\n", wp[i] * 0.25 + owp[i] * 0.5 + oowp[i] * 0.25);
 	
 	}
 	return 0;
 	
 }
