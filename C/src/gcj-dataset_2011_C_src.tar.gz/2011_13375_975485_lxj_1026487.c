#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<ctype.h>
 
 int main(){
 
   int num;int i=0;int j=0;int k=0;
   scanf("%d",&num);
   
   
   for(i=0;i<num;i++){
     int c;
     int n,d;
     scanf("%d",&c);
     char clist[c][4];
     for(j=0;j<c;j++){scanf("%s",clist[j]);}
   
     scanf("%d",&d);
     char dlist[d][3];
     for(j=0;j<d;j++){scanf("%s",dlist[j]);}
 
     scanf("%d",&n);
     char nlist[n];
     scanf("%s",nlist);
     
     char result[n];
     int t;
     for(t=0;t<n;t++){result[t]='\0';}
     int npt=0;int rpt=0;int cpt=0;int dpt=0;
     result[0]=nlist[0];
     
     for(npt=1;npt<n;npt++){
       if(rpt==-1){result[rpt+1]=nlist[npt];rpt++;goto label1;}
       for(cpt=0;cpt<c;cpt++){
 	//	printf("cpt 0 is %c, cpt 1 is %c, result %d is %c nlist %d is %c\n",clist[cpt][0],clist[cpt][1],rpt,result[rpt],npt,nlist[npt]);
 	//if((clist[cpt][0]==result[rpt])&&(clist[cpt][1]==nlist[npt]))printf("yes");else printf("no");
 	if(((clist[cpt][0]==result[rpt])&&(clist[cpt][1]==nlist[npt]))||((clist[cpt][1]==result[rpt])&&(clist[cpt][0]==nlist[npt]))){
 	  result[rpt]=clist[cpt][2];goto label1;
 	} 
 	
       }
       
       for(dpt=0;dpt<d;dpt++){
 	  if(dlist[dpt][0]==nlist[npt]){
 	    for(k=0;k<=rpt;k++){if(dlist[dpt][1]==result[k]){
 		for(t=0;t<n;t++){result[t]='\0';}rpt=-1;goto label1;}
 	}
 	  }
 	     if(dlist[dpt][1]==nlist[npt]){
 	    for(k=0;k<=rpt;k++){if(dlist[dpt][0]==result[k]){
 		for(t=0;t<n;t++){result[t]='\0';}rpt=-1;goto label1;}
 	    }
 	     }
 	
 	}
 	result[rpt+1]=nlist[npt];rpt++;
    
 
       label1:;
     }
     
     printf("Case #%d: [",i+1);
     rpt=0;
 
     while(result[rpt]!='\0'){printf("%c",result[rpt]);rpt++;if(result[rpt]=='\0')break;else printf(", ");}
     printf("]\n");
 
   }
 
 
   //  for(i=0;i<num;i++){printf("Case #%d= %d"i+1,result[i]);}
 
   return 0;
 }
 

