#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 FILE *fin,*fout;
 int T,N;
 int numTaskO,numTaskB;
 int taskO[100],taskB[100];
 int nowTaskO,nowTaskB;
 int active[100];
 int curTime;
 int whereO,whereB;
 
 int OFinish(){
 	return nowTaskO == numTaskO;
 }
 
 int BFinish(){
 	return nowTaskB == numTaskB;
 }
 
 void initial(){
 	int i,target;
 	char temp[10];
 	fscanf(fin,"%d",&N);
 	numTaskO = 0;
 	numTaskB = 0;
 	nowTaskO = 0;
 	nowTaskB = 0;
 	for(i = 0 ; i < N ; ++i){
 		fscanf(fin,"%s %d",temp,&target);
   		if(temp[0] == 'O'){
     		taskO[numTaskO++] = target;
     		active[i] = 0;
   		}
   		else{
     		taskB[numTaskB++] = target;
     		active[i] = 1;
   		}
  	}
  	curTime = 0;
  	whereO = 1;
  	whereB = 1;
 }
 
 void work(int num){
 	initial();
 	int i,addition;
 	for(i = 0 ; i < N ; ++i){
 		if(active[i] == 0){
 			addition = abs(taskO[nowTaskO] - whereO) + 1;
 			whereO = taskO[nowTaskO++];
 			curTime += addition;
 			if(!BFinish()){
 				if(abs(taskB[nowTaskB]-whereB) <= addition) whereB = taskB[nowTaskB];
 				else{
     				if(taskB[nowTaskB] >= whereB)whereB += addition;
     				else whereB -= addition;
 				}
    			}
   		}
   		else{
 			addition = abs(taskB[nowTaskB] - whereB) + 1;
 			whereB = taskB[nowTaskB++];
 			curTime += addition;
 			if(!OFinish()){
 				if(abs(taskO[nowTaskO]-whereO) <= addition) whereO = taskO[nowTaskO];
 				else{
     				if(taskO[nowTaskO] >= whereO)whereO += addition;
     				else whereO -= addition;
 				}
    			}		
   		}
  	}
  	fprintf(fout,"Case #%d: %d\n",num,curTime);
 }
 
 int main(){
 	fin = fopen("Rot.in","r");
 	fout = fopen("Rot.out","w");
 	fscanf(fin,"%d",&T);
 	int i;
 	for(i = 0 ; i < T ; ++i) work(i+1);
 	close(fin);
 	close(fout);
 	return 0;
 }

