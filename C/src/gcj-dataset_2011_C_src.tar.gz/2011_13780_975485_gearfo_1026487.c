#include <assert.h>	
 #include <ctype.h>	
 #include <math.h>	
 #include <stdarg.h> 
 #include <stdio.h>	
 #include <stdlib.h>	
 #include <string.h>	
 #include <time.h>	
 
 #define LOOP(i,N) for((i)=0;(i)<(int)(N);i++)
 #define GETMEM(type,n) (type*)malloc((n)*sizeof(type))
 #define OUT(...) printf(__VA_ARGS__)
 #define FOUT(...) fprintf(out_fp, __VA_ARGS__)
 #define FIN(...) fscanf(in_fp, __VA_ARGS__)
 #define ERR(...) fprintf(stderr, __VA_ARGS__)
 #define ERRCHK(x) if(x==NULL){perror("Error");exit(1);}
 
 #define TRUE 1
 #define FALSE 0
 
 
 
 int main(int argc, char* argv[])
 {
 	/* DECLARE VARIABLES */
 	FILE* in_fp=NULL;
 	FILE* out_fp=NULL;
 	
 	int i,j,k;
 	int numCases;
 	
 	signed char tablec[26][26];
 	int tableo[26][26];
 	int numCombine;
 	int numOpposed;
 	char combining[3];
 	char opposed[2];
 	int numElements;
 	char* elements;
 	char* final_elements;
 	int len;
 	
 	/* CHECK COMMAND LINE ARGUMENTS*/
 	if (argc!=2)
 	{
 		ERR("Incorrect number of command line arguments, exiting...\n");
 		return 1;
 	}
 	
 	/* OPEN FILES */
 	in_fp = fopen(argv[1],"r");
 	ERRCHK(in_fp);
 	
 	out_fp = fopen("output.txt","w");
 	ERRCHK(out_fp);
 	
 	/* READ NUMBER OF CASES */
 	fscanf(in_fp,"%d",&numCases);
 
 	/* MAIN LOOP */
 	LOOP(k,numCases)
 	{
 		LOOP(i,26)
 		{
 			LOOP(j,26)
 			{
 				tablec[i][j]=0;
 				tableo[i][j]=0;
 			}
 		}
 		
 		FIN("%d",&numCombine);
 		
 		LOOP(i,numCombine)
 		{
 			FIN("%*c%c%c%c",&combining[0],&combining[1],&combining[2]);
 			combining[0]-=65;
 			combining[1]-=65;
 			assert(combining[0]<26&&combining[0]>=0);
 			assert(combining[1]<26&&combining[1]>=0);
 			tablec[(int)combining[0]][(int)combining[1]] = combining[2];
 			tablec[(int)combining[1]][(int)combining[0]] = combining[2];
 
 		}
 		
 		FIN("%d",&numOpposed);
 		
 		LOOP(i,numOpposed)
 		{
 			FIN("%*c%c%c",&opposed[0],&opposed[1]);
 			opposed[0]-=65;
 			opposed[1]-=65;
 			assert(opposed[0]<26&&opposed[0]>=0);
 			assert(opposed[1]<26&&opposed[1]>=0);
 			tableo[(int)opposed[0]][(int)opposed[1]] = -1;
 			tableo[(int)opposed[1]][(int)opposed[0]] = -1;
 
 		}
 		
 		FIN("%d",&numElements);
 		elements = GETMEM(char,numElements);
 		ERRCHK(elements);
 		final_elements = GETMEM(char,numElements);
 		ERRCHK(final_elements);
 		
 		FIN("%*c");
 		LOOP(i,numElements)
 		{
 			FIN("%c",&elements[i]);
 		}
 		
 		len=0;
 		LOOP(i,numElements)
 		{
 			if(len) //non zero elements 
 			{
 				//check for combination
 				if(tablec[(int)final_elements[len-1]-65][(int)elements[i]-65]) //they combine
 					final_elements[len-1]=tablec[(int)final_elements[len-1]-65][(int)elements[i]-65]; //combine them
 				else 
 				{
 					//check for opposition
 					LOOP(j,len)
 					{
 						if(tableo[(int)final_elements[j]-65][(int)elements[i]-65]==-1)
 						{
 							len=0;
 						}
 					}
 					if(len) //no opposition
 					{
 						final_elements[len]=elements[i];
 						len++;
 					}
 				}
 			}
 			else //get any element
 			{
 				final_elements[0]=elements[i];
 				len++;
 			}
 			
 		}
 		
 		
 		FOUT("Case #%d: [",k+1);
 		LOOP(i,len-1)
 			FOUT("%c, ",final_elements[i]);
 		if(len)
 			FOUT("%c",final_elements[i]);
 		FOUT("]\n");
 		
 		free(elements);
 		free(final_elements);
 	}
 	
 	/* CLOSE FILES */
 	fclose(out_fp);
 	fclose(in_fp);
 	
 	return 0;
 }

