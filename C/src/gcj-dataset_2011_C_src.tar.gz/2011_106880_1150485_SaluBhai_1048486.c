#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
 int xres=0;
 int N,i;
 int team[101][101]={99};
 float wc[101]={0.0},lc[101]={0.0};
 int T;
 char c[101];
 float wp[101],owp[101]={0.0},oowp[101]={0.0},rpi[101]={0.0};
 int all,arr[2000]={0},j=0;
 scanf("%d",&T);all=T;
 
 while (T!=0)
 {
 	for(i=0;i<101;i++)
 	{
 		for (j=0;j<101;j++)
 		{
 		team[i][j]=99;
 		}
 	}
 	scanf("%d",&N);
 	for (i=0;i<N;i++)
 	{
 		scanf("%s",c);
 		for (j=0;j<N;j++)
 		{
 		if(c[j]=='0')
 			team[i][j]=0;
 		if(c[j]=='1')
 			team[i][j]=1;
 		if(c[j]=='.');
 		}
 	}
 
 	for(i=0;i<N;i++)
 	{
 	wp[i]=0;
 	wc[i]=0;lc[i]=0;
 		for (j=0;j<N;j++)
 		{
 		if (team[i][j]==1) wc[i]++;
 		if (team[i][j]==0) lc[i]++;
 		}
 		wp[i]=(wc[i]/(wc[i]+lc[i]));
 	}
 	for (i=0;i<N;i++)
 	{
 	owp[i]=0;
 		for (j=0;j<N;j++)
 		{
 		if(team[i][j]==1)
 			owp[i]+=(wc[j]/(wc[j]+lc[j]-1));
 		if(team[i][j]==0)
 			owp[i]+=(wc[j]-1)/(wc[j]+lc[j]-1);
 		}
 		owp[i]=owp[i]/(wc[i]+lc[i]);
 	}
 	
 	for (i=0;i<N;i++)
 	{
 	oowp[i]=0;
 		for (j=0;j<N;j++)
 		{
 		if(team[i][j]!=99)
 			oowp[i]+=owp[j];
 		}
 		oowp[i]=oowp[i]/(wc[i]+lc[i]);
 	}
 	
 	for (i=0;i<N;i++)
 	{
 	rpi[i]=(0.25 *wp[i]) + (0.5*owp[i]) + (0.25*oowp[i]);	
 	}
 	T--;
 	printf ("Case #%d:\n",all-T);
 	for (i=0;i<N;i++)
 	{
 	printf("%f\n",rpi[i]);	
 	}
 }
 }

