#include<stdio.h>
 
 int main(){
     int T,N;
     int i,j,cant,count;
     long mul=1,max=0,min=9999999;
     long C[1000],sum;
     scanf("%d",&T);
     for(i=0;i<T;i++){
                      mul=1;
                      cant=0;
                      sum=0;
                      max=0;
                      min=9999999;
                      scanf("%d",&N);
                      for(j=0;j<N;j++){
                                       scanf("%ld",&C[j]);
                                       if(max<C[j])max=C[j];
                                       if(min>C[j])min=C[j];
                                       sum+=C[j];
                      }
                      while(mul<max){
                              count=0;
                              for(j=0;j<N;j++){
                                               count+=(C[j]/mul)%2;
                              }
                              if(count%2==1){  
                                             cant=1;
                                             break;
                              }
                              else{
                                   mul=mul*2;
                              }
                      }
                      if(cant==1){
                                  printf("Case #%d: NO\n",i+1);
                      }
                      else{
                            printf("Case #%d: %ld\n",i+1,sum-min);
                      }
     }
 }

