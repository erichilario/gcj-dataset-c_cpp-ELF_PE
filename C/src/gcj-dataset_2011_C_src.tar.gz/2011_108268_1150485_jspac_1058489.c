#include <stdio.h>
 
 int main(void)
 {
 	int t, T, c, C;
 	long long D, P[200], v, V[200], N;
 	double X0, X, mtime, max_mtime;
 	FILE *in, *out;
 	
 	in = fopen("input.txt", "rt");
 	out = fopen("output.txt", "wt");
 	
 	fscanf(in, "%d", &T);
 	for (t = 1; t <= T; t++)
 	{
 		fscanf(in, "%d %lld", &C, &D);
 		N = 0;
 		for (c = 0; c < C; c++)
 		{
 			fscanf(in, "%lld %lld", P + c, V + c);
 			N += V[c];
 		}
 		c = C - 1;
 		
 		if (P[0] == P[c] - (N - 1) * D)
 			X0 = (double)P[0];
 		else
 			X0 = (double)(P[0] * P[0] - (P[c] - (N - 1) * D) * (P[c] - (N - 1) * D)) / (P[0] - (P[c] - (N - 1) * D)) / 2;
 		
 		X = X0;
 		max_mtime = 0.0;
 		for (c = 0; c < C; c++)
 			for (v = 1; v <= V[c]; v++)
 			{
 				mtime = X - P[c];
 				if (mtime < 0)
 					mtime = -mtime;
 				if (mtime > max_mtime)
 					max_mtime = mtime;
 				X += D;
 			}
 		
 		fprintf(out, "Case #%d: %.12f\n", t, max_mtime);
 	}
 	
 	fclose(in);
 	fclose(out);
 	
 	return 0;
 }
