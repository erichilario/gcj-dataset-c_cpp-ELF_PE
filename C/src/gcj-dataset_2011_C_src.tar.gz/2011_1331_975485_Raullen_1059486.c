#include<stdio.h>
 
 
 int main(){
 	long T, N, tmp, tmp0, no_case=0;
 	int i, j, res, res2;
 	scanf("%ld",&T);
 	//printf("T = %ld\n",T);
 	for (i=0;i<T;i++){
 	
 		no_case++;
 		scanf("%ld",&N);
 		res = res2 = tmp0 = 0;
 		for (j=0;j<N;j++){
 			scanf("%ld",&tmp);
 			//printf("%ld\n",tmp);
 			if(j==0) tmp0 = tmp;
 			tmp0 = ((tmp<tmp0)?tmp:tmp0);
 			res ^= tmp;
 			res2 += tmp;
 		}
 		
 		if (res == 0){
 			printf("Case #%ld: %d\n",no_case, res2-tmp0);
 		}
 		else printf("Case #%ld: NO\n",no_case);
 
 	}
 }
 
 
 
 

