#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
 	FILE * fp = fopen("C:\\Users\\biswa\\Documents\\c_progs\\input\\inp111.txt","r");
 	FILE *fp_out = fopen("C:\\Users\\biswa\\Documents\\c_progs\\input\\out111.txt","w");
 	if(fp == NULL)
 	{
 		printf("\nError opening file\n");
 		return -1;
 	}
 	int T = -1;
 	fscanf(fp,"%d",&T);
 	int i=1;
 	for(i=1;i<=T;i++)
 	{
 		int N=-1;	
 		fscanf(fp,"%d",&N);
 		int j=1;
 		char robot[N];
 		int button[N];
 		int add=0;
 		int Tcr=0,To=0,Tb=0;
 		int No=1,Nb=1;
 		
 		for(j=1;j<=N;j++)
 		{
 			add=0;
 			fgetc(fp);
 			fscanf(fp,"%c",&robot[j]);	
 			fscanf(fp,"%d",&button[j]);
 			//printf("\n%c %d\n",robot[j],button[j]);
 			
 			if(robot[j] == 'O')
 			{
 				int difa=Tcr-To;
 				int difp=button[j]-No;
 				if(difp<0)
 					difp=difp*(-1);
 				//printf("\n1: difa=%d difp=%d\n",difa,difp);
 				if(difp > difa)	
 				{
 					add = difp-difa;
 				}
 				No=button[j];
 			}
 			else if(robot[j] == 'B')
 			{
 				int difa=Tcr-Tb;
 				int difp=button[j]-Nb;
 				if(difp<0)
 					difp=difp*(-1);
 				//printf("\n1: difa=%d difp=%d\n",difa,difp);
 				if(difp > difa)	
 				{
 					add = difp-difa;
 				}
 				Nb=button[j];
 			}
 			//printf("\nadd=%d\n",add);
 			Tcr = Tcr + add + 1;
 			//printf("\nTcr=%d\n",Tcr);
 			if(robot[j] == 'B')
 			{
 				Tb=Tcr;
 				//printf("\nTb=%d\n",Tb);
 			}
 			else
 			{
 				To=Tcr;
 				//printf("\nTo=%d\n",To);
 			}
 		}		
 		fprintf(fp_out,"Case #%d: %d\n",i,Tcr);
 		printf("Case #%d: %d\n",i,Tcr);
 	}
 	fclose(fp);
 	fclose(fp_out);
 	return 0;
 }
