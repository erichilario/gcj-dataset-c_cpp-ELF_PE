#include <stdio.h>
 #include <stdlib.h>
 #include "bot_trust.h"
 
 int main (int argc, const char * argv[]) {
 	solve_bot_trust();
     return 0;
 }

