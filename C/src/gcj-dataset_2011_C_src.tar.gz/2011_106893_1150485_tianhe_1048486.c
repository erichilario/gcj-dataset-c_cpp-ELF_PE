#include<stdio.h>
 
 void main()
 {
     int t,n,count,i,j,k,m;
     int s[100][100];
     double wp[100],haar,jeet,rpi;
     double owp[100],oowp[100],ab[100];
     char faltu,c;
 
     i=0;
     scanf("%d",&t);
     while((++i)<=t)
     {
 	scanf("%d",&n);
 	for(j=0;j<n;j++)
 	{
 	    scanf("%c",&faltu);
 	    for(k=0;k<n;k++)
 	    {
     		scanf("%c",&c);
     		if(c!='.')
 		    s[j][k]=c-'0';
 		else
 		    s[j][k]=-1;
 	    }
 	}
 	//calc WP
 	for(j=0;j<n;j++)
 	{
 	    wp[j]=0;
 	    haar=0;
 	    jeet=0;
 	    for(k=0;k<n;k++)
 	    {
 		if(s[j][k]==0)
 		    haar+=1;
 		else if(s[j][k]==1)
 		    jeet+=1;
 	    }
 	    wp[j]=jeet/(haar+jeet);
 //	    printf("wp[%d]=%f\n",j+1,wp[j]);
 	}
 	for(j=0;j<n;j++)
 	{
 	    for(m=0;m<n;m++)
     	    {
 		if(m==j) continue;
     		ab[m]=0;
     		haar=0;
     		jeet=0;
     		for(k=0;k<n;k++)
     		{
 		    if(k==j) continue;
     		    if(s[m][k]==0)
     			haar+=1;
     		    else if(s[m][k]==1)
     			jeet+=1;
     		}
     		ab[m]=jeet/(haar+jeet);
     	    }
 	    count = 0;
 	    owp[j]=0;
 	    for(k=0;k<n;k++)
 	    {
 				
 		if(s[j][k] == 0 || s[j][k] == 1)
 		{
 		    count+=1;
 		    owp[j]+=ab[k];
 		}
 	    }
 //	    printf("ha[%d]=%f, %d\n",j+1,owp[j],count);
 
 	    owp[j]/=count;
 //	    printf("owp[%d]=%f\n",j+1,owp[j]);
 	}
 	for(j=0;j<n;j++)
 	{
 	    count = 0;
 	    oowp[j]=0;
 	    for(k=0;k<n;k++)
 	    {
 		if(s[j][k] == 0 || s[j][k] == 1)
 		{
 		    count+=1;
 		    oowp[j]+=owp[k];
 		}
 	    }
 	    oowp[j]/=count;
 //	    printf("oowp[%d]=%f\n",j+1,oowp[j]);
 	}
 	printf("Case #%d:\n",i);
 	for(j=0;j<n;j++)
 	{
 	    rpi = 0.25 * wp[j] + 0.50 * owp[j] + 0.25 * oowp[j];
 	    printf("%g\n",rpi);
 	}
     }
 }
 
 
 
 	

