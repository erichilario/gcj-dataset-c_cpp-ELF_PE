#include <stdlib.h>
 #include <stdio.h>
 
 int main(){
 	FILE * f_in = fopen("test","rt");
 	FILE * f_out = fopen("out","wt");
 	int n,t,i,c[1001],sum,min,j;
 	fscanf(f_in,"%i",&t);
 	for(j=0;j<t;j++){
 		fscanf(f_in,"%i",&n);
 		sum =0;
 		min = 999999;
 		for(i=0;i<n;i++){
 			fscanf(f_in,"%i",&c[i]);
 			sum += c[i];
 			if (min>c[i])
 				min = c[i];
 		}
 
 		int xor = c[0];		
 		for(i=1;i<n;i++)
 			xor ^= c[i];
 
 		if (xor==0){
 			fprintf(f_out,"Case #%i: %i\n",j+1,sum-min);
 		}else{
 			fprintf(f_out,"Case #%i: NO\n",j+1);
 		}
 
 	}
 	fclose(f_in);
 	fclose(f_out);
 }

