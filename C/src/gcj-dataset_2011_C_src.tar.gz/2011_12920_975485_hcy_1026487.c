#include <stdlib.h>
 #include <stdio.h>
 
 int t, c, d, n;
 
 char cs[50][5];
 char ds[50][5];
 char ns[105];
 
 char stack[100];
 int top;
 
 static int findOpposed()
 {
 	int i, j;
 	char target;
 	for(i = 0; i < d; ++i){
 		if(stack[top - 1] == ds[i][0]){
 			target = ds[i][1];
 		}else if(stack[top - 1] == ds[i][1]){
 			target = ds[i][0];
 		}
 		for(j = top - 2; j >=0; --j){
 			if(stack[j] == target){
 				top = 0;
 				return 1;
 			}
 		}
 	}
 	return 0;
 }
 
 static int findCombine()
 {
 	int i;
 	for(i = 0; i < c; ++i){
 		if(cs[i][0] == stack[top - 1] && cs[i][1] == stack[top - 2]){
 			stack[top - 2] = cs[i][2];
 			top -= 1;
 			return 1;
 		}
 		if(cs[i][0] == stack[top - 2] && cs[i][1] == stack[top - 1]){
 			stack[top - 2] = cs[i][2];
 			top -= 1;
 			return 1;
 		}
 	}
 	return 0;
 }
 
 int main(int argc, char **argv)
 {
 	char tmpc;
 	int cnt, id = 0;
 	scanf("%d", &t);
 	while(t--){
 		++id;
 		scanf("%d", &c);
 		cnt = 0;
 		while(cnt < c){
 			scanf("%c", &tmpc);
 			while(tmpc == ' '){
 				scanf("%c", &tmpc);
 			}
 			cs[cnt][0] = tmpc;
 			scanf("%c", &tmpc);
 			cs[cnt][1] = tmpc;
 			scanf("%c", &tmpc);
 			cs[cnt][2] = tmpc;
 			cs[cnt][3] = '\0';
 			++cnt;
 		}
 		
 		scanf("%d", &d);
 		cnt = 0;
 		while(cnt < d){
 			scanf("%c", &tmpc);
 			while(tmpc == ' '){
 				scanf("%c", &tmpc);
 			}
 			ds[cnt][0] = tmpc;
 			scanf("%c", &tmpc);
 			ds[cnt][1] = tmpc;
 			ds[cnt][2] = '\0';
 			++cnt;
 		}
 		
 		scanf("%d", &n);
 		scanf("%c", &tmpc);
 		while(tmpc == ' '){
 			scanf("%c", &tmpc);
 		}
 		cnt = 1;
 		ns[0] = tmpc;
 		while(cnt < n){
 			scanf("%c", &tmpc);
 			ns[cnt] = tmpc;
 			++cnt;
 		}
 		ns[cnt] = '\0';
 		
 		int i;
 		top = 0;
 		for(i = 0; i < n; ++i){
 			stack[top] = ns[i];
 			++top;
 			while(findCombine());
 			while(findOpposed());
 		}
 
 		printf("Case #%d: [", id);
 		for(i = 0; i < top - 1; ++i){
 			printf("%c, ", stack[i]);
 		}
 		if(top == 0){
 			printf("]\n");
 		}else{
 			printf("%c]\n", stack[top - 1]);
 		}
 	}
 
 	return 0;
 }

