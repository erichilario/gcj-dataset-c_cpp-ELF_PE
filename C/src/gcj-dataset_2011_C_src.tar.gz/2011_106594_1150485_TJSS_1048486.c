#include<stdio.h>
 #include<string.h>
 
 int main()
 {
 
    int T,N;
    double wp[200],owp[200],oowp[200],rip[200],num1[200],num0[200];
 	char teams[200][200];
     double tempoowp,curwp,curn0,curn1,curowp,totowp;
    int i,j,k,l,p,ip1,ip2;
 
    scanf("%d",&T);
    for(i=0;i<T;i++)
 	{
 		scanf("%d",&N);
 		for(ip1=0;ip1<N;ip1++)
 		{
 			scanf("%s",teams[ip1]);
 			num0[ip1]=0;num1[ip1]=0;
 		}
 	
 		for(k=0;k<N;k++)
 		{
 			for(l=0;l<N;l++)
 			{
 				 if(teams[k][l]=='0')
 					{ num0[k]++;}
 			 	 else if(teams[k][l]=='1')
 					{num1[k]++;}
 			}
 			wp[k]=num1[k]/(num1[k]+num0[k]);
 		}
 		
 		for(k=0;k<N;k++)
 		{ totowp=0;
 			for(l=0;l<N;l++)
 			{       
 				if(k!=l && teams[k][l]!='.')
 				{
 					curwp=wp[l];
 					curn0=num0[l];
 					curn1=num1[l];
 					if(teams[k][l]=='0')
 					{ curn1--;
 					}
 					else if(teams[k][l]=='1')
 					{curn0--;	
 					}
 					curwp=curn1/(curn1+curn0);
 					totowp=totowp+curwp;
 				}
 			}
 			owp[k]=totowp/(num0[k]+num1[k]);
 		}
 
              for(k=0;k<N;k++)
 		{    tempoowp=0;
 			for(l=0;l<N;l++)
 			{
 				if(teams[k][l]!='.')
 				{
 					tempoowp=tempoowp+owp[l];
 				}
 			}
 			oowp[k]=tempoowp/(num0[k]+num1[k]);
 		}
 		printf("Case #%d:\n",i+1);
 		for(p=0;p<N;p++)
 		{
 			rip[p]=0.25*wp[p]+0.5*owp[p]+0.25*oowp[p];
 		        	printf("%lf\n",rip[p]);
 		}
 }
 return 0;
 }
 				
 
 				
    

