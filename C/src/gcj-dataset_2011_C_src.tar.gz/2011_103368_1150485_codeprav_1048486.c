#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
 	int i,j,k,t,n;
 	char src[100][100];
 	double rpi[100],owp[101],oowp[101];
 	scanf("%d",&t);
 	for(i=0;i<t;i++)
 	{
 		int count[100]={0},**list;
 		list=(int**)calloc(100,sizeof(int*));
 		for(j=0;j<100;j++)
 			list[j]=(int*)calloc(100,sizeof(int));
 		scanf("%d",&n);
 		for(j=0;j<n;j++)
 		{
 			scanf("%s",src[j]);
 			for(k=0;k<n;k++)
 			{
 				if(src[j][k]!='.')
 				{
 					list[j][j]+=(src[j][k]-'0');
 					count[j]++;
 				}
 			}
 			for(k=0;k<n;k++)
 			{
 				if(src[j][k]!='.')
 					list[j][k]+=list[j][j]-(src[j][k]-'0');
 			}
 		}
 		//calculating owp
 		for(j=0;j<n;j++)
 		{
 			double sum=0.0;
 			for(k=0;k<n;k++)
 			{
 				if(src[j][k]!='.')
 				{
 					sum=sum+((double)list[k][j])/(count[k]-1);
 				}
 			}
 			owp[j]=sum/count[j];
 //			printf("%lf\n",owp[j]);
 		}
 //		printf("\n");
 		// claculating oowp
 		for(j=0;j<n;j++)
 		{
 			double sum=0.0;
 			for(k=0;k<n;k++)
 			{
 				if(src[j][k]!='.')
 					sum=sum+owp[k];		
 			}
 			oowp[j]=sum/count[j];
 //			printf("%lf\n",oowp[j]);
 		}	
 		printf("Case #%d:\n",i+1);
 		for(j=0;j<n;j++)
 		{
 			rpi[j]=0.25*(((double)list[j][j])/count[j])+0.50*owp[j]+0.25 *oowp[j];
 			printf("%0.7lf\n",rpi[j]);
 		}
 		for(j=0;j<100;j++)
 			free(list[j]);
 		free(list);
 	}
 	return 0;
 }

