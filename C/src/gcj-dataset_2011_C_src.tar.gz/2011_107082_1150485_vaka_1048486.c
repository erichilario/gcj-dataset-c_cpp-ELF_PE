#include<stdio.h>
 char sch[100][100];
 
 void solve(int n){
 	int i,j,k,opp,opp_1;
 	int played[100],won[100];
 	int oplayed[100][100],owon[100][100];
 	float wp,owp,oowp,oowp_1,rpi,tmp,tmp_1;
 	for(i=0;i<n;i++){
 		played[i]=won[i]=0;
 		for(j=0;j<n;j++){
 			oplayed[i][j]=owon[i][j]=0;
 		}
 	}
 	
 	for(i=0;i<n;i++){
 		for(j=i+1;j<n;j++){
 			if(sch[i][j] != '.'){
 				played[i]++;
 				played[j]++;
 				oplayed[i][j]--;
 				oplayed[j][i]--;
 				if(sch[i][j] == '1'){
 					won[i]++;
 					owon[i][j]--;
 				}else{
 					won[j]++;
 					owon[j][i]--;
 				}
 			}			
 		}
 	}
 	
 	for(i=0;i<n;i++){
 		//printf("Team: %d\n",i);
 		opp = opp_1 = 0;
 		owp = oowp = oowp_1 = 0;
 		wp = (float) won[i]/played[i];
 		//printf("Win Percentage: %f\n",wp);
 		for(j=0;j<n;j++){
 			if(j != i && sch[i][j] != '.'){
 				//printf("Opponent:%d\n",j);
 				oowp_1=opp_1 = 0;
 				tmp = (float) (won[j] + owon[j][i])/(played[j] + oplayed[i][j]);
 				////printf("	owp %f\n",tmp);
 				owp += tmp;
 				for(k=0;k<n;k++){
 					if(k != j && sch[k][j] != '.'){
 						tmp_1 = (float) (won[k] + owon[k][j])/(played[k] + oplayed[k][j]);
 						//printf("	Opponent's Opponent:%d, owp:%f\n",k,tmp_1);
 						oowp_1 += tmp_1;
 						opp_1++;
 					}
 				}
 				oowp_1 = (float) oowp_1/opp_1;
 				//printf("	Total opponents of opponet %d, Avg: %f\n",opp_1,oowp_1);
 				oowp += oowp_1;
 				opp++;
 			}
 		}
 		owp = (float) owp/opp;
 		////printf("Opponents: %d;OWP: %f\n",opp,owp);
 		oowp = (float) oowp/opp;
 		rpi = 0.25*wp + 0.5*owp + 0.25*oowp;
 		printf("%f\n",rpi);
 	}
 }
 
 
 int main(){
 	int t,n,i,j;
 
 	scanf("%d",&t);
 
 	for(i=1;i<=t;i++){
 		scanf("%d",&n);
 		for(j=0;j<n;j++){
 			scanf("%s",sch[j]);
 		}
 		printf("Case #%d:\n",i);
 		solve(n);
 	}
 
 return 0;
 }
