#include<stdio.h>
 #include<conio.h>
 long long int stack[100]={0},x[21]={0};
 int top=-1;
 
 void cal( int num)
 {
  int i=0,j=0,flag=0,a[22]={0},k=0,old=0;
  long long int mi,sum=0;
  mi=x[0];
   for(i=0; i<num; i++)
   {
    j=21;
    sum+=x[i];
    if(mi>x[i])
     mi=x[i];
    k=0;
    while(x[i]!=0)
    {
     a[j]+=x[i]%2;
     x[i]=x[i]/2;
     k++;
     j--;
    }
    if(old<k);
     old=k;
   }
   for(i=21; i>(21-old); i--)
    if(a[i]%2!=0)
    { flag=1;break;}
   if(flag==1)
     stack[top]=0;
   else
    stack[top]=sum-mi;
 
 }
 int main()
 {
 
  int i=0,num=0,te;
 
  scanf("%d",&te);
  while(te--)
  {
   top++;
   scanf("%d",&num);
   for(i=0; i<num; i++)
   {
    scanf("%lld",&x[i]);
   }
   cal(num);
  }
  i=0;
  while(i<=top)
  {
   if(stack[i]==0)
     printf("Case #%d: No",i+1);
   else
    printf("Case #%d: %lld",i+1,stack[i]);
   i++;
   printf("\n");
   getch();
  }
 
  return 0;
 }
