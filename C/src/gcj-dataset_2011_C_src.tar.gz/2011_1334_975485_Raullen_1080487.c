#include<stdio.h>
 #include<string.h>
 #include <stdlib.h>
 
 
 int back_forth(int* seq, int order){
 
 	int tmp_close=101, tmp_pos=0, k;
 	for(k=0;k<101;k++){
 		if((seq[k]>=order) && seq[k]-order<tmp_close){
 			tmp_close = seq[k]-order;
 			tmp_pos = k;
 		}
 	}
 
 	return  tmp_pos;
 }
 
 int main(){
 	long T, N, no_case=0;
 	int i, j, k, q;
 	char tmp_sz[2];
 	int tmp_i, time, O_seq[102], B_seq[102];
 
 
 
 	scanf("%ld",&T);
 	//printf("T = %ld\n",T);
 	for (i=0;i<T;i++){
 		
 		for(j=0;j<102;j++)
 			O_seq[j] = B_seq[j] = -1;
 		time = 0;
 		
 		no_case++;
 		scanf("%ld",&N);
 		//printf("\nN = %ld\n",N);
 		for(j=0;j<N;j++){
 			scanf("%s",&tmp_sz);
 			scanf("%ld",&tmp_i);
 			if(tmp_sz[0] == 'O'){
 				O_seq[j+1] = tmp_i;
 			}
 			else{ 
 				B_seq[j+1] = tmp_i;
 			}
 		}
 		
 
 		int O_pos =1, B_pos=1;
 		j = k = 0;
 
 		for(q=0;q<101;q++){
 			if(j==0 && O_seq[q] > -1) 
 				 j = q;
 			if(k==0 && B_seq[q] > -1) 
 				 k = q;
 		}
 
 		if(j==0) j=100;
 		if(k==0) k=100;
 		
 		while(1){
 
 			time++;
 			int O_mux = 0, B_mux = 0;
 			if (B_seq[k]>0 && B_pos < B_seq[k]){ B_mux = 1;	B_pos++;}
 			if (B_seq[k]>0 && B_pos > B_seq[k]){ B_mux = 1;	B_pos--;}
 			if (O_seq[j]>0 && O_pos < O_seq[j]){ O_mux = 1;	O_pos++;}
 			if (O_seq[j]>0 && O_pos > O_seq[j]){ O_mux = 1;	O_pos--;}
 
 
 			int old_j = j;
 			if(O_mux==0 && O_seq[j] == O_pos && j<k){
 				//push O, update j, process next block
 				for(q=j+1;q<101;q++){
 					if(O_seq[q] != -1){
 						j = q;
 						break;
 					}
 					j = q;
 				}
 			}//otherwise O waits
 			
 			if(B_mux==0 && B_seq[k] == B_pos && old_j>k){
 					//push B, update k
 				for(q=k+1;q<101;q++){
 					if(B_seq[q] != -1){
 						k = q;
 						break;
 					}
 					k = q;
 				}
 			}//otherwise B waits
 			
 
 			if (O_seq[j]!=-1 && B_seq[k] ==-1)
 				k = (k+2<102)?k+2:101;
 
 			if (O_seq[j]==-1 && B_seq[k] !=-1)
 				j = (j+2<102)?j+2:101;
 
 			if (O_seq[j]==-1 && B_seq[k] ==-1)
 				break;
 
 		}
 
 		printf("Case #%ld: %ld\n",no_case, time);
 
 	}
 }
