
 #include <stdio.h>
 
 #define N 100
 
 int all;
 int max;
 int n;
 int a[N];
 
 static void select(int x, int begin, int ans, int sum, int count);
 
 int
 main(void)
 {
 	int test;
 	int i, j;
 
 	scanf("%d", &test);
 	for (j = 1; j <= test; ++j) {
 		scanf("%d", &n);
 
 		all = 0;
 		for (i = 0; i < n; ++i) {
 			scanf("%d", &a[i]);
 			all ^= a[i];
 		}
 
 		max = -1;
 		for (i = 1; i < n; ++i)
 			select(i, 0, 0, 0, 0);
 
 		printf("Case #%d: ", j);
 		if (max == -1)
 			printf("NO\n");
 		else
 			printf("%d\n", max);
 	}
 
 	return 0;
 }
 
 static void
 select(int x, int begin, int ans, int sum, int count)
 {
 	int i;
 
 	if (count == x) {
 		if ((all ^ ans) == ans && max < sum)
 			max = sum;
 		return;
 	}
 
 	for (i = begin; i < n; ++i)
 		select(x, i + 1, ans ^ a[i], sum + a[i], count + 1);
 }

