#include <stdio.h>
 #include <stddef.h>
 #include <stdlib.h>
 #include <string.h>
 
 char Table[100][100];
 double RPI[100];
 
 void calc_rpi(int N)
 {
 	int i, j, k;
 	int win[100], lose[100];
 	int tcount;
 	double WP[100], OWP[100], OOWP[100];
 
 	for (i = 0; i < N; i++) {
 		win[i] = 0;
 		lose[i] = 0;
 		for (j = 0; j < N; j++) {
 			if (Table[i][j] == '1') {
 				win[i]++;
 			}
 			else if (Table[i][j] == '0')
 				lose[i]++;
 		}
 		WP[i] = win[i]/(double)(lose[i]+win[i]);
 	}
 	
 	for (i = 0; i < N; i++) {
 		tcount = 0;
 		OWP[i] = 0;
 		for (j = 0; j < N; j++) {
 			if (Table[i][j] == '.')
 				continue;
 			if (Table[i][j] == '1')
 				OWP[i] += ((win[j]) / (double)(win[j]+lose[j]-1));
 			if (Table[i][j] == '0')
 				OWP[i] += ((win[j]-1) / (double)(win[j]+lose[j]-1));
 			tcount++;
 		}
 		OWP[i] /= tcount;
 	}
 	for (i = 0; i < N; i++) {
 		tcount = 0;
 		OOWP[i] = 0;
 		for (j = 0; j < N; j++) {
 			if (Table[i][j] == '.')
 				continue;
 			OOWP[i] += OWP[j];
 			tcount++;
 		}
 		OOWP[i] /= tcount;
 	}
 	for (i = 0; i < N; i++) {
 		RPI[i] = 0.25 * WP[i] + 0.50 * OWP[i] + 0.25 * OOWP[i];
 	}
 }
 
 int main(int argc, char **argv)
 {
 	FILE *fp_in, *fp_out;
 	int i, j, k;
 	int T;
 	int N;
 
 	fp_in = fopen(argv[1], "r");
 	if (fp_in == NULL) {
 		perror(argv[1]);
 		exit(1);
 	}
 	fp_out = fopen(argv[2], "w");
 	if (fp_out == NULL) {
 		perror(argv[2]);
 		exit(1);
 	}
 
 	fscanf(fp_in, "%d ", &T);
 	for (i = 0; i < T; i++) {
 		fscanf(fp_in, "%d ", &N);
 		for (j = 0; j < N; j++) {
 			for (k = 0; k < N; k++) {
 				fscanf(fp_in, "%c", &Table[j][k]);
 			}
 			fscanf(fp_in, " ");
 		}
 		calc_rpi(N);
 
 
 		fprintf(fp_out, "Case #%d:\n", i+1);
 		for (j = 0; j < N; j++) {
 			fprintf(fp_out, "%.12lf\n", RPI[j]);
 		}
 	}
 
 	fclose(fp_in);
 	fclose(fp_out);
 	return 0;
 }

