#include <stdlib.h>
 #include <stdio.h>
 
 int abs(int a) {
     if (a > 0)
         return a;
     return -a;
 }
 
 int main(char *argv[], int argc) {
 
     FILE *input_data = fopen("input.txt", "r");
 
     char buf[8192];
     int index = -1;
 
     while (!feof(input_data)) {
         buf[++index] = getc(input_data);
     }
     buf[++index] = '\0';
     fclose(input_data);
 
     FILE *output_data = fopen("output.txt", "w");
     index = 0;
 
     while (buf[index] != '\n')
         ++index;
     while (buf[index] != ' ')
         ++index;
 
     int case_id = 1;
 
     while (buf[index] != 0) {
         int fail = 0;
 
         int score = 0;
 
         int blue = 1;
         int red = 1; 
         int blue_dist = 0;
         int red_dist = 0;
 
         int blue_residue = 0;
         int red_residue = 0;
 
         int blue_turns = 0;
         int red_turns = 0;
 
         while (buf[index] != '\n') {
             ++index;
             char bot = buf[index];
             ++index;
 
             char num_buf[10];
             int num_index = -1;
             int temp_index = index;
 
             int value = 0;
 
             while (buf[++temp_index] < 0x3A && buf[temp_index] > 0x2F) {
                 num_buf[++num_index] = buf[temp_index];
             }
 
             if (num_index > -1) {
                 num_buf[++num_index] = '\0';
                 value = atoi(num_buf);
             }
             else {
                 fail = 1;
                 break;
             }
 
             if (bot == 'B') {
                 int addition = abs(blue - value);
 
                 blue_residue += addition;
 
                 if (blue_residue > 0) {
                    score += blue_residue + 1;
                    red_residue -= (blue_residue + 1);
                 }
                 else {
                     ++score;
                     --red_residue;
                 }
 
                 blue_residue = 0;
                 blue = value;
             }
             else if (bot == 'O') {
                 int addition = abs(red - value);
 
                 red_residue += addition;
 
                 if (red_residue > 0) {
                    score += red_residue + 1;
                    blue_residue -= (red_residue + 1);
                 }
                 else {
                     ++score;
                     --blue_residue;
                 }
 
                 red_residue = 0;
                 red = value;
             }
 
             index = temp_index;
         }
         if (buf[index] != 0) {
             while (buf[index] != ' ')
                 ++index;
         }
         else
             break;
 
         if (fail == 1)
             break;
 
         fprintf(output_data, "Case #%i: %i\n", case_id, score);
 
         ++case_id;
     }
 
     fclose(output_data);
 
     return 0;
 }

