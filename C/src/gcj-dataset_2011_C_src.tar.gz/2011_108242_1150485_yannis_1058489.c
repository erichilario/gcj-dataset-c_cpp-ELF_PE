#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int P[222], V[222];
 double groupmin[222], groupst[222], groupfin[222];
 int groupStartId[222];
 int C, D;
 
 double max(double a, double b) { return (a > b ? a : b); }
 double min(double a, double b) { return (a < b ? a : b); }
 
 double dogroup(int a, int b, int groupid) {
     int s = 0, i;
     double q = 0, o = 0x3f3f3f;
     double xx;
 
     for (i=a; i<=b; i++) {
         o = min( s*D - (P[i]-P[a]) , o);
         s += V[i];
         q = max( (s-1)*D - (P[i]-P[a]) , q);
     }
 
     xx = (fabs(q) - fabs(o)) / 2.0;
     groupmin[groupid ] = max(fabs(q), fabs(o)) - xx;
 
     groupst[ groupid ] = V[a] - xx;
     groupfin[ groupid ] = V[a] + (s-1)*D + xx;
 }
 
 int main(void) {
     freopen("input.txt", "r", stdin);
     freopen("output.txt", "w", stdout);
     int i, j, t, T, last, groupcnt;
     double mans;
 
     scanf("%d", &T);
 
     for (t=1; t<=T; t++) {
         scanf("%d %d", &C, &D);
         groupcnt = 0;
         groupStartId[1] = 1;
 
         for (i=1; i<=C; i++) {
             scanf("%d %d", &P[i], &V[i]);
         }
 
         for (i=2; i<=C; i++) {
             if ( V[i] - V[i-1] > C ) {
                 groupcnt++;
                 dogroup(groupStartId[groupcnt], i-1, groupcnt);
                 while (groupcnt > 1 && groupfin[groupcnt-1] - groupst[groupcnt] < D ) {
                     dogroup(groupStartId[groupcnt-1], i-1, groupcnt-1);
                     groupcnt--;
                 }
 
                 groupStartId[groupcnt+1] = i;
             }
         }
         groupcnt++;
         dogroup(groupStartId[groupcnt], C, groupcnt);
         while (groupcnt > 1 && groupfin[groupcnt-1] - groupst[groupcnt] < D ) {
             dogroup(groupStartId[groupcnt-1], C, groupcnt-1);
             groupcnt--;
         }
 
         mans = groupmin[1];
 
         for (i=2; i<=groupcnt; i++) {
             if ( groupmin[i] > mans ) mans = groupmin[i];
         }
 
         printf("Case #%d: %lf\n", t, mans);
     }
 
     return 0;
 }
 

