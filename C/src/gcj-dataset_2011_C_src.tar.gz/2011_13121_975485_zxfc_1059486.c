#include<stdio.h>
 int ar[16];
 int main(){
 	int t,i,j,r,s,m,n;
 	scanf("%d",&t);
 	for(i=1;i<=t;i++){
 
 		scanf("%d",&n);
 		r=0;
 		for(j=1;j<=n;j++){
 			scanf("%d",&ar[j]);
 			r=r^ar[j];
 		}
 		if(r){
 			printf("Case #%d: NO\n",i);
 			continue;
 		}
 		else{
 			s=ar[1];
 			m=ar[1];
 			for(j=2;j<=n;j++){
 				if(m>ar[j])m=ar[j];
 				s+=ar[j];
 			}
 			printf("Case #%d: %d\n",i,s-m);
 		}
 	}
 	//system("PAUSE");
 	return 0;
 }
 
 			

