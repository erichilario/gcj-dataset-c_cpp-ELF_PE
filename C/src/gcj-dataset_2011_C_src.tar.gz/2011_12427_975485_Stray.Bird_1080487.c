#include <stdio.h>
 #include <math.h>
 
 int main()
 {
     int tkase, kase, n, p, op, bp, cs, ls, res;
     char r[2], cr, lr;
 
     scanf("%d", &tkase);
     for ( kase = 1; kase <= tkase; kase++ ) {
         printf("Case #%d: ", kase);
         scanf("%d", &n);
         op = bp = 1;
         res = ls = 0;
         while ( n-- ) {
             scanf("%s %d", r, &p);
             if ( r[0] == 'O' ) {
                 cr = 'O';
                 cs = abs(p - op) + 1;
                 op = p;
             } else {
                 cr = 'B';
                 cs = abs(p - bp) + 1;
                 bp = p;
             }
 
             if ( cr == lr ) {
                 ls += cs;
             } else {
                 if ( ls >= cs ) cs = 1;
                 else cs -= ls;
                 ls = cs;
                 lr = cr;
             }
             res += cs;
         }
         printf("%d\n", res);
     }
     return 0;
 }
 

