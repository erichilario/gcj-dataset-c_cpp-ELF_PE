#include <stdio.h>
 
 int main()
 {
     int t;
     int n;
     scanf("%d", &t);
     int i, j, k;
     char buf[105][105];
     double wp[105];
     double owp[105];
     double oowp[105];
     int win[105];
     int count[105];
     for (i = 0 ;i < t ; i ++)
     {
         scanf("%d", &n);
         for (j = 0; j < n ; j ++)
         {
             scanf("%s", buf[j]);
             count[j] = 0;
             win[j] = 0;
             for (k = 0; k < n; k ++)
             {
                 if (buf[j][k] != '.')
                     count[j] ++;
                 if (buf[j][k] == '1')
                     win[j] ++;
             }
             wp[j] = (double) win[j] / count[j];
         }
 
         for (j = 0; j < n; j ++)
         {
             double sum = 0;
             for (k = 0; k < n; k ++)
             {
                 if (buf[j][k] != '.')
                 {
                     int w = win[k];
                     int c = count[k] - 1;
                     if (buf[j][k] == '0')
                         w --;
                     sum += (double) w / c;
                 }
             }
             owp[j] = sum / count[j];
         }
         
         for (j = 0; j < n; j ++)
         {
             int count = 0;
             double sum = 0;
             for (k = 0; k < n; k ++)
             {
                 if (buf[j][k] != '.')
                 {
                     sum += owp[k];
                     count ++;
                 }
             }
             oowp[j] = sum / count;
         }
 
 
         printf("Case #%d:\n", i + 1);
         for (j = 0; j < n; j ++)
             printf("%1.10lf\n", 0.25 * wp[j] + 0.5 * owp[j] + 0.25 * oowp[j]);
     }
 }

