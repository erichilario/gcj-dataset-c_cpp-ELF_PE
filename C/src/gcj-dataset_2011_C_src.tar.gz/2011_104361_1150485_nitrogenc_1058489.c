#include <stdlib.h>
 #include <stdio.h>
 #include <math.h>
 
 #define MAX_VENDORS 200
 
 float max(float n1, float n2)
 {
 	if (n2 < n1)
 	{
 		return n1;
 	}
 	else
 	{
 		return n2;
 	}
 }
 
 int main(void)
 {
 	FILE *f_in, *f_out;
 	if (!(f_in = fopen("B.in", "r")))
 	{
 		printf("ERROR: no input file.\n");
 		return EXIT_FAILURE;
 	}
 	f_out = fopen("B.out", "w+");
 	
 	int i, j, n;
 	int distance, points;
 	int p_min, p_max;
 	int num = 0;
 	int nb, ou;
 	int couverture, range;//concentration;
 	float couvplus;
 	float res;//move
 	
 	fscanf(f_in, "%d\n", &n);
 	for(i = 0; i < n; i++)
 	{
 		num = 0;
 		couvplus = 0;
 		fprintf(f_out, "Case #%d: ", i+1);
 		fscanf(f_in, "%d %d\n", &points, &distance);
 		//On remplit la liste avec l'ensemble des positions.
 		for(j = 0; j < points; j++)
 		{
 			fscanf(f_in, "%d %d\n", &ou, &nb);
 			couvplus+=(((nb-1)*1.0)/2)*distance;
 			//if (concentration < nb) concentration = nb;
 			if (num != 0)
 			{
 				if (ou < p_min) p_min = ou;
 				if (ou > p_max) p_max = ou;
 			}
 			else
 			{
 				p_min = ou;
 				p_max = ou;
 			}
 			num+=nb;
 		}
 		printf("Positions : %d, %d\n", p_min, p_max);
 		couverture = (num-1)*distance;
 		if (p_min < 0 && p_max >> 0)
 		{
 			range = p_max - p_min;
 			printf("(-+)>%d\n", range);
 		}
 		else
 		{
 			range = abs(p_max) - abs(p_min);
 			printf("(--/++)>%d\n", range);
 		}
 		/*couverture-=range;
 		res = (couverture*1.0)/2;
 		//Voici le nombre de mtres requis pour dispatcher un groupe :
 		move = (((concentration-1)*1.0)/2)*distance;
 		res = max(res, move);
 		*/
 		res = abs((couvplus - range)/2*1.0);
 		
 		
 		fprintf(f_out, "%.6g", res);
 		if (floor(res) == res) fprintf(f_out, ".0");
 		fprintf(f_out, "\n");
 	}
 	fclose(f_in);
 	fclose(f_out);
 	return EXIT_SUCCESS;
 }

