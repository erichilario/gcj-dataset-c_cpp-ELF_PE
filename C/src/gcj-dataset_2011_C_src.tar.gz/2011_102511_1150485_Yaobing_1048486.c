#include <stdio.h>
 #include <stdlib.h>
 #define MAX 110
 
 char schedule[MAX][MAX];
 double WP[MAX], OWP[MAX], OOWP[MAX], RPI[MAX];
 int numWP[MAX], numOWP[MAX], numOOWP[MAX];
 
 int main()
 {
     int t, n, count = 1, i, j;
     double tmp;
     
     FILE *finp = fopen("A-small-attempt0.in","r");
 	FILE *foutp = fopen("A.out","w");
     fscanf(finp, "%d", &t);  
     //scanf("%d", &t);
     
     while (t--)
     {
         fscanf(finp, "%d", &n); 
         //scanf("%d", &n);
         
         for (i = 0; i < n; i++)
         {
             fscanf(finp, "%s", schedule[i]); 
             //scanf("%s", schedule[i]);
         }
         
         memset(WP, 0, sizeof(WP));
         memset(OWP, 0, sizeof(OWP));
         memset(OOWP, 0, sizeof(OOWP));
         memset(numWP, 0, sizeof(numWP));
         memset(numOWP, 0, sizeof(numOWP));
         memset(numOOWP, 0, sizeof(numOOWP));
         
         for (i = 0; i < n; i++)
         {
             for (j = 0; j < n; j++)
             {
                 if (schedule[i][j] == '1')
                     WP[i]++;
                 if (schedule[i][j] != '.')
                     numWP[i]++;
             }
             WP[i] /= (double)numWP[i];
         }
         
         for (i = 0; i < n; i++)
         {
             for (j = 0; j < n; j++)
             {
                 if (schedule[i][j] != '.')
                 {
                     tmp = WP[j] * (double)numWP[j];
                     if (schedule[i][j] == '0') tmp--;
                     tmp /= (double)(numWP[j] - 1);
                     OWP[i] += tmp;
                     numOWP[i]++;
                 }
             }
             OWP[i] /= (double)numOWP[i];
         }
         
         for (i = 0; i < n; i++)
         {
             for (j = 0; j < n; j++)
             {
                 if (schedule[i][j] != '.')
                 {
                     OOWP[i] += OWP[j];
                     numOOWP[i]++;
                 }
             }
             OOWP[i] /= (double)numOOWP[i];
         }
         
         fprintf(foutp, "Case #%d:\n", count++);
         //printf("Case #%d:\n", count++);
         
         for (i = 0; i < n; i++)
         {
             RPI[i] = 0.25 * WP[i] + 0.50 * OWP[i] + 0.25 * OOWP[i];
             
             fprintf(foutp, "%.9lf\n", RPI[i]);
             //printf("%.9lf\n", RPI[i]);
         }
     }
     
     fclose(finp);
     fclose(foutp);
     
     return 0;
 }

