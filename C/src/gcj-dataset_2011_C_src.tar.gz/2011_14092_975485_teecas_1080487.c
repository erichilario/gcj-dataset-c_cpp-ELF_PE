/*
  *  bot_trust.c
  *  GoogleCodeJam2011
  *
  *  Created by Vinicius Tosta Ribeiro on 06/05/11.
  *  Copyright 2011 __MyCompanyName__. All rights reserved.
  *
  */
 
 #include "bot_trust.h"
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 FILE* read_input(char name[]) {
 	FILE* arq;
 	char path[100];
 	
 	strcat(path, "/Users/vribeiro/Documents/GoogleCodeJam2011/");
 	strcat(path, name);
 	
 	arq = fopen(path, "r");
 	
 	return arq;
 }
 
 void solve(FILE* input) {
 	
 	int T, t, N, n;
 	int i, b;
 	int time;
 	char bot;
 	int btn;
 	int timeline[101];
 	int orders_bot[3][101], I[3], pos[3];
 	int cur_bot, cur_btn;
 	
 	FILE* out = fopen("/Users/vribeiro/Desktop/A-small-attempt0.out.txt", "w");
 	
 	fscanf(input, "%d", &T);
 	
 	for (t = 0; t < T; t++) {
 		
 		fscanf(input, "%d", &N);
 		
 		i = 0;
 		I[1] = 0;
 		I[2] = 0;
 		
 		// carrega as ordens
 		for (n = 0; n < N; n++) {
 			fscanf(input, "%c", &bot);
 			if (bot == 'O' || bot == 'B') {
 				fscanf(input, "%d", &btn);
 				
 				if (bot == 'B') {
 					orders_bot[1][I[1]] = btn;
 					I[1]++;
 					timeline[i] = 1000;
 				}
 				else if (bot == 'O') {
 					orders_bot[2][I[2]] = btn;
 					I[2]++;
 					timeline[i] = 2000;
 				}
 				timeline[i] += btn;
 				i++;
 			}
 			else {
 				n--;
 			}
 		}
 		
 		// processa as ordens
 		// 1 : Blue
 		// 2 : Orange
 		i = 0;
 		I[1] = 0;
 		I[2] = 0;
 		pos[1] = 1;
 		pos[2] = 1;
 		for (time = 0; i < N; time++) {
 			cur_bot = timeline[i]/1000;
 			cur_btn = timeline[i]%1000;
 			
 			for (b = 1; b <= 2; b++) {
 				if (b == cur_bot) {
 					if (pos[b] - orders_bot[b][I[b]] == 0) {
 						I[b]++;
 						i++;
 					}
 					else {
 						if (pos[b] > orders_bot[b][I[b]]) {
 							pos[b]--;
 						}
 						else {
 							pos[b]++;
 						}
 					}
 
 				}
 				else {
 					if (pos[b] - orders_bot[b][I[b]] != 0) {
 						if (pos[b] > orders_bot[b][I[b]]) {
 							pos[b]--;
 						}
 						else {
 							pos[b]++;
 						}
 					}
 				}
 			}
 			//printf("time: %d   pos[1] = %d  pos[2] = %d\n", time, pos[1], pos[2]);
 		}
 		fprintf(out, "Case #%d: %d\n", t+1, time);
 	}
 	fclose(out);
 }
 
 void solve_bot_trust() {
 	FILE* input;
 	
 	input = read_input("A-small-attempt0.in");
 	if (input != NULL) {
 		solve(input);
 		fclose(input);
 	}
 }

