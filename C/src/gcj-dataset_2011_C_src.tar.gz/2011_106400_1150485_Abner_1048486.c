#include <stdio.h>
 #include <math.h>
 #include <string.h>
 
 int main() {
 	int T, test=1, v[100], p[100], n, i, j, k, l;
 	double temp,  points[100], owp[100];
 	char matches[100][100];
 	
 	scanf("%d", &T);
 	while (T--) {
 		scanf("%d%*c", &n);
 		for (i = 0; i < n; i++)
 			scanf("%s", &matches[i][0]);
 		for (i = 0; i < n; i++) {
 			k = l = 0;
 			for (j = 0; j < n; j++) {
 				if (matches[i][j] == '1') {
 					k++;
 					l++;
 				} else if(matches[i][j] == '0') {
 					l++;
 				}
 			}
 			v[i] = k;
 			p[i] = l;
 			points[i] = (double)(0.25 * k) / l;
 		}
 		for (i = 0; i < n; i++) {
 			temp = 0;
 			for (j = 0; j < n; j++) 
 				if (matches[i][j] != '.') {
 					k = v[j];
 					l = p[j] - 1;
 					if (matches[i][j] == '0')
 						k--;
 					temp += (double)(1.0 * k) / l;
 				}
 			owp[i] = temp / p[i];
 		}
 		for (i = 0; i < n; i++) {
 			temp = 0;
 			for (j = 0; j < n; j++)  
 				if (matches[i][j] != '.') 
 					temp += owp[j];
 			points[i] += (double)0.25 * temp / p[i];
 			points[i] += (double)owp[i] * 0.5;
 		}
 		printf("Case #%d:\n", test++);
 		for (i = 0; i < n; i++)
 			printf("%.12lf\n", points[i]); 
 	}
 	return 0;
 }

