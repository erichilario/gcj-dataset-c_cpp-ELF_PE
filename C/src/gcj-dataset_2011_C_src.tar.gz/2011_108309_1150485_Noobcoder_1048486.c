#include<stdio.h>
 #include<math.h>
 #include<stdlib.h>
 #include<string.h>
 double ans[150][100];int sch[100][100];double wp[100][2]={0},owp[100]={0},oowp[100]={0},length[100];
 void main()
 {
 	int t,i,j;
 	scanf("%d",&t);
 	for(i=0;i<t;i++)
 	{
 		int n,k;
 		scanf("%d",&n);
 		length[i]=n;
 		for(j=0;j<n;j++)
 		{
 			int co=0;
 			char ch[100];
 			scanf("%s",ch);
 			//puts(ch);
 			int sum=0;
 			for(k=0;k<n;k++)
 			{
 			
 				
 				if(ch[k]=='.')
 				sch[j][k]=-1;
 				else if(ch[k]=='0')
 				sch[j][k]=0;		
 				else if(ch[k]=='1')
 				sch[j][k]=1;
 				if(sch[j][k]!=-1)
 				{
 				sum+=sch[j][k];co++;
 				}
 				
 			}
 			//printf("%d ",sum);
 			//printf("%lf\n",wp[j][0]);
 			//printf("\n");
 			wp[j][0]=sum/(double)co;
 			wp[j][1]=co;
 			//printf("%lf\n",wp[j][0]);
 			
 		}
 		for(j=0;j<n;j++)
 		{
 	
 			double s=0;
 			
 			for(k=0;k<n;k++)
 			{
 				if(j!=k)
 				{
 					if(sch[k][j]!=-1)
 					s+=(wp[k][0]*wp[k][1]-sch[k][j])/(wp[k][1]-1);
 				}
 				
 			}
 			//printf("%lf\n",owp[j]);
 
 			owp[j]=s/wp[j][1];
 			//printf("%lf\n",owp[j]);
 
 		}
 		for(j=0;j<n;j++)
 		{
 
 			double s=0;
 			
 			for(k=0;k<n;k++)
 			{
 				if(j!=k)
 				{
 					if(sch[j][k]!=-1)
 					s+=owp[k];
 				}
 			}
 			oowp[j]=s/wp[j][1];
 		}	
 		for(j=0;j<n;j++)
 		{
 		double rpi=0.25 * wp[j][0] + 0.50 * owp[j] + 0.25 * oowp[j];
 		ans[i][j]=rpi;
 		}
 		
 	}
 	for(i=0;i<t;i++)
 	{
 		printf("Case #%d:\n",i+1,ans[i]);
 		for(j=0;j<length[i];j++)
 		{
 			printf("%g\n",ans[i][j]);
 		}	
 
 	}
 }			

