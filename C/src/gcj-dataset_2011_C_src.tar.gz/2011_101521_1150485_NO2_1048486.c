#include<stdio.h>
 #define LIM 10
 main() {
 	FILE *fpi,*fpo;
 	int i,t,n,j,k,ttl,wn,tl[LIM];
 	char m[LIM][LIM];
 	float wp[LIM],owp[LIM],oowp[LIM],rpi[LIM],wps,tp;
 	fpi=fopen("in.txt","r");
 	fpo=fopen("out.txt","w");
 	fscanf(fpi,"%d",&t);
 	for(i=0;i<t;i++) {
 		fscanf(fpi,"%d",&n);
 		fscanf(fpi,"\n");
 		for(j=0;j<n;j++) {
 			for(k=0;k<n;k++) {
 				fscanf(fpi,"%c",&m[j][k]);
 			}
 			fscanf(fpi,"\n");
 		}
 		for(j=0;j<n;j++) {
 			ttl=0;
 			wn=0;
 			for(k=0;k<n;k++) {
 				if(m[j][k]=='1') {
 					wn++;
 					ttl++;
 				}
 				else if(m[j][k]=='0') ttl++;
 			}
 			wp[j]=1.0*wn/ttl;
 			tl[j]=ttl;
 		}
 		for(j=0;j<n;j++) {
 			wps=0;
 			for(k=0;k<n;k++) {
 				if(m[j][k]=='0') {
 					tp=(wp[k]*tl[k]-1)/(tl[k]-1);
 					wps+=tp;
 				}
 				else if(m[j][k]=='1') {
 					tp=(wp[k]*tl[k])/(tl[k]-1);
 					wps+=tp;
 				}
 			}
 			owp[j]=wps/tl[j];
 		}
 		for(j=0;j<n;j++) {
 			wps=0;
 			for(k=0;k<n;k++) {
 				if(m[j][k]!='.') {
 					wps+=owp[k];
 				}
 			}
 			oowp[j]=wps/tl[j];
 		}
 		for(j=0;j<n;j++) {
 			rpi[j]=.25*wp[j]+.5*owp[j]+.25*oowp[j];
 		}
 		fprintf(fpo,"Case #%d:\n",i+1);
 		for(j=0;j<n;j++) {
 			fprintf(fpo,"%.7f\n",rpi[j]);
 		}
 	}
 }
