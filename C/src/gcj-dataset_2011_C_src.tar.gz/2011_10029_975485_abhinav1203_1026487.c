#include<stdio.h>
 int makepair[256][256],dest[256][256];
 char s[105];
 char stack[105];
 int main()
 {
   int T,C,D,N,i,j,k,top;
   scanf("%d",&T);
   for(i=1;i<=T;i++)
     {
       scanf("%d",&C);
       for(j=0;j<=255;j++)
 	for(k=0;k<=255;k++)
 	  makepair[j][k]=0;
       for(j=0;j<C;j++)
 	{
 	  scanf("%s",s);
 	  makepair[(int)s[0]][(int)s[1]]=(int)s[2];
 	  makepair[(int)s[1]][(int)s[0]]=(int)s[2];
 	}
       scanf("%d",&D);
       for(j=0;j<=255;j++)
 	for(k=0;k<=255;k++)
 	  dest[j][k]=0;
       for(j=0;j<D;j++)
 	{
 	  scanf("%s",s);
 	  dest[(int)s[0]][(int)s[1]]=1;
 	  dest[(int)s[1]][(int)s[0]]=1;
 	}
       scanf("%d",&N);
       scanf("%s",s);
       /*
       change=1;
       while(change)
 	{
 	  top=0;
 	  stack[top++]=s[0];
 	  for(j=1;j<N;j++)
 	    {
 	      if(makepair[s[j]][s[j-1]]!=0)
 		{
 		  top=top-1;
 		  stack[top++]=s[
 		}
 		
       */
       top=0;
       stack[top++]=s[0];
       for(j=1;j<N;j++)
 	{
 	  stack[top++]=s[j];
 	  while(top>=2 && makepair[stack[top-1]][stack[top-2]])
 	    {
 	      stack[top-2]=(char)makepair[stack[top-1]][stack[top-2]];
 	      top--;
 	    }
 	  /*
 	  for(k=top-2;k>=0;k--)
 	    {
 	      if(dest[(int)stack[top-1]][(int)stack[k]])
 		{
 		  top=k;
 		}
 	    }
 	  */
 	  for(k=0;k<(top-1);k++)
 	    {
 	      if(dest[(int)stack[top-1]][(int)stack[k]])
 		{
 		  top=0;
 		  break;
 		}
 	    }
 	}
       if(top>0)
 	{
 	  printf("Case #%d: [",i);
 	  for(j=0;j<(top-1);j++)
 	    printf("%c, ",stack[j]);
 	  printf("%c]",stack[top-1]);
 	}
       else
 	{
 	  printf("Case #%d: []",i);
 	}
       printf("\n");
     }
   return 0;
 }

