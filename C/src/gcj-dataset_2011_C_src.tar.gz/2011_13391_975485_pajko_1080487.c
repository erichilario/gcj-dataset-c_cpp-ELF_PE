#include <stdio.h>
 
 #define MAX_BUTTONS 100
 #define MAX_TESTCASES 100
 #define MAX_TERMS 100
 
 #define __min(a,b)          ((a) < (b) ? (a) : (b))
 #define min(a,b)            ((a) < (b) ? (a) : (b))
 #define __max(a,b)          ((a) > (b) ? (a) : (b))
 #define max(a,b)            __max((a), (b))
 #define __min_not_zero(a,b) (((a) == 0) ? (b) : __min((a), (b)))
 #define min_not_zero(a,b)   __min_not_zero((a), (b))
 
 static int robots[MAX_TERMS];
 static int buttons[MAX_TERMS];
 
 static int solve(int terms)
 {
   int i;
   int result = 0;
   int robot_positions[2] = {1, 1, };
   int current_robot = robots[0];
   int prev_time = 0;
   for (i = 0; i < terms; i++) {
     int this_robot_needs = abs(buttons[i] - robot_positions[robots[i]]) + 1;
     if (current_robot != robots[i]) {
       result += prev_time;
       if (prev_time >= this_robot_needs) {
         prev_time = 1;
         // printf(" %d", prev_time);
       } else {
         prev_time = this_robot_needs - prev_time;
         // printf(" %d", prev_time);
       }
       current_robot = robots[i];
     } else {
       prev_time += this_robot_needs;
       // printf(" %d", this_robot_needs);
     }
     robot_positions[robots[i]] = buttons[i];
   }
   // printf(" - %d\n", prev_time);
   result += prev_time;
   return result;
 }
 
 int main(int argc, char **argv)
 {
   int i;
   int testcases;
   FILE *fi = fopen(argv[1], "rt");
   FILE *fo = fopen("result", "wt");
   fscanf(fi, "%d", &testcases);
   for (i = 0; i < testcases; i++) {
     int j, terms;
     fscanf(fi, "%d", &terms);
     for (j = 0; j < terms; j++) {
       char ch;
       do {
         ch = fgetc(fi);
       } while ((ch != 'O') & (ch != 'B'));
       robots[j] = (ch == 'B');
       fscanf(fi, "%d", &buttons[j]);
     }
     fprintf(fo, "Case #%d: %d\n", i + 1, solve(terms));
   }
   fclose(fi);
   fclose(fo);
   return 0;
 }

