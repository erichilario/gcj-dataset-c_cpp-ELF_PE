#include "../../../../CS392/lib/my.h"
 #include <stdlib.h>
 #include <stdio.h>
 #define BUF_LEN 2048
 
 int main(int argc, char** argv)
 {
   char *buffer;
   char *temp;
   int ** teams;
   FILE *fp;
   int t;
   int n;
   int i;
   int j;
   int k;
 
   buffer = (char*)xmalloc(BUF_LEN*sizeof(char));
   teams = (int**)xmalloc(100*sizeof(int*));
   for (i=0;i<100;i++){
     teams[i] = (int*)xmalloc(100*sizeof(int));
   }
 
   fp = fopen("input", "r");
 
   fgets(buffer, BUF_LEN-1, fp);
 
   t = my_atoi(buffer);
 
   for (i=0;i<t;i++){
     fgets(buffer, BUF_LEN-1, fp);
     temp = buffer;
     for (j=0;temp[j]!='\0';j++){
       if (temp[j]==' '){
 	temp[j++]='\0';
 	break;
       }
     }
     n = my_atoi(temp);
 
     for (j=0;j<n;j++){
       fgets(buffer, BUF_LEN-1, fp);
       for (k=0;k<n;k++){
 	if (buffer[k]=='.'){
 	  teams[j][k]=-1;
 	}else if (buffer[k]=='1'){
 	  teams[j][k]=1;
 	}else if (buffer[k]=='0'){
 	  teams[j][k]=0;
 	}
       }
     }
 
     //n = testcase(n, teams);
 
     printf("Case #%d: \n", i+1);
     testcase(n, teams);
   }
 
   free(buffer);
 
   fclose(fp);
 }

