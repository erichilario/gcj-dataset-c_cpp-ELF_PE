#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int get_fp_num(FILE *a);
 
 int main(void){
 	FILE *fp,*fw;
 	char robot;
 	int T,N;
 	int i,j;
 	int P,num,loca_o,loca_b,com_o,com_b,result;
 
 	fp = fopen("A-small-attempt0.in","r");
 	fw = fopen("A-small-attempt0.out","w");
 	
 	T = get_fp_num(fp);
 	
 	for(i=1;i<=T;i++){
 		loca_o=loca_b=1;
 		com_o=com_b=0;
 		result=0;
 		N=get_fp_num(fp);
 		for(j=0;j<N;j++){
 			robot = fgetc(fp);
 			fgetc(fp);
 			P = get_fp_num(fp);
 			if(robot == 'O'){
 				num = abs(P - loca_o) - result + com_o;
 				if(num < 0)	num=0;
 				result+=num + 1;
 				loca_o = P;
 				com_o = result;
 			}
 			else if(robot == 'B'){
 				num = abs(P - loca_b) - result + com_b;
 				if(num < 0)	num=0;
 				result+=num + 1;
 				loca_b = P;
 				com_b = result;
 			}
 			else{}
 		}		
 		fprintf(fw,"Case #%d: %d\n",i,result);
 	}
 	fclose(fp);
 	fclose(fw);
 	
 	return 0;
 }
 
 int get_fp_num(FILE *a)
 {
   int k=0,j=0;
   char temp[10];
   while(1){
     temp[k] = fgetc(a);	
     if(temp[k] == 10)	{
       temp[k+1]=0;
 	  return atoi(temp);
 	}	
     if(temp[k] == 32){
       temp[k+1]=0;
 	  return atoi(temp);
 	}
     k++;
   }
 
 
 }
