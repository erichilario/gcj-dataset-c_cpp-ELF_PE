#include<stdio.h>
 int f(int *array,int m)
 {
 	int i,xor=0;
 	for(i=0;i<m;i++)
 	{
 		xor=xor ^ array[i];
 	}
 	if(xor)
 	{
 		return -1;
 	}
 	else
 	{
 		int min=array[0];
 		int sum=array[0];
 		for(i=1;i<m;i++)
 		{
 			sum=sum+array[i];
 			if(min>array[i])
 			min=array[i];
 		}
 		return (sum-min);
 	}
 }
 void main()
 {
 	int n,i,j,m,*array,ans;
 	scanf("%d",&n);
 	for(i=0;i<n;i++)
 	{
 		scanf("%d",&m);
 		array=(int *) malloc(m*sizeof(int));
 		for(j=0;j<m;j++)
 		scanf("%d",&array[j]);
 		ans=f(array,m);
 		if(ans==-1)
 		{
 			printf("Case #%d: NO\n",i+1);
 		}
 		else
 			printf("Case #%d: %d\n",i+1,ans);
 	}
 }

