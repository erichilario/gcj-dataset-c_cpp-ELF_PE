#include <stdlib.h>
 #include <stdio.h>
 
 #define absminus(a, b)  ((a) > (b) ? ((a) - (b)) : ((b) - (a)))
 
 struct step
 {
 	char robot;
 	int pos;
 };
 
 struct step steps[105];
 int steps_num, steps_idx;
 
 struct step osteps[105], bsteps[105];
 int o_num, b_num, o_idx, b_idx;
 
 int time;
 int o_pos, b_pos;
 
 int main(int argc, char **argv)
 {
 	int o_time, b_time;
 
 	freopen("input", "r", stdin);
 	int t,n;
 	int id = 0;
 	char tmpc;
 	int pos;
 	char robot;
 	scanf("%d", &t);
 	printf("T: %d\n", t);
 	while(t--){
 		++id;
 		scanf("%d", &n);
 		scanf("%c", &tmpc);
 		steps_num = 0;
 		o_num = b_num = 0;
 		while(n--){
 			scanf("%c %d", &robot, &pos);
 			scanf("%c", &tmpc);
 			steps[steps_num].robot = robot;
 			steps[steps_num].pos = pos;
 			if(robot == 'O'){
 				osteps[o_num] = steps[steps_num];
 				++o_num;
 			}else{
 				bsteps[b_num] = steps[steps_num];
 				++b_num;
 			}
 			++steps_num;
 		}
 
 		time = 0;
 		o_idx = b_idx = 0;
 		steps_idx = 0;
 		o_pos = b_pos = 1;
 		while(steps_idx < steps_num){
 			if(steps_idx == steps_num - 1){
 				if(steps[steps_idx].robot == 'O'){
 					time += absminus(steps[steps_idx].pos
 							, o_pos);
 				}else{
 					time += absminus(steps[steps_idx].pos
 							, b_pos);
 				}
 				++time;
 				break;
 			}
 
 
 			o_time = absminus(osteps[o_idx].pos, o_pos);
 			b_time = absminus(bsteps[b_idx].pos, b_pos);
 			
 			if(steps[steps_idx].robot == 'O'){
 				++o_time;
 				if(o_time >= b_time){
 					b_pos = bsteps[b_idx].pos;
 				}else{
 					if(b_pos < bsteps[b_idx].pos){
 						b_pos += o_time;
 					}else{
 						b_pos -= o_time;
 					}
 				}
 				o_pos = osteps[o_idx].pos;
 				time += o_time;
 				++o_idx;
 			}else{
 				++b_time;
 				if(b_time >= o_time){
 					o_pos = osteps[o_idx].pos;
 				}else{
 					if(o_pos < osteps[o_idx].pos){
 						o_pos += b_time;
 					}else{
 						o_pos -= b_time;
 					}
 				}
 				b_pos = bsteps[b_idx].pos;
 				time += b_time;
 				++b_idx;
 			}
 			++steps_idx;
 		}
 		printf("Case #%d: %d\n", id, time);
 	}
 	return 0;
 }

