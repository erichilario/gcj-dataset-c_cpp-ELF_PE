#include <stdio.h>
 
 int ndc; // Numero de casos
 int casoactual; // caso actual
 
 
 char m[100][100]; // matriz
 int nde = 0; // numero de equipos
 
 // porcentajes
 double WP = 0.0, OWP = 0.0, OOWP = 0.0;
 
 double wps[100];
 double owps[100];
 double oowps[100];
 
 
 void imprimir(int caso){
 
     printf("Case #%d:\n",caso);
     // imprime resultado
     int i,j;
     for (i=0; i<nde; i++){
         double resul = (0.25 * wps[i]) + (0.50 * owps[i]) + (0.25 * oowps[i]);
         printf("%.12lf\n",resul);
     }
 }
 
 void resolver(int caso){    
     
     // LEER ENTRADA
     scanf("%d\n",&nde);    
     int i,j;
     for (i=0; i<nde; i++){
         for (j=0; j<nde; j++){
             char tmp;
             if (j==nde-1) scanf("%c\n",&m[i][j]);
             else scanf("%c",&m[i][j]);
         }
     }
     
     // RESOLVER
     // wps
     for (i=0; i<nde; i++){
     
         int juegos = 0;
         int jganados = 0;
         for (j=0; j<nde; j++){
         
             if (m[i][j] != '.' && j!=i){
             
                 juegos++;
                 if (m[i][j] == '1') jganados++;
             }
         }
         if (juegos > 0) wps[i] = (double)jganados/(double)juegos;
         else wps[i] = 0.0;
     }
     
     //owps
     int e, a;    
     // para cada equipo
     for (e=0; e<nde; e++){
     
         double total = 0.0;
         double equipos = 0.0;
         
         // reviso el porcentaje de cada equipo adversario "after first throwing 
         // out the games they played against you" <- WTF???
         for (a=0; a<nde; a++){
             
             // yo no soy mi adversario
             if (e != a && m[a][e] != '.'){
                 
                 int juegos = 0;
                 int jganados = 0;
                 for (i=0; i<nde ;i++) {
                     if (m[a][i] != '.' && i != e){
                         juegos++;
                         if (m[a][i] == '1') jganados++;
                     }
                 }
                 total += (double)jganados/(double)juegos;
                 equipos += 1;
             } 
         }
         if (equipos > 0) owps[e] = total/(equipos);
         else owps[e] = 0.0;
     }   
     
     // oowps
     // para cada equipo
     for (e=0; e<nde; e++){
     
         double total = 0.0;
         double equipos = 0.0;
         
         
         // reviso el owp de los demas equipos
         for (i=0; i<nde; i++){
             // suma todos menos el mio
             if (i!=e && m[i][e] != '.') {
                 total += owps[i];
                 equipos += 1.0;
             }
         }
         
         oowps[e] = total/(double)(equipos);
     }
     
     
     // IMPRIMIR
     imprimir(caso+1);
 }
 
 int main(){
 
     scanf("%d\n",&ndc);
     //printf("El numero de casos es: %d\n",ndc);
     for (casoactual = 0; casoactual<ndc; casoactual++){
     
         resolver(casoactual);
     }
 }

