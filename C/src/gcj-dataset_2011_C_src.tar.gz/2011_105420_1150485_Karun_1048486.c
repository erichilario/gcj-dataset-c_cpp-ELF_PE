
 #include <stdio.h>
 
 #ifdef DEBUG
 #define dprintf(...) printf(__VA_ARGS__)
 #else
 #define dprintf(...)
 #endif
 
 char A[100][100];
 double OWP[100];
 
 int N;
 
 double wp(int k){
 	int i;
 	double games_played=0, games_won=0;
 
 	for (i=0;i<N; i++){
 		if (A[k][i]!='.'){
 			games_played++;
 			if (A[k][i]=='1'){
 				games_won++;
 			}
 		}
 	}
 	return (games_won/games_played);
 }
 
 double owpx(k, j){
 	int i;
 	double games_played=0, games_won=0;
 
 	for (i=0;i<N; i++){
 		if( i==j){
 			continue;
 		}
 		if (A[k][i]!='.'){
 			games_played++;
 			if (A[k][i]=='1'){
 				games_won++;
 			}
 		}
 	}
 	return (games_won/games_played);
 }
 
 double owp(int k){
 	int i;
 	double n_opp=0, o_wp=0;
 
 	for (i=0; i<N; i++){
 		if (A[k][i]!='.'){
 			o_wp += owpx(i, k);
 			n_opp++;
 		}
 	}
 	return (o_wp/n_opp);
 }
 
 double oowp(int k){
 	int i;
 	double n_opp=0, o_wp=0;
 
 	for (i=0; i<N; i++){
 		if (A[k][i]!='.'){
 			o_wp += OWP[i];
 			n_opp ++;
 		}
 	}
 	return (o_wp/n_opp);
 }
 
 int main() {
 	int T, i, j;
 	if (freopen("./A-small.in", "r", stdin) == NULL){
 		printf("Could not open File\n");
 		return 0;
 	}
 
     scanf("%d", &T);
     dprintf("%d\n", T);
 
     for (i = 1; i <= T; i++) {
 		printf("Case #%d:\n",i);
 		memset(A, 0, sizeof(A));
 		memset(OWP, 0, sizeof(OWP));
 
 		scanf("%d", &N);
 		dprintf("%d", N);
 		for (j=0; j<N; j++){
 			scanf("%s", A[j]);
 
 		}
 
 		for (j=0; j<N; j++){
 			OWP[j]=owp(j);
 		}
 
 		for (j=0; j<N; j++){
 			printf("%1.12lf\n", 0.25*wp(j) + 0.5*OWP[j] + 0.25*oowp(j));
 		}
 
 	}
 }

