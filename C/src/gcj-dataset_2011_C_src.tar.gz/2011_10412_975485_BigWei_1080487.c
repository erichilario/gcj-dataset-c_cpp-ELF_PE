#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 int n,N;
 int ok(int index);
 int done[300];
 int main(){
 	int i,j,k;
 	int blue[200][2];
 	int orange[200][2];	
 	char color[3];
 	int where;
 	int O_count;
 	int B_count;
 	int finished;
 	int B_done;
 	int O_done;
 	int cur_B;
 	int cur_O;
 	int times;
 	scanf("%d ",&n);
 	for(i=0;i<n;i++){	
 		times=0;
 		O_count=B_count=0;
 		cur_B=cur_O=1;
 		B_done = O_done=0;
 		memset(orange,0,sizeof(orange));
 		memset(blue,0,sizeof(blue));
 		memset(done,0,sizeof(done));
 		scanf("%d",&N);	
 		finished = N;
 		for(j=0;j<N;j++){
 			scanf("%s %d",color,&where);
 			if(color[0]=='O'){
 				orange[O_count][0]=where;
 				orange[O_count++][1]=j;
 			}
 			else{
 				blue[B_count][0]=where;
 				blue[B_count++][1]=j;
 			}
 		}
 		blue[B_count][1] = orange[O_count][1] = -1;
 		blue[B_count][0] = orange[O_count][0]=-1;
 		int B_move=1;
 		int O_move=1;
 		while(finished>0){
 			O_move=B_move=0;
 			if(cur_B == blue[B_done][0] && ok(blue[B_done][1])&& cur_O == orange[O_done][0]&& ok(orange[O_done][1]) ){
 				printf("@@@");	
 			if(blue[B_done][1] < orange[O_done][1]){
 					done[blue[B_done][1]]=1;
 					B_done++;
 					finished--;
 					B_move=1;
 				}else{
 					done[orange[O_done][1]]=1;
 					O_done++;
 					finished--;
 					O_move=1;
 				}
 			}
 
 			else if(cur_B == blue[B_done][0] && ok(blue[B_done][1])){
 				finished--;
 				done[blue[B_done][1]]=1;
 				B_done++;
 				B_move=1;
 			}
 			else if(cur_O == orange[O_done][0]  && ok(orange[O_done][1])){
 				finished--;
 				done[orange[O_done][1]]=1;
 				O_done++;
 				O_move=1;
 			}
 
 			if(O_move==0){
 				if(cur_O > orange[O_done][0])
 					cur_O--;
 				else if(cur_O < orange[O_done][0]) 
 					cur_O++;	
 			}
 			if(B_move==0){
 				if(cur_B > blue[B_done][0])
 					cur_B--;
 				else if(cur_B < blue[B_done][0]) 
 					cur_B++;	
 			}
 			times++;
 			
 		}
 		printf("Case #%d: %d\n",i+1,times);
 
 	}
 }
 int ok(int index){
 	int i;
 	if(index==-1)return 0;
 	for(i=0; i<index;i++){
 		if(done[i]==0)
 			return 0;
 	}
 
 	return 1;
 }

