#include<stdio.h>
 FILE *in,*out;
 char table[100][100];
 void solve();
 float calc_owp(int,int);
 int main()
 {
     int T,t;
     in=fopen("input_1.txt","r");
     out=fopen("output_1.txt","w");
     fscanf(in,"%d",&T);
     for(t=1;t<=T;t++)
     {
 	fprintf(out,"Case #%d:\n",t);
 	solve();
     }
     return 0;
 }
 void solve()
 {
      int N,i;
      int j,count_1=0,count_0=0,count;
      double wp[100],owp[100],oowp[100],temp,RPI;
      fscanf(in,"%d",&N);
      for(i=0;i<N;i++)
       {
        fscanf(in,"%s",table[i]);
        count_1=0,count_0=0;
        for(j=0;j<N;j++)
        {
          if(table[i][j]=='1') count_1++;
          else if(table[i][j]=='0') count_0++;      
        }
        wp[i]=(float)count_1/(count_1+count_0);
       } 
      for(i=0;i<N;i++)
         owp[i]=calc_owp(i,N);
      for(i=0;i<N;i++)
       {
         temp=0; 
         count=0;
         for(j=0;j<N;j++)
          {
            if(table[i][j]=='.') continue;
            temp+=owp[j];
            count++;
          } 
          oowp[i]=temp/count;
       }  
     for(i=0;i<N;i++)
      {
        RPI = (0.25 * wp[i]) + (0.50 * owp[i])+ (0.25 * oowp[i]);
        fprintf(out,"%f\n",RPI);        
      }
 }
 float calc_owp(int i,int n)
 {
       int j,k,count_1=0,count_0=0,count=0;
       float wp=0;
         if(i==3)
           count_0=0,count_1=0; 
       for(j=0;j<n;j++)
        {
         count_0=0,count_1=0;
         if(j==i || table[j][i]=='.') continue;
         for(k=0;k<n;k++)
         {
           if(k==i || table[j][k]=='.') continue;
           if(table[j][k]=='1') count_1++;
           else if(table[j][k]=='0') count_0++;
         }
         count++;
         wp+=(float)count_1/(count_0+count_1);
        } 
      return(wp/count);
 }

