#include <stdio.h>
 #include <stdlib.h>
 char sche[102][102];
 double wp[100], owp[100], oowp[100], rpi[100];
 int cwin[100], ctotal[100];
 int main()
 {
 	int t, tind;
 	int n;
 	int i, j, k;
 	//int cwin, ctotal;
 	scanf("%d", &t);
 	for(tind = 1; tind <= t; tind++) {
 		scanf("%d", &n);
 		for(i = 0; i < n; i++) {
 			scanf("%s", sche[i]);
 		}
 		for(i = 0; i < n; i++) {
 			cwin[i] = ctotal[i] = 0;
 			for(j = 0; j < n; j++) {
 				if(sche[i][j] == '1') {
 					cwin[i]++, ctotal[i]++;
 				}
 				else if(sche[i][j] == '0') {
 					ctotal[i]++;
 				}
 			}
 			wp[i] = (double)cwin[i]/ctotal[i];
 		}
 
 		for(i = 0; i < n; i++) {
 			owp[i] = 0.0; 
 			for(j = 0; j < n; j++) {
 				if(sche[i][j] == '1' || sche[i][j] == '0') {
 					int temp = ((sche[i][j] == '0') ? 1:0) ;
 					owp[i] += (double )(cwin[j] - temp) / (ctotal[j] - 1);
 				}
 			}
 			owp[i] = (double)owp[i] / ctotal[i];
 		}
 		for(i = 0; i < n; i++) {
 			oowp[i] = 0.0; 
 			for(j = 0; j < n; j++) {
 				if(sche[i][j] == '1' || sche[i][j] == '0') {
 					//ctotal++;
 					oowp[i] += owp[j];
 				}
 			}
 			oowp[i] = (double)oowp[i] / ctotal[i];
 		}
 		for(i = 0; i < n; i++) {
 			rpi[i] = 0.25 * wp[i] + 0.5 *owp[i] + 0.25 * oowp[i];
 		}
 		printf("Case #%d:\n",tind);
 		for(i = 0; i < n; i++) {
 			printf("%.7f\n", rpi[i]);
 		}
 	}
 }

