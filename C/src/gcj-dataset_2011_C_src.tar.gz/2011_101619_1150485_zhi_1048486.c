#include <stdio.h>
 int main()
 {
 	int i,j,k,l,q,r,T,N;
 	char m[100][101];
 	double p,WP[100],OWP[100],OOWP[100];
 	scanf("%d",&T);
 	for(i=0;i<T;i++)
 	{
 		scanf("%d",&N);
 		for(j=0;j<N;j++)
 			scanf("%s",m[j]);
 
 		// WP
 		for(j=0;j<N;j++)
 		{
 			p=0.0;
 			q=0;
 			for(k=0;k<N;k++)
 				if(m[j][k]!='.')
 				{
 					q++;
 					if(m[j][k]=='1')
 						p++;
 				}
 			WP[j]=p/q;
 		}
 
 		// OWP
 		for(j=0;j<N;j++)
 		{
 			OWP[j]=0;
 			r=0;
 			for(k=0;k<N;k++)
 			{
 				if(m[j][k]!='.')
 				{
 					r++;
 					p=0.0;
 					q=0;
 					for(l=0;l<N;l++)
 						if(j!=l&&m[k][l]!='.')
 						{
 							q++;
 							if(m[k][l]=='1')
 								p++;
 						}
 					OWP[j]+=p/q;
 				}
 			}
 			OWP[j]/=r;
 		}
 
 		// OOWP
 		for(j=0;j<N;j++)
 		{
 			p=0.0;
 			q=0;
 			for(k=0;k<N;k++)
 				if(m[j][k]!='.')
 				{
 					p+=OWP[k];
 					q++;
 				}
 			OOWP[j]=p/q;
 		}
 
 		printf("Case #%d:\n",i+1);
 		for(j=0;j<N;j++)
 			printf("%.12lf\n",0.25*WP[j]+0.50*OWP[j]+0.25*OOWP[j]);
 	}
 	return 0;
 }

