#include<stdio.h>
 
 #define BOOL int
 #define FALSE 0
 #define TRUE 1
 
 #define MAX_TEAMS 100
 
 
 
 int
 main(void)
 {
   int T, iT;
   int N, rN, cN;
   double teams_played[MAX_TEAMS];
   double WP[MAX_TEAMS];
   double OWP[MAX_TEAMS];
   double OOWP[MAX_TEAMS];
   double OWP_increment;
 
   char matrix[MAX_TEAMS][MAX_TEAMS];
 
   scanf("%d", &T);
   for(iT = 1; iT <= T; ++iT) {
     printf("Case #%d:\n", iT);
 
     scanf("%d", &N);
 
     // read matrix
     for(rN = 1; rN <= N; ++rN) {
       for(cN = 1; cN <= N; ++cN) {
         scanf(" %c", &(matrix[rN][cN]));
       }
     }
 
     for(rN = 1; rN <= N; ++rN) {
 
       // fill teams_played array
       teams_played[rN] = 0;
       for(cN = 1; cN <= N; ++cN) {
         if('.' != matrix[rN][cN]) {
           ++(teams_played[rN]);
         }
       }
 
       // fill WP array
       WP[rN] = 0.0;
       for(cN = 1; cN <= N; ++cN) {
         if('1' == matrix[rN][cN]) {
           ++(WP[rN]);
         }
       }
       WP[rN] /= teams_played[rN];
     }
 
     for(rN = 1; rN <= N; ++rN) {
 
       // fill OWP array
       OWP[rN] = 0.0;
       for(cN = 1; cN <= N; ++cN) {
         if('.' != matrix[rN][cN]) {
           OWP_increment = WP[cN];
           if('0' == matrix[rN][cN]) { // cN beat rN, so effect OWP_increment's numerator
             OWP_increment -= (1/teams_played[cN]); // throw out games cN played against rN
           }
           OWP_increment *= teams_played[cN]; // fix OWP_increment's ...
           OWP_increment /= (teams_played[cN]-1); // ... denominator
 
           OWP[rN] += OWP_increment;
         }
       }
       OWP[rN] /= teams_played[rN];
     }
 
     for(rN = 1; rN <= N; ++rN) {
 
       // fill OOWP array
       OOWP[rN] = 0.0;
       for(cN = 1; cN <= N; ++cN) {
         if('.' != matrix[rN][cN]) {
           OOWP[rN] += OWP[cN];
         }
       }
       OOWP[rN] /= teams_played[rN];
 
     }
 
     // print RPIs
     for(cN = 1; cN <= N; ++cN) {
       printf("%lf\n", 0.25*WP[cN] + 0.50*OWP[cN] + 0.25*OOWP[cN]);
     }
   }
 
   return(0);
 }

