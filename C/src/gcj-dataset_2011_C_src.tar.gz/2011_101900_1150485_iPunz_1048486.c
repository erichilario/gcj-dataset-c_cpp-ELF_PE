#include <stdio.h>
 
 
 
 int main(void){
 int i;
 int j;
 int T;
 scanf("%d ", &T);
 i=0;
 int N;
 int k=0;
 j=0;
 char x;
 int num=0;
 int count=0;
 double WP[100][100];
 char value[100][100];
 double OWP[100];
 double OOWP[100];
 while(i<T){
     scanf("%d ", &N);
         printf("Case #%d:\n", i+1);
         j=0;
         while(j<N){
             
             k=0;
             count=0;
             num=0;
             int cur=0;
             while(k<N){
                 scanf("%c ", &x);
                 value[j][cur++]=x;
                 if(x=='1'){
                     count++;
                     num++;
                 }
                 else if(x=='0')
                     num++;    
             k++;
             }
             int l=0;
             while(l<N){
                 if(value[j][l]=='0'){
                     WP[j][l]=(1.0*count)/(num-1);
                 }
                 else if(value[j][l]=='1'){
                     WP[j][l]=(1.0*(count-1))/(num-1);
                 }
                 else
                     WP[j][l]=(1.0*count)/num;
                 //printf("WP: %.2lf ", WP[j][l]);
             l++;
             }
         j++;
         }
             //printf("\n");
             j=0;
             while(j<N){
             int l;
             l=0;
             double countWB=0;
             int numWB=0;
             while(l<N){
                 if(value[j][l]=='1'|| value[j][l]=='0'){
                     countWB+=WP[l][j];
                     //printf("%.2lf , %d, %d ", WP[l][j], l , j);
                     numWB++;
                 }
             l++;
             }
 
             OWP[j]=countWB/numWB;
             //printf("%.2f \n", OWP[j]);
             //printf("\n");
             //printf("n: %d\n", num);
        j++;
        }
        j=0;
        while(j<N){
        int l=0;
        double countOWP=0;
        int numOWP=0;
             while(l<N){
                 if(value[j][l]=='1'||value[j][l]=='0'){
                     countOWP+=OWP[l];
                     numOWP++;
                 }
             l++;    
             }
             OOWP[j]=(countOWP/numOWP);
             //printf("%.2f", countOWP/numOWP);
             //printf("%d has RPI=(0.25*%.2f) + (0.5 * %.2f) + (0.25 *%.2f)=%.7f",
             //    j, WP[j][j], OWP[j], OOWP[j],
             printf("%.12f\n",    ((0.25*WP[j][j])+(0.5*OWP[j])+(0.25*OOWP[j])));
        j++;
        }
     i++;    
 
 }
 
 
 
 }

