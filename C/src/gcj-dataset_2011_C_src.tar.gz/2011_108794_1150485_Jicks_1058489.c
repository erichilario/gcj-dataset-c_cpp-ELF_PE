#include <stdlib.h>
 #include <stdio.h>
 
 int pos[200];
 int vend[200];
 
 void run(int c, int d)
 {
 	int new_pos = pos[0];
 	int my_case = 0;
 	int new_worker = 0;
 	float t = 0;
 	while (my_case < c)
 	{
 		t += d * (vend[my_case]-1);
 		new_pos += d * (vend[my_case]-1);
 		new_worker = 0;
 		while (my_case < c && pos[my_case] < new_pos)
 			new_worker += vend[my_case++];
 		if (my_case == c)
 			t += d * (new_worker-1);
 		else
 			vend[++my_case] += new_worker+1;
 	}
 	printf("%f\n", t/4);
 }
 
 int main(void)
 {
 	int warn = 0;
 	int t = 0;
 
 	warn = scanf("%d\n", &t);
 	for (int i = 0; i < t; i++)
 	{
 		int c, d;
 		warn = scanf("%d %d\n",&c, &d);
 		for (int j = 0; j < c; j++)
 			warn = scanf("%d %d\n", &pos[j], &vend[j]);
 		printf("Case #%d: ", i+1);
 		run(c, d);
 	}
 	return (0);
 }
 

