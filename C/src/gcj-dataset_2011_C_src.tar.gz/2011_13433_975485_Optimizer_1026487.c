#include <stdio.h>
 
 char combine[128][128];
 int oppose[128][128];
 
 void main() {
     int ntests, c, d, n;
     char c1, c2, c3;
     int i, j, k;
     char res[100];
     int nres = 0;
 
     scanf("%d", &ntests);
     for (k = 0; k < ntests; k++) {
         nres = 0;
         for (j = 0; j < 128; j++) for (i = 0; i < 128; i++) {
             combine[j][i] = 0; oppose[j][i] = 0;
         }
         scanf("%d", &c);
         scanf("%c", &c1);
         if (c > 0) {
             for (i = 0; i < c; i++) {
                 scanf("%c%c%c", &c1, &c2, &c3);
                 combine[c1][c2] = c3; combine[c2][c1] = c3;
                 scanf("%c", &c1);
             }
         }
         scanf("%d", &d);
         scanf("%c", &c1);
         if (d > 0) {
             for (i = 0; i < d; i++) {
                 scanf("%c%c", &c1, &c2);
                 oppose[c1][c2] = 1; oppose[c2][c1] = 1;
                 scanf("%c", &c1);
             }
         }
         scanf("%d", &n);
         scanf("%c", &c1);
         for (i = 0; i < n; i++) {
             scanf("%c", &c1);
             if (nres > 0) {
                 if (combine[res[nres-1]][c1] != 0) {
                     res[nres-1] = combine[res[nres-1]][c1]; continue;
                 }
                 for (j = 0; j < nres; j++) if (oppose[res[j]][c1]) break;
                 if (j < nres) {
                     nres = 0; continue;
                 }
             }
             res[nres++] = c1;
         }
         printf("Case #%d: [", k+1);
         for (i = 0; i < nres; i++) {
             if (i != nres-1) printf("%c, ", res[i]);
             else printf("%c", res[i]);
         }
         printf("]\n");
     }
     getchar();
     getchar();
     return;
 }

