#include <stdio.h>
 
 int main(){
   double wp[100],owp[100],oowp[100];
   int t,ti,n,i,j;
   int m[100][100];
   char c;
   int k1[100],k2[100],k3;
   scanf("%d",&t);
   
   for(ti=1;ti<=t;ti++){
     printf("Case #%d:\n",ti);
     scanf("%d",&n);
     for (i=0;i<n;i++){
       wp[i]=0;owp[i]=0;oowp[i]=0;
     }
 
     for (i=0;i<n;i++){
       scanf("%c",&c);
       for (j=0;j<n;j++){
 	scanf("%c",&c);
 	if (c=='1') m[i][j]=1;
 	if (c=='0') m[i][j]=0;
 	if (c=='.') m[i][j]=-1;
       }
       
     }
 
     for (i=0;i<n;i++){
       k1[i]=0;k2[i]=0;
       for (j=0;j<n;j++){
 	if (m[i][j]==1) k1[i]++;
 	if (m[i][j]==0) k2[i]++;
       }
       wp[i]=1.0*k1[i]/(k1[i]+k2[i]);
     }
 
     for (i=0;i<n;i++){
       for (j=0;j<n;j++)
 	if(m[i][j]!=-1)
 	  owp[i]+=(wp[j]*(k1[j]+k2[j])-m[j][i])/(k1[j]+k2[j]-1);
       owp[i]/=k1[i]+k2[i];
     }
 
     for (i=0;i<n;i++){
       for(j=0;j<n;j++)
 	if(m[i][j]!=-1)
 	  oowp[i]+=owp[j];
       oowp[i]/=k1[i]+k2[i];
     }
     for (i=0;i<n;i++)
       printf("%.12f\n",0.25*wp[i]+0.5*owp[i]+0.25*oowp[i]);
   }
   return 0;
 }

