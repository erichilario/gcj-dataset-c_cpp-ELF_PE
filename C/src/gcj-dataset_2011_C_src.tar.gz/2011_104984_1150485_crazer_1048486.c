#include <stdio.h>
 
 int main(){
 	int T, N;
 	int i, j, k;
 	int schedule[100][100];
 	char c;
 	double winP[100];
 	double OWP[100];
 	double OOWP[100];
 	int gamesAccount[100][2];
 	int totalWins, totalGames, totalOpponents;
 	double tempWP;
 	double tempTotalWP;
 	double tempTotalOWP;
 	double RPI;
 	
 	scanf("%d", &T);
 	
 	
 	for(i = 0; i < T; i++){
 		scanf("%d", &N);
 		
 		for(j = 0; j < N; j++){
 			c = getchar();
 			for(k = 0; k < N; k++){
 				c = getchar();
 				if(c == '.'){
 					schedule[j][k] = -1;
 				}
 				else if(c == '1'){
 					schedule[j][k] = 1;
 				}
 				else if(c == '0'){
 					schedule[j][k] = 0;
 				}
 			}
 		}
 		
 		/*
 		for(j = 0; j < N; j++){
 			for(k = 0; k < N; k++){
 				printf("%d\t", schedule[j][k]);
 			}
 			printf("\n");
 		}
 		printf("\n");
 		*/
 		
 		for(j = 0; j < N; j++){
 			totalWins = 0;
 			totalGames = 0;
 			for(k =0; k < N; k++){
 				if(schedule[j][k] == 1){
 					totalWins++;
 					totalGames++;
 				}
 				else if(schedule[j][k] == 0){
 					totalGames++;
 				}
 			}
 			winP[j] = (double)totalWins / (double)totalGames;
 			gamesAccount[j][0] = totalWins;
 			gamesAccount[j][1] = totalGames;
 		}
 		
 		for(j = 0; j < N; j++){
 			tempTotalWP = 0;
 			totalOpponents = 0;
 			for(k =0; k < N; k++){
 				if(schedule[j][k] == 1){
 					tempWP = (double)gamesAccount[k][0] / (double)(gamesAccount[k][1] - 1);
 					tempTotalWP = tempTotalWP + tempWP;
 					totalOpponents++;
 				}
 				else if(schedule[j][k] == 0){
 					tempWP = (double)(gamesAccount[k][0] - 1) / (double)(gamesAccount[k][1] - 1);
 					tempTotalWP = tempTotalWP + tempWP;
 					totalOpponents++;
 				}
 				else
 					tempWP = winP[k];
 			}
 			OWP[j] = tempTotalWP / (double)totalOpponents;
 		}
 		
 		for(j = 0; j < N; j++){
 			tempTotalOWP = 0;
 			totalOpponents = 0;
 			for(k =0; k < N; k++){
 				if(schedule[j][k] != -1){
 					tempTotalOWP = tempTotalOWP + OWP[k];
 					totalOpponents++;
 				}
 			}
 			OOWP[j] = tempTotalOWP / (double)totalOpponents;
 		}
 		
 		printf("Case #%d:\n", i + 1);
 		for(j = 0; j < N; j++){
 			RPI = 0.25 * winP[j] + 0.50 * OWP[j] + 0.25 * OOWP[j];
 			printf("%.12f\n", RPI);
 		}
 	}
 	
 	return 0;
 }
