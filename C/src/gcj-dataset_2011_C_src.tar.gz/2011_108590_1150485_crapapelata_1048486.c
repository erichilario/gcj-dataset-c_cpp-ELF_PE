#include <stdio.h>
 
 #define MAX_QUEUE 100
 
 #define MAX_N 100
 
 #define MIN(a,b) ((a)<=(b)?(a):(b))
 
 typedef unsigned long ulong; 
 
 
 int main(int argc,char **argv)
 {
   int T; /* # test cases */
   int N; /* # of teams */
   int n;
   int t;
 
   FILE *fpin; 
   FILE *fpout; 
 
 
   char S[MAX_N][MAX_N];
 
 
   double RPI;
   int wins[MAX_N];
   int loss[MAX_N];
   double WP[MAX_N];
   double OWP[MAX_N];
   double OOWP[MAX_N];
 
   int i,win,lose,tot;
 
 
   int retval=0;
 
 
   if (argc!=2){
     fprintf(stderr,"Please provide input file name on command line.\n");
     retval=1;
     goto end;
   }
 
 
   fpin = fopen(argv[1],"r");
   if (!fpin){
     fprintf(stderr,"input file not found\n");
     return 1;
   }
   fpout = fopen("outcome","w");
 
 
   /* read 'T' */
   if (fscanf(fpin,"%d",&T)!=1){
     fprintf(stderr,"[T] input file format wrong\n");
     retval=1;
     goto end;
   }
 
 
   for (t=1;t<=T;t++){
 
 
     /* read 'N' */
     if (fscanf(fpin,"%d",&N)!=1){
       fprintf(stderr,"[N] input file format wrong\n");
       retval=1;
       goto end;
     }
 
     for (n=1;n<=N;n++){
       wins[n-1]=loss[n-1]=0;
       for (i=0;i<N;i++){
         if (fscanf(fpin," %c",&S[n-1][i])!=1){
           fprintf(stderr,"[S[][]] input file format wrong\n");
           retval=1;
           goto end;
         }
         printf("%c",S[n-1][i]);
 
         switch(S[n-1][i]){
 	  case '.': 
             break;
           case '1': 
             ++wins[n-1];
             break;
           case '0': 
             ++loss[n-1];
             break;
         }
 
       }
 
       WP[n-1] = (double)wins[n-1] / (wins[n-1]+loss[n-1]); 
 
       printf("\n");
       printf("WP[%d]=%0.12f\n",n-1,WP[n-1]);
     }
 
         printf("------------\n");
 
     for (i=1;i<=N;i++){
       OWP[i-1]=0;
       tot=0; 
       for (n=1;n<=N;n++){
         printf("%c",S[n-1][i-1]);
         if (n!=i){
           switch (S[n-1][i-1]){
             case '.': 
               break;
             case '1':
               OWP[i-1] += (double)(wins[n-1]-1) / (wins[n-1]+loss[n-1]-1);
               ++tot;
               break;
             case '0':
               OWP[i-1] += (double)wins[n-1] / (wins[n-1]+loss[n-1]-1);
               ++tot;
               break;
           }
         }
       }
 
       printf("\n");
 
       OWP[i-1]/=tot;
 
       printf("OWP[%d]=%0.12f\n",i-1,OWP[i-1]);
     }
 
 
     for (i=1;i<=N;i++){
       OOWP[i-1]=0; 
       tot=0;
       printf("(");
 
       for (n=1;n<=N;n++){
         if (n!=i){
           if (S[n-1][i-1]!='.'){
             printf("%0.12f + ",OWP[n-1]);
             OOWP[i-1]+=OWP[n-1];
             ++tot;
           }
         }
       }
       printf(") / %d\n",tot);
       OOWP[i-1]/=tot;
       printf("OOWP[%d]=%0.12f\n",i-1,OOWP[i-1]);
     }
 
 
 
  //   printf("[debug] N=%d   1<<N:%d %lu %d %s\n",N,K,1<<N,K % (1<<N),(1<<N) - 1,((ulong)(K % (1<<N))==(ulong)((1<<N) - 1) ? "S" : "N"));
 
     fprintf(fpout,"Case #%d:\n",t);
     fprintf(stdout,"Case #%d:\n",t);
  
     for (n=1;n<=N;n++){
 
       RPI = 0.25 * WP[n-1] + 0.50 * OWP[n-1] + 0.25 * OOWP[n-1];
       fprintf(fpout,"%0.12f\n",RPI);
       fprintf(stdout,"%0.12f\n",RPI);
       
     }
   } /* for t */
 
 
 end:
   fclose(fpout);
   fclose(fpin);
 
   return retval;
 }

