#include<stdio.h>
 void main(){
 	int T,N,i,j,k;
 	char store[100][100];
 	int win[100];
 	int lose[100];
 	double owp[100];
 	double ans[100];
 	scanf("%d",&T);
 	for(i=0;i<T;i++){
 		scanf("%d",&N);
 		for(j=0;j<100;j++){
 			win[j]=0;
 			lose[j]=0;
 			owp[j]=0;
 			ans[j]=0;
 		}
 		for(j=0;j<N;j++){
 			scanf("%s",store[j]);
 		}
 		printf("Case #%d:\n",i+1);
 		for(j=0;j<N;j++){
 			for(k=0;k<N;k++){
 				if(store[j][k]=='.'){
 					continue;
 				}
 				else if(store[j][k]=='1'){
 					win[j]++;
 				}
 				else if(store[j][k]=='0'){
 					lose[j]++;
 				}
 			}
 		}
 		for(j=0;j<N;j++){
 			for(k=0;k<N;k++){
 				if(store[k][j]=='.'){
 					continue;
 				}
 				else if(store[k][j]=='1'){
 					owp[j]+=(double)(win[k]-1.0)/(win[k]+lose[k]-1.0)/(win[j]+lose[j]);
 				}
 				else if(store[k][j]=='0'){
 					owp[j]+=(double)(win[k])/(win[k]+lose[k]-1.0)/(win[j]+lose[j]);
 				}
 			}
 		}
 		for(j=0;j<N;j++){
 			for(k=0;k<N;k++){
 				if(store[j][k]=='.'){
 					continue;
 				}
 				else{
 					ans[j]+=(double)0.25*owp[k]/(win[j]+lose[j]);
 				}
 			}
 			ans[j]+=owp[j]*0.5+0.25*win[j]/(win[j]+lose[j]);
 			printf("%.12lf\n",ans[j]);
 		}
 		
 	}
 }
 

