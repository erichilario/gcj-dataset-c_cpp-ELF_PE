/** @file 	CandySplitting.c
  *  @brief      Google Code Jam Problem C
  *  @author     keroserene
  */
 #include <stdlib.h>
 #include <stdio.h>
 #include <malloc.h>
 
 #define max(a,b) ((a) > (b) ? a : b)
 
 typedef struct candyset {
 	int s1, s2;
 	int p1, p2;
 
 	struct candyset * next;
 } candyset;
 
 
 FILE * f = NULL;
 
 int solve() {
 	int N, i;
 	int c1, c2;
 	int val = -1;
 	candyset * list = NULL;
 	candyset * temp = NULL;
 	candyset * next = NULL;
 
 	fscanf(f, "%d\n", &N);
 	fscanf(f, "%d %d ", &c1, &c2); 	/* base */
 
 	list = malloc(sizeof(candyset));
 	list->s1 = c1;
 	list->s2 = c2;
 	list->p1 = c1;
 	list->p2 = c2;
 
 	for ( i = 2 ; i < N ; i++ ) {
 		int c;
 		fscanf(f, "%d ", &c);	/* Parse */
 
 		temp = list;
 		while (temp) {	/* Check entire list */
 			next = temp->next;
 
                         candyset * n = malloc(sizeof(candyset));	/* Split set */
 //			printf("SPLIT %d, %d, %d, %d by %d\n", temp->s1, temp->s2, temp->p1, temp->p2, c);
 			n->s1 = temp->s1;
 			n->s2 = temp->s2 + c;
 			n->p1 = temp->p1;
 			n->p2 = temp->p2 ^ c;
  			temp->s1 += c;
 			temp->p1 ^= c;
  
 //			printf("-> %d, %d, %d, %d\n", temp->s1, temp->s2, temp->p1, temp->p2);
 //			printf("-> %d, %d, %d, %d\n", n->s1, n->s2, n->p1, n->p2);
 
 			n->next = next;			/* linked list insert */
 			temp->next = n;
 			temp = next;
 		}
 	}
 
 	/* Find max and free list at same time */
 	temp = list;
 	while (temp) {
 		next = temp->next;
 		if (temp->p1 == temp->p2) {
 			int sean = max(temp->s1, temp->s2);
 			if (sean > val)
 				val = sean;
 		}
                 free(temp);
 		temp = next;
 	}
 
 	fscanf(f, "\n");
 	return val;
 }
 
 
 int main ( int argc, char ** argv ) {
 	int T, Ti;
 	if (argc < 2)
 		return -1;
 
 	const char * file = argv[1];
 	f = fopen(file, "r");
 	
 	fscanf(f, "%d\n", &T);				/* Parse and loop */
 	for ( Ti = 1 ; Ti <= T ; Ti++ ) {
 		int val = solve();
 		if (val == -1)
 			printf("Case #%d: NO\n", Ti);
 		else
 			printf("Case #%d: %d\n", Ti, val);
 	}
 
 	fclose(f);
 	return 0;	
 }

