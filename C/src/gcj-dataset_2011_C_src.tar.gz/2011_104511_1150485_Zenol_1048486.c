#include <iostream>
 
 #define WI	-1
 #define	LO	+1
 
 struct	dt {
 	double	wp;
 	double	wp_c;
 	double	owp;
 	double	oowp;
 	int	nb;
 	int	otable[100];
 };
 
 dt	wk[100];
 
 void	read(int n)
 {
 	for(int i = 0; i < n; i++)
 	{
 		wk[i].wp = 0;
 		wk[i].owp = 0;
 		wk[i].oowp = 0;
 		wk[i].nb = 0;
 		for(int j = 0; j < n; j++)
 		{
 			char c;
 			std::cin >> c;
 			wk[i].otable[j] = 0;
 			if (c != '.')
 			{
 				if (c == '1')
 				{
 					wk[i].wp += 1;
 					wk[i].otable[j] = WI;
 				}
 				else
 				{
 					wk[i].otable[j] = LO;
 				}
 				wk[i].nb++;
 			}
 		}
 		wk[i].wp_c = wk[i].wp;
 		wk[i].wp /= wk[i].nb;
 //		std::cout << "WP " << (char)('A' + i) << " = " << wk[i].wp << std::endl; 
 	}
 }
 
 void	owp(int n)
 {
 	double st;
 	for (int i = 0; i < n; i++)
 	{
 //		std::cout << (char)('A' + i) << ":\n";
 		for (int j = 0; j < n; j++)
 			if(wk[i].otable[j])
 			{
 				if (wk[i].otable[j] == LO)
 				{
 					st = (wk[j].wp_c - 1) / (wk[j].nb - 1);
 					wk[i].owp += st;
 				}
 				else
 				{
 					st = (wk[j].wp_c) / (wk[j].nb - 1);
 					wk[i].owp += st;
 				}
 
 //				std::cout << (char)('A' + j) << " has nb=" << wk[j].wp_c << "\n";
 //				std::cout << (char)('A' + j) << " has " << st << "\n";
 			}
 		wk[i].owp /= (wk[i].nb);
 //		std::cout << "OWP " << (char)('A' + i) << " = " << wk[i].owp << std::endl; 
 	}
 }
 
 
 void	oowp(int n)
 {
 	for (int i = 0; i < n; i++)
 	{
 //		std::cout << (char)('A' + i) << ":\n";
 		for (int j = 0; j < n; j++)
 			if(wk[i].otable[j])
 				wk[i].oowp += wk[j].owp;
 		wk[i].oowp /= (wk[i].nb);
 //		std::cout << "OOWP " << (char)('A' + i) << " = " << wk[i].oowp << std::endl; 
 	}
 }
 
 void	calc_case(int i)
 {
 	int	n;
 
 	std::cout.precision(12);
 	std::cin >> n;
 	read(n);
 	owp(n);
 	oowp(n);
 
 	std::cout << "Case #" << i + 1 << ":\n";
 	for (int i = 0; i < n; i++)
 		std::cout << 0.25 * wk[i].wp + 0.50 * wk[i].owp + 0.25 * wk[i].oowp << "\n";
 }
 
 int	main(void)
 {
 	int	t;
 
 	std::cin >> t;
 	for(int i = 0; i < t; i++)
 		calc_case(i);
 	
 	return 0;
 }

