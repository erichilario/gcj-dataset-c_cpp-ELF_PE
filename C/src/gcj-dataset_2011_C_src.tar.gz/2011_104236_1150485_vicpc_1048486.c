#include <stdio.h>
 
 typedef struct
 {
   int win, total;
 }stat;
 
 int result[100][100];
 
 stat WP[100];
 long double OWP[100];
 long double OOWP[100];
 long double RIP[100];
 
 
 int main ()
 {
   int i,j;
   int t,T;
   int N;
   int total;
   char aux;
 
   scanf("%d", &T);
   for (t=0; t<T;t++)
   {
     for (i = 0; i < 100; i++)
     {
       WP[i].total = 0;
       WP[i].win = 0;
       OWP[i] = 0;
       OOWP[i] = 0;
     }
     
     scanf("%d\n",&N);
     for (i = 0; i < N; i++)
     {
       for (j = 0; j < N; j++)
       {
         scanf ("%c", &aux);
         
         if (aux == '1')
         {
           result[i][j] = 1;
           WP[i].total++;
           WP[i].win++;
         }
         if (aux == '0')
         {
           result[i][j] = 0;
           WP[i].total++;    
         }
         if (aux == '.')
           result[i][j] = -1;
       }
       scanf(" ");
     }
 /*
     for (i = 0; i < N; i++)
     {
       for (j = 0; j < N; j++)
         printf("%d", result[i][j]);
       printf("\n");
     }
 */   
     //printf("aaa\n");
  
     for (i = 0; i < N; i++)
     {
       total=0;
       for (j = 0; j < N; j++)
       {
         //printf("%d %d %d %d/%d\n",i,j,result[i][j],WP[j].win,WP[j].total);
         if (result[i][j] != -1)
         {
           total++;
           if (result[i][j] == 1)
             OWP[i] += ((double)WP[j].win/(WP[j].total - 1));
           else
             OWP[i] += ((double)(WP[j].win-1)/(WP[j].total - 1));
         }
       }
       //printf("aaa-a\n");
       OWP[i] = OWP[i]/total;
     }
 
     //printf("bbb\n");
 
     for (i = 0; i < N; i++)
     {
       total=0;
       //printf ("====\n");
       for (j = 0; j < N; j++)
       {
         if (result[i][j] != -1)
         { 
           total++;
           //printf("%Lf %Lf\n",OOWP[i],OWP[j]);
           OOWP[i] += OWP[j];
         }
       }
       OOWP[i] = OOWP[i]/total;
     }
  
     //printf("ccc\n");
 
     printf("Case #%d:\n",t+1);
     for (i = 0; i < N; i++)
     {
       //printf("RIP = 0,25*%Lf + 0,5*%Lf + 0,25*%Lf\n", ((long double)WP[i].win/WP[i].total), (OWP[i]), (OOWP[i]));
       RIP[i] = 0.25*((long double)WP[i].win/WP[i].total) + 0.5*(OWP[i]) + 0.25*(OOWP[i]); 
       printf("%.8Lf\n",RIP[i]);
     }
 
   }
   return 0;
 }

