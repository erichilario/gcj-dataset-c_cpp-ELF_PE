#include <stdio.h>
 
 int T, caseCtr;
 
 int N;
 int playedWith[100][100];
 int wins[100], gamesPlayed[100];
 double			OW[100], OOW[100], RPIx4;
 double WP[100], OWP[100], OOWP[100];
 
 
 int main(){
 	int i, j;
 	freopen("A.in", "r", stdin);
 	freopen("output.txt", "w", stdout);
 	scanf("%d ", &T);
 	for(caseCtr=0; caseCtr<T; ++caseCtr){
 		printf("Case #%d: \n", caseCtr+1);
 		/*solve*/
 		scanf("%d ", &N);
 		for(i=0; i<N; ++i){
 			wins[i] = gamesPlayed[i] = 0;
 			
 			for(j=0; j<N; ++j){
 				char c;
 				playedWith[i][j] = 0;
 				scanf("%c", &c);
 				switch (c){
 				case '0': 
 					--wins[i];
 					++playedWith[i][j];
 				case '1':
 					++gamesPlayed[i];
 					++playedWith[i][j];
 					++wins[i];
 				case '.': break;
 				}
 				scanf(" ");
 			}
 		}
 		for(i=0; i<N; ++i)
 			WP[i] = (double)wins[i] / gamesPlayed[i];
 		for(i=0; i<N; ++i){
 			OOW[i] = OW[i] = 0;
 			for(j=0; j<N; ++j)
 				if(playedWith[i][j]) OW[i] += (double) (wins[j]- (playedWith[i][j] == 2? 1: 0) )/ (gamesPlayed[j]-1);
 		}
 		
 		for(i=0; i<N; ++i)
 			OWP[i] = OW[i] / gamesPlayed[i];
 		for(i=0; i<N; ++i){
 			for(j=0; j<N; ++j)
 				if(playedWith[i][j]) OOW[i] += OWP[j];
 		}
 
 		for(i=0; i<N; ++i){
 			OOWP[i] = OOW[i] / gamesPlayed[i];
 			RPIx4 = WP[i] + 2* OWP[i] + OOWP[i];
 			printf("%.10lf\n", RPIx4 / 4);
 		}
 		
 		/*output*/
 	}
 	return 0;
 }
