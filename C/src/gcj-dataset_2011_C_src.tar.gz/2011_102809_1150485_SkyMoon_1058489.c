#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 //./p2 <input >output
 main()
 {
 	int T;
 	int i,j,k;
 
 	scanf("%d",&T);
 	for(i=0;i<T;i++)
 	{
 		
 		int C,D,P[200],V[200],cnt=0;
 		double result=0;
 
 		scanf("%d%d",&C,&D);
 		
 		for(j=0;j<C;j++)
 		{
 			scanf("%d%d",P+j,V+j);
 			cnt+=V[j];
 
 
 			if(V[j]>1)
 			{
 				result+=(V[j]-1)*D/2.0;
 			}
 			if(j>0 && ((D-(P[j]-P[j-1]))>0))
 			{
 				result+=(V[j])*(D-(P[j]-P[j-1]))/2.0;
 			}
 		}
 
 
 		printf("Case #%d: %f\n",i+1,result);
 	}
 }
 
 /*
 double process(int P[],int V[],C,D)
 {
 	if ((P[1]-P[0])>=D)
 	{
 		return process(P+1,V+1,C-1,D);
 	}
 }
 */
 

