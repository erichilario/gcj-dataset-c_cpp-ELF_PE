#include<stdio.h>
 int f(int *array,int m)
 {
 	int i,tmp,step=0,loc1=1,loc2=1,c1=0,c2=0;
 	for(i=0;i<m;i=i+2)
 	{
 //		printf("%d %d",array[i],array[i+1]);
 		if(array[i]==-1)
 		{
 			tmp=array[i+1]-loc1;
 			if(tmp<0)
 			tmp*=-1;
 			tmp-=c1;
 			if(tmp<0)
 			tmp=0;
 			step+=tmp+1;
 			loc1=array[i+1];
 			c2+=tmp+1;
 			c1=0;
 		}
 		else
 		{
 			tmp=array[i+1]-loc2;
 			if(tmp<0)
 			tmp*=-1;
 			tmp-=c2;
 			if(tmp<0)
 			tmp=0;
 			step+=tmp+1;
 			loc2=array[i+1];
 			c1+=tmp+1;
 			c2=0;
 		}
 	}
 	return step;
 }
 void main()
 {
 	int n,i,j,m,t;
 	char c; 
 	int *array;
 	scanf("%d",&n);
 //	printf("%d\n",n);
 	for(i=0;i<n;i++)
 	{
 		scanf("%d",&m);
 //		printf("%d ",m);
 		m=m*2;
 		array=(int *) malloc(m*sizeof(int));
 		for(j=0;j<m;)
 		{
 			scanf("%c",&c);
 			if(c==' ')
 			continue;
 			else if(c=='O')
 			{
 				array[j]=-1;
 				j++;
 			}
 			else if(c=='B')
 			{
 				array[j]=-2;
 				j++;
 			}
 			else
 			{
 			   t=0;
 			   while(c!='\n'&& c!=' ')
 				{
 					t=t*10+c-'0';
 					scanf("%c",&c);
 				}
 			   array[j]=t;
 			   j++;
 			}
 		}
 		//	printf("%c",array[j]);
 		printf("Case #%d: %d\n",i+1,f(array,m));
 	}
 }

