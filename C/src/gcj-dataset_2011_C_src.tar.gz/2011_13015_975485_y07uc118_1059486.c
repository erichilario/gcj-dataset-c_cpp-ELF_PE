#include<stdio.h>
 int main()
 {
 	int i,j,k,n,t,p1,p2,q=1;
 	long long int s,z;
 	long long int a[20000],min;
 	freopen("C.in","r",stdin);
 	freopen("1.txt","w",stdout);
 	scanf("%d",&t);
 	while(t--)
 	{
 		scanf("%d",&n);
 		s=0L;
 		for(i=0;i<n;i++)
 		{	scanf("%lld",&a[i]);
 			s=s+a[i];
 		}
 		min=a[0];
 		for(i=1;i<n;i++)
 		{
 			if(a[i]<=min)
 				min=a[i];
 		}
 		s=s-min;
 		z=0;
 		for(i=0;i<n;i++)
 		{
 			z=z^a[i];
 		}
 		printf("Case #%d: ",q); q++;
 		if(z==0) printf("%lld\n",s);
 		else printf("NO\n");
 	}
 	return 0;
 }

