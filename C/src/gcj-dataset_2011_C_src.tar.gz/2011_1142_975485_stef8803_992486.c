#include <stdio.h>
 
 int v[1005];
 
 void go(int nr){
 	int n,i,x,aux,j;
 	scanf("%d",&n);
 	for(i=1;i<=n;++i){
 		scanf("%d",&x);
 		v[i]=x;
 	}
 	int nsorted;
 	int found;
 	int sum=0;
 	do{
 		nsorted = 0;
 		for(i=1;i<=n;++i){
 			if(v[i]!=i){
 				nsorted = 1;
 				break;
 			}
 		}
 		if(nsorted){
 			found = 0;
 			for(i=1;i<=n;++i){
 				x=v[v[i]];
 				if(v[i] != i && v[i]==x && v[x]==i){
 					sum+=2;
 					v[i]=i;
 					v[x]=x;
 					found = 1;
 				}
 			}
 			if(!found){
 				for(i=1;i<=n;++i){
 					if(v[i]!=i)
 						for(j=i+1;j<=n;++j){
 							if(v[j]==i){
 								sum+=2;
 								aux=v[i];
 								v[i]=i;
 								v[j]=aux;
 								break;
 							}
 						}
 				}
 			}
 		}
 	}while(nsorted);
 
 	printf("Case #%d: %d.000000\n",nr,sum);
 
 	fflush(stdout);
 }
 
 int main(){
 	int T,i;
 	scanf("%d",&T);
 	for(i=1;i<=T;++i){
 		go(i);
 	}
 	return 0;
 }

