#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 int abs(int a) {
     if (a > 0)
         return a;
     return -a;
 }
 
 int main(char *argv[], int argc) {
 
     FILE *input_data = fopen("input.txt", "r");
 
     char *buf = malloc(1000000);
     int index = -1;
 
     while (!feof(input_data)) {
         buf[++index] = getc(input_data);
     }
     buf[++index] = '\0';
     fclose(input_data);
 
     FILE *output_data = fopen("output.txt", "w");
     index = 0;
 
     while (buf[index] != '\n')
         ++index;
 
     int case_id = 1;
 
     
     char C[36][3];
     char D[28][2];
 
     char base[8] = { 'Q', 'W', 'E', 'R', 'A', 'S', 'D', 'F' };
 
     while (buf[index] != 0) {
 
         int Ci = 0;
         int Di = 0;
         int Ni = 0;
 
         memset(C, 0, 36*3);
         memset(D, 0, 28*2);
 
         char num_buf[10];
         int num_index = -1;
         int temp_index = index;
 
         while (buf[++temp_index] < 0x3A && buf[temp_index] > 0x2F) {
             num_buf[++num_index] = buf[temp_index];
         }
 
         if (num_index > -1) {
             num_buf[++num_index] = '\0';
             Ci = atoi(num_buf);
         }
         else
             break;
 
         index = temp_index + 1;
 
         int i;
 
         for (i = 0; i < Ci; ++i) {
             memcpy(C[i], buf + index, 3);
             index += 4;
         }
 
         num_index = -1;
         temp_index = index - 1;
 
         while (buf[++temp_index] < 0x3A && buf[temp_index] > 0x2F) {
             num_buf[++num_index] = buf[temp_index];
         }
 
         if (num_index > -1) {
             num_buf[++num_index] = '\0';
             Di = atoi(num_buf);
         }
         else
             break;
 
         index = temp_index + 1;
 
         for (i = 0; i < Di; ++i) {
             memcpy(D[i], buf + index, 2);
             index += 3;
         }
 
         num_index = -1;
         temp_index = index - 1;
 
         while (buf[++temp_index] < 0x3A && buf[temp_index] > 0x2F) {
             num_buf[++num_index] = buf[temp_index];
         }
 
         if (num_index > -1) {
             num_buf[++num_index] = '\0';
             Ni = atoi(num_buf);
         }
         else
             break;
 
         index = temp_index + 1;
 
         char Q[101];
         memset(Q, 0, 101);
         char *N = Q;
 
         for (i = 0; i < Ni; ++i) {
             int j;
             int invokeable = 0;
 
             for (j = 0; j < 8; ++j) {
                 if (buf[index] == base[j]) {
                     invokeable = 1;
                     break;
                 }
             }
 
             if (!invokeable) {
                 --i;
                 --Ni;
 
                 continue;
             }
 
             N[i] = buf[index];
 
             ++index;
         }
 
 
         int element_num = 0;
         int old_Ni = Ni;
 
         int try_again = 0;
 
         while (1) {
 
             if (element_num < 2) {
                 ++element_num;
                 try_again = 0;
                 continue;
             }
 
             if (element_num > Ni && try_again == 0)
                 break;
 
             try_again = 0;
             
             for (i = 0; i < Ci; ++i) {
                 if ((N[element_num - 1] == C[i][0]
                     && N[element_num - 2] == C[i][1]) ||
                     (N[element_num - 1] == C[i][1]
                     && N[element_num - 2] == C[i][0])) {
 
                     N[element_num - 2] = C[i][2];
 
                     int j;
 
                     for (j = element_num - 1; j < Ni; ++j) {
                         N[j] = N[j + 1];
                     }
 
                     --element_num;
                     --Ni;
 
                     try_again = 1;
                     break;
                 }
             }
             if (try_again)
                 continue;
 
             for (i = 0; i < element_num; ++i) {
                 int j;
 
                 for (j = 0; j < element_num; ++j) {
                     if (i == j)
                         continue;
 
                     int k;
 
                     for (k = 0; k < Di; ++k) {
                         if ((N[i] == D[k][0]
                             && N[j] == D[k][1]) ||
                             (N[i] == D[k][1]
                             && N[j] == D[k][0])) {
 
                             int l;
 
                             for (l = 0; l < element_num; ++l)
                                 N[l] = 0;
 
                             try_again = 1;
                             break;
                         }
                     }
 
                     if (try_again)
                         break;
                 }
 
                 if (try_again)
                     break;
             }
 
             if (try_again)
                 continue;
 
             ++element_num;
         }
 
         fprintf(output_data, "Case #%i: [", case_id);
 
         for (i = 0; i < Ni - 1; ++i) {
             if (N[i] != 0)
                 fprintf(output_data, "%c, ", N[i]);
         }
         if (N[i] != 0)
             fprintf(output_data, "%c]\n", N[i]);
         else
             fprintf(output_data, "]\n");
 
         ++case_id;
     }
 
     fclose(output_data);
 
     return 0;
 }

