/** @file 	BotTrust.c
  *  @brief      Google Code Jam Problem A
  *  @author     keroserene
  */
 #include <stdlib.h>
 #include <stdio.h>
 
 #define PMIN	1
 #define PMAX 	100
 #define ORANGE	0
 #define BLUE	1
 
 #define max(a,b) 	((a) > (b) ? a : b)
 #define min(a,b)	((a) > (b) ? b : a)
 #define abs(x)		((x) > 0 ? x : -(x))
 
 FILE * f = NULL;
 
 int solve() {
 	int N, i;
  	int p[2];      		/* positions */
 	int t[2];		/* time trace */
 	int time = 0;
 	int cur = 0;
 
 	p[ORANGE] = 1;        	/* state */
 	p[BLUE] = 1;
 	t[ORANGE] = 0;
 	t[BLUE] = 0;
 
 	fscanf(f, "%d\n", &N);
 	for ( i = 0 ; i < N ; i++ ) {
 	        char next = 0;
 		int pos = 0;
 
 		fscanf(f, "%c %d ", &next, &pos);	/* Parse */
                 int bot = (next == 'O' ? ORANGE : BLUE);
 		int move = abs(pos-p[bot]) + 1;   		 
 
 		if ( bot != cur ) {               	/* Change bot and compare */
 			time += t[cur];
 			move = max(1, move - t[cur]);
 			t[ORANGE] = 0;			/* Reset */
 			t[BLUE] = 0;
 			cur = bot;
 		}
 
 		t[cur] += move;                         /* Update state */
 		p[cur] = pos;
 	}
 
 	time += max(t[ORANGE], t[BLUE]);		/* Finish */
 	fscanf(f, "\n");
 	return time;
 }
 
 
 int main ( int argc, char ** argv ) {
 	int T, Ti;
 	if (argc < 2)
 		return -1;
 
 	const char * file = argv[1];
 	f = fopen(file, "r");
 	
 	fscanf(f, "%d\n", &T);				/* Parse and loop */
 	for ( Ti = 1 ; Ti <= T ; Ti++ ) {
 		int time = solve();
 		printf("Case #%d: %d\n", Ti, time);
 	}
 
 	fclose(f);
 	return 0;	
 }

