#include <stdio.h>
 #include <math.h>
 #include <string.h>
 #include <stdlib.h>
 
 int main( ) 
 {
   FILE *f = fopen( "test.in", "r" );
   unsigned long cases, c, N, M, i, j, k, l;
 
   fscanf( f, "%lu", &cases );
   for( c = 1; c <= cases; c++ ) {
     printf( "Case #%lu:", c );
     
     fscanf( f, "%lu", &N );
     char table[ N ][ N ];
     for( i = 0; i < N; i++ ) {
       char tmp;
       fscanf( f, "%c", &tmp );
       for( j = 0; j < N; j++ ) {
         fscanf( f, "%c", &table[ i ][ j ] );
       }
     }
 
     double table_wp[ N ];
     double table_owp[ N ];
     double table_oowp[ N ];
     for( i = 0; i < N; i++ ) {
       unsigned int sum = 0, cnt = 0;
       for( j = 0; j < N; j++ ) {
 	if( table[ i ][ j ] != '.' ) {
 	  if( table[ i ][ j ] == '1' ) {
 	    sum++;
 	  }
 	  cnt++;
 	}
       }
       table_wp[ i ] = (double) sum / cnt;
       //printf( "(%lu) = %f\n", i, table_wp[ i ] );
     }
 
     for( i = 0; i < N; i++ ) {
       double sum = 0, cnt = 0;
       for( j = 0; j < N; j++ ) {
 	if( table[ i ][ j ] != '.' ) {
 	  int cnt_op = 0;
 	  for( k = 0; k < N; k++ ) {
 	    if( table[ j ][ k ] != '.' ) {
 	      cnt_op++;
 	    }
 	  }
 	  sum += ( cnt_op * table_wp[ j ] - table[ j ][ i ] + '0' ) / ( cnt_op - 1 );
 	  cnt++;
 	}
       }
       table_owp[ i ] = sum / cnt;
       //printf( "(%lu) %f %f = %f\n", i, sum, cnt, table_owp[ i ] );
     }
     
     for( i = 0; i < N; i++ ) {
       double sum = 0, cnt = 0;
       for( j = 0; j < N; j++ ) {
 	if( table[ i ][ j ] != '.' ) {
 	  sum += table_owp[ j ];
 	  cnt++;
 	}
       }
       table_oowp[ i ] = sum / cnt;
     }
     
     for( i = 0; i < N; i++ ) {
       double rdi = 0.25 * table_wp[ i ] + 0.5 * table_owp[ i ] + 0.25 * table_oowp[ i ];
       printf( "\n%f", rdi );
     }
     
     printf( "\n" );
   }
 }

