#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 double round_double(double val, int precision)
 {
     double ret;
     char buf[256] = {'\0'};
     char *p;
     sprintf(buf, "%.*f", precision, val);
     ret = strtod(buf, &p);
     return ret;
 }
 
 int gcd(int m, int n)
 {
 	while(m != n) {
 		if (m > n)
 			m = m - n;
 		else
 			n = n - m;
 	}
 	return m;
 }
 
 void sum(long long int *a, long long int *b, long long int c, long long int d)
 {
 	long long int i, j;
 	i = *a * d + c * *b;
 	j = *b * d;
 	*a = i;
 	*b = j;
 }
 
 void solve(int casenum)
 {
 	int a, b, c, i, j, k, n, count;
 	double buf;
 	scanf("%d", &n);
 	char list[n][n];
 	long long int point[n][6];
 	memset(list, -1, sizeof(list));
 	for(i = 0; i < n; i++)
 		for(j = 0; j < n; j++)
 			scanf(" %c", &list[i][j]);
 	for(i = 0; i < n; i++) {
 		a = 0;
 		b = 0;
 		for(j = 0; j < n; j++) {
 			if(list[i][j] == '1')
 				a++;
 			else if(list[i][j] == '0')
 				b++;
 		}
 		point[i][0] = a;
 		point[i][1] = a + b;
 	}
 	for(i = 0; i < n; i++) {
 		count = 0;
 		point[i][2] = 0;
 		point[i][3] = 1;
 		for(j = 0; j < n; j++) {
 			if(list[i][j] != '.') {
 				count++;
 				a = 0;
 				b = 0;
 				for(k = 0; k < n; k++) {
 					if(i == k)
 						continue;
 					if(list[j][k] == '1')
 						a++;
 					else if(list[j][k] == '0')
 						b++;
 				}
 				if(a) {
 					c = gcd(a, (a + b));
 					a /= c;
 					b /= c;
 				}
 				sum(&point[i][2], &point[i][3], (long long int)a, (long long int)(a + b));
 			}
 		}
 		if(count) {
 			buf = (double)point[i][2] / (double)count;
 			if(ceil(buf) == floor(buf))
 				point[i][2] = buf;
 			else
 				point[i][3] *= count;
 		}
 	}
 	for(i = 0; i < n; i++) {
 		count = 0;
 		point[i][4] = 0;
 		point[i][5] = 1;
 		for(j = 0; j < n; j++) {
 			if(list[i][j] != '.') {
 				count++;
 				if(point[j][2]) {
 					c = gcd(point[j][2], point[j][3]);
 					point[j][2] /= c;
 					point[j][3] /= c;
 				}
 				sum(&point[i][4], &point[i][5], point[j][2], point[j][3]);
 				if(point[i][4] > 12233720368547758 || point[i][5] > 12233720368547758) {
 					point[i][4] /= 1000;
 					point[i][5] /= 1000;
 				}
 			}
 		}
 		if(count) {
 			buf = (double)point[i][4] / (double)count;
 			if(ceil(buf) == floor(buf))
 				point[i][4] = buf;
 			else
 				point[i][5] *= count;
 		}
 	}
 	printf("Case #%d:\n", casenum);
 	for(i = 0; i < n; i++) {
 //		printf("%lld %lld %lld %lld %lld %lld\n", point[i][0], point[i][1], point[i][2], point[i][3], point[i][4], point[i][5]);
 		buf = (double)point[i][0] / (double)point[i][1] / 4.0 + (double)point[i][2] / (double)point[i][3] / 2.0 + (double)point[i][4] / (double)point[i][5] / 4.0;
 		buf = round_double(buf, 12);
 		printf("%.12g\n", buf);
 	}
 }
 
 int main(void)
 {
 	int i, n;
 	scanf("%d", &n);
 	for(i = 0; i < n; i++)
 		solve(i + 1);
 	return 0;
 }

