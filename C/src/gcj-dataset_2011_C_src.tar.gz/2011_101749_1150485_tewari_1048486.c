#include<stdio.h>
 main()
 {
       int n, t;
       int i, j;
       char M[1000][1000];
       scanf("%d",&t);
       int N = t+1;
       for(;t>0;t--)
       {
                    double wp[1000], ans = 0.0;
                    static double owp[1000], oowp[1000];
                    int total[1000];
                    scanf("%d",&n);
                   // printf("%d\n",n);
                    getchar();
                    for(i=0; i<n; i++)
                    {
                             for(j=0; j<n; j++)
                             {
                                      scanf("%c",&M[i][j]);
                             }
                             getchar();
                    }
                    double a, b;
                    for(i=0; i<n; i++)
                    {
                             a = b = 0.0;
                             for(j=0; j<n; j++)
                             {        
                                        if(M[i][j] == '.')
                                           continue;
                                        else
                                        {
                                           if(M[i][j] == '1')
                                           {
                                             a++;
                                           }
                                           b++;
                                        }
                             }
                             wp[i] = a/b;
                             total[i] = b;
                         //    printf("wp%lf\n",wp[i]);
                    }
                    int c;
                    for(i=0; i<n; i++)
                    {
                             c = 0;
                            // printf("%lf\n",wp[i]);
                            owp[i] = 0.0;
                            for(j=0; j<n; j++)
                            {
                                     if(M[i][j] != '.')
                                     {
                                                c++;
                                              //  printf("aaa%lf\n",((wp[j]*total[j]) - (int)(M[j][i]-'0'))/(total[j]-1));
                                                owp[i] = owp[i] + ((wp[j]*total[j]) - (int)(M[j][i]-'0'))/(total[j]-1);
                                     }
                            }
                      //      printf("%d\n",c);
                            owp[i] = owp[i] / c;
                        //    printf("owp%lf\n",owp[i]);
                           
                    }
                    printf("Case #%d:\n",N-t);
                    for(i=0; i<n; i++)
                    {
                             oowp[i] = 0.0;
                             c = 0;
                             for(j=0; j<n; j++)
                             {
                                      if(M[i][j] != '.')
                                      {
                                                 c++;
                                                 oowp[i] = oowp[i] + owp[j];
                                      }
                             }
                             oowp[i] = oowp[i]/c;
                          //    printf("oowp%lf\n",oowp[i]);
                             ans = (0.25*wp[i]) + (0.5*owp[i]) + (0.25*oowp[i]);
                             printf("%lf\n",ans);
                    }
                             
       }
 }
                    

