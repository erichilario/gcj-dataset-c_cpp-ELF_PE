#include<stdio.h>
 
 int main()
 {
 int i,j,k,d,l,n,N,f;    
 long C[11][11],W[11],F[11],Fl[11],D[11];
 float T[11],t;
 
 
 
 for(i=0;i<11;i++)
 {
 if(i==0)
  F[i]=1;
 else
 F[i]=i*F[i-1];                 
 C[i][0]=1;
 C[i][i]=1;
 for(j=1;j<i;j++)
     {
     
     C[i][j]=C[i-1][j-1]+C[i-1][j];             
     }                 
 }
 
 
 
 W[0]=0;
 T[0]=0;
 W[1]=0;
 T[1]=0;
 
 for(i=2;i<11;i++)
 {
 T[i]=1;
 W[i]=F[i]-1;
 for(j=2;j<i;j++)
 {
 T[i]=T[i]+C[i][j]*T[j]*W[j];                 
 W[i]=W[i]-C[i][j];
 }                 
 T[i]=T[i]/F[i];
 //printf("%d->%f W->%d \n",i,T[i],W[i]);                 
 }
 
 
 
 scanf("%d",&N);
 for(n=1;n<=N;n++)
 {
 
 scanf("%d",&d);
 for(i=1;i<=d;i++)
 {
 scanf("%d",&D[i]);
 Fl[i]=0;
 }
 
 
 
 f=0;t=0;
 
 //while(f<d)
 //{
 
 for(i=1;i<=d;i++)
 {
 if(Fl[i]) continue;
 if(D[i]==i)
 	{
 	Fl[i]=1;
 	f++;
 	}
 }
 
 for(i=1;i<=d;i++)
 {
 if(Fl[i]) continue;
 j=D[i];
 if(D[j]==i)
 {
 	Fl[i]=1;
 	f++;
 	Fl[j]=1;
 	f++;
 	t=t+1/T[2];
 }
 }
 
 
 for(i=1;i<=d;i++)
 {
 if(Fl[i]) continue;
 j=D[i];
 if(D[D[j]]==i)
 {
 	Fl[i]=1;
 	Fl[j]=1;
 	Fl[D[j]]=1;
 	f=f+3;
 	t=t+1/T[3];
     
 }
 }
 
 
 //printf("Reached");
 //scanf("%d");
 for(j=4;j<=d;j++)
 {
 if(f==d) break;
 for(i=1;i<=d;i++)
 {
 if(Fl[i])
  continue;
 //if(d==4)
 //printf("Ch %d %d %d %d %d \n",i,D[i],D[D[i]],D[D[D[i]]],D[D[D[D[i]]]]);
 k=D[i];
 l=j-1;
 while(l--)
 k=D[k];
 //printf("Checked%d ",k);
 if(i==k)
 {
         
 k=i;
 l=j;
 while(l--)
 {
 Fl[k]=1;
 k=D[k];          
 f++;
 }
 //printf("Marked");
 t=t+1/T[j];        
 }
 
 }
 
 }
 
 
 //}
 
 
 printf("Case #%d: %.6f\n",n,t);
 }
 
 return 0;
 }

