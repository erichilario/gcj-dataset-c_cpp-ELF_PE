#include <stdio.h>
 #include <stdlib.h>
 
 #define MAXN 101
 
 int main()
 {
 	int i,j,tcase,T,N,total[MAXN],totwin[MAXN];
 	char win[MAXN][MAXN];
 	double owp[MAXN],oowp[MAXN];
 
 	scanf("%d",&T);
 	for(tcase=1;tcase<=T;tcase++)
 	{
 		scanf("%d",&N);
 		for(i=0;i<N;i++)
 		{
 			total[i]=totwin[i]=0;
 			getchar();
 			for(j=0;j<N;j++)
 			{
 				win[i][j]=getchar();
 				if(win[i][j]!='.')
 				{
 					total[i]++;
 					if(win[i][j]=='1')
 						totwin[i]++;
 				}
 			}
 		}
 		for(i=0;i<N;i++)
 		{
 			owp[i]=0;
 			for(j=0;j<N;j++)
 			{
 				if(win[i][j]!='.')
 				{
 					if(win[i][j]=='0')
 						owp[i]+=(totwin[j]-1)/(total[j]-1.0);
 					else if(win[i][j]=='1')
 						owp[i]+=totwin[j]/(total[j]-1.0);
 					else
 						fprintf(stderr,"Wrong input reading!\n");
 				}
 			}
 			owp[i]/=total[i];
 		}
 		printf("Case #%d:\n",tcase);
 		for(i=0;i<N;i++)
 		{
 			oowp[i]=0;
 			for(j=0;j<N;j++)
 			{
 				if(win[i][j]!='.')
 					oowp[i]+=owp[j];
 			}
 			oowp[i]/=total[i];
 			printf("%.12f\n",(0.25*totwin[i])/total[i]+0.5*owp[i]+0.25*oowp[i]);
 		}
 	}
 	return 0;
 }

