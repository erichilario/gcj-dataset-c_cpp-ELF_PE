
 #include <stdio.h>
 #include <string.h>
 
 static int find(char (*s)[5], int len, char a, char b);
 
 int
 main(void)
 {
 	int test;
 	int cnt;
 	int x;
 	int c, d, n, count;
 	char cs[50][5];
 	char ds[50][5];
 	char s[200];
 	char ans[200];
 	int used[256];
 	int i, j;
 
 	scanf("%d", &test);
 	cnt = 0;
 	while (test--) {
 
 		scanf("%d", &c);
 		for (i = 0; i < c; ++i)
 			scanf("%s", cs[i]);
 		scanf("%d", &d);
 		for (i = 0; i < d; ++i)
 			scanf("%s", ds[i]);
 		scanf("%d", &n);
 		scanf("%s", s);
 
 		memset(used, 0, sizeof(used));
 		count = 0;
 		for (i = 0; i < n; ++i) {
 			if (count == 0) {
 				ans[count++] = s[i];
 				used[s[i]] += 1;
 			} else if ((x = find(cs, c, ans[count-1], s[i])) != 0) {
 				used[ans[count-1]] -= 1;
 				ans[count-1] = x;
 				used[x] += 1;
 			} else {
 				for (j = 0; j < d; ++j) {
 					if ((ds[j][0] == s[i] && used[ds[j][1]]) ||
 							(ds[j][1] == s[i] && used[ds[j][0]]))
 						break;
 				}
 				if (j != d) {
 					memset(used, 0, sizeof(used));
 					count = 0;
 				} else {
 					ans[count++] = s[i];
 					used[s[i]] += 1;
 				}
 			}
 		}
 
 		printf("Case #%d: [", ++cnt);
 		if (count > 0)
 			printf("%c", ans[0]);
 		for (i = 1; i < count; ++i)
 			printf(", %c", ans[i]);
 		printf("]\n");
 	}
 
 	return 0;
 }
 
 static int
 find(char (*s)[5], int len, char a, char b)
 {
 	int i;
 
 	for (i = 0; i < len; ++i) {
 		if ((s[i][0] == a && s[i][1] == b) ||
 				(s[i][0] == b && s[i][1] == a))
 			return s[i][2];
 	}
 
 	return 0;
 }

