#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 #include<string.h>
 int main()
 {
     freopen("1B-A-RPI.in","r",stdin);
     freopen("1B-A-RPI.out","w",stdout);
     int T,N;
     int i,j,k,aWP[110];
     char s[110][110];
     double WP[110],OWP[110],OOWP[11];
     scanf("%d",&T);
     for(i=1;i<=T;i++){
         scanf("%d",&N);
         printf("Case #%d:\n",i);
         for(j=0;j<N;j++){
             scanf("%s",s[j]);
             WP[j]=0; OWP[j]=0; OOWP[j]=0;
         }
         for(j=0;j<N;j++){
             int a=0;
             for(k=0;k<N;k++){
                 if(s[j][k]!='.'){
                     a++;
                     WP[j]+=s[j][k]-'0';
                 }
             }
             aWP[j]=a;
             WP[j]/=a;
             //printf("%lf ",WP[j]);
         }
         //printf("\n");
         for(j=0;j<N;j++){
             int a=0;
             for(k=0;k<N;k++){
                 if(s[j][k]!='.'){
                     a++;
                     OWP[j]+=(WP[k]*aWP[k]-(s[k][j]-'0'))/(aWP[k]-1);
                 }
             }
             OWP[j]/=a;
             //printf("%lf ",OWP[j]);
         }
         //printf("\n");
         for(j=0;j<N;j++){
             int a=0;
             for(k=0;k<N;k++){
                 if(s[j][k]!='.'){
                     a++;
                     OOWP[j]+=OWP[k];
                 }
             }
             OOWP[j]/=a;
             //printf("%lf ",OWP[j]);
             //printf("\n");
             printf("%.12lf\n",0.25*WP[j]+0.5*OWP[j]+0.25*OOWP[j]);
         }
     }
     return 0;
 }

