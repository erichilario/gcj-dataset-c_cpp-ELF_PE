#include<stdio.h>
 int main()
 {
     long long int t,t1,i,n,z,s,val,min;
     long long int a[1100];
     freopen("2.in","r",stdin);
 	freopen("3.txt","w",stdout);
 	
     scanf("%lld",&t);
         for(t1=1;t1<=t;t1++)
         {
 
             scanf("%lld",&n);
             for(i=1;i<=n;i++)
                 scanf("%lld",&a[i]);
                 
                 
                 s=a[1];
                 val=a[1];
                 min=a[1];
             for(i=2;i<=n;i++)
             {
                 s+=a[i];
                 val^=a[i];
                 if(a[i]<min)
                 min=a[i];
                 
             }
             
             s-=min;
             if(val==0) printf("Case #%lld: %lld\n",t1,s);
             else printf("Case #%lld: NO\n",t1);
 
         }
 return 0;
 }

