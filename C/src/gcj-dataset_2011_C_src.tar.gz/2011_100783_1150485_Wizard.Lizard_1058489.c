#include <stdio.h>
 
 int T, caseCtr;
 
 int N, P, V, D;
 
 
 int main(){
 	int i;
 	freopen("A.in", "r", stdin);
 	freopen("output.txt", "w", stdout);
 	scanf("%d ", &T);
 	for(caseCtr=0; caseCtr<T; ++caseCtr){
 		int min, max, total;
 
 		scanf("%d %d ", &N, &D);
 		scanf("%d %d ", &P, &V);
 			min = max = P;
 			total = V;
 		for(i=1; i<N; ++i){
 			scanf("%d %d ", &P, &V);
 			if(P<min) min = P;
 			if(P>max) max = P;
 			total += V;
 		}
 
 
 		if(total*D - (max - min) < 0) 
 			printf("Case #%d: %d\n", caseCtr+1, 0);
 		else
 			printf("Case #%d: %f\n", caseCtr+1, (float)(total*D - (max - min)) /2);
 		/*output*/
 	}
 	return 0;
 }
