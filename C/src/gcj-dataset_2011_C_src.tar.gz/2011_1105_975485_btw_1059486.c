
 #include <stdio.h>
 
 #define N 1000
 
 int
 main(void)
 {
 	int test;
 	int i, j;
 	int a[N];
 	int n;
 	int all, min, sum;
 
 	scanf("%d", &test);
 	for (j = 1; j <= test; ++j) {
 		scanf("%d", &n);
 
 		all = 0;
 		sum = 0;
 		min = 10000000;
 		for (i = 0; i < n; ++i) {
 			scanf("%d", &a[i]);
 			all ^= a[i];
 			sum += a[i];
 			if (min > a[i])
 				min = a[i];
 		}
 
 		if (all != 0) {
 			printf("Case #%d: NO\n", j);
 			continue;
 		}
 
 		printf("Case #%d: %d\n", j, sum - min);
 	}
 
 	return 0;
 }

