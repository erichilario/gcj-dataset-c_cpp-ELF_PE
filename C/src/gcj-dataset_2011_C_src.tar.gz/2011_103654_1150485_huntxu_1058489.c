#include <stdio.h>
 #include <math.h>
 #define MAX 20
 
 int t, n;
 int i[20];
 int j[20];
 
 int main()
 {
     int l, d, c, k, v, x, min, max;
     double time, mid, west, east, tmp;
     scanf("%d\n", &t);
     for (l=1; l<=t; l++) {
         scanf("%d %d\n", &c, &d);
         v = 0;
         for (k=0; k<c; k++) {
             scanf("%d %d\n", &i[k], &j[k]);
             v += j[k];
         }
         min = i[0];
         max = i[c-1];
         mid = (double)(min+max)/2;
         west = mid-(double)(d*(v-1)/2);
         east = mid+(double)(d*(v-1)/2);
         for (k=0, v=0; k<c; k++) {
             for (x=0; x<j[k]; x++, v++) {
                 if (i[k]>west+v*d) {
                     tmp = i[k]-west-v*d;
                 }
                 else {
                     tmp = west+v*d-i[k];
                 }
                 time = time>tmp?time:tmp;
             }
         }
         printf("Case #%d: %.8f\n", l, time);
     }
     return 0;
 }

