#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 #define MAX_SIZE 105
 #define MAX(x,y) x>y?x:y
 
 int main()
 {
 	freopen("A-large.in","r",stdin);
 	freopen("A-large.out","w",stdout);
 	//freopen("A-small-attempt0.in","r",stdin);
 	//freopen("A-small-attempt0.out","w",stdout);
 	//freopen("in","r",stdin);
 	int T,i,j,t,ctr,N;
 	char Schedule[MAX_SIZE][MAX_SIZE];
 	double WP[MAX_SIZE],OWP[MAX_SIZE],OOWP[MAX_SIZE],RPI[MAX_SIZE];
 	scanf("%d",&T);
 	//printf("%d",T);
 	for(t=1;t<=T;t++)
 	{
 		printf("Case #%d:",t);
 		scanf("\n%d",&N);
 		//printf("\n%d",N);
 		for(i=0;i<N;i++) {
 			scanf("\n");
 			for(j=0;j<N;j++)
 				scanf("%c",&Schedule[i][j]);
 		}
 		/*for(i=0;i<N;i++) {
 			printf("\n");
 			for(j=0;j<N;j++)
 				printf("%c",Schedule[i][j]);
 
 		}*/
 		int total_games[MAX_SIZE],wins[MAX_SIZE];
 
 		for(i=0;i<N;i++) {
 			wins[i]=total_games[i]=0;
 			for(j=0;j<N;j++) {
 				if(i==j)
 					continue;
 				if(Schedule[i][j]!='.')
 					total_games[i]++;
 				if(Schedule[i][j]=='1')
 					wins[i]++;
 			}
 			WP[i]=((double)wins[i])/((double)total_games[i]);
 			//printf("%.12lf\n",WP[i]);
 		}
 		double temp,OWP_WP[MAX_SIZE];
 		for(i=0;i<N;i++) {
 			OWP[i]=0;
 			for(j=0;j<N;j++) {
 				if(i==j || Schedule[i][j]=='.')
 					continue;
 				temp=((double)(wins[j]-(Schedule[j][i]-'0')))/((double)(total_games[j]-1));
 				//printf("\n%d,%d->%d|%d|%d|",i,j,wins[j],total_games[j],Schedule[j][i]-'0');
 				OWP[i]+=temp;
 				//printf("%d->%.6lf,",j,temp);
 			}
 			OWP[i]/=((double)(total_games[i]));
 			//printf("%.12lf\n",OWP[i]);
 		}
 		for(i=0;i<N;i++) {
 			OOWP[i]=0;
 			for(j=0;j<N;j++) {
 				if(i==j || Schedule[i][j]=='.')
 					continue;
 				OOWP[i]+=OWP[j];
 			}
 			OOWP[i]/=((double)(total_games[i]));
 			RPI[i]=0.25000000 * WP[i] + 0.50000000 * OWP[i] + 0.25000000 * OOWP[i];
 			printf("\n%0.12lf",RPI[i]);
 		}
 		if(t<T)
 			printf("\n");
 
 	}
 	return 0;
 }

