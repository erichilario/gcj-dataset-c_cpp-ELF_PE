#include <stdio.h>
 #define MAX 110
 
 int coor[MAX];
 
 int main()
 {
     int t, c, d, p, v, count = 1, i, j, num, cur, max, min;
     
     FILE *finp = fopen("B-small-attempt1.in","r");
 	FILE *foutp = fopen("B.out","w");
     fscanf(finp, "%d", &t);  
     //scanf("%d", &t);
     
     while (t--)
     {
         fscanf(finp, "%d %d", &c, &d); 
         //scanf("%d %d", &c, &d);
         
         num = 0;
         for (i = 0; i < c; i++)
         {
             fscanf(finp, "%d %d", &p, &v); 
             //scanf("%d %d", &p, &v);
             
             for (j = 0; j < v; j++)
                 coor[num++] = p;
         }
         
         min = 9999999;
         max = -9999999;
         for (i = 0; i < num; i++)
         {
             cur = d * i - coor[i];
             if (min > cur) min = cur;
             if (max < cur) max = cur;
         }
         
         fprintf(foutp, "Case #%d: %lf\n", count++, (double)(max - min) / 2.0);
         //printf("Case #%d: %lf\n", count++, (double)(max - min) / 2.0);
     }
     
     fclose(finp);
     fclose(foutp);
     
     return 0;
 }

