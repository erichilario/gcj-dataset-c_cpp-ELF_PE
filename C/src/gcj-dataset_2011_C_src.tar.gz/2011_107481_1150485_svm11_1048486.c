#include<stdio.h>
 #include<string.h>
 #include<math.h>
 
 #define MAX(a,b) (a>b?a:b)
 #define MIN(a,b) (a>b?b:a)
 #define REP(a,b,c) for(a=b;a<c;a++)
 #define rep(a,n) REP(a,0,n)
 #define ABS(x) (x>0?x:-x)
 #define ULL unsigned long long
 #define MOD 0
 char a[100][100];
 double wp[100],owp[100],oowp[100];
 
 int main()
 {
     freopen("A-small-attempt0.in","r",stdin); freopen("A-output.out","w",stdout);
     int t,i,j,k,n;
     int w[100],l[100];
     double x;
     scanf("%d",&t);
     for(i=1;i<=t;i++)
     {
         scanf("%d",&n);
         rep(j,n) { w[j]=l[j]=0; }
 
         rep(j,n)
         {
             rep(k,n)
             {
                  scanf("%1s",&a[j][k]);
                  if(a[j][k]=='1') w[j]++;
                  else if(a[j][k]=='0') l[j]++;
             }
             wp[j]=(double)w[j]/(w[j]+l[j]);
         }
 
         rep(j,n)
         {
             x=0.0;
             rep(k,n)
             {
                 if(k==j) continue;
                 if(a[k][j]=='0') x+=(double)w[k]/(w[k]+l[k]-1);
                 else if(a[k][j]=='1') x+=(double)(w[k]-1)/(w[k]+l[k]-1);
             }
             owp[j]=(double)x/(w[j]+l[j]);
         }
 
         rep(j,n)
         {
             x=0.0;
             rep(k,n)
             {
                 if(k==j) continue;
                 if(a[k][j]!='.') x+=owp[k];
             }
             oowp[j]=(double)x/(w[j]+l[j]);
         }
 
         printf("Case #%d: \n",i);
         rep(j,n)
         {
             double rpi=0.25*wp[j]+0.5*owp[j]+.25*oowp[j];
             printf("%lf\n",rpi);
         }
     }
     return 0;
 }

