#include <stdio.h>
 #include <math.h>
 
 
 int main (void)
 {
 	int t,n;
 	double wp[100];
 	double owp[100];
 	double oowp[100];
 	double count;
 	double w,l;
 	
 	double temp;
 	double rpi;
 	
 	int i,j,k,m;
 	char s[100][101];
 	t=0;
 	scanf("%d\n", &t);
 	//printf("%d\n" ,t);
 	
 	
 	
 	for (i=0; i<t; i++){
 		scanf("%d\n",&n);
 		for(j=0;j<n;j++){
 			gets(s[j]);
 		}
 		
 		/*
 		for(j=0;j<n;j++){
 		for(k=0;k<n;k++)
 		printf("%c",s[j][k]);
 		printf("\n");
 		}
 		*/
 		for(j=0;j<n;j++){
 			w=0;l=0;
 			for(k=0;k<n;k++){
 				if(s[j][k] =='1'){
 					w+=1;
 				}else if(s[j][k] =='0'){
 					l+=1;
 				}
 			}
 			wp[j]=w/(w+l);
 		}
 		/*
 		printf("\nwp: ");
 		for(j=0;j<n;j++){
 			printf("%.12f|",wp[j]);
 		}
 		*/
 		for(j=0;j<n;j++){
 			owp[j]=0;count=0;
 			for(k=0;k<n;k++){
 				if(s[j][k] =='1' || s[j][k] =='0'){
 					count++;
 					w=0;l=0;
 					for(m=0;m<n;m++){
 						if(m!=j){
 							if(s[k][m] =='1'){
 								w+=1;
 							}else if(s[k][m] =='0'){
 								l+=1;
 							}
 						}
 					}
 					owp[j]+=(w/(w+l));
 				}
 				//printf("\ns[%d][%d]:%c|owp[%d]:%.12f|count:%f",j,k,s[j][k],j,owp[j],count);
 			}
 			if(count==0) count = 1;
 			owp[j] /= count;
 		}
 		/*
 		printf("\nowp: ");
 		for(j=0;j<n;j++){
 			printf("%.12f|",owp[j]);
 		}
 		*/
 		
 		
 		for(j=0;j<n;j++){
 			count=0;
 			temp = 0;
 			for(k=0;k<n;k++){
 				if(s[j][k] =='1' || s[j][k] =='0'){
 					count++;
 					temp += owp[k];
 				}
 			}
 			if(count==0) count = 1;
 			oowp[j] = temp/count;
 		}
 		/*
 		printf("\noowp: ");
 		for(j=0;j<n;j++){
 			printf("%.12f|",oowp[j]);
 		}
 		*/
 		
 	
 		printf("Case #%d:\n", i+1);
 		for(j=0;j<n;j++){
 			rpi = 0.25 * wp[j] + 0.50 * owp[j] + 0.25 * oowp[j];
 			printf("%.12f\n",rpi);
 		}
 	}
 		
 	return 0;
 }

