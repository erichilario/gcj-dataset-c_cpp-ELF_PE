#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int get_fp_num(FILE *);
 void check_start(char,int);
 void check_end(char *,int);
 
 char com_rule[36][4],opp_rule[28][4];
 char N_str[100];
 int T,N,C,D;
 
 int main(void){
 	FILE *fp,*fw;
 	int i,j,N_num,cur_num;
 	char cur_str;
 
 	fp = fopen("B-small-attempt4.in","r");
 	fw = fopen("B-small-attempt4.out","w");
 	
 	T = get_fp_num(fp);
 	
 	for(i=1;i<=T;i++){
 		C=get_fp_num(fp);
 		for(j=0;j<C;j++){
 			com_rule[j][0] = fgetc(fp);
 			com_rule[j][1] = fgetc(fp);
 			com_rule[j][2] = fgetc(fp);
 			com_rule[j][3] = -1;
 			fgetc(fp);
 		}
 
 		D=get_fp_num(fp);
 		for(j=0;j<D;j++){
 			opp_rule[j][0] = fgetc(fp);
 			opp_rule[j][1] = fgetc(fp);
 			opp_rule[j][2] = -1;
 			opp_rule[j][3] = -1;
 			fgetc(fp);
 		}
 
 		N=get_fp_num(fp);
 		memset(N_str,0,sizeof(N_str));
 		for(j=0;j<N;j++){
 			cur_str = fgetc(fp);
 			N_str[j]=cur_str;
 			check_end(&cur_str,j);
 			check_start(cur_str,j);
 		}
 		fgetc(fp);
 		fprintf(fw,"Case #%d: [",i);
 		N_num=cur_num=0;
 		for(j=0;j<N;j++)
 			if(N_str[j] !=0)	N_num++;
 		
 		for(j=0;j<N;j++){
 			if(N_str[j] !=0){
 				fprintf(fw,"%c",N_str[j]);
 				cur_num++;
 			
 				if(cur_num == N_num)	break;
 				else	fprintf(fw,", ");
 			}
 		}
 		fprintf(fw,"]\n");
 
 	}
 	fclose(fp);
 	fclose(fw);
 	
 	return 0;
 }
 
 int get_fp_num(FILE *a)
 {
   int k=0,j=0;
   char temp[10];
   while(1){
     temp[k] = fgetc(a);	
     if(temp[k] == 10)	{
       temp[k+1]=0;
 	  return atoi(temp);
 	}	
     if(temp[k] == 32){
       temp[k+1]=0;
 	  return atoi(temp);
 	}
     k++;
   }
 }
 
 void check_end(char *a,int index)
 {
 	int i,j;
 
 	for(i=0;i<C;i++){
 		if(com_rule[i][3] !=-1){
 			if( (com_rule[i][3] == 0 && com_rule[i][1] == *a) || (com_rule[i][3] == 1 && com_rule[i][0] == *a) ){
 				N_str[index-1]=0;
 				N_str[index] = com_rule[i][2];
 				*a = com_rule[i][2];
 				for(j=0;j<D;j++){
 					if(opp_rule[j][3] == index-1){
 					opp_rule[j][2] = -1;
 					opp_rule[j][3] = -1;
 					}
 				}
 				break;
 			}
 		}
 	}
 	for(j=0;j<C;j++)	com_rule[j][3]=-1;
 
 	for(i=0;i<D;i++){
 		if(opp_rule[i][2] !=-1){
 			if( (opp_rule[i][2] == 0 && opp_rule[i][1] == *a) || (opp_rule[i][2] == 1 && opp_rule[i][0] == *a) ){
 				for(j=0;j<=index;j++)	N_str[j]=0;
 				*a = 0;
 				for(j=0;j<D;j++){
 					opp_rule[j][2] = -1;
 					opp_rule[j][3] = -1;
 				}
 				break;
 			}
 		}
 	}
 }
 
 void check_start(char a,int index)
 {
 	int i,j;
 
 	for(i=0;i<C;i++){
 		if(com_rule[i][0] == a || com_rule[i][1] == a){
 			if(com_rule[i][0] == a){
 				com_rule[i][3] = 0;
 			}
 			else{
 				com_rule[i][3] = 1;
 			}
 		}
 	}
 	for(i=0;i<D;i++){
 		if(opp_rule[i][2] == -1 && (opp_rule[i][0] ==a || opp_rule[i][1] == a)){
 			if(opp_rule[i][0] == a)	opp_rule[i][2] =0;
 			else	opp_rule[i][2] = 1;
 			opp_rule[i][3] = index;
 		}
 	}
 
 }
