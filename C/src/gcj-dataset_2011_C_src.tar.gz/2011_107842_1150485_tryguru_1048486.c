#include<stdio.h>
 #include<string.h>
 
 #define LD long double
 #define N 105
 
 #define DEBUG 0
 
 char matr[N][N];
 LD ans[N];
 LD wp[N];
 LD owp[N];
 LD oowp[N];
 
 int valid[N][N];
 
 void comput(int n){
   memset(valid, 0, sizeof(valid));
 
   int i, j, sucess, total;
   for(i = 0; i < n; i++){
     sucess = 0;
     total = 0;
     for (j = 0; j < n; j++){
       if (matr[i][j] != '.'){
         total++;
         valid[i][j] = 1;
       }
       if (matr[i][j] == '1')
         sucess++;
     }
     wp[i] = (LD)sucess / (LD)total;
   }
 
   LD wp1[N];
   //memset(wp1, 0, sizeof(wp1);
 
   for (i = 0; i < n; i++)
     owp[i] = (LD)0;
 
   int k;
   for(k = 0; k < n; k++){
     for (i = 0; i < n; i++){
       //if (valid[k][i]){
       if (k != i){
         sucess = 0;
         total = 0;
         for (j = 0; j < n; j++){
           if (k!= j && matr[i][j] != '.')
             total++;
           if (k!= j && matr[i][j] == '1')
             sucess++;
         }
         wp1[i] = (LD)sucess / (LD)total;
       }
     }
     int temp = 0;
     for(i = 0; i < n; i++)
       if (valid[k][i]){
         temp++;
         owp[k] += wp1[i];
       } 
     if (temp == 0){
       printf("owp %d\n", k);
       owp[k] = 0;
     }
     else
       owp[k] = owp[k] / (LD)temp;  
   }
 
   for( i = 0; i < n; i++)
     oowp[i] = 0;
 
   for(i = 0; i < n; i++){
     int temp = 0;
     for (j = 0; j < n; j++)
       if (valid[i][j]){
         temp++;
         oowp[i] += owp[j];
       }
     
     oowp[i] = oowp[i] / (LD)temp;
   } 
 
   for(i = 0; i < n; i++)
     ans[i] = ((LD)0.25)*wp[i] + ((LD)0.5)*owp[i] + ((LD)0.25)*oowp[i];     
 }
 
 int main(){
   int t;
   scanf("%d", &t);
   int n;
   int i,j,k;
 
   for(i = 0; i < t; i++){
     scanf("%d", &n);
     for(j = 0; j < n; j++)
       scanf("%s", matr[j]);
 
     comput(n);
     printf("Case #%d:\n", (i+1));
     for(j = 0; j < n; j++)
       printf("%.12Lf\n", ans[j]);
   }
   
   return 0;
 }

