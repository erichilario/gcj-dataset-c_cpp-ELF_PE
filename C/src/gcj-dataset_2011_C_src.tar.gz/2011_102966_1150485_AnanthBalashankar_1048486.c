#include<stdio.h>
 #include<stdlib.h>
 char** a;
 double **b;
 int n;
  
 void OWP(int j,int k)
 {
 	int won=0,played=0,i;
 	for(i=0;i<n;i++)
 	{
 		if(i!=k)
 		{
 			if(a[j][i]=='1')
 			{won++;played++;}
 			else if(a[j][i]=='0')
 				played++;
 		}
 	}
 	b[j][k]=(double)((double)won/(double)played);
 }
 
 
 int main(){
 int t,i,j,k,won,*played;
 	double *wp,*owp,*oowp;
 	char ch;
 	FILE *fin,*fout;
 	fin=fopen("input.txt","r");
 	fout=fopen("output.txt","w");
 	fscanf(fin,"%d",&t);
 	for(i=0;i<t;i++)
 	{
 		fprintf(fout,"Case #%d:\n",i+1);
 		fscanf(fin,"%d",&n);
 		a=(char **)malloc(n*sizeof(char*));
 		b=(double **)malloc(n*sizeof(double*));
 		wp=(double *)malloc(n*sizeof(double));
 		owp=(double *)malloc(n*sizeof(double));
 		oowp=(double *)malloc(n*sizeof(double));
 		played=(int *)malloc(n*sizeof(int));
 		for(j=0;j<n;j++)
 		{
 			fscanf(fin,"%c",&ch);
 			a[j]=(char *)malloc(n*sizeof(char));
 			b[j]=(double *)malloc(n*sizeof(double));
 			for(k=0;k<n;k++)
 				fscanf(fin,"%c",&a[j][k]);
 		}
 		for(j=0;j<n;j++)
 		{
 			for(k=0;k<n;k++)
 			{
 				if(j!=k)
 					OWP(j,k);
 			}
 		}
 
 		for(j=0;j<n;j++)
 		{
 			wp[j]=0;owp[j]=0;oowp[j]=0;
 			won=0;played[j]=0;
 			for(k=0;k<n;k++)
 			{
 			if(a[j][k]=='1')
 			{won++;played[j]++;}
 			else if(a[j][k]=='0')
 				played[j]++;
 			}
 			wp[j]=(double)((double)won/(double)played[j]);
 			
 			for(k=0;k<n;k++)
 			{
 				if(a[j][k]!='.')
 				{
 					owp[j]+=b[k][j];
 				}
 			}
 			owp[j]=(double)(owp[j]/played[j]);
 		}
 
 
 		for(j=0;j<n;j++)
 		{
 			for(k=0;k<n;k++)
 			{
 				if(a[j][k]!='.')
 				{
 					oowp[j]+=owp[k];
 				}
 			}
 			oowp[j]=(double)(oowp[j]/played[j]);
 			fprintf(fout,"%lf\n",(0.25 * wp[j] + 0.50 * owp[j] + 0.25 * oowp[j]));
 		}
 
 		/*for(j=0;j<n;j++)
 			{for(k=0;k<n;k++)
 				printf("%c",a[j][k]);
 			printf("\n");
 			}
 
 		for(j=0;j<n;j++)
 			{for(k=0;k<n;k++)
 				printf("%f  ",b[j][k]);
 			printf("\n");
 			}
 
 		for(j=0;j<n;j++)
 			printf("%f ",wp[j]);
 		printf("\n");
 		for(j=0;j<n;j++)
 			printf("%f ",owp[j]);
 		printf("\n");
 		for(j=0;j<n;j++)
 			printf("%f ",oowp[j]);*/
 
 
 
 		
 	}
 
 
 }

