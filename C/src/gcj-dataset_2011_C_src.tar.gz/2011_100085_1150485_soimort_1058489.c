#include <stdio.h>
 #include <math.h>
 int main()
 {
     int t;
     scanf("%d", &t);
     for (int tc = 0; tc < t; tc++) {
         int c, d, p_max = -100001, p_min = 100001, vs = 0, p[200], v[200];
         scanf("%d%d", &c, &d);
         for (int i = 0; i < c; i++) {
             scanf("%d%d", &p[i], &v[i]);
             if (p[i] > p_max) p_max = p[i];
             if (p[i] < p_min) p_min = p[i];
             vs += v[i];
         }
         double center = (double)(p_max - p_min) / 2;        
         double len = (vs - 1) * d;
         double start = center - len / 2;
         double maxwaste = -1, waste;
         int tt = 0;
         for (int i = 0; i < vs; i++) {
             while (v[tt] == 0) tt++;
             v[tt]--;
             waste = fabs((start + i * d) - p[tt]);
             if (waste > maxwaste) maxwaste = waste;
         }
         printf("Case #%d: %f\n", tc + 1, maxwaste);
     }
     return 0;
 }

