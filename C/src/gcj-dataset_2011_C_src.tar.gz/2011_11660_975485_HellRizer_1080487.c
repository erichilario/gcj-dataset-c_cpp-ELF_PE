#include<stdio.h>
 
 int main(){
     int T,N;
     char ch,lastch;
     int b,no,nb,i,j;
     int lastOT,lastBT;
     int lastOP,lastBP;
     int O[100],B[100],C[100];
     int time;
     scanf("%d\n",&T);
     for(i=0;i<T;i++){
                      time=1;
                      no=0;
                      nb=0;
     
                      lastOT=1;
                      lastBT=1;
                      lastOP=1;
                      lastBP=1;
                      scanf("%d",&N);
                      for(j=0;j<N;j++){
                                       scanf(" %c %d",&ch,&b );
                                     //  printf("s%ds",b);
                                       if(ch=='O'){
                                                   if(lastch=='B'){
                                                   if((time-lastOT)<myabs(lastOP,b)){
                                                                                     time+=myabs((time-lastOT),myabs(lastOP,b))+1;
                                                                                     
                                                   }
                                                   else time=time+1;
                                                   lastOP=b;
                                                   lastOT=time;}
                                                   else{
                                                       // printf("%d %d",b,lastOP);
                                                         time+=myabs(b,lastOP)+1;
                                                         lastOP=b;
                                                         lastOT=time;
                                                         }
                                                   
                                          
                                       }
                                       if(ch=='B'){
                                                   if(lastch='O'){
                                                   if((time-lastBT)<myabs(lastBP,b))time+=myabs((time-lastBT),myabs(lastBP,b))+1;
                                                   else time=time+1;
                                                   lastBP=b;
                                                   lastBT=time;
                                                   }
                                                   else {
                                                        time+=myabs(b,lastBP)+1;
                                                        lastBP=b;
                                                        lastBT=time;
                                                   }
                                       
                                       }
                                       lastch=ch;
                      
                                      
                                       
                      }
                      printf("Case #%d: %d\n",i+1,time-1);
                       
     }
     
 }
 int myabs(int a,int b){
     if(a-b>0)return a-b;
     else return b-a;
 }

