#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 
 #define MAX 101
 
 char sched[MAX][MAX];
 int played[MAX];
 int won[MAX];
 float wp[MAX];
 float owp[MAX];
 float oowp[MAX];
 
 
 int main()
 {
   FILE *p=fopen("a.out","w");
   FILE *in=fopen("a.in","r");
   long long int T, c=0, N;
   int    i, j;
   long long int oplayed, owon;
   float op;
   fscanf(in,"%lld",&T);
   while(T--){
     fscanf(in,"%lld",&N);
     memset(sched,0, sizeof(sched));
     memset(wp,0, sizeof(wp));
     memset(owp,0, sizeof(owp));
     memset(oowp,0, sizeof(oowp));
     memset(played,0, sizeof(played));
     memset(won,0, sizeof(won));
 
     for(i=0;i<N;i++) {
       fscanf(in,"%s",sched[i]);  
     }
     
     // compute wp
     for(i=0;i<N;i++) {
         for (j=0; j<N; j++) {
             if (sched[i][j] != '.') {
                 played[i]++;
                 if (sched[i][j] == '1') {
                     won[i]++;
                 }
             }
             wp[i] = (float)won[i]/ (float)played[i];
         }
     }
 
 
     // compute owp
 
 //OWP (Opponents' Winning Percentage) is the average WP of all your opponents, after first throwing out the games they played against you.
 //For example, if you throw out games played against team D, then team B has WP = 0 and team C has WP = 0.5. Therefore team D has OWP = 0.5 * (0 + 0.5) = 0.25. Similarly, team A has OWP = 0.5, team B has OWP = 0.5, and team C has OWP = 2/3.
 
      for(i=0;i<N;i++) {
         oplayed = 0; 
         owon = 0;
         op=0;
         for (j=0; j<N; j++) {
             if (sched[i][j] != '.') {
                  //we ve played 'j'
                 oplayed++;
                 if (sched[i][j] == '1') {
                    owon = won[j];
                 } else { // i has lost to j; so penalize j 
                     if (won[j]) owon = won[j]-1;
                 }
                 op += (float) owon/ (float) (played[j]-1);
                 printf ("%d:%d: %c->%c: op=%lld/%d=%f\t", i, j, 'a'+i, 'a'+j, owon, played[j]-1,
                         (float) owon/ (float) (played[j]-1));
 
             }
             owp[i] = op/ (float)oplayed; 
         }
             printf("\n");
     }
 
 
      // compute oowp
 
       for(i=0;i<N;i++) {
         op=0;
         oplayed=0;
         for (j=0; j<N; j++) {
             if (sched[i][j] != '.') {
                 oplayed++;
                 op+=owp[j];
             }
 
         }
         oowp[i] = (float)op/ (float) oplayed;
       }
       
 
 
      for(i=0;i<N;i++) {
       printf("%s |%d/%d=%f| %f\n",sched[i], won[i], played[i], wp[i], owp[i]);  
     }
 
 
 
     fprintf(p,"Case #%lld:\n",++c);
     for(i=0;i<N;i++) {
         fprintf(p,"%f\n", 0.25*wp[i] + 0.5*owp[i] + 0.25*oowp[i]);
     }
 
    }
   fclose(p);
   fclose(in);
 return 0;
 }
 

