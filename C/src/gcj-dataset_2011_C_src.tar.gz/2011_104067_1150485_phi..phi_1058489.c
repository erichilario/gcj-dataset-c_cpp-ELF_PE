#include<stdio.h>
 #include<stdlib.h>
 int main(){
 	double sol;
 	int T,t,C,P,V,D,last,i;
 	scanf("%i\n",&T);
 	for(t=1;t<=T;t++){
 		scanf("%i %i\n",&C,&D);
 		sol=0;
 		for(i=0;i<C;i++){
 			scanf("%i %i\n",&P,&V);
 			if(V==1);
 			else if(V==2)sol+=(double)D/2;
 			else if(V==3)sol+=D;
 			else{
 				if(!V%2){
 					V-=3;
 					sol+=D+(double)(D-1)/2;
 				}
 				sol+=V/2+(V/2-1)*D+(double)(D-1)/2;
 			}
 			if(i!=0 && abs(last-P)==1)sol+=(double)(D-1)/2;
 			last=P;
 		}
 		printf("Case #%i: %lf\n",t,sol);
 	}
 	return 0;
 }
