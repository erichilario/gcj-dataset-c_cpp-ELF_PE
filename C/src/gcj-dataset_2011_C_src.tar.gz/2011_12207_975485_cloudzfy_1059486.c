#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 int main()
 {
 	FILE *fp1,*fp2;
 	int total,xor,x,t,min,n,i,c;
 	fp1=fopen("C-large.in","r");
 	fp2=fopen("C-large.out","w");
 	fscanf(fp1,"%d",&t);
 	for(x=1;x<=t;x++)
 	{
 		xor=0;
 		total=0;
 		min=1111111;
 		fscanf(fp1,"%d",&n);
 		for(i=0;i<n;i++)
 		{
 			fscanf(fp1,"%d",&c);
 			total+=c;
 			xor=xor^c;
 			if(min>c)min=c;
 		}
 		if(xor==0)fprintf(fp2,"Case #%d: %d\n",x,total-min);
 		else fprintf(fp2,"Case #%d: NO\n",x);
 	}
 }
