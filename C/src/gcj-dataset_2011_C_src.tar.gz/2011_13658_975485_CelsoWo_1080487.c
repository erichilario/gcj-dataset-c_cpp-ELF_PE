#include<stdio.h>
 
 int main()
 {
 	register int i, aux;
 	int t, n, p, sO, sB, pO, pB;
 	char r;
 	
 	scanf ( "%d" , &t );
 	
 	for ( i = 1; i <= t; i++ )
 	{
 		scanf ( "%d" , &n );
 		
 		sO = sB = 0;
 		pO = pB = 1;
 		while ( n-- )
 		{
 			scanf ( " %c %d" , &r, &p );
 
 			if ( r == 'O' )
 			{
 				aux = (p - pO > 0 ?	p - pO : pO - p );
 				
 				if ( sB - sO > aux ) sO += sB - sO;
 				else sO += aux;
 				
 				sO++;
 				pO = p;
 			}
 			else
 			{
 				aux = (p - pB > 0 ?	p - pB : pB - p );
 				
 				if ( sO - sB > aux ) sB += sO - sB;
 				else sB += aux;
 				
 				sB++;
 				pB = p;
 			}
 		}
 		
 		printf ( "Case #%d: %d\n" , i, sB > sO ?  sB : sO );
 	}
 	
 	return 0;
 }

