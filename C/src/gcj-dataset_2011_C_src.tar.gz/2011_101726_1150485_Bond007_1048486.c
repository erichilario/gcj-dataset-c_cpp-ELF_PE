#include <stdio.h>
 
 FILE *fpr = NULL;
 FILE *fpw = NULL;
 
 
 char MainArr[100][100];
 long double win[100],loss[100];
 long double Wp[100],Owp[100],Oowp[100];
 long double sum = 0,Result = 0;
 
 int main()
 {
 
 	int TcNo = 0;
 	int i=0,j=0,k=0;
 	int N= 0;
 	int TcIndex = 0;
 	int ResultSec = 0;
 	char tempstr[1000];
 	
 	fpr = fopen("Sol1.in","r");
 	if(fpr == NULL)
 	{
 	  printf("File Not Found");
 	  getch();
 	  return 0;
 	}
 
 	fpw = fopen("Sol1.out","w");
 	if(fpw == NULL)
 	{
 	  printf("Can't Create File");
 	  getch();
 	  return 0;
 	}
 
 	fscanf(fpr,"%d",&TcNo);
 
 	for(k=0;k<TcNo;k++)
 	{
 				
 		fscanf(fpr,"%d",&N);
 		memset(MainArr,0,sizeof(char)*(N*N));
 		
 		for(i=0;i<N;i++)
 		{
 			fscanf(fpr,"%s",tempstr);
 			for(j=0;j<N;j++)
 			{
 				MainArr[i][j] = tempstr[j];;
 			}
 		}
 	
 		for(i=0;i<N;i++)
 		{
 			win[i] = 0;
 			loss[i] = 0;
 			for(j=0;j<N;j++)
 			{
 				switch(MainArr[i][j])
 				{
 					case 49:
 						win[i]++;
 					break;
 					case 48:
 						loss[i]++;
 					break;
 					case 46:
 					break;
 				}				
 			}
 			Wp[i] = ((win[i])/(win[i]+loss[i]));
 		}
 
 		for(i=0;i<N;i++)
 		{
 			sum = 0;
 			for(j=0;j<N;j++)
 			{
 				if(i!=j)
 				{
 					switch(MainArr[i][j])
 					{
 						case 49:
 							sum = sum + ((win[j])/(win[j]+loss[j]-1));
 						break;
 						case 48:
 							sum = sum + ((win[j]-1)/(win[j]+loss[j]-1));
 						break;
 						case 46:
 							//sum = sum + wp[j];
 						break;
 					}
 				}
 				
 			}
 			Owp[i] = (sum)/(win[i]+loss[i]);
 		}
 		for(i=0;i<N;i++)
 		{
 			sum = 0;
 			for(j=0;j<N;j++)
 			{
 				if(i!=j)
 				{
 					switch(MainArr[i][j])
 					{
 						case 49:
 							sum = sum + Owp[j];
 						break;
 						case 48:
 							sum = sum + Owp[j];
 						break;
 						case 46:
 						break;
 					}
 				}
 			}
 			Oowp[i] = sum/(win[i]+loss[i]);		
 		}
 
 		fprintf(fpw,"Case #%d:\n",k+1);
 
 		for(i=0;i<N;i++)
 		{
 			Result = (0.25*Wp[i])+(0.5*Owp[i])+(0.25*Oowp[i]);
 			fprintf(fpw,"%.12f\n",Result);
 		}
 	}
 
 
 	fclose(fpr);
 	fclose(fpw);
 return 0;
 }
