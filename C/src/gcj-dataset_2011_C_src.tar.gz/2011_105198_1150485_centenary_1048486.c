#include <stdlib.h>
 #include <stdio.h>
 #include <errno.h>
 #include <math.h>
 #include <string.h>
 
 #define MIN(a, b) ((a) < (b) ? (a) : (b))
 #define MAX(a, b) ((a) > (b) ? (a) : (b))
 #define ABS(a)    ((a) < 0 ? (0 - (a)) : (a))
 
 typedef unsigned long long ub8;
 
 int main(int argc, char **argv)
 {
   FILE *input;
   int ret;
 
   int numTests;
   int curTest;
 
   int n;
   int x, y;
   char game;
 
   char games[100][100];
   int wins[100];
   int losses[100];
 
   double wp[100];
   double wp_wo_x[100][100];
   double owp[100];
   double oowp[100];
 
   int tempWins;
   int tempLosses;
 
   if(argc != 2)
   {
     printf("Usage: %s <input file>\n", argv[0]);
     exit(1);
   }
 
   if(!(input = fopen(argv[1], "r"))) {
     printf("Failed to open input file: %d\n", errno);
     exit(1);
   }
 
   /* Read number of tests */
   ret = fscanf(input, "%d", &numTests);
   if(ret != 1)
   {
     printf("Failed to read number of tests\n");
     exit(1);
   }
 
   for(curTest = 0 ; curTest < numTests ; curTest++)
   {
     /* Zero out arrays */
     memset(games, 0, sizeof(char) * 100 * 100);
     memset(wins, 0, sizeof(int) * 100);
     memset(losses, 0, sizeof(int) * 100);
     memset(wp, 0, sizeof(double) * 100);
     memset(wp_wo_x, 0, sizeof(double) * 100 * 100);
     memset(owp, 0, sizeof(double) * 100);
     memset(oowp, 0, sizeof(double) * 100);
 
     /* Read number of inputs in current test */
     ret = fscanf(input, "%d" , &n);
     if(ret != 1)
     {
       printf("Case #%d: Failed to read number of inputs\n", curTest + 1);
       exit(1);
     }
     fscanf(input, "\n");
 
     for(x = 0 ; x < n ; x++)
     {
       for(y = 0 ; y < n ; y++)
       {
         ret = fscanf(input, "%c", &game);
         if(ret != 1)
         {
           printf("Case #%d: Failed to read game\n", curTest + 1);
         }
 
         games[x][y] = game;
 
         if(game == '1')
           wins[x]++;
         else if(game == '0')
           losses[x]++;
       }
       fscanf(input, "\n");
     }
 
     /*
     for(x = 0 ; x < n ; x++)
     {
       for(y = 0 ; y < n ; y++)
       {
         printf("% c", games[x][y]);
       }
       printf("\n");
     }
     */
 
     for(x = 0 ; x < n ; x++)
     {
       wp[x] = ((double)wins[x]) / ((double)(wins[x] + losses[x]));
     }
 
     for(x = 0 ; x < n ; x++)
     {
       for(y = 0 ; y < n ; y++)
       {
         if(games[y][x] == '.')
           continue;
 
         tempWins = wins[y];
         tempLosses = losses[y];
 
         if(games[y][x] == '1')
         {
           tempWins--;
         }
         else if(games[y][x] == '0')
         {
           tempLosses--;
         }
 
         if(tempWins + tempLosses != 0)
         {
           wp_wo_x[x][y] = ((double)tempWins) / ((double)(tempWins + tempLosses));
         }
       }
     }
 
     /*
     for(x = 0 ; x < n ; x++)
     {
       for(y = 0 ; y < n ; y++)
       {
         printf("%f ", wp_wo_x[x][y]);
       }
       printf("\n");
     }
     */
 
     for(x = 0 ; x < n ; x++)
     {
       for(y = 0 ; y < n ; y++)
       {
         if(games[y][x] == '.')
           continue;
 
         owp[x] += (wp_wo_x[x][y]) / (wins[x] + losses[x]);
       }
     }
 
     /*
     for(x = 0 ; x < n ; x++)
     {
       printf("%f ", owp[x]);
     }
     printf("\n");
     */
 
     for(x = 0 ; x < n ; x++)
     {
       for(y = 0 ; y < n ; y++)
       {
         if(games[y][x] == '.')
           continue;
 
         oowp[x] += (owp[y]) / (wins[x] + losses[x]);
       }
     }
 
     /*
     for(x = 0 ; x < n ; x++)
     {
       printf("%f ", oowp[x]);
     }
     printf("\n");
     */
 
     printf("Case #%d:\n", curTest + 1);
     for(x = 0 ; x < n ; x++)
     {
       double rpi = 0.25 * wp[x] + 0.5 * owp[x] + 0.25 * oowp[x];
       printf("%.12f\n", rpi);
     }
   }
 
   return 0;
 }

