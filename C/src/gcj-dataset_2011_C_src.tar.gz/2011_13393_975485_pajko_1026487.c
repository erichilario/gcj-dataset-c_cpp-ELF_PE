#include <stdio.h>
 #include <string.h>
 
 #define MAX_COMBINES 36
 #define MAX_OPPOSES 28
 #define MAX_INPUT 100
 
 #define __min(a,b)          ((a) < (b) ? (a) : (b))
 #define min(a,b)            ((a) < (b) ? (a) : (b))
 #define __max(a,b)          ((a) > (b) ? (a) : (b))
 #define max(a,b)            __max((a), (b))
 #define __min_not_zero(a,b) (((a) == 0) ? (b) : __min((a), (b)))
 #define min_not_zero(a,b)   __min_not_zero((a), (b))
 
 static char COMBINES[256][256];
 static unsigned int OPPOSES[256];
 static char INPUT[100];
 static char OUTPUT[100];
 static int last[256];
 
 int solve(FILE *fo, int testcase, int input_length)
 {
   int i;
   unsigned int opposed = 0, prev_opposed = 0, out_ptr = 0;
   unsigned char prev = '\0';
   for (i = 0; i < input_length; i++) {
     // printf("prev: 0x%02x input: %c opposes: 0x%08x prev_opposed: 0x%08x opposed: %08x\n", prev, INPUT[i], OPPOSES[INPUT[i]], prev_opposed, opposed);
     if (COMBINES[prev][INPUT[i]]) {
       // printf("combines with %c to %c\n", prev, COMBINES[prev][INPUT[i]]);
       out_ptr--;
       OUTPUT[out_ptr++] = COMBINES[prev][INPUT[i]];
       opposed = prev_opposed;
       prev = '\0';
     } else if (opposed & (1U << (INPUT[i] - 'A'))) {
       // printf("opposed\n");
       opposed = 0;
       out_ptr = 0;
       prev_opposed = 0;
       prev = '\0';
     } else {
       // printf("out\n");
       prev_opposed = opposed;
       opposed |= OPPOSES[INPUT[i]];
       OUTPUT[out_ptr++] = INPUT[i];
       prev = INPUT[i];
     }
   }
   fprintf(fo, "Case #%d: [", testcase);
   if (out_ptr) {
     fprintf(fo, "%c", OUTPUT[0]);
     for (i = 1; i < out_ptr; i++) {
       fprintf(fo, ", %c", OUTPUT[i]);
     }
   }
   fprintf(fo, "]\n");
 }
 
 int main(int argc, char **argv)
 {
   int i;
   int testcases;
   FILE *fi = fopen(argv[1], "rt");
   FILE *fo = fopen("result", "wt");
   fscanf(fi, "%d", &testcases);
   for (i = 0; i < testcases; i++) {
     int j, combines, opposes, input_length;
     memset(COMBINES, 0, sizeof(COMBINES));
     memset(OPPOSES, 0, sizeof(OPPOSES));
     fscanf(fi, "%d", &combines);
     for (j = 0; j < combines; j++) {
       char comb_1, comb_2, comb_result;
       do {
         comb_1 = fgetc(fi);
       } while (comb_1 == ' ');
       do {
         comb_2 = fgetc(fi);
       } while (comb_2 == ' ');
       do {
         comb_result = fgetc(fi);
       } while (comb_result == ' ');
       // printf("%c combines with %c to %c\n", comb_1, comb_2, comb_result);
       COMBINES[comb_1][comb_2] = comb_result;
       COMBINES[comb_2][comb_1] = comb_result;
     }
     fscanf(fi, "%d", &opposes);
     for (j = 0; j < opposes; j++) {
       char opp_1, opp_2;
       do {
         opp_1 = fgetc(fi);
       } while (opp_1 == ' ');
       do {
         opp_2 = fgetc(fi);
       } while (opp_2 == ' ');
       // printf("%c opposes with %c\n", opp_1, opp_2);
       OPPOSES[opp_1] |= (1U << (opp_2 - 'A'));
       OPPOSES[opp_2] |= (1U << (opp_1 - 'A'));
     }
     fscanf(fi, "%d", &input_length);
     for (j = 0; j < input_length; j++) {
       do {
         INPUT[j] = fgetc(fi);
       } while (INPUT[j] == ' ');
     }
     solve(fo, i + 1, input_length);
   }
   fclose(fi);
   fclose(fo);
   return 0;
 }

