#include<stdio.h>
 int main()
 {
 	int t,temp=1;
 	scanf("%d",&t);
 	while(temp<=t)
 	{
 		printf("Case #%d: ",temp);
 		int n,sum=0,xor,min=0,i;
 		scanf("%d",&n);
 		int num;
 		scanf("%d",&num);
 		xor=num;
 		min=num;
 		sum=num;
 		for(i=0;i<n-1;i++)
 		{
 			scanf("%d",&num);
 			xor=xor^num;
 			if(min>num)
 			{
 				min=num;
 			}
 			sum=sum+num;
 		}
 		if(xor!=0)
 		{
 			printf("NO\n");
 		}
 		else
 		{
 			printf("%d\n",sum-min);
 		}
 		temp++;
 	}
 	return 0;
 }
 
 
 

