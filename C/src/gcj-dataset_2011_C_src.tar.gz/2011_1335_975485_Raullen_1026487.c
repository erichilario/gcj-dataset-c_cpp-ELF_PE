#include<stdio.h>
 
 int main(){
 	long T, C, D, N, no_case=0;
 	int i, j, k, kk, q;
 	char C_list[36][3], D_list[28][2], N_list[100];
 	scanf("%ld",&T);
 	//printf("T = %ld\n",T);
 	for (i=0;i<T;i++){
 	
 		no_case++;
 		scanf("%ld",&C);
 		//printf("C = %ld\n",C);
 		for(j=0;j<C;j++){
 			scanf("%s",&C_list[j]);
 			//printf("%s\n",C_list[j]);
 		}
 		
 		scanf("%ld",&D);
 		//printf("D = %ld\n",D);
 		for(j=0;j<D;j++){
 			scanf("%s",&D_list[j]);
 			//printf("%s\n",D_list[j]);
 		}
 		
 		scanf("%ld",&N);
 		//printf("N = %ld\n",N);
 		if(N>0){
 			scanf("%s",&N_list);
 			//strncpy( N_list_cpy, N_list, N);
 			//printf("%s\n",N_list_cpy);
 		}
 		
 		
 		for(j=0;j<N;j++){
 			//combine first 
 
 			if(j>0){
 				for(k=0;k<C;k++){
 					if (   ((N_list[j-1] == C_list[k][0]) && (N_list[j] == C_list[k][1]))  || ((N_list[j-1] == C_list[k][1]) && (N_list[j] == C_list[k][0]))   ){
 						
 						N_list[j] = C_list[k][2];
 						N_list[j-1] = '#';
 						break;
 					}
 				}
 			}	
 
 			//revoke
 			for(k=0;k<D;k++){
 				if(N_list[j] == D_list[k][0]){
 					for(kk=j;kk>=0;kk--){
 						if (N_list[kk] == D_list[k][1]){
 							for(q=j;q>=kk;q--){
 								N_list[q] = '#';
 							}
 							break;
 						}
 					}
 				}
 
 				if(N_list[j] == D_list[k][1]){
 					for(kk=j;kk>=0;kk--){
 						if (N_list[kk] == D_list[k][0]){
 							for(q=j;q>=kk;q--){
 								N_list[q] = '#';
 							}
 							break;
 						}
 					}
 				}
 					
 			}
 		
 		
 		}
 
 		//output
 		int flag = 0;
 		printf("Case #%ld: [",no_case );
 		for(k=0;k<N;k++){
 			if (N_list[k] != '#'){
 				if (flag && k >0 ) printf(", ");
 				printf("%c", N_list[k]);
 				flag = 1;
 			}
 			
 		}
 		printf("]\n");
 		
 	}
 }

