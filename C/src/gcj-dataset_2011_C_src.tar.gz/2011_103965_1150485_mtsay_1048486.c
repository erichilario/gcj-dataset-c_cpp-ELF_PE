#include<stdio.h>
 
 int N;
 
 char schedule[101][101];
 
 int game_played[101];
 int game_won[101];
 
 float wp[101];
 float owp[101];
 float oowp[101];
 
 void compute_played_won()
 {
   int i, j;
 
   for(i = 0; i < N; i++)
     {
       game_played[i] = 0;
       game_won[i] = 0;
 
       for(j = 0; j < N; j++)
 	switch(schedule[i][j])
 	  {
 	  case '0':
 	    game_played[i]++;
 	    break;
 	  case '1':
 	    game_played[i]++;
 	    game_won[i]++;
 	    break;
 	  case '.':
 	    break;
 	  }
     }
 }
 
 void compute_wp()
 {
   int i;
 
   for(i = 0; i < N; i++)
     wp[i] = 1.f * game_won[i] / game_played[i];
 }
 
 void compute_owp()
 {
   int i, j;
 
   for(i = 0; i < N; i++)
     {
       float sum_wp;
 
       sum_wp = 0;
 
       for(j = 0; j < N; j++)
 	switch(schedule[i][j])
 	  {
 	  case '0':
 	    sum_wp += 1.f * (game_won[j] - 1) / (game_played[j] - 1);
 	    break;
 	  case '1':
 	    sum_wp += 1.f * game_won[j] / (game_played[j] - 1);
 	    break;
 	  case '.':
 	    break;
 	  }
 
       owp[i] = sum_wp / game_played[i];
     }
 }
 
 void compute_oowp()
 {
   int i, j;
 
   for(i = 0; i < N; i++)
     {
       float sum_owp;
 
       sum_owp = 0;
 
       for(j = 0; j < N; j++)
 	if(schedule[i][j] != '.')
 	  sum_owp += owp[j];
 
       oowp[i] = sum_owp / game_played[i];
     }
 }
 
 int main()
 {
   int T, t;
 
   scanf("%d\n", &T);
 
   for(t = 1; t <= T; t++)
     {
       int i, j;
 
       scanf("%d\n", &N);
 
       for(i = 0; i < N; i++)
 	{
 	  for(j = 0; j < N; j++)
 	    scanf("%c", &schedule[i][j]);
 
 	  scanf("\n");
 	}
 
       compute_played_won();
       compute_wp();
       compute_owp();
       compute_oowp();
 
       printf("Case #%d:\n", t);
 
       for(i = 0; i < N; i++)
 	printf("%f\n", 0.25 * wp[i] + 0.5 * owp[i] + 0.25 * oowp[i]);
     }
 }

