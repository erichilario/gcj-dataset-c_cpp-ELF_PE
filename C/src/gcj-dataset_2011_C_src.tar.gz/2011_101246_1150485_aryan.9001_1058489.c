#include"stdio.h"
 double max(double a,double b)
 {
  return a<b?b:a;
 }
 double abs(double b)
 {
  return b<0?-b:b;
 }
 struct pts
 {
  int num,x;
 };
 int main()
 {
  int T;
  scanf("%d",&T);
  for(int t=1;t<=T;t++)
  {
    int n;
    long long d;
    scanf("%d%Ld",&n,&d);
    pts p[n];
    for(int x=0;x<n;x++)
      scanf("%d%d",&p[x].x,&p[x].num);
    double conjustedOpt[n][n],leftMost[n][n],rightMost[n][n];
    for(int x=0;x<n;x++)
      for(int y=0;y+x<n;y++)
      {
        if(x==0)
        {
          conjustedOpt[y][y+x]=(d-1)*p[y].num/2.0;
          leftMost[y][y+x]=p[y].x-conjustedOpt[y][y+x];
          rightMost[y][y+x]=p[y].x+conjustedOpt[y][y+x];
        }
        else
        {
          int i=x+y-1,j=y+x;
          if(rightMost[y][i]+d<=leftMost[j][j])
          {
            rightMost[y][j]=rightMost[j][j];
            leftMost[y][j]=leftMost[y][i];
            conjustedOpt[y][j]=max(conjustedOpt[y][i],conjustedOpt[j][j]);
          }
          else
          {
            double b=rightMost[y][i]+d-leftMost[j][j],b2=conjustedOpt[y][i]-conjustedOpt[j][j];
            if(abs(b2)>b)
            {
              leftMost[y][j]=leftMost[y][i]-(b2>0?0:b);
              rightMost[y][j]=rightMost[j][j]+(b2<0?0:b);
              conjustedOpt[y][j]=max(conjustedOpt[y][i],conjustedOpt[j][j]);
            }
            else
            {
              double d=(b-abs(b2))/2;
              leftMost[y][j]=leftMost[y][i]-(b2>0?0:-b2)-d;
              rightMost[y][j]=rightMost[j][j]+(b2<0?0:b2)+d;
              conjustedOpt[y][j]=max(conjustedOpt[y][i],conjustedOpt[j][j])+d;
              //compromize one less and the other more
            }
          }
        }
      }
    double rightOpt[n],best[n];
    best[0]=conjustedOpt[0][0];
    rightOpt[0]=rightMost[0][0];
    for(int x=1;x<n;x++)
    {
      rightOpt[x]=rightMost[0][x];
      best[x]=conjustedOpt[0][x];
      for(int j=0;j<x;j++)
      {
        if(leftMost[j+1][x]>rightOpt[j]&&best[x]>best[j]&&best[x]>conjustedOpt[j+1][x])//can
 exist parallely
        {
          rightOpt[x]=rightMost[j+1][x];
          best[x]=max(conjustedOpt[j+1][x],best[j]);
        }
      }
    }
    printf("Case #%d: %f\n",t,best[n-1]);
  }
 }

