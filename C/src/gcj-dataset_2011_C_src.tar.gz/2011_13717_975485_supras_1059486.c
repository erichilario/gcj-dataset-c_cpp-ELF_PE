/* candy splitting */
 
 #include <stdio.h>
 #include <math.h>
 
 // 2^N - 1
 #define MAX_VALUE 32767 
 #define MAX_N 15
 #define MAX_T 100
 
 void set_bit(int *arr,int bit_vector,int n){
   int i=1;
   while(i <= n){
     arr[n-i]= bit_vector % 2;
     bit_vector = bit_vector / 2;
     i++;
   }
 }
 
 
 int XOR(int arr[],int n,int bit_vector){
 
   int inc[MAX_N];
 
   int tmp=0,i;
   set_bit(inc,bit_vector,n);
 
   for(i=0;i<n;i++){
     if(inc[i])
       tmp ^= arr[i];
   }
 
   return tmp;
 }
 
 int ADD(int arr[], int n, int bit_vector){
   int inc[MAX_N];
   int tmp=0,i;
   set_bit(inc,bit_vector,n);
 
   for(i=0;i<n;i++){
     if(inc[i])
       tmp += arr[i];
   }
   return tmp;
 }
 
 int max(int a,int b){
   if (a > b)
     return a;
   else
     return b;
 }
 
 int main(){
 
   int T,N,bit_vector,max_bit;
   int array[MAX_N];
   int value,max_value;
   int oi=0;
   int i,output[MAX_T];
 
   scanf("%d",&T);
 
   while(T > 0){
     scanf("%d",&N);
 
     bit_vector = pow(2,N) - 1;
     max_bit = bit_vector;
 
     for(i=0;i<N;i++)
       scanf("%d",&array[i]);
 
     max_value = 0;
     while(bit_vector >= 0){
       if( (XOR(array,N,bit_vector) == XOR(array,N,max_bit - bit_vector)) &&  bit_vector != max_bit && bit_vector != 0 ){
 	  value = max(ADD(array,N,bit_vector),ADD(array,N,max_bit - bit_vector));
 	  if(value > max_value)
 	    max_value = value;
 	}
       bit_vector--;
     } 
     output[oi++] = max_value;
     T--;
   }
 
   for(i=0;i<oi;i++){
     if(output[i])
       printf("Case #%d: %d\n",i+1,output[i]);
     else
       printf("Case #%d: NO\n",i+1);
   }
 
   return 1;
 }

