#include <assert.h>	
 #include <ctype.h>	
 #include <math.h>	
 #include <stdarg.h> 
 #include <stdio.h>	
 #include <stdlib.h>	
 #include <string.h>	
 #include <time.h>	
 
 #define LOOP(i,N) for((i)=0;(i)<(int)(N);i++)
 #define GETMEM(type,n) (type*)malloc((n)*sizeof(type))
 #define OUT(...) printf(__VA_ARGS__)
 #define FOUT(...) fprintf(out_fp, __VA_ARGS__)
 #define FIN(...) fscanf(in_fp, __VA_ARGS__)
 #define ERR(...) fprintf(stderr, __VA_ARGS__)
 #define ERRCHK(x) if(x==NULL){perror("Error");exit(1);}
 
 #define TRUE 1
 #define FALSE 0
 
 int main(int argc, char* argv[])
 {
 	/* DECLARE VARIABLES */
 	FILE* in_fp=NULL;
 	FILE* out_fp=NULL;
 	
 	int i,j,k;
 	int numCases;
 	
 	int buttonsToPress;
 	char* robots;
 	int* buttons;
 	
 	int curTimeB;
 	int curTimeO;
 	int atButtonB;
 	int atButtonO;
 	
 	/* CHECK COMMAND LINE ARGUMENTS*/
 	if (argc!=2)
 	{
 		ERR("Incorrect number of command line arguments, exiting...\n");
 		return 1;
 	}
 	
 	/* OPEN FILES */
 	in_fp = fopen(argv[1],"r");
 	ERRCHK(in_fp);
 	
 	out_fp = fopen("output.txt","w");
 	ERRCHK(out_fp);
 	
 	/* READ NUMBER OF CASES */
 	fscanf(in_fp,"%d",&numCases);
 
 	/* MAIN LOOP */
 	LOOP(k,numCases)
 	{
 		FIN("%d",&buttonsToPress);
 		robots = GETMEM(char,buttonsToPress);
 		ERRCHK(robots);
 		buttons = GETMEM(int,buttonsToPress);
 		ERRCHK(buttons);
 		
 		LOOP(i,buttonsToPress)
 		{
 			FIN("%*c%c%*c%d",&robots[i],&buttons[i]);
 		}
 		
 		atButtonB=1;
 		atButtonO=1;
 		curTimeO=0;
 		curTimeB=0;
 		
 		LOOP(i,buttonsToPress)
 		{
 			if(robots[i]=='O') //orange robot's button
 			{
 				curTimeO += (buttons[i]>atButtonO) ? (buttons[i]-atButtonO) : (atButtonO-buttons[i]); //time to get to button
 				
 				if(curTimeO<=curTimeB)			//time waiting for other robot
 					curTimeO = curTimeB;
 				
 				curTimeO++; //Time to push the button
 				
 				atButtonO = buttons[i];
 			}
 			else //blue robot's button
 			{
 				curTimeB += (buttons[i]>atButtonB) ? (buttons[i]-atButtonB) : (atButtonB-buttons[i]);
 				
 				if(curTimeB<=curTimeO)
 					curTimeB = curTimeO;
 				
 				curTimeB++;
 				atButtonB = buttons[i];
 
 			}
 		}
 		
 		FOUT("Case #%d: %d\n",k+1,(curTimeO>curTimeB) ? curTimeO : curTimeB);
 		free(robots);
 		free(buttons);
 	}
 	
 	/* CLOSE FILES */
 	fclose(out_fp);
 	fclose(in_fp);
 	
 	return 0;
 }

