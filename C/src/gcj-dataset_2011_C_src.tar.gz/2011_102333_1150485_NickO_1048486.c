#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
 	int T;
 	scanf("%d", &T);
 	int tc;
 	for(tc = 1; tc<=T; tc++){
 		printf("Case #%d:\n", tc);
 		int i,j,k;
 		int N;
 		scanf("\n%d", &N);
 		double *wins = malloc(N*sizeof(double));
 		double *plays = malloc(N*sizeof(double));
 		int **playd = malloc(N*sizeof(int*));
 		double *WP = malloc(N*sizeof(double));
 		double *WPw = malloc(N*sizeof(double));
 		double *WPl = malloc(N*sizeof(double));
 		double *OWP = malloc(N*sizeof(double));
 		double *OOWP = malloc(N*sizeof(double));
 		double *RPI = malloc(N*sizeof(double));
 		for(i = 0; i < N; i++){
 			playd[i] = malloc(N*sizeof(int));
 			scanf("\n");
 			plays[i] = 0;
 			wins[i] = 0;
 			for(j = 0; j < N; j++){
 				char game;
 				scanf("%c", &game);
 				playd[i][j] = 0;
 				if(game == '.')
 					continue;
 				playd[i][j] = 1;
 				plays[i]++;
 				if(game == '1'){
 					playd[i][j] = 2;
 					wins[i]++;
 				}
 			}
 		}
 		for(i = 0; i < N; i++){
 			WP[i] = wins[i]/plays[i];
 			WPw[i] = (wins[i])/(plays[i]-1);
 			WPl[i] = (wins[i]-1)/(plays[i]-1);
 		}
 		for(i = 0; i < N; i++){
 			OWP[i] = 0;
 			for(j = 0; j < N; j++){
 				if(playd[i][j]==1){
 					OWP[i] += WPl[j];
 				}else if(playd[i][j]==2){
 					OWP[i] += WPw[j];
 				}
 			}
 			OWP[i] = OWP[i]/plays[i];
 		}
 		for(i = 0; i < N; i++){
 			OOWP[i] = 0;
 			for(j = 0; j < N; j++)
 				if(playd[i][j])
 					OOWP[i] += OWP[j];
 			OOWP[i] = OOWP[i]/plays[i];
 		}
 		for(i = 0; i < N; i++){
 			RPI[i] = 0.25*WP[i]+0.5*OWP[i]+0.25*OOWP[i];
 			printf("%f\n", RPI[i]);
 		}
 		free(wins);
 		free(plays);
 		for(i = 0; i < N; i++)
 			free(playd[i]);
 		free(playd);
 		free(WP);
 		free(WPw);
 		free(WPl);
 		free(OWP);
 		free(OOWP);
 		free(RPI);
 	}
 	return 0;
 }
 
 
 /*
 2
 3
 .10
 0.1
 10.
 4
 .11.
 0.00
 01.1
 .10.
 
 */
