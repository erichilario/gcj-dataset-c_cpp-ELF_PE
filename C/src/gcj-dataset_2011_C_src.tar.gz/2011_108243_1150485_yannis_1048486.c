#include <stdio.h>
 #include <stdlib.h>
 
 char table[111][111];
 double wp[111], owp[111], oowp[111];
 
 int main(void) {
     freopen("input.txt", "r", stdin);
     freopen("output.txt", "w", stdout);
     int i, j, k, w, l, t, T, N, cnt;
     double sowp;
 
     scanf("%d ", &T);
 
     for (t=1; t<=T; t++) {
         scanf("%d ", &N);
 
         for (i=1; i<=N; i++) {
             for (j=1; j<=N; j++) {
                 scanf("%c", &table[i][j]);
             }
             scanf("\n");
         }
 
         sowp = 0;
 
         for (i=1; i<=N; i++) {
             w = 0; l = 0;
             for (j=1; j<=N; j++) {
                 if ( table[i][j] == '1' ) w++;
                 else if ( table[i][j] == '0' ) l++;
             }
             if ( w+l == 0 ) wp[i] = 0;
             else wp[i] = (double)w/(w+l);
 
             owp[i] = 0; cnt = 0;
             for (j=1; j<=N; j++) {
                 if ( table[i][j] == '.' ) continue;
                 cnt++;
                 w = 0; l = 0;
                 for (k=1; k<=N; k++) {
                     if ( k == i ) continue;
                     if ( table[j][k] == '1' ) w++;
                     else if ( table[j][k] == '0' ) l++;
                 }
                 if ( w+l != 0 ) owp[i] += (double)w/(w+l);
             }
             if ( cnt != 0 ) owp[i] = owp[i]/cnt;
             sowp += owp[i];
         }
 
         for (i=1; i<=N; i++) {
             oowp[i] = 0; cnt = 0;
             for (j=1; j<=N; j++) {
                 if ( table[i][j] == '.' ) continue;
                 cnt++;
                 oowp[i] += owp[j];
             }
             oowp[i] = oowp[i]/cnt;
         }
 
         printf("Case #%d:\n", t);
         for (i=1; i<=N; i++) {
             printf("%.8lf\n", wp[i]*0.25 + owp[i]*0.5 + oowp[i]*0.25);
         }
     }
 
     return 0;
 }
 

