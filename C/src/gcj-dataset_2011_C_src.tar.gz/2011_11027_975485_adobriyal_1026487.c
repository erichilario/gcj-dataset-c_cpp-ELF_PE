#include <string.h>
 #include<stdio.h>
 #include<stdlib.h>
 #include <iostream>
 #include <stack>
 #include <vector>
 #include <string>
 #include<list>
 #include <algorithm>
 #include <map>
 #include<math.h>
 
 #define INF 2000000000
 #define INF_L 2000000000000000LL
 #define pri(v) cout<<" "<<v<<" ";
 #define pr(s)	cout<<s;     //note cin and cout are 3 times slower than printf and scanf
 #define forr(i,n)  for(i=0;i<n;i++)
 #define dbg(v) cout<<endl<<" debug: "<<v<<endl;
 #define hi cout<<" hi "<<endl;
 #define dem(a,n) a=(int**)malloc(sizeof(int*)*n);
 #define dems(a,n) a=(int*)malloc(sizeof(int)*n);
 
 #define dem_s(a,n) a=(char**)malloc(sizeof(char*)*n);
 #define dems_s(a,n) a=(char*)malloc(sizeof(char)*n);
 
 #define decs(a,n) a=(int*)calloc(sizeof(int),n);
 #define space cout<<endl;
 #define swap(a,b,c) {temp=a[b];a[b]=a[c];a[c]=temp;} 
 #define sca(a) scanf("%d",&a);
 
 #define R 1000000000007
 
 using namespace std;
 int sum,j;
 
 
 int main(){
 
 	int nn,n,ii,flag, m ,i , j, k,sum;
 	int a, b;
 	
 	char buf[15],temp[15];
 	
 	sca(nn)
 	
 
 	int COMB[36][36];
 	int OPP[36][36];
 	
 	forr(ii,nn){
 		sca(a)
 		
 		forr(j,26)
 			forr(k,26){
 				COMB[j][k]=-1;
 				OPP[j][k]=0;
 			}
 		
 		forr(j,a){
 			scanf("%s",buf);	
 			COMB[buf[0]-65][buf[1]-65]=buf[2]-65;
 			COMB[buf[1]-65][buf[0]-65]=buf[2]-65;
 		}
 		
 		sca(a)
 		forr(j,a){
 			scanf("%s",buf);	
 			OPP[buf[0]-65][buf[1]-65]=1;
 			OPP[buf[1]-65][buf[0]-65]=1;
 		}
 		
 		sca(n)	//read the input now
 		scanf("%s",buf);
 		
 		temp[0]=buf[0];
 
 		k=0;
 		//now do the simulation	
 		for(i=1;i<n;i++){
 			if(k==-1){
 				temp[0]=buf[i];
 				k=0;
 				continue;
 			}
 			//now try to reduce
 			if((COMB[buf[i]-65][temp[k]-65]>=0) || (COMB[temp[k]-65][buf[i]-65]>=0)){
 				temp[k]=COMB[buf[i]-65][temp[k]-65]+65;
 				continue;
 			}
 			
 			j=k; flag=0;
 			for(j=k;j>=0;j--){
 				if(OPP[buf[i]-65][temp[j]-65]){
 					flag=1;
 					k=-1;
 					break;
 				}
 			}
 			
 			if(flag==0){	//nothing of above holds , so just push
 				temp[k+1]=buf[i];
 				k++;
 			}
 				
 		}
 		
 		printf("Case #%d: [",ii+1);
 		forr(i,k+1){
 			printf("%c",temp[i]);
 			if(i!=k)
 			printf(", ");
 		}
 		printf("]\n");
 	}
 }
 
 
 
 

