#include <stdio.h>
 #include <string.h>
 
 unsigned int shaun_xor = 0;
 unsigned int patrick_xor = 0;
 
 #define MAX_CANDIES 1000
 int candies;
 int candy[MAX_CANDIES + 1];
 
 #define __max(a,b)          ((a) > (b) ? (a) : (b))
 #define max(a,b)            __max((a), (b))
 
 int patrick_sum = 0;
 
 int probe(int at)
 {
   int yes, no;
   if (at == candies) {
     shaun_xor ^= candy[at];
     if (patrick_sum && (shaun_xor == patrick_xor)) {
       // printf(" %d:S\n", at);
       shaun_xor ^= candy[at];
       return candy[at];
     } else {
       shaun_xor ^= candy[at];
       patrick_xor ^= candy[at];
       if (shaun_xor == patrick_xor) {
         // printf(" %d:P\n", at);
         patrick_xor ^= candy[at];
         return 0;
       } else {
         // printf(" %d:!\n", at);
         patrick_xor ^= candy[at];
         return -1;
       }
     }
   } else {
     // printf(" %d:S", at);
     shaun_xor ^= candy[at];
     yes = probe(at + 1);
     shaun_xor ^= candy[at];
     // printf(" %d:P", at);
     patrick_xor ^= candy[at];
     patrick_sum += candy[at];
     no = probe(at + 1);
     patrick_xor ^= candy[at];
     patrick_sum -= candy[at];
     if (no == -1) {
       if (yes == -1)
         return -1;
       else
         return (candy[at] + yes);
     } else {
       if (yes == -1)
         return no;
       else return max(no, candy[at] + yes);
     }
   }
 }
 
 int main(int argc, char **argv)
 {
   int i;
   int testcases;
   FILE *fi = fopen(argv[1], "rt");
   FILE *fo = fopen("result", "wt");
   fscanf(fi, "%d", &testcases);
   for (i = 0; i < testcases; i++) {
     int j, result;
     shaun_xor = 0;
     patrick_xor = 0;
     fscanf(fi, "%d", &candies);
     for (j = 1; j <= candies; j++)
       fscanf(fi, "%d", &candy[j]);
     result = probe(1);
     if (result == -1)
       fprintf(fo, "Case #%d: NO\n", i + 1);
     else
       fprintf(fo, "Case #%d: %d\n", i + 1, result);
   }
   fclose(fi);
   fclose(fo);
   return 0;
 }

