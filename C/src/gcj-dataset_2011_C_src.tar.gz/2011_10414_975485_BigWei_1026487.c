#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 char table_compose[270][270];
 int table_oppose[270][270];
 int top=0;
 int main(){
 	int n;
 	int i,j,k,l,m;
 	int n_base;
 	int n_opp;
 	int n_input;
 	char base[5000];
 	char opp[5000];
 	char stack[1500];
 	scanf("%d",&n);
 	for(i=0 ; i< n ;i++){
 		memset(table_compose,0,sizeof(table_compose));
 		memset(table_oppose,0,sizeof(table_oppose));
 		memset(stack,0,sizeof(stack));
 		top=0;	
 		scanf("%d ",&n_base);
 		for(j=0;j<n_base;j++){
 			scanf("%s",base);
 			table_compose[base[0]][base[1]] = table_compose[base[1]][base[0]]= base[2];		
 		}
 		scanf("%d ",&n_opp);
 		for(j = 0; j < n_opp ; j++){
 			scanf("%s",opp);
 			table_oppose[opp[0]][opp[1]] = table_oppose[opp[1]][opp[0]] = 1;
 		}
 		scanf("%d ",&n_input);
 		for(j=0;j<n_input;j++){
 			stack[top++] = getchar();
 			while(process(stack)){
 				// process check if there is composed or opposed 
 			}
 		}
 		printf("Case #%d: [",i+1);
 		for(j=0;j<top;j++){
 			if(j==0)
 				printf("%c",stack[j]);
 			else
 				printf(", %c",stack[j]);
 		}
 		printf("]\n");
 
 	}
 
 
 }
 
 int process(char stack[150]){
 	int i,j;
 	if(top-2>=0){
 		if(table_compose[stack[top-1]][stack[top-2]] !=0){
 			stack[top-2]=table_compose[stack[top-1]][stack[top-2]];
 			stack[top-1]=0;
 			top--;
 			return 1;
 		}
 	}
 	for(i=0;i<top;i++){
 		if(table_oppose[stack[i]][stack[top-1]]==1){
 			memset(stack,0,sizeof(stack));
 			top=0;
 			return 1;
 		}
 	}
 
 	return 0;
 
 
 }

