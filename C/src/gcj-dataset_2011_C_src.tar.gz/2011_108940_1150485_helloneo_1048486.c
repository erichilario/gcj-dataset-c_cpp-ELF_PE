#include <stdio.h>
 #include <string.h>
 char map[110][110];
 int n;
 double wp[110], owp[110], oowp[110];
 int main()
 {
     int tc, cn;
     int i, j, k;
     int g, w, l, cnt;
     double wpsum;
     scanf("%d", &tc);
     for (cn = 1; cn <= tc; cn++) {
         scanf("%d", &n);
         for (i = 0; i < n; i++) {
             scanf("%s", map[i]);
         }
         for (i = 0; i < n; i++) {
             wp[i] = owp[i] = oowp[i] = 0;
         }
 
         for (i = 0; i < n; i++) {
             g = 0;
             w = 0;
             l = 0;
             for (j = 0; j < n; j++) {
                 if (map[i][j] == '.')
                     continue;
                 else if (map[i][j] == '1') {
                     g++;
                     w++;
                 }
                 else {
                     g++;
                     l++;
                 }
             }
             wp[i] = (double)w / (double)g;
 
             /* throw out i */
             cnt = 0;
             wpsum = 0.0;
             for (j = 0; j < n; j++) {
                 if (j == i)
                     continue;
                 if (map[j][i] == '.')
                     continue;
                 g = 0;
                 w = 0;
                 l = 0;
                 for (k = 0; k < n; k++) {
                     if (i == k)
                         continue;
                     if (map[j][k] == '.')
                         continue;
                     g++;
                     if (map[j][k] == '1') {
                         w++;
                     }
                     else {
                         l++;
                     }
                 }
                 if (g) {
                     cnt++;
                     wpsum += (double)w / (double)g;
                 }
             }
             owp[i] = wpsum / (double)cnt;
         }
 
         for (i = 0; i < n; i++) {
             cnt = 0;
             for (j = 0; j < n; j++) {
                 if (map[i][j] != '.') {
                     oowp[i] += owp[j];
                     cnt++;
                 }
             }
             oowp[i] /= (double)cnt;
         }
         printf("Case #%d:\n", cn);
         for (i = 0; i < n; i++) {
             printf("%.10lf\n", 0.25*wp[i] + 0.50*owp[i] + 0.25*oowp[i]);
         }
     }
     return 0;
 }

