#include<stdio.h>
 char final[20],input[20];
 int map[27][27],k1[27],k2[27];
 int comb(int a,int b){
 	if(a<0)return 0;
 	else
 		return map[a][b];
 }
 void print(int cs,int size){
 	int i;
 	if(size==0)
 		printf("Case #%d: []\n",cs);
 	else{
 	printf("Case #%d: [",cs);
 	for(i=0;i<size-1;i++){
 		printf("%c, ",final[i]);
 	}
 	printf("%c]\n",final[i]);
 	}
 }
 int main(){
 	int t,i,j,c,a,n,b,m,size,prev;
 	char ch;
 	scanf("%d",&t);
 
 	for(i=1;i<=t;i++){
 		size=0;
 		memset(map,0,sizeof(map));
 		memset(k1,0,sizeof(k1));
 		memset(k2,0,sizeof(k2));
 		memset(final,0,sizeof(final));
 		scanf("%d",&c);
 		for(j=0;j<c;j++){
 			scanf(" %c",&ch);
 			a=ch-64;
 			scanf("%c",&ch);
 			b=ch-64;
 			scanf("%c",&ch);
 			m=ch-64;
 			map[a][b]=m;
 			map[b][a]=m;
 		}
 
 		scanf("%d",&c);
 		for(j=0;j<c;j++){
 			scanf(" %c",&ch);
 			a=ch-64;
 			scanf("%c",&ch);
 			b=ch-64;
 			k1[a]=b;
 			k1[b]=a;
 		}
 		scanf("%d ",&n);
 		prev=-1;
 		gets(input);
 		for(j=0;j<n;j++){
 			ch=input[j];
 			a=ch-64;
 			if(comb(prev,a)){
 				final[size-1]=map[prev][a]+64;
 				k2[prev]-=1;
 				prev=map[prev][a];
 				continue;
 			}
 
 			if(k2[k1[a]]){
 				k2[k1[a]]=0;
 				size=0;
 				memset(final,0,sizeof(final));
 				prev=-1;
 				continue;
 			}
 			else{
 				k2[a]+=1;
 							
 			}
 			prev=a;
 			final[size++]=ch;
 
 		}
 
 		print(i,size);
 	}
 	//system("PAUSE");
 	return 0;
 }

