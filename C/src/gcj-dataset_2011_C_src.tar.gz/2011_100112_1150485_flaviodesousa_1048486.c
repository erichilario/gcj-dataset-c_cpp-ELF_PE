#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char games[100][101];
 int wins[100];
 int plays[100];
 double WP[100];
 double OWP[100];
 
 int main(int argc, char**argv)
 {
 	if (argc != 2) exit(1);
 	FILE *in = fopen(argv[1], "rt");
 	if (!in) {
 		ferror(in);
 	}
 	FILE *out = fopen("output.txt", "wt");
 	int T=0;
 	fscanf(in,"%d",&T);
 	int i,j,k,l,m,n;
 	for (i = 0; i < T; i++) {
 		int N;
 		fscanf(in,"%d",&N);
 
 		printf("Case #%d:\n", i + 1);
 		fprintf(out, "Case #%d:\n", i + 1);
 
 		memset(wins, 0, sizeof wins);
 		memset(plays, 0, sizeof plays);
 
 		for (j=0; j<N; j++) {
 			char *cp = games[j];
 			fscanf(in, "%s", cp);
 			while (*cp) {
 				if (*cp != '.') {
 					plays[j]++;
 					if (*cp == '1') {
 						wins[j]++;
 					}
 				}
 				cp++;
 			}
 		}
 
 		for (j=0; j<N; j++) {
 			WP[j] = wins[j] / (double)plays[j];
 		}
 
 		for (j=0; j<N; j++) {
 			double owps = .0;
 			int owpc = 0;
 			for (k=0; k<N; k++) {
 				if(j==k||games[j][k]=='.')continue;
 				int ww = games[k][j]=='1';
 				owps += (wins[k]-ww)/(plays[k]-1.0); owpc++;
 			}
 			OWP[j] = owps/owpc;
 		}
 
 		for (j=0; j<N; j++) {
 			double rpi = .25 * WP[j] + .5 * OWP[j];
 			double oowps = 0.0;
 			int oowpc = 0;
 			for (k=0; k<N; k++) {
 				if (k==j||games[j][k]=='.') continue;
 				oowps += OWP[k]; oowpc++;
 			}
 			rpi += .25 * oowps / oowpc;
 			printf("%.12lf\n",rpi);
 			fprintf(out, "%.12lf\n",rpi);
 		}
 	}
 	fclose(in);
 	fclose(out);
 }

