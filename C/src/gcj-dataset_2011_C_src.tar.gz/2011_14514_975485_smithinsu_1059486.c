#include<stdio.h>
 int n,ans,given[1001],ar[100];
 void f(int candy,int a,int b)
 {
 //	printf("%d %d %d\n",candy,a,b);
 	if(candy==n)
 	{
 		int flag,temp,temp2,i;
 		if(a==b)
 		{
 			flag=1;
 			temp=0;
 			temp2=0;
 			for(i=0;i<n;i++)
 			{
 				if(given[i]==0)
 					temp+=ar[i];
 				else
 					temp2+=ar[i];
 			}
 			if(temp==0||temp2==0)
 				return;
 			if(temp>ans)
 				ans=temp;
 			if(temp2>ans)
 				ans=temp2;
 		}
 		return ;
 	}
 	given[candy]=0;
 	f(candy+1,a^ar[candy],b);
 	given[candy]=1;
 	f(candy+1,a,b^ar[candy]);
 }
 int main()
 {
 	int t,i,j;
 	scanf("%d",&t);
 	for(i=1;i<=t;i++)
 	{
 		scanf("%d",&n);
 		for(j=0;j<n;j++)
 			scanf("%d",&ar[j]);
 //		for(j=0;j<n;j++)
 //			printf("%d ",ar[j]);
 //		printf("\n");
 		ans=-1;
 		f(0,0,0);
 		if(ans==-1)
 		{
 			printf("Case #%d: NO\n",i);
 		}
 		else
 		{
 			printf("Case #%d: %d\n",i,ans);
 		}
 	}
 	return 0;
 }

