#include<stdio.h>
 #include<string.h>
 char arr1[1000],str[1000];
 char comb[100][1000];
 char arr2[100][1000];
 int d,c;
 int check(char ch)
 {
 	int i,j,x;
 	x=strlen(arr1);
 	if(x>0)
 	  	for(j=0;j<c;j++)
 	  	{
 	  	if((arr1[x-1]==comb[j][0] && ch==comb[j][1]) || (arr1[x-1]==comb[j][1] && ch==comb[j][0])) { arr1[x-1]=comb[j][2]; arr1[x]='\0'; return 1;}
 	  	}
 	return 0;  	
 }
 int dissolve(char ch)
 {
 	int i,j;
 	for(i=0;arr1[i]!='\0';i++)
 	  {
 	  	for(j=0;j<d;j++)
 	  	  if((arr1[i]==arr2[j][0] && ch==arr2[j][1]) || (arr1[i]==arr2[j][1] && ch==arr2[j][0])) { arr1[0]='\0'; return 1 ; }
 	  }
 	return 0;
 }
 
 int main()
 {
 	int x,i,n,test,j;
 	freopen("B.in","r",stdin);
 	freopen("B.txt","w",stdout);
 
     scanf("%d",&test);
     for(j=1;j<=test;j++)
     {
     	arr1[0]='\0';
      scanf("%d",&c);
      for(i=0;i<c;i++)
      scanf("%s",comb[i]);
      
      
      scanf("%d",&d);
      for(i=0;i<d;i++)
      scanf("%s",arr2[i]);
      
      
      scanf("%d",&n);
      scanf("%s",str);
      
      for(i=0;str[i]!='\0';i++)
      {
      	x=strlen(arr1);
      if(!check(str[i]))
      	if(!dissolve(str[i])) {arr1[x]=str[i]; arr1[x+1]='\0';}
 
 	 }
      printf("Case #%d: [",j);
      for(i=0;arr1[i]!='\0';i++)
       {	if(i==0) printf("%c",arr1[i]);
       	else printf(", %c",arr1[i]);
        }
  printf("]\n");
     }
 }
 

