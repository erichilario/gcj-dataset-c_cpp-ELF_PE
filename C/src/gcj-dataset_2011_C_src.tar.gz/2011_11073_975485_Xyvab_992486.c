#include <stdio.h>
 #include <stdlib.h>
 
 int main (void)
 {
     FILE *stream;
     FILE *maerts;
     int T;
     int N;
     int i;
     int ry[N];
     double counter = 0;
     int casee = 0;
     stream = fopen("/Users/Xyvab/Downloads/Dscanme.in", "r");
     maerts = fopen("/Users/Xyvab/Downloads/Dscanme.out", "w");
     
     fscanf(stream, "%d", &T);
     
     if((maerts = freopen("/Users/Xyvab/Downloads/Dscanme.out", "w", stdout)) == NULL) 
     {
         printf("Cannot open file.\n");
         exit(1);
     }
     
     while (T--) 
     {
         counter = 0;
         casee++;
         fscanf(stream, "%d", &N);
         for(i = 0; i < N; i++)
         {
             fscanf(stream, "%d", &ry[i]);
             if(ry[i]!= i+1){
                 counter++;
             }
         }
         printf("Case #%d: %.6f\n", casee, counter);
     }
     
 }
 

