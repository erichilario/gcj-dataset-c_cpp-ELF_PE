#include <stdio.h>
 
 int main()
 {
 	int T, a;
 	scanf("%d", &T);
 	for (a=1;a<=T;a++){
 		int n;
 		char arr[105][105];
 		double WP[105], OWP[105], OOWP[105];
 		int i, j;
 		scanf("%d\n", &n);
 		for (i=0;i<n;i++)
 			gets(arr[i]);
 
 		//WP 계산
 		for (i=0;i<n;i++){
 			int wincount = 0;
 			int playcount = 0;
 			for (j=0;j<n;j++){
 				if (arr[i][j] != '.') playcount++;
 				if (arr[i][j] == '1') wincount++;
 			}
 			WP[i] = (double)wincount / playcount;
 		}
 		//OWP 계산
 		for (i=0;i<n;i++){
 			//i번째 플레이어와의 경기를 제외한 j 플레이어의 승률을 계산
 			double sum = 0;
 			int iplaycount = 0;
 			for (j=0;j<n;j++){
 				if (arr[i][j] != '.'){
 					int k;
 					int wincount = 0;
 					int playcount = 0;
 					for (k=0;k<n;k++){
 						if (k == i) continue;
 						if (arr[j][k] != '.') playcount++;
 						if (arr[j][k] == '1') wincount++;
 					}
 					iplaycount++;
 					sum += (double)wincount / playcount;
 
 				}
 			}
 			OWP[i] = (double)sum / iplaycount;
 		}
 
 		//OOWP 계산
 		for (i=0;i<n;i++){
 			double sum = 0.0;
 			int count = 0;
 			for (j=0;j<n;j++){
 				if (arr[i][j] != '.'){
 					sum += OWP[j];
 					count++;
 				}
 			}
 			OOWP[i] = sum / count;
 		}
 
 		printf("Case #%d:\n", a);
 		for (i=0;i<n;i++){
 			double RPI = (0.25*WP[i]) + (0.5*OWP[i]) + (0.25*OOWP[i]);
 			printf("%.12lf\n", RPI);
 		}
 	}
 	return 0;
 }

