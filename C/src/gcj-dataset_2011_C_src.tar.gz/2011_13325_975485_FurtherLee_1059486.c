#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 FILE *fin,*fout;
 int S,P,flag,best;
 int T,N;
 unsigned long A[1000];
 unsigned long SumS,SumP;
 
 int cmp(const void *a,const void *b){
 	return *(int *)a < *(int *)b;
 }
 
 void seek(int dep){
 	if(dep == N){
 		//fprintf(fout,"%d:%d %d:%d\n",S,SumS,P,SumP);
 		if(SumS == SumP && S != 0 && P != 0){
 			flag = 1;
 			if(best < S) best = S;
 			if(best < P) best = P;
   		}
  	}
  	else{
  		if(S < best && P < best) return;
    		P += A[dep];
      	S -= A[dep];
      	SumS = SumS^A[dep];
      	SumP = SumP^A[dep];
      	seek(dep+1);
      	P -= A[dep];
      	S += A[dep];
      	SumS = SumS^A[dep];
      	SumP = SumP^A[dep];
      	seek(dep+1);
   	}
  	return;
 }
 
 void work(int num){
 	int i;
 	best = 0;
 	flag = 0;
 	S = 0;
 	P = 0;
 	SumS = 0;
 	SumP = 0;
 	fscanf(fin,"%d",&N);
 	for(i = 0 ; i < N ; ++i){
  		fscanf(fin,"%d",&A[i]);
  		S += A[i];
  		SumS = SumS^A[i];
   	}
   	qsort(A,N,sizeof(A[0]),cmp);
   	seek(0);
   	fprintf(fout,"Case #%d: ",num);
   	if(flag == 0) fprintf(fout,"NO\n");
   	else fprintf(fout,"%d\n",best);
 }
 
 int main(){
 	fin = fopen("Candy.in","r");
 	fout = fopen("Candy.out","w");
 	fscanf(fin,"%d",&T);
  	int i;
     for(i = 0 ; i < T ; ++i) work(i+1);	
 	close(fin);
 	close(fout);
 	return 0;
 }

