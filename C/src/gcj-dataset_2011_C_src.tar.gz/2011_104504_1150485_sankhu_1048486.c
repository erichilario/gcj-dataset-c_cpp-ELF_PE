#include<stdio.h>
 #include<stdlib.h>
 #include<conio.h>
 int main()
 {
     FILE *fp,*fp1;
     int test,t=1,N,rec[101][2];
     float wp[101],owp[101],oowp[101],ans[101];
     char his[101][101];
     fp = fopen("input.txt","r");
     fp1 = fopen("output.txt","w");
     fscanf(fp,"%d",&test);
     while(t<=test)
     {
                   fscanf(fp,"%d",&N);
                   int i,j;
                   for(i=0;i<N;i++)
                   {
                                   fscanf(fp,"%s",&his[i]);
                                   rec[i][0]=0;
                                   rec[i][1]=0;
                                   for(j=0;j<N;j++)
                                   {
                                                   if(his[i][j]=='1')
                                                   {
                                                        rec[i][0]++;
                                                        rec[i][1]++;
                                                   }
                                                   else if(his[i][j]=='0')
                                                        rec[i][1]++;
                                   }
                                   wp[i] = ((float)rec[i][0])/rec[i][1];
                                   //fprintf(fp1,"%f\n",wp[i]);
                   }
                   for(i=0;i<N;i++)
                   {
                        int count = 0;
                        float temp=0;
                        for(j=0;j<N;j++)
                        {
                            if(his[i][j]=='1')
                            {
                                temp = temp + ((float)rec[j][0])/(rec[j][1]-1);
                                /*if(i==1)fprintf(fp1,"%d %f\n",j,temp);*/
                                count++;
                            }
                            else if(his[i][j]=='0')
                            {
                                 temp = temp + ((float)(rec[j][0]-1))/(rec[j][1]-1);
                                 /*if(i==1&&j==2)fprintf(fp1,"%d %d\n",rec[j][0],rec[j][1]);
                                 if(i==1)fprintf(fp1,"%d %f\n",j,temp);*/
                                 count++;
                            }
                        }
                        //fprintf(fp1,"%d\n",count);
                        owp[i] = temp/count;
                        //fprintf(fp1,"%f\n",owp[i]);
                   }
                   for(i=0;i<N;i++)
                   {
                       int count=0;
                       float temp=0;
                       for(j=0;j<N;j++)
                       {
                               if(his[i][j]!='.')
                               {
                                                 temp = temp+owp[j];
                                                 count++;
                               }
                       }
                       oowp[i]=temp/count;
                   }
                   fprintf(fp1,"Case #%d:\n",t);
                   for(i=0;i<N;i++)
                   {
                        fprintf(fp1,"%.8f\n",0.25*wp[i]+0.50*owp[i]+0.25*oowp[i]);
                   }
                   t++;
     }
     getch();
     fclose(fp);
 }

