/* magicka */
 #include <stdio.h>
 #include <stdlib.h>
 
 int main(){
   int T;
   int c,d,n;
   char *C, *D, *str;
   char *tmp_str;
   int tmp_int=12;
   int out=0;
 
   tmp_str = (char*)malloc(12);
   C = (char*)malloc(5);
   D = (char*)malloc(4);
   str = (char*)malloc(12);
 
   getline(&tmp_str,&tmp_int,stdin);
 
   T = atoi(tmp_str);
 
   while(T > 0){
     int first;
     int i,already_found_d,next_d;
     getline(&tmp_str,&tmp_int,stdin);
     c = atoi(tmp_str);
 
     if(c)
       getline(&C,&tmp_int,stdin);
 
     getline(&tmp_str,&tmp_int,stdin);
     d = atoi(tmp_str);
 
     if(d)
       getline(&D,&tmp_int,stdin);
 
     getline(&tmp_str,&tmp_int,stdin);
     n = atoi(tmp_str);
     
     getline(&str,&tmp_int,stdin);
 
 
     already_found_d = 0;
     next_d=-1;
     i=0;
     while(str[i+1] != '\0'){
       if(d && (already_found_d) && (str[i] == D[next_d])){
 	int j;
 	for(j = already_found_d - 1;j <= i;j++)
 	  str[j] = '0';
 	already_found_d = 0;
 	next_d = -1;
 	i++;
       }
       else if(c && (((str[i] == C[0]) && (str[i+1] == C[1])) || ((str[i] == C[1]) && (str[i+1] == C[0])))){
 
 	if(str[i+1] == D[next_d]){
 	  already_found_d = 0;
 	  next_d = -1;
 	}
 	str[i]='0';
 	str[i+1] = C[2];
 
 	i++;
       }
       else if(d && (str[i] == D[0]) && !already_found_d){
 	next_d = 1;
 	i++;
 	already_found_d=i;
       }
       else if(d && (str[i] == D[1]) && !already_found_d){
 	next_d = 0;
 	i++;
 	already_found_d = i;
       }
       else{
 	i++;
       }
     }
 
     out++;
     printf("Case #%d: [",out);
    
     for(i=0, first=1;i<n;i++){
 
       if(str[i] != '0'){
 
 	if(first){
 	  printf("%c",str[i]);
 	  first=0;
 	}
 
 	else{
 	  printf(", %c",str[i]);
 	}
       }
     }
     printf("]\n");
     T--;
   }
   return 0;
 }
 
 

