#include <stdio.h>
 
 double wp[105],owp[105],oowp[105];
 char klasemen[105][105];
 int n;
 
 void countWP(){
     int i,j;
 
     for(i=0;i<n;i++){
         int count=0;
         for(j=0;j<n;j++)
         {
             if(klasemen[i][j]=='1' || klasemen[i][j]=='0')
             {
                 count++;
                 wp[i]+=klasemen[i][j]-'0';
             }
         }
         wp[i]/=count;
     }
 }
 
 void countOWP(){
     int i,j,k;
     double WP;
 
     for(i=0;i<n;i++){
         int count=0;
         for(j=0;j<n;j++)
         {
             if(klasemen[i][j]=='1' || klasemen[i][j]=='0')
             {
                 count++;
                 WP=0;
                 int c=0;
                 for(k=0;k<n;k++){
                     if((klasemen[j][k]=='1'||klasemen[j][k]=='0')&&k!=i)
                     {
                           c++;
                           WP += klasemen[j][k]-'0';
                     }
                 }
                 WP/=c;
                 owp[i]+=WP;
             }
         }
         owp[i]/=count;
     }
 }
 
 void countOOWP(){
 
     int i,j;
 
     for(i=0;i<n;i++){
         int count=0;
         for(j=0;j<n;j++)
         {
             if(klasemen[i][j]=='1' || klasemen[i][j]=='0')
             {
                 count++;
                 oowp[i]+=owp[j];
             }
         }
         oowp[i]/=count;
     }
 
 }
 
 int main(){
 
     freopen("ALinput.in","r",stdin);
     freopen("output.txt","w",stdout);
 
     int t,k,i,j;
 
     scanf("%d",&t);
     for(k=1;k<=t;k++){
         scanf("%d",&n);
         getchar();
         for(i=0;i<n;i++)
             gets(klasemen[i]);
 
         memset(wp,0,sizeof(wp));
         memset(owp,0,sizeof(owp));
         memset(oowp,0,sizeof(oowp));
 
         countWP();
         countOWP();
         countOOWP();
 
         printf("Case #%d:\n",k);
         for(i=0;i<n;i++){
             //printf("%f %f %f\n",wp[i],owp[i],oowp[i]);
             printf("%f\n",wp[i]*0.25+owp[i]*0.5+oowp[i]*0.25);
         }
     }
     return 0;
 }

