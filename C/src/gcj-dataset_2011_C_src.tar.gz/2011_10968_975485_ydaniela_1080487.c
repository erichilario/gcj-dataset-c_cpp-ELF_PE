#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct _no {
 	char robot;
 	int pos;
 	int used;
 } no;
 
 int main() {
     int i, j, k, l, m, n, o, p, q, r, s, t, b;
     char c;
     no com[105];
     
     scanf(" %d ", &t);
     for (p = 1; p <= t; p++) {
     	scanf(" %d ", &m);
     	
     	o = 1;
 		b = 1;
 		n = 0;
 		q = 0;
 		r = 0;
     	
     	while (m--) {
 			scanf(" %c %d ", &c, &s);
 
 			if (c == 'O') {
 				if (s > o) {
 					if (s - o + 1 <= r) {
 						r = 0;
 						q++;
 						n++;
 					} else {
 						n = n + s - o + 1 - r;
 						q = q + s - o + 1 - r;
 						r = 0;
 					}
 				} else if (s < o) {
 					if (o - s + 1 <= r) {
 						r = 0;
 						q++;
 						n++;
 					} else {
 						n = n + o - s + 1 - r;
 						q = q + o - s + 1 - r;
 						r = 0;
 					}
 				} else {
 					if (r >= 1) {
 						r = 0;
 						q++;
 						n++;
 					} else {
 						n++;
 						q++;
 					} 
 				}
 				o = s;
 			} else if (c == 'B') {
 				if (s > b) {
 					if (s - b + 1 <= q) {
 						q = 0;
 						r++;
 						n++;
 					} else {
 						n = n + s - b + 1 - q;
 						r = r + s - b + 1 - q;
 						q = 0;
 					}
 				} else if (s < b) {
 					if (b - s + 1 <= q) {
 						q = 0;
 						r++;
 						n++;
 					} else {
 						n = n + b - s + 1 - q;
 						r = r + b - s + 1 - q;
 						q = 0;
 					}
 				} else {
 					if (q >= 1) {
 						q = 0;
 						r++;
 						n++;
 					} else {
 						n++;
 						r++;
 					} 
 				}
 				b = s;
 			}	
 		}
 
 		printf("Case #%d: %d\n", p, n);
 
 	}
     return 0;
 }

