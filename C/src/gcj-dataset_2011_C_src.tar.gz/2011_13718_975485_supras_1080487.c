/* small set bottrust */
 #include <stdio.h>
 #include <stdlib.h>
 
 #define MAX_B 100
 #define MAX_T 100
 #define MAX_IN 4*MAX_B + 2 + 1
 
 int time_req(int O[],int B[],char seq[],int on,int bn,int seqn){
   int t=0,oi=0,bi=0,seqi=0,curo=1,curb=1;
   int oopdone=0,bopdone=0;
 
   while(seqi < seqn){
 
     if(curo == O[oi] && seq[seqi] == 'O'){
       seqi++;
       oi++;
       oopdone=1;
     }
 
     else if(curb == B[bi] && seq[seqi] == 'B'){
       seqi++;
       bi++;
       bopdone=1;
     }
  
     if(curo > O[oi] && !oopdone)
       curo--;
     else if(curo < O[oi] && !oopdone)
       curo++;
     
     if(curb > B[bi] && !bopdone)
       curb--;
     else if(curb < B[bi] && !bopdone)
       curb++;
 
     t++;
     oopdone=0;
     bopdone=0;
   }
   return t;
 }
 /*
 int mod(int a){
   if(a < 0)
     return a * -1;
   else
     return a;
 }
 */
 int main(){
 
   int T,N,b,i;
   char c,dummy;
   int O[MAX_B],B[MAX_B],oi,bi;
   char seq[MAX_B];
   int seqi;
   int OUT[MAX_T],ti;
   char *IN;
   int max_in = MAX_IN;
   int j;
 
   int pob,pbb;
 
   //scanf("%d",&T);
  
 
   ti=0;
 
   IN = (char*) malloc(MAX_IN);
 
   getline(&IN,&max_in,stdin);
   T = atoi(&IN[0]);
   
 while(T > 0){
     int tmpb,tmpo,output;
     //    scanf("%d",&N);
 
     oi=0;
     bi=0;
     getline(&IN,&max_in,stdin);
     N = atoi(IN);
 
     // j=2;
     pob=1;pbb=1;
     tmpb=0;tmpo=0;
     seqi=0;
 
     while(N > 0){
       //scanf("%c%d",&c, &b);
       getline(&IN,&max_in,stdin);
       c = IN[0];
       getline(&IN,&max_in,stdin);
       b = atoi(IN);
 
       switch(c){
       case 'O':
 	//tmpb += mod (b - pob) + 1;
 	//pob = b;
 	O[oi]=b;
 	oi++;
 	seq[seqi]='O';
 	seqi++;
 	break;
 
       case 'B':
 	B[bi]=b;
 	bi++;
 	seq[seqi]='B';
 	seqi++;
 	//tmpo += mod(b - pbb) + 1;
 	//pbb = b;
 	break;
   
       default:
 	printf("OOPS ! something wrong in input \n");
 	exit(0);
       }
       N--;
       //j+=4;
     }
 
     output = time_req(O,B,seq,oi,bi,seqi);
     /* tmpb = time_req(B,bi);
     tmpo = time_req(O,oi);
 
     if(tmpb > tmpo)
       output = tmpb;
     else 
       output = tmpo;
     */
 
     OUT[ti++]=output;
     T--;
   }
   for(i=0;i<ti;i++)
     printf("Case #%d: %d\n",i+1,OUT[i]);
 
   return 0;
 }

