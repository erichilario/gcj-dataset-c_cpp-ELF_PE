#include<stdio.h>
 int main()
 {
 	int t,temp=1;
 	scanf("%d",&t);
 	while(temp<=t)
 	{
 		char cons[36][3],dest[36][2],in[100],out[100];
 		int cc=0,cd=0,ci=0,co=0,flag=0,i,j,prsnt[26],k;
 		for(i=0;i<26;i++)
 		{
 			prsnt[i]=0;
 		}
 		scanf("%d",&cc);
 		for(i=0;i<cc;i++)
 		{
 			scanf("%s",cons[i]);
 		}
 		cons[i][0]='\0';
 		scanf("%d",&cd);
 		for(i=0;i<cd;i++)
 		{
 			scanf("%s",dest[i]);
 		}
 		dest[i][0]='\0';
 		scanf("%d",&ci);
 		if(ci>0)
 		{
 			scanf("%s",in);
 			out[0]=in[0];
 			prsnt[in[0]-65]=prsnt[in[0]-65]+1;
 			co=co+1;
 			out[co]='\0';
 		}
 		else
 		{
 			in[0]='\0';
 		}
 /*			printf("cons=%s dest=%s ci=%d in=%s out=%s\n",cons[0],dest[0],ci,in,out);
 			for(j=0;j<26;j++)
 			{
 			printf("%d ",prsnt[j]);
 			}
 			printf("\n");
 			*/
 		for(i=1;i<ci;i++)
 		{
 			flag=1;
 			out[co]=in[i];
 			co=co+1;
 			out[co]='\0';
 //			printf("pvs=%d of index=%d\n",prsnt[in[i]-65],in[i]-65);
 			prsnt[in[i]-65]=prsnt[in[i]-65]+1;
 //					printf("FOR I=%d in[i]=%c out=%s\n",i,in[i],out);
 //					for(j=0;j<26;j++)
 //					{
 //						printf("%d ",prsnt[j]);
 //					}
 //					printf("\n");
 			
 			while(flag==1)
 			{
 				flag=0;
 				for(j=0;j<cc;j++)
 				{
 					//					printf("b4 cons=%s out=%s\n",cons[j],out);
 					if((out[co-1]==cons[j][0] && out[co-2]==cons[j][1])||(out[co-2]==cons[j][0] && out[co-1]==cons[j][1]))
 					{
 //						printf("cons out[co-2]=%c cons[i][2]=%c out=%s\n",out[co-2],cons[j][2],out);
 						out[co-2]=cons[j][2];
 						flag=1;
 						co=co-1;
 						out[co]='\0';
 						prsnt[cons[j][0]-65]--;
 						prsnt[cons[j][1]-65]--;
 						prsnt[cons[j][2]-65]++;
 //						printf("cons out[co-2]=%c cons[i][2]=%c out=%s pp=%d p=%d nw=%d\n",out[co-2],cons[j][2],out,prsnt[dest[j][0]-65],prsnt[dest[j][1]-65],prsnt[dest[j][2]-65]);
 						break;
 					}
 				}
 	
 			if(flag==0)
 			{
 				for(j=0;j<cd;j++)
 				{
 //					printf("b 4 chk destruct dest[j][0]=%c dest[j][1]=%c out=%s c1=%d c2=%d\n",dest[j][0],dest[j][1],out,prsnt[dest[j][0]-65],prsnt[dest[j][1]-65]);
 					if((prsnt[dest[j][0]-65]>0 && prsnt[dest[j][1]-65]>0))
 					{
 //						printf("destruct dest[j][0]=%c dest[j][1]=%c out=%s c1=%d c2=%d\n",dest[j][0],dest[j][1],out,prsnt[dest[j][0]-65],prsnt[dest[j][1]-65]);
 						co=0;
 						out[co]='\0';
 						prsnt[dest[j][0]-65]--;
 						prsnt[dest[j][1]-65]--;
 //						printf("destruct dest[j][0]=%c dest[j][1]=%c out=%s c1=%d c2=%d\n",dest[j][0],dest[j][1],out,prsnt[dest[j][0]-65],prsnt[dest[j][1]-65]);
 						for(k=0;k<26;k++)
 						{
 							prsnt[k]=0;
 						}					
 						break;
 					}
 				}
 			}
 			}
 		}
 	printf("Case #%d: [",temp);
 	for(i=0;i<co;i++)
 	{
 		if(i==(co-1))
 		{
 			printf("%c]",out[i]);
 		}
 		else
 		{
 			printf("%c, ",out[i]);
 		}
 	}
 	if(co==0)
 	{
 		printf("]");
 	}
 	printf("\n");
 	temp=temp+1;
 }
 return 0;
 }	

