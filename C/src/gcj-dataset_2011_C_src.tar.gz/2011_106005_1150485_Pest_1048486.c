#include<stdio.h>
 int main()
 {
     int pd,pg,flag,i=1,t,flag2=1;
     long long int n,validintegral,j;
     double pdreq,valid;
     char arr1[9]="Possible";
     char arr2[7]="Broken";
     scanf("%d",&t);
     while(t--)
     {
               flag=0;flag2=1;
               scanf("%lld%d%d",&n,&pd,&pg);
               pdreq=((double)pd)/100.0;
               for(j=1;j<=n;j++)
               {
                                valid=pdreq*((double)j);
                                validintegral=(long long int)valid;
                                if(validintegral==valid)
                                {                        flag2=0;break;}
               }
               if(flag2!=0&&pd!=0)
                                     flag=1;  
               if(pd<100)
               {
                         if(pg==100)
                                    flag=1;
               }
               if(pg==0)
               {
                         if(pd>0)
                                    flag=1;
               }
               if(pg==100)
               {
                         if(pd<100)
                                    flag=1;
               }
               if(flag==1)
                          printf("Case #%d: %s\n",i,arr2);
               else if(flag==0)
                          printf("Case #%d: %s\n",i,arr1); 
               
               i++;
     }
     return 0;
 }

