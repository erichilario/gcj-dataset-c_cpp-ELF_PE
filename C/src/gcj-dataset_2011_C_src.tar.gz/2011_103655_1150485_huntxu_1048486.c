#include <stdio.h>
 #include <string.h>
 #define MAX 100
 
 int t, n;
 char sche[MAX][MAX];
 double wp[MAX];
 double owp[MAX];
 double oowp[MAX];
 
 int main()
 {
     int l, k, i, j, win, game, team;
     long double p;
     scanf("%d\n", &t);
     for (l=1; l<=t; l++) {
         memset(wp, 0, MAX*sizeof(double));
         memset(owp, 0, MAX*sizeof(double));
         memset(oowp, 0, MAX*sizeof(double));
         scanf("%d\n", &n);
         for (i=0; i<n; i++) {
             win = 0;
             game = 0;
             for (j=0; j<n; j++) {
                 sche[i][j] = (char)getchar();
                 if (sche[i][j] == '1') {
                     win ++;
                     game ++;
                 }
                 else if (sche[i][j] == '0') {
                     game ++;
                 }
             }
             wp[i] = (double)win/game;
             scanf("\n");
         }
         for (k=0; k<n; k++) {
             p = 0;
             team = 0;
             for (i=0; i<n; i++) {
                 win = 0;
                 game = 0;
                 if (sche[k][i] != '.') {
                     team++;
                     for (j=0; j<n; j++) {
                         if (j!=k) {
                             if (sche[i][j] == '1') {
                                 win ++;
                                 game ++;
                             }
                             else if (sche[i][j] == '0') {
                                 game ++;
                             }
                         }
                     }
                 p += (double)win/game;
                 }
             }
             owp[k] = p/team;
         }
         for (k=0; k<n; k++) {
             p = 0;
             team = 0;
             for (i=0; i<n; i++) {
                 if (sche[k][i] != '.') {
                     p += owp[i];
                     team ++;
                 }
             }
             oowp[k] = p/team;
         }
         printf("Case #%d:\n", l);
         for (k=0; k<n; k++) {
             printf("%.8f\n", 0.25*wp[k]+0.5*owp[k]+0.25*oowp[k]);
         }
     }
     return 0;
 }

