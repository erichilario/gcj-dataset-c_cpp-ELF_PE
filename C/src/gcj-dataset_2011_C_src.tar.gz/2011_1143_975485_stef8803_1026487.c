#include <stdio.h>
 
 char sir[200];
 char mc[36][4];
 char md[28][4];
 int c,d;
 int l;
 void testCombine(){
 	int j;
 	if(l>=1){
 		for(j=0;j<c;++j){
 			if((sir[l-1]==mc[j][0] && sir[l]==mc[j][1]) || (sir[l-1]==mc[j][1] && sir[l]==mc[j][0]) ){
 				sir[l-1] = mc[j][2];
 				--l;
 				break;
 			}
 		}
 	}
 }
 void testDel(){
 	int j,i;
 	if(l>=1){
 		for(j=0;j<d;++j){
 			char o=0;
 			if(sir[l] == md[j][1]){
 				o = md[j][0];
 			}
 			if(sir[l] == md[j][0]){
 				o = md[j][1];
 			}
 			if(o){
 				for(i=0;i<l;++i){
 					if(sir[i]==o){
 						l=-1;
 						break;
 					}
 				}
 			}
 		}
 	}
 }
 
 void go(int nr){
 	int i,n;
 	char x;
 	scanf("%d",&c);
 	for(i=0;i<c;++i){
 		do{
 			scanf("%c",&x);
 		}while(x==' ');
 		mc[i][0]=x;
 		scanf("%c",&x);
 		mc[i][1]=x;
 		scanf("%c",&x);
 		mc[i][2]=x;
 //		printf("C %c%c%c\n",mc[i][0],mc[i][1],mc[i][2]);
 	}
 	scanf("%d",&d);
 	for(i=0;i<d;++i){
 		do{
 			scanf("%c",&x);
 		}while(x==' ');
 		md[i][0]=x;
 		scanf("%c",&x);
 		md[i][1]=x;
 //		printf("D %c%c\n",md[i][0],md[i][1]);
 	}
 	scanf("%d",&n);
 	//printf("READ\n");
 	do{
 		scanf("%c",&x);
 	}while(x==' ');
 	fflush(stdout);
 	sir[0] = x;
 	l=1;
 	for(i=1;i<n;++i){
 		scanf("%c",&x);
 //		printf("%c\n",x);
 		sir[l] = x;
 		testCombine();
 		testDel();
 		l++;
 	}
 	printf("Case #%d: [",nr);
 	int nfirst=0;
 	for(i=0;i<l;++i){
 		if(nfirst)
 			printf(", ");
 		else
 			nfirst=1;
 		printf("%c",sir[i]);
 	}
 	printf("]\n");
 	fflush(stdout);
 }
 
 int main(){
 	int T,i;
 	scanf("%d",&T);
 	for(i=1;i<=T;++i){
 		go(i);
 	}
 	return 0;
 }

