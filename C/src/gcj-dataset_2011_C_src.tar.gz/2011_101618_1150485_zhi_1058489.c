#include <math.h>
 #include <stdio.h>
 int main()
 {
 	int i,j,k,T,C,D,P[200],V[200],total_V;
 	double interval,center,head,tail,step,now,diff,max;
 	scanf("%d",&T);
 	for(i=0;i<T;i++)
 	{
 		scanf("%d%d",&C,&D);
 		total_V=0;
 		for(j=0;j<C;j++)
 		{
 			scanf("%d%d",&P[j],&V[j]);
 			total_V+=V[j];
 		}
 		center=(double)(P[0]+P[C-1])/2;
 		interval=(double)D*(total_V-1);
 		head=center-(interval/2);
 		tail=center+(interval/2);
 		step=interval/(total_V-1);
 		now=head;
 		max=0.0;
 		for(j=0;j<C;j++)
 			for(k=0;k<V[j];k++)
 			{
 				diff=fabs(now-P[j]);
 				if(max<diff)
 					max=diff;
 				now+=step;
 			}
 		printf("Case #%d: %.1lf\n",i+1,max);
 	}
 	return 0;
 }

