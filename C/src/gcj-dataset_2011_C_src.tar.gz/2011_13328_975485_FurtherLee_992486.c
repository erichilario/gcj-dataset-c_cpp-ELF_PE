#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 FILE *fin,*fout;
 int T,N;
 int A[1001];
 int visited[1001];
 int have[1001];
 void initial(){
 	fscanf(fin,"%d",&N);
 	int i;
 	for(i = 1; i <= N ; ++i){
 		fscanf(fin,"%d",&A[i]);
 		if(A[i] == i) visited[i] = 1;
 		else visited[i] = 0;
 		have[i] = 0;
 	}
 }
 
 int seek(int num){
 	if(visited[num]) return 0;
 	else{
  		visited[num] = 1;
    		return seek(A[num]) + 1;
 	}
 }
 
 double calculate(){
 	int i,temp;
 	long cur = 1;
 	double ans = 0;
  	for(i = 1 ; i <= N ; ++i)
 		if(!visited[i]){
 			have[seek(i)]++;;
   		}
 	for(i = 2 ; i <= N ; ++i){
 		if(have[i] != 0)
 			ans += have[i]*2*(i-1);
  	}
  	return ans;
 }
 
 void work(int num){
 	initial();
 	fprintf(fout,"Case #%d: %.6f\n",num,calculate());
 }
 
 int main(){
 	fin = fopen("Goro.in","r");
 	fout = fopen("Goro.out","w");
 	fscanf(fin,"%d",&T);
 	int i;
 	for(i = 0 ; i < T ; ++i)
 		work(i+1);
 	close(fin);
 	close(fout);
 	return 0;
 }

