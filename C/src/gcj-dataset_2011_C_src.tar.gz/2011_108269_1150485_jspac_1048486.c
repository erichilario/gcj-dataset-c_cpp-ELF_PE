#include <stdio.h>
 #include <stdlib.h>
 
 int main(void)
 {
 	char input[110];
 	int t, T, i, j, k, N, num_games[100], schedule[100][100], wins, sum;
 	double WP[100], OWP[100], OOWP[100], sum_owp;
 	FILE *in, *out;
 	
 	in = fopen("input.txt", "rt");
 	out = fopen("output.txt", "wt");
 	
 	fgets(input, 110, in);
 	T = atoi(input);
 	
 	for (t = 1; t <= T; t++)
 	{
 		fgets(input, 110, in);
 		N = atoi(input);
 		
 		for (i = 0; i < N; i++)
 		{
 			fgets(input, 110, in);
 			num_games[i] = 0;
 			wins = 0;
 			for (j = 0; j < N; j++)
 			{
 				if (input[j] == '.')
 					schedule[i][j] = -1;
 				else
 				{
 					schedule[i][j] = input[j] - '0';
 					num_games[i] += 1;
 					wins += schedule[i][j];
 				}
 			}
 			WP[i] = (double)wins / num_games[i];
 		}
 		
 		for (i = 0; i < N; i++)
 		{
 			sum_owp = 0.0;
 			for (j = 0; j < N; j++)
 				if (schedule[i][j] >= 0)
 				{
 					sum = 0;
 					for (k = 0; k < i; k++)
 						if (schedule[j][k] >= 0)
 							sum += schedule[j][k];
 					for (k = i + 1; k < N; k++)
 						if (schedule[j][k] >= 0)
 							sum += schedule[j][k];
 					sum_owp += (double)sum / (num_games[j] - 1);
 				}
 			OWP[i] = sum_owp / num_games[i];
 		}
 		
 		fprintf(out, "Case #%d:\n", t);
 		for (i = 0; i < N; i++)
 		{
 			sum_owp = 0.0;
 			for (j = 0; j < N; j++)
 				if (schedule[i][j] >= 0)
 					sum_owp += OWP[j];
 			OOWP[i] = sum_owp / num_games[i];
 			fprintf(out, "%.12f\n", 0.25 * WP[i] + 0.5 * OWP[i] + 0.25 * OOWP[i]);
 		}
 	}
 	
 	fclose(in);
 	fclose(out);
 	
 	return 0;
 }
