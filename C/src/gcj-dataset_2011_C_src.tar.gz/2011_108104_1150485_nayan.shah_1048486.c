#include <stdio.h>
 
 int main() {
     int t, n, i, j, k ,l, won, lost, op;
     float wp[100], owp[100], oowp[100], rpi[100];
     char games[100][100];
     freopen("A-small-attempt0.in", "r", stdin);
     freopen("A-small-attempt0.out", "w", stdout);
     scanf("%d", &t);
     for(l=1; l<=t; l++) {
         scanf("%d", &n);
         for(i=0; i<n; i++) {
             scanf("%s", games[i]);
         }
         for(i=0; i<n; i++) {
             for(won=lost=j=0; j<n; j++) {
                 if(games[i][j]=='1') {
                     won++;    
                 } else if(games[i][j]=='0') {
                     lost++;
                 }
             }
             wp[i] = won*1.0/(won+lost);
         }
         for(i=0; i<n; i++) {
             for(owp[i]=op=j=0; j<n; j++) {
                 if(j==i)
                     continue;
                 if(games[i][j]=='.')
                     continue;
                 for(won=lost=k=0; k<n; k++) {
                     if(k==i)
                         continue;
                     if(games[j][k]=='1') {
                         won++;
                     } else if(games[j][k]=='0'){
                         lost++;
                     }
                 }
                 owp[i] += won*1.0/(won+lost);
                 op++;
             }
             owp[i]/=op;
         }
         for(i=0; i<n; i++) {
             for(oowp[i]=op=j=0; j<n; j++) {
                 if(j==i)
                     continue;
                 if(games[i][j]=='.')
                     continue;
                 oowp[i] += owp[j];
                 op++;
             }
             oowp[i]/=op;
         }
         printf("Case #%d:\n", l);
         for(i=0; i<n; i++) {
             rpi[i] = 0.25*wp[i] + 0.5*owp[i] + 0.25*oowp[i];
         }
 /*
         printf("\n");
         for(i=0; i<n; i++) {
             printf("%f ", wp[i]);
         }
         printf("\n");
         for(i=0; i<n; i++) {
             printf("%f ", owp[i]);
         }
         printf("\n");
         for(i=0; i<n; i++) {
             printf("%f ", oowp[i]);
         }
         printf("\n");
 // */
         for(i=0; i<n; i++) {
             printf("%.12f\n", rpi[i]);
         }
     }
 }

