#include <stdio.h>
 #include <string.h>
 #include <malloc.h>
 #include <fcntl.h>
 
 
 #define	SMALL_SAMPLE_SET	1
 #define OUT_FILE_NAME "rpi.out"
 FILE *fout;
 
 #if SMALL_SAMPLE_SET
 #define	N	10
 #else
 #define	N	100
 #endif
 
 int n;
 double  Points[N][N];
 
 void Process(
 	)
 {
   int i,j,k;
 
  // fprintf(fout,"NO\n", iMaxSum);
 }
 
 double CalculateWP(int row)
 {
    int i,j;
    int played = 0;
    int wins = 0;
    for (i = 0; i < n; ++i)
    {
        if (-1 != Points[row][i])
          played++;
 
        if (1 == Points[row][i])
          wins++;
    }
 
    double temp = (double) ((double)wins / (double)played);
    return temp;
 }
 
 
 double CalculateSpecialWP(int row, int SkipCol)
 {
    int i,j;
    int played = 0;
    int wins = 0;
    for (i = 0; i < n; ++i)
    {
        if (i == SkipCol)
          continue;
 
        if (-1 != Points[row][i])
          played++;
 
        if (1 == Points[row][i])
          wins++;
    }
 
    double temp = (double) ((double)wins / (double)played);
    return temp;
 }
 
 double CalculateOWP(int row)
 {
    int i,j;
    double SumOfWP = 0.0;
    int count = 0;
    
    for (i = 0; i < n;++i)
    {
      if (-1 != Points[row][i])
      {
         SumOfWP += CalculateSpecialWP(i, row);
 	count++;
      }
    }
    
    return (double) (SumOfWP / (double)count);
 }
 
 double CalculateOOWP(int row)
 {
    int i;
    double SumOfOWP = 0.0;
    int count = 0;
 
    for (i = 0; i < n; ++i)
    {
       if (-1 != Points[row][i])
       {
          SumOfOWP += CalculateOWP(i);
 	 count++;
       }
    }
 
    return (double) (SumOfOWP / (double)count);
 }
 
 
 int ParseInput(
 	char *pcszFileName
 	)
 {
   int T;
   int i,j,k;
   char ch;
   FILE *fp;
 
   double WP, OWP, OOWP, RPI;
 
   if (NULL == pcszFileName)
     return -1;
 
   fp = fopen(pcszFileName, "r");
   if (NULL == fp)
   {
      printf("\nAccess denied file: %s", pcszFileName);
      return -1;
   }
 
   fscanf(fp, "%d ", &T);
 
   fout = fopen(OUT_FILE_NAME, "w");
   if (NULL == fout)
   {
      printf("\nCannot create new file.");
      return -1;
   }
 
   for (i = 1; i <= T; ++i)
   {
     fscanf(fp, "%d ", &n);
     if (n > N || n < 3)
     {
       printf("\nLimits out of bound.");
       return -1;
     }
 
     for (j= 0; j < n; ++j)
     {
         for (k = 0; k < n; ++k)
 	{
   	   ch = fgetc(fp);
 	   switch(ch)
 	   {
 	      case '.': Points[j][k] = -1; break;
 	      case '1': Points[j][k] = 1; break;
 	      case '0': Points[j][k] = 0; break;
 	   }
 	}
 	fgetc(fp);
     }
 
     WP = 0.0;
     OWP = 0.0;
     OOWP = 0.0;
 
     fprintf(fout, "Case #%d:\n", i);
 
     for (j = 0; j < n ; ++j)
     {
         WP = CalculateWP(j);
 	OWP = CalculateOWP(j);
 	OOWP = CalculateOOWP(j);
  	//printf("\nWP(%d) = %0.12f", j,WP);
  	//printf("\nOWP(%d) = %0.12f", j,OWP);
  	//printf("\nOOWP(%d) = %0.12f", j,OOWP);
 	//getchar();
 
 	RPI = (0.25 * WP) + (0.50 * OWP) + (0.25 * OOWP);
 	fprintf(fout, "%0.12f\n", RPI);
     }
 
     /*for (j = 0; j  <n; ++j)
     {
        printf("\n");
        for (k = 0; k<n; ++k)
          printf("%f\t", Points[j][k]);
     }*/
         
 
 
     //Process(arrCandy, iCntCandies);
   }
 
   fclose(fp);
   fclose(fout);
   return 0;
 }
 
 int main(
 	int argc,
 	char *argv[]
 	)
 {
   if (2 != argc)
   {
     printf("Program expects input file as argument.\n");
     return 0;
   }
 
   ParseInput(argv[1]);
 }

