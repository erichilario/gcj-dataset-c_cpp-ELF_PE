
 #include <stdio.h>
 
 int main() {
 	int it, i, j, k;
 	int T, n;
 	int ss[100][100];
 	double WP[100];
 	double OWP[100];
 	double OWPt;
 	double OOWP[100];
 	char str[101];
 	double sum;
 
 	scanf("%d", &T);
 	for(it = 0; it < T; it++) {
 
 		scanf("%d", &n);
 		for(i = 0; i < n; i++) {
 			scanf("%s", str);
 			sum = 0;
 			WP[i] = 0;
 			for(j = 0; j < n; j++) {
 				if(str[j] == '.') ss[i][j] = 0;
 				else if(str[j] == '1') {ss[i][j] = 1; WP[i]++; sum++;}
 				else {ss[i][j] = -1; sum++;}
 			}
 			if(sum != 0) WP[i] /= sum;
 		}
 		for(i = 0; i < n; i++) {
 			sum = 0;
 			OWP[i] = 0;
 			for(j = 0; j < n; j++) {
 				if(j != i && ss[i][j] != 0) {
 					int sumt = 0;
 					OWPt = 0;
 					for(k = 0; k < n; k++) {
 						if(ss[j][k] != 0 && k != i) {
 							sumt++;
 							if(ss[j][k] == 1) OWPt++;
 						}
 					}
 					if(sumt != 0) OWPt /= sumt;
 					OWP[i] += OWPt;
 					sum++;
 				}
 			}
 			if(sum != 0) OWP[i] /= sum;
 		}
 		for(i = 0; i < n; i++) {
 			sum = 0;
 			OOWP[i] = 0;
 			for(j = 0; j < n; j++) {
 				if(ss[i][j] != 0) {
 					sum++;
 					OOWP[i] += OWP[j];
 				}
 			}
 			if(sum != 0) OOWP[i] /= sum;
 		}
 		printf("Case #%d:\n", it+1);
 		for(i = 0; i < n; i++) {
 			double RPI = 0.25 * WP[i] + 0.50 * OWP[i] + 0.25 * OOWP[i];
 			printf("%lf\n", RPI);			
 		}
 	}
 
 	return 0;
 }

