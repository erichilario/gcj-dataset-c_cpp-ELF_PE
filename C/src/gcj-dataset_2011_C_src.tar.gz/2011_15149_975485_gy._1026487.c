#include<stdio.h>
 #include<string.h>
 
 char com[32][32];
 char op[32][32];
 char str[128];
 char ret[128];
 
 int main() {
 	int N,n,c,d,i,j,cs=0,r,m,k;
 	for(scanf("%d",&N);N--;) {
 		memset(com,0,sizeof(com));
 		memset(op,0,sizeof(op));
 		scanf("%d",&c);
 		for(i=0;i<c;i++) {
 			scanf("%s",str);
 			com[str[0]-'A'][str[1]-'A']=com[str[1]-'A'][str[0]-'A']=str[2];
 		}
 		scanf("%d",&d);
 		for(i=0;i<d;i++) {
 			scanf("%s",str);
 			op[str[0]-'A'][str[1]-'A']=op[str[1]-'A'][str[0]-'A']=1;
 		}
 		scanf("%d",&n);
 		scanf("%s",str);
 		m=r=0;
 		for(i=0;i<n;i++) {
 			ret[r++]=str[i];
 			while(r>1 && com[ret[r-1]-'A'][ret[r-2]-'A']) ret[r-2]=com[ret[r-1]-'A'][ret[r-2]-'A'],r--;
 			for(j=0;j<r-1;j++) if (op[ret[j]-'A'][ret[r-1]-'A']) r=0;
 		}
 		printf("Case #%d: [",++cs);
 		if (!r) {
 			puts("]");
 			continue;
 		}
 		for(i=0;i<r-1;i++) printf("%c, ",ret[i]);
 		printf("%c]\n",ret[i]);
 	}
 	return 0;
 }

