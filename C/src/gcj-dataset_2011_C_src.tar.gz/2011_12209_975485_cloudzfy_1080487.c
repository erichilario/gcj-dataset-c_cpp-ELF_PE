#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 int main()
 {
 	FILE *fp1,*fp2;
 	int t,i,n,pos,result,po[2],pb[2],x;
 	char robot[2];
 	fp1=fopen("A-large.in","r");
 	fp2=fopen("A-large.out","w");
 	fscanf(fp1,"%d",&t);
 	for(x=1;x<=t;x++)
 	{
 		fscanf(fp1,"%d",&n);
 		po[0]=-1;
 		po[1]=0;
 		pb[0]=-1;
 		pb[1]=0;
 		result=0;
 		for(i=0;i<n;i++)
 		{
 			fscanf(fp1,"%s%d",robot,&pos);
 			result++;
 			if(robot[0]=='O')
 			{
 				if(result-po[0]<abs(pos-po[1])+1)
 				{
 					result=po[0]+abs(pos-po[1])+1;
 				}
 				po[0]=result;
 				po[1]=pos;
 			}
 			else
 			{
 				if(result-pb[0]<abs(pos-pb[1])+1)
 				{
 					result=pb[0]+abs(pos-pb[1])+1;
 				}
 				pb[0]=result;
 				pb[1]=pos;
 			}
 		}
 		fprintf(fp2,"Case #%d: %d\n",x,result);
 	}
 }
