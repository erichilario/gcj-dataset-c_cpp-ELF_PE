#include <stdio.h>
 
 int main()
 {
 int a[100][100],t,n,win,total,win1[100],total1[100],i,j,f,count=0;
 long double wp[100],owp[100],oowp[100],temp1,rpi;
 
 char temp;
 scanf("%d\n",&t);
 for(f=1;f<=t;f++)
 {
 	scanf("%d\n",&n);
 	for(i=0;i<n;i++)	
 	{
 		for(j=0;j<n;j++)	
 		{
 		scanf("%c",&temp);
 		if(temp=='.')
 		a[i][j]=-1;
 	        if(temp=='0')
 		a[i][j]=0;
 		if(temp=='1')
 		a[i][j]=1;
 		}
 		scanf("\n");
 	}
 	
 	
 	
 	for(i=0;i<n;i++)	
 	{
 	win=0;total=0;
 		for(j=0;j<n;j++)
 		{
 			if(a[i][j]!=-1)
 			{total++;
 			if(a[i][j]==1)
 			win++;
 			
 			}
 		}
 		win1[i]=win;
 		total1[i]=total;
 		wp[i]=(long double)win/total;
 	}
 	for(i=0;i<n;i++)
 	{count=0;temp1=0;
 		for(j=0;j<n;j++)
 		{
 			if(a[i][j]!=-1)
 			{count++;
 				if(a[i][j]==0)
 				temp1+=(long double)(win1[j]-1)/(total1[j]-1);
 				else
 				temp1+=(long double)(win1[j])/(total1[j]-1);
 				
 			}
 		}
 		owp[i]=(long double)temp1/count;
 	}
 	for(i=0;i<n;i++)
 	{temp1=0;count=0;
 		for(j=0;j<n;j++)
 		{
 			if(a[i][j]!=-1)
 			{
 			count++;
 			temp1+=owp[j];
 			}
 		}
 		oowp[i]=(long double)temp1/count;
 	}
 	printf("Case #%d:\n",f);
 	
 	
 	for(i=0;i<n;i++)
 	{
 	rpi=(0.25*wp[i])+(0.50*owp[i])+(0.25*oowp[i]);
 	printf("%0.12Lf\n",rpi);
 	}
 }
 
 
 	 
 return 0;
 }
