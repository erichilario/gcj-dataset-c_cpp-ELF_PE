#include <stdio.h>
 #include <conio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <memory.h>
 
 #pragma warning(disable:4996)
 
 #define SWAP( a, b, tmp ) {tmp=a;a=b;b=tmp;}
 #define ARRAY( ptr, type, cnt ) { ptr = (##type*)malloc( sizeof(##type) * cnt ); }
 #define FREE( mem ) free( mem )
 #define PUTCASE( N, res ) { fprintf( stdout, "Case #%d: %d\n", N+1, res ); }
 
 #define GETINT( k ) {fscanf( stdin, "%d", &k );}
 #define GETBR() {getc(stdin);}
 #define GETLINE( str, len ) { char t; len = 0; do{ t = getc( stdin ); str[len++] = t; } while( '\n' != t && !feof( stdin ) ); str[len-1] = '\0'; }
 
 
 
 int main( void )
 {
 	int T;
 	int N;
 	int tt;
 	int i;
 	int j;
 	int mat[100][100];
 	int win[100];
 	int match[100];
 	float owp[100];
 	int owpi[100];
 	float oowp[100];
 	float res1;
 	int c;
 
 	GETINT( T );GETBR();
 	for( tt=0; tt<T; tt++ )
 	{
 		GETINT( N ); GETBR();
 		memset( win, 0, sizeof(win) );
 		memset( match, 0, sizeof(match) );
 		memset( owp, 0, sizeof(owp) );
 		memset( owpi, 0, sizeof(owpi) );
 		memset( oowp, 0, sizeof(oowp) );
 
 		printf("Case #%d:\n", tt+1);
 		for( i=0; i<N; i++ )
 		{
 			for( j=0; j<N; j++ )
 			{
 				c = getc( stdin );
 				if( c == '1' ) mat[i][j] = 1;
 				else if( c == '0' ) mat[i][j] = 0;
 				else mat[i][j] = -1;
 			}
 			GETBR();
 		}
 
 
 		/* WP */
 		for( i=0; i<N; i++ )
 		{
 			match[i] = 0;
 			for( j=0; j<N; j++ )
 			{
 				if( mat[i][j] != -1 )
 				{
 					win[i] += mat[i][j];
 					match[i]++;
 				}
 			}
 		}
 
 		/* OWP */
 		for( i=0; i<N; i++ )
 		{
 			c = 0;
 			owp[i] = 0;
 			for( j=0; j<N; j++ )
 			{
 				if( mat[i][j] != -1 )
 				{
 					if( mat[j][i] == 1 )
 						owp[i] += (win[j]-1)*1.0f/(match[j]-1);
 					else
 						owp[i] += win[j]*1.0f/(match[j]-1);
 					c++;
 				}
 			}
 
 			owpi[i] = c;
 			owp[i] /= c;
 		}
 
 		/* OOWP */
 		for( i=0; i<N; i++ )
 		{
 			oowp[i] = 0;
 			for( j=0; j<N; j++ )
 			{
 				if( mat[i][j] != -1 )
 					oowp[i] += owp[j];
 			}
 
 			oowp[i] /= owpi[i];
 		}	
 
 		for( i=0; i<N; i++ )
 		{
 			res1 = 0.25*(win[i]*1.0f/match[i]*1.0f) + 0.5*owp[i] + 0.25*oowp[i];
 			printf("%f\n",res1);
 		}
 	}
 
 	return 0;
 }
