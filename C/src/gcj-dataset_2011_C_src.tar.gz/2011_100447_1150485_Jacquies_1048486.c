#include "../../../../CS392/lib/my.h"
 
 int testcase(int n, int **teams)
 {
   int i;
   int j;
   int k;
   int l;
   double *wp;
   double *owp;
   double *oowp;
   int wins;
   int games;
   int opgames;
   int oopgames;
   double sum;
   double rpi;
 
   wp = (double*)xmalloc(n*sizeof(double));
   owp = (double*)xmalloc(n*sizeof(double));
   oowp = (double*)xmalloc(n*sizeof(double));
 
   /*for (i=0;i<n;i++){
     for (j=0;j<n;j++){
       printf("%d ", teams[i][j]);
     }
     printf("\n");
     }*/
   
 
 
   for (i=0;i<n;i++){
     wins = 0;
     games = 0;
 
     for (j=0;j<n;j++){
       if (teams[i][j]<0)
 	  continue;
       
       if (teams[i][j]>0){
 	wins++;
       }
       games++;
     }
 
     wp[i] = ((double)wins)/(games);
   }
 
   for (i=0;i<n;i++){
     owp[i] = 0;
     opgames = 0;
 
     for (j=0;j<n;j++){
       if (teams[i][j]<0)
 	continue;
 
       wins = 0;
       games = 0;
       for (k=0;k<n;k++){
 	if (i==k || teams[j][k]<0)
 	  continue;
 
 	if (teams[j][k]>0){
 	  wins++;
 	}
 	games++;
       }
 
       owp[i] += (double)wins/games;
       opgames++;
     }
 
     owp[i] /= opgames;
   }
 
   for (i=0;i<n;i++){
     oowp[i] = 0;
     opgames = 0;
 
     for (j=0;j<n;j++){
       if (teams[i][j]<0)
 	continue;
 
       oowp[i] += owp[j];
       opgames++;
     }
 
     oowp[i] /= opgames;
   }
 
   for (i=0;i<n;i++){
     //printf("Team %d: %f, %f, %f\n", i, wp[i], owp[i], oowp[i]);
     rpi = 0.25 * wp[i] + 0.5 * owp[i] + 0.25 * oowp[i];
     printf("%f\n", rpi);
   }
 
   /* opgames = 0;
     owp = 0;
     for (j=0;j<n;j++){
       if (teams[i][j]==-1)
 	continue;
 
       wins = 0;
       games = 0;
       for (k=0;k<n;k++){
 	if (k==i)
 	  continue;
 	if (teams[j][k]>0){
 	  wins++;
 	}
 	if (teams[j][k]>=0){
 	  games++;
 	}
       }
 
       opgames++;
       owp += (double)wins/games;
     }
     owp /= opgames;
     
     oopgames=0;
     oowp=0;
     for (j=0;j<n;j++){
       if (teams[i][j]<0)
 	continue;
 
       opgames = 0;
       sum = 0;
       for (k=0;k<n;k++){
 	if (teams[j][k]<0)
 	  continue;
 
 	wins = 0;
 	games = 0;
 	for (l=0;l<n;l++){
 	  if (l==j)
 	    continue;
 	  if (teams[k][l]>0){
 	    wins++;
 	  }
 	  if (teams[k][l]>=0){
 	    games++;
 	  }
 	}
 
 	opgames++;
 	sum += (double)wins/games;
       }
       sum /= opgames;
 
       oopgames++;
       oowp += sum;
     }
     oowp /= oopgames;
 
     rpi = 0.25*wp + 0.5*owp + 0.25*oowp;
     printf("%f\n", rpi);
     }*/
   
 }

