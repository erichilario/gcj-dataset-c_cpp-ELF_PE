#include <stdlib.h>
 #include <stdio.h>
 
 double team[100][100];
 double win[100];
 double play[100];
 
 double  wp_min_me(int i, int j) 
 {
 	if (team[i][j] == -1)
 		return (0);
 	if (team[j][i] == 1)
 		return ((play[j] > 1) ? (win[j]-1)/(play[j]-1) : 0);
 	else
 		return ((play[j] > 1) ? (win[j]/(play[j]-1)) : 0);
 }
 
 void solve(int n)
 {
 	double wp[100];
 	double owp[100];
 	double oowp[100];
 
 	for (int i = 0; i < n; i++)
 		wp[i] = win[i]/play[i];
 	for (int i = 0; i < n; i++)
 	{
 		owp[i] = 0;
 		for (int j = 0; j < n; j++)
 			owp[i] += wp_min_me(i,j);
 		owp[i] /= play[i];
 	}
 	for (int i = 0; i < n; i++)
 	{
 		oowp[i] = 0;
 		for (int j = 0; j < n; j++)
 			oowp[i] += (i != j && team[i][j] != -1) ? owp[j] : 0;
 		oowp[i] /= play[i];
 	}
 	for (int i = 0; i < n; i++)
 		printf("%.10f\n", 0.25*wp[i]+0.5*owp[i]+0.25*oowp[i]);
 }
 
 int main(void)
 {
 	int warn = 0;
 	int t = 0;
 
 	warn = scanf("%d\n", &t);
 	for (int i = 0; i < t; i++)
 	{
 		int n = 0;
 		warn = scanf("%d\n", &n);
 		for (int j = 0; j < n; j++)
 		{
 			win[j] = play[j] = 0;
 			for (int k = 0; k < n; k++)
 			{
 				int c = getchar();
 				if (c == '1')
 					team[j][k] = 1, win[j]++, play[j]++;
 				else if (c == '0')
 					team[j][k] = 0, play[j]++;
 				else
 					team[j][k] = -1;
 			}
 			warn = getchar();
 		}
 		printf("Case #%d:\n", i+1);
 		solve(n);
 	}
 	return (0);
 }
 

