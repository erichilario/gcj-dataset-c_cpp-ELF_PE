#include <stdio.h>
 
 int main (int argc, char **argv)
 {
     int t, i;
     int c, d;
     int j, k;
     int p, v;
     int n;
     double m;
     double ad, md;
     int ma, na;
     double max, min;
     int ps [300];
     scanf ("%d", &t);
     for (i = 1; i <= t;i ++)
     {
         scanf ("%d %d", &c, &d);
         m = 0;
         n = 0;
         md = 0;
         for (j = 0; j < c; j ++)
         {
             scanf ("%d %d", &p, &v);
             if (j == 0)
                 ma = na = p;
             else
             {
                 if (p > ma)
                     ma = p;
                 if (p < na)
                     na = p;
             }
             m += p;
             for (k = 0; k < v; k ++)
                 ps [n ++] = p;
         }
         m /= c;
         max = m + (n - 1) * d / 2.0;
         min = m - (n - 1) * d / 2.0;
 //        printf ("m=%f, a=%f, i=%f\n", m, max, min);
         for (j = 0; j < n; j ++)
         {
             ad = ps [j] - min;
             if (ad > md)
                 md = ad;
             min += d;
         }
         printf ("Case #%d: %.8g\n", i, md);
     }
     return 0;
 }

