#include<stdio.h>
 int main(){
 	int T,N;
 	int t,i,j,k;
 	int won,games,others;
 	scanf("%i\n",&T);
 	for(t=1;t<=T;t++){
 		scanf("%i\n",&N);
 		char a[N][N];
 		double wp[N];
 		double owp[N];
 		double oowp[N];
 		for(i=0;i<N;i++)
 			for(j=0;j<N;j++)
 				scanf("%c ",&a[i][j]);
 		for(i=0;i<N;i++){
 			won=games=0;
 			for(j=0;j<N;j++){
 				if(a[i][j]=='1')won++;
 				if(a[i][j]!='.')games++;
 			}
 			wp[i]=(double)won/(double)games;
 		}
 		for(i=0;i<N;i++){
 			owp[i]=0;
 			others=0;
 			for(j=0;j<N;j++){
 				won=games=0;
 				if(a[i][j]!='.'){
 					others++;
 					for(k=0;k<N;k++){
 						if(a[j][k]=='1' && k!=i)won++;
 						if(a[j][k]!='.' && k!=i)games++;
 					}
 					owp[i]+=(double)won/(double)games;
 				}	
 			}
 			owp[i]/=(double)others;
 		}
 		for(i=0;i<N;i++){
 			others=oowp[i]=0;
 			for(j=0;j<N;j++){
 				if(a[i][j]!='.'){
 					oowp[i]+=owp[j];
 					others++;
 				}
 			}
 			if(others)oowp[i]/=(double)others;
 		}
 		printf("Case #%i:\n",t);
 		for(i=0;i<N;i++)
 			printf("%lf\n",0.25*wp[i]+0.50*owp[i]+0.25*oowp[i]);
 	}
 	return 0;
 }
