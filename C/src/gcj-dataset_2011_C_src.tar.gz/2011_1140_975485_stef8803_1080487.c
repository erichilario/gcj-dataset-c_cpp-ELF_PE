#include <stdio.h>
 
 #define ORANGE 1
 #define BLUE 0
 
 #define cvect(c) (((c)==BLUE)?vB:vO)
 #define ovect(c) (((c)==ORANGE)?vB:vO)
 #define oindex(c) (((c)==BLUE)?ib:io)
 #define cindex(c) (((c)==ORANGE)?ib:io)
 #define cpos(c) (((c)==BLUE)?blue:orange)
 #define opos(c) (((c)==ORANGE)?blue:orange)
 #define str(c) (((c)==ORANGE)?"ORANGE":"BLUE")
 int vB[101],vO[101];
 int t[101];
 void go(int nr){
 //	printf("test %d\n",nr);
 //	fflush(stdout);
 	int n;
 	scanf("%d",&n);
 
 	unsigned long blue=1;
 	unsigned long orange=1;
 
 	unsigned long sum;
 	char c;
 	int b;
 	int ib=0,io=0,i=0;
 	for(i=0;i<n;++i){
 		do{
 			scanf("%c",&c);
 		}while(c!='B' && c!='O');
 		scanf("%d",&b);
 
 //		printf("%c %d\n",c,b);
 
 		if(c=='O'){
 //			printf("Written O %d at %d\n",b,io);
 			vO[io++] = b;
 			t[i] = ORANGE;
 		}
 		else{
 //			printf("Written B %d at %d\n",b,ib);
 			vB[ib++] = b;
 			t[i] = BLUE;
 		}
 	}
 	int nb=ib,no=io;
 	ib=0;
 	io=0;
 	sum=0;
 	int *v1,*v2,i1,i2,dif,pos2,ab;
 	for(i=0;i<n;++i){
 		v1=cvect(t[i]);
 		v2=ovect(t[i]);
 		i1=cindex(t[i]);
 		i2=oindex(t[i]);
 //		printf("%s %d %d %d %d\n",str(t[i]),i1,v1[i1],v1[i1]==vB,cpos(t[i]));
 		if(v1[i1] > cpos(t[i]))
 			ab = v1[i1]-cpos(t[i]);
 		else
 			ab = cpos(t[i]) - v1[i1];
 		dif=ab+1;
 		pos2=opos(t[i]);
 		if(i2 < (t[i]==ORANGE?nb:no) && v2[i2] != pos2){
 			if(pos2<v2[i2]){
 				pos2 += dif;
 				if(pos2>v2[i2])
 					pos2 = v2[i2];
 				opos(t[i]) = pos2;
 			}
 			else{
 				pos2 -= dif;
 				if(pos2<v2[i2])
 					pos2 = v2[i2];
 				opos(t[i]) = pos2;
 			}
 		}
 		cpos(t[i])=v1[i1];
 		cindex(t[i])++;
 		sum+=dif;
 //		printf("Doing %lu steps\n",dif);
 	}
 	printf("Case #%d: %lu\n",nr,sum);
 	fflush(stdout);
 }
 
 int main(){
 	int T,i;
 	scanf("%d",&T);
 	for(i=1;i<=T;++i){
 		go(i);
 	}
 	return 0;
 }

