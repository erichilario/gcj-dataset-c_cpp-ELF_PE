/*
  * Hirakendu Das, 20 May 2011, for Google Code Jam contest.
  * Problem X: XXX.
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 #define VERBOSE_LEVEL_DEFAULT 1
 
 #define max(x,y) ((x) > (y) ? (x) : (y))
 #define abs(x) ((x) > 0? (x) : (-(x)))
 
 int main(int argc, char *argv[])
 {
   int i, temp_i;
   FILE *input_file_ptr, *output_file_ptr;
   int verbose_level = VERBOSE_LEVEL_DEFAULT;
   char *input_file_name_default = "input.txt";
   char *input_file_name = NULL;
   char *output_file_name_default = "output.txt";
   char *output_file_name = NULL;
   int num_cases, case_id;
   
   int n, w[200][200];
   double wp[200], owp[200][200], oowp[200][200], avg_owp[200], avg_oowp[200];
   int j;
   char c;
   int wins, matches, wt[200], m[200], num_opps[200];
   double rpi[200];
   
   /* Parse commandline arguments. */
   for (i = 1; i < argc; i++) {
     if (strcmp(argv[i], "-i") == 0 && i + 1 < argc) {
       input_file_name = argv[++i];
     } else if (strcmp(argv[i], "-o") == 0 && i + 1 < argc) {
       output_file_name = argv[++i];
     } else if (strcmp(argv[i], "-v") == 0) {
       verbose_level = atoi(argv[++i]);
     } else {
       printf("Error parsing arguments!\n");
       printf("Usage: template.bin -i <input_file_name> -o <output_file_name>");
       printf("  -v <verbose_level>\n");
       return 0;
     }
   }
   if (input_file_name == NULL) {
     input_file_name = input_file_name_default;
   }
   if (output_file_name == NULL) {
     output_file_name = output_file_name_default;
   }
   
   /* Parse input file and run the algorithm. */
   input_file_ptr = fopen(input_file_name, "r");
   if (input_file_ptr == NULL) {
     printf("Error opening input file.\n");
     return 0;
   }
   output_file_ptr = fopen(output_file_name, "w");
   if (input_file_ptr == NULL) {
     printf("Error opening output file.\n");
     return 0;
   }
   temp_i = fscanf(input_file_ptr, "%d", &num_cases);
   if (verbose_level >= 2) {
     printf("  Number of test cases: %d\n", num_cases);
   }
   for (case_id = 1; case_id <= num_cases; case_id++) {
     if (verbose_level >= 1) {
       printf("  Case #%d: ", case_id);
     }
     /* A particular test case. */
     /* Get the input. */
     temp_i = fscanf(input_file_ptr, "%d", &n);
     for (i = 0; i < n; i++) {
       temp_i = fscanf(input_file_ptr, "%c", &c);
       for (j = 0; j < n; j++) {
 	temp_i = fscanf(input_file_ptr, "%c", &c);
 	if (c == '.') {
 	  w[i][j] = -1;
 	} else if (c == '1') {
 	  w[i][j] = 1;
 	} else if (c == '0') {
 	  w[i][j] = 0;
 	}
       }
     }
     if (verbose_level >= 3) {
       printf("    input: \n");
       for (i = 0; i < n; i++) {
 	for (j = 0; j < n; j++) {
           printf("\t %d", w[i][j]);
 	}
 	printf("\n");
       }
     }
     /* 2. The algorithm and printing output. */
     /* Calculate WP. */
     for (i = 0; i < n; i++) {
       wins = 0;
       matches = 0;
       for (j = 0; j < n; j++) {
 	if (w[i][j] == 1) {
 	  matches++;
 	  wins++;
 	} else if (w[i][j] == 0) {
 	  matches++;
 	}
       }
       wp[i] = ((double) wins) / matches;
       wt[i] = wins;
       m[i] = matches;
     }
     if (verbose_level >= 3) {
       printf("    wp: ");
       for (i = 0; i < n; i++) {
         printf(" %0.3f", wp[i]);
       }
       printf("\n");
     }
     for (i = 0; i < n; i++) {
       num_opps[i] = 0;
       avg_owp[i] = 0;
       for (j = 0; j < n; j++) {
 	if (w[i][j] == 1) {
 	  wins = wt[j];
 	  matches = m[j] - 1;
 	  num_opps[i]++;
 	  owp[i][j] = ((double) wins) / matches;
 	  avg_owp[i] += owp[i][j];
 	} else if (w[i][j] == 0) {
 	  wins = wt[j] - 1;
 	  matches = m[j] - 1;
 	  num_opps[i]++;
 	  owp[i][j] = ((double) wins) / matches;
 	  avg_owp[i] += owp[i][j];
 	}
       }
       avg_owp[i] /= num_opps[i];
     }
     if (verbose_level >= 3) {
       printf("    owp: \n");
       for (i = 0; i < n; i++) {
 	for (j = 0; j < n; j++) {
 	  printf("\t %0.3f", owp[i][j]);
 	}
 	printf("  avg_owp = %0.3f, num_opps = %d\n", avg_owp[i], num_opps[i]);
       }
     }
     for (i = 0; i < n; i++) {
       avg_oowp[i] = 0;
       for (j = 0; j < n; j++) {
 	if ((w[i][j] == 1) || (w[i][j] == 0)) {
 	  owp[i][j] = ((double) wins) / matches;
 	  avg_oowp[i] += avg_owp[j];
 	} 
       }
       avg_oowp[i] /= num_opps[i];
     }
     if (verbose_level >= 1) {
       printf("avg_oowp: ");
       for (i = 0; i < n; i++) {
 	printf(" %.3f ", avg_oowp[i]);
       }
       printf("\n");
     }
     for (i = 0; i < n; i++) {
       rpi[i] = 0.25 * wp[i] + 0.5 * avg_owp[i] +  0.25 * avg_oowp[i];
     }
     if (verbose_level >= 1) {
       printf("rpi: ");
       for (i = 0; i < n; i++) {
 	printf(" %.3f ", rpi[i]);
       }
       printf("\n");
     }
     if (verbose_level >= 1) {
       printf("\n");
     }
     fprintf(output_file_ptr, "Case #%d:\n", case_id);
     for (i = 0; i < n; i++) {
       fprintf(output_file_ptr, "%.10f\n", rpi[i]);
     }
   }  /* End of case_id loop. */
   fclose(input_file_ptr);
   fclose(output_file_ptr);
   
   return 0;
 }

