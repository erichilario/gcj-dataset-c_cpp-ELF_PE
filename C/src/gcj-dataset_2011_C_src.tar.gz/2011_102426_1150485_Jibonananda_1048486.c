#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 int main()
 {
 	char a[102][102];
 	int count[102],c;
 	int notc,i,j,n,tc;
 	long double wp[102],owp[102],oowp[102],sum;
 	scanf("%d",&notc);
 	for(tc=1;tc<=notc;++tc)
 	{
 		scanf("%d",&n);
 		fflush(stdin);
 		for(i=0;i<n;++i)
 		{
 			sum=c=0;
 			scanf("%s",a[i]);
 			for(j=0;j<n;++j)
 			{				
 				if (a[i][j]=='1' || a[i][j]=='0')
 				{
 					if (a[i][j]=='1')
 						++sum;
 					++c;
 				}					
 			}
 			count[i]=c;
 			wp[i]=sum/c;
 			//printf("wp[%d]=%Lf\n",i,wp[i]);
 		}
 		
 		for(i=0;i<n;++i)
 		{
 			sum=c=0;
 			for(j=0;j<n;++j)
 			{
 				if (i==j || a[j][i]=='.')	continue;
 				
 				if (a[j][i]=='1')
 					sum+=((wp[j]*count[j])-1)/(count[j]-1);
 				else
 					sum+=((wp[j]*count[j]))/(count[j]-1);
 				++c;
 			}
 			owp[i]=sum/c;
 			//printf("owp[%d]=%Lf\n",i,owp[i]);
 		}
 		
 		for(i=0;i<n;++i)
 		{
 			sum=c=0;
 			for(j=0;j<n;++j)
 			{
 				if (i==j || a[i][j]=='.')	continue;
 				sum+=owp[j];
 				++c;
 			}
 			oowp[i]=sum/c;
 			//printf("oowp[%d]=%Lf\n",i,oowp[i]);
 		}
 		
 		printf("Case #%d:\n",tc);
 		for(i=0;i<n;++i)
 			printf("%Lf\n",0.25*wp[i]+0.5*owp[i]+0.25*oowp[i]);
 	}
 	return 0;
 }

