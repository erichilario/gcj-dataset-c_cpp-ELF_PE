#include <stdio.h>
 #include <string.h>
 
 void combine(char [],char [],int,int);
 void oppose(char [],char [],int,int);
 char rv[10];
 	
 int main()
  {
 	int T,C,D,N,i,j,k;
 	char cs[6],ds[6],ns[11];
 	scanf("%d",&T);
 	if(T<1 || T>100)
 		return 1;
 	for(i=0;i<T;i++)
 	 {
 		scanf("%d",&C);
 		if(C<0 || C>1)
 			return 1;
 		for(j=0;j<C;j++)
 			scanf("%s",cs);
 		scanf("%d",&D);
 		if(C<0 || C>1)
 			return 1;
 		for(j=0;j<D;j++)
 			scanf("%s",ds);
 		scanf("%d",&N);
 		if(N<1 || N>10)
 			return 1;
 		scanf("%s",ns);
 		if(N!=strlen(ns))
 			return 1;
 		for(j=1;j<=N-1;j++)
 		 {
 			if(C)
 			 {
 				combine(ns,cs,j,N);
 				strcpy(ns,rv);
 			 }
 			if(D)
 			 {
 				oppose(ns,ds,j,N);
 				strcpy(ns,rv);
 			 }
 		 }
 		k=0;
 		printf("Case #%d: [",i+1);
 		for(j=0;j<strlen(ns);j++)
 		 {
 			if(k++)
 				printf(", ");
 			printf("%c",ns[j]);
 		 }		
 		printf("]\n");
 	 }
 	return 0;
  }
 
 void combine(char ns[],char cs[],int j,int n)
  {
 	int i,sp=0,k;
 	for(i=0;i<j;i++)
 	 {
 		if((ns[i]==cs[0] && ns[i+1]==cs[1]) || (ns[i]==cs[1] && ns[i+1]==cs[0]))
 		 {
 			rv[sp++]=cs[2];
 			for(k=i+1;k<n;k++)
 				ns[k]=ns[k+1];
 		 }	
 		else
 		 {
 			rv[sp++]=ns[i];
 		 }
 	 }
 	for(;i<=n;i++)
 		rv[sp++]=ns[i];
  }
 
 void oppose(char sn[],char ds[],int j,int n)
  {
 	int i,flag=0,k;
 	for(i=0;i<=j;i++)
 	 {	
 		if(!flag)
 		 {
 			if(sn[i]==ds[0])
 			 {
 				flag=1; 
 				continue;
 			 }
 			else if(sn[i]==ds[1])
 			 {
 				flag=2;
 				continue;
 			 }
 		 }
 		if(flag==1)
 		 {		
 			if(sn[i]==ds[1])
 			 {
 				if(i==n)
 					sn[0]=sn[n];
 				for(k=0;i<n;k++,i++)
 					sn[k]=sn[i+1];
 				flag=0;
 			 }
 		 }
 		else if(flag==2)
 		 {
 			if(sn[i]==ds[0])
 			 {
 				if(i==n)
 					sn[0]=sn[n];
 				for(k=0;i<n;k++,i++)
 					sn[k]=sn[i+1];
 				flag=0;	
 			 }
 		 }
 	 }
 	strcpy(rv,sn);			
  }

