#include <stdio.h>
 
 int temp[15];
 int fake_add(int a, int b) {
     int i, ret = 0;
     for (i = 0; i < 23; i++) {
         if ((a&(1<<i)) && (b&(1<<i))) continue;
         if (a&(1<<i)) ret |= (1<<i);
         if (b&(1<<i)) ret |= (1<<i);
     }
     return ret;
 }
 int calc(int ncandies, int* candies, int p) {
     int t1, t2, i;
     if (p == ncandies) {
         t1 = t2 = 0;
         for (i = 0; i < ncandies; i++) if (temp[i] == 0) t1 = fake_add(t1, candies[i]);
         for (i = 0; i < ncandies; i++) if (temp[i] == 1) t2 = fake_add(t2, candies[i]);
         if (t1 != t2) return -1;
         t1 = t2 = 0;
         for (i = 0; i < ncandies; i++) if (temp[i] == 0) t1 += candies[i];
         for (i = 0; i < ncandies; i++) if (temp[i] == 1) t2 += candies[i];
         if ((t1 == 0) || (t2 == 0)) return -1;
         return (t1 > t2) ? t1 : t2;
     }
     temp[p] = 0;
     t1 = calc(ncandies, candies, p+1);
     temp[p] = 1;
     t2 = calc(ncandies, candies, p+1);
     return (t1 > t2) ? t1:t2;
 }
 
 void main() {
     int ntests, ncandies, candies[15];
     int i, j, t = -1;
     scanf("%d", &ntests);
 
     for (i = 0; i < ntests; i++) {
         scanf("%d", &ncandies);
         for (j = 0; j < ncandies; j++) scanf("%d", &candies[j]);
         t = calc(ncandies, candies, 0);
         if (t == -1) printf("Case #%d: NO\n", i+1);
         else printf("Case #%d: %d\n", i+1, t);
     }
     getchar();
     getchar();
     return;
 }

