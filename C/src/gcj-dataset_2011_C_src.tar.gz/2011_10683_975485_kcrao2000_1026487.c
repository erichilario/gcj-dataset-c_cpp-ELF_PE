/* 
  * Code for the MagicKa Fun Problem.
  * kcrao2000
  */
 
 #include <stdio.h>
 #include "magicka.h"
 
 static void load_and_init_magicka_data(FILE *fp,
                                        char combine_matrix[9][9],
                                        int oppose_matrix[9][9])
 {
     int num_combine_inputs = 0;
     int i;
     char c1, c2, c3;
     int num_oppose_inputs = 0;
 
     fscanf(fp, "%d \n", &num_combine_inputs);
 
     for (i = 0; i < num_combine_inputs; i++)
     {
         fscanf(fp, "%c%c%c ", &c1, &c2, &c3);
         combine_matrix[char_idx[c1 - 'A']][char_idx[c2 - 'A']] = c3;
         combine_matrix[char_idx[c2 - 'A']][char_idx[c1 - 'A']] = c3;
     }
 
     fscanf(fp, "%d \n", &num_oppose_inputs);
     
     for (i = 0; i < num_oppose_inputs; i++)
     {
         fscanf(fp, "%c%c ", &c1, &c2);
         oppose_matrix[char_idx[c1 - 'A']][char_idx[c2 - 'A']] = 1;
         oppose_matrix[char_idx[c2 - 'A']][char_idx[c1 - 'A']] = 1;
     }
 
 }
 
 static int is_oppose_hist_present(char curr_elem,
                                  int oppose_history_matrix[9][9])
 {
     int i;
     int curr_idx = char_idx[curr_elem - 'A'];
 
     for (i = 0; i < 8; i++)
     {
         if (oppose_history_matrix[i][curr_idx] > 0) {
             return 1;
         }
     }
 
     return 0;
 }
 
 
 static void set_oppose_hist_entries(char curr_elem,
                                     int oppose_matrix[9][9],
                                     int oppose_history_matrix[9][9])
 {
     int i;
     int curr_idx = char_idx[curr_elem - 'A'];
 
     for (i = 0; i < 8; i++)
     {
         oppose_history_matrix[curr_idx][i] += oppose_matrix[curr_idx][i];
     }
 }
 
 static void clear_oppose_hist_entries(char prev_elem,
                                       int oppose_matrix[9][9],
                                       int oppose_history_matrix[9][9])
 {
     int i;
     int prev_idx = char_idx[prev_elem - 'A'];
 
     for (i = 0; i < 8; i++)
     {
         oppose_history_matrix[prev_idx][i] -= oppose_matrix[prev_idx][i];
     }
 }
 
 
 static void generate_magicka_list(FILE* fp,
                                   char combine_matrix[9][9],
                                   int oppose_matrix[9][9],
                                   char *list_str,
                                   int *pnum_elems)
 {
     int num_chars_to_read = 0;
     int oppose_history_matrix[9][9];
     int num_chars_in_list = 0;
     char curr_elem;
     char prev_elem;
     char combine_elem;
     int i;
     memset(oppose_history_matrix, 0, sizeof(oppose_history_matrix));
 
     fscanf(fp, "%d \n", &num_chars_to_read);
 
     for (i = 0; i < num_chars_to_read; i++)
     {
        curr_elem = fgetc(fp);
 
        if (num_chars_in_list > 0) 
        {
           /* Combination? */
           prev_elem = list_str[num_chars_in_list - 1];
           combine_elem = combine_matrix[char_idx[prev_elem - 'A']][char_idx[curr_elem - 'A']];
           
           if (combine_elem) {
             /* Yup - can combine */
             list_str[num_chars_in_list - 1] = combine_elem;
 
             clear_oppose_hist_entries(prev_elem,
                                       oppose_matrix,
                                       oppose_history_matrix);
 
           } else if (is_oppose_hist_present(curr_elem,
                                             oppose_history_matrix))
           {
              num_chars_in_list = 0;
              memset(oppose_history_matrix, 0, sizeof(oppose_history_matrix));
           } else {
              num_chars_in_list++;
              list_str[num_chars_in_list - 1] = curr_elem;
 
              set_oppose_hist_entries(curr_elem,
                                      oppose_matrix,
                                      oppose_history_matrix);
           }
        } else {
             num_chars_in_list++;
             list_str[num_chars_in_list - 1] = curr_elem;
             set_oppose_hist_entries(curr_elem,
                                     oppose_matrix,
                                     oppose_history_matrix);
        }
     }
     
     fprintf(fp, "\n", NULL);
     
     *pnum_elems = num_chars_in_list;
 
 }
 
 int main(int argc, char* argv[])
 {
     FILE *fp = NULL;
     int num_test_cases = 0;
     int num_elems;
     int i, j;
 
     char list_str[MAX_STR_CHARS + 300];
 
     /* 
      * We use hard constants here since the definition of base
      * elements is rigid anyway
      */
     char combine_matrix[9][9];
     int oppose_matrix[9][9];
 
     
     if (argc < 2) {
         fprintf(stderr,"Dude, pass a filename\n");
         return -1;
     }
 
     /* Quick and dirty programming - we assume file input is correct, except
      * for some major gotchas */
 
     fp = fopen(argv[1], "r");
 
     if (NULL == fp) {
         fprintf(stderr,"Dude, pass a VALID file\n");
         return -1;
     }
     
     fscanf(fp, "%d\n", &num_test_cases);
 
     for (i = 1; i <= num_test_cases; i++) {
         memset(combine_matrix, 0, sizeof(combine_matrix));
         memset(oppose_matrix, 0, sizeof(oppose_matrix));
         load_and_init_magicka_data(fp, combine_matrix, oppose_matrix);
 
         /*{
             int j, k;
 
             printf("Test case: %d\n", i);
 
             for (j = 0; j < 9; j++)
             {
                 for (k = 0; k < 9; k++)
                 {   if (combine_matrix[j][k])
                         printf("%c ", combine_matrix[j][k]);
                     else 
                         printf("X ");
                 }
                 printf("\n");
             }
 
             for (j = 0; j < 9; j++)
             {
                 for (k = 0; k < 9; k++)
                 {
                     printf("%d ", oppose_matrix[j][k]);
                 }
                 printf("\n");
             }
 
         }*/
 
         generate_magicka_list(fp,
                               combine_matrix,
                               oppose_matrix,
                               list_str,
                               &num_elems
                               );
 
        printf("Case #%d: [",i);
        for (j = 0; j < num_elems; j++) 
        {
             if (j > 0) {
                 printf(", ");
             }
 
             printf("%c", list_str[j]);
        }
 
        printf("]\n");
     }
     
 }

