#include <assert.h>	
 #include <ctype.h>	
 #include <math.h>	
 #include <stdarg.h> 
 #include <stdio.h>	
 #include <stdlib.h>	
 #include <string.h>	
 #include <time.h>	
 
 #define LOOP(i,N) for((i)=0;(i)<(int)(N);i++)
 #define GETMEM(type,n) (type*)malloc((n)*sizeof(type))
 #define OUT(...) printf(__VA_ARGS__)
 #define FOUT(...) fprintf(out_fp, __VA_ARGS__)
 #define FIN(...) fscanf(in_fp, __VA_ARGS__)
 #define ERR(...) fprintf(stderr, __VA_ARGS__)
 #define ERRCHK(x) if(x==NULL){perror("Error");exit(1);}
 
 #define TRUE 1
 #define FALSE 0
 int compareInt(const void* x, const void *y);
 
 int main(int argc, char* argv[])
 {
 	/* DECLARE VARIABLES */
 	FILE* in_fp=NULL;
 	FILE* out_fp=NULL;
 	
 	int i,j,k;
 	int numCases;
 	
 	int n;
 	int* values;
 	int* modArray;
 	int* tempArray;
 	int ones;
 	long long sean;
 	int index;
 	/* CHECK COMMAND LINE ARGUMENTS*/
 	if (argc!=2)
 	{
 		ERR("Incorrect number of command line arguments, exiting...\n");
 		return 1;
 	}
 	
 	/* OPEN FILES */
 	in_fp = fopen(argv[1],"r");
 	ERRCHK(in_fp);
 	
 	out_fp = fopen("output.txt","w");
 	ERRCHK(out_fp);
 	
 	/* READ NUMBER OF CASES */
 	fscanf(in_fp,"%d",&numCases);
 
 	/* MAIN LOOP */
 	LOOP(k,numCases)
 	{
 		sean=0;
 		FIN("%d",&n);
 		values = GETMEM(int,n);
 		ERRCHK(values);
 		modArray = GETMEM(int,n);
 		ERRCHK(modArray);
 		
 		LOOP(i,n)
 		{
 			FIN("%d",&values[i]);
 		}
 		ones=0;
 		LOOP(i,n)
 		{
 			modArray[i]=values[i]%2;
 			ones+=modArray[i];
 		}
 		if(ones%2!=0)
 		{
 			FOUT("Case #%d: NO\n",k+1);
 			continue;
 		}
 		tempArray = GETMEM(int,ones);
 		index=0;
 		LOOP(i,n)
 		{
 			if(modArray[i]==0)
 				sean+=values[i];
 			else
 			{
 				tempArray[index]=values[i];
 				index++;
 			}
 		}
 				
 		qsort(tempArray,ones,sizeof(int),compareInt);
 		for(i=ones-1;i>((ones/2)-1);i--)
 		{
 			sean+=tempArray[i];
 		}
 
 		FOUT("Case #%d: %Ld\n",k+1,sean);
 		free(values);
 		free(modArray);
 		free(tempArray);
 	}
 	
 	/* CLOSE FILES */
 	fclose(out_fp);
 	fclose(in_fp);
 	
 	return 0;
 }
 
 int compareInt(const void* x, const void *y)
 {
 	return (*(int*)x-*(int*)y);
 }
