#include<stdio.h>
 int a[1005],pos[1005];
 int main()
 {
   int t,i,j,n,ans;
   scanf("%d",&t);
   for(i=1;i<=t;i++)
     {
       scanf("%d",&n);
       for(j=1;j<=n;j++)
 	{
 	  scanf("%d",&a[j]);
 	  pos[a[j]]=j;
 	}
       ans=0;
       for(j=1;j<=n;j++)
 	{
 	  if(pos[j]!=j)
 	    {
 	      ans+=2;
 	      a[pos[j]]=a[j];
 	      a[j]=j;
 	      pos[a[pos[j]]]=pos[j];
 	      pos[j]=j;
 	    }
 	}
       printf("Case #%d: %lf\n",i,(double)ans);
     }
   return 0;
 }

