/* 
  * Code for the Bot Trust Fun Problem.
  * kcrao2000
  */
 
 #include <stdio.h>
 #include "bottrust.h"
 
 static void load_and_init_robo_data(FILE* fp,
                                     int *pnum_presses,
                                     int *pfirst_orange_idx,
                                     int *pfirst_blue_idx,
                                     buttonpress_t *allpresses)
 {
     int i = 0;
     int lastorangeidx = -1;
     int lastblueidx = -1;
 
     fscanf(fp, "%d ", pnum_presses);
 
     for (i = 0; i < *pnum_presses; i++)
     {
         allpresses[i].next = -1;
         
         fscanf(fp, "%c %d ", &(allpresses[i].robot), &(allpresses[i].button));
 
         if (allpresses[i].robot == 'O') {
             if (lastorangeidx != -1) {
                 allpresses[lastorangeidx].next = i;
             }
             
             lastorangeidx = i;
 
             if ((*pfirst_orange_idx) == -1) {
                 *pfirst_orange_idx = i;
             }
 
         } else if (allpresses[i].robot == 'B') {
             if (lastblueidx != -1) {
                 allpresses[lastblueidx].next = i;
             }
             
             lastblueidx = i;
 
             if ((*pfirst_blue_idx) == -1) {
                 *pfirst_blue_idx = i;
             }
 
         } else {
             /* Huh? */
             fprintf(stderr, "Dude, wrong robo code: %c. Fail!\n", allpresses[i].robot);
             *pnum_presses = -1;
             return;
         }
     }
     
     fscanf(fp, "\n", NULL);
 
 }
 
 static int calculate_num_robo_moves(int num_presses,
                                     int first_orange_idx,
                                     int first_blue_idx,
                                     buttonpress_t *allpresses)
 {
     int i = 0;
     int ticks = 0;
 
     int curr_orange_button = 1;
     int curr_blue_button = 1;
     int next_orange_idx = first_orange_idx;
     int next_blue_idx = first_blue_idx;
     int curr_main_idx = 0;
     int button_pressed = 0;
 
 #if BOTTRUST_DEBUG 
     printf("next_orange_idx = %d next_blue_idx = %d\n", next_orange_idx, next_blue_idx);
 #endif
 
     while (curr_main_idx  < num_presses)
     {
         button_pressed = 0;
 
          /* Orange at the sweet button? */
          if (allpresses[curr_main_idx].robot == 'O' &&
              curr_orange_button == allpresses[curr_main_idx].button) {
             /* Yeah - press! */
             button_pressed = 1;
 #if BOTTRUST_DEBUG 
             printf("Orange: Push button %d  ", allpresses[curr_main_idx].button);
 #endif
             next_orange_idx = allpresses[curr_main_idx].next;
 
          } else if (next_orange_idx != -1) {
             /* Check if Movement required */
             if (curr_orange_button < allpresses[next_orange_idx].button) {
                 /* Move a meter, drink a litre */
                 curr_orange_button++;
 #if BOTTRUST_DEBUG 
                 printf("Orange: Move to button %d  ", curr_orange_button);
 #endif
             } else if (curr_orange_button > allpresses[next_orange_idx].button) {
                 /* Move back a meter, drink a litre */
                 curr_orange_button--;
 #if BOTTRUST_DEBUG 
                 printf("Orange: Move to button %d  ", curr_orange_button);
 #endif
             }
 #if BOTTRUST_DEBUG
             else {
                 printf("Orange: Stay at button %d  ", curr_orange_button);
             }
 #endif
          }
         
          /* Blue at the sweet button? */
          if (allpresses[curr_main_idx].robot == 'B' &&
              curr_blue_button == allpresses[curr_main_idx].button) {
             /* Yeah - press! */
             button_pressed = 1;
 #if BOTTRUST_DEBUG 
             printf("Blue: Push button %d\n", allpresses[curr_main_idx].button);
 #endif
             next_blue_idx = allpresses[curr_main_idx].next;
 
          } else if (next_blue_idx != -1) {
             /* Check if Movement required */
             if (curr_blue_button < allpresses[next_blue_idx].button) {
                 /* Move a meter, drink a litre */
                 curr_blue_button++;
 #if BOTTRUST_DEBUG 
                 printf("Blue: Move to button %d\n", curr_blue_button);
 #endif
             } else if (curr_blue_button > allpresses[next_blue_idx].button) {
                 /* Move back a meter, drink a litre */
                 curr_blue_button--;
 #if BOTTRUST_DEBUG 
                 printf("Blue: Move to button %d\n", curr_blue_button);
 #endif
             }
 #if BOTTRUST_DEBUG
             else {
                 printf("Blue: Stay at button %d\n", curr_blue_button);
             }
 #endif
  
          }
         
          if (button_pressed) {
             curr_main_idx++;
          }
        
          /* And the giant gong soundeth */
          ticks++;
 
 #if BOTTRUST_DEBUG
          //printf("ticks = %d curr_main_idx=%d\n", ticks, curr_main_idx);
         printf("next_orange_idx = %d next_blue_idx = %d\n", next_orange_idx, next_blue_idx);
 #endif
     }
 
 
     return ticks;
 }
 
 int main(int argc, char* argv[])
 {
     /* Since limits are known, use static array per test case */
     buttonpress_t allpresses[MAX_BUTTON_PRESSES];
     
     FILE *fp = NULL;
     int num_test_cases = 0;
     int num_presses = 0;
     int first_orange_idx = -1;
     int first_blue_idx = -1;
     int i;
     int num_moves = 0;
 
     if (argc < 2) {
         fprintf(stderr,"Dude, pass a filename\n");
         return -1;
     }
 
     /* Quick and dirty programming - we assume file input is correct, except
      * for some major gotchas */
 
     fp = fopen(argv[1], "r");
 
     if (NULL == fp) {
         fprintf(stderr,"Dude, pass a VALID file\n");
         return -1;
     }
     
     fscanf(fp, "%d\n", &num_test_cases);
 
     for (i = 1; i <= num_test_cases; i++) {
         num_moves = 0;
         num_presses = 0;
         first_orange_idx = -1;
         first_blue_idx = -1;
 
         load_and_init_robo_data(fp,
                                 &num_presses,
                                 &first_orange_idx,
                                 &first_blue_idx,
                                 allpresses);
 
         num_moves = calculate_num_robo_moves(num_presses,
                                              first_orange_idx,
                                              first_blue_idx,
                                              allpresses);
         
         /* Print it, screw it */
         printf("Case #%d: %d\n", i, num_moves);
     }
     
 }

