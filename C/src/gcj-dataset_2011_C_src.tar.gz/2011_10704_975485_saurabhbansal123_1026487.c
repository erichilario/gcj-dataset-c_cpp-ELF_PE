#include<stdio.h>
 #include<stdlib.h>
 
 main(){
   FILE *fp;
   int T,i;
   fp=fopen("input","r");
   fscanf(fp,"%d",&T);
   
   for(i=0;i<T;i++){
   
   	int C,D,N,M,j,k,l,m,t;
 		char A[36][3],B[28][2],X[100],Y[100];  
 		int flag1=0,flag2=0;  
     fscanf(fp,"%d",&C);
     for(j=0;j<C;j++)
       fscanf(fp,"%s",A[j]);
 		fscanf(fp,"%d",&D);
 		for(k=0;k<D;k++)
       fscanf(fp,"%s",B[k]);
     fscanf(fp,"%d",&N);
 	  fscanf(fp,"%s",Y);
     M=N;
     
       //printf("delete %s\n",B);
       //printf("replace %s\n",A);
       //printf("test %s\n",Y);
     
     for(l=0,m=0;m<M,l<N;l++,m++){
 			X[l]=Y[m];
 			//printf("\nX[%d][%d]=%c \n",i,l,X[l]);
 			//printf("l=%d m=%d \n",l,m);
 			//printf("N=%d \n",N);
 			
 			for(k=0;k<D;k++){
 				if(X[l]==B[k][0]){
 				flag1=1;}
 				if(X[l]==B[k][1]){
 				flag2=1;}
 			}
 			//printf("f1=%d f2=%d\n",flag1,flag2);
 			if(l>0){
 			//replace
 				for(j=0;j<C;j++){
 					if(((X[l-1]==A[j][0])&&(X[l]==A[j][1]))||((X[l-1]==A[j][1])&&(X[l]==A[j][0]))){
 		//printf("new character\n");
 						X[l-1]=A[j][2];
 						l=l-1;
 						N=N-1;
 						flag1=0;
 						flag2=0;
 						for(t=0;t<=l;t++){
 							for(k=0;k<D;k++){
 								if(X[t]==B[k][0]){
 								flag1=1;}
 								if(X[t]==B[k][1]){
 								flag2=1;}
 								}
 							}
 						}
 					}
 					    //delete
 					for(k=0;k<C;k++){    
 						if(((X[l]==B[k][0])&&(flag2==1))||((X[l]==B[k][1])&&(flag1==1))){
 						//	      printf("delete all\n");
 							N=N-l-1;
 							l=-1;
 							flag1=0;
 							flag2=0;
 						}
 				}
 			}
 		}	
 				//printf("l=%d m=%d \n",l,m);
 			  //printf("N=%d \n",N);
 				printf("Case #%d: [",i+1);
 				for(l=0;l<N-1;l++)
 				printf("%c, ",X[l]);
 				if(N!=0)
 				printf("%c]\n",X[N-1]);
 				else
 				printf("]\n");
 				
 		}
 	}
 	
   
   
              
   
 
 

