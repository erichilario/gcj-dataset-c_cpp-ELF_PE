#include <stdio.h>
 
 int main() {
     
     int T, N, i, j;
     int Opos, Bpos, pos;
     char c, prev;
     int sum;
     int freetime;
     int dist;
     scanf("%d", &T);
     
     for (i = 1; i <= T; i++) {
         sum = 0;
         freetime = 0;
         Opos = 1;
         Bpos = 1;
         dist = 0;
         prev = 'a';
         scanf("%d", &N);
         printf("Case #%d: ", i);
         for (j = 0; j < N; j++) {
             getchar();
             scanf("%c", &c);
             getchar();
             scanf("%d", &pos);
             if (c == 'O') {
                 if (pos >= Opos) {
                     dist = pos - Opos;
                     Opos = pos;
                 }
                 else if (pos < Opos) {
                     dist = Opos - pos;
                     Opos = pos;
                 }
             }
             else if (c == 'B') {
                 if (pos >= Bpos) {
                     dist = pos - Bpos;
                     Bpos = pos;
                 }
                 else if (pos < Bpos) {
                     dist = Bpos - pos;
                     Bpos = pos;
                 }
             }
             if (prev == c || j == 0) {
                 sum = sum + dist + 1;
                 freetime = freetime + dist + 1;
             }
             else
                 if (freetime >= dist) {
                     sum = sum + 1;
                     freetime = 1;
                 }
                 else if (dist > freetime) {
                     sum = sum + (dist - freetime) + 1;
                     freetime = (dist - freetime) + 1;
                 }
             prev = c;         
         }
 
         printf("%d\n", sum);
     }
     return 0;
 }

