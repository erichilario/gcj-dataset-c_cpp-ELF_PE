#include<stdio.h>
 
 int main()
 {
 	int t,i,j,e,x,y;
 	double g,p,jugados;
 	char array[1000][1000];
 	double wp,owp,oowp,rpi,suma;
 	double wpa[1000],owpa[1000],oowpa[1000];
 	while(scanf("%d",&t)!=EOF)
 	{
 		for(i=0;i<t;i++)
 		{
 			scanf("%d",&e);
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<e;j++)
 			{
 				scanf("%s",array[j]);
 			}
 			
 			for(j=0;j<e;j++)
 			{
 				g=p=jugados=0;
 				for(x=0;x<e;x++)
 				{
 					if(array[j][x]=='1'){g++;jugados++;}
 					if(array[j][x]=='0'){p++;jugados++;}
 				}
 				if(jugados==0)wpa[j]=0;
 				else wpa[j]=g/jugados;
 			}
 			
 			for(j=0;j<e;j++)
 			{
 				suma=0;
 				jugados=0;
 				for(x=0;x<e;x++)
 				{
 					if(array[j][x]=='1' || array[j][x]=='0')
 					{
 						g=0;
 						p=0;
 						for(y=0;y<e;y++)
 						{
 							if(array[x][y]=='1' && y!= j){g++;p++;}
 							if(array[x][y]=='0' && y!= j)p++;
 						}
 						if(p==0)wp=0;
 						else wp=g/p;
 						suma+=wp;
 						jugados++;
 					}
 				}
 				if(jugados==0) owpa[j]=0;
 				else owpa[j]=suma/jugados;
 			}
 			
 			for(j=0;j<e;j++)
 			{
 				jugados=0;
 				suma=0;
 				for(x=0;x<e;x++)
 				{
 					if(array[j][x]=='1' || array[j][x]=='0'){jugados++;suma+=owpa[x];}
 				}
 				if(jugados==0)oowpa[j]=0;
 				else oowpa[j]=suma/jugados;
 			}
 			
 			for(j=0;j<e;j++)
 			{
 				rpi=0.25 * wpa[j] + 0.50 * owpa[j] + 0.25 * oowpa[j];
 				printf("%lf\n",rpi);
 			}
 			
 		}
 	}
 }

