#include<stdio.h>
 
 int ar[11], input[11],n;
 void update(){
 	int i;
 	for(i=1;i<=n;i++)
 		ar[input[i]]=i;
 }
 
 void swap(int a, int b){
 	int temp;
 	temp = input[a];
 	input[a]=input[b];
 	input[b]=temp;
 }
 
 int main(){
 	int t,i,j,k;
 	float current;
 	scanf("%d",&t);
 
 	for(k=1;k<=t;k++){
 		current=0.0;
 		scanf("%d",&n);
 		for(i=1;i<=n;i++)
 			scanf("%d",&input[i]);
 
 		update();
 
 		for(i=1;i<=n;i++){
 			if(i==ar[i])
 				continue;
 			else{
 				current+=2.0;
 				swap(i,ar[i]);
 			}
 			update();
 		}
 		printf("Case #%d: %0.6f\n",k,current);
 	}
 	//system("PAUSE");
 	return 0;
 }

