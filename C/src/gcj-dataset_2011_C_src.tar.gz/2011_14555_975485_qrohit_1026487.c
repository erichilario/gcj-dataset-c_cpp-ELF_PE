#include<stdio.h>
 char str[100];
 char comb[100][3],opp[100][2];
 int ind;
 int t,i,j,k,l,m,c,d,n=0;
 
 int next(int q){
 	int p=0;
 	if(q==(n-1))
 		return n;
 	for(p=q+1;p<n;p++)
 		if(str[p]!='\0')return p;
 	return n;
 	}
 void combine(){
 	//printf("n is now %d %c %c\n",n,str[n-1],str[n]);
 	int p=0,q=0;
 	if(n<1)return;
 		for(q=0;q<c;q++)
 		{
 			if(str[n-1]==comb[q][0]){
 				if(str[n]==comb[q][1]){
 				
 					str[n-1]=comb[q][2];
 					str[n]='\0';
 					n--;
 					}
 				}
 			else if(str[n-1]==comb[q][1])
 				{
 				if(str[n]==comb[q][0]){
 					str[n-1]=comb[q][2];
 					str[n]='\0';
 					n--;
 					}
 				}
 		
 		}
 	
 	
 }
 void clear(){
 	int p=0,q=0,r,s;
 		for(q=0;q<d;q++){
 		for(r=0;r<n;r++){
 			if(opp[q][0]==str[n]){
 				
 					if(str[r]==opp[q][1])
 					
 					 n=-1;
 					
 				}
 			
 				
 			else if(opp[q][1]==str[n]){
 				
 					if(str[r]==opp[q][0])
 					n=-1;
 				}
 			}
 		}
 	}
 
 int main(){
 	
 	scanf("%d",&t);
 	for(l=1;l<=t;l++){
 		char tmp;
 		n=-1;
 		scanf("%d",&c);
 		for(i=0;i<c;i++)
 			scanf("%c%c%c%c",&tmp,&comb[i][0],&comb[i][1],&comb[i][2]);
 		scanf("%d",&d);
 		for(i=0;i<d;i++)
 			scanf("%c%c%c",&tmp,&opp[i][0],&opp[i][1]);
 		scanf("%d",&ind);
 		scanf("%c",&tmp);
 		for(i=0;i<ind;i++)
 			{
 			
 			n++;
 			scanf("%c",&str[n]);
 			combine();
 			clear();
 			}
 	
 	printf("Case #%d: [",l);
 	for(i=0;i<=n;i++)
 	if(i!=n)printf("%c, ",str[i]);
 	else printf("%c",str[i]);
 	printf("]\n");
 	}
 }

