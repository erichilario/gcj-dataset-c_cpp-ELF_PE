#include<stdio.h>
 
 int main(void){
 	int T,c,i,j,d;
 	int C,num,tp,s;
 	__int64 min,max,temp;
 	freopen("F:\\B.in","r",stdin);
     freopen("F:\\B.out","w",stdout);
 	scanf("%d",&T);
 	for(c=1;c<=T;c++){
 		scanf("%d%d",&C,&d);
 		temp=0;
 		min=-10000000;
 		max=-10000000;
 		for(i=0;i<C;i++){
 			scanf("%d%d",&tp,&num);
 			if(i==0) s=tp;
 			for(j=0;j<num;j++){			
 				if(tp-temp>max) max=tp-temp;
 				if(max-(tp-temp)>min) min=tp-temp;
 				temp+=d;
 			}
 		}
 		if(min<=0) printf("Case #%d: 0.0\n",c);
 		else printf("Case #%d: %f\n",c,(min)*1.0/2.0);
 	}
 	fclose(stdout);
 }

