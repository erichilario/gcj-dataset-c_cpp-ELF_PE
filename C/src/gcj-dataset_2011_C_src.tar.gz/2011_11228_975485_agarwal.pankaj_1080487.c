#include<stdio.h>
 #include<math.h>
 int main()
 {
 	int d,tm,lb,lo,o1,b1,t,n,t1,i,s,s1,b[200];
 	char ch,a[200];
 	
 	freopen("2.in","r",stdin);
 	freopen("2.txt","w",stdout);
 	scanf("%d",&t);
 	for(t1=1;t1<=t;t1++)
 	{
 		scanf("%d",&n);
 		for(i=1;i<=n;i++)
 		scanf("%c%c%c%d",&ch,&a[i],&ch,&b[i]);
 		
 		lo=lb=1;
 		//s=0;
 		o1=b1=tm=0;
 		for(i=1;i<=n;i++)
 		{
 			switch(a[i])
 			{
 				case 'O': 
 							d=abs(b[i]-lo);
 							if(o1+d<=tm)
 							{
 								tm++;		
 								o1=tm;
 							}
 							else
 							{
 								tm=(o1+d)+1;
 								o1=tm;	
 							}
 							
 							lo=b[i];
 							break;
 				
 				case 'B': 
 							d=abs(b[i]-lb);
 							if(b1+d<=tm)
 							{
 								tm++;		
 								b1=tm;
 							}
 							else
 							{
 								tm+=(b1+d)-tm+1;
 								b1=tm;	
 							}
 				
 							lb=b[i];
 							break;
 							
 			}
 				
 				
 		/*		if(o1<b[i])  s1=(b[i]-o1)+1; 
 	   					  else if(lo>b[i]) s1=(lo-b[i])+1; else s1=1;
 	   					  
 	   					  	s+=s1;
 							o1=b[i];b1+=s1;
 							lo=b[i];
 							//printf("g %d\n",s1);
 							break;
 				case 'B': if(b1<b[i])  s1=(b[i]-b1)+1; 
 						  else if(lb>b[i]) s1=(lb-b[i])+1; else s1=1;	
 						  
 						  	s+=s1;
 							b1=b[i];o1+=s1;
 							lb=b[i];
 							//printf("g %d\n",s1);  	
 							break;
 			}
 			*/
 		}
 		
 		printf("Case #%d: %d\n",t1,tm);
 	}
 	
 return 0;
 }

