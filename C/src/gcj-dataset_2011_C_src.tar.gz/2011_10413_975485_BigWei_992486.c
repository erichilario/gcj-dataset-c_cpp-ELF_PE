#include <stdio.h>
 int cmp(const void * a , const void * b){
 
 	if(*(int *)a > *(int*)b)
 		return 1;
 	else if(*(int*)a == *(int*)b)
 		return 0;
 	else 
 		return -1;
 }
 int main(){
 	int n;
 	int i,j,k;
 	int N;
 	int input[1002];
 	int temp[1002];
 	int sum=0;
 	scanf("%d",&n);
 	for(i=0; i <n;i++){
 		scanf("%d",&N);
 		sum=N;
 		for(j=0;j<N;j++){
 			scanf("%d",&input[j]);
 			temp[j] = input[j];
 		}
 		qsort(temp,N,sizeof(int),cmp);
 		for(k=0 ; k<N; k ++){
 			if(temp[k] == input[k])
 				sum--;
 		}
 		printf("Case #%d: ",i+1);
 		if(sum%2 ==0){
 			printf("%f\n",(float)sum);
 		}
 		else{
 			printf("%f\n",(float)(sum+2));
 
 		}
 
 	}
 
 
 
 }

