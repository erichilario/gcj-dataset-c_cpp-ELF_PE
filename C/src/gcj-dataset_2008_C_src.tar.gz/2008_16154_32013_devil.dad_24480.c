#include<stdio.h>
 #include<conio.h>
 #include<string.h>
 
 
 int findlatest(char que[100][100],char ser[10][100],int q,int j,int s,int flg)
 {
 	int i,l,temp,k;
 	k=-1;
 	while(flg)
 	{
 	     if((strcmp(que[j],que[j+1])==0)&&(j<q-1))
 		j++;
 	     else
 		flg=0;
 	}
 	for(l=0;l<s;l++)
 	{
 		temp=-1;
 		for(i=j;i<q;i++)
 		{
 			if(strcmp(ser[l],que[i])==0)
 			{
 				temp=i;
 				break;
 			}
 		}
 		if(temp>k)
 		{
 			k=temp;
 		}
 		if(temp==-1)
 			return(temp);
 	}
 	return(k);
 }
 void main()
 {
 	int n,s,q,res[20],i,j,k,l,temp;
 	char ser[10][100],que[100][100];
 	FILE *f;
 	clrscr();
 	scanf("%d",&n);
 	for(i=0;i<n;i++)
 	{
 		scanf("%d",&s);
 		for(j=0;j<s;j++)
 		{
 			fflush(stdin);
 			gets(ser[j]);
 		}
 		scanf("%d",&q);
 		for(j=0;j<q;j++)
 		{
 			fflush(stdin);
 			gets(que[j]);
 		}
 		k=findlatest(que,ser,q,0,s,0);
 		for(j=0;k!=-1;j++)
 			k=findlatest(que,ser,q,k,s,1);
 		res[i]=j;
 	}
 	printf("Output\n");
 	f=fopen("outdevil.txt","w");
 	for(i=0;i<n;i++)
 	{
 		fprintf(f,"Case #%d: %d\r",i+1,res[i]);
 		printf("Case #%d: %d",i+1,res[i]);
 	}
 	fclose(f);
 	getch();
 }
 

