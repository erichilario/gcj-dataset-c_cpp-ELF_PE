// Google codejam template TWO
 
 //  $g++ -g -W -Wall [executable name].c -o [executable name] -lm
 //  $gdb [executable name]
 
 #include <stdio.h>
 #include <iostream>
 #include <math.h>
 // for strtok
 #include <cstring>
 
 using namespace std;
 
 // ASSIGN:
 #define LINES 1200
 #define LENGTH 110
 #define NENAMES 101
 
 inline int name_to_num(const char name_set[][LENGTH], int num_names, const char in_name[]);
 
 // ASSIGN:
 char infile[] = "A-small-attempt0.in";
 //char infile[] = "SwitchesTest.in";
 char outfile[] = "Switches-small.out";
 
 FILE *p_infile = NULL;
 FILE *p_outfile = NULL;
 
 #define ZERO(a,len,eye) \
 for (eye=0;eye<len;eye++) \
 a[eye]=0
 
 #define cZERO(a,len,eye) \
 for (eye=0;eye<len;eye++) \
 a[eye]='\0'
 
 #define GETLINE() \
 if (fgets(line_data[curr_line], LENGTH, p_infile)==NULL) \
 { \
     cout << "Problem in file..."; \
     fclose(p_infile); \
     exit(0); \
 } \
 strtok(line_data[curr_line],chk)
 
 
 
 int main() 
 {
 
   // ASSIGN:
   char line_data[LINES][LENGTH] = {{'\0'}};
   char engine_names[NENAMES][LENGTH] = {{'\0'}};
 
   int total_cases;
 
   p_infile = fopen(infile, "r"); 
   if(p_infile==NULL) {
     printf("Error: can't open file.\n");
     return 1;
   }
 
   
   p_outfile = fopen(outfile, "w"); 
   if(p_outfile==NULL) {
     printf("Error: can't open file.\n");
     return 1;
   }
 
 
   
   char trials[20];
   if (fgets(trials, LENGTH, p_infile)==NULL)
     {
 	cout << "Problem in file...";
 	fclose(p_infile);
 	exit(0);
     }
   total_cases = atoi(trials);
 
   long curr_line;
   int i,j,k;
   int zero_int;
   int S_in;
   int Q_in;
   char chk[] = {'\n','\0'};
   int nameNUMS[LINES] = {0};
   int site_hits[NENAMES];
   int num_switches, num_used;
   char buf[50];
   for (i=0;i<total_cases;i++)
   {
 
     curr_line = 0;
     GETLINE();
     S_in = atoi(line_data[curr_line]);
     curr_line++;
 
     for (k=0;k<S_in;k++)
     {
 	GETLINE();
 	curr_line++;
     }
 
     GETLINE();
     Q_in = atoi(line_data[curr_line]);
     curr_line++;
 
     for (k=0;k<Q_in;k++)
     {
 	GETLINE();
 	nameNUMS[k] = name_to_num(line_data, S_in, line_data[curr_line]);
 	curr_line++;
     }
 
     // carryforwards: nameNUMS[0 to Q_in-1] w/ each value 1 to S_in, file pointer
 
 
     num_switches = 0;
     num_used = 0;
     ZERO(site_hits,NENAMES,zero_int);
     for (k=0;k<Q_in;k++)
     {
 	if (site_hits[nameNUMS[k]] == 0)
 	{
 	  site_hits[nameNUMS[k]]=1;
 	  num_used++;
 	}
 	if (num_used==S_in)
 	{
 	  num_switches++;
 	  num_used = 0;
 	  ZERO(site_hits,NENAMES,zero_int);
 	  k--;
 	}
     }
 
 	
     sprintf(buf,"Case #%d: %d\n",i+1,num_switches);
     fputs(buf, p_outfile);
 //    putc('\n', p_outfile);
 
 
 
 
     for (j=0;j<LINES;j++)
 	cZERO(line_data[j],LENGTH,zero_int);
     for (j=0;j<NENAMES;j++)
 	cZERO(engine_names[j],LENGTH,zero_int);
     ZERO(nameNUMS,LINES,zero_int);
 
   }	// cases
 
 
 
 
 
 
 
 
   // WRITE array to output file
 
   }	// End line-processing loop (i)
 
 
 //  printf("\n\nNow closing file...\n");
 
   fclose(p_outfile);
   fclose(p_infile);
 
 }	// End main
 
 
 
 inline int name_to_num(const char name_set[][LENGTH], int num_names, const char in_name[])
 {
   int i;
   for (i=1;i<=num_names;i++)
   {
     if (strcmp(name_set[i],in_name)==0)
 	return i;
   }
   cout << "oops!" << endl;
   return -1;
 }
 	
 

