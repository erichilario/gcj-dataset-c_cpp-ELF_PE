#include<stdio.h>
 #include<string.h>
 #include<conio.h>
 
 
 
 //Code Jam 08 Problem 1;
 
 #define MAX 200
 void init_marked(char *got, int s);
 
 int main()
 {
 
 	
 	
 	char list[MAX][MAX], query[MAX];
 	int queries[2000];
 		int k,n,s,i,j,q;
 	
 	char got[MAX];
 	int no_marked,switchctr;
 
 	scanf("%d", &n);
 	
 	
 
 	for(k=0;k<n;k++)
 	{
 		scanf("%d", &s);
 		
       //Input search engines
 		for(i=0;i<s;i++)
 		
 		{
 			scanf(" %[^\n]", list[i]);
 			
 			
 		}
 
 		scanf("%d", &q);
 
 		for(i=0;i<q;i++)
 		{
 			scanf(" %[^\n]", query);
 		//input, analyse query values
 			for(j=0;j<s;j++)
 			{
 				if(strcmp(query, list[j]) == 0)
 				{
 					queries[i] = j;
 					break;
 				}
 			}
 		}
 
 		init_marked(got, s);
 		
 		
 
 		no_marked = 0;
 		switchctr = 0;
 		
 		
 
 		for(i=0;i<q;)
 		{
 			if(got[queries[i]] == '\0')
 			{
 				got[queries[i]] = 'x';
 				no_marked++;
 			}
 
 			if(no_marked == s)
 			{
 				no_marked = 0;
 				switchctr++;
 				init_marked(got, s);
 			}
 			else
 				i++;
 		}
 
 
 
 		printf("Case #%d: %d\n", k+1, switchctr);
 	}
 
 	return 0;
 }
 
 void init_marked(char *got, int s)
 {
 	int i;
 	for(i=0;i<s;i++)
 	{
 		got[i] = '\0';
 	}
 }

