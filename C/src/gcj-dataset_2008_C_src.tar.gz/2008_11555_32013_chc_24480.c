#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 char engine[100][80];
 char query[1000][80];
 int m[100];
 
 solve(int s, int q)
 {
   int i, j, k;
   int n=s;
   int sh=0;
 
 /*
   for (i=0; i<s; i++) {
     printf("%s\n", engine[i]);
   }
 */
   for (k=0; k<100; k++)
     m[k]=0;
 
   for (i=0; i<q; i++) {
     // printf("%s\n", query[i]);
     for (j=0; j<s; j++) {
       if (m[j]==1)
         continue;
       if (!strcmp(query[i], engine[j])) {
         n--;
         if (n<=0) {
           sh++;
           for (k=0; k<100; k++)
             m[k]=0;
           // bzero(&m,s*sizeof(int));
           n=s-1;
         }
         m[j]=1;
       }
     }
   }
   return(sh);
 }
 
 main(int argc, char *argv[])
 {
   char *fname;
   char buf[1024], data[80];
   FILE *fp;
   int i, num, line, j, s, q;
 
   if (argc<2)
     fname = "A-small.in";
   else
     fname = argv[1];
 
   fp = fopen(fname, "r");
   if (!fp) {
     fprintf(stderr, "unable to open %s\n", fname);
     exit(-1);
   }
   
   fgets(buf, sizeof(buf), fp);
   num = atoi(buf);
 
   for (i=0; i<num; i++) {
     printf("Case #%d: ",i+1);
 
     fgets(buf, sizeof(buf), fp);
     s= atoi(buf);
     for (j=0; j<s; j++) {
       fgets(data, sizeof(data), fp);
       data[strlen(data)-1]='\0';
       strcpy(engine[j],data);
     }
 
     fgets(buf, sizeof(buf), fp);
     q= atoi(buf);
     for (j=0; j<q; j++) {
       fgets(data, sizeof(data), fp);
       data[strlen(data)-1]='\0';
       strcpy(query[j],data);
     }
     if (q==0)
       printf("0", solve(s, q));
     else
       printf("%d", solve(s, q));
     printf("\n",i+1);
   }
 
   fclose(fp);
 }

