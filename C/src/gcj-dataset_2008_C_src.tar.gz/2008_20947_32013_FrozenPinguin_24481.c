#include <stdio.h>
 #include <stdlib.h>
 
 #define MIN_IN_24 	14400 // = 24*60
 #define BUFLEN 		80
 
 //#define DEBUG1
 
 /******************************************** VARIABLES *******************************************/
 char trA[MIN_IN_24], trB[MIN_IN_24];
 char readBuf[BUFLEN];
 
 struct time
 {
 	unsigned char m;
 	unsigned char h;
 };
 
 typedef struct time tTime;
 int turnT;
 
 /************************************* FUNCTION DECLARATIONS **************************************/
 
 void getTimes(char *buf, tTime* dep, tTime* arr);
 void mark(tTime *dep, tTime *arr, unsigned char *from, unsigned char *to);
 
 /********************************************* MAIN() *********************************************/
 int main(void)
 {
 	int casesQty, casesCnt, aQty, aCnt, bQty, bCnt;
 	tTime tDep, tArr;
 	int th, tm, minCnt, countTrA, countTrB;
 
 	FILE *inFile;
 	
 	inFile = fopen("input.in", "rt");
 	
 	fgets(readBuf, BUFLEN, inFile);
 	sscanf(readBuf, "%i", &casesQty);
 	
 	for(casesCnt = 0; casesCnt < casesQty; casesCnt++)
 	{
 		fgets(readBuf, BUFLEN, inFile);
 		sscanf(readBuf, "%i", &turnT);
 		
 		fgets(readBuf, BUFLEN, inFile);
 		sscanf(readBuf, "%i %i", &aQty, &bQty);
 		
 		for(minCnt = 0; minCnt < MIN_IN_24; minCnt++)
 		{
 			trA[minCnt] = 0;
 			trB[minCnt] = 0;
 		}
 	
 #ifdef DEBUG1
 		printf("Cases %i, Time %i, AtoB %i, BtoA %i\n", casesQty, turnT, aQty, bQty);
 #endif
 		
 		for(aCnt = 0; aCnt < aQty; aCnt++)
 		{
 			fgets(readBuf, BUFLEN, inFile);
 			
 			getTimes(readBuf, &tDep, &tArr);
 			mark(&tDep, &tArr, trA, trB);
 	
 #ifdef DEBUG1
 			printf("From %02i%02i to %02i%02i\n", tDep.h, tDep.m, tArr.h, tArr.m);
 #endif
 		}
 		
 		for(bCnt = 0; bCnt < bQty; bCnt++)
 		{
 			fgets(readBuf, BUFLEN, inFile);
 			
 			getTimes(readBuf, &tDep, &tArr);
 			mark(&tDep, &tArr, trB, trA);
 	
 #ifdef DEBUG1
 			printf("From %02i%02i to %02i%02i\n", tDep.h, tDep.m, tArr.h, tArr.m);
 #endif
 		}
 		
 #ifdef DEBUG1
 		for(th = 0; th < 24; th++)
 		{
 			for(tm = 0; tm < 60; tm++)
 				printf("%2i ", trA[60*th + tm]);
 			printf("\n");
 		}
 		printf("\n");
 
 		for(th = 0; th < 24; th++)
 		{
 			for(tm = 0; tm < 60; tm++)
 				printf("%2i ", trB[60*th + tm]);
 			printf("\n");
 		}
 		printf("\n\n\n");
 #endif
 		
 		countTrA = countTrB = 0;
 		for(minCnt = 0; minCnt < MIN_IN_24; minCnt++)
 		{
 			if(trA[minCnt] < countTrA)
 				countTrA = trA[minCnt];
 			if(trB[minCnt] < countTrB)
 				countTrB = trB[minCnt];
 		}
 		printf("Case #%i: %i %i\n", casesCnt+1, -countTrA, -countTrB);
 
 	} //for(cases)
 
 
 	return 0;
 }
 
 /************************************* FUNCTION DEFINITIONS ***************************************/
 
 void getTimes(char *buf, tTime* dep, tTime* arr)
 {
 	int tmp;
 	
 	tmp = (int)(buf[0] - '0')*10 + (int)(buf[1] - '0');
 	dep->h = tmp;
 
 	tmp = (int)(buf[3] - '0')*10 + (int)(buf[4] - '0');
 	dep->m = tmp;
 
 	tmp = (int)(buf[6] - '0')*10 + (int)(buf[7] - '0');
 	arr->h = tmp;
 
 	tmp = (int)(buf[9] - '0')*10 + (int)(buf[10] - '0');
 	arr->m = tmp;
 }
 
 /**************************************************************************************************/
 
 void mark(tTime *dep, tTime *arr, unsigned char *from, unsigned char *to)
 {
 	int i;
 	
 	for(i = 60 * (dep->h) + dep->m; 			i < MIN_IN_24; i++)
 		from[i]--;
 	
 	for(i = 60 * (arr->h) + (arr->m) + turnT ; 	i < MIN_IN_24; i++)
 		to[i]++;
 }

