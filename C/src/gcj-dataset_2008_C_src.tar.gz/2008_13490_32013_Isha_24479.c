#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 
 
 #define sqr(z) ((z) * (z))
 
 
 double func(double y, double r)
 {
 	double theta = asin(y / r);
 
 	return (sqr(r) * (theta + sin(theta) * cos(theta)) / 2.0);
 }
 
 double cal(double d, double t, double p, double r)
 {
 
 	double k = p + (t / 2.0);
 	double area = 0.0;
 
 	static int const map[4][4] =
 	{
 		{ 0, 0, 1, 2 },
 		{ 0, 0, 1, 2 },
 		{ 0, 0, 3, 4 },
 		{ 0, 0, 0, 5 },
 	};
 
 	{
 		double y;
 
 		for (y = 0; y < r; y += d)
 		{
 			double yu = y + d - k;
 			double yd = y + k;
 
 			double xuc = -1.0;
 			double xdc = -1.0;
 
 			if (yu <= r)
 				xuc = sqrt(sqr(r) - sqr(yu));
 
 			if (yd <= r)
 				xdc = sqrt(sqr(r) - sqr(yd));
 
 //			printf("%d %lf %d %lf\n", caseu, xuc, cased, xdc);
 
 			{
 				double x;
 
 				for (x = 0; x < r; x += d)
 				{
 					double xl = x + k;
 					double xr = x + d - k;
 
 					int caseu;
 					int cased;
 					double a;
 
 
 					if (xuc < 0)
 						caseu = 0;
 					else if (xuc < xl)
 						caseu = 1;
 					else if (xuc < xr)
 						caseu = 2;
 					else
 						caseu = 3;
 
 					if (xdc < 0)
 						cased = 0;
 					else if (xdc < xl)
 						cased = 1;
 					else if (xdc < xr)
 						cased = 2;
 					else
 						cased = 3;
 
 //					printf("%7.4lf %7.4lf %7.4lf %7.4lf\n", yd, yu, xl, xr);
 //					printf("%7.4lf %7.4lf %7.4lf %d %d\n", xuc, xl, xr, caseu, cased);
 //					printf("%d %d | ", caseu, cased);
 
 					switch (map[caseu][cased])
 					{
 					case 0:
 						a = 0.0;
 						break;
 
 					case 1:
 						{
 							double yl = sqrt(sqr(r) - sqr(xl));
 
 							a = func(yl, r) - func(yd, r) - xl * (yl - yd);
 						}
 						break;
 
 					case 2:
 						{
 							double yl = sqrt(sqr(r) - sqr(xl));
 							double yr = sqrt(sqr(r) - sqr(xr));
 
 							a = func(yl, r) - func(yr, r) + xr * (yr - yd) - xl * (yl - yd);
 						}
 						break;
 
 					case 3:
 						a = func(yu, r) - func(yd, r) - xl * (yu - yd);
 						break;
 
 					case 4:
 						{
 							double yr = sqrt(sqr(r) - sqr(xr));
 
 							a = func(yu, r) - func(yr, r) + xr * (yr - yd) - xl * (yu - yd);
 						}
 						break;
 
 					case 5:
 						a = (xr - xl) * (yu - yd);
 						break;
 					}
 
 					area += a;
 				}
 			}
 		}
 	}
 
 	return area;
 }
 
 
 int main(){
 	int nr, te;
 	double f, R, t, r, g;
 	double P, P1, P2;
 	double A, B;
 	double area;
 
 	double PI = 3.1415926535;
 	
 	scanf("%d", &te);
 
 	for ( nr = 0; nr < te; nr++ )
 	{
 		printf("Case #%d: ", nr+1);
 
 		scanf("%lf%lf%lf%lf%lf", &f, &R, &t, &r, &g);
 		//printf("%.8f %.8f %.8f %.8f %.8f\n", f, R, t2, r, g);
 
 		A = (R-(t+f));
 		B = (g+(2*r));
 
 		area = cal(B, 2*r, f, A);
 
 		//printf("S : %lf\n", A*A*PI/4);
 
 		P1 = 1 - (area / (A*A*PI/4));
 		//printf("(1) %.8f\n", P1);
 
 		P2 = 1 - ( ((R-(t+f))*(R-(t+f))*PI) / (R*R*PI) );
 		//printf("(2) %.8f\n", P2);
 
 
 		P =  (P1 * (1 - P2)) + P2;
 
 		printf("%.6f\n", P);
 
 	}
 	return 0;
 }

