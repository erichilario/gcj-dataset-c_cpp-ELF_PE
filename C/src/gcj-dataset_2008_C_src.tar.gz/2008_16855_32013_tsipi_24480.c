// Saving the Universe
 
 #include <stdio.h>
 #include <string.h>
 
 #define MAX_STRING 101 //size includes NULL char
 
 //----------------------------------------------------------------
 
 void filter_input(char *input){
   char *ptr;
 
   if((ptr = strchr(input, '\r')) != NULL){
     *ptr = '\0';
   }
 }
 
 //----------------------------------------------------------------
 
 int main(int argc, char* argv[]){
   FILE *fin;
   int x, y, z, w;
   int cases, engines, queries;
   char *engine_list;
   int *engine_stats; //for storing first encounter of each engine
   char tmp[MAX_STRING];
   char current[MAX_STRING];
   int counter, max_id;
   int switches = 0;
 
   if(argc != 2){
     printf("ERROR! Please use syntax: universe input.txt\n");
     exit(1);
   }
 
   fin = fopen(argv[1], "r");
 
   if(!fin){
     printf("ERROR! Cannot open input file!\n");
     exit(1);
   }
   
   fscanf(fin, "%d", &cases);
 
   for(x=0; x<cases; x++){
     strcpy(current, "");
 
     fscanf(fin, "%d", &engines);
     fgets(tmp, MAX_STRING - 1, fin);
     engine_list = (char*)malloc(engines * MAX_STRING * sizeof(char));
     engine_stats = (int*)malloc(engines * sizeof(int));
 
     for(y=0; y<engines; y++){
       engine_stats[y] = -1;
       fgets(tmp, MAX_STRING - 1, fin);
       filter_input(tmp);
       strcpy(&engine_list[y * MAX_STRING], tmp);
     }
 
     fscanf(fin, "%d", &queries);
     counter = 0;
 
     //advance to next line
     fgets(tmp, MAX_STRING - 1, fin);
 
     for(y=0; y<queries; y++){
       //determine when is the first appearance of each engine
       bzero(tmp,MAX_STRING);
       fgets(tmp, MAX_STRING - 1, fin);
       //printf("before: -%s-\n", tmp);
       filter_input(tmp);
       //printf("after: -%s-\n", tmp);
 
       for(z=0; z<engines; z++){
 	if(strcmp(tmp, &engine_list[z * MAX_STRING]) == 0 && engine_stats[z] == -1){
 	  if(strcmp(current, tmp) != 0){
 	    //note down the query id where the engine is found for the first time`
 	    engine_stats[z] = y;
 	    counter++;
 	  }
 	}
       }
 
       //stop iterating through queries as soon as all engines are used
       //at that point a change is necessary, since we can assume that for
       //all previous queries, this latest engine was being used
       if(counter == engines){
 	switches++;
 	counter = 1;
 	max_id = -1;
 
 	for(z=0; z<engines; z++){
 	  if(engine_stats[z] > max_id){
 	    max_id = engine_stats[z];
 	    strcpy(current, &engine_list[z * MAX_STRING]);
 	  }
 	}
 
 	for(z=0; z<engines; z++){
 	  engine_stats[z] = -1;
 	}
       }
     } 
 
     printf("Case #%d: %d\n", x+1, switches);
 
     //initialize variables for new case
     switches = 0;
     free(engine_stats);
     free(engine_list);
     engines = 0;
     queries = 0;
     counter = 0;
   }
 
   fclose(fin);
 }
 
 //----------------------------------------------------------------

