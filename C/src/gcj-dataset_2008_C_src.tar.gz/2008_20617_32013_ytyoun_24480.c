#include <stdio.h>
 #include <string.h>
 
 /* the length of input string */
 #define LENGTH 105
 #define MAX_ENGINE 105
 #define MAX_QUERY 1005
 
 /* input string */
 char input[LENGTH];
 char engine[LENGTH][MAX_ENGINE];
 char query[LENGTH][MAX_QUERY];
 
 /* previous count in each engine */
 int prev[MAX_ENGINE];
 /* current count in each engine */
 int curr[MAX_ENGINE];
 
 void show_engine(int length)
 {
 	int i;
 
 	for (i = 0; i < length; i++)
 	{
 		printf("%s", engine[i]);
 	}
 
 	printf("-----\n");
 }
 
 void show_query(int length)
 {
 	int i;
 
 	for (i = 0; i < length; i++)
 	{
 		printf("%s", query[i]);
 	}
 
 	printf("-----\n");
 }
 
 /**
  * Find the minimum value in an array except the index-th element
  * and returns it
  */
 int find_min(int size, int index)
 {
 	int i;
 	int min = MAX_ENGINE + 100;
 
 	for (i = 0; i < size; i++)
 	{
 		if (min > prev[i] && i != index)
 			min = prev[i];
 	}
 
 	return min;
 }
 
 int compute(int Q, int S)
 {
 	int i;
 	int q;
 
 	if (Q == 0)
 		return 0;
 
 	/* initialize the array */
 	for (i = 0; i < S; i++)
 	{
 		prev[i] = 0;
 		curr[i] = 0;
 	}
 
 	for (q = 0; q < Q; q++)
 	{
 		for (i = 0; i < S; i++)
 		{
 			if (strcmp(engine[i], query[q]) == 0)
 				curr[i] = find_min(S, i) + 1;
 			else
 				curr[i] = prev[i];
 		}
 
 		/* change prev and curr */
 		for (i = 0; i < S; i++)
 			prev[i] = curr[i];
 	}
 
 	return find_min(S, -1);
 }
 
 int main()
 {
 	int test;
 
 	int i, j;
 	int S;
 	int Q;
 
 	/* read the number of test cases */
 	fgets(input, LENGTH, stdin);
 	sscanf(input, "%d", &test);
 
 	for (i = 1; i <= test; i++)
 	{
 		/* read search engines */
 		fgets(input, LENGTH, stdin);
 		sscanf(input, "%d", &S);
 
 		for (j = 0; j < S; j++)
 		{
 			fgets(input, LENGTH, stdin);
 			strcpy(engine[j], input);
 		}
 
 		/* read queries */
 		fgets(input, LENGTH, stdin);
 		sscanf(input, "%d", &Q);
 
 		for (j = 0; j < Q; j++)
 		{
 			fgets(input, LENGTH, stdin);
 			strcpy(query[j], input);
 		}
 
 /*
 		show_engine(S);
 		show_query(Q);
 */
 		printf("Case #%d: %d\n", i, compute(Q, S));
 	}
 
 	return 0;
 }

