#include<stdio.h>
 
 
 typedef struct 
 {
 	int *ArrivalAtA;
 	int *ArrivalAtB;
 	int *DepartureFromA;
 	int *DepartureFromB;
 
 	int TurnAroundTime;
 
 	int NA;				/* Number of Arrivals at A */
 	int NB;				/* Number of Arrivals at B */
 
 	int	TrainsAtA;
 	int TrainsAtB;
 }
 TESTCASE;
 
 int EvaluateTrains(TESTCASE *tc)
 {
 	int i, j;
 
 	int temp;
 	int prevDep; int prevj;
 
 	for(i = 0; i < tc->NA; i++)
 	{
 		tc->ArrivalAtA[i] += tc->TurnAroundTime;
 	}
 	for(i = 0; i < tc->NB; i++)
 	{
 		tc->ArrivalAtB[i] += tc->TurnAroundTime;
 	}
 
 
 	for(i = 0; i < tc->NA; i++)
 	{
 		temp = 2500;
 		prevj = -1;
 
 		for(j = 0; j < tc->NB; j++)
 		{
 			if(tc->DepartureFromA[j] >= tc->ArrivalAtA[i])
 			{
 				if(temp > (tc->DepartureFromA[j] - tc->ArrivalAtA[i]))
 				{
 					temp = (tc->DepartureFromA[j] - tc->ArrivalAtA[i]);
 					prevj = j;
 				}
 			}
 		}
 
 		if(prevj >= 0)
 			tc->DepartureFromA[prevj] = -1;
 	}
 
 	for(i = 0; i < tc->NB; i++)
 	{
 		temp = 2500;
 		prevj = -1;
 
 		for(j = 0; j < tc->NA; j++)
 		{
 			if(tc->DepartureFromB[j] >= tc->ArrivalAtB[i])
 			{
 				if(temp > (tc->DepartureFromB[j] - tc->ArrivalAtB[i]))
 				{
 					temp = (tc->DepartureFromB[j] - tc->ArrivalAtB[i]);
 					prevj = j;
 				}
 			}
 		}
 
 		if(prevj >= 0)
 			tc->DepartureFromB[prevj] = -1;
 	}
 
 
 	tc->TrainsAtA = 0;
 	tc->TrainsAtB = 0;
 
 	for(i = 0; i < tc->NB; i++)
 	{
 		if(tc->DepartureFromA[i] >= 0)
 			tc->TrainsAtA++;
 	}
 	for(i = 0; i < tc->NA; i++)
 	{
 		if(tc->DepartureFromB[i] >= 0)
 			tc->TrainsAtB++;
 	}
 
 	return 0;
 }
 
 
 int GetTestCaseCount(FILE *fin, int *tcCount)
 {
 	fscanf(fin, " %d", tcCount);
 	return 0;
 }
 
 int GetNextTestCase(FILE *fin, TESTCASE *tc)
 {
 	int hr, min;
 	int i;
 
 	fscanf(fin, " %d", &tc->TurnAroundTime);
 	fscanf(fin, " %d %d", &tc->NB, &tc->NA);
 
 	for(i = 0; i < tc->NB; i++)
 	{
 		fscanf(fin, " %2d : %2d", &hr, &min);
 		tc->DepartureFromA[i] = (hr * 60) + min;
 
 		fscanf(fin, " %2d : %2d", &hr, &min);
 		tc->ArrivalAtB[i] = (hr * 60) + min;
 	}
 
 	for(i = 0; i < tc->NA; i++)
 	{
 		fscanf(fin, " %2d : %2d", &hr, &min);
 		tc->DepartureFromB[i] = (hr * 60) + min;
 
 		fscanf(fin, " %2d : %2d", &hr, &min);
 		tc->ArrivalAtA[i] = (hr * 60) + min;
 	}
 
 	return 0;
 }
 
 int PrintUsage(char *ExeName)
 {
 	fprintf(stderr, "Usage: \n\t%s [<input file> [<output file>]]\n\n", ExeName);
 	fprintf(stderr, "If input file is not provided, stdin will be used.\nIf output file is not provided, stdout will be used\n\n");
 	return 0;
 }
 
 int main(int cArg, char **vArg)
 {
 	FILE *fin;
 	FILE *fout;
 	int tcCount;
 	TESTCASE	tc;
 
 	int i;
 
 	int ArrA[100];
 	int ArrB[100];
 	int DepA[100];
 	int DepB[100];
 
 	tc.ArrivalAtA = ArrA;
 	tc.ArrivalAtB = ArrB;
 	tc.DepartureFromA = DepA;
 	tc.DepartureFromB = DepB;
 
 	fin = stdin;
 	fout = stdout;
 
 	if(cArg > 3)
 	{
 		PrintUsage(vArg[0]);
 		return 0;
 	}
 
 	cArg--;
 	if(cArg)
 	{
 		fin = fopen(vArg[1], "r");
 		if(!fin)
 		{
 			fprintf(stderr, "Cannot open input file [%s], will read from stdin\n", vArg[1]);
 			fin = stdin;
 		}
 
 		cArg--;
 		if(cArg)
 		{
 			fin = fopen(vArg[2], "w");
 			if(!fin)
 			{
 				fprintf(stderr, "Cannot open output file [%s], will write to stdout\n", vArg[2]);
 				fin = stdout;
 			}
 		}
 	}
 
 
 	if(GetTestCaseCount(fin, &tcCount))
 	{
 		fprintf(stderr, "Error reading Input file, Aborting\n\n");
 		return 0;
 	};
 
 	for(i = 0; i < tcCount; i++)
 	{
 		if(GetNextTestCase(fin, &tc))
 		{
 			fprintf(stderr, "Error reading Input file, Aborting\n\n");
 			return 0;
 		}
 
 		EvaluateTrains(&tc);
 		printf("Case #%d: %d %d\n", (i+1), tc.TrainsAtA, tc.TrainsAtB);
 	}
 
 	if(stdin != fin)
 		fclose(fin);
 
 	if(stdout != fout)
 		fclose(fout);
 
 	return 0;
 }

