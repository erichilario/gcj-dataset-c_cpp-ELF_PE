char visited[603][603];
 char marked[603][603];
 int dx[4] = {0,1,0,-1};
 int dy[4] = {1,0,-1,0};
 int main(){
     int N,L,i,j,k,x,y,T,d,tot,l;
     char ch;
     char S[100];
     scanf("%d",&N);
     for(i = 0; i<N; i++){
         for(j = 0; j<603; j++){
             for(k = 0; k<603; k++){
                 visited[j][k] = 0;
                 marked[j][k] = 0;
             }
         }
         x=y=301;
         d = 0;
         tot = 0;
         scanf("%d",&L);
         for(j = 0; j<L; j++){
             scanf("%s%d",S,&T);
             for(k = 0; k<T; k++){
                 for(l = 0;S[l];l++){
                     ch = S[l];
                     if(ch == 'F'){
                         visited[x][y] |= 1<<d;
                         x+=dx[d];
                         y+=dy[d];
                     }else if(ch == 'R'){
                         d = (d+1)%4;
                     }else if(ch == 'L'){
                         d = (d+3)%4;
                     }
                 }
             }
         }
         for(j = 0; j<602; j++){
             int cnt = 0, gap = 0, last = 0;
             for(k = 0; k<602; k++){
                 if((visited[j][k]&2) || (visited[j+1][k] & 8)){
                     last = k;
                 }
             }
             for(k = 0; k<602; k++){
                 if((visited[j][k]&2) || (visited[j+1][k] & 8)){
                     cnt++;
                     //printf("A: %d %d %d %d\n",j,k,visited[j][k],visited[j+1][k]);
                     if(cnt % 2 == 1 && cnt != 1){
                         //printf("A %d %d %d\n",j,gap,cnt);
                         tot+=gap+1;
                     }
                     gap = 0;
                 }else{
                     gap++;
                 }
                 if(cnt > 0 && k < last)
                     marked[j][k] = 1;
             }
         }
         //printf("%d\n",visited[303][302]);
         for(j = 1; j<602; j++){
             int cnt = 0, gap = 0;
             for(k = 1; k<602; k++){
                 if((visited[k][j]&1) || (visited[k][j+1] & 4)){
                     //printf("%d %d\n",k,j);
                     cnt++;
                     if(cnt % 2 == 1 && cnt != 1){
                         //printf("B %d %d %d\n",j,gap,cnt);
                         tot+=gap;
                     }
                     gap = 0;
                 }
                 if(!marked[k][j])
                     gap++;
             }
         }
         printf("Case #%d: %d\n",i+1,tot);
     }
 }

