#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define MAX_LEN	   100
 
 char* filename = "A-small.in";
 
 struct sto_eng {
     char engine_name[MAX_LEN+1];
     int tag;
 };
 
 void getline_from_file(FILE* f, char* line)
 {
     int len = 0;
 
     fgets(line, MAX_LEN, f);
     len = strlen(line);
     if (line[len-1] == '\n') {
         int i = 1;
         if (line[len-2] == '\n') {
             i++;
         }
         line[len-i] = '\0';
     }
 }
 
 int find_name(struct sto_eng* se, int num_engine, char* line)
 {
     int i;
 
     for (i=0; i < num_engine; i++) {
         if (strcmp(se[i].engine_name, line) == 0) {
             return i;
         }
     }
 
     return -1;
 }
 
 void init_sto_eng(struct sto_eng* se, int num_engine, FILE* f)
 {
     int i;
     char line[MAX_LEN+1];
 
     for (i = 0; i < num_engine; i++) {
         getline_from_file(f, line);
         strcpy(se[i].engine_name, line);
         se[i].tag = 1; 
     }
 }
 
 int main(int argc, char** argv)
 {
     FILE* f;
     char line[MAX_LEN+1];
     int len = 0;
     int cases = 0;
     int num_engine = 0;
     int query = 0;
     int i, j, k;
     struct sto_eng* se;
     int ret;
     int switches;
     int switch_pp;
 
     f = fopen(filename, "r");
     getline_from_file(f, line);
     cases = atoi(line);
     for (i; i < cases; i++) {
         switch_pp = 0;
         getline_from_file(f, line);
         switches = num_engine = atoi(line);
         se = (struct sto_eng*)malloc(num_engine * sizeof(struct sto_eng));
         init_sto_eng(se, num_engine, f);
 
         getline_from_file(f, line);
         query = atoi(line);
         
         for (j=0; j < query; j++) {
             getline_from_file(f, line);
             ret = find_name(se, num_engine, line);
             if (se[ret].tag == 1) {
                 se[ret].tag = 0;
                 switches--;
             }
             if (switches == 0) {
                 switch_pp++;
                 switches = num_engine;
                 for (k=0; k < num_engine; k++) {
                     se[k].tag = 1;
                 }
                 ret = find_name(se, num_engine, line);
                 if (se[ret].tag == 1) {
                     se[ret].tag = 0;
                     switches--;
                 }
                 
             }
         }
         fprintf(stdout, "Case #%d: %d\n", i+1, switch_pp);
         
         free(se);
     }
 
     fclose(f);
 
     return;
 }
 

