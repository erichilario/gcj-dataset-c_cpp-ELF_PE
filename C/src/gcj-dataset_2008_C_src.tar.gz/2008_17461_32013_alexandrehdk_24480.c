/* Autor:   Alexandre Hideki Hagihara
  *          alexandre.hagihara@gmail.com
  */
 
 /* Arquivos de include bsicos */
 #include "stdio.h"
 #include "stdlib.h"
 #include "string.h"
 #include "math.h"
 
 /* Defines */
 int contabiliza(int desde);
 int processa(void);
 int menorLista(void);
 int percorre(int desde, int conta);
 
 /* Structs / Typedefs / Enums */
 char listSearches[100][101];
 char listQueries[1000][101];
 int indexes[1000];
 
 /* Functions */
 
 /* Funo readLine
  * L uma linha da entrada padro
  * Parmetros:  lineBuffer  - buffer para onde armazenaremos a linha lida
  *              maxSize     - tamanho mximo do buffer
  *              nCase       - nmero do caso que estamos tratando
  * Retorno:     lineBuffer, se conseguiu ler
  * Se no conseguir ler linha, exibe mensagem de erro e termina o programa
  */
 char* readLine(char *lineBuffer, int maxSize, int nCase)
 {
     char *temp;
     // Leitura da linha
     temp = fgets(lineBuffer, maxSize, stdin);
     // Se no conseguiu ler
     if(temp == NULL)
     {
         fprintf(stderr, "Erro na leitura de dados para caso %i\n", nCase);
         exit(0);
     }
     return temp;
 }
 
 /* Funo readCases
  * L o nmero de casos da entrada padro
  * Retorno:     nmero de casos
  * Se no conseguir ler linha, exibe mensagem de erro e termina o programa
  */
 int readCases(void)
 {
     int temp;
     if(scanf("%i ", &temp) != 1)
     {
         fprintf(stderr, "Erro na leitura do nmero de casos\n");
         exit(0);
     }
     return temp;
 }
 
 /* Programa principal.
  * Para usar, redirecione o arquivo de entrada para a entrada padro,
  * a sada padro para um arquivo e a sada de erro padro para NUL
  * (ou para algum arquivo, se voc deseja debugar)
  * Exemplo: alien <A-small.in 1>alien.out 2>NUL         => Uso mais comum
  *          alien <A-small.in 1>alien.out 2>alien.dbg   => Debug em arquivo
  *          alien <A-small.in 1>alien.out               => Debug na tela
  *          alien <A-small.in                           => Sada e debug na tela
  */
 int search; // Nmero de motores de busca
 int querie;
 int conta[100];
 int main(void)
 {
     char line[4096];
 
     // L o nmero de casos para processar
     int nCases = readCases();
 
     // Loop que l dados de cada caso, processa os dados e joga na sada
     // o resultado do processamento
     for(int c = 1; c <= nCases; c++)
     {
 
         scanf("%i ", &search);
 
         for(int s = 0; s < search; s++)
         {
             readLine(line, sizeof(line), c);
             strncpy(listSearches[s], line, 100);
             listSearches[s][100] = 0;
         }
 
         scanf("%i ", &querie);
         for(int q = 0; q < querie; q++)
         {
             readLine(line, sizeof(line), c);
             strncpy(listQueries[q], line, 100);
             listQueries[q][100] = 0;
         }
         fprintf(stderr, "S = %i | Q = %i\n", search, querie);
         int minimo = processa();
 
         printf("Case #%i: %i", c, minimo);
 
         printf("\n");
     }
     return 1;
 }
 
 int menor;
 int processa(void)
 {
     contabiliza(0);
     if(menorLista() == 0)
         return 0;
     else
     {
         menor = percorre(0, 0);
         
     }
     return menor;
 }
 
 // desde: querie
 // conta: nmero de trocas
 int percorre(int desde, int conta)
 {
     //fprintf(stderr,"Desde %i Atual %i Conta %i Menor %i\n", desde, atual, conta, menor);
     // Se trocamos um valor menor que antes
     int sMax = -1;
     int dMax = 0;
     int dCount;
     for(int s = 0; s < search; s++)
     {
         dCount = 0;
         for(int q = desde; q < querie; q++)
         {
             if(indexes[q] != s)
                 dCount++;
             else
                 break;
         }
         if(dCount > dMax)
         {
             dMax = dCount;
             sMax = s;
         }
     }    
     // sMax contm o ndice da busca que pode ir mais longe
     fprintf(stderr, "Busca atual: %s [%d](%d)\n", listSearches[sMax], desde, dMax);
     if(desde+dMax < querie)
     {
         return percorre(desde+dMax, conta+1);
     }
     return conta;
 }
 
 int menorLista(void)
 {
     int menor = querie;
     for(int i = 0; i < search; i++)
     {
         if(conta[i] < menor)
             menor = conta[i];
     }
     return menor;
 }
 
 // Conta quantas vezes ocorre o nome do mecanismo de busca na lista
 // de queries desde um certo valor
 int contabiliza(int desde)
 {
     for(int i = 0; i < 100; i++)
         conta[i] = 0;
     for(int q = desde; q < querie; q++)
     {
         for(int s = 0; s < search; s++)
         {
             if(strcmp(listQueries[q], listSearches[s]) == 0)
             {
                 indexes[q] = s;
                 //fprintf(stderr, "Q[%i]:%i\n", q, s);
                 conta[s]++;
             }
         }
     }
 }
 

