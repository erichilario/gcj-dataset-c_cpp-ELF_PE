#include <stdio.h>
 #define MAXN 100
 //#define DEBUG
 
 typedef struct Train_T{
 	int depart, arrive;
 	int ok;
 } Train;
 
 int main()
 {
 	Train trains[2][MAXN], tmpt;
 	Train *from, *to; 
 	int i, j, k, n[2], T;
 	int icase, ncase;
 	int ta, tb, tc, td;
 	int ans[2];
 	
 	scanf("%d", &ncase);
 	for(icase= 0; icase < ncase; ++icase){
 		scanf("%d", &T);
 		scanf("%d%d", &n[0], &n[1]);
 		for(k=0; k<2; ++k){
 			for(i=0; i<n[k]; ++i){
 				scanf("%d:%d %d:%d", &ta, &tb, &tc, &td);
 				trains[k][i].depart = ta*60+tb;
 				trains[k][i].arrive = tc*60+td;
 				trains[k][i].ok = 0;
 			}
 		}
 		for(k=0; k<2; ++k){
 			for(i=0; i<n[k]; ++i){
 				for(j=i+1; j<n[k]; ++j){
 					if(trains[k][i].depart > trains[k][j].depart){
 						tmpt = trains[k][i];
 						trains[k][i] = trains[k][j];
 						trains[k][j] = tmpt;
 					}
 				}
 			}
 		}
 		for(k=0; k<2; ++k){
 			from = trains[k];
 			to = trains[1-k];
 			for(i=0; i<n[k]; ++i){
 				for(j=0; j<n[1-k]; ++j){
 					if(from[i].arrive + T <= to[j].depart && to[j].ok == 0){
 						to[j].ok = 1;
 						break;
 					}
 				}
 			}
 		}
 		for(k=0; k<2; ++k){
 			ans[k] = 0;
 			for(i=0; i<n[k]; ++i)
 				ans[k] += (1 - trains[k][i].ok);
 #ifdef DEBUG
 			for(i=0; i<n[k]; ++i)
 				printf("%d %d %d ", trains[k][i].depart, trains[k][i].arrive, trains[k][i].ok);
 			printf("\n");
 #endif
 		}
 		printf("Case #%d: %d %d\n", icase+1, ans[0], ans[1]);
 	}
 
 	return 0;
 }

