#include<stdlib.h>
 int compare(const void *a,const void *b)
 {
   return *((int*)a)-*((int*)b);
 }
 main()
 {
   int N,NA,NB,T,i,j,k,x,y,acnt,bcnt,ru;
   int A[102],B[102],A1[102],B1[102];
   scanf("%d",&N);
   for(i=0;i<N;i++)
   {
     scanf("%d",&T);
     scanf("%d",&NA);
     scanf("%d",&NB);
     for(j=0;j<NA;j++)
     {
       scanf("%d:%d",&x,&y);
       A[j] = x*60+y;
       scanf("%d:%d",&x,&y);
       A1[j] = x*60+y;
     }
     for(j=0;j<NB;j++)
     {
       scanf("%d:%d",&x,&y);
       B[j] = x*60+y;
       scanf("%d:%d",&x,&y);
       B1[j] = x*60+y;
     }
     qsort(A,NA,sizeof(int),compare);
     qsort(A1,NA,sizeof(int),compare);
     qsort(B,NB,sizeof(int),compare);
     qsort(B1,NB,sizeof(int),compare);
     acnt = 0,ru=0;
     for(j=0,k=0;j<NA;j++)
     {
       for(;k<NB && (B1[k]+T)<=A[j];k++,ru++) ;
       if(ru>0)
         ru--;
       else
         acnt++;
     }
     bcnt = 0,ru=0;
     for(j=0,k=0;j<NB;j++)
     {
       for(;k<NA && (A1[k]+T)<=B[j];k++,ru++) ;
       if(ru>0)
         ru--;
       else
         bcnt++;
     }
     printf("Case #%d: %d %d\n",i+1,acnt,bcnt);
   }
   return 0;
 }

