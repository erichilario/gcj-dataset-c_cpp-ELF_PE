#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 // one params
 // 1: Filename
 
 void freadline(char *, FILE *);
 int is_set(int *, int);
 int sematch(char *q, char *selist);
 
 void clear_array(int *array, int num) {
   int i;
 
   for(i=0; i<num; i++) 
     array[i]=0;
 }
 
 int strsize(char *str) {
   int retval=0;
   
   while(str[retval++]!='\0');
 
   return (retval-1);
 }
 
 int main(int argc, char **argv) {
 
   FILE *f1, *f2;
   char sname[100][80], qname[1000][80], tmp[80], *a;
   long n, s, q;
   int i, j, k, last=-1, sarray[100], cnt=0, num_switch=0;
 
   f1=fopen(argv[1], "r");
 
   freadline(tmp, f1);
   n=strtol(tmp, &a, 10);
 
   k=0;
   while(k<n) {
     num_switch=0;
     freadline(tmp, f1);
     s=strtol(tmp, &a, 10);
     //read all the search engines in
     for(i=0; i<s; i++) 
       freadline(sname[i], f1);
     
     clear_array(sarray, s);
     freadline(tmp, f1);
     q=strtol(tmp, &a, 10);
     //read all the queries in
     for(i=0; i<q; i++) 
       freadline(qname[i], f1);
     
     cnt=0;
     while(cnt<q) {
       while(!is_set(sarray, s)) {
 	for(i=0; i<s; i++) {
 	  if(sematch(qname[cnt], sname[i]) != -1) {
 	    sarray[i]=1;
 	    last=i;
 	    break;
 	  }
 	}
 	cnt++;
 	if(cnt == q) break;
       }   
       if(is_set(sarray, s)) {
 	num_switch++;
 	//	printf("%d. %s  ", num_switch, sname[last]);
 	clear_array(sarray, s);
 	cnt--;
       }
       else if(cnt == q) {
 	j=-1;
 	while(sarray[++j]==1);
 	//	printf("%d: %s", (num_switch+1), sname[j]);
       }
     }
     //printf("\n");
     printf("Case #%d: %d\n", ((k++)+1), num_switch); 
   }
 }
 
 void freadline(char *s, FILE *f) {
   int i=0;
   while((s[i++] = fgetc(f)) != '\n');
   
   s[i-1]='\0';
   return;
 }
 
 int is_set(int *sa, int s) {
   int i, retval=1;
 
   for(i=0;i<s; i++) {
     if(sa[i] == 0) {
       retval=0;
       break;
     }
   }
 
   return retval;
 }
 
 
 // Returns -1 or num search engine that matches 
 int sematch(char *q, char *selist) {
   int retval=-1, i;
   
   if((strstr(selist, q) != NULL) && (strsize(q) == strsize(selist))) 
     retval = i;
 
   return retval;
 }

