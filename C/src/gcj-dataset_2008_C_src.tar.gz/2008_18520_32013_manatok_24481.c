#include <stdio.h>
 #include <string.h>
 
 int get_hours(char *in);
 void sort_it();
 
 
 struct train {
    int dep_time;
    int arr_time;
    int dest;//b=1,a=0
    int loc;
 };
 typedef struct train Train;
 
 Train pop();
 
 Train dep_list[1000];
 int A[1000];
 int B[1000];//stations
 
 int A_count;
 int B_count;
 int train_count;
 
  int NA;
  int NB;
 int main() {
  
  char s[200];
  int cases = 0;
  int a_need = 0;//final
  int b_need = 0;
  int T;
 
  int x;
  int i;
  int j;
  char tmp_from_a_l[200][6];
  char tmp_from_b_l[200][6];
  char tmp_from_a_a[200][6];
  char tmp_from_b_a[200][6];
  int found = 0;
  Train temp_train;
  int k = 0;
  gets(s);
  sscanf(s,"%d",&cases);
  
  
  for(i=1;i<=cases;i++) {
       A_count = 0;
       B_count = 0;
       a_need = 0;
       b_need = 0;
       for(x=0;x<1000;x++) A[x] = 0;
       for(x=0;x<1000;x++) B[x] = 0;
    //   for(x=0;x<1000;x++) dep_list[x] = 0;
       train_count = 0;
       gets(s);
       sscanf(s,"%d",&T);
       gets(s);
       sscanf(s,"%d %d",&NA,&NB);
       
       for(x=0;x<NA;x++) {
        gets(s);
        sscanf(s,"%s %s",tmp_from_a_l[x],tmp_from_a_a[x]);
       }
       for(x=0;x<NB;x++) {
        gets(s);
        sscanf(s,"%s %s",tmp_from_b_l[x],tmp_from_b_a[x]);
       // printf("scanedB: %s - %s\n",tmp_from_b_l[x],tmp_from_b_a[x]);
       }
       x=0;
       for(x=0;x<NA;x++) {
          dep_list[x].dep_time = get_hours(tmp_from_a_l[x]);
          dep_list[x].arr_time = get_hours(tmp_from_a_a[x]);
          dep_list[x].dest = 1;
          dep_list[x].loc = 0;
          train_count++;
       }
       for(x=0;x<NB;x++) {
          dep_list[x+NA].dep_time = get_hours(tmp_from_b_l[x]);
          dep_list[x+NA].arr_time = get_hours(tmp_from_b_a[x]);
          dep_list[x+NA].dest = 0;
          dep_list[x+NA].loc = 1;
          train_count++;
       }
       
       sort_it();  
       //for(x=0;x<NA+NB;x++)
         // printf("arr: %d - dep: %d\n",dep_list[x].arr_time,dep_list[x].dep_time);
       
         
       for(x=0;x<NA+NB;x++) {//for each train
         /* for(k=0;k<NA+NB;k++)
          printf("arr: %d - dep: %d\n",dep_list[k].arr_time,dep_list[k].dep_time);
          for(k=0;k<10;k++) printf("A: %d - ",A[k]);
          printf("\n");
          for(k=0;k<10;k++) printf("B: %d - ",B[k]);
          printf("\n");*/
          found = 0;
          //printf("tmp_loc: %d\n",dep_list[0].loc);
          if(dep_list[0].loc == 0) {
            //printf("loc in A\n");
            for(j=0;j<1000;j++) {
               if(A[j] <= dep_list[0].dep_time && A[j] != 0) {
                   for(k=0;k<1000;k++) {
                     if(B[k] == 0) {
                       B[k] = dep_list[0].arr_time+T;
                       break;
                     }
                   }
                   A[j] = 0;
                   found = 1;
                   //printf("found in A\n");
                   break;
               }
            }
            if(found == 0) {
               //printf("not found in A\n");
                a_need++;
                for(k=0;k<1000;k++) {
                 if(B[k] == 0) {
                   B[k] = dep_list[0].arr_time+T;
                   break;
                 }
               }
            }
          }
          else {
               //printf("loc in B\n");
               for(j=0;j<1000;j++) {
               if(B[j] <= dep_list[0].dep_time && B[j] != 0) {
                   for(k=0;k<1000;k++) {
                     if(A[k] == 0) {
                       A[k] = dep_list[0].arr_time+T;
                       break;
                     }
                   }
                   B[j] = 0;
                   found = 1;
                   //printf("found in B\n");
                   break;
               }
            }
            if(found == 0) {
                //printf("not in B\n");
                b_need++;
                for(k=0;k<1000;k++) {
                 if(A[k] == 0) {
                   A[k] = dep_list[0].arr_time+T;
                   break;
                 }
               }
            }
          }
          pop();
       }
       printf("Case #%d: %d %d\n",i,a_need,b_need);
       //getch();
  }
  
  
    
 return 0;
 }
 
 int get_hours(char *in) {
     //printf("in: %s\n",in);
     char hours[3];
     char mins[3];
     int h=0;
     int m = 0;
     int t = 0;
     hours[0] = in[0];
     hours[1] = in[1];
     hours[2] = '\0';
     mins[0] = in[3];
     mins[1] = in[4];
     mins[2] = '\0';
     
     h=atoi(hours);
     m=atoi(mins);
     //printf("hours: %d\nmin: %d\n",h,m);
     t = (h*60)+m;
     return t;
 }
 
 void sort_it(){
      int i;
      int j;
      Train hold;
      for(i=1;i<NA+NB;i++) {
       for(j=0;j<NA+NB-1;j++) {
          if(dep_list[j].dep_time > dep_list[j+1].dep_time) {
             hold.arr_time = dep_list[j].arr_time;
             hold.dep_time = dep_list[j].dep_time;
             hold.dest = dep_list[j].dest;
             hold.loc = dep_list[j].loc;
             
             dep_list[j].arr_time = dep_list[j+1].arr_time;
             dep_list[j].dep_time = dep_list[j+1].dep_time;
             dep_list[j].dest = dep_list[j+1].dest;
             dep_list[j].loc = dep_list[j+1].loc;
             
             dep_list[j+1].arr_time  = hold.arr_time;
             dep_list[j+1].dep_time  = hold.dep_time;
             dep_list[j+1].dest  = hold.dest;
             dep_list[j+1].loc  = hold.loc;
 
          }
          else if(dep_list[j].dep_time == dep_list[j+1].dep_time){
               if(dep_list[j].arr_time > dep_list[j+1].arr_time){
                 hold.arr_time = dep_list[j].arr_time;
             hold.dep_time = dep_list[j].dep_time;
             hold.dest = dep_list[j].dest;
             hold.loc = dep_list[j].loc;
             
             dep_list[j].arr_time = dep_list[j+1].arr_time;
             dep_list[j].dep_time = dep_list[j+1].dep_time;
             dep_list[j].dest = dep_list[j+1].dest;
             dep_list[j].loc = dep_list[j+1].loc;
             
             dep_list[j+1].arr_time  = hold.arr_time;
             dep_list[j+1].dep_time  = hold.dep_time;
             dep_list[j+1].dest  = hold.dest;
             dep_list[j+1].loc  = hold.loc;
               }
          }
       }
      }
 }
 
 Train pop() {
   Train tmp;
   tmp.arr_time = dep_list[0].arr_time;
   tmp.dep_time = dep_list[0].dep_time;
   tmp.dest = dep_list[0].dest;
   tmp.loc = dep_list[0].loc;
   int i;
   for(i=0;i<train_count-1;i++) {
    dep_list[i] = dep_list[i+1];
   }
   train_count--;
 }
   
         
        

