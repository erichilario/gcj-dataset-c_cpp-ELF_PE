#include <stdio.h>
 
 int N;
 
 int T;
 int NA, NB;
 
 int sa[300]; /* Start at a */
 int aa[300]; /* Arrived from a. */
 
 int sb[300]; /* start at b */
 int ab[300]; /* Arrived from b */
 
 int sol1, sol2; 
 
 void solve(void)
 {
 	int sap=0, aap=0, sbp=0, abp=0; /* Positions in the list. */
 	int tca=0, tcb=0;
 	int t=0;
 
 	sol1=0; sol2=0;
 
 	while (sap < NA || sbp < NB)
 	{
 		/* Check earliest outbound */
 		if (sap<NA && (sbp==NB || sa[sap] < sb[sbp]))
 		{
 			/* SA is earlier. */
 			/* Check for incoming. */
 			while (abp<NB && ab[abp]<=sa[sap])
 			{
 				//printf ("Existing train: %d (%d)\n", ab[abp],abp);
 				abp++;
 				tca++;
 			}
 			if (tca==0)
 			{
 				//printf ("New train at A-%d (%d/%d)\n", sb[sap], sap, NA);
 				sol1++;
 			} else
 			{
 				tca--;
 			}
 			sap++;
 		} else
 		{
 			/* SB earlier. */
 			/* SA is earlier. */
 			/* Check for incoming. */
 			while (aap<NA && aa[aap]<=sb[sbp])
 			{
 				//printf ("Existing train: %d (%d)\n", aa[aap],aap);
 				aap++;
 				tcb++;
 			}
 			if (tcb==0)
 			{
 				//printf ("New train at B-%d (%d/%d)\n", sb[sbp], sbp, NB);
 				sol2++;
 			} else
 			{
 				tcb--;
 			}
 			sbp++;
 		}
 			//printf ("%d/%d (%d), %d/%d (%d)\n", sap, NA, sa[sap], sbp, NB, sb[sbp]);
 	}
 
 }
 
 int main (void)
 {
 	int t;
 	int ta, tb, tc, td;
 	int val; 
 	int i,j;
 	int swp;
 	scanf("%d", &N);
 
 	for (t=1; t<=N; t++)
 	{
 		scanf ("%d", &T);
 		scanf ("%d %d", &NA, &NB);
 
 		
 		for (i=0; i<NA; i++)
 		{
 			scanf ("%d:%d %d:%d", &ta, &tb, &tc, &td);
 			val=ta*60+tb;
 			sa[i]=val;
 
 			val=tc*60+td+T;
 			aa[i]=val;
 			//printf ("Train A-%d: %d -> %d\n", i, sa[i], aa[i]);
 		}
 
 		for (i=0; i<NB; i++)
 		{
 			scanf ("%d:%d %d:%d", &ta, &tb, &tc, &td);
 			val=ta*60+tb;
 			sb[i]=val;
 
 			val=tc*60+td+T;
 			ab[i]=val;
 			//printf ("Train B-%d: %d -> %d\n", i, sb[i], ab[i]);
 		}
 
 		/* Bubble sort */
 		for (i=NA-1; i>0; i--)
 		{
 			for (j=0; j<i; j++)
 			{
 				if (sa[j]>sa[j+1])
 				{
 					swp=sa[j+1];
 					sa[j+1]=sa[j];
 					sa[j]=swp;
 				}
 			}
 		}
 		for (i=NA-1; i>0; i--)
 		{
 			for (j=0; j<i; j++)
 			{
 				if (aa[j]>aa[j+1])
 				{
 					swp=aa[j+1];
 					aa[j+1]=aa[j];
 					aa[j]=swp;
 				}
 			}
 		}
 
 		for (i=NB-1; i>0; i--)
 		{
 			for (j=0; j<i; j++)
 			{
 				if (sb[j]>sb[j+1])
 				{
 					swp=sb[j+1];
 					sb[j+1]=sb[j];
 					sb[j]=swp;
 				}
 			}
 		}
 		for (i=NB-1; i>0; i--)
 		{
 			for (j=0; j<i; j++)
 			{
 				if (ab[j]>ab[j+1])
 				{
 					swp=ab[j+1];
 					ab[j+1]=ab[j];
 					ab[j]=swp;
 				}
 			}
 		}
 
 		solve();
 
 		printf ("Case #%d: %d %d\n", t, sol1, sol2);
 
 	}
 }
 
 		/* Debugging statements that were used: */
 		/*
 		*/
 

