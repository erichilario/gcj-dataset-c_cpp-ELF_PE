#include<stdio.h>
 #include<conio.h>
 #define MAX 400
 #define MAXSIZE 60
 char arrival_time[MAX][MAXSIZE]={0};
 char departure_time[MAX][MAXSIZE]={0};
 int arrival[MAX]={0};
 int departure[MAX]={0};
 int tt;
 int NA, NB;
 int da[MAX]={0},db[MAX]={0},aa[MAX]={0},ab[MAX]={0};
 int noa=0,nob=0;
 
 
 void sort(int a[],int n)
 {
       int i=0,j=0,temp=0;
       for(i=0;i<n;i++)
       {
        for(j=i+1;j<n;j++)
            {
                if(a[i]>a[j])
                 {
                 temp=a[i];
                 a[i]=a[j];
                 a[j]=temp;               
                 }
           }    
        }
 }
 void TrainforA()
 {
      int i=0;
      int j=0;
      while(i<NA)
      {
                // da & ab
                while(j<NB){
                      if(ab[j]<=da[i])
                           {
                                     ab[j]=4000;
                                     noa--;
                                     break;
                           }
                           j++;
                }
               i++;
               j=0;
      }
 }
 
 void TrainforB()
 {
      int i=0;
      int j=0;
      while(i<NB)
      {
                // da & ab
                while(j<NA){
                      if(db[i]>=aa[j])
                           {
                                     aa[j]=4000;
                                     nob--;
                                     break;
                           }
                           j++;
                }
               i++;
               j=0;
      }
 }
 convert_min(int i)
 {
    int j=0,temp=0,h[2]={0},m[2]={0},k=0,rem=0;
    char c[2];
    while( departure_time[i][j]!=':')
    {
           c[j]=departure_time[i][j];
           h[j]=c[j]-48;
           j++;
    }
    temp=j;
    j++;       
    while(departure_time[i][j]!='\0')
    {
           c[k]=departure_time[i][j];
           m[k]=c[k]-48;
           j++;
           k++;
    }
    rem=m[0]*10+m[1];
    j=temp;
    if(j==2)
             departure[i]=(h[0]*10 +h[1])*60 + rem ;
    else if(j==1)
            departure[i]=h[0]*60 + rem ;
     else
             departure[i]=0 + rem ;
 
 j=0;
 temp=0;
 k=0;
 rem=0;
 //arrival            
    while( arrival_time[i][j]!=':')
    {
           c[j]=arrival_time[i][j];
           h[j]=c[j]-48;
           j++;
    }
    temp=j;
    j++;       
    while(arrival_time[i][j]!='\0')
    {
           c[k]=arrival_time[i][j];
           m[k]=c[k]-48;
           j++;
           k++;
    }
    rem=m[0]*10+m[1];
    j=temp;
    if(j==2)
             arrival[i]=(h[0]*10 +h[1])*60 + rem +tt;
    else if(j==1)
            arrival[i]=h[0]*60 + rem + tt ;
     else
             arrival[i]=0 + rem + tt;           
    printf("departure %d arrival %d ",departure[i],arrival[i]);
 }
 
 int main()
 {
  int i,j;
  int testcase=1;                                                                     
  int total,k=0;
  int ln=1;
  FILE *fp;
   fp=fopen("output.txt","w");
  scanf("%d",&testcase);
  while(testcase>0)
  {
   tt=0; NA=0; NB=0;k=0;
    printf("turn arount time \n");                    
     scanf("%d",&tt);
     printf("\n NA ");
     scanf("%d",&NA);
     printf("\nNB ");
     scanf("%d ",&NB);
     noa=NA;
     nob=NB;
     total=NA+NB;
               for(i=0;i<total;i++)
               {
                 scanf("%s",departure_time[i]);
                 scanf("%s",arrival_time[i]);
                 convert_min(i);
                 }
                 printf("\n");
                 for(i=0;i<total;i++)
                 {
                 printf("%s \t",departure_time[i]);
                 printf("%s \n",arrival_time[i]);
                 }
                 k=0;
                 j=0;
               //  for(i=0;i<NA;i++)
                 //                 printf("%d  \t ", arrival[i]);
                 for(i=0;i<total;i++)
                 {
                    if(j<NA)
                    {                   
                               da[j]=departure[i];
                                aa[j]=arrival[i];
                                j++;
                                 }
                                 else if (k<NB)
                                 {
                                  db[k]=departure[i];
                                   ab[k]=arrival[i];
                                     k++;    
                                     }
                 }
      printf("\n departure %d \t arrival %d \n",departure[i],arrival[i]);
      
      sort(da,NA);
      sort(db,NB);
     sort(aa,NA);
      sort(ab,NB);
      i=0;
       for(i=0;i<NB;i++)
                    printf("%d  \t ",db[i]);
     
      TrainforA();
      TrainforB();
      //fp=fopen("new.txt","a");
      fprintf(fp,"Case #%d: %d %d\n",ln,noa,nob);
      //printf(" noa =%d , nob=%d",noa,nob);                    
      testcase--;
      ln++;
   }
   fclose(fp); 
   getch();
 }

