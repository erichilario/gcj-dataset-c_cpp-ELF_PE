#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int S,Q;
 int A[1001][1002];
 int B[1001][1002];
 int C[1002];
 int D[1002][1002];
 int lengthb[1001];
 int lengthd[1002];
 
 int set()
 {
     int i,j;
     S=0;
     Q=0;
     for(j=0;j<102;j++)
     {
         for(i=0;i<11;i++)
         {
             A[i][j]=0;
             B[i][j]=0;
             D[i][j]=0;
         }
         C[j]=0;
         lengthd[j]=0;
     }
     for(i=0;i<11;i++)
     {
         lengthb[i]=0;
     }
     return 0;
 }
 
 int checksame(int i,int j)
 {
     int k;
     for(k=0;k<=lengthb[j];k++)
     {
         //printf("B[%d][%d]= %d , D[%d][%d]= %d \n",j,k,B[j][k],i,k,D[i][k]);
         if(B[j][k]==D[i][k])
             continue;
         else
         {
             return 1;
         }
     }
 return 0;
 }
 
 int convertdc()
 {
     C[0]=1000;
     int i,j,k;
     for(i=1;i<=Q;i++)
     {
         for(j=1;j<=S;j++)
         {
             if(lengthb[j]==lengthd[i])
             {
                 k=checksame(i,j);
                 if(k==0)
                 {
                     C[i]=j;
                     break;
                 }
                 else
                     continue;
             }
         }
         if(C[i]==0)
             C[i]=1000; 
     }
 return 0;
 }
 
 int findmina(int i)
 {
     int j,k;
     k=A[i][1];
     for(j=2;j<=S;j++)
     {
         if(k>A[i][j])
             k=A[i][j];
     }
 return k;    
 }
 
 int setvaluesa()
 {
     int i,j,k;
     for(i=1;i<=Q;i++)
     {
         for(j=0;j<=S;j++)
         {
             if(C[i]==j)
                 A[i][j]=1000;
             else
             {
                 k=findmina(i-1);
                 k++;
                 if(k>A[i-1][j])
                     A[i][j]=A[i-1][j];
                 else
                     A[i][j]=k;
             }
         }
     }
 return 0;
 }
 
 int main()
 {
     int N,i,j,k,result;
     FILE *fp;
         if((fp = fopen("KVS1", "w"))==NULL)
         {
             exit(1);
         }
     scanf("%d",&N);
     for(i=1;i<=N;i++)
     {
         set();
         scanf("%d",&S);
         for(j=0;j<=S;j++)
         {
             for(k=0;k<102;k++)
             {
                 scanf("%c",&B[j][k]);
                 if(B[j][k]==10)
                 {
                     lengthb[j]=k;
                     break;
                 }
             }
         }
         scanf("%d",&Q);
         for(j=0;j<=Q;j++)
         {
             for(k=0;k<102;k++)
             {
                 scanf("%c",&D[j][k]);
                 if(D[j][k]==10)
                 {
                     lengthd[j]=k;
                     break;
                 }
             }
         }
 /*        for(j=0;j<10;j++)
     {
         for(i=0;i<Q;i++)
         {
             printf("B[%d][%d] = %d   ",i,j,B[i][j]);
             printf("D[%d][%d] = %d\n",i,j,D[i][j]);
         }
     }
 */        
         convertdc();
         setvaluesa();
         result=findmina(Q);
         fprintf(fp,"Case #%d: %d\n",i,result);
 
         printf("Case #%d: %d\n",i,result);
 /*        for(j=0;j<=Q;j++)
         {
         printf("C[%d] = %d\n",j, C[j]);
         }
         for(i=0;i<=Q;i++)
         {
             for(j=0;j<=S;j++)
             {
             printf("A[%d][%d] = %d",i,j, A[i][j]);
             }
             printf("\n");
         }*/
     }
     fclose(fp);
 return 0;
 }

