#include <stdio.h>
 #include <string.h>
 #define infinit 20000
 #define nmax 1001
 #define lmax 40
 char e[nmax][lmax],s[nmax][lmax];
 int cnt[nmax][nmax];
 int main()
 {
  int t,i,j,k,tt;
  long min,n,c;
  freopen("1.in","r",stdin);
  freopen("1.out","w",stdout);
 
  scanf("%d",&t);
  for (tt=1;tt<=t;tt++)
        {
 	tt=tt;
 	scanf("%ld\n",&n);
 	for (i=1;i<=n;i++) gets(e[i]);
 	scanf("%ld\n",&c);
 	for (i=1;i<=c;i++) gets(s[i]);
 
 	for (i=1;i<=n;i++) cnt[0][i]=0;
 
 	for (i=1;i<=c;i++)
 	    for (j=1;j<=n;j++)
 		{
 		 min=infinit;
 		 for (k=1;k<=n;k++)
 		     if (min>cnt[i-1][k] && k!=j) min=cnt[i-1][k];
 
 		 if (strcmp(s[i],e[j])==0) cnt[i][j]=infinit;
 		    else
 		 if (min+1<cnt[i-1][j]) cnt[i][j]=min+1;
 		    else cnt[i][j]=cnt[i-1][j];
 
 		}
 	min=cnt[c][1];
 	for (i=1;i<=n;i++)
 	    if (min>cnt[c][i]) min=cnt[c][i];
 
 	printf("Case #%d: %d\n",tt,min);
        }
  return 0;
 }
