#include <stdio.h>
 #include <string.h>
 
 
 char sE[105][110];
 char query[1005][110];
 int flag[105][1005];
 int count;
 
 int main(){
 	int t,tk;
 	int s,q;
 	char temp[110];
 	int i, j, fine, last;
 	
 	scanf("%d",&tk);
 	for(t=1;t<=tk;t++){
 		scanf("%d",&s);
 		fgets(temp, 10, stdin);
 		for(i=0;i<s;i++){
 			fgets(sE[i], 105, stdin);
 			if(sE[i][strlen(sE[i])-1]=='\n')sE[i][strlen(sE[i])-1]='\0';
 		}
 		scanf("%d",&q);
 		fgets(temp, 10, stdin);
 		for(i=0;i<q;i++){
 			fgets(query[i], 105, stdin);
 			if(query[i][strlen(query[i])-1]=='\n')query[i][strlen(query[i])-1]='\0';
 			
 		}
 		
 		count = 0;
 		j=0;
 		for(i=0;i<s;i++){
 			if(strcmp(sE[i], query[j])==0) flag[i][j] = 1;
 			else flag[i][j] = 0;
 		}
 		for(j=1;j<q;j++){
 			fine = 0;
 			for(i=0;i<s;i++){
 				if(strcmp(sE[i], query[j])==0){ flag[i][j] = 1; last=i; }
 				else if(flag[i][j-1]==1) flag[i][j] = 1;
 				else { flag[i][j] = 0; fine = 1; }
 			}
 			if(fine==0){ 
 				count++; 
 				for(i=0;i<s;i++) flag[i][j] = 0;
 				flag[last][j] = 1;
 			}
 		}
 		
 		printf("Case #%d: %d\n",t,count);
 	}
 
 	return 0;
 }
