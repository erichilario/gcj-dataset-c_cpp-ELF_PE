#include<stdio.h>
 #include<alloc.h>
 #include<stdlib.h>
 
 typedef struct
 {
  char name[1000];
  int flag;
 }search_engine;
 
 int main()
 {
  search_engine **se;
  FILE *fp,*fp1;
  int min,ns,mse,i,j,k,temp,n_cases,n_se,n_r;
  int done=0;
  char **req;
  char tr[1000];
  int i_cases=-1;
  int count=0;
 
  fp=fopen("input.dat","r");
  fp1=fopen("output.dat","w");
  if(fp==NULL)
  {
   printf("file not found");
   exit(1);
  }
  if(fp1==NULL)
  {
   printf("file not found");
   exit(1);
  }
 
 
  fscanf(fp,"%d\n",&n_cases);
 
 
  while(++i_cases<n_cases)
  {
   fscanf(fp,"%d\n",&n_se);
   se=(search_engine **)malloc(sizeof(search_engine *)*n_se);
 
   for(i=0;i<n_se;i++)
   {
    se[i]=NULL;
    se[i]=(search_engine *)malloc(sizeof(search_engine));
    fscanf(fp,"%[^\n]\n",se[i]->name);
    se[i]->flag=0;
   }
 
   fscanf(fp,"%d\n",&n_r);
   req=(char **)malloc(sizeof(char *)*n_r);
 
   for(i=0;i<n_r;i++)
   {
    fscanf(fp,"%[^\n]\n",tr);
    if(i>0 && stricmp(req[i-1],tr)==0)
    {
     n_r--;
     i--;
    }
    else
    {
     req[i]=NULL;
     req[i]=(char *)malloc(sizeof(char)*strlen(tr)+1);
     if(req[i]==NULL)
     {
      printf("Not enough memory space");
      exit(1);
     }
     strcpy(req[i],tr);
    }
   }
 
   ns=0;
   count=0;
   done=0;
   for(i=0;i<n_r;i++)
   {
    for(j=0;j<n_se;j++)
    {
     if(stricmp(req[i],se[j]->name)==0 && se[j]->flag==0)
     {
      if(done==1)
      {
       ns++;
       count=0;
       done=0;
       for(k=0;k<n_se;k++)
        se[k]->flag=0;
      }
      se[j]->flag=1;
      count++;
      if(count==n_se-1)
      {
       done=1;
 //      ns++;
 //      count=0;
 //      for(k=0;k<n_se;k++)
 //       se[k]->flag=0;
      }
      break;
     }
    }
   }
 //  if(ns>0)
 //   ns--;
 
   fprintf(fp1,"Case #%d: %d\n",i_cases+1,ns);
   printf("Case #%d: %d\n",i_cases,ns);
   for(i=0;i<n_se;i++)
    free(se[i]);
   free(se);
   for(i=0;i<n_r;i++)
    free(req[i]);
   free(req);
  }
  fclose(fp);
  fclose(fp1);
  return 0;
 }
