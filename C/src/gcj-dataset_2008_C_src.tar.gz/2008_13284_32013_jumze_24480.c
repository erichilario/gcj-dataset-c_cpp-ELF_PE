
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 
 // maximum is defined in the question. so, instead of allocating, i'll use arrays for convenience
 
 #define MAX_ENGINE_NAMELEN		100
 #define MAX_ENGINE_COUNT		100
 
 #define MAX_QUERY_LEN			MAX_ENGINE_NAMELEN
 #define MAX_QUERY_COUNT			1000
 
 typedef struct EngineInfo
 {
 	int numberOfEngines;
 	char engineNames[MAX_ENGINE_COUNT][MAX_ENGINE_NAMELEN];
 	int nameCheck[MAX_ENGINE_COUNT];					// sync index with engine names
 }EngineInfo;
 
 
 typedef struct QueryInfo
 {
 	int numberOfQueries;
 	char queries[MAX_QUERY_COUNT][MAX_QUERY_LEN];
 }QueryInfo;
 
 
 
 EngineInfo engineInfo = {0,};
 QueryInfo queryInfo = {0,};
 
 
 
 #define MAXTB					256		// max temp buf
 #define ERROUT()				printf( "input/output file error\n" ); return -1;
 #define DEL_LF( buf )			buf[strlen(buf)-1] = 0
 
 
 
 int main( int argc, char *argv[] )
 {
 	FILE *fp;
 	FILE *fpOut;
 	char buf[MAXTB];
 	int cases;
 	int i, j, k, l;
 	int allCalledCount = 0;			// main counts 
 
 	if( argc != 3 )
 	{
 		printf( "usage : %s input output\n", argv[0] );
 		return -1;
 	}
 
 	fp = fopen( argv[1], "rt" );
 	if( fp == NULL )
 	{
 		ERROUT();
 	}
 
 	fpOut = fopen( argv[2], "wt" );
 	if( fpOut == NULL )
 	{
 		ERROUT();
 	}
 
 
 	if( fgets( buf, MAXTB, fp ) == NULL )
 	{
 		ERROUT();
 	}
 	DEL_LF( buf );
 
 	cases = atoi( buf );
 
 	for( i = 0; i < cases; i ++ )
 	{
 		// each cases
 
 		// init
 		memset( &engineInfo, 0, sizeof(engineInfo) );
 		memset( &queryInfo, 0, sizeof(queryInfo) );
 
 
 		if( fgets( buf, MAXTB, fp ) == NULL )
 		{
 			ERROUT();
 		}
 		DEL_LF( buf );
 
 		// engine names
 		engineInfo.numberOfEngines = atoi( buf );
 
 		for( j = 0; j < engineInfo.numberOfEngines; j ++ )
 		{
 			if( fgets( engineInfo.engineNames[j], MAX_ENGINE_NAMELEN, fp ) == NULL )
 			{
 				ERROUT();
 			}
 			DEL_LF( engineInfo.engineNames[j] );
 		}
 
 		// queries
 		if( fgets( buf, MAXTB, fp ) == NULL )
 		{
 			ERROUT();
 		}
 		DEL_LF( buf );
 
 		queryInfo.numberOfQueries = atoi( buf );
 
 		for( j = 0; j < queryInfo.numberOfQueries; j ++ )
 		{
 			if( fgets( queryInfo.queries[j], MAX_QUERY_LEN, fp ) == NULL )
 			{
 				ERROUT();
 			}
 			DEL_LF( queryInfo.queries[j] );
 		}
 
 		// let us check the queries.
 		for( j = 0; j < queryInfo.numberOfQueries; j ++ )
 		{
 			for( k = 0; k < engineInfo.numberOfEngines; k ++ )
 			{
 				if( strncmp( engineInfo.engineNames[k], queryInfo.queries[j], min( MAX_ENGINE_NAMELEN, MAX_QUERY_LEN ) ) == 0 )
 				{
 					if( engineInfo.nameCheck[k] == 1 )
 					{
 						// no need to go through all the way below
 						break;
 					}
 					
 					engineInfo.nameCheck[k] = 1;
 
 					// check if all engines were queried.
 					for( l = 0; l < engineInfo.numberOfEngines; l ++ )
 					{
 						if( engineInfo.nameCheck[l] == 0 )
 						{
 							break;
 						}
 					}
 					if( l == engineInfo.numberOfEngines )
 					{
 						// which means all engines were queried.
 						memset( engineInfo.nameCheck, 0, sizeof(int) * MAX_ENGINE_COUNT );
 						allCalledCount ++;
 						engineInfo.nameCheck[k] = 1;
 					}
 
 					break;
 				}
 			}
 		}
 
 		fprintf( fpOut, "Case #%d: %d\n", i+1, allCalledCount );
 		allCalledCount = 0;
 	}
 
 	fclose( fp );
 	fclose( fpOut );
 
 	return 0;
 
 }
 
 

