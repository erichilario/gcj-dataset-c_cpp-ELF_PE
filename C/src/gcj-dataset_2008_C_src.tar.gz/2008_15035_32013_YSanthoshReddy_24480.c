#include <stdio.h>
 
 typedef struct tagServers
 {
 	char 		acName[120];
 	signed int  	iBest;
 } Servers;
 
 Servers		gstServers[120];
 char		gacList[1020][120];
 int		giServerCount;
 int		giQueueCount;
 int 		giSwitches = 0;
 
 #if 0
 void Fill()
 {
 	gstServers[0].acName[0] = 'A';
 	gstServers[0].acName[1] = '\0';
 	gstServers[1].acName[0] = 'B';
 	gstServers[1].acName[1] = '\0';
 	giServerCount = 2;
 
 	gacList[0][0] = 'A';
 	gacList[0][1] = '\0';
 	gacList[1][0] = 'B';
 	gacList[1][1] = '\0';
 	gacList[2][0] = 'B';
 	gacList[2][1] = '\0';
 	gacList[3][0] = 'B';
 	gacList[3][1] = '\0';
 	gacList[4][0] = 'A';
 	gacList[4][1] = '\0';
 	giQueueCount = 5;
 
 	return;
 }
 #endif
 
 void Switches(int iStart)
 {
 	int i, j, iMax = 0;
 
 	/* Calculate Best for each Server with in the given Queue range */
 	for (i = 0; i < giServerCount; i++)
 	{
 		for (j = iStart; j < giQueueCount; j++)
 		{
 			//printf("Test : %d %d %s %s\n", i, j, gstServers[i].acName, gacList[j]);
 			if (0 == strcmp(gstServers[i].acName, gacList[j]))
 			{
 				//printf("Test : Matched\n");
 				break;
 			}
 		}
 
 		iMax = (iMax < j) ? (j) : (iMax);
 		//printf("Test : iMax = %d\n", iMax);
 	}
 
 	if (iMax == giQueueCount) return;
 
 	giSwitches ++;
 	Switches(iMax);
 	return;
 }
 
 int main(int argc, char *argv)
 {
 	int iCases = 0, i, j, k;
 	FILE *in;
 	char c;
 
 	in = fopen("A-large.in", "r");
 	if (NULL == in)
 	{
 		return -1;
 	}
 
 	/* Read number of cases from file */
 	fscanf(in, "%d", &iCases);
 	//printf("Test : Cases = %d\n", iCases);
 
 	for (i = 1; i <= iCases; i++)
 	{
 		giSwitches = 0;
 
 		/* Read number of Servers */
 		fscanf(in, "%d\n", &giServerCount);
 		//printf("Test : giServerCount = %d\n", giServerCount);
 
 		/* Read each Server name and store it */
 		for (j = 0; j < giServerCount; j++)
 		{
 			k = 0;
 			while (((c = getc(in)) != '\n') && (c != EOF))
 			{
 				gstServers[j].acName[k] = c;
 				k++;
 			}
 
 			gstServers[j].acName[k] = '\0';
 			//printf("Test : gstServers[%d] = %s\n", j, gstServers[j].acName);
 		}
 
 		/* Read number of Servers in incoming Queue */
 		fscanf(in, "%d\n", &giQueueCount);
 		//printf("Test : giQueueCount = %d\n", giQueueCount);
 
 		/* Read each Server name from incoming Queue and store it */
 		for (j = 0; j < giQueueCount; j++)
 		{
 			k = 0;
 			while (((c = getc(in)) != '\n') && (c != EOF))
 			{
 				gacList[j][k] = c;
 				k++;
 			}
 
 			gacList[j][k] = '\0';
 			//printf("Test : gacList[%d] = %s\n", j, gacList[j]);
 		}
 
 		/* Calculate number of Switches */
 		Switches(0);
 		printf("Case #%d: %d\n", i, giSwitches);
 	}
 
 #if 0
 	Fill();
 	Switches(0);
 	printf("Case #%d: %d\n", 0, giSwitches);
 #endif
 	fclose(in);
 	return 0;
 }

