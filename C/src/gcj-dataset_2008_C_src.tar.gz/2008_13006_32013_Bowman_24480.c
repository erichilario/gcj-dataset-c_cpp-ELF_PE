#include <sys/types.h>
 #include <sys/stat.h>
 #include <fcntl.h>
 #include <stdio.h>
 #include <pwd.h>
 #include <string.h>
 #include <errno.h>
 #include <stdlib.h>
 
 #include <crypt.h>
 #include <unistd.h>
 #include <dirent.h>
 
 #define MAX_NAME_LEN	100
 typedef struct tag_db
 {
     char		dbname[MAX_NAME_LEN];
     int			count;
 
 }TAG_DB;
 
 static TAG_DB sql_db[10];
 static char	target[100][MAX_NAME_LEN];
 
 static int	sql_n = 0;
 static int	target_n = 0;
 static int	switch_n = 0;
 
 
 void show_arrays()
 {
 	int i;
 	
 	printf("%d\n", sql_n);
 	for(i = 0; i < sql_n; i++)
 	{
 		printf("%s\n", sql_db[i].dbname);
 	}
 
 	printf("%d\n", target_n);
 	for(i = 0; i < target_n; i++)
 	{
 		printf("%s\n", target[i]);
 	}
 }
 
 void clear_count()
 {
 	int i;
 
 	for(i = 0; i < sql_n; i++)
 	{
 		sql_db[i].count = 0;
 	}
 }
 
 char * ltrimstr(char *buf)
 {
 
 	int	len;
 	int	i;
 	char *	p;
 
 	len = strlen(buf);
 	if (len <= 0)	return buf;
 
 	p = buf;
 	for (i = 0; i < len; i++)
 	{
 		if (buf[i] == ' ' || buf[i] == '\t')
 			p = buf + i;
 		else
 			break;
 	}
 
 	return p;
 
 }
 
 /************************************************************************
  * 
  ************************************************************************/
 char * rtrimstr(char *buf)
 {
 
 	int	len;
 	int	i;
 
 	len = strlen(buf);
 	if (len <= 0)	return buf;
 
 	for (i = len - 1; i >= 0; i--)
 	{
 		if (buf[i] == ' ' || buf[i] == '\r' || buf[i] == '\n')
 		{
 			buf[i] = '\0';
 		}
 		else	break;
 	}
 
 	return buf;
 
 }
 char *readline(FILE *fp, char *line, int len)
 {
 	char *start;
 
 	if(fgets(line, len, fp) == NULL)
 	{
 		printf("fgets error\n");
 		return NULL;
 	}
 	
 	start = ltrimstr(line);
 	rtrimstr(start);
 
 	return start;
 }
 
 int found_name(const char *name, int temp_db)
 {
 	int i;
 
 	for(i = 0; i < sql_n; i++)
 	{
 		if(!strcmp(name, sql_db[i].dbname))
 		{
 			if(sql_db[i].count == 0)
 			{
 				sql_db[i].count++;
 				temp_db--;
 			}
 			break;
 			
 		}
 	}
 	
 //	printf("temp_db = %d, %s\n", temp_db, name);
 	if(temp_db == 0)
 	{
 		printf("%d: %s\n", switch_n, name);
 		switch_n++;
 		temp_db = sql_n - 1;
 		clear_count();
 		sql_db[i].count = 1;
 	}
 
 	return temp_db;
 }
 
 
 void count_switch_n()
 {
 	int temp_db = sql_n;
 	int	i;
 
 	/* 
 	 * find each target with dbname, until only one dbname left 
 	 * or on target left
 	 */
 	
 	for(i = 0; i < target_n; i++)
 	{
 		temp_db = found_name(target[i], temp_db);
 		
 		
 	}
 
 	for(i = 0; i < sql_n; i++)
 	{
 		if(sql_db[i].count == 0)
 		{
 			printf("%d: %s\n", switch_n, sql_db[i].dbname);
 			break;
 		}
 	}
 	
 
 }
 
 
 int main()
 {
  	FILE            *fp_r, *fp_w;
 	char            line[MAX_NAME_LEN];
 	int				i, j, lines = 0;
 	char			*start;
 	int				cases = 0;
 
 
 	fp_r = fopen("./input", "r");
 	fp_w = fopen("./output", "w+");
 	if(!fp_r || !fp_w)
 	{
 		printf("open file error\n");
 		return 1;
 	}
 
 	start = readline(fp_r, line, sizeof(line));
 	cases = strtoul(start, NULL, 0);
 
 
 	for(i = 0; i < cases; i++)
 //	for(i = 0; i < 1; i++)
 	{
 		start = readline(fp_r, line, sizeof(line));
 		sql_n = strtoul(start, NULL, 0);
 		for(j = 0; j < sql_n; j++)
 		{
 			start = readline(fp_r, line, sizeof(line));
 			strcpy(sql_db[j].dbname, start);
 			sql_db[j].count = 0;			
 
 		}
 
 		start = readline(fp_r, line, sizeof(line));
 		target_n = strtoul(start, NULL, 0);
 		for(j = 0; j < target_n; j++)
 		{
 			start = readline(fp_r, line, sizeof(line));
 			strcpy(target[j], start);
 
 		}
 
 		switch_n = 0;
 		printf("Case #%d:\n", i + 1);
 //		show_arrays();
 //		printf("========================\n");
 		count_switch_n();
 		fprintf(fp_w, "Case #%d: %d\n", i + 1, switch_n);	
 		
 
 	}
 
 
 	fclose(fp_r);
 	fclose(fp_w);
 	return 0;
 }

