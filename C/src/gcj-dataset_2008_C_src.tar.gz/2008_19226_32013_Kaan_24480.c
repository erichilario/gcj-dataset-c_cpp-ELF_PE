#include<stdio.h>
 #include<stdlib.h>
 #define INPUT "saving.in","r"
 #define OUTPUT "saving.out","w"
 #define MAXN 120
 #define MAXQ 1100
 
 int DP[MAXQ][MAXN],N,Q,slast[MAXN],list[MAXQ];
 char string[MAXN][200];
 
 void clear(void)
 {
 	int i,j;
 	for(i=0;i<MAXN;i++)
 	{
 		for(j=0;j<MAXQ;j++)
 			DP[i][j]=-1;
 		slast[i]=0;
 	}
 }
 
 void find(int n,int q)
 {
 	if(DP[n][q]!=-1) return;
 	if(q>Q) {DP[n][q]=0; return;}
 	if(n!=list[q])
 	{
 		find(n,q+1);
 		DP[n][q]=DP[n][q+1];
 		return;
 	}
 	int i,min=1<<30;
 	for(i=1;i<=N;i++)
 	{
 		if(i==n) continue;
 		find(i,q+1);
 		if(DP[i][q+1]<min) min=DP[i][q+1];
 	}
 	DP[n][q]=min+1;
 }
 
 int main()
 {
 	int i,j,t,k,last,cur[200];
 	char c;
 	freopen(INPUT,stdin);
 	freopen(OUTPUT,stdout);
 	scanf(" %d",&t);
 	for(k=0;k<t;k++)
 	{
 		clear();
 		scanf(" %d",&N);
 			scanf("%c",&c);
 		for(i=1;i<=N;i++)
 		{
 			while(1)
 			{
 				scanf("%c",&c);
 				string[i][slast[i]++]=c;
 				if(c=='\n')
 				{
 					string[i][slast[i]-1]=0;
 					break;
 				}
 			}
 		}
 		scanf(" %d",&Q);
 			scanf("%c",&c);
 		for(i=1;i<=Q;i++)
 		{
 			int ok,u;
 			last=0;
 			while(1)
 			{
 				scanf("%c",&c);
 				cur[last++]=c;
 				if(c=='\n')
 				{
 					cur[last-1]=0;
 					break;
 				}
 			}
 			for(j=1;j<=N;j++)
 			{
 				ok=1;
 				if(last!=slast[j]) continue;
 				for(u=0;u<last;u++) if(string[j][u]!=cur[u]) {ok=0; break;}
 				if(ok)
 				{
 					list[i]=j;
 					break;
 				}
 			}
 		}
 		int res=1<<30;
 		for(i=1;i<=N;i++)
 		{
 			find(i,1);
 			if(DP[i][1]<res) res=DP[i][1];
 		}
 		printf("Case #%d: %d\n",k+1,res);
 	}
 	return 0;
 }

