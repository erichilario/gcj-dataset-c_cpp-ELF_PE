#include <stdio.h>
 #include <stdlib.h>
 
 
 #define MAXVIAJES     100
 #define MAXBUSQUEDAS  1000
 #define MAXCASOS      100
 
 
 int main(int argc, char *argv[])
 {
   FILE *infile;
   FILE *outfile;
 
   int i,j,k,l,temp;
   
   int cantidadCasos;
   int viajesAB;
   int viajesBA;
   
   int horasPartidaAB;
   int minutosPartidaAB;
   int horasLlegadaAB;
   int minutosLlegadaAB;
   int horasPartidaBA;
   int minutosPartidaBA;
   int horasLlegadaBA;
   int minutosLlegadaBA;
   
   int  tiempoPartidaAB[MAXVIAJES];
   int  tiempoLlegadaAB[MAXVIAJES];
   int  tiempoPartidaBA[MAXVIAJES];
   int  tiempoLlegadaBA[MAXVIAJES];
 
   int  PAB[MAXVIAJES];
   int  LAB[MAXVIAJES];
   int  PBA[MAXVIAJES];
   int  LBA[MAXVIAJES];
   
   int tiempoRecarga;
      
 
   char tmp_cadena[100];
   char *tmp_cadena2;
   char *tmp_cadena3;
   
   int cantidadTrenesA[MAXCASOS];
   int cantidadTrenesB[MAXCASOS];
 
   if((infile = fopen("c:\\B-large.in", "r")) == NULL) {
     printf("Error Opening File.\n");
     exit(1);
   }
   
 
    fgets(tmp_cadena, 100, infile);
    cantidadCasos = atoi(tmp_cadena);
  
     for(i=0;i!=cantidadCasos;i++)
     {
       fgets(tmp_cadena, 100, infile);
       tiempoRecarga = atoi(tmp_cadena);
 
       fgets(tmp_cadena, 100, infile);
       tmp_cadena2=tmp_cadena;
 
       tmp_cadena3=strtok(tmp_cadena2, " ");
       viajesAB=atoi(tmp_cadena3);
       tmp_cadena3=strtok(NULL, " ");
       viajesBA=atoi(tmp_cadena3);
 
       
       for(j=0;j!=viajesAB;j++)
       {
           fgets(tmp_cadena, 100, infile);      
           tmp_cadena2=tmp_cadena;
 
 
           tmp_cadena3=strtok(tmp_cadena2, ":");
           horasPartidaAB=atoi(tmp_cadena3);
 
           tmp_cadena3=strtok(NULL, " ");
           minutosPartidaAB=atoi(tmp_cadena3);
 
           tmp_cadena3=strtok(NULL, ":");
           horasLlegadaAB=atoi(tmp_cadena3);          
 
           tmp_cadena3=strtok(NULL, " ");
           minutosLlegadaAB=atoi(tmp_cadena3);          
 
           tiempoPartidaAB[j]=(horasPartidaAB*60)+minutosPartidaAB;
           tiempoLlegadaAB[j]=(horasLlegadaAB*60)+minutosLlegadaAB;
       }
       for(j=0;j!=viajesBA;j++)
       {
           fgets(tmp_cadena, 100, infile);      
           tmp_cadena2=tmp_cadena;
 
 
           tmp_cadena3=strtok(tmp_cadena2, ":");
           horasPartidaBA=atoi(tmp_cadena3);
 
           tmp_cadena3=strtok(NULL, " ");
           minutosPartidaBA=atoi(tmp_cadena3);
 
           tmp_cadena3=strtok(NULL, ":");
           horasLlegadaBA=atoi(tmp_cadena3);          
 
           tmp_cadena3=strtok(NULL, " ");
           minutosLlegadaBA=atoi(tmp_cadena3);          
           
           tiempoPartidaBA[j]=(horasPartidaBA*60)+minutosPartidaBA;
           tiempoLlegadaBA[j]=(horasLlegadaBA*60)+minutosLlegadaBA;
       }
           
     
       
     for (j=1; j<viajesAB; j++)
          for(k=0 ; k<viajesAB - 1; k++)
               if (tiempoPartidaAB[k] > tiempoPartidaAB[k+1])
               {
                    temp = tiempoPartidaAB[k];
                    tiempoPartidaAB[k] = tiempoPartidaAB[k+1];
                    tiempoPartidaAB[k+1] = temp;
               }
 
     for (j=1; j<viajesAB; j++)
          for (k=0 ; k<viajesAB - 1; k++)
               if (tiempoLlegadaAB[k] > tiempoLlegadaAB[k+1])
               {
                    temp = tiempoLlegadaAB[k];
                    tiempoLlegadaAB[k] = tiempoLlegadaAB[k+1];
                    tiempoLlegadaAB[k+1] = temp;
               }
               
     for (j=1; j<viajesBA; j++)
          for (k=0 ; k<viajesBA - 1; k++)
               if (tiempoPartidaBA[k] >tiempoPartidaBA[k+1])
               {
                    temp = tiempoPartidaBA[k];
                    tiempoPartidaBA[k] = tiempoPartidaBA[k+1];
                    tiempoPartidaBA[k+1] = temp;
               }
 
     for (j=1; j<viajesBA; j++)
          for (k=0 ; k<viajesBA - 1; k++)
               if (tiempoLlegadaBA[k] > tiempoLlegadaBA[k+1])
               {
                    temp = tiempoLlegadaBA[k];
                    tiempoLlegadaBA[k] = tiempoLlegadaBA[k+1];
                    tiempoLlegadaBA[k+1] = temp;
               }
               
     for(k=0;k!=viajesAB;k++){
         PAB[k]=0;
         LAB[k]=0;}
     for(k=0;k!=viajesBA;k++){
         PBA[k]=0;
         LBA[k]=0;}
 
     cantidadTrenesA[i]=viajesAB;
     cantidadTrenesB[i]=viajesBA;
   
       for(j=viajesAB-1;j!=-1;j--)
       for(k=0;k!=viajesBA;k++)
         {
             if((tiempoLlegadaAB[j]+tiempoRecarga)<=tiempoPartidaBA[k] && PBA[k]==0 && LAB[j]==0)
             {
                 LAB[j]=1;
                 PBA[k]=1;
                 cantidadTrenesB[i]--;
             }
         }
               
       for(j=viajesBA-1;j!=-1;j--)
       for(k=0;k!=viajesAB;k++)
         {
             if((tiempoLlegadaBA[j]+tiempoRecarga)<=tiempoPartidaAB[k] && PAB[k]==0 && LBA[j]==0)
             {
                 LBA[j]=1;
                 PAB[k]=1;
                 cantidadTrenesA[i]--;
             }
         }
                             
     }
 //    viajesAB=atoi(tmp_cadena2);{
 //    printf(tmp_cadena2);
  /*   tmp_cadena2 = strtok (NULL, " ");
     viajesBA=atoi(tmp_cadena2);
     printf(tmp_cadena);*/
     
  /* {
 
      fgets(tmp_cadena, 100, infile);
      cantidadMotores = atoi(tmp_cadena);
 
      for(j=0;j!=cantidadMotores;j++)
     {
       fgets(motores[j],100,infile);
     }
     fgets(tmp_cadena, 100, infile);
     cantidadBusquedas = atoi(tmp_cadena);
 
    
     for(j=0;j!=cantidadBusquedas;j++) 
     {
       fgets(busquedas[j], 100, infile);
 
     }
     
     for(l=0;l!=cantidadMotores;l++)
     {
         esPosibleBuscador[l]=1;
     }
     buscadoresPosibles=cantidadMotores;
     cantidadCambios[i]=0;
     
     for(j=0;j!=cantidadBusquedas;j++)
     {
     
       for(k=0;k!=cantidadMotores;k++)
       {
           if(strcmp(motores[k],busquedas[j])==0 && esPosibleBuscador[k]==1)
           {
               esPosibleBuscador[k] = 0;
               buscadoresPosibles--;
           
               if(buscadoresPosibles==0)
               {
                   cantidadCambios[i]++;
                   for(l=0;l!=cantidadMotores;l++)
                   {
                       esPosibleBuscador[l]=1;
                   }
                   buscadoresPosibles=cantidadMotores-1;
               esPosibleBuscador[k] = 0;
               }
           }
       }
     }  
   }
 */
 
   if((outfile = fopen("c:\\salida.in", "w")) == NULL) {
     printf("Error Creating File.\n");
     exit(1);
   }
   
   for(k=0;k!=cantidadCasos;k++)
   {
       fputs("Case #",outfile);
       fputs(itoa(k+1,tmp_cadena,10),outfile);
       fputs(": ",outfile);
       fputs(itoa(cantidadTrenesA[k],tmp_cadena,10),outfile);     
       fputs(" ",outfile);     
       fputs(itoa(cantidadTrenesB[k],tmp_cadena,10),outfile);     
       fputs("\n",outfile);
 //      printf(itoa(cantidadCambios[k],tmp_cadena,10));
   }
 
   
      
   system("PAUSE");	
   fclose(infile);  /* Close the file */
   return 0;
 }

