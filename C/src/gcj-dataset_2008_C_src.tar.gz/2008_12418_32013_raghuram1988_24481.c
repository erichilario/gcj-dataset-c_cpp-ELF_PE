#include<stdio.h>
 #include<stdlib.h>
 struct time
 {
 	int dep;
 	int arr;
 	int mark;
 };
 void sortbydeptime(struct time *A[],int noA)
 {
 	int i,j;
 	for(i=0;i<noA;i++)
 	{
 		for(j=i+1;j<noA;j++)
 		{
 			if(A[i]->dep>A[j]->dep)
 			{
 				A[i]->arr=A[i]->arr+A[j]->arr;
 				A[j]->arr=A[i]->arr-A[j]->arr;
 				A[i]->arr=A[i]->arr-A[j]->arr;
 				A[i]->mark=A[i]->mark+A[j]->mark;
 				A[j]->mark=A[i]->mark-A[j]->mark;
 				A[i]->mark=A[i]->mark-A[j]->mark;
 				A[i]->dep=A[i]->dep+A[j]->dep;
 				A[j]->dep=A[i]->dep-A[j]->dep;
 				A[i]->dep=A[i]->dep-A[j]->dep;
 			}
 		}
 	}
 }
 void setmarkzero(struct time *A[],struct time *B[],int noA,int noB)
 {
 		int j;
 		for(j=0;j<noA;j++)
 		{
 			
 			A[j]->mark=0;
 		}
 		for(j=0;j<noB;j++)
 		{
 			
 			B[j]->mark=0;
 		}
 }
 void mintrain(struct time *A[],struct time *B[],int noA,int noB,int caseno)
 {
 	int i,j;
 	int solA=0,solB=0;
 	for(i=0;i<noA;i++)
 	{
 		for(j=0;j<noB;j++)
 		{
 			if((A[i]->dep>=B[j]->arr) && (B[j]->mark==0))
 			{
 				A[i]->mark=1;
 				B[j]->mark=1;
 				break;
 			}
 		}
 	}
 	for(i=0;i<noA;i++)
 	{
 		if(A[i]->mark==0)
 		{
 			solA++;
 		}
 	}
 	setmarkzero(A,B,noA,noB);
 	for(i=0;i<noB;i++)
 	{
 		for(j=0;j<noA;j++)
 		{
 			if((B[i]->dep>=A[j]->arr) && (A[j]->mark==0))
 			{
 				B[i]->mark=1;
 				A[j]->mark=1;
 				break;
 			}	
 		}
 	}
 	for(i=0;i<noB;i++)
 	{
 		if(B[i]->mark==0)
 		{
 			solB++;
 		}
 	}
 	printf("Case #%d: %d %d\n",caseno+1,solA,solB);
 }
 int main()
 {
 	int turnaroundtime;
 	int noofcases,noA,noB,i,hr,min;
 	struct time *A[120],*B[120];
 	scanf("%d",&noofcases);
 	for(i=0;i<noofcases;i++)
 	{
 		scanf("%d",&turnaroundtime);
 		scanf("%d",&noA);
 		scanf("%d",&noB);
 		int j,k;
 		for(j=0;j<noA;j++)
 		{
 			A[j]=(struct time *)malloc(sizeof(struct time));
 			scanf("%d:%d",&hr,&min);
 			A[j]->dep=hr*60+min;
 			scanf("%d:%d",&hr,&min);
 			A[j]->arr=hr*60+min+turnaroundtime;
 		}
 		for(j=0;j<noB;j++)
 		{
 			B[j]=(struct time *)malloc(sizeof(struct time));
 			scanf("%d:%d",&hr,&min);
 			B[j]->dep=hr*60+min;
 			scanf("%d:%d",&hr,&min);
 			B[j]->arr=hr*60+min+turnaroundtime;			
 		}
 	setmarkzero(A,B,noA,noB);
 	sortbydeptime(A,noA);
 	sortbydeptime(B,noB);
 	mintrain(A,B,noA,noB,i);
 	}
 	return 0;
 }
