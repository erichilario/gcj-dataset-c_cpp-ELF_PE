#include<stdio.h>
 char s[100][100],q[1000][100];
 int count,count1;
 int findvalue(int n)
 {
 	int k,j,i,number[100],l=0,answer=0;
 	for(i=0;i<100;i++)
 		number[i]=0;
 	if(n==count1)
 		return(0);
 	else
 	{
 		for(k=n;k<count1;k++)
 			for(j=0;j<count;j++)
 				if(strcmp(q[k],s[j])==0)
 					number[j]++;
 		for(j=0;j<count;j++)
 			if(number[j]==0)
 				break;
 		if(j==count)
 		{
 			for(k=0;k<count;k++)
 				if(strcmp(q[n],s[k])==0)
 					break;
 			for(j=0;j<count;j++)
 			{
 				if(j!=k)
 				{
 					for(i=n+1;i<count1;i++)
 						if(strcmp(s[j],q[i])==0)
 							break;
 					if(answer<i)
 						answer=i;
 				}
 			}
 			return(1+findvalue(answer));
 		}
 		else
 			return(0);
 	}
 }
 int main(int argc,char *argv[])
 {
 	int *number,l,i,j,k,min,select,answer,num;
         FILE *fp;
         fp=fopen(argv[1],"r");
         fscanf(fp,"%d",&num);
 	char t[100];
         for(i=0;i<num;i++)
         {
 		answer=l=0;
         	fscanf(fp,"%d",&count);
 		fgets(t,100,fp);
 		for(j=0;j<count;j++)
 			fgets(s[j],100,fp);
 		fscanf(fp,"%d",&count1);
 		fgets(t,100,fp);
 		for(j=0;j<count1;j++)
 			fgets(q[j],100,fp);
 		if(count1>0)
 		{
 			answer=findvalue(0);
 		}
 		printf("Case #%d: %d\n",i+1,answer);
 	}
 }			

