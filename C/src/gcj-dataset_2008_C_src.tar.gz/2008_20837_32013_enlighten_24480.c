#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main()
 {
     int allnum,casenum,ennum,connum,sw,cnt;
     char buffer[128];
     char en[100][128];
     int i,j,k;
     char map[100];
     FILE *fp = fopen("a.in","r");
     fgets(buffer,128,fp);
     allnum = atoi(buffer);
     for(casenum=1;casenum<=allnum;casenum++)
     {
            fgets(buffer,128,fp);
            ennum = atoi(buffer);                 
            for(i=0;i<ennum;i++)
            {
                fgets(en[i],128,fp);
             }
             fgets(buffer,128,fp);
             connum = atoi(buffer);
             memset(map,0,100);
             sw = 0;
             cnt = 0;
             for(i=0;i<connum;i++)
             {
                 fgets(buffer,128,fp);
                 for(j=0;j<ennum;j++)
                 {
                      if(strcmp(buffer,en[j]) == 0)
                          break;               
                 }
                 if(j<ennum)
                 {
                   if(map[j] == 0)
                   {
                         cnt++;
                         if(cnt == ennum)
                         {
                           memset(map,0,100);
                           cnt=1;    
                           sw++;   
                         }       
                         map[j] = 1;        
                   }           
                            
                 }                 
                                  
              }                        
                                             
                                             
             printf("Case #%d: %d\n",casenum,sw);         
         }
     
     
     
     return 0;
     }

