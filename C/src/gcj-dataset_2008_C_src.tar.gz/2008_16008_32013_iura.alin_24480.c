/*
  *      SavingTheUniverse.c
  *      
  *      Copyright 2008 Iura <iura@iura-pc>
  *      
  *      This program is free software; you can redistribute it and/or modify
  *      it under the terms of the GNU General Public License as published by
  *      the Free Software Foundation; either version 2 of the License, or
  *      (at your option) any later version.
  *      
  *      This program is distributed in the hope that it will be useful,
  *      but WITHOUT ANY WARRANTY; without even the implied warranty of
  *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *      GNU General Public License for more details.
  *      
  *      You should have received a copy of the GNU General Public License
  *      along with this program; if not, write to the Free Software
  *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
  *      MA 02110-1301, USA.
  */
 
 
 #include <stdio.h>
 #include <string.h>
 
 void central_system(FILE *fin, FILE *fout,int casee)
 {
 	int i,j,n,m,tabel[100],nr_change=0,sw,poz;
 	char search_engine[100][100],tmp[100];
 	fscanf(fin,"%d\n",&n);
 	for (i=0; i<n; i++)
 		fgets(search_engine[i],100,fin);
 	fscanf(fin,"%d\n",&m);
 	for (i=0; i<n; i++)
 		tabel[i]=0;
 	for (j=0; j<m; j++)
 	{
 		sw=0;
 		for (i=0; i<n; i++)
 			if (tabel[i]==0)
 			{
 				sw++;
 				poz=i;
 			}
 		fgets(tmp,100,fin);
 		if (sw==1 && strcmp(search_engine[poz],tmp)==0)
 		{
 			for (i=0; i<n; i++)
 				tabel[i]=0;
 			tabel[poz]=1;
 			nr_change++;
 		}
 		else
 		{
 			for (i=0; i<n; i++)
 				if (strcmp(tmp,search_engine[i])==0)
 					tabel[i]++;
 		}
 	}	
 	fprintf(fout,"Case #%d: %d\n",casee,nr_change);	
 }
 
 void citeste_fisier (void)
 {
 	int i,n;
 	FILE *fin,*fout;
 	fin=fopen("A-small-attempt4.in","rt");
 	fout=fopen("Output.out","wt");
 	fscanf(fin,"%d\n",&n);
 	for (i=1; i<=n; i++)
 	{
 		central_system(fin,fout,i);
 	}
 	fclose(fin);
 	fclose(fout);
 }
 
 int main(int argc, char** argv)
 {
 	citeste_fisier();
 	return 0;
 }

