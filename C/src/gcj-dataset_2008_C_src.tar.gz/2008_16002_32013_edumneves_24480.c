#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define MAXS 120
 #define MAXENGS 120
 #define MAXQUERYS 1020
 
 struct ENG{
 	char name[MAXS];
 	int nrep;
 };
 
 struct ENG seng[MAXENGS];
 char query[MAXQUERYS][MAXS];
 
 int comp(const void *a, const void *b)
 {
 	struct ENG a1, b1;
 	a1 = *((struct ENG*)a);
 	b1 = *((struct ENG*)b);
 	return(strcmp(a1.name, b1.name));
 }
 
 int main(void)
 {
 	int n, s, q, tc;
 	register int i,j, k;
 	int ns;
 	char ult[MAXENGS];
 	int ndisp;
 	
 	struct ENG *patual;
 	
 	scanf("%d\n", &n);
 	tc = 1;
 	for (i=0; i< n; i++)
 	{
 		printf("Case #%d: ", tc++);
 		scanf("%d\n", &s);
 		
 		ns = 0;				
 		for (j=0; j<s; j++)
 			gets(seng[j].name);
 		qsort(seng, s,sizeof(seng[0]), comp);
 
 		scanf("%d\n", &q);
 		for(j=0; j<q; j++)
 			gets(query[j]);
 		for(k=0; k<s; k++)
 			seng[k].nrep = 0;
 			
 		/*Calculating switchs*/
 		ult[0] = '\0';
 		ndisp = s;
 		for(j=0; j<q; j++)
 		{
 			patual = bsearch(query[j], seng, s,sizeof(seng[0]), comp);
 						
 			(*patual).nrep++;
 					
 			if (strcmp(ult, (*patual).name) && ((*patual).nrep == 1))
 			{
 				ndisp--;
 				/* Find the last search engine, we have to change*/
 				if (ndisp == 0)
 				{
 					ns++;
 					strcpy(ult, (*patual).name);
 					ndisp = s-1;
 					for(k=0; k<s; k++)
 						seng[k].nrep = 0;
 				}
 			}
 			
 		}
 			
 		printf("%d\n", ns);
 	}
 	
 	return 0;
 }
 

