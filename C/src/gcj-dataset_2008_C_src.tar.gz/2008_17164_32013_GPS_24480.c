#include<stdio.h>
 #include<string.h>
 
 typedef struct 
 {
 	int *Query;
 	int QueryCount;
 	int EngineCount;
 
 	int Switches;
 }
 TESTCASE;
 
 int EvaluateSearchEngines(TESTCASE *tc)
 {
 	int fTable[100];
 	int QCount;
 
 	int i, j;
 
 	tc->Switches = 0;
 
 	QCount		= tc->EngineCount;
 	for(i = 0; i < tc->EngineCount; i++)
 	{
 		fTable[i] = 0;
 	}
 
 	for(i = 0; i < tc->QueryCount; i++)
 	{
 		if(fTable[tc->Query[i]] == 0)
 		{
 			QCount--;
 			fTable[tc->Query[i]] = 1;
 		}
 
 		if(QCount == 0)
 		{
 			tc->Switches++;
 
 			QCount		= tc->EngineCount - 1;
 			for(j = 0; j < tc->EngineCount; j++)
 			{
 				fTable[j] = 0;
 			}
 			fTable[tc->Query[i]] = 1;
 		}
 	}
 
 	return 0;
 }
 
 int GetTestCaseCount(FILE *fin, int *tcCount)
 {
 	fscanf(fin, " %d", tcCount);
 	return 0;
 }
 
 int GetNextTestCase(FILE *fin, TESTCASE *tc)
 {
 	int i, j;
 
 	char EngineNames[100][101];		/* EngineName[EngineNo][CharNo] */
 
 	char Query[101];
 
 	fscanf(fin, " %d", &tc->EngineCount);
 
 	for(i = 0; i < tc->EngineCount; i++)
 	{
 		fscanf(fin, " %[a-zA-Z0-9 ]", EngineNames[i]);
 	}
 
 	fscanf(fin, " %d", &tc->QueryCount);
 
 	for(i = 0; i < tc->QueryCount; i++)
 	{
 		fscanf(fin, " %[a-zA-Z0-9 ]", Query);
 
 		for(j = 0; j < tc->EngineCount; j++)
 		{
 			if(0 == strncmp(Query, EngineNames[j], 100))
 			{
 				tc->Query[i] = j;
 				break;
 			}
 		}
 	}
 
 	return 0;
 }
 
 int PrintUsage(char *ExeName)
 {
 	fprintf(stderr, "Usage: \n\t%s [<input file> [<output file>]]\n\n", ExeName);
 	fprintf(stderr, "If input file is not provided, stdin will be used.\nIf output file is not provided, stdout will be used\n\n");
 	return 0;
 }
 
 int main(int cArg, char **vArg)
 {
 	FILE *fin;
 	FILE *fout;
 	int tcCount;
 	TESTCASE	tc;
 
 	int Queries[1000];
 	int i;
 
 	tc.Query = Queries;
 
 	fin = stdin;
 	fout = stdout;
 
 	if(cArg > 3)
 	{
 		PrintUsage(vArg[0]);
 		return 0;
 	}
 
 	cArg--;
 	if(cArg)
 	{
 		fin = fopen(vArg[1], "r");
 		if(!fin)
 		{
 			fprintf(stderr, "Cannot open input file [%s], will read from stdin\n", vArg[1]);
 			fin = stdin;
 		}
 
 		cArg--;
 		if(cArg)
 		{
 			fin = fopen(vArg[2], "w");
 			if(!fin)
 			{
 				fprintf(stderr, "Cannot open output file [%s], will write to stdout\n", vArg[2]);
 				fin = stdout;
 			}
 		}
 	}
 
 
 	if(GetTestCaseCount(fin, &tcCount))
 	{
 		fprintf(stderr, "Error reading Input file, Aborting\n\n");
 		return 0;
 	};
 
 	for(i = 0; i < tcCount; i++)
 	{
 		if(GetNextTestCase(fin, &tc))
 		{
 			fprintf(stderr, "Error reading Input file, Aborting\n\n");
 			return 0;
 		}
 
 		EvaluateSearchEngines(&tc);
 		fprintf(fout, "Case #%d: %d\n", (i+1), tc.Switches);
 	}
 
 	if(stdin != fin)
 		fclose(fin);
 
 	if(stdout != fout)
 		fclose(fout);
 
 	return 0;
 }

