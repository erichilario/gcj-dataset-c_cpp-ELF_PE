#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, char *argv[])
 {
   int s[30],q[30];
   int i,j,k,n,check;
   char ser[30][110][50];
   int visit[200];
   int switches;
   char qer[25][500][80];
   //for(i=0;i<30;i++)
 //  {
 //  s[i]=0;
 //  q[i]=0;
 //  }
   
   scanf("%d",&n);
   for(j=1;j<=n;j++)
   {
    scanf("%d",&s[j]);
    //printf("input s[%d]= %d\n",j,s[j]);
    for(i=0;i<=s[j];i++)
    {
     gets(ser[j][i]);
    }
    //printf("%s   %s\n",ser[j][1],ser[j][i-1]);
    scanf("%d",&q[j]);
    //printf("input q[%d]= %d\n",j,q[j]);
    for(i=0;i<=q[j];i++)
    {
     gets(qer[j][i]);
    }
   }
   for(j=1;j<=n;j++)
   {
                   //printf("%s   %s\n",ser[j][1],ser[j][s[j]]);
                   for(i=1;i<=s[j];i++)
                   {
                    visit[i]=0;
                    //printf("visit[%d]= %d\n",i,visit[i]);
                   }
                   k=1;
                   switches=0;
                   while(k<=q[j])
                   {
                                 
                    for(i=1;i<=s[j];i++)
                    {
                                       if(strcmp(qer[j][k],ser[j][i])==0)
                                       {
                                        visit[i]=1;
                                        //printf("match: k= %d  i= %d quer= %s  ser= %s\n",k,i,qer[j][k],ser[j][i]);
                                        break;
                                       }
                    }
    
                    check=1;
                    for(i=1;i<=s[j];i++)
                    {
                     if(visit[i]==0)
                     {
                      check=0;
                       break;
                     }
                    }
                    //for(i=1;i<=s[j];i++)
 //                   {
 //                            printf("visit[%d]= %d\n",i,visit[i]);
 //                   }
                    
                    if(check==1)
                    {
                             
                             switches++;
                             for(i=1;i<=s[j];i++)
                             {
                                                visit[i]=0;
                                                
                             }
                    }
                    else
                    {
                     k++;
                    }
                   } 
   printf("Case #%d: %d\n",j,switches);
   }
   
   return 0;
 }
 

