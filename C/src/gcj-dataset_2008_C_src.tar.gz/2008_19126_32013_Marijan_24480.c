#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define S 100
 #define Q 1000
 #define MAX 101
 
 char s[S][MAX];
 char *q[Q];
 
 int f(const void *l,const void *d) {
 	return strcmp(l,d); }
 
 main() {
 	int i,j,k,l,n,bs,bq,cq,mq;
 	char buff[MAX],*ms;
 
 	gets(buff);
 	sscanf(buff,"%d",&n);
 	for (k=1;k<=n;k++) {
 		gets(buff);
 		sscanf(buff,"%d",&bs);
 		for (i=0;i<bs;i++) gets(s[i]);
 		qsort(s,bs,MAX,f);
 		gets(buff);
 		sscanf(buff,"%d",&bq);
 		for (i=0;i<bq;i++) q[i]=bsearch(gets(buff),s,bs,MAX,f);
 		for (cq=mq=0,l=0;;l++,cq=mq) {
 			for (ms=s[cq],i=0;i<bs;i++) {
 				for (j=cq;j<bq;j++) if (s[i]==q[j]) break;
 				if (j==bq) break;
 				if (mq<j) { ms=s[i]; mq=j; }
 			}
 			if (i!=bs) break;
 		}
 		printf("Case #%d: %d\n",k,l);
 	}
 }

