#include <stdio.h>
 #define MAX 1600
 int main() {
     int i, j, N, NA, NB, T, sH, sM, tH, tM, M;
     int A, B;
     int Aneed[MAX], Ahave[MAX], Bneed[MAX], Bhave[MAX];
     int AhaveNow, BhaveNow;
     scanf("%d", &N);
     for(i = 1; i <= N; i++) {
 	A = 0, B = 0;
 	AhaveNow = 0, BhaveNow = 0;
 	for(j = 0; j < MAX; j++) {
 	    Aneed[j] = 0;
 	    Ahave[j] = 0;
 	    Bneed[j] = 0;
 	    Bhave[j] = 0;
 	}
 	scanf("%d", &T);
 	scanf("%d %d", &NA, &NB);
 	for(j = 0; j < NA; j++) {
 	    scanf("%d:%d %d:%d", &sH, &sM, &tH, &tM);
 	    M = sH * 60 + sM;
 	    Aneed[M]++;
 	    M = tH * 60 + tM + T;
 	    Bhave[M]++;
 	}
 	for(j = 0; j < NB; j++) {
 	    scanf("%d:%d %d:%d", &sH, &sM, &tH, &tM);
 	    M = sH * 60 + sM;
 	    Bneed[M]++;
 	    M = tH * 60 + tM + T;
 	    Ahave[M]++;
 	}
 	for(j = 0; j < 1440; j++) {
 	    AhaveNow += Ahave[j];
 	    if (Aneed[j] > AhaveNow) {
 		A += (Aneed[j] - AhaveNow);
 		AhaveNow = 0;
 	    } else {
 		AhaveNow -= Aneed[j];
 	    }
 	    BhaveNow += Bhave[j];
 	    if (Bneed[j] > BhaveNow) {
 		B += (Bneed[j] - BhaveNow);
 		BhaveNow = 0;
 	    } else {
 		BhaveNow -= Bneed[j];
 	    }
 	}
 	printf("Case #%d: %d %d\n", i, A, B);
     }
     return 0;
 }

