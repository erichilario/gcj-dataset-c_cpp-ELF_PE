#include <stdio.h>
 #include <string.h>
 
 int main() {
     char s[200];
     
     char e_names[101][200];
     char e_ques[1001][200];
     
     int cases;
     int S;
     int Q;
     int i;
     int x;
     
     int tmp[101];
     
     int count = 0;
     int crossed = 0;
     int y = 0;
     int j,k;
     
     
     gets(s);
     sscanf(s,"%d",&cases);
     for(i=1;i<=cases;i++) {
      y=0;
      crossed = 0;
      count = 0;
      gets(s);
      sscanf(s,"%d",&S);
      for(x=0;x<S;x++) {
         gets(e_names[x]);
         //printf("is : %s",&e_names[x]);
      }
      gets(s);
      sscanf(s,"%d",&Q);
      for(x=0;x<Q;x++) {
         gets(e_ques[x]);
      }
      
      for(x=0;x<101;x++) tmp[x] = 2;
      for(x=0;x<S;x++) tmp[x] = 1;
      //printf("Q: %d\n",Q);
      
      for(x=0;x<Q;x++) {//current query
         //printf("current x:%d Q: %s\n",x,e_ques[x]);
         for(y=0;y<S;y++) {//current eng
         //printf("current y: %d S: %s\n",y,e_names[y]);
           if(strcmp(e_ques[x],e_names[y]) == 0) { //match
           //printf("match\n");
              if(tmp[y] == 1) {
                 tmp[y] = 0;
                 crossed++;
                 
                 if(crossed == S) {
                    count++;
                    for(j=0;j<S;j++) tmp[j] = 1;
                    tmp[y] = 0;
                    crossed = 1;
                 }
            
              }
              break;
           }
          // else  printf("no match\n");
         }
      }
      printf("Case #%d: %d\n",i,count);
      //getch();
     }
     
 return 0;
 }

