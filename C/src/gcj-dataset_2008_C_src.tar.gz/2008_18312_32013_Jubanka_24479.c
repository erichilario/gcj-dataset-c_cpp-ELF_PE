#include <stdio.h>
 #include <math.h>
 
 #define NUMS 10000000.0
 #define PI 3.141592653589793
 
 int incirc(double x, double y, double r) {
 	return sqrt(x*x + y*y) < r ? 1 : 0;
 }
 
 double isectv(double x, double y, double h, double r) {
 	double cy = sqrt(r*r - x*x);
 	if (cy > y+h)
 		return h;
 	return cy-y;
 }
 
 double dorect(double x, double y, double g, double r) {
 	double xp = x, E=0, xl, xs;
 	int smp = 0;
 
 	if (!incirc(x, y, r))
 		return 0;
 	if (incirc(x, y+g, r) && incirc(x+g, y+g, r) && incirc(x+g, y, r))
 		return g*g;
 
 	xl = sqrt(r*r - y*y);
 	if (xl > x+g)
 		xl = x+g;
 	xs = (xl-x)/NUMS;
 	while (xp < xl){
 		E += isectv(xp, y, g, r);
 		xp += xs;
 		smp++;
 	}
 
 	return ((xp-xs)-x)/(double)smp*E;
 }
 
 double racquet(double f, double R, double t, double r, double g) {
 	double x, y, ER=0, EI, EO, EF, EFI, EOFL, E, EIFR, EIFL;
 
 	if (g <= 2.0*f)
 		return 1.0;
 
 	x=r+f;
 	while (x < R - t - f) {
 		y = r+f;
 		while (y < R - t -f) {
 			E = dorect(x, y, g-2.0*f, R-t-f);
 			ER += E;
 
 			y += g + 2.0*r;
 		}
 		x += g + 2.0 *r;
 	}
 
 	EF = ((double) PI )*R*R;
 	EOFL = ((double) PI )*R*R - ((double) PI )*(R-t-f)*(R-t-f);
 	EIFR = ((double) PI )*(R-t-f)*(R-t-f) - ER*4.0;
 
 	return (EOFL + EIFR)/EF;
 }
 
 int main(void) {
 	FILE *fin;
 	int N, i;
 	double f, R, t, r, g;
 
 	fin = fopen("in.dat","r");
 	fscanf(fin, "%d", &N);
 
 	for (i=0; i<N; i++) {
 		fscanf(fin, "%lf %lf %lf %lf %lf", &f, &R, &t, &r, &g);
 		printf("Case #%d: %lf\n", i+1, racquet(f, R, t, r, g));
 	}
 	
 	fclose(fin);
 }

