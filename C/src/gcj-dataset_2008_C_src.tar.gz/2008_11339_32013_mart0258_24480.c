#include <stdio.h>
 
 char buf[512];
 
 char names[200][200];
 int query[2000];
 
 int N;
 int S;
 int Q; 
 
 /* pos = first entry that needs to be checked by a new engine. */
 int solve(int pos)
 {
 	int ret=0;
 	int i;
 	int j;
 	int best=pos; 
 	int bi;
 
 	for (i=0; i<S; i++)
 	{
 		for (j=pos; j<Q; j++)
 		{
 			if (query[j]==i)
 				break;
 		}
 		if (j==Q) 
 			return 0;
 
 		if (j>best)
 		{
 			best=j;
 			bi=i;
 		}
 	}
 
 	ret = solve(best)+1;
 
 	return ret;
 }
 
 int main (void)
 {
 	int i,j,k;
 	fgets(buf, 512, stdin);
 	sscanf(buf, "%d", &N);
 
 	for (i=1; i<=N; i++)
 	{
 		fgets(buf, 512, stdin);
 		sscanf(buf, "%d", &S);
 
 		for (j=0; j<S; j++)
 		{
 			fgets(names[j], 512, stdin);
 		}
 
 		fgets(buf, 512, stdin);
 		sscanf(buf, "%d", &Q);
 
 		for (j=0; j<Q; j++)
 		{
 			fgets(buf, 512, stdin);
 			for (k=0; k<S; k++)
 			{
 				if (strcmp(buf, names[k])==0)
 				{
 					query[j]=k;
 					break;
 				}
 			}
 		}
 
 		/* Solve. */
 		j = solve(0);
 
 		printf ("Case #%d: %d\n", i, j);
 
 	}
 }
