#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 enum {TRUE, FALSE};
 
 typedef struct engine{
    char name[101];
    int counted;
 
 } ENGINE;
 
 int main(void)
 {
    char *inputFile = "A-large.in";
    char *outputFile = "A-large.out";
    FILE *fpIn;
    FILE *fpOut;
 
    int i, j, k, n;
    char c;
 
    char nCases[4];
    int numCases;
 
    char queries[1000][101];
    ENGINE searchEngine[100];
    char nEngines[4];
    int numEngines;
    char nQueries[5];
    int numQueries;
 
    int enginesCounted = 0;
    int numSwitches = 0;
 
    /* open input and output files */
    if((fpIn = fopen(inputFile, "r")) == NULL)
    {
       fprintf(stderr, "Could not open file \"%s\"!\n", inputFile);
       exit(1);
    }
 
    if((fpOut = fopen(outputFile, "w")) == NULL)
    {
       fprintf(stderr, "Could not open file \"%s\"!\n", outputFile);
       exit(1);
    }
 
   /* get number of cases */
    for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
    {
       nCases[i] = c;
    }
    nCases[i] = '\0';
    numCases = atoi(nCases);
 
    for(n = 0; n < numCases; n++)
    {
       /* get number of engines */
       for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
       {
          nEngines[i] = c;
       }
       nEngines[i] = '\0';
       numEngines = atoi(nEngines);
 
       /* get search engines */
       for(j = 0; j < numEngines; j++)
       {
          for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
          {
             searchEngine[j].name[i] = c;
          }
          searchEngine[j].name[i] = '\0';
          searchEngine[j].counted = FALSE;
       }
 
       /* get number of queries */
       for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
       {
          nQueries[i] = c;
       }
       nQueries[i] = '\0';
       numQueries = atoi(nQueries);
 
       /* get queries */
       for(j = 0; j < numQueries; j++)
       {
          for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
          {
             queries[j][i] = c;
          }
          queries[j][i] = '\0';
       }
 
       for(i = 0; i < numQueries; i++)
       {
          for(j = 0; j < numEngines; j++)
          {
             if(strcmp(queries[i], searchEngine[j].name) == 0)
                break;
          }
          if(searchEngine[j].counted == FALSE)
          {
             searchEngine[j].counted = TRUE;
             enginesCounted++;
             if(enginesCounted == numEngines)
             {
                numSwitches++;
                enginesCounted = 1;
                for(k = 0; k < numEngines; k++)
                {
                   searchEngine[k].counted = FALSE;
                }
                searchEngine[j].counted = TRUE;
             }
          }
       }
 
       fprintf(fpOut, "Case #%d: %d\n", n + 1, numSwitches);
 
       numSwitches = 0;
       enginesCounted = 0;
 
    }
 
    fclose(fpIn);
    fclose(fpOut);
 
    return 0;
 }
 

