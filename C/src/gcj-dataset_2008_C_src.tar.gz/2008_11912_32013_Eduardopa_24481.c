#include <stdio.h>
 #include <math.h>
 #include <string.h>
 
 #define BUFF_SIZE 200
 
 typedef struct TRAIN_TT
 {
 	int departure;
 	int freeTime;
 	unsigned char newTrain;
 }TRAIN_TT;
 
 void initTrains (TRAIN_TT * trains, int qtdTrains)
 {
 	int i;
 
 	for (i=0;i<qtdTrains;i++)
 		trains[i].newTrain = 1;
 }
 
 int compDepart (TRAIN_TT * first, TRAIN_TT * second)
 {
 	if (first->departure < second->departure)
 		return -1;
 	if (first->departure > second->departure)
 		return 1;
 	return 0;
 
 }
 
 int compFreeTime (TRAIN_TT * first, TRAIN_TT * second)
 {
 	if (first->freeTime < second->freeTime)
 		return -1;
 	if (first->freeTime > second->freeTime)
 		return 1;
 	return 0;
 
 }
 
 void bSort (TRAIN_TT * vet, int tamVet, int (*comp)(void *, void *))
 {
 	int i;
 	int j;
 	TRAIN_TT aux;
 
 	for (i=0;i<tamVet;i++)
 	{
 		for (j=i+1;j<tamVet;j++)
 		{
 			if (comp(&vet[i],&vet[j]) == 1) // j  maior
 			{
 				aux = vet[i];
 				vet[i] = vet[j];
 				vet[j] = aux;
 			}
 		}
 	}
 }
 
 void Trains(TRAIN_TT * trainsA, int qtdTrainsA, TRAIN_TT * trainsB, int qtdTrainsB, int * iniTrainsA, int * iniTrainsB)
 {
 	int i;
 	int j;
 
 	initTrains (trainsA,qtdTrainsA);
 	initTrains (trainsB,qtdTrainsB);
 	*iniTrainsA = 0;
 	*iniTrainsB = 0;
 
 	bSort (trainsA,qtdTrainsA,compDepart);
 	bSort (trainsB,qtdTrainsB,compFreeTime);
 
 	j=0;
 	for (i=0;i<qtdTrainsB;i++)
 	{
 		for (;j<qtdTrainsA;j++)
 		{
 			if (trainsB[i].freeTime <= trainsA[j].departure)
 			{
 				trainsA[j].newTrain = 0;
 				j++;
 				break;
 			}
 		}
 	}
 
 	bSort (trainsA,qtdTrainsA,compFreeTime);
 	bSort (trainsB,qtdTrainsB,compDepart);
 
 	j=0;
 	for (i=0;i<qtdTrainsA;i++)
 	{
 		for (;j<qtdTrainsB;j++)
 		{
 			if (trainsA[i].freeTime <= trainsB[j].departure)
 			{
 				trainsB[j].newTrain = 0;
 				j++;
 				break;
 			}
 		}
 	}
 
 	for (i=0;i<qtdTrainsA;i++)
 		*iniTrainsA += trainsA[i].newTrain;
 
 	for (i=0;i<qtdTrainsB;i++)
 		*iniTrainsB += trainsB[i].newTrain;
 
 }
 
 void main (void)
 {
 	FILE * inputFile;
 	FILE * outputFile;
 	int paramCount;
 	int i;
 	int j;
 	TRAIN_TT trainsA[BUFF_SIZE];
 	int qtdTrainsA;
 	int qtdTrainsB;
 	int auxHour;
 	int auxMin;
 	TRAIN_TT trainsB[BUFF_SIZE];
 	int turnTime;
 	int iniTrainsA;
 	int iniTrainsB;
 
 	inputFile = fopen ("input.txt", "rt");
 	if (inputFile == NULL)
 	{
 		puts ("File not found");
 		return;
 	}
 	outputFile = fopen ("output.txt", "wt");
 	if (outputFile == NULL)
 	{
 		puts ("Error creating file");
 		return;
 	}
 	fscanf (inputFile,"%d",&paramCount);
 
 	for (i=0;i<paramCount;i++)
 	{
 		fscanf (inputFile, "%d", &turnTime);
 		fscanf (inputFile, "%d %d",&qtdTrainsA, &qtdTrainsB);
 		for (j=0;j<qtdTrainsA;j++)
 		{
 			fscanf (inputFile, "%d:%d", &auxHour, &auxMin);
 			trainsA[j].departure = auxHour * 60 + auxMin;
 			fscanf (inputFile, "%d:%d", &auxHour, &auxMin);
 			trainsA[j].freeTime = auxHour * 60 + auxMin + turnTime;
 		}
 		for (j=0;j<qtdTrainsB;j++)
 		{
 			fscanf (inputFile, "%d:%d", &auxHour, &auxMin);
 			trainsB[j].departure = auxHour * 60 + auxMin;
 			fscanf (inputFile, "%d:%d", &auxHour, &auxMin);
 			trainsB[j].freeTime = auxHour * 60 + auxMin + turnTime;
 		}
 		Trains(trainsA, qtdTrainsA, trainsB, qtdTrainsB, &iniTrainsA, &iniTrainsB);
 		fprintf (outputFile, "Case #%d: %d %d\n",i+1, iniTrainsA, iniTrainsB);
 	}
 
 	fclose (inputFile);
 	fclose (outputFile);
 }
