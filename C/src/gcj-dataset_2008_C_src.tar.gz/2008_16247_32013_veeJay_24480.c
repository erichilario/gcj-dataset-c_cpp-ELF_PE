#include<stdio.h>
 #include<string.h>
 main()
 {
     char srch[100][1000],qry[1000][1000];
 	int sr[100];
     int n,s,q,l;
 	int max;
 	int count;
     int i,j,k;
     scanf("%d",&n);
 	for(i=1;i<=n;i++)
 	{
 		scanf("%d",&s);
 		for(j=0;j<=s;j++)
 		{
 			gets(srch[j]);
 			sr[j]=0;
 		}
 		scanf("%d",&q);
 		for(j=0;j<=q;j++)
 		    gets(qry[j]);
 		count=0;
 		max=0;
 		l=1;
 		if(q==0)
 			count=1;
 		//Now we will check for minimum switching
 		while(l<=q)
 		{
 			for(k=1;k<=s;k++)
 			{
 				j=l;
 				while(strcmp(srch[k],qry[j]) && j<=q)
 					j++;
 				sr[k]=j;
 //				printf("sr[%d]=%d\n",k,sr[k]);
 			}
 			for(k=1;k<=s;k++)
 				max=(sr[k]>max)?sr[k]:max;
 			l=max;
 //			printf("max=%d\n",max);
 			count++;
 		}
 		printf("Case #%d: %d\n",i,count-1);
 	}
 	getch();
 }
 			
 		
     

