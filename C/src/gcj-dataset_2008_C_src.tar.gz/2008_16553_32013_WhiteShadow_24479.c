#include <stdio.h>
 #include <stdlib.h>
 #include <time.h>
 #include <math.h>
 #include <limits.h>
 
 #define SAMPLES 10000000
 
 // pi * r^2
 
 typedef struct {
   int x, y;
 } IntCoord;
 
 double f, R, t, r, g, p, aux_r, aux_g;
 
 void hole(double x, double y, IntCoord *c) {
   double auxx, auxy;
   if (x*x+y*y>=aux_r) {
     c->x = INT_MAX;
     c->y = INT_MAX;
     return;
   };
   auxx = fmod(fabs(x),aux_g);
   auxy = fmod(fabs(y),aux_g);
   //printf("%.4lf %.4lf\n",auxx,auxy);
   if (auxx<=r || auxx>=r+g ||
       auxy<=r || auxy>=r+g) {
     c->x = INT_MAX;
     c->y = INT_MAX;
   } else {
     //printf("$ %.4f %.4f\n",x,y);
     if (x<0) x = x-aux_g;
     if (y<0) y = y-aux_g;
     c->x = x / aux_g;
     c->y = y / aux_g;
   }
 }
 
 char hit(double x, double y) {
   IntCoord org, c;
 
   hole(x,y,&org);
   if (org.x == INT_MAX) return 1;
   //printf("org: %d %d -------------\n",org.x,org.y);
 
   hole(x+f,y,&c);
   //printf("c: %d %d\n",c.x,c.y);
   if (c.x!=org.x || c.y!=org.y) return 1;
   hole(x-f,y,&c);
   //printf("c: %d %d\n",c.x,c.y);
   if (c.x!=org.x || c.y!=org.y) return 1;
   hole(x,y+f,&c);
   //printf("c: %d %d\n",c.x,c.y);
   if (c.x!=org.x || c.y!=org.y) return 1;
   hole(x,y-f,&c);
   //printf("c: %d %d\n",c.x,c.y);
   if (c.x!=org.x || c.y!=org.y) return 1;
 
   //printf("!%.4f %.4f\n",x,y);
   
   return 0;
 }
 
 int main() {
   int i, n, j, hits;
   double myr, myangle, myx, myy;
 
   srand(time(NULL));
 
   scanf("%d",&n);
   for (i=1; i<=n; i++) {
     scanf("%lf %lf %lf %lf %lf",&f, &R, &t, &r, &g);
     aux_r = (R-t) * (R-t);
     aux_g = g+2*r;
 
     hits = SAMPLES;
     for (j=0; j<SAMPLES; j++) {
       myr = R * (double)rand() / (double)RAND_MAX;
       myangle = (M_PI / 2)  * (double)rand() / (double)RAND_MAX;
       myx = myr * cos(myangle);
       myy = myr * sin(myangle);
       //printf("Point %.6lf %.6lf\n",myx,myy);
       if (!hit(myx,myy)) hits--;     
     }
     p = (double)hits / (double)SAMPLES;
     printf("Case #%d: %.6lf\n", i, p);
   }
 
   return 0;
 }

