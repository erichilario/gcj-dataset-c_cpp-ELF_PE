#include <stdio.h>
 #include <string.h>
 
 #define MAXLEN 10
 
 int g[1024][1024];
 int map[MAXLEN];
 int row[2][10];
 int p[11] = {1, 2, 4, 8, 16, 32, 64, 128,
 	     256, 512, 1024};
 int num1 = 0, num2 = 0;
 int cnt[1024], count = 0;
 
 void build_graph(int r, int c)
 {
      if (c == 10)
 	  g[num1][num2] = 1;
      else {
 	  if (r == 0) {
 	       if (row[0][c-1] != 1) {
 		    row[0][c] = 1;
 		    num1 += p[c];
 		    count++;
 		    if (c < 9)
 			 build_graph(0, c+1);
 		    else
 			 build_graph(1, 1);
 		    num1 -= p[c];
 		    count--;
 	       }
 	       row[0][c] = 0;
 	       if (c < 9)
 		    build_graph(0, c+1);
 	       else {
 		    cnt[num1] = count;
 		    build_graph(1, 0);
 	       }
 	  } else {
 	       int sum;
 	       if (c == 0)
 		    sum = row[0][1];
 	       if (c == 9)
 		    sum = row[0][8]+row[1][8];
 	       else
 		    sum = row[0][c-1]+row[0][c+1]+row[1][c-1]+row[1][c+1];
 	       if (sum == 0) {
 		    row[1][c] = 1;
 		    num2 += p[c];
 		    build_graph(1, c+1);
 		    num2 -= p[c];
 	       }
 	       row[1][c] = 0;
 	       build_graph(1, c+1);
 	  }
      }
 }
 
 int main()
 {
      int c, i;
      scanf("%d", &c);
      memset(g, 0, sizeof(g));
      build_graph(0, 0);
      for (i = 1; i <= c; i++) {
 	  int m, n, j, k, l;
 	  scanf("%d %d\n", &m, &n);
 	  memset(map, 0, sizeof(map));
 	  for (j = 0; j < m; j++) {
 	       for (k = 0; k < n; k++)
 		    if (getchar() == 'x')
 			 map[j] += p[k];
 	       scanf("\n");
 	  }
 	  int f[MAXLEN][1024];
 	  memset(f, 0, sizeof(f));
 	  for (j = 0; j < p[n]; j++)
 	       if ((map[0] & j) == 0)
 		    f[0][j] = cnt[j];
 	  for (j = 1; j < m; j++)
 	       for (k = 0; k < p[n]; k++)
 		    if ((map[j] & k) == 0)
 			 for (l = 0; l < p[n]; l++)
 			      if (g[l][k] == 1 && f[j-1][l]+cnt[k] > f[j][k])
 				   f[j][k] = f[j-1][l]+cnt[k];
 	  int max = 0;
 	  for (j = 0; j < p[n]; j++)
 	       if (f[m-1][j] > max)
 		    max = f[m-1][j];
 	  printf("Case #%d: %d\n", i, max);
      }
      
      return 0;
 }

