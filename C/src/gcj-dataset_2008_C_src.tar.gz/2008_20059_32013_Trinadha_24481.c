#include<stdio.h>
 #include<conio.h>
 void mergesort(int*,int,int);
 void merge(int*,int,int,int);
 void main()
 {
  FILE *fp,*fp1;
  int aarr[100],adep[100],barr[100],bdep[100];
  int i,j,k,z;
  int not;
  int nota,notb,notra,notrb;
  int temp;
  int NA,NB;
  int tat;
  char q[102];
  clrscr();
  fp=fopen("input.txt","r");
  fp1=fopen("output.txt","w");
  fscanf(fp,"%d",&not);
  fgetc(fp);
  for(z=0;z<not;z++)
  {
   fscanf(fp,"%d",&tat);
   fgetc(fp);
   fscanf(fp,"%d",&NA);
   fgetc(fp);
   fscanf(fp,"%d",&NB);
   fgetc(fp);
   for(i=0;i<NA;i++)
   {
    fscanf(fp,"%d",&temp);
    fgetc(fp);
    adep[i]=temp*60;
    fscanf(fp,"%d",&temp);
    fgetc(fp);
    adep[i]+=temp;
 
    fscanf(fp,"%d",&temp);
    fgetc(fp);
    barr[i]=temp*60;
    fscanf(fp,"%d",&temp);
    fgetc(fp);
    barr[i]+=temp;
   }
   for(i=0;i<NB;i++)
   {
    fscanf(fp,"%d",&temp);
    fgetc(fp);
    bdep[i]=temp*60;
    fscanf(fp,"%d",&temp);
    fgetc(fp);
    bdep[i]+=temp;
 
    fscanf(fp,"%d",&temp);
    fgetc(fp);
    aarr[i]=temp*60;
    fscanf(fp,"%d",&temp);
    fgetc(fp);
    aarr[i]+=temp;
   }
   mergesort(adep,0,NA-1);
   mergesort(aarr,0,NB-1);
   mergesort(bdep,0,NB-1);
   mergesort(barr,0,NA-1);
   nota=0;
   notra=0;
   i=j=0;
   while(1)
   {
    if(i==NB || j==NA)
     break;
    if((aarr[i]+tat)<adep[j])
    { nota++;i++;}
    else
     if((aarr[i]+tat)==adep[j])
     {i++;j++;}
     else
      {if(nota==0)notra++;else nota--;j++;}
   }
   if(i==NB)
   notra+=(nota>(NA-j)?0:(NA-j-nota));
 
   notb=0;
   notrb=0;
   i=j=0;
 
   while(1)
   {
    if(i==NA || j==NB)
     break;
    if((barr[i]+tat)<bdep[j])
    { notb++;i++;}
    else
     if((barr[i]+tat)==bdep[j])
     {i++;j++;}
     else
      {if(notb==0)notrb++;else notb--;j++;}
   }
   if(i==NA)
   notrb+=(notb>(NB-j)?0:(NB-j-notb));
   fprintf(fp1,"Case #%d: %d %d\n",z+1,notra,notrb);
 
  }
  getch();
  fclose(fp);
  fclose(fp1);
 }
 void mergesort(int a[],int start,int end)
 {
  int mid;
  if(start>=end)
   return;
  mid=(start+end)/2;
  mergesort(a,start,mid);
  mergesort(a,mid+1,end);
  merge(a,start,mid,end);
 }
 void merge(int a[],int start,int mid,int end)
 {
  int b[100],k,i,j;
  for(i=start,j=mid+1,k=0;i<=mid && j<=end;k++)
  {
   if(a[i]<a[j])
    b[k]=a[i++];
   else
    b[k]=a[j++];
  }
  if(i==(mid+1))
   for(;j<=end;j++,k++)
    b[k]=a[j];
  else
   for(;i<=mid;i++,k++)
    b[k]=a[i];
  for(k=start;k<=end;k++)
   a[k]=b[k-start];
 }
