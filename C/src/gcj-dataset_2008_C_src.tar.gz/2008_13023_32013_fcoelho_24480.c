#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 struct avanco{
 	int avanco;
 	int buscador;
 };
 
 int comp(const void *p1, const void *p2)
 {
 	struct avanco *a = (struct avanco*)p1;
 	struct avanco *b = (struct avanco*)p2;
 	
 	return b->avanco - a->avanco;	
 }
 
 int main(int argc, char *argv[])
 {
 	int N, S, Q;
 	int caso, i, j;
 	int trocas;
 	int max=0, total = 0;
 	struct avanco avanco[100];
 	char buscador[100][101];
 	char busca[1000][101];
 	char linha[256];
 	FILE *arq;
 	
 	arq = fopen("A-small.in","r");
 	if (!arq)
 	{
 		perror("DEU ERRO!!");
 		exit(1);
 	}
 
 	/*quantidade de casos de teste*/
 	fgets(linha, 255, arq);
 	sscanf(linha, "%i", &N);
 	
 	for (caso=1 ; caso<=N ; caso++)
 	{
 		/*número de buscadores*/
 		fgets(linha, 255, arq);
 		sscanf(linha, "%i", &S);
 		for (i=0 ; i<S ; i++)
 		{
 			/*pega o nome do buscador*/
 			fgets(buscador[i], 101, arq);
 			/*zera os avanços*/
 			avanco[i].avanco = 0;
 			avanco[i].buscador = i;
 		}
 		/*número de buscas*/
 		fgets(linha, 255, arq);
 		sscanf(linha, "%i", &Q);
 		for (i=0 ; i<Q ; i++)
 		{
 			/*pega a busca*/
 			fgets(busca[i], 101, arq);
 		}
 		/*parte hardcore da coisa*/
 		trocas = total = max = 0;
 		while (total < Q)
 		{
 			/*testa cada buscador pra saber o quanto ele "vai pra frente"*/
 			/*parte do último ponto em que chegou*/
 			for (i=0 ; i<S ; i++)
 			{
 				j = max;			
 				while ( j<Q && (strcmp(buscador[i], busca[j]) != 0))
 					j++;
 				avanco[i].avanco = j;
 			}
 			
 			/*ordena decrescente -> primeiro é o que andou mais*/
 			qsort(avanco, S, sizeof(struct avanco), comp);
 			/*se ainda não chegou no final, tá na hora de fazer uma troca..*/
 			max = avanco[0].avanco;
 			if (max != Q)
 				trocas++;
 			total = max;
 		}
 		printf("Case #%i: %i\n", caso, trocas);
 	}
 	return 0;
 }

