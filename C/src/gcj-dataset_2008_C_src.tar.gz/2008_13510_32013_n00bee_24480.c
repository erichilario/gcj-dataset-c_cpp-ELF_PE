#include <stdio.h>
 #include <stdlib.h>
 
 #define MAX_NAME_SIZE		100
 
 #define MAX_SEARCH_ENGINES	100
 
 typedef struct
 {
 	char name[MAX_NAME_SIZE + 1];
 	int occurrence_count;
 } search_engine_statistics;
 
 int qs_comp(const void *c1, const void *c2)
 {
 	return strcmp(((search_engine_statistics *)c1)->name, ((search_engine_statistics *)c2)->name);
 }
 
 int read_search_engine_names(FILE *fp, search_engine_statistics *ses)
 {
 	int i, count;
 
 	fscanf(fp, "%d\n", &count);
 
 	for( i = 0; i < count; i++ )
 	{
 		fgets(ses[i].name, MAX_NAME_SIZE, fp);
 		ses[i].occurrence_count = 0;
 	}
 
 	qsort(ses, count, sizeof(search_engine_statistics), qs_comp);
 
 	return count;
 }
 
 int bs_comp(const void *c1, const void *c2)
 {
 	return strcmp(c1, ((search_engine_statistics *)c2)->name);
 }
 
 int count_switches(FILE *fp, search_engine_statistics *ses, int count)
 {
 	int i, j, switches;
 	int queries, max_available_search_engines;
 	search_engine_statistics *sr;
 	char query_string[MAX_NAME_SIZE + 1];
 
 	switches = 0;
 	max_available_search_engines = count;
 
 	fscanf(fp, "%d\n", &queries);
 
 	for( i = 0; i < queries; i++ )
 	{
 		fgets(query_string, MAX_NAME_SIZE, fp);
 
 		sr = bsearch(query_string, ses, count, sizeof(search_engine_statistics), bs_comp);
 
 		if( sr == NULL )
 		{
 			printf("ERROR: NO MATCHING SEARCH ENGINE\n");
 
 			exit(-1);
 		}
 
 		if( sr->occurrence_count == 0 )
 		{
 			sr->occurrence_count++;
 			max_available_search_engines--;
 
 			if( max_available_search_engines == 0 )
 			{
 				switches++;
 
 				for( j = 0; j < count; j++ )
 					ses[j].occurrence_count = 0;
 
 				sr->occurrence_count++;
 				max_available_search_engines = count - 1;
 			}
 		}
 	}
 
 	return switches;
 }
 
 int main(int argc, char *argv[])
 {
 	FILE *fp;
 	int i, max_trial;
 	int count, switches;
 	search_engine_statistics ses[MAX_SEARCH_ENGINES];
 
 	if( argc < 2 )
 	{
 		printf("%s <filename>\n", argv[0]);
 
 		return -1;
 	}
 
 	fp = fopen(argv[1], "r");
 
 	if( fp == NULL )
 	{
 		printf("Unable to open file '%s'\n", argv[1]);
 
 		return -2;
 	}
 
 	fscanf(fp, "%d\n", &max_trial);
 
 	for( i = 0; i < max_trial; i++ )
 	{
 		count = read_search_engine_names(fp, ses);
 
 		switches = count_switches(fp, ses, count);
 
 		printf("Case #%d: %d\n", i + 1, switches);
 	}
 
 	fclose(fp);
 
 	return 0;
 }

