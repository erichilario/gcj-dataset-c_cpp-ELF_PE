#include<stdio.h>
 #include<string.h>
 main()
 {
 	FILE *fp,*ft;
 	char ch;
 	fp=fopen("A-small-attempt1.in","r");
 	ft=fopen("save.in","w+");
 	int test;
 	int t;
 	fscanf(fp,"%d",&t);
 	for(test=0;test<t;test++)
 	{
 		int number,query,i,j=0,k,flag[10],m=1,set,count=0;
 		char search[10][101],store[100][100];
 		fscanf(fp,"%d",&number);
 		fgetc(fp);
 		for(i=0;i<number;i++)
 		{
 			
 			fgets(search[i],100,fp);
 			
 			
 		}
 		fscanf(fp,"%d",&query);
 		fgetc(fp);
 		
 			for(i=0;i<query;i++)
 			{
 				fgets(store[i],100,fp);
 				
 			}
 		while(j!=query)
 		{
 			for(i=0;i<number;i++)
 			{
 				flag[i]=0;
 			}
 			k=0,m=1;
 			while(1)
 			{
 				set=1;
 	
 				for(k=0;k<number;k++)
 				{
 					if((strcmp(search[k],store[j])==0)&&flag[k]==0)
 					{
 						flag[k]=m;
 						break;
 					}
 				}
 				m++;
 				j++;
 				for(i=0;i<number;i++)
 				{
 					if(flag[i]==0)
 					{
 						set=0;
 						break;
 					}
 				}
 				if(set==1)
 				{
 					count++;
 					j--;
 					break;
 				}
 				if(j==query)
 					break;
 			}
 		}
 		fputs("Case #",ft);
 		fprintf(ft,"%d",test+1);
 		fputs(": ",ft);
 		fprintf(ft,"%d",count);
 		fputs("\n",ft);
 			
 	}	
 }
 	

