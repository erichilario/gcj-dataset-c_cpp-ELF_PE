#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 enum {TRUE, FALSE};
 
 typedef struct trainnode{
    int departure;
    int arrival;
    struct trainnode *next;
 } TRAINNODE;
 
 int main(void)
 {
    char *inputFile = "B-large.in";
    char *outputFile = "B-large.out";
    FILE *fpIn;
    FILE *fpOut;
 
    int i, j, n;
    char c;
 
    char nCases[4];
    int numCases;
    char nTurnaround[3];
    int turnaround;
    char nAdepart[4];
    int numAdepart;
    char nBdepart[4];
    int numBdepart;
 
    char tempHour[3];
    int hours;
    char tempMinutes[3];
    int minutes;
 
    TRAINNODE *NA = NULL;
    TRAINNODE *NB = NULL;
    TRAINNODE *tempNode;
    TRAINNODE *current, *currentA, *currentB;
    TRAINNODE *prev;
    TRAINNODE *arrivalB = NULL;
    TRAINNODE *arrivalA = NULL;
    
    int numTrainsA = 0;
    int numTrainsB = 0;
 
    /* open input and output files */
    if((fpIn = fopen(inputFile, "r")) == NULL)
    {
       fprintf(stderr, "Could not open file \"%s\"!\n", inputFile);
       exit(1);
    }
 
    if((fpOut = fopen(outputFile, "w")) == NULL)
    {
       fprintf(stderr, "Could not open file \"%s\"!\n", outputFile);
       exit(1);
    }
 
   /* get number of cases */
    for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
    {
       nCases[i] = c;
    }
    nCases[i] = '\0';
    numCases = atoi(nCases);
 
    for(n = 0; n < numCases; n++)
    {
       /* get turnaround time */
       for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
       {
          nTurnaround[i] = c;
       }
       nTurnaround[i] = '\0';
       turnaround = atoi(nTurnaround);
 
       /* get number of trains departing A */
       for(i = 0; (c = fgetc(fpIn)) != ' '; i++)
       {
          nAdepart[i] = c;
       }
       nAdepart[i] = '\0';
       numAdepart = atoi(nAdepart);
 
       /* get number of trains departing B */
       for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
       {
          nBdepart[i] = c;
       }
       nBdepart[i] = '\0';
       numBdepart = atoi(nBdepart);
 
       /* get departure and arrival times for station A */
       for(j = 0; j < numAdepart; j++)
       {
          for(i = 0; (c = fgetc(fpIn)) != ':'; i++)
          {
             tempHour[i] = c;
          }
          tempHour[i] = '\0';
          hours = atoi(tempHour);
 
          for(i = 0; (c = fgetc(fpIn)) != ' '; i++)
          {
             tempMinutes[i] = c;
          }
          tempMinutes[i] = '\0';
          minutes = atoi(tempMinutes);
 
          tempNode = (TRAINNODE *)malloc(sizeof(TRAINNODE));
          tempNode->next = NULL;
          tempNode->departure = 60 * hours + minutes;
 
          for(i = 0; (c = fgetc(fpIn)) != ':'; i++)
          {
             tempHour[i] = c;
          }
          tempHour[i] = '\0';
          hours = atoi(tempHour);
 
          for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
          {
             tempMinutes[i] = c;
          }
          tempMinutes[i] = '\0';
          minutes = atoi(tempMinutes);
 
          tempNode->arrival = 60 * hours + minutes;
 
          current = NA;
          prev = NULL;
 
          if(current == NULL)
             NA = tempNode;
          else
          {
             while(current != NULL)
             {
                if(tempNode->departure > current->departure)
                {
                   prev = current;
                   current = current->next;
                }
                else
                {
                   tempNode->next = current;
                   if(prev != NULL)
                      prev->next = tempNode;
                   else
                      NA = tempNode;
                   break;
                }
             }
             if(current == NULL)
                prev->next = tempNode;
          }
       }
 
       /* get departure and arrival times for station B */
       for(j = 0; j < numBdepart; j++)
       {
          for(i = 0; (c = fgetc(fpIn)) != ':'; i++)
          {
             tempHour[i] = c;
          }
          tempHour[i] = '\0';
          hours = atoi(tempHour);
 
          for(i = 0; (c = fgetc(fpIn)) != ' '; i++)
          {
             tempMinutes[i] = c;
          }
          tempMinutes[i] = '\0';
          minutes = atoi(tempMinutes);
 
          tempNode = (TRAINNODE *)malloc(sizeof(TRAINNODE));
          tempNode->next = NULL;
          tempNode->departure = 60 * hours + minutes;
 
          for(i = 0; (c = fgetc(fpIn)) != ':'; i++)
          {
             tempHour[i] = c;
          }
          tempHour[i] = '\0';
          hours = atoi(tempHour);
 
          for(i = 0; (c = fgetc(fpIn)) != '\n'; i++)
          {
             tempMinutes[i] = c;
          }
          tempMinutes[i] = '\0';
          minutes = atoi(tempMinutes);
 
          tempNode->arrival = 60 * hours + minutes;
 
          current = NB;
          prev = NULL;
 
          if(current == NULL)
             NB = tempNode;
          else
          {
             while(current != NULL)
             {
                if(tempNode->departure > current->departure)
                {
                   prev = current;
                   current = current->next;
                }
                else
                {
                   tempNode->next = current;
                   if(prev != NULL)
                      prev->next = tempNode;
                   else
                      NB = tempNode;
                   break;
                }
             }
             if(current == NULL)
                prev->next = tempNode;
          }
       }
       
       /* calculate number of trains at stations A and B */
       for(currentA = NA, currentB = NB; currentA != NULL || currentB != NULL; )
       {
          if(currentA == NULL || currentB == NULL)
          {
             if(currentB != NULL)
             {
                if(arrivalB != NULL)
                {
                   if(currentB->departure < arrivalB->departure)
                   {
                      numTrainsB++;
                   }
                   else
                   {
                      tempNode = arrivalB->next;
                      free(arrivalB);
                      arrivalB = tempNode;
                   }
                }
                else
                   numTrainsB++;
 
                tempNode = (TRAINNODE *)malloc(sizeof(TRAINNODE));
                tempNode->next = NULL;
                tempNode->departure = currentB->arrival + turnaround;
 
                current = arrivalA;
                prev = NULL;
                
                if(current == NULL)
                   arrivalA = tempNode;
                else
                {
                   while(current != NULL)
                   {
                      if(tempNode->departure > current->departure)
                      {
                         prev = current;
                         current = current->next;
                      }
                      else
                      {
                         tempNode->next = current;
                         if(prev != NULL)
                            prev->next = tempNode;
                         else
                            arrivalA = tempNode;
                         break;
                      }
                   }
                   if(current == NULL)
                      prev->next = tempNode;
                }
 
                currentB = currentB->next;
             }
             else if(currentA != NULL)
             {
                if(arrivalA != NULL)
                {
                   if(currentA->departure < arrivalA->departure)
                   {
                      numTrainsA++;
                   }
                   else
                   {
                      tempNode = arrivalA->next;
                      free(arrivalA);
                      arrivalA = tempNode;
                   }
                }
                else
                   numTrainsA++;
 
                tempNode = (TRAINNODE *)malloc(sizeof(TRAINNODE));
                tempNode->next = NULL;
                tempNode->departure = currentA->arrival + turnaround;
 
                current = arrivalB;
                prev = NULL;
                
                if(current == NULL)
                   arrivalB = tempNode;
                else
                {
                   while(current != NULL)
                   {
                      if(tempNode->departure > current->departure)
                      {
                         prev = current;
                         current = current->next;
                      }
                      else
                      {
                         tempNode->next = current;
                         if(prev != NULL)
                            prev->next = tempNode;
                         else
                            arrivalB = tempNode;
                         break;
                      }
                   }
                   if(current == NULL)
                      prev->next = tempNode;
                }
 
                currentA = currentA->next;
 
             }
          }
          else
          {
             if(currentA->departure <= currentB->departure)
             {
                if(arrivalA != NULL)
                {
                   if(currentA->departure < arrivalA->departure)
                   {
                      numTrainsA++;
                   }
                   else
                   {
                      tempNode = arrivalA->next;
                      free(arrivalA);
                      arrivalA = tempNode;
                   }
                }
                else
                   numTrainsA++;
 
                tempNode = (TRAINNODE *)malloc(sizeof(TRAINNODE));
                tempNode->next = NULL;
                tempNode->departure = currentA->arrival + turnaround;
 
                current = arrivalB;
                prev = NULL;
                
                if(current == NULL)
                   arrivalB = tempNode;
                else
                {
                   while(current != NULL)
                   {
                      if(tempNode->departure > current->departure)
                      {
                         prev = current;
                         current = current->next;
                      }
                      else
                      {
                         tempNode->next = current;
                         if(prev != NULL)
                            prev->next = tempNode;
                         else
                            arrivalB = tempNode;
                         break;
                      }
                   }
                   if(current == NULL)
                      prev->next = tempNode;
                }
 
                currentA = currentA->next;
             }
             else
             {
                if(arrivalB != NULL)
                {
                   if(currentB->departure < arrivalB->departure)
                   {
                      numTrainsB++;
                   }
                   else
                   {
                      tempNode = arrivalB->next;
                      free(arrivalB);
                      arrivalB = tempNode;
                   }
                }
                else
                   numTrainsB++;
 
                tempNode = (TRAINNODE *)malloc(sizeof(TRAINNODE));
                tempNode->next = NULL;
                tempNode->departure = currentB->arrival + turnaround;
 
                current = arrivalA;
                prev = NULL;
                
                if(current == NULL)
                   arrivalA = tempNode;
                else
                {
                   while(current != NULL)
                   {
                      if(tempNode->departure > current->departure)
                      {
                         prev = current;
                         current = current->next;
                      }
                      else
                      {
                         tempNode->next = current;
                         if(prev != NULL)
                            prev->next = tempNode;
                         else
                            arrivalA = tempNode;
                         break;
                      }
                   }
                   if(current == NULL)
                      prev->next = tempNode;
                }
 
                currentB = currentB->next;
             }
          }
       }
 
       fprintf(fpOut, "Case #%d: %d %d\n", n + 1, numTrainsA, numTrainsB);
       numTrainsA = 0;
       numTrainsB = 0;
 
       /* free all nodes */
       current = NA;
       prev = current;
       
       while(current != NULL)
       {
         current = current->next;
         free(prev);
         prev = current;
       }
       NA = NULL;
 
       current = NB;
       prev = current;
       
       while(current != NULL)
       {
         current = current->next;
         free(prev);
         prev = current;
       }
       NB = NULL;
 
       current = arrivalA;
       prev = current;
       
       while(current != NULL)
       {
         current = current->next;
         free(prev);
         prev = current;
       }
       arrivalA = NULL;
 
       current = arrivalB;
       prev = current;
       
       while(current != NULL)
       {
         current = current->next;
         free(prev);
         prev = current;
       }
       arrivalB = NULL;
 
    }
 
    fclose(fpIn);
    fclose(fpOut);
 
    return 0;
 }

