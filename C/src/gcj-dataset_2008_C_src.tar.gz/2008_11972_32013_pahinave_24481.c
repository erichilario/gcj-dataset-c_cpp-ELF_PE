#include <stdio.h>
 #include <stdlib.h>
 #include <malloc.h>
 
 typedef struct
 {
 	int hour;
 	int min;
 }TIME;
 
 typedef struct
 {
 	int dept;
 	int arrv;
 	int flag;
 	int fromStation;
 }TrainRoute;
 
 typedef struct trainStruct
 {
 	int nextStartTime;
 	int fromStation;
 	int startedFrom;
 	struct trainStruct *next;
 }Train;
 
 Train *train = NULL;
 
 FILE *fp = NULL;
 
 int getTime(TIME t)
 {
 	return t.hour * 100 + t.min;
 }
 
 TrainRoute TrainRoutes[200];
 
 void getTT(int n, int fromStation, int ttStartIndex)
 {
 	char buffer[15];
 	int i;
 	TIME tD, tA;
 
 	for(i=0; i<n; i++)
 		{
 			fgets(buffer, 15, fp);
 			sscanf(buffer, "%d:%d %d:%d", &tD.hour, &tD.min, &tA.hour, &tA.min);
 			
 			TrainRoutes[ttStartIndex].dept = getTime(tD);
 			TrainRoutes[ttStartIndex].arrv = getTime(tA);
 			TrainRoutes[ttStartIndex].flag = 0;
 			TrainRoutes[ttStartIndex].fromStation = fromStation;
 			ttStartIndex++;
 		}
 }
 
 
 void printTrainRoute(int routeIndex)
 {
 	printf("\n TrainRoute: From %d Dept %d Arrv %d", TrainRoutes[routeIndex].fromStation , TrainRoutes[routeIndex].dept, TrainRoutes[routeIndex].arrv);
 }
 void printTrain(Train *train)
 {
 	printf("\n From station %d nextStartTime %d", train->fromStation, train->nextStartTime);
 }
 void allocateTrain(int routeIndex, int tuTime)
 {
 	Train *prev = train, *head = train, *foundTrain = NULL;
 
 	while(head != NULL)
 	{
 		if(	head->fromStation == TrainRoutes[routeIndex].fromStation &&
 			head->nextStartTime <= TrainRoutes[routeIndex].dept)
 		{
 			if(foundTrain != NULL && foundTrain->nextStartTime > head->nextStartTime)
 			{
 				foundTrain = head;
 			}
 			else
 			{
 				foundTrain = head;
 			}
 		}
 		prev = head;
 		head = head->next;
 	}
 
 	if(foundTrain == NULL)
 	{
 		foundTrain = (Train*) calloc(1, sizeof(Train));		
 		foundTrain->startedFrom = TrainRoutes[routeIndex].fromStation;
 		foundTrain->next = NULL;	
 		
 		if(train == NULL)
 			train = foundTrain;
 		else
 		{
 			head = train;
 			while(head->next != NULL)
 			{
 				head = head->next;
 			}
 			head->next = foundTrain;
 		}
 	}
 	foundTrain->fromStation = !TrainRoutes[routeIndex].fromStation;
 	foundTrain->nextStartTime = TrainRoutes[routeIndex].arrv + tuTime;
 }
 void sortTT(int n)
 {
 	int i, j;
 	TrainRoute temp;
 	for(i=0; i<n-1;i++)
 	{
 		for(j=i+1; j<n; j++)
 		{
 			if(TrainRoutes[i].dept > TrainRoutes[j].dept)
 			{
 				temp = TrainRoutes[i];
 				TrainRoutes[i] = TrainRoutes[j];
 				TrainRoutes[j] = temp;
 			}
 		}
 	}
 }
 
 
 int main(int argc, char **argv)
 {
 	int n, t, na, nb, tCounter, i, j, nTrainRoutes, done, nTrainsFromA, nTrainsFromB;
 	TrainRoute curr;
 	Train *head;
 	
 	char buffer[15];
 	TIME tD, tA;
 
 	if(argc < 2)
 	{
 		printf("\nInput file missing.");
 		exit(0);
 	}
 	
 	fp = fopen(argv[1], "r");
 	if(fp == NULL)
 	{
 		printf("\nError opening input file.");
 		exit(0);
 	}
 
 	fgets(buffer, 15, fp);
 	sscanf(buffer, "%d",&n);
 
 	for(tCounter = 1; tCounter <= n; tCounter++)
 	{
 		printf("Case #%d: ", tCounter);
 		// Reset
 		nTrainRoutes = 0;
 		done = 0;
 		nTrainsFromA = nTrainsFromB = 0;
 		train = NULL;
 
 		fgets(buffer, 15, fp);
 		sscanf(buffer, "%d", &t);
 
 		fgets(buffer, 15, fp);
 		sscanf(buffer, "%d %d", &na, &nb);
 		getTT(na, 0, 0);
 		getTT(nb, 1, na);
 		sortTT(na+nb);
 		
 		for(i=0; i<na+nb; i++)
 		{
 			allocateTrain(i, t);
 		}
 	
 		head = train;
 		while(head != NULL)
 		{
 			if(head->startedFrom ==0)
 				nTrainsFromA++;
 			else
 				nTrainsFromB++;
 			head = head->next;
 		}	
 		printf("%d %d\n", nTrainsFromA, nTrainsFromB);
 	}
 
 }
