#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define MAX_STR       100
 #define MAX_ENGINES   100
 #define MAX_SEARCHES  1000
 
 typedef unsigned char bool;
 #define true  (bool)(3>2)
 #define false (bool)(3<2)
 
 #define DEBUG if(debug) printf
 bool debug = false;
 
 
 void swap( char s1[], char s2[] )
 {
   char temp[MAX_STR];
 
   strcpy( temp, s1 );
   strcpy( s1, s2 );
   strcpy( s2, temp );
 
   return;
 }
 
 void getstring( FILE *file, char str[] )
 {
   //fscanf( file, "%s\n", str );
   fgets( str, MAX_STR, file );
   str[strlen( str ) - 1] = '\0';
 }
 
 
 bool run_case( FILE *infile, int *result )
 {
   bool retval = false;
   int num_engines,
       num_searches;
   char *engines[MAX_ENGINES],
        *searches[MAX_SEARCHES],
        in[MAX_STR];
   int candidates;
   int switches = 0;
   bool found;
 
   int i;
   int j;
 
 
   *result = -1;
 
   getstring( infile, in );
   num_engines = atoi( in );
 
   DEBUG( "====================================\n" );
   DEBUG( "num_engines is %d\n", num_engines );
 
   engines[0] = (char *)calloc( (MAX_STR * MAX_ENGINES), sizeof( char ) );
   if( engines )
   {
     for( i = 1; i < MAX_ENGINES;  i++ )
     {
       engines[i] = engines[0] + (i * MAX_STR);
     }
     for( i = 0;  i < num_engines;  i++ )
     {
       getstring( infile, engines[i] );
       DEBUG( "engines[%d] is %s\n", i, engines[i] );
     }
 
 
     getstring( infile, in );
     num_searches = atoi( in );
 
     DEBUG( "num_searches is %d\n", num_searches );
     DEBUG( "---------------------------------\n" );
 
     /*
      * Now search
      */
     retval = true;
     candidates = num_engines;
     for( i = 0;  retval && (i < num_searches);  i++ )
     {
       found = false;
 
       getstring( infile, in );
 
       DEBUG( "search is %s\n", in );
       for( j = 0;  j < candidates;  j++ )
       {
         found = ( strcmp( in, engines[j] ) == 0 );
         if( found )
         {
           DEBUG( "Swapping %s and %s\n", engines[j], engines[candidates - 1]);
           swap( engines[j], engines[candidates - 1] );
           candidates--;
         }
       }
 
       if( candidates == 0 )
       {
         DEBUG( ">>>>>>>>> Switching\n" );
         switches++;
         swap( engines[0], engines[num_engines - 1] );
         candidates = num_engines - 1;
       }
     }
 
     *result = switches;
     DEBUG( "result is %d\n", *result );
   }
   else
   {
     perror( "Couldn't allocate engines" );
   }
 
   return retval;
 }
 
 
 
 int main( int argc, char *argv[] )
 {
   FILE *infile = NULL,
        *outfile = NULL;
   char in[MAX_STR];
   int runs;
   int i;
   int result;
 
   if( argc > 1 )
   {
     infile = fopen( argv[1], "r" );
     if( !infile )
     {
       perror( "Couldn't open infile" );
       exit( 1 );
     }
   }
 
   outfile = fopen( "output.txt", "w" );
   if( !outfile )
   {
     perror( "Couldn't open outfile" );
     exit( 5 );
   }
 
   if( argc > 2 )
   {
     if( atoi( argv[2] ) == 1 )
     {
       debug = true;
     }
   }
 
 
   fscanf( infile, "%s\n", in );
   runs = atoi( in );
   DEBUG( "Num cases is %d\n", runs );
 
   for( i = 1;  i <= runs;  i++ )
   {
     if( run_case( infile, &result ) )
     {
       fprintf( outfile, "Case #%d: %d\n", i, result );
     }
     else
     {
       perror( "Case failed" );
     }
   }
 
 
   if( infile ) fclose( infile );
   if( outfile ) fclose( outfile );
 }
 
 

