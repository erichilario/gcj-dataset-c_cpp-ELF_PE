#include<stdio.h>
 #include<string.h>
 
 #define MIN(x,y)(x)<(y)?(x):(y)
 #define finname "A-small.in"
 #define foutname "A-small.out"
 
 char q[1001][105],s[100][105];
 int f[1001],flag[100],N,l,S,Q,i,j; 
 int check(int j,int i)
 {
  int k,h,returnValue=0; 
  memset(flag,0,sizeof(flag));
  for(k=j;k<=i;k++)
   for(h=0;h<S;h++)
   if(strcmp(q[k],s[h])==0)
    flag[h]=1;
  for(h=0;h<S;h++)
   if(!flag[h])
   {
    returnValue=1;
    break;
   }   
  return returnValue;
 }
 void dp()
 {
  memset(f,Q,sizeof(f));
  f[0]=-1;
  for(i=1;i<=Q;i++)
   for(j=i;j>0;j--)
   {
    if(check(j,i))
      f[i]=MIN(f[i],f[j-1]+1); 
    else
     break;
   } 
 }
  main()
 {
  FILE *fin,*fout;
  char *t;
  fin=fopen(finname,"r");
  fout=fopen(foutname,"w");
  fscanf(fin,"%d\n",&N);
  for(l=0;l<N;l++)
  {
  fscanf(fin,"%d\n",&S);
  for(i=0;i<S;i++)
  {
   t=s[i];
   while(fscanf(fin,"%c",t),*t!='\n')
    t++;
   *t='\0';
  }
  fscanf(fin,"%d\n",&Q);
  for(i=1;i<=Q;i++)
  {
   t=q[i];
   while(fscanf(fin,"%c",t),*t!='\n')
    t++;
   *t='\0';
  }
  dp();
  if(f[Q]<0)
   f[Q]=0;
  fprintf(fout,"Case #%d: %d\n",l+1,f[Q]);
  }
  fclose(fin);
  fclose(fout);
 } 

