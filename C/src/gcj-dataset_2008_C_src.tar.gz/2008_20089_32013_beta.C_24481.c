#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 void main()
 {
 	FILE* fIn,*fOut;
 	int NA,NB,arrA[100],depA[100],arrB[100],depB[100];
 	char temp[5],tempa[3],tempb[3];
 	int hr,min,trainA,trainB,i,j,T,N,l,trainAno[100],trainBno[100],jstore,mingap,gap[100];
 
 	fIn = fopen("input.txt","rb");
 	fOut = fopen("output.txt","wb");
 	fscanf(fIn,"%d",&N);
 	for(l=1;l<=N;l++)
 	{
 		for(i=0;i<100;i++)
 		{ 
 			trainAno[i] = 0;
 			trainBno[i] = 0;
 		}
 		fscanf(fIn,"%d",&T);
 		fscanf(fIn,"%d",&NA);
 		fscanf(fIn,"%d",&NB);
 		trainA = NA;
 		trainB = NB;
 		for(i=0;i<NA;i++)
 		{
 			fscanf(fIn,"%s",temp);
 			tempa[0] = temp[0];
 			tempa[1] = temp[1];
 			tempa[2] = '\0';
 			tempb[0] = temp[3];
 			tempb[1] = temp[4];
 			tempb[2] = '\0';
 
 			hr = atoi(tempa);
 			min = atoi(tempb);
 
 			depA[i] = hr*60 + min;		
 			
 			fscanf(fIn,"%s",temp);
 
 			tempa[0] = temp[0];
 			tempa[1] = temp[1];
 			tempa[2] = '\0';
 			tempb[0] = temp[3];
 			tempb[1] = temp[4];
 			tempb[2] = '\0';
 
 			hr = atoi(tempa);
 			min = atoi(tempb);
 			arrA[i] = hr*60 + min;	
 		}
 
 		for(i=0;i<NB;i++)
 		{
 			fscanf(fIn,"%s",temp);
 			tempa[0] = temp[0];
 			tempa[1] = temp[1];
 			tempa[2] = '\0';
 			tempb[0] = temp[3];
 			tempb[1] = temp[4];
 			tempb[2] = '\0';
 
 			hr = atoi(tempa);
 			min = atoi(tempb);
 			depB[i] = hr*60 + min;		
 			
 			fscanf(fIn,"%s",temp);
 			tempa[0] = temp[0];
 			tempa[1] = temp[1];
 			tempa[2] = '\0';
 			tempb[0] = temp[3];
 			tempb[1] = temp[4];
 			tempb[2] = '\0';
 
 			hr = atoi(tempa);
 			min = atoi(tempb);
 			arrB[i] = hr*60 + min;	
 		}
 		
 		for(i=0;i<NA;i++)
 		{
 			mingap = 24*60;
 			jstore = -1;
 
 			for(j=0;j<NB;j++)
 			{
 				gap[j] = (depB[j]-arrA[i]);
 				if(gap[j]>=T)
 				{	
 					if(gap[j] < mingap && trainBno[j] != 1)
 					{
 						jstore = j;
 						mingap = gap[j];
 					}
 				}
 			}
 			if(jstore>-1)
 				trainBno[jstore] = 1;
 		}
 		for(j=0;j<NB;j++)
 		{
 			trainB -= trainBno[j];
 		}
 		for(i=0;i<NB;i++)
 		{
 			mingap = 24*60;
 			jstore = -1;
 
 			for(j=0;j<NA;j++)
 			{
 				gap[j] = (depA[j]-arrB[i]);
 				if(gap[j]>=T)
 				{	
 					if(gap[j] < mingap  && trainAno[j] != 1)
 					{
 						jstore = j;
 						mingap = gap[j];
 					}
 				}
 			}
 			if(jstore>-1)
 				trainAno[jstore] = 1;
 		}
 		for(j=0;j<NA;j++)
 		{
 			trainA -= trainAno[j];
 		}
 
 
 		fprintf(fOut,"Case #%d: %d %d\n",l,trainA,trainB);
 	}
 	fclose(fIn);
 	fclose(fOut);
 }
