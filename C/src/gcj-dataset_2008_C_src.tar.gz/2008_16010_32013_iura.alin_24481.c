/*
  *      TrainTable.c
  *      
  *      Copyright 2008 Iura <iura@iura-pc>
  *      
  *      This program is free software; you can redistribute it and/or modify
  *      it under the terms of the GNU General Public License as published by
  *      the Free Software Foundation; either version 2 of the License, or
  *      (at your option) any later version.
  *      
  *      This program is distributed in the hope that it will be useful,
  *      but WITHOUT ANY WARRANTY; without even the implied warranty of
  *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *      GNU General Public License for more details.
  *      
  *      You should have received a copy of the GNU General Public License
  *      along with this program; if not, write to the Free Software
  *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
  *      MA 02110-1301, USA.
  */
 
 
 #include <stdio.h>
 #include <math.h>
 
 void schedule (FILE *fin, FILE *fout, int casee)
 {
 	int tren_din_a[100][2],tren_din_b[100][2],n,m,turn,ocupat_a[100],ocupat_b[100];
 	int i,j,a,b,c,d,min,leg;
 	int nr_tren_a,nr_tren_b;
 	fscanf(fin,"%d",&turn);
 	fscanf(fin,"%d %d",&n,&m);
 	for (i=0; i<n; i++)
 	{
 		fscanf(fin,"%d:%d %d:%d",&a,&b,&c,&d);
 		tren_din_a[i][0]=a*60+b;
 		tren_din_a[i][1]=c*60+d;
 		ocupat_a[i]=0;
 	}	
 	for (j=0; j<m; j++)
 	{
 		fscanf(fin,"%d:%d %d:%d",&a,&b,&c,&d);
 		tren_din_b[j][0]=a*60+b;
 		tren_din_b[j][1]=c*60+d;
 		ocupat_b[j]=0;
 	}
 	nr_tren_a=0;
 	for (i=0; i<n; i++)
 	{
 		min=1000;
 		leg=-1;
 		for (j=0; j<m; j++)
 			if (tren_din_a[i][0]>=tren_din_b[j][1]+turn && tren_din_a[i][0]-tren_din_b[j][1]<min && ocupat_b[j]==0)
 			{
 				min=tren_din_a[i][0]-tren_din_b[j][1];
 				leg=j;
 			}
 		if (leg!=-1)
 			ocupat_b[leg]=1;
 		else
 			nr_tren_a++;
 	}
 	
 	nr_tren_b=0;
 	for (j=0; j<m; j++)
 	{
 		min=1000;
 		leg=-1;
 		for (i=0; i<n; i++)
 			if (tren_din_b[j][0]>=tren_din_a[i][1]+turn && tren_din_b[j][0]-tren_din_a[i][1]<min && ocupat_a[i]==0)
 			{
 				min=tren_din_b[j][0]-tren_din_a[i][1];
 				leg=i;
 			}
 		if (leg!=-1)
 			ocupat_a[leg]=1;
 		else
 			nr_tren_b++;
 	}				
 	fprintf(fout,"Case #%d: %d %d\n",casee,nr_tren_a,nr_tren_b);	
 }
 void citeste (void)
 {
 	int i,n;
 	FILE *fin,*fout;
 	fin=fopen("B-small-attempt1.in","rt");
 	fout=fopen("Output.out","wt");
 	fscanf(fin,"%d",&n);
 	for (i=1; i<=n; i++)
 		schedule(fin,fout,i);
 	fclose(fin);
 	fclose(fout);
 }
 
 int main(int argc, char** argv)
 {
 	citeste();
 	return 0;
 }

