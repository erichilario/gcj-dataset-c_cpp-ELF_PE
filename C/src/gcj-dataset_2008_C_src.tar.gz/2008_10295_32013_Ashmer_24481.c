#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define aDEBUG
 
 int Astart[100] , Aend[100];
 int Bstart[100] , Bend[100];
 int t;
 int na , nb;
 
 void _quicksort(int * data,int left,int right)
 {
     int i,j,temp;
     i=left;
     j=right;
     temp=data[left];
     if(left>right)
 	return;
     while(i!=j)
     {
 	while(data[j]>=temp && j>i)
 	    j--;
 	if(j>i)
 	    data[i++]=data[j];
 	while(data[i]<=temp && j>i)
 	    i++;
 	if(j>i)
 	    data[j--]=data[i];
     }
     data[i]=temp;
     _quicksort(data,left,i-1);
     _quicksort(data,i+1,right);
 }
 
 int QuickSort(int * data , int count)
 {
     _quicksort(data , 0 , -- count);
     return 0;
 
 }
 
 int a(void)
 {
     int i , j;
     int start =0;
     int re = na;
     for (i = 0 ; i< na ; i ++ )
 	for (j = start ; j< nb ; j ++ )
 	    if (Astart[i] >= Bend[j])
 	    {
 		start  = j + 1;
 		re -- ;
 		break;
 	    }
 	    return re;
 }
 
 int b(void)
 {
     int i , j;
     int start = 0;
     int re = nb;
     for (i = 0 ; i< nb ; i ++ )
 	for (j = start ; j< na ; j ++ )
 	    if (Bstart[i] >= Aend[j])
 	    {
 		start  = j + 1;
 		re -- ;
 		break;
 	    }
 	    return re;
 }
 
 int deal(int order)
 {
     int i ;
     int hh , mm;
     char str[128];
     scanf ("%d" , &t);
     scanf ("%d%d" , &na , &nb);
 
     for (i = 0 ; i < na ; i++)
     {
 	scanf ("%d:%d" , &hh , &mm);
 	Astart[i] = hh*60 + mm;
 	scanf ("%d:%d" , &hh , &mm);
 	Aend[i] = hh*60 + mm + t;
     }
     QuickSort(Astart , na);
     QuickSort(Aend , na);
     for (i = 0 ; i < nb ; i++)
     {
 	scanf ("%d:%d" , &hh , &mm);
 	Bstart[i] = hh*60 + mm;
 	scanf ("%d:%d" , &hh , &mm);
 	Bend[i] = hh*60 + mm + t;
     }
     QuickSort(Bstart , nb);
     QuickSort(Bend , nb);
     printf ("Case #%d: %d %d\n" , order , a() , b());
     return 0;
 }
 
 
 int main (int argc , char * argv[])
 {
     int n , c;
     FILE * fp;
     if (argc == 1)
 	fp = freopen ("./input.in","r" , stdin);
     else
 	fp = freopen (argv[1] , "r" , stdin);
     if (fp == NULL)
 	exit(1);
     scanf ("%d" , &n);
     for (c = 0 ; c < n ; c ++)
     {
 	#ifdef DEBUG
 	printf ("Check\n");
 	#endif
 	deal(c + 1);
     }
     return 0;
 }
 
 

