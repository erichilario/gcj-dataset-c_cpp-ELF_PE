#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 
 int main(void)
 {
 
         FILE *fp;
         int caseno, turnaround, AB, BA, ABans, BAans;
         int ABtime1[100], ABtime2[100], BAtime1[100], BAtime2[100];
         int temp1, temp2, temp3, temp4, temp5;
         int i, j, k, m;
 
 
         fp = fopen("/home/lyip/B-small.in", "r");
         fscanf(fp, "%d", &caseno);
 
         for (i = 1; i <=caseno; i++) {
 
                 fscanf(fp, "%d", &turnaround);
                 fscanf(fp, "%d %d", &AB, &BA);
                 ABans=AB;
                 BAans=BA;
 
 
                 for (j=0; j< AB; j++){
                         fscanf(fp, "%d:%d %d:%d", &temp1, &temp2, &temp3, &temp4);
 
                         ABtime1[j]=temp1*60+temp2;
                         for (m=j;m>0; m--){
                                 if (ABtime1[m]<ABtime1[m-1]){
                                         temp5 = ABtime1[m-1];
                                         ABtime1[m-1] = ABtime1[m];
                                         ABtime1[m] = temp5;
                                 }
                                 else    m=0;
                                 }
 
                         ABtime2[j]=temp3*60+temp4+turnaround;
                         for (m=j;m>0; m--){
                                 if (ABtime2[m]<ABtime2[m-1]){
                                         temp5 = ABtime2[m-1];
                                         ABtime2[m-1] = ABtime2[m];
                                         ABtime2[m] = temp5;
                                 }
                                 else    m=0;
                                 }
 
 
                         }
                 for (j=0; j< BA; j++){
                         fscanf(fp, "%d:%d %d:%d", &temp1, &temp2, &temp3, &temp4);
                         BAtime1[j]=temp1*60+temp2;
                         for (m=j;m>0; m--){
                                 if (BAtime1[m]<BAtime1[m-1]){
                                         temp5 = BAtime1[m-1];
                                         BAtime1[m-1] = BAtime1[m];
                                         BAtime1[m] = temp5;
                                 }
                                 else    m=0;
                                 }
 
 
 
                         BAtime2[j]=temp3*60+temp4+turnaround;
                         for (m=j;m>0; m--){
                                 if (BAtime2[m]<BAtime2[m-1]){
 
                                         temp5 = BAtime2[m-1];
                                         BAtime2[m-1] = BAtime2[m];
                                         BAtime2[m] = temp5;
                                 }
                                 else    m=0;
                                 }
 
 
 
                         }
 
                 for (j=0; j<AB; j++){
                         for(k=0; k<BA; k++){
                                 if (ABtime1[j]>=BAtime2[k]){
                                         BAtime2[k]=6000;
                                         ABans--;
                                         k=BA;
                                 }
                         }
                 }
 
 
                 for (j=0; j<BA; j++){
                         for(k=0; k<AB; k++){
                                 if (BAtime1[j]>=ABtime2[k]){
                                         ABtime2[k]=6000;
                                         BAans--;
                                         k=AB;
                                 }
                         }
                 }
 
                 printf("Case #%d: %d %d\n", i, ABans, BAans);
 
         }
         fclose(fp);
         return 0;
 }
 
          
