#include<stdio.h>
 #include<conio.h>
 #include<string.h>
 #include<stdlib.h>
 // Server Name max length
 #define serverNameLenghtMax 100
 #define numServerMax 100
 #define numServerMin 2
 #define numQueriesMax 1000
 
 // Errors
 typedef enum ERROR_e
 {
   NO_ERROR,
   ERROR_OPENING_FILE,
   ERROR_MORE_THAN_MAX_SERVER,
   ERROR_LESS_THAN_MIN_SERVER,
   ERROR_MORE_THAN_MAX_QUERIES
 }Error_t;
 
 #define INF 0xFFFFFFF
 
 /* Model problem as "most late used in future" */
 typedef struct querySet // This is one test case
 {
     int countQuery;
 	int countServer;
 	char ServerName[numServerMax][serverNameLenghtMax];
 	char QueryList[numQueriesMax][serverNameLenghtMax];
 }querySet_t;
 
 typedef enum status_e
 {
    DONE,
    NOT_DONE
 }status_t;
 
 querySet_t q;
 
 int getMaxIndex(int * array)
 {
     int max=array[0],index=0;
     int itr=0;
     for(itr=0;itr<q.countServer;itr++)
     {
        if(max<array[itr])
        {
           max=array[itr];
           index=itr;
        }
     }
     return max;
 }
 
 int updateTimeStamp(int * timeStamp,int startIndex,int countQuery,int countServer)
 {
      int itrCountQuery = countQuery,itrCountServer=countServer;
 
 	 // Make all time INF
 	 itrCountServer = q.countServer;
 	 while(itrCountServer--)
 	 {
 		 timeStamp[itrCountServer]=INF;
 	 }
      itrCountServer=countServer;
      if(startIndex>countQuery)
      {
        return DONE;
      }
      // traverse from end and go to index and update itr into timeStamp
      while(itrCountServer--!=0)
      {
        itrCountQuery=countQuery;
        while(itrCountQuery-->startIndex)
        {
          if(!strcmp(q.ServerName[itrCountServer],q.QueryList[itrCountQuery]))
 		 	timeStamp[itrCountServer]=itrCountQuery;
        }
 	 }
 
 }
 
 int main(void)
 {
 	int itrCountServer=0,itrCountQuery=0,index=0,maxValue=0;
 	int nextServiceIndex=0;
 	int leftOverReq,switchIndex,switchCount;
 	int numTests,numTestsItr;
 	int * timeStamp=NULL;
 	char ch;
 	FILE  * fp;
 	FILE  * fpOUT;
 
     fp=fopen("d://input.txt","r") ;
 	if(!fp)
 		exit(ERROR_OPENING_FILE);
 
     fpOUT=fopen("d://output.txt","w");
 	if(!fpOUT)
     	exit(ERROR_OPENING_FILE);
 
     // Read number of tests
 	fscanf(fp,"%d",&numTests);
 
     // For each test case do
     for(numTestsItr=1;numTestsItr<=numTests;numTestsItr++)
     {
         // Read server Count
         fscanf(fp,"%d",&(q.countServer));
 
 		if(q.countServer>numServerMax)
 			exit(ERROR_MORE_THAN_MAX_SERVER);
 
 		if(q.countServer<numServerMin)
 			exit(ERROR_LESS_THAN_MIN_SERVER);
 
 		// Skip \n
         fscanf(fp,"%c",&ch);
 
 		// allocating equal number of server timestamp record for most late used
         timeStamp= (int *)malloc(sizeof(int)*(q.countServer));
 
         // iterating through server to read its name
         for(itrCountServer=0;itrCountServer<q.countServer;itrCountServer++)
 	    {
              fgets(&(q.ServerName[itrCountServer][0]),serverNameLenghtMax,fp);
 	    }
 
         // Read Query numbers
         fscanf(fp,"%d",&(q.countQuery));
 		if(q.countQuery>numQueriesMax)
 			exit(ERROR_MORE_THAN_MAX_QUERIES);
 
 		// Skip \n
         fscanf(fp,"%c",&ch);
 
         // read queries into array of string
         for(itrCountQuery=0;itrCountQuery<q.countQuery;itrCountQuery++)
         {
             fgets(q.QueryList[itrCountQuery],serverNameLenghtMax,fp);
         }
 
         // Here starts algo
 
         itrCountServer = q.countServer;
         switchIndex=0; // initialize switch index to zero
         switchCount=0; // intialize switch count to zero
         nextServiceIndex=0;
         // Continue till this seq ends, all query string exhausted
         while(1)
         {
             // Update with most late used
             updateTimeStamp(timeStamp,nextServiceIndex,q.countQuery,q.countServer);
 
             // get Maximum Value
             maxValue=getMaxIndex(timeStamp);
 
             // Next Service Index
             nextServiceIndex=maxValue;
 
             // Done so go out ....
             if(nextServiceIndex>q.countQuery)
             {
                 break;
             }
 
             // Incr switch count
             switchCount++;
           }
 		
 		 // Free timestamp
          free(timeStamp);
 
 		 // One case over so print result
 		 fprintf(fpOUT,"Case #%d: %d\n",numTestsItr,switchCount);
 
     }
    fclose(fpOUT);
    fclose(fp);
 
     return 0;
 }
 

