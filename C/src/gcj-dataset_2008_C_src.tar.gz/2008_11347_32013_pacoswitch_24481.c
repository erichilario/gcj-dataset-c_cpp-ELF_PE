#include <stdio.h>
 #define MAX 102
 #define SALE 0
 #define LLEGA 1
 
 int empalma(int llega[], int sale[], int n, int m, int tiempo)
 {
     int i, j, cont = 0;
     for(i = j = 0; i < n && j < m; j++){
         if(sale[j] >= (llega[i]+tiempo))
             i++;
         else
             cont++;
     }
     if(j < m){
         cont += (m-j);
     }
     return cont;
 }
 
 void shellsort(int v[], int n)
 {
    int gap, i, j, temp;
    for (gap = n/2; gap > 0; gap /= 2)
       for (i = gap; i < n; i++)
          for (j=i-gap; j>=0 && v[j]>v[j+gap]; j-=gap) 
          {
             temp = v[j];
             v[j] = v[j+gap];
             v[j+gap] = temp;
          }
    return;
 }
 
 void imprime(int m[2][MAX], int n)
 {
     int i;
     printf("%d\n", n);
     for(i = 0; i < n; i++)
         printf("%d %d\n", m[SALE][i], m[LLEGA][i]);
     return;
 }
 
 int hmilitar(int horas, int minutos)
 {
     return (horas * 60) + minutos;
 }
 
 int main()
 {
     int a, b, c, d, i, k, salena, salenb, tiempo, casos, na, nb, ab[2][MAX], ba[2][MAX];
     scanf("%d", &casos);
     for(k = 1; k <= casos; k++){
         scanf("%d\n", &tiempo);
         scanf("%d%d\n", &na, &nb);
         for(i = 0; i < na; i++){
             scanf("%d:%d %d:%d\n", &a, &b, &c, &d);
             ab[SALE][i] = hmilitar(a, b);
             ab[LLEGA][i] = hmilitar(c, d);
 /*            printf("%02d:%02d %02d:%02d %d %d\n", a, b, c, d, ab[SALE][i], ab[LLEGA][i]);*/
         }
         for(i = 0; i < nb; i++){
             scanf("%d:%d %d:%d\n", &a, &b, &c, &d);
             ba[SALE][i] = hmilitar(a, b);
             ba[LLEGA][i] = hmilitar(c, d);
 /*            printf("%02d:%02d %02d:%02d %d %d\n", a, b, c, d, ba[SALE][i], ba[LLEGA][i]);*/
         }
         /*Primero ordeno en base a las salidas de A*/
         shellsort(ab[SALE], na);
         /*Por lo que ordeno en base a las llegadas de B*/
         shellsort(ba[LLEGA], nb);
 /*        imprime(ab, na);
         imprime(ba, nb);*/
         salena = empalma(ba[LLEGA], ab[SALE], nb, na, tiempo);
         /*Primero ordeno en base a las salidas de A*/
         shellsort(ab[LLEGA], na);
         /*Por lo que ordeno en base a las llegadas de B*/
         shellsort(ba[SALE], nb);
 /*        imprime(ab, na);
         imprime(ba, nb);*/
         salenb = empalma(ab[LLEGA], ba[SALE], na, nb, tiempo);
         printf("Case #%d: %d %d\n", k, salena, salenb);
     }
     return 0;
 }

