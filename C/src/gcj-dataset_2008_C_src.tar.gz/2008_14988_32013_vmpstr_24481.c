#include <stdio.h>
 #include <string.h>
 
 int main(void)
 {
 	int cases, turn, na, nb;
 	int atrain, btrain;
 	int a[101][2];
 	int b[101][2];
 	int i, j, t1, t2, cur, curp, curpick;
 	
 	scanf("%d\n", &cases);
 	for(i=0; i<cases; i++)
 	{
 		atrain = btrain = 0;
 		scanf("%d\n", &turn);
 		scanf("%d %d\n", &na, &nb);
 		for(j=0; j<na; j++)
 		{
 			scanf("%d:%d ", &t1, &t2);
 			a[j][0] = t1*60 + t2;
 			
 			scanf("%d:%d\n", &t1, &t2);
 			a[j][1] = t1*60 + t2;
 
 		}
 		for(j=0; j<nb; j++)
 		{
 			scanf("%d:%d ", &t1, &t2);
 			b[j][0] = t1*60 + t2;
 		
 			scanf("%d:%d\n", &t1, &t2);
 			b[j][1] = t1*60 + t2;
 
 		}
 		for(;;)
 		{
 			cur = 1e6;
 			curp = -1;
 			curpick = -1;
 			for(j=0; j<na; j++)
 			{
 				if(a[j][0] < cur)
 				{
 					cur = a[j][0];
 					curp = j;
 					curpick = 'a';
 				}
 			}
 			for(j=0; j<nb; j++)
 			{
 				if(b[j][0] < cur)
 				{
 					cur = b[j][0];
 					curp = j;
 					curpick = 'b';
 				}
 			}
 			if(curp < 0)
 			{
 				break;
 			}
 			if(curpick == 'a')
 			{
 				atrain++;
 				cur = a[curp][1]+turn;
 				a[curp][0] = a[na-1][0];
 				a[curp][1] = a[na-1][1];
 				na--;
 				curpick = 'b';
 
 			}
 			else if(curpick == 'b')
 			{
 				btrain++;
 				cur = b[curp][1]+turn;
 				b[curp][0] = b[nb-1][0];
 				b[curp][1] = b[nb-1][1];
 				nb--;
 				curpick = 'a';
 
 			}
 			
 			for(;;)
 			{
 				int newcur = 1e6;
 				if(curpick == 'a')
 				{
 					for(j=0; j<na; j++)
 					{
 						if((a[j][0] >= cur) &&
                                                    (a[j][0] < newcur))
 						{
 							newcur = a[j][0];
 							curp = j;
 						}
 					}
 					if(newcur < 1e6)
 					{
 						cur = a[curp][1]+turn;
 						a[curp][0] = a[na-1][0];
 						a[curp][1] = a[na-1][1];
 						na--;
 						curpick = 'b';
 								
 					}
 					else break;
 				}
 				newcur = 1e6;
 				if(curpick == 'b')
 				{
 					for(j=0; j<nb; j++)
 					{
 						if((b[j][0] >= cur) &&
                                                    (b[j][0] < newcur))
 						{
 							newcur = b[j][0];
 							curp = j;
 						}
 					}
 					if(newcur < 1e6)
 					{
 						cur = b[curp][1]+turn;
 						b[curp][0] = b[nb-1][0];
 						b[curp][1] = b[nb-1][1];
 						nb--;
 						curpick = 'a';
 					}
 					else break;
 				}
 			}
 		}
 		printf("Case #%d: %d %d\n", i+1, atrain, btrain);
 	}
 	return 0;
 }

