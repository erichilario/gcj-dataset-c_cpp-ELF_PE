#include<stdio.h>
 #include<alloc.h>
 #include<stdlib.h>
 
 typedef struct
 {
  int h;
  int m;
 }time;
 
 int main()
 {
  time Aa[100],Ad[100],Ba[100],Bd[100],temp;
  FILE *fp,*fp1;
  int n_cases,i_cases,i,j,x,T,NA,NB,na,nb;
 
 
  fp=fopen("input.dat","r");
  fp1=fopen("output.dat","w");
  if(fp==NULL)
  {
   printf("file not found");
   exit(1);
  }
  if(fp1==NULL)
  {
   printf("file not found");
   exit(1);
  }
 
 
  fscanf(fp,"%d\n",&n_cases);
 
  i_cases=-1;
  while(++i_cases<n_cases)
  {
   fscanf(fp,"%d\n",&T);
   fscanf(fp,"%d %d\n",&NA,&NB);
 
   for(i=0;i<NA;i++)
    fscanf(fp,"%d:%d %d:%d\n",&Ad[i].h,&Ad[i].m,&Ba[i].h,&Ba[i].m);
 
   for(i=0;i<NB;i++)
    fscanf(fp,"%d:%d %d:%d\n",&Bd[i].h,&Bd[i].m,&Aa[i].h,&Aa[i].m);
 
   for(i=0;i<NA-1;i++)
   {
    for(j=0;j<NA-i-1;j++)
    {
     if((Ba[j].h>Ba[j+1].h) || (Ba[j].h==Ba[j+1].h && Ba[j].m>Ba[j+1].m))
     {
      x=Ba[j].h;
      Ba[j].h=Ba[j+1].h;
      Ba[j+1].h=x;
      x=Ba[j].m;
      Ba[j].m=Ba[j+1].m;
      Ba[j+1].m=x;
     }
     if((Ad[j].h>Ad[j+1].h) || (Ad[j].h==Ad[j+1].h && Ad[j].m>Ad[j+1].m))
     {
      x=Ad[j].h;
      Ad[j].h=Ad[j+1].h;
      Ad[j+1].h=x;
      x=Ad[j].m;
      Ad[j].m=Ad[j+1].m;
      Ad[j+1].m=x;
     }
    }
   }
 
   for(i=0;i<NB-1;i++)
   {
    for(j=0;j<NB-i-1;j++)
    {
     if((Aa[j].h>Aa[j+1].h) || (Aa[j].h==Aa[j+1].h && Aa[j].m>Aa[j+1].m))
     {
      x=Aa[j].h;
      Aa[j].h=Aa[j+1].h;
      Aa[j+1].h=x;
      x=Aa[j].m;
      Aa[j].m=Aa[j+1].m;
      Aa[j+1].m=x;
     }
     if((Bd[j].h>Bd[j+1].h) || (Bd[j].h==Bd[j+1].h && Bd[j].m>Bd[j+1].m))
     {
      x=Bd[j].h;
      Bd[j].h=Bd[j+1].h;
      Bd[j+1].h=x;
      x=Bd[j].m;
      Bd[j].m=Bd[j+1].m;
      Bd[j+1].m=x;
     }
    }
   }
 
   na=NA;
   for(i=0;i<NB;i++)
   {
    temp.m=Aa[i].m+T;
    temp.h=Aa[i].h+(temp.m/60);
    temp.m%=60;
 
    for(j=0;j<NA;j++)
    {
     if(Ad[j].h<temp.h)
      continue;
     if(Ad[j].h==temp.h && Ad[j].m<temp.m)
      continue;
     break;
    }
    if(j<NA)
    {
     Ad[j].h=-1;
     Ad[j].m=-1;
     na--;
    }
    else
     break;
   }
 
   nb=NB;
   for(i=0;i<NB;i++)
   {
    temp.m=Ba[i].m+T;
    temp.h=Ba[i].h+(temp.m/60);
    temp.m%=60;
 
    for(j=0;j<NB;j++)
    {
     if(Bd[j].h<temp.h)
      continue;
     if(Bd[j].h==temp.h && Bd[j].m<temp.m)
      continue;
     break;
    }
    if(j<NB)
    {
     Bd[j].h=-1;
     Bd[j].m=-1;
     nb--;
    }
    else
     break;
   }
 
   fprintf(fp1,"Case #%d: %d %d\n",i_cases+1,na,nb);
   printf("Case #%d: %d %d\n",i_cases,na,nb);
  }
  fclose(fp);
  fclose(fp1);
  return 0;
 }
