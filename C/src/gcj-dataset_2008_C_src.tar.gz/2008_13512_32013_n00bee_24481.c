#include <stdio.h>
 #include <stdlib.h>
 
 #define MAX_TEMP_SZ	128
 
 #define MAX_T		60
 
 #define MAX_NA		100
 #define MAX_NB		100
 
 typedef enum
 {
 	STATION_A = 0,
 	STATION_B
 } station_type;
 
 typedef enum
 {
 	DEPARTURE = 0,
 	ARRIVAL
 } train_state;
 
 typedef struct
 {
 	int minute;
 	train_state state;
 } trains_at_station;
 
 int get_number(char ch)
 {
 	return ch - '0';
 }
 
 int convert_time_to_minute(char *str)
 {
 	int hour, min;
 	int value;
 
 	if( str[2] != ':' )
 		return -1;
 
 	hour = get_number(str[0]) * 10 + get_number(str[1]);
 	min = get_number(str[3]) * 10 + get_number(str[4]);
 
 	value = hour * 60 + min;
 
 	return value;
 }
 
 void translate_timeline(char *str, trains_at_station *ta, trains_at_station *tb, station_type st, int turn_around_time)
 {
 	int count, delta_t;
 	trains_at_station *t[2];
 
 	switch(st)
 	{
 		case STATION_A:
 			t[0] = ta;
 			t[1] = tb;
 			break;
 
 		case STATION_B:
 			t[0] = tb;
 			t[1] = ta;
 			break;
 	}
 
 	count = 0;
 	delta_t = 0;
 
 	while( (*str) && (count < 2) )
 	{
 		if( (*str >= '0') && (*str <= '9') )
 		{
 			t[count]->minute = convert_time_to_minute(str) + delta_t;
 			t[count]->state = count;
 
 			if( t[count]->minute < 0 )
 			{
 				printf("ERROR: INVALID INPUT FORMAT\n");
 
 				exit(-1);
 			}
 
 			str += 5;
 			delta_t = turn_around_time;
 			count++;
 		}
 		else
 			str++;
 	}
 }
 
 int qs_comp(const void *c1, const void *c2)
 {
 	return (((trains_at_station *)c1)->minute - ((trains_at_station *)c2)->minute) * 2 + 
 		   (((trains_at_station *)c2)->state - ((trains_at_station *)c1)->state); // calcualte arrival first
 }
 
 void sort_timelines(trains_at_station *ta, trains_at_station *tb, int num)
 {
 	qsort(ta, num, sizeof(trains_at_station), qs_comp);
 	qsort(tb, num, sizeof(trains_at_station), qs_comp);
 }
 
 int count_number_of_trains_required(trains_at_station *t, int count)
 {
 	int i;
 	int starting_trains, remaining_trains;
 
 	remaining_trains = 0;
 	starting_trains = 0;
 
 	for( i = 0; i < count; i++ )
 	{
 		switch( t[i].state )
 		{
 			case DEPARTURE:
 				if( remaining_trains > 0 )
 					remaining_trains--;
 				else
 					starting_trains++;
 				break;
 
 			case ARRIVAL:
 				remaining_trains++;
 				break;
 		}
 	}
 
 	return starting_trains;
 }
 
 void read_timetable(FILE *fp, int *trains)
 {
 	int i;
 	int turn_around_time;
 	int num_a, num_b;
 	char temp[MAX_TEMP_SZ];
 	trains_at_station ta[MAX_NA + MAX_NB], tb[MAX_NA + MAX_NB];
 
 	fscanf(fp, "%d\n", &turn_around_time);
 	fscanf(fp, "%d %d\n", &num_a, &num_b);
 
 	memset(ta, 0, sizeof(ta));
 	memset(tb, 0, sizeof(tb));
 
 	for( i = 0; i < num_a + num_b; i++ )
 	{
 		fgets(temp, MAX_TEMP_SZ, fp);
 
 		translate_timeline(temp, &ta[i], &tb[i], (i < num_a) ? STATION_A : STATION_B, turn_around_time);
 	}
 
 	sort_timelines(ta, tb, num_a + num_b);
 
 	trains[0] = count_number_of_trains_required(ta, num_a + num_b);
 	trains[1] = count_number_of_trains_required(tb, num_a + num_b);
 }
 
 int main(int argc, char *argv[])
 {
 	FILE *fp;
 	int i, max_trial;
 	int trains[2];
 
 	if( argc < 2 )
 	{
 		printf("%s <filename>\n", argv[0]);
 
 		return -1;
 	}
 
 	fp = fopen(argv[1], "r");
 
 	if( fp == NULL )
 	{
 		printf("Unable to open file '%s'\n", argv[1]);
 
 		return -2;
 	}
 
 	fscanf(fp, "%d\n", &max_trial);
 
 	for( i = 0; i < max_trial; i++ )
 	{
 		read_timetable(fp, trains);
 
 		printf("Case #%d: %d %d\n", i + 1, trains[0], trains[1]);
 	}
 
 	fclose(fp);
 
 	return 0;
 }

