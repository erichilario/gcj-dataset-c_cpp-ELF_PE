#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define M 100
 
 struct trip { int a,d; } a[M],b[M];
 
 int fa(const void *l, const void *d) {
 	if (((struct trip *)l)->a>((struct trip *)d)->a) return 1;
 	if (((struct trip *)l)->a<((struct trip *)d)->a) return -1;
 	return 0;
 }
 
 int fd(const void *l, const void *d) {
 	if (((struct trip *)l)->d>((struct trip *)d)->d) return 1;
 	if (((struct trip *)l)->d<((struct trip *)d)->d) return -1;
 	return 0;
 }
 
 main() {
 	int i,j,k,n,na,nb,h,m,tt,nv,mav,mbv;
 
 	scanf("%d",&n);
 	for (k=1;k<=n;k++) {
 		scanf("%d",&tt);
 		scanf("%d %d",&na,&nb);
 		for (i=0;i<na;i++) {
 			scanf("%d:%d",&h,&m);
 			a[i].d=m+h*60;
 			scanf("%d:%d",&h,&m);
 			a[i].a=m+h*60;
 		}
 		for (i=0;i<nb;i++) {
 			scanf("%d:%d",&h,&m);
 			b[i].d=m+h*60;
 			scanf("%d:%d",&h,&m);
 			b[i].a=m+h*60;
 		}
 		qsort(a,na,sizeof(struct trip),fd);
 		qsort(b,nb,sizeof(struct trip),fa);
 		for (mav=nv=j=i=0;i<na;i++) {
 			while (j<nb) if (b[j].a+tt<=a[i].d) j++, nv++;
 				else break;
 			nv--;
 			if (nv<mav) mav=nv;
 		}
 		qsort(a,na,sizeof(struct trip),fa);
 		qsort(b,nb,sizeof(struct trip),fd);
 		for (mbv=nv=j=i=0;i<nb;i++) {
 			while (j<na) if (a[j].a+tt<=b[i].d) j++, nv++;
 				else break;
 			nv--;
 			if (nv<mbv) mbv=nv;
 		}
 		printf("Case #%d: %d %d\n",k,-mav,-mbv);
 		fflush(stdin);
 	}
 }

