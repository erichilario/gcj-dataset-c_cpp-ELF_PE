#include<stdio.h>
 #include<string.h>
 #define MAX_NUMBER_OF_SEARCH_ENGINES 10
 #define MAX_NUMBER_OF_QUERIES 100
 #define FILENAME "A-small-attempt2.in"
 
 typedef struct searchEnginesStruct
 {
     char name[MAX_NUMBER_OF_SEARCH_ENGINES][100];
     int flag[MAX_NUMBER_OF_SEARCH_ENGINES];
 }searchEnginesStruct;
 
 typedef struct queryStruct
 {
     char name[MAX_NUMBER_OF_QUERIES][100];
 }queryStruct;
 
 int solveInput(searchEnginesStruct searchEngines, queryStruct queries, int N, int S, int Q, int* start, int *finish)
 {
     int i, j, k, count;
     for(i=0; i<S; i++)
         searchEngines.flag[i]=0;
 
     count=0;
     for(i=*start; i<Q; i++)  // go thru the queries
     {
         for(j=0; j<S; j++)  // go thru the search engines
             if(strcmp(queries.name[i],searchEngines.name[j])==0)
             {
                 if(searchEngines.flag[j]==0)
                 {
                     searchEngines.flag[j]=1;
                     count++;
                 }
                 break;
             }
        if(count==S-1 && i+1!=Q)  //only one engine remaining
        {
            for(k=0; k<S; k++)
            {
                if(strcmp(queries.name[i+1], searchEngines.name[k])==0 && searchEngines.flag[k]==0)
 
                 {
                     *finish=i+1;
                     return 1;
                 }
            }
        }
     }
     return 0;
 }
 
 
 int main()
 {
     searchEnginesStruct searchEngines;
     queryStruct queries;
     FILE *file;
     FILE *fileOut;
     int N, S, Q;
     int noOfChanges=-1;
     int start;
 
     int i, j;
 
 
     file=fopen(FILENAME, "r");
     fileOut=fopen("output.txt", "w");
 
     if(file==NULL)
     {
         printf("Error: can't open file.\n");
         return 1;
     }
     else
     {
 
         printf("File opened successfully.\n");
 
         fscanf(file, "%d", &N);
         for(i=0; i<N; i++)
         {
             fscanf(file,"%d", &S);
             for(j=-1; j<S; j++)
             {
                 fgets((searchEngines.name[j]), 100, file);
                 searchEngines.name[j][strlen(searchEngines.name[j])-1]='\0';
             }
             fscanf(file,"%d", &Q);
             for(j=-1; j<Q; j++)
             {
                 fgets((queries.name[j]), 100, file);
                 queries.name[j][strlen(queries.name[j])-1]='\0';
             }
 
             start=0;
             noOfChanges=0;
             while(solveInput(searchEngines, queries, N, S, Q, &start, &start)!=0 )
             {
                 noOfChanges++;
             }
             fprintf(fileOut,"Case #%d: %d\n",i+1, noOfChanges);
             printf("Case #%d: %d\n",i+1, noOfChanges);
         }
     }
 
     fclose(file);
     fclose(fileOut);
     return 1;
 }
 

