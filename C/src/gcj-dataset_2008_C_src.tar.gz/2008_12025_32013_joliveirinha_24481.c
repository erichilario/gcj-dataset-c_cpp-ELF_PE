#include <stdio.h>
 #include <stdlib.h>
 
 #define MAX 205
 
 typedef struct _route {
 	int station;
 	int h1, m1, h2,m2;
 } route;
 
 typedef struct _train {
 	int station;
 	int h, m;
 } train;
 
 route timetable[MAX];
 train trains[MAX];
 int n, na, nb, t, conta;
 
 int cmp(const void *a, const void *b) {
 	route *a2 = (route *) a;
 	route *b2 = (route *) b;
 
 	if (a2->h1 == b2->h1)
 		return a2->m1 - b2->m1;
 	else return a2->h1 - b2->h1;
 }
 
 int checktime(int a, int b) {
 
 	int t = timetable[a].h1 - trains[b].h;
 	int t2 = timetable[a].m1 - trains[b].m;
 
 	//printf("%d:%d %d:%d\n", timetable[a].h1, timetable[a].m1, trains[b].h, trains[b].m);
 
 	if (t>0 || (t==0 && t2>=0))
 		return 1;
 	else return 0;
 }
 
 int main(void) {
 	int i, j, a, b, c, d;
 	int contat[2], conta;
 
 	scanf("%d", &n);
 
 	for (i=0;i<n;i++) {
 		scanf("%d%d%d", &t, &na, &nb);
 		for (j=0;j<na+nb;j++) {
 			scanf("%d:%d %d:%d", &timetable[j].h1, &timetable[j].m1, &timetable[j].h2, &timetable[j].m2);
 			
 			if (j>=na)
 				timetable[j].station = 1;
 			else timetable[j].station = 0;
 		}
 	
 
 		qsort(timetable, na+nb, sizeof(route), cmp);
 
 		conta = contat[0] = contat[1] = 0;
 		for (j=0;j<na+nb;j++) {
 			int flag = 0;
 			int k, use;
 
 			for (k=0;k<conta;k++) 
 				if (timetable[j].station == trains[k].station && checktime(j, k)) {
 					use = k;
 					flag = 1;
 					break;
 				}
 
 			if (!flag) { 
 				use = conta;
 				conta++;
 				contat[timetable[j].station]++;
 			}
 
 			trains[use].station = !timetable[j].station;
 			trains[use].m = (timetable[j].m2 + t)%60;
 			trains[use].h = timetable[j].h2 + (timetable[j].m2+t>=60?1:0); 
 		}
 
 		printf("Case #%d: %d %d\n", i+1, contat[0], contat[1]);
 	}
 
 	return 0;
 }
 

