#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #define HASH_PRIME 5003
 
 typedef struct node *link;
 struct node {
     int w;
     link next;
 };
 
 char engines[100][100];
 link hash_table[HASH_PRIME];
 int queries[1000];
 int full[100];
 
 /*Universal hash function */
 int hash(char *key)
 {
     int h, a=31415, b=27183;
     for (h=0; *key!='\0'; key++, a=a*b%(HASH_PRIME-1))
 	h = (a*h + *key) % HASH_PRIME;
     return h;
 }
 
 int hash_find(char *word)
 {
     int i = hash(word);
     link p;
     for(p=hash_table[i]; p!=NULL; p=p->next)
 	if(strcmp(word, engines[p->w]) == 0)
 	    return p->w;
     return -1;
 }
 
 link hash_insert(link p, int w)
 {
     link new = malloc(sizeof(link));
     new->w = w;
     new->next = p;
     return new;
 }
 
 /*Inserts search engine number in the hash_table */
 void add(int x)
 {
     int i = hash(engines[x]);
     hash_table[i] = hash_insert(hash_table[i], x);
 }
 
 void cleanup()
 {
     int i;
     for(i=0; i<HASH_PRIME; i++){
 	free(hash_table[i]);
 	hash_table[i] = NULL;
     }	
 }
 
 /*Calculates minimum number of switches */
 int solve(int Nengines, int Nqueries)
 {
     int i, switches=0, sum=0, j, sENG = -1;
     for(i=0; i<Nengines; i++)
 	full[i] = -1;
 
     for(i=0; i<Nqueries; i++){
 	/*printf("%s\n", engines[queries[i]]);*/
 	if(full[queries[i]] == -1){
 	    full[queries[i]] = 1;
 	    sum++;
 	}
 
 	if(sum == Nengines){
 	    sENG = queries[i];
 	    switches++;
 	    sum = 0;
 	    for(j=0; j<Nengines; j++)
 		full[j] = -1;
 	    i--;
 	    /*printf("ateh aqui com o %s\n", engines[sENG]);*/
 	}
     }
 	
 
     return switches;
 }
 
 int main()
 {
     int n, tests = 1, eng, i, j, k, q;
     char c, query[100];
 
     scanf("%d", &n);
 
     while(n>0){
 	/*Prepare hash_table */
 	cleanup();
 
 	/*Get Search Engines */
 	scanf("%d", &eng);
 	getchar();
 	for(i=0; i<eng; i++){
 	    c = getc(stdin);
 	    j=0;
 	    while(c!='\n'){
 		engines[i][j++] = c;
 		c = getc(stdin);
 	    }
 	    engines[i][j] = '\0';
 	    add(i);
 	}
 
 	/*Get Queries */
 	scanf("%d", &q);
 	getchar();
 	for(i=0, k=0; i<q; i++){
 	    c = getc(stdin);
 	    j=0;
 	    while(c!='\n'){
 		query[j++] = c;
 		c = getc(stdin);
 	    }
 	    query[j] = '\0';
 
 	    queries[k] = hash_find(query);
 	    if(k==0 || queries[k-1] != queries[k])
 		k++;			    
 	}
 	
 	/*Solve & print answer */
 	printf("Case #%d: %d\n", tests++, solve(eng, k));
 	n--;
     }
 
     return 0;
 }

