#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main(){
     int N, S, Q;
     int i, j, k;
     int answer;
     char sname[150][150];
     int sflag[150], scount;
     char query[150];
 
     gets(query);
     N = atoi(query);
 
     for(i = 0; i < N; i++){
           answer = 0;
           memset(sflag, 0, sizeof(sflag));
           scount = 0;
 
           gets(query);
           S = atoi(query);
           for(j = 0; j < S; j++){
                 gets(sname[j]);
           }
 
           gets(query);
           Q = atoi(query);
           for(j = 0; j < Q; j++){
                 gets(query);
                 for(k = 0; k < S; k++){
                       if(strcmp(query, sname[k]) == 0) break;
                 }
                 if(k == S) printf("error\n");
 
                 if(sflag[k] == 0){
                       sflag[k] = 1;
                       scount++;
 
                       if(scount == S){
                            answer++;
                            memset(sflag, 0, sizeof(sflag));
                            scount = 1;
                            sflag[k] = 1;
                       }
                 }
           }
           printf("Case #%d: %d\n", i + 1, answer);
     }
 
     return 0;
 }

