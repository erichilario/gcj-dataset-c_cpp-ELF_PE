#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define MAX_FILENAME 20
 #define MAX_LINE_LENGTH 50
 #define MAX_TEST_CASES 20
 #define MAX_SEARCHENGINES 100
 
 void process_testcase(FILE *, FILE *, int, int);
 
 main()
 {
 
 	char str_buf[MAX_FILENAME + 2];
 	FILE *filePtr = NULL;
 	FILE *outfile = NULL;
 	char line[MAX_LINE_LENGTH + 2];
 	int input_number, testcases, i;
 
 	printf("Enter input type (1 for small, 2 for large):\n");
 	fgets(str_buf, MAX_LINE_LENGTH + 1, stdin);
 	sscanf(str_buf, "%d", &input_number);
 	if (input_number == 1)
 	{
 		filePtr = fopen("A-small.in", "r");
 	}
 	else if (input_number == 2)
 	{
 		filePtr = fopen("A-large.in", "r");
 	}
 	if (filePtr == NULL)
 	{
 		fprintf(stderr, "Error: input file not found.\n");
 		return;
 	}
 
 	outfile = fopen("qual.out", "w");
 
 	while (fgets(line, MAX_LINE_LENGTH + 1, filePtr) != NULL)
 	{
 		sscanf(line, "%d", &testcases);
 
 		if (testcases < 1 || testcases > MAX_TEST_CASES)
 		{
 			fprintf(stderr, "Error: invalid number of test cases, must be between 1 and %d inclusive.\n", MAX_TEST_CASES);
 			return;
 		}
 
 		for (i=0; i<testcases; i++)
 		{
 			process_testcase(filePtr, outfile, i+1, input_number);
 		}
 	}
 
 	fclose(filePtr);
 	fclose(outfile);
 	
 	return;
 }
 
 void process_testcase(FILE *filePtr, FILE *outfile, int test_case, int input_number)
 {
 	char line[MAX_LINE_LENGTH + 2];
 	int searchengines, queries, i, j, k;
 	char *searchenginelist[MAX_SEARCHENGINES];
 	char searchenginename[MAX_LINE_LENGTH + 1];
 	char query[MAX_LINE_LENGTH + 1];
 	int visited[MAX_SEARCHENGINES];
 	int switchcount = 0, hitcount = 0;
 	
 	fgets(line, MAX_LINE_LENGTH + 1, filePtr);
 	sscanf(line, "%d", &searchengines);
 
 	if (searchengines < 2 || (input_number == 1 && searchengines > 10) || searchengines > MAX_SEARCHENGINES)
 	{
 		fprintf(stderr, "Error: too many search engines.\n");
 		return;
 	}
 
 	for (i=0; i<searchengines; i++)
 	{
 		fgets(searchenginename, MAX_LINE_LENGTH + 1, filePtr);
 		searchenginelist[i] = (char *) malloc(strlen(searchenginename) +1);
 		strcpy(searchenginelist[i], searchenginename);
 		visited[i] = 0;
 	}
 
 	fgets(line, MAX_LINE_LENGTH + 1, filePtr);
 	sscanf(line, "%d", &queries);
 
 if (queries < 0 || (input_number == 1 && queries > 100) || queries > 1000)
 	{
 		fprintf(stderr, "Error: too many queries.\n");
 		return;
 	}
 
 	for (i=0; i<queries; i++)
 	{
 		fgets(query, MAX_LINE_LENGTH + 1, filePtr);
 		j = 0;
 		while (j < searchengines && strcmp(query, searchenginelist[j]) != 0)
 			j++;
 
 		if (j < searchengines)
 		{
 			if (visited[j] != 1)
 			{
 				visited[j] = 1;
 				if (hitcount < searchengines - 1)
 					hitcount++;
 				else
 				{
 					switchcount++;
 					for (k=0; k<searchengines; k++)
 						if (k != j)
 							visited[k] = 0;
 					hitcount = 1;
 				}
 			}
 		}
 	}
 
 	fprintf(outfile, "Case #%d: %d\n", test_case, switchcount);
 
 	return;
 
 }
