#include <stdio.h>
 #include <stdlib.h>
 
 
 
 struct train{
        int arr;
        int dep;
        int marker;
        };
 
 typedef struct train train;
 train train1[5],temp;
 
 
 int main(){
     int i,j,k,l,i1,op1=0,op2=0,test,test1=0,ta=0,t1=0,t2=0;
     FILE *fp;
     fp=fopen("input.in","r");
     fscanf(fp,"%d\n",&test1);
     test1=test1+1;
     for(test=1;test<test1;test++){
     fscanf(fp,"%d\n",&ta);
     fscanf(fp,"%d\n",&t1);
     fscanf(fp,"%d\n",&t2);
       
      for(i1=0;i1<t1;i1++){
     fscanf(fp,"%d:%d    %d:%d\n",&i,&j,&k,&l);
   //  printf("%d:%d",i,j);
     train1[i1].arr=(i*60+j);
     train1[i1].dep=(k*60+l+ta);
     train1[i1].marker=1;
     }
 for(i1=t1;i1<(t1+t2);i1++){
     fscanf(fp,"%d:%d    %d:%d\n",&i,&j,&k,&l);
    // printf("%d:%d",i,j);
     train1[i1].arr=(i*60+j);
     train1[i1].dep=(k*60+l+ta);
        train1[i1].marker=2;
 }
     //for(i1=0;i1<(t1+t2);i1++)
     //printf("%d------------->%d  %d \n", train1[i1].arr,train1[i1].dep,train1[i1].marker);
     //printf("\n\n\n");
 
 j=0;
 
  
 
      for(i = 0; i < (t1+t2-1); i++)
      {
           for ( j=i+1;j<(t1+t2);j++)
           {
                if ((train1[i].arr > train1[j].arr))  //comparing brands
                {
                      temp = train1[ i ];    //swapping entire struct
                      train1[i] =train1[j];
                      train1[j] = temp;
                }
           }
      }
 
 
 
 /*
 
 for(i1=0;i1<5;i1++)
     printf("%d------------->%d  %d \n", train1[i1].arr,train1[i1].dep,train1[i1].marker);
     
   */  
     
     
     
 for(i=0;i<(t1+t2-1);i++)
 {
  for(j=i+1;j<(t1+t2);j++){
      if((train1[i].dep > train1[j].arr)||(train1[j].arr==9999))
      continue;
      else         
      {//printf("\n %d:%d", train1[i].dep,train1[j].arr);
      if(train1[i].marker==train1[j].marker)
           continue;
        else{          train1[j].arr   =9999;         
       if(train1[i].marker==1)         
          { op2=op2-1;}//printf("\n inininelse  i=%d,j=%d,%d",i,j,op1);}
        else
           {op1=op1-1;}//printf("\n ininin else i=%d,j=%d,%d",i,j,op2);}
                 break;  }
      if(train1[i].marker==1)
      {op1=op1+1;} //printf("i=%d,j=%d,%d",i,j,op1);}
       else
       {op2=op2+1;}//printf("i=%d,j=%d,%d",i,j,op2);}             
                   
                   
                   }
      
      }
                 
                 
                 
                 
                 
                 
                 
                 
                 }    
     
     
     
     
   
     
     
     
     printf("Case #%d: %d %d\n",test,t1+op1,t2+op2);
     
     
     
     ta=0,t1=0,t2=0,op1=0;op2=0;
 }
 
 }

