#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 char* engines[104];
 char* queries[1004];
 int apps[104];
 
 void initialise(){
   int i;
   for(i=0;i<104;i++)
     engines[i] = (char*) malloc(105*(sizeof(char)));
     
   for(i=0;i<1004;i++)
     queries[i] = (char*) malloc(105*(sizeof(char)));
 }
 
 int getno(char* s){
   int i = 1;
   while(0 != (strcmp(s,engines[i])))
     i++;
   return (i);
 }
 
 int findans(int e, int q){ // number of engines and queries
   int total = 0;
   int at = 1;
   int j;
   int ans = 0;
   int num;
 
   
   while(at<=q){
     for(j=1;j<=e;j++)
       apps[j] = 0;
     
     total = 0;
     
     for(;((at<=q)&&(total<e));at++){
       num = getno(queries[at]);
 
       if (apps[num] == 0){
 	total++;
 	
 	if (total == e){
 	  at--;  
 	  ans++;
 	}
 	
 	apps[num] = 1;
 	
       }
      
     }
   }
 
   return(ans);
 }
 
 
 void doacase(int caseno){
   int e,q;
   int i;
   int linesize = 110;
   scanf("%d",&e);
   getchar();
   
   for(i=1;i<=e;i++){
     getline(engines+i,&linesize,stdin);
   }
   
   scanf("%d",&q);
 
   getchar();
   
   for(i=1;i<=q;i++){
     getline(queries+i,&linesize,stdin);
   }
 
   printf("Case #%d: %d\n",caseno,findans(e,q));
 }
 
 
 int main(){
   int nofcases;
   int i;
 
   initialise();
   scanf("%d",&nofcases);
   getchar();
   
   for(i=1;i<=nofcases;i++)
     doacase(i);
   
   return(0);
 }
 

