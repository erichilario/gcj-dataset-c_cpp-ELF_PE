#include <stdio.h>
 #include <string.h>
 /*
 #include <math.h>
 */
 
 /* Used for debug levels */
 /* #define	I_DEBUG	1		*/
 /* #define	DEBUG	1		*/
 /* #define	O_DEBUG	1		*/
 
 /* Structure to store the train table and the departure arrival schedule */
 /* The time is stored in format HHMM and the conversion from 0060 to 0100 */
 /* will be managed in the program */
 
 struct	traint {
 	int	time;
 	int	depart;
 	};
 
 struct	traint	train_a[40];
 struct	traint	train_b[40];
 
 int	travel_a;
 int	travel_b;
 int	total_travel;
 int	turnaround;
 
 int	get_input();
 
 main(argc, argv)
 {
 int	i, j, min, k;
 int	n;
 int max_a, max_b, count;
 
 extern	struct	traint	train_a[];
 extern	struct	traint	train_b[];
 struct	traint	train_t;
 
 /* Input function */
 /* Get number of cases */
 	n = get_input(0);
 
 /* Processing function */
 	for(i = 0; i < n; i++) {
 		turnaround = get_input(0);
 		get_input(1);
 		total_travel = travel_a + travel_b;
 		for(j = 0; j < total_travel; j++) {
 			if(!get_input(j+2))
 			break;
 #ifdef DEBUG
 		printf("I %d --> J %d\n", i, j);  
 #endif
 		}
 
 /* Sorting structs */
 		for(j=0; j< total_travel; j++) {
 			min=j;
 			for(k=j+1; k<total_travel; k++) {
 				if(train_a[k].time < train_a[min].time) {
 					train_t.time = train_a[min].time;
 					train_t.depart = train_a[min].depart;
 					train_a[min].time = train_a[k].time;
 					train_a[min].depart = train_a[k].depart;
 					train_a[k].time = train_t.time;
 					train_a[k].depart = train_t.depart;
 				}
 				if(train_a[k].time == train_a[min].time) {
 					if(train_a[min].depart){
 						train_t.depart = train_a[min].depart;
 						train_a[min].depart = train_a[k].depart;
 						train_a[k].depart = train_t.depart;
 					}
 				}
 			}
 		}
 
 		max_a = 0;
 		count = 0;
 		for(j = 0; j < total_travel; j++) {
 			if(train_a[j].time >= 2400)
 				continue;
 			if(train_a[j].depart)
 				count++;
 			else
 				count--;
 			if(max_a < count)
 				max_a = count;
 #ifdef O_DEBUG
 			printf("%d - %d %d ct %d mx %d\n", j, train_a[j].time, train_a[j].depart, count, max_a);
 #endif
 		}
 
 		for(j=0; j< total_travel; j++) {
 			min=j;
 			for(k=j+1; k<total_travel; k++) {
 				if(train_b[k].time < train_b[min].time) {
 					train_t.time = train_b[min].time;
 					train_t.depart = train_b[min].depart;
 					train_b[min].time = train_b[k].time;
 					train_b[min].depart = train_b[k].depart;
 					train_b[k].time = train_t.time;
 					train_b[k].depart = train_t.depart;
 				}
 				if(train_b[k].time == train_b[min].time) {
 					if(train_b[min].depart){
 						train_t.depart = train_b[min].depart;
 						train_b[min].depart = train_b[k].depart;
 						train_b[k].depart = train_t.depart;
 					}
 				}
 			}
 		}
 
 		max_b = 0;
 		count = 0;
 		for(j = 0; j < total_travel; j++) {
 			if(train_b[j].time >= 2400)
 				continue;
 			if(train_b[j].depart)
 				count++;
 			else
 				count--;
 			if(max_b < count)
 				max_b = count;
 			
 #ifdef O_DEBUG
 			printf("%d - %d %d ct %d mx %d\n", j, train_b[j].time, train_b[j].depart, count, max_b);
 #endif
 		}
 
 /* Output process */
 
 
 /* Printing output */
 
 		printf("Case #%d: %d %d\n", i+1, max_a, max_b);	
 	}
 }
 
 get_input(int l)
 {
 	int	n;
 	char	c;
 	char 	lptr[30];
 	char	*s;
 	/* hour and minutes */
 	int	h1, h2, m1, m2;
 	int	temp;
 	double x;
 
 	/* train struct reference */
 	struct	traint	*tr_a;
 	struct	traint	*tr_b;
 	extern	struct	traint	train_a[];
 	extern	struct	traint	train_b[];
 	
 	n = 0;
 	c = -1;
 	s = &lptr[0];
 
 	#ifdef I_DEBUG
 		printf("L %d\n", l);
 	#endif
 
 	while (c != '\n' && c != '\0') {
 		c = getchar();
 		lptr[n++] = c;
 	}
 	lptr[n] = '\0';
 	
 	#ifdef I_DEBUG
 		printf("STRING %s\n", s);
 	#endif
 	if(c == '\0')
 		return(0);
 	if(l == 0) {
 	#ifdef I_DEBUG
 		printf("DEC %d\n", atoi(s));
 	#endif
 		return(atoi(s));
 	}
 	else if(l == 1){
 	#ifdef I_DEBUG
 		printf("LEN %d\n", strlen(s));
 	#endif
 		sscanf(s,"%d %d", &travel_a, &travel_b);
 	#ifdef I_DEBUG
 		printf("NA NB %d %d", travel_a, travel_b);
 	#endif
 	}
 	else {
 	#ifdef I_DEBUG
 		printf("LEN %d\n", strlen(s));
 	#endif
 		sscanf(s,"%d:%d %d:%d", &h1, &m1, &h2, &m2);
 		if((l-2) < travel_a) {
 			train_a[l-2].time = h1*100+m1;
 			temp = m2+turnaround;
 			if(temp >= 60){
 				temp -= 60;
 				h2++;
 			}
 			train_b[l-2].time = h2*100+temp;
 			train_a[l-2].depart = 1;
 			train_b[l-2].depart = 0;
 		}
 		else {
 			train_b[l-2].time = h1*100+m1;
 			temp = m2+turnaround;
 			if(temp >= 60){
 				temp -= 60;
 				h2++;
 			}
 			train_a[l-2].time = h2*100+temp;
 			train_a[l-2].depart = 0;
 			train_b[l-2].depart = 1;
 		}
 	#ifdef I_DEBUG
 		printf("STRUCT %d %d\n", train_a[l-2].time, train_b[l-2].time);
 	#endif
 	}
 	
 	return(strlen(s));
 	
 }

