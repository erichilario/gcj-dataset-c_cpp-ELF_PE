#include <stdio.h>
 #include <stdlib.h>
 
 struct traintime
 {
 	int starttime;
 	int stoptime;
 	int sid;
 }trfroma[100],trfromb[100];
 
 int compare( const void *a , const void *b ) //order by stoptime
 { 
 	struct traintime *c = (struct traintime *)a; 
 	struct traintime *d = (struct traintime *)b; 
 	if(c->stoptime != d->stoptime ) return c->stoptime  - d->stoptime ; 
 	else return c->starttime  - d->starttime ; 
 } 
 
 
 int main()
 {
 	int cases;
 	int	na,nb;
 	int t;
 	int sa;
 	int i,k,j;
 	int flag;
 	int temp1,temp2,temp3,temp4,temptime,tempsub,tempid,tempflag;
 	int sub,counta,countb;
 
 	freopen("B-small-attempt3.in","r",stdin);
 	freopen("out.txt","w",stdout);
 	scanf("%d",&cases);
 
 	for(k=0;k<cases;k++)
 	{
 		scanf("%d",&t);
 		scanf("%d %d",&na,&nb);
 		for(i=0;i<na;i++)
 		{
 			scanf("%d:%d %d:%d",&temp1,&temp2,&temp3,&temp4 );
 			trfroma[i].starttime=temp1*60+temp2;
 			trfroma[i].stoptime =temp3*60+temp4;
 			trfroma[i].sid =1;
 		}
 		qsort(trfroma,na,sizeof(trfroma[0]),compare);//order trfroma by stoptime
 		for(i=0;i<nb;i++)
 		{
 			scanf("%d:%d %d:%d",&temp1,&temp2,&temp3 ,&temp4);
 			trfromb[i].starttime=temp1*60+temp2;
 			trfromb[i].stoptime =temp3*60+temp4;
 			trfromb[i].sid =2;
 		}
 		qsort(trfromb,nb,sizeof(trfromb[0]),compare);
 
 		flag=1;
 		while(flag)
 		{
 			flag=0;
 			for(i=0;i<na;i++) // to b
 			{
 				if(trfroma[i].sid==0)
 					continue;
 				tempflag=0;
 				temptime=trfroma[i].stoptime +t;
 //				printf("temptime %d\n",temptime);
 				sub=2000;
 				for(j=0;j<nb;j++)
 				{
 					if(trfromb[j].sid!=2)
 						continue;
 //					printf("trfromb[%d]:%d\n",j,trfromb[j].starttime ); 
 					if(temptime<=trfromb[j].starttime )
 					{
 						tempsub=trfromb[j].starttime-temptime ;
 						if(sub>tempsub)
 						{
 							tempid=j;
 							flag=1;
 							sa=2;
 							tempflag=1;
 							sub=tempsub;
 						}
 //						printf("%d \n",j);
 					}
 					
 				}
 				for(j=0;j<na;j++)
 				{
 					if(trfroma[j].sid!=2)
 						continue;
 					if(temptime<=trfroma[j].starttime )
 					{
 						tempsub=trfroma[j].starttime -temptime;
 						if(sub>tempsub)
 						{
 							tempid=j;
 							sa=1;
 							flag=1;
 							tempflag=1;
 							sub=tempsub;
 						}
 					}
 				}
 				
 				if(tempflag==1)
 				{
 					switch(sa)
 					{
 					//delete trfroma[i] from trfroma[] and trfroma2[]
 					case 1:
 						trfroma[tempid].starttime =trfroma[i].starttime ;
 						trfroma[tempid].sid =trfroma[i].sid ;
 						trfroma[i].sid=0;
 						break;
 					case 2:
 						trfromb[tempid].starttime =trfroma[i].starttime ;
 						trfromb[tempid].sid=trfroma[i].sid;
 						trfroma[i].sid=0;
 						break;
 					}
 				}
 //				for(j=0;j<na;j++)
 //					printf("trfroma %d %d %d\n",trfroma[j].starttime ,trfroma[j].stoptime ,trfroma[j].sid );
 //				printf("\n");
 //				for(j=0;j<nb;j++)
 //					printf("trfromb %d %d %d\n",trfromb[j].starttime,trfromb[j].stoptime ,trfromb[j].sid );
 //				printf("\n");
 			}
 			for(i=0;i<nb;i++)
 			{
 				if(trfromb[i].sid==0)
 					continue;
 				tempflag=0;
 				temptime=trfromb[i].stoptime +t;
 				sub=2000;
 				for(j=0;j<na;j++)
 				{
 					if(trfroma[j].sid!=1)
 						continue;
 					if(temptime<=trfroma[j].starttime )
 					{
 						tempsub=trfroma[j].starttime-temptime ;
 						if(sub>tempsub)
 						{
 							tempid=j;
 							flag=1;
 							sa=1;
 							tempflag=1;
 							sub=tempsub;
 						}
 					}					
 				}
 				for(j=0;j<nb;j++)
 				{
 					if(trfromb[j].sid!=1)
 						continue;
 					if(temptime<=trfromb[j].starttime )
 					{
 						tempsub=trfromb[j].starttime -temptime;
 						if(sub>tempsub)
 						{
 							tempid=j;
 							flag=1;
 							sa=2;
 							tempflag=1;
 							sub=tempsub;
 						}
 					}
 				}
 				if(tempflag==1)
 				{
 					//delete trfroma[i] from trfroma[] and trfroma2[]
 					switch(sa)
 					{
 					case 1:
 						trfroma[tempid].starttime =trfromb[i].starttime ;
 						trfroma[tempid].sid=trfromb[i].sid;
 						trfromb[i].sid=0;
 						break;
 					case 2:
 						trfromb[tempid].starttime=trfromb[i].starttime ;
 						trfromb[tempid].sid =trfromb[i].sid ;
 						trfromb[i].sid =0;
 						break;
 					}
 				}
 			}
 		}
 		counta=0;
 		countb=0;
 		for(i=0;i<na;i++)
 		{
 			if(trfroma[i].sid==1)
 				counta++;
 			else if(trfroma[i].sid==2)
 				countb++;
 		}
 		for(i=0;i<nb;i++)
 		{
 			if(trfromb[i].sid==1)
 				counta++;
 			else if(trfromb[i].sid==2)
 				countb++;
 		}
 		printf("Case #%d: %d %d\n",k+1,counta,countb);
 		
 	}
 	
 	return 0;
 }
