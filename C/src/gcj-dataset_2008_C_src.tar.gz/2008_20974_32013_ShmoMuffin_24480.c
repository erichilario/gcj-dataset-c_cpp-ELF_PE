#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 typedef char maxname[102];
 
 int main(const int argc, const char *const argv[])
 {
 	FILE *input;
 	int cases, engine_num, i, j, k, query_num, *count, solution, temp;
 	maxname *engines, *queries;
 	char *ptr;
 	if (argc < 2)
 	{
 		fprintf(stderr, "enter file name as first argument\n");
 		return(1);
 	}
 	if (!(input = fopen(argv[1], "r")))
 	{
 		fprintf(stderr, "enter file name as first argument\n");
 		return(2);
 	}
 	fscanf(input, "%d\n", &cases);
 	for (i=0; i<cases; i++)
 	{
 		fscanf(input, "%d\n", &engine_num);
 		if (!(engines = (maxname *)malloc(engine_num*sizeof(maxname))))
 		{
 			fprintf(stderr, "malloc error\n");
 			return(3);
 		}
 		for (j=0; j<engine_num; j++)
 		{
 			fgets(engines[j], 102, input);
 			if ((ptr = strchr(engines[j], '\n')))
 				*ptr = '\0';
 		}
 		fscanf(input, "%d\n", &query_num);
 		if (!(queries = (maxname *)malloc(query_num*sizeof(maxname))))
 		{
 			fprintf(stderr, "malloc error\n");
 			return(4);
 		}
 		for (j=0; j<query_num; j++)
 		{
 			fgets(queries[j], 102, input);
 			if ((ptr = strchr(queries[j], '\n')))
 				*ptr = '\0';
 		}
 		count = (int *)malloc(sizeof(int)*engine_num);
 		for (j=0; j<engine_num; j++)
 			count[j] = 0;
 
 		solution = 0;
 		for (j=0; j<query_num; j++)
 		{
 			k = 0;
 			while (strcmp(queries[j], engines[k]))
 				k++;
 			count[k]++;
 			temp = k;
 			for (k=0; k<engine_num; k++)
 			{
 				if (count[k]==0)
 					break;
 			}
 			if (k==engine_num)
 			{
 				solution++;
 				for (k=0; k<engine_num; k++)
 					count[k] = 0;
 				count[temp]++;
 			}
 		}
 
 		printf("Case #%d: %d\n", i+1, solution);
 		free(count);
 		free(engines);
 		free(queries);
 	}
 	return(0);
 }

