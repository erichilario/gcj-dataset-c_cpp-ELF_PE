#include <math.h>
 #include <stdio.h>
 
 int main(void)
 {
 	int N, i, k;
 	double P, R, S, a, b, f, g, h, n, r, s, t, x, y, z;
 	scanf("%d", &N);
 	for (k = 1; k <= N; k++)
 	{
 		scanf("%lf %lf %lf %lf %lf", &f, &R, &t, &r, &g);
 		z = 1.0 / (R - t - f), f *= z, R *= z, t *= z, r *= z, g *= z;
 		r += f, g -= f + f;
 		if (r >= 1.0 || g <= 0.0)
 		{
 			P = 1.0;
 		}
 		else
 		{
 			S = M_PI * (R * R) / 4.0;
 			s = S - M_PI * ((R - t - f) * (R - t - f)) / 4.0;
 			for (i = 0; i < 10000000; i++)
 			{
 				x = (double)(i * 2 + 1) / (double)(10000000 * 2);
 				y = sqrt(1.0 - x * x);
 				z = (x + r) / (g + r + r);
 				if ((z - floor(z)) * (g + r + r) >= r + r)
 				{
 					n = floor(y / (g + r + r));
 					a = (g + r + r) * n + r, b = a + g;
 					if (y >= a)
 					{
 						if (y >= b)
 						{
 							h = y - (g * n + (b - a));
 						}
 						else
 						{
 							h = y - (g * n + (y - a));
 						}
 					}
 					else
 					{
 						h = y - g * n;
 					}
 				}
 				else
 				{
 					h = y;
 				}
 				s += h / (double)10000000;
 			}
 			P = s / S;
 		}
 		printf("Case #%d: %.6f\n", k, P);
 	}
 }

