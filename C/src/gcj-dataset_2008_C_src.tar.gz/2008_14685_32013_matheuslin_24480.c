#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 void removeenter(char *s){
 	int i = 0;
 	while(s[i] != '\n' && s[i] != 0) i++;
 	s[i] = 0;
 }
 
 void reset(int vect[103]){
 	int i;
 	for(i = 0; i < 103; i++){
 		vect[i] = 0;
 	}
 }
 
 int howManySwitches(char SE[][103], char Q[][103], int s, int q){
 	int boomvect[103];
 	int boom, ns;
 	int i, j;
 
 	reset(boomvect);
 	ns = 0;
 	j = 0;
 	boom = 0;
 
 	while(j < q){
 		for(i = 0; i < s; i++){
 			if(boomvect[i] == 0 && (strcmp(Q[j], SE[i]) == 0)){
 				boomvect[i] = 1;
 				boom++;
 			}
 		}
 		if(boom == s){
 			ns++;
 			reset(boomvect);
 			boom = 1;
 			for(i = 0; i < s; i++){
 				if(boomvect[i] == 0 && (strcmp(Q[j], SE[i]) == 0)){
 					boomvect[i] = 1;
 				}
 			}
 
 		}
 		j++;
 	}
 
 	return ns;
 }
 
 int main()
 {
 	FILE *in, *out;
 
 	char line[103];
 	int n, i, j, sn;
 	int s, q;
 	char SE[103][103], Q[1003][103];
 
 	printf("input file: ");
 	scanf("%s", &line);
 
 	in = fopen(line, "r");
 	while(!in){
 		printf("missing file. Try again!\ninput file: ");
 		scanf("%s", &line);
 		in = fopen(line, "r");
 	}
 
 	strcat(line, "_out");
 	out = fopen(line, "w");
 
 	fgets(line, 103, in);
 	sscanf(line, "%d", &n);
 
 	i = 1;
 	while(i <= n){
 		fgets(line, 103, in);
 		sscanf(line, "%d", &s);
 		j = 0;
 		while(j < s){
 			fgets(line, 103, in);
 			strcpy(SE[j], line);
 			j++;
 		}
 		fgets(line, 103, in);
 		sscanf(line, "%d", &q);
 		j = 0;
 		while(j < q){
 			fgets(line, 103, in);
 			strcpy(Q[j], line);
 			j++;
 		}
 
 		sn = howManySwitches(SE, Q, s, q);
 		fprintf(out, "Case #%d: %d\n", i, sn);
 
 		i++;
 	}
 	return 0;
 
 }

