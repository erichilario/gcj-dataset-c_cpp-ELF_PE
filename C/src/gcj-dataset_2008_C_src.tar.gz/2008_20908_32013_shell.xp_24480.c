#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int count_switch(int s, char **search_engine, int q, char **query)
 {
 	int i, j, last, count, max_without_switch;
 
 	count = 0;
 	last = max_without_switch = 0;
 	while(1){
 		for(i = 0; i < s; i++){
 			if(strcmp(search_engine[i], query[last])){
 				for(j = last; j < q; j++){
 					if(strcmp(search_engine[i], query[j]) == 0){
 						if(max_without_switch < j){
 							max_without_switch = j;
 						}
 						break;
 					}
 				}
 				if(j == q){
 					return count;
 				}
 			}
 		}
 		last = max_without_switch;
 		count++;
 	}
 }
 
 int geti(FILE *fp, int *n)
 {
 	char buf[256];
 	
 	fgets(buf, sizeof(buf), fp);
 	*n = atoi(buf);
 
 	return *n;
 }
 
 char **salloc(int n, int m)
 {
 	int i;
 	char **ptr;
 
 	ptr = (char **)malloc(sizeof(char *) * (m + 1));
 	for(i = 0; i < m; i++){
 		ptr[i] = (char *)malloc(sizeof(char) * n);
 	}
 	ptr[m] = NULL;
 	return ptr;
 }
 
 void frees(char **ptr)
 {
 	char **p = ptr;
 
 	do{
 		free(*p);
 	} while(*p++);
 
 	free(ptr);
 	return;
 }
 
 void chomp(char *str)
 {
 	char *ptr;
 	
 	ptr = str;
 
 	if(*str == '\0') return;
 	while(*(++ptr) != '\0');
 	while(str <= (--ptr) && (*ptr == '\r' || *ptr == '\n')){
 		*ptr = '\0';
 	}
 	return;
 }
 
 int main()
 {
 	int n, s, q, i, j;
 	char **search_engine, **query;
 	FILE *fp1, *fp2;
 
 	n = s = q = 0;
 
 	search_engine = salloc(101, 100);
 	query = salloc(101, 1000);
 
 	fp1 = fopen("A-large.in", "r");
 	fp2 = fopen("output.txt", "w");
 
 	geti(fp1, &n);
 	for(i = 0; i < n; i++){
 		geti(fp1, &s);
 		for(j = 0; j < s; j++){
 			fgets(search_engine[j], 101, fp1);
 			chomp(search_engine[j]);
 		}
 		geti(fp1, &q);
 		for(j = 0; j < q; j++){
 			fgets(query[j], 101, fp1);
 			chomp(query[j]);
 		}
 
 		fprintf(fp2, "Case #%d: %d\n", i + 1, count_switch(s, search_engine, q, query));
 	}
 
 	frees(search_engine);
 	frees(query);
 	return 0;
 }
