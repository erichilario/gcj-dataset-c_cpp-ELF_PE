#include<stdio.h>
 #include<stdlib.h>
 //#include<alloc.h>
 
 #define len 102
 #define max 10000
 
 void findoccur(char **si,int s,char **qu,int q,int *x,int idx)
 {
  int i,j;
  for(i=0;i<s;i++)
    *(x+i)=max;
    for(i=0;i<s;i++)
               for(j=idx;j<q;j++)                      
                   if(strcmp(*(si+i),*(qu+j))==0)
                            {
                            *(x+i)=j;
                            break;
                            } 
      
 }    
 
 int findmax(int *x,int s)
 {
     int i,j=0,val=*x;
     for(i=0;i<s;i++)
     if(val<*(x+i))
     val=*(x+i);
     return val;
 }    
 
 int main()
 {
   char buff[len];
   int n,s,q,i,j,count,cases,*x;
   char **si,**qu;
   FILE *file=NULL;  /* declare a FILE pointer  */
   FILE *file1=NULL;
   file = fopen("d:\input.in","r");
   file1 = fopen("d:\output.txt","w"); 
   /* open a text file for reading */
      printf("File opened successfully. Contents:\n\n");
         fgets(buff,len,file);
         n=atoi(buff);
         printf("%d\n",n);
         cases=1;
         while(cases<=n)
         {        j=0;count=-1;
               s=atoi(fgets(buff,len,file));
               printf("%d\n",s);
               si=malloc(sizeof (char *) * s);
               x= malloc(sizeof (int) * s);
               for(i=0;i<s;i++)
               {             
                             *(si+i)=malloc(sizeof (char *) * len);
                             fgets(*(si+i),102,file);
                             printf("%s\n",*(si+i));
                             *(x+i)=-1;
               }
               
               q=atoi(fgets(buff,102,file));
               printf("%d\n",q);
               qu=malloc(sizeof (char *) * q); 
               for(i=0;i<q;i++)
               {             
                             *(qu+i)=malloc(sizeof (char *) * len);
                             fgets(*(qu+i),102,file);
                             printf("%s\n",*(qu+i));
               }  
               while(j<=q)
                        {
                             findoccur(si,s,qu,q,x,j);
                             j= findmax(x,s);
                             printf("j=%d\n",j);
                             count++;
                        }
                            
              fprintf(file1,"Case #%d: %d\n",cases++,count);
              free(x);
              for(i=0;i<s;i++)
               {             
                             free(*(si+i));
               }
               free(si);
              for(i=0;i<q;i++)
               {             
                             free(*(qu+i));
               }      
               free(qu);    
         }
         
     printf("\n\nNow closing file...\n");
     fclose(file);
    fclose(file1); 
     getchar();
    
     
     return 0;
 }

