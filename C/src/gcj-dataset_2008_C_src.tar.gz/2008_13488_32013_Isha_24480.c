#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 	int main(){
 	int nr, te;
 
 	char ss[100][101], qs[1000][101];
 	int s, q, sn, qn, sc[100] = {0, };
 	char st[10], qt[10], tet[10];
 	int tt, swt;
 
 
 	//scanf("%d", &te);
 	gets(tet);
 	te = atoi(tet);
 
 	for ( nr = 0; nr < te; nr++ )
 	{
 		printf("Case #%d: ", nr+1);
 
 		//scanf("%d", &sn);
 		gets(st);
 		sn = atoi(st);
 		for ( s = 0 ; s < sn ; s++ ) 
 		{
 			gets(ss[s]);		
 		}
 
 
 		//scanf("%d", &qn);
 		gets(qt);
 		qn = atoi(qt);
 		for ( q = 0 ; q < qn ; q++ )
 		{
 			gets(qs[q]);
 		}
 
 		tt = 0;
 		swt = 0;
 		memset(sc, 0, sizeof(sc));
 
 		for ( q = qn - 1 ; q >= 0 ; q-- )
 		{
 			for ( s = 0 ; s < sn ; s++ )
 			{
 				if ( strcmp(qs[q], ss[s]) == 0 ) {
 					if ( sc[s] == 0 ) {
 						sc[s] = 1;
 						tt++;
 						if ( tt == sn ) {
 							swt++;
 							memset(sc, 0, sizeof(sc));
 							sc[s] = 1;
 							tt = 1;
 						}
 					}
 					break;
 				}
 			}
 		}
 		
 		printf("%d\n", swt);
 
 	}
 	return 0;
 }

