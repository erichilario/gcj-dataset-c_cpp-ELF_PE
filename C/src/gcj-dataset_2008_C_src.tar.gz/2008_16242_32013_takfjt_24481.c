#include <stdio.h>
 
 #include <limits.h>
 
 enum event {
     START_FROM_A,
     START_FROM_B,
     READY_AT_A,
     READY_AT_B,
 };
 
 struct time_table {
     int time;
     enum event event;
     int data;
     struct time_table *next;
 };
 
 int
 s2a(char *t)
 {
     return ((t[0] - '0') * 10 + (t[1] - '0')) * 60
         + (t[3] - '0') * 10 + (t[4] - '0');
 }
 
 int
 main()
 {
     struct time_table *t_start = NULL, *t_tmp, *t, **t_prev, *t2;
     
     int turn;
     int na, nb;
     int ra, rb;
     int ua, ub;
 
     int line, l;
     int i;
     char s1[6], s2[6];
 
     scanf("%d", &line);
 
     for (l = 0; l < line; l++) {
         ra = rb = 0;
         ua = ub = 0;
         scanf("%d", &turn);
         scanf("%d %d", &na, &nb);
 
         for (i = 0; i < na; i++) {
             t_tmp = malloc(sizeof(*t_tmp));
             //printf("malloc:%p\n", t_tmp);
             memset(t_tmp, 0, sizeof(*t_tmp));
             scanf("%s %s", s1, s2);
             t_tmp->time = s2a(s1);
             t_tmp->data = s2a(s2) + turn;
             t_tmp->event = START_FROM_A;
 
             if (t_start == NULL) t_start = t_tmp;
             else {
                 for (t = t_start, t_prev = &t_start; t; t_prev = &t->next, t = t->next) {
                     if (t->time > t_tmp->time) {
                         *t_prev = t_tmp;
                         t_tmp->next = t;
                         break;
                     }
                     if (t->next == NULL) {
                         t->next = t_tmp;
                         t_tmp->next = NULL;
                         break;
                     }
                 }
             }
         }
         for (i = 0; i < nb; i++) {
             t_tmp = malloc(sizeof(*t_tmp));
             //printf("malloc:%p\n", t_tmp);
             memset(t_tmp, 0, sizeof(*t_tmp));
             scanf("%s %s", s1, s2);
             t_tmp->time = s2a(s1);
             t_tmp->data = s2a(s2) + turn;
             t_tmp->event = START_FROM_B;
 
             if (t_start == NULL) t_start = t_tmp;
             else {
                 for (t = t_start, t_prev = &t_start; t; t_prev = &t->next, t = t->next) {
                     if (t->time > t_tmp->time) {
                         *t_prev = t_tmp;
                         t_tmp->next = t;
                         break;
                     }
                     if (t->next == NULL) {
                         t->next = t_tmp;
                         t_tmp->next = NULL;
                         break;
                     }
                 }
             }
         }
 
         // go!
 
         t = t_start;
         t_start = NULL;
         while (t) {
             //fprintf(stderr, "(%d %d %d) (%d %d %d)\n", na, ra, ua, nb, rb, ub);
             fprintf(stderr, "%02d:%02d %02d:%02d %s\n",
                     t->time / 60,
                     t->time % 60,
                     t->data / 60,
                     t->data % 60,
                     t->event == START_FROM_A ? "A->B" :
                     t->event == START_FROM_B ? "B->A" :
                     t->event == READY_AT_A ? "Ready A" :
                     t->event == READY_AT_B ? "Ready B" : "-");
 
             switch (t->event) {
             case START_FROM_A:
                 if (ra > 0) ra--;
                 else {
                     na--;
                     ua++;
                 }
                 t->event = READY_AT_B;
                 t->time = t->data;
                 t->data = 0;
                 break;
             case START_FROM_B:
                 if (rb > 0) rb--;
                 else {
                     nb--;
                     ub++;
                 }
                 t->event = READY_AT_A;
                 t->time = t->data;
                 t->data = 0;
                 break;
             case READY_AT_A:
                 t->time = -1;
                 ra++;
                 break;
             case READY_AT_B:
                 t->time = -1;
                 rb++;
                 break;
             }
 
             t_tmp = t;
             t = t->next;
             
             if (t_tmp->time > 0) {
                 for (t2 = t, t_prev = &t; t2; t_prev = &t2->next, t2 = t2->next) {
                     if (t2->time >= t_tmp->time) {
                         *t_prev = t_tmp;
                         t_tmp->next = t2;
                         break;
                     }
                     if (t2->next == NULL) {
                         t2->next = t_tmp;
                         t_tmp->next = NULL;
                         break;
                     }
                 }
             } else {
                 //printf("%p\n", t_tmp);
                 printf("");
                 free(t_tmp);
             }
         }
         fprintf(stderr, "%d / %d\n", na, nb);
         printf("Case #%d: %d %d\n", l + 1, ua, ub);
 
 
     }
 
     return 0;
 }
 
 
 
 

