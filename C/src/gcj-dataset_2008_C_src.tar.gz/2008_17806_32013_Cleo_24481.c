#include <stdio.h>
 #include <string.h>
 #define NMAX 101
 #define HMAX 1439 //23:59
 
 int n, t, na, nb;
 FILE *fi, *fo;
 
 struct timetable {
        int departure, arrival;
 }listA[NMAX], listB[NMAX];
 
 int minutes (int h, int m) { return h*60+m;}
 
 void sort (struct timetable listX[], int nx)
 {
      int i, j, pos;
      struct timetable aux;
      
      for (i = 0; i < nx; ++i)
      {
          pos = i;
          for (j = i + 1; j < nx; ++j)
              if (listX[pos].departure == listX[j].departure && listX[pos].arrival > listX[j].arrival) pos = j;
              else
                  if (listX[pos].departure > listX[j].departure) pos = j;
          //swap
          aux = listX[i];
          listX[i] = listX[pos];
          listX[pos] = aux;
      }     
 }
 
 int minAB (int ia, int ib) //true when A is min
 {
      if (ia == na) return 0;
      if (ib == nb) return 1;     
      if (listA[ia].departure>listB[ib].departure) return 0;
      if (listA[ia].departure<listB[ib].departure) return 1;
      if (listA[ia].arrival>listB[ib].arrival) return 0;
      return 1;
 }
 
 int existsTrain (int uz[], int maxDeparture)
 {
      int i;
      for (i=maxDeparture; i>=0; --i)
      {
          if (uz[i]>0)
          {
             uz[i]--;
             return 1;//found
          }    
      }   
      return 0;//not found
 }
 void solve (int nCase)
 {
      int ia, ib;
      int resA, resB;
      int arrival;
      int uzA[HMAX+1], uzB[HMAX+1];
      
      for (ia = 0; ia < HMAX ; ++ia) uzA[ia] = uzB[ia] = 0;
      
      resA = resB = 0;
      ia = ib = 0;
      while (ia<na || ib<nb)
      {
          if (minAB(ia, ib))
          {
             if (!existsTrain(uzA, listA[ia].departure)) resA++;
             arrival = listA[ia].arrival + t;
             if (arrival <= HMAX) uzB[arrival]++;
             ia++;
          }
          else
          {
             if (!existsTrain(uzB, listB[ib].departure)) resB++;
             arrival = listB[ib].arrival + t;
             if (arrival <= HMAX) uzA[arrival]++;
             ib++;
          }
      }
      fprintf(fo, "Case #%d: %d %d\n", nCase, resA, resB);
 }
 
 int main()
 {
     int i, k;
     int h, m;
 	fi = fopen ("B-large.in", "r");
 	fo = fopen ("output", "w");
 	fscanf(fi, "%d", &n);
 	for (i = 1; i <= n; ++i)
 	{
 		fscanf(fi, "%d %d %d", &t, &na, &nb);
 		for (k = 0; k < na; ++k)
 		{
 			fscanf(fi, "%d:%d", &h, &m);
 			listA[k].departure = minutes(h, m);
 			fscanf(fi, "%d:%d", &h, &m);
 			listA[k].arrival = minutes(h, m);	
 		}
 		sort (listA, na);
 		
 		for (k = 0; k < nb; ++k)
 		{
 			fscanf(fi, "%d:%d", &h, &m);
 			listB[k].departure = minutes(h, m);
 			fscanf(fi, "%d:%d", &h, &m);
 			listB[k].arrival = minutes(h, m);
 		}
 		sort (listB, nb);
 	
 		solve(i);
 	}
 	fclose(fi);
 	fclose(fo);
 	return 0;
 }

