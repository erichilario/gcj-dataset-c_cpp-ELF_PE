#include <stdio.h>
 #include <string.h>
 int main ()
 {
     FILE *arqent, *arqsai;
     char strlista[11][100];
     char strval[101][100];
     int wpos, contador, a, b, c, wposatu, h, nocor, nbuscador, nlista, x, wposreg, wposant;  
     arqsai = fopen ("A-large.out", "w");
     arqent = fopen ("A-large.in", "r");
     fscanf(arqent, "%d", &nocor);
     printf("nocor - %d\n", nocor); 
     for (a=1; a <= nocor; a++)
     {
         fscanf(arqent, "%d", &nbuscador);
         printf("nbuscador - %d\n", nbuscador); 
         for (b=0; b <= nbuscador; b++ )
         {
             fgets (strlista[b], 100, arqent);
             printf("Entrada - %s\n", strlista[b]); 
         }
         fscanf(arqent, "%d", &nlista);
         printf("nlista - %d\n", nlista); 
         for (c=0; c <= nlista; c++ )
         {
             fgets (strval[c], 100, arqent);
             printf("Lista - %s\n", strval[c]);
         }
         fprintf(arqsai, "Case #%d: ",a);
         contador=0;
         if (nlista>0)
         {   
            for (wpos=1; wpos<nlista;)  
            {
                wposant=0;
                for (b=1; b <= nbuscador; b++)
                {
                    c=wpos; 
                    while (c <= nlista)
                    {
                        printf("Buscador = %s\n", strlista[b]); 
                        printf("String = %s\n", strval[c]); 
                        printf("c = %d\n", c); 
                        printf("b = %d\n", b); 
                        printf("wposreg = %d\n", wposreg); 
                        if (strcmp(strlista[b],strval[c])==0)
                        {
                           wposreg=c;
                           c=nlista+1;
                        }    
                        else
                        {  
                           if (c==nlista)
                           {
                              wposreg=nlista+1;
                              c=nlista+1;
                           }
                           else
                           {  
                              c++;
                           }    
                        }
                        printf("c = %d\n", c); 
                        printf("wposreg = %d\n", wposreg); 
                    }        
                if (wposreg > wposant)
                   wposatu=wposreg;
                else
                   wposatu=wposant; 
                wposant=wposatu;
                wposreg=0;
                }             
                wpos=wposatu;
                contador++;
                printf("Contador - %d\n", contador); 
            }
            if (wposatu==nlista)
                fprintf(arqsai, "%d\n",contador);
            else
                fprintf(arqsai, "%d\n",contador-1);
         }
         else
            fprintf(arqsai, "%d\n",contador);
     }    
     fclose(arqent);
     fclose(arqsai);
     system("pause");
     return(0);
 }

