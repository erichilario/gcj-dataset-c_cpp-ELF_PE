#include <stdio.h>
 int main()
 {
     int name[10][105];
     int order[10];
     int order2[150][2];
     int querly[101];
     int querly2[101];
     int dp[101][10];
     int mc;
     int data_number,name_number,querly_number,q,w,e,r,m1,m2,m3;
     FILE *in,*out;
     out=fopen("a.out","w");
     in=fopen("a.in","r");
     fscanf(in,"%d",&data_number);
   
     for(q=0;q<data_number;q++)
     {
 
         fscanf(in,"%d\n",&name_number);
         for(w=0;w<name_number;w++)
             for(e=0;e<=100;e++)
                 name[w][e]=3274;
         for (w=0;w<name_number;w++)
         {
             fscanf(in,"%c",&mc);
             m1=0;
             while(mc!='\n')
             {
 				name[w][m1++]=mc;
     			fscanf(in,"%c",&mc);
 			}
             
             
             
             
             
             
             
             
             
             
             
            
          }
                   
         for(w=0;w<=name_number;w++)
             order[w]=w;
         
         for(w=0;w<name_number;w++)
            for(e=0;e<name_number-1;e++)
             if (name[order[e]][0]>name[order[e+1]][0])
             {
                 m1=order[e];
                 order[e]=order[e+1];
                 order[e+1]=m1;
             }
         name[name_number][0]=999;
         m1=1;
         for(w=1;w<=name_number;w++)
         if (name[order[w-1]][0]==name[order[w]][0]) 
         m1++;
         else
         {
             order2[name[order[w-1]][0]][0]=w-m1;
             order2[name[order[w-1]][0]][1]=w-1;
         }
 	    fscanf(in,"%d\n",&querly_number);
 	 
         for(w=0;w<querly_number;w++)
         {
             m1=0;
           
           for(e=0;e<=100;)
            querly[e++]=3274;  
 		   fscanf(in,"%c",&mc);
           
            while(mc!='\n')    
            {
 
                querly[m1++]=mc;
 //        	   printf("%c1",mc);
                fscanf(in,"%c",&mc);
            }
 //           printf("\n");
        
             for(e=order2[querly[0]][0];e<=order2[querly[0]][1];e++)
             {
 				
                 m1=0;
                 for(r=0;r<=15;r++)
                 {
 //				   printf("%c %c %d\n",name[order[e]][r],querly[r],r);
              	   if (name[order[e]][r]!=querly[r])
              	      m1=1;
                 }
                	   
                	   
 				if (m1==0) 
                 {
                  querly2[w]=e;
                  break;
                 }
 
             }
             
             // querly2Ż 
         }
         for(w=0;w<name_number;w++)
         dp[0][w]=0;
        
         
         
         dp[0][querly2[0]]=999;
        
         for(w=1;w<querly_number;w++)
         
             for(e=0;e<name_number;e++)
                 if(querly2[w]!=e)
                 {
                     m1=999;
                     for(r=0;r<name_number;r++)
                     {
                      if((r==e)&& (m1>dp[w-1][r]))
                      m1=dp[w-1][r];
                      if((r!=e)&&(m1>dp[w-1][r]+1))
                      m1=dp[w-1][r]+1;
                     }
                     dp[w][e]=m1;
                 }    
                 else
                 dp[w][e]=999;
         
 	
      
 
         	 
         m1=999;
         for(w=0;w<name_number;w++)
         if (dp[querly_number-1][w]<m1)
          m1=dp[querly_number-1][w];
         fprintf(out,"Case #%d: %d\n",q+1,m1);
 
       
       
 	
   }    
 
   
 }      
                     
         
 
             
             
             
 
  
 
 

