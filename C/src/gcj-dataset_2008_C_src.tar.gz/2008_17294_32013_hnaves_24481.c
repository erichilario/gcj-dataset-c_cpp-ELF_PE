#include <stdio.h>
 #include <stdlib.h>
 
 #define MAX_TRIPS 128
 
 static int NA, NB, T;
 static int solA, solB;
 
 static int A_start[MAX_TRIPS];
 static int A_end[MAX_TRIPS];
 static int B_start[MAX_TRIPS];
 static int B_end[MAX_TRIPS];
 
 int cmp_int (const void *ptr1, const void *ptr2)
 {
   int *i1 = (int *) ptr1;
   int *i2 = (int *) ptr2;
   return (*i1) - (*i2);
 }
 
 void solve (void)
 {
   int t, min, c, i1, i2;
 
   qsort (A_start, NA, sizeof (int), &cmp_int);
   qsort (A_end, NA, sizeof (int), &cmp_int);
   qsort (B_start, NB, sizeof (int), &cmp_int);
   qsort (B_end, NB, sizeof (int), &cmp_int);
 
   c = 0;
   i1 = i2 = 0;
   min = 0;
   for(t = 0; t < 24*60; t++) {
     while (A_start[i1] == t) {
       i1++; c--;
     }
     while (B_end[i2] == t) {
       i2++; c++;
     }
     if (min > c) min = c;
   }
   solA = -min;
 
   c = 0;
   i1 = i2 = 0;
   min = 0;
   for(t = 0; t < 24*60; t++) {
     while (B_start[i1] == t) {
       i1++; c--;
     }
     while (A_end[i2] == t) {
       i2++; c++;
     }
     if (min > c) min = c;
   }
   solB = -min;
 }
 
 
 
 int main (int argc, char **argv)
 {
   int N, t;
   int i, h1, m1, h2, m2;
   scanf (" %d ", &N);
   for(t = 1; t <= N; t++) {
     scanf (" %d ", &T);
     scanf (" %d %d ", &NA, &NB);
     for (i = 0; i < NA; i++) {
       scanf (" %d:%d %d:%d ", &h1, &m1, &h2, &m2);
       A_start[i] = 60 * h1 + m1;
       A_end[i] = 60 * h2 + m2 + T;
     }
     A_start[NA] = A_end[NA] = -1;
 
     for (i = 0; i < NB; i++) {
       scanf (" %d:%d %d:%d ", &h1, &m1, &h2, &m2);
       B_start[i] = 60 * h1 + m1;
       B_end[i] = 60 * h2 + m2 + T;
     }
     B_start[NB] = B_end[NB] = -1;
 
     solve ();
     printf ("Case #%d: %d %d\n", t, solA, solB);
   }
   return 0;
 }

