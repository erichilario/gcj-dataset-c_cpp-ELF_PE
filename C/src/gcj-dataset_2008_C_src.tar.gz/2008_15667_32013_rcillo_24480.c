/* Este programa resolve o problema da rodada de qualificação do GCJ */
 /* para usa-lo basta passar como primeiro argumento o nome do arquivo de entrada */
 /* o segundo argumento é o nome do arquivo de saida */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define MAX_LEN 102
 
 int search(char * key, char ** list, int p, int q) {
   int r;
   int m;
   while (1) {
     if (p == q) return p;
     m = (q + p)/2;
     r = strcmp(key, list[m]);
     if (r == 0) return m;
     if (r < 0) q = m -1;
     else p = m +1;
   }
   return -1;
 }
 
 
 static int cmpstringp(const void *p1, const void *p2) {
   return strcmp(* (char * const *) p1, * (char * const *) p2);
 }
 
 /* a cada search_engines_num consultas distintas, é necessário um switch */
 /* o que este programa faz é ler as consultas e incrementar distintic_querys */
 /* a fim de saber quantos switchs são necessários */
 int main(int argc, char * argv[]) {
 
   int i;			/* caso em analise */
   int j;
   int k;
   int q;
   int test_cases;
   int search_engines_num;
   char ** search_engines_list;
   int query_repetition_counter[100];
   int querys_num;
   char * query = (char*)malloc(101 * sizeof(char));
   int distinct_querys = 0;
   int minimum_switchs = 0;
   FILE * input_file;
   FILE * output_file;
 
   search_engines_list = (char**)malloc(100 * sizeof *search_engines_list);
   for (j = 0; j < 100; j++) 
     search_engines_list[j] = (char*)malloc(MAX_LEN * sizeof(char));
   
   input_file = fopen(argv[1], "r");
   output_file = fopen(argv[2], "w");
   fscanf(input_file, "%d", &test_cases);
   fgetc(input_file);
   for (i = 1; i <= test_cases; i++) {
     
     /* this chunk of code treats the search engines names */
     fscanf(input_file, "%d", &search_engines_num);
     fgetc(input_file);		/* newline */
     for (j = 0; j < search_engines_num; j++) {
       fgets(search_engines_list[j], MAX_LEN, input_file);
       query_repetition_counter[j] = 0;
     }
     qsort(search_engines_list, search_engines_num, sizeof(char*), cmpstringp);
 
     /* this chunck of code looks at the query */
     fscanf(input_file, "%d", &querys_num);
     fgetc(input_file);		/* newline */
     for (j = 0; j < querys_num; j++) {
       fgets(query, MAX_LEN, input_file);
       q = search(query, search_engines_list, 0, search_engines_num-1);
       if (!query_repetition_counter[q]) {
 	query_repetition_counter[q]++;
 	distinct_querys++;
 	if (distinct_querys == search_engines_num) {
 	  minimum_switchs++;
 	  for (k = 0; k < search_engines_num; k++)
 	    query_repetition_counter[k] = 0;
 	  query_repetition_counter[q] = 1;
 	  distinct_querys = 1;
 	}
       }
     }
     fprintf(output_file, "Case #%d: %d\n", i, minimum_switchs);
     minimum_switchs = 0;
     distinct_querys = 0;
     
   }
   fclose(input_file);
   fclose(output_file);
   for (j = 0; j < 100; j++) 
     free(search_engines_list[j]);
 
   return 0;
 }

