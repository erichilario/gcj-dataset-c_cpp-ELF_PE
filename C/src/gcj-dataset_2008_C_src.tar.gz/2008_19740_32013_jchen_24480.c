#include <stdio.h>
 #include <string.h>
 
 char engines[100][256];
 char tables[100];
 char line[100];
 char query[256];
 
 int N,S,Q;
 
 void initTables()
 {
 	int j;
 	for(j=0;j<S;j++)
 		tables[j]= 1;
 }
 
 char full()
 {
 	int j;
 	for(j=0;j<S;j++)
 		if(tables[j])return 0;
 	return 1;
 }
 
 int main(void)
 {
 	int index;
 	int i,j,result;
 	scanf("%d\n", &N);
 	for(index=1;index<=N;index++)
 	{
 		scanf("%d\n", &S);
 		for(i=0;i<S;i++)
 			gets(engines[i]);
 		scanf("%d\n", &Q);
 		result= 0;
 		initTables();
 		for(i=0;i<Q;i++)
 		{
 			gets(query);
 			for(j=0;j<S;j++)
 				if(strcmp(query, engines[j])==0)break;
 			tables[j]= 0;
 			
 			if(full())
 			{
 				initTables();
 				tables[j]= 0;
 				result++;
 			}
 		}
 			
 		printf("Case #%d: %d\n",index, result);
 	}
 	
 	return 0;
 }

