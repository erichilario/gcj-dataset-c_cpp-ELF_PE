#include <stdio.h>
 #include <stdlib.h>
 
 // #define DEBUGINPUT
 // #define DEBUGSCHEDULE
 
 int t, na, nb;
 
 #define A 0
 #define B 1
 
 typedef struct sTrip {
   int from;
   char dep[6];
   char arr[6];
   int  tdep;
   int  tarr;
   int  sched;
 } Trip;
 
 typedef int (*compfn)(const void*, const void*);
 
 Trip trip[2*100+1];
 int ntrips;
 
 int compare(Trip *elem1, Trip *elem2)
 {
    if ( elem1->tdep < elem2->tdep)
       return -1;
 
    else if (elem1->tdep > elem2->tdep)
       return 1;
 
    else
       if (elem1->tarr < elem1->tarr)
         return -1;
       else if (elem1->tarr > elem1->tarr)
         return 1;
       else
         return 0;
 }
 
 int solve(int c)
 {
   char dep[6], arr[6];
   int i, j, k, s[2], prev, found;
 
   scanf("%d\n", &t);
   scanf("%d %d\n", &na, &nb);
 
   ntrips = 0;
   for(i = 0; i < na + nb; i++)
   {
     trip[ntrips].from = (i<na)?A:B;
     trip[ntrips].sched = 0;
     scanf("%s %s\n", trip[ntrips].dep, trip[ntrips].arr);
     trip[ntrips].tdep = atoi(trip[ntrips].dep)*60 + atoi(&trip[ntrips].dep[3]);
     trip[ntrips].tarr = atoi(trip[ntrips].arr)*60 + atoi(&trip[ntrips].arr[3]);
     ntrips++;
   }
 
   qsort((void *)&trip, ntrips, sizeof(Trip), (compfn)compare );
 
 #ifdef DEBUGINPUT
   printf("t=%d na=%d nb=%d\n", t, na, nb);
 
   for(i = 0; i < ntrips; i++)
   {
     printf("trip %3d: from=%s dep=%s arr=%s tdep=%d tarr=%d\n", i+1, (trip[i].from==A)?"A":"B", trip[i].dep, trip[i].arr, trip[i].tdep, trip[i].tarr);
   }
 
 #endif
 
   s[A] = s[B] = 0; // initialize number of trains that start from A and B
 
   for (k = 0; k < ntrips; k++)
   {
     i = k;
     prev = -1; // no previous trip
 
     do
     {
       found = 0;
 
       if (!trip[i].sched)
       {
         trip[i].sched = 1; 
 
         if (prev == -1) s[trip[i].from]++;
 
 #ifdef DEBUGSCHEDULE
         printf("trip %3d: prev=%3d from=%s dep=%s arr=%s tdep=%d tarr=%d s[%s]=%d\n", i+1, prev, (trip[i].from==A)?"A":"B", trip[i].dep, trip[i].arr, trip[i].tdep, trip[i].tarr, (trip[i].from==A)?"A":"B", s[trip[i].from]);
 #endif
 
         // find next trip with same train
         for (j = i+1; j < ntrips; j++)
           if (!trip[j].sched)
             if (trip[j].from == !trip[i].from)
               if (trip[j].tdep >= trip[i].tarr + t)
               {
                 found = 1; prev = i; i = j; break;
               }
       }
     } while (found);
   } 
 
   printf("Case #%d: %d %d\n", c, s[A], s[B]);
 }
 
 int main (int argc, char **argv)
 {
   int i, n;
   scanf("%d\n", &n);
   for (i = 1; i <= n; i++) solve(i);
 }
 

