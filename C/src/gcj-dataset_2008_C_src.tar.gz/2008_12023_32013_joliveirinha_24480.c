#include <stdio.h>
 #include <string.h>
 
 #define MAXS 101
 #define MAXQ 1002
 #define MAXSTR 1000
 
 int n, s, q;
 int data[MAXS][MAXQ];
 char engines[MAXS][MAXSTR];
 char querys[MAXQ][MAXSTR];
 
 int solve(int a, int b) {
 	int tmp = strcmp(engines[a], querys[b]);
 	int i, min=q, result;
 
 	if (b==q)
 		return 0;
 
 	if (data[a][b] != -1)
 		return data[a][b];
 
 	if (tmp==0) {
 		for (i=0;i<s;i++)
 			if (i!=a) {
 				tmp = 1+solve(i, b+1);
 				if (tmp < min)
 					min = tmp;
 			}
 
 		result = min;
 	} else 
 		result = solve(a, b+1);
 
 	return data[a][b] = result;
 }
 
 int main(void) {
 	int i, j;
 
 	scanf("%d", &n);
 	for (i=0;i<n;i++) {
 		memset(data, -1,sizeof(data));
 
 		scanf("%d\n", &s);
 		for (j=0;j<s;j++) 
 			fgets(engines[j], sizeof(engines[j]), stdin);
 
 		scanf("%d\n", &q);
 		for (j=0;j<q;j++)
 			fgets(querys[j], sizeof(querys[j]), stdin);
 	
 		if (q==0) {
 			printf("Case #%d: %d\n", i+1, 0);
 			continue;
 		}
 
 		int min = q, t;
 		for (j=0;j<s;j++) {
 			t = solve(j, 0);
 			if (t<min)
 				min = t;
 		}
 	
 		printf("Case #%d: %d\n", i+1, min);
 	}
 
 	return 0;
 }
 

