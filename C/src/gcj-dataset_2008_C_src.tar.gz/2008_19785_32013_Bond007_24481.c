#include<stdio.h>
 #include<conio.h>
 #include<alloc.h>
 
 struct table
 {
 int depth,deptm;
 int arrth,arrtm;
 int ava,flag;
 };
 
 int comp(struct table,struct table);
 
 void main()
 {
  int i,j,k,l,n;
  int na,nb,t;
  int h,m,noa,nob,no;
  char c;
  struct table tshed[300];
  struct table tra[450];
  struct table temp;
 
  FILE *fp,*fp1;
  clrscr();
  fp=fopen("smallt2.txt","r");
  fscanf(fp,"%d",&n);
  printf("%d\n",n);
  fp1=fopen("small2op.txt","w");
  for(i=0;i<n;i++)
  {
   noa=0;
   nob=0;
   no=0;
   fscanf(fp,"%d %d %d",&t,&na,&nb);
  // printf("NA=%d  NB=%d  t=%d",na,nb,t);
   //tshed=(struct table *)malloc(sizeof(struct table)*(na+nb));
   for(j=0;j<na+nb;j++)
   {
    fscanf(fp,"%d%c%d",&temp.depth,&c,&temp.deptm);
    fscanf(fp," %d%c%d",&temp.arrth,&c,&temp.arrtm);
    if(j<na)
    temp.flag=0;
    else
    temp.flag=1;
    //printf("\nDeparture time %d%c%d  -  Arrival time %d%c%d\n"
    //,temp.depth,c,temp.deptm,temp.arrth,c,temp.arrtm);
    //getch();
    if(j==0)
    tshed[j]=temp;
    else
    {
     for(k=0;k<j;k++)
     {
       if(comp(temp,tshed[k])==1)
       {
 	for(l=j;l>k;l--)
 	tshed[l]=tshed[l-1];
 	break;
       }
     }
     tshed[k]=temp;
   }
  }
 
   for(j=0;j<na+nb;j++)
   {
    for(k=0;k<no;k++)
    {
      if(tra[k].flag==tshed[j].flag)
      {
       if(comp(tra[k],tshed[j])==1)
       {
 	 if(tshed[j].arrtm+t>=60)
 	 {
 	   tra[k].depth=tshed[j].arrth+1;
 	   tra[k].deptm=tshed[j].arrtm+t-60;
 	 }
 	  else
 	  {
 	   tra[k].depth=tshed[j].arrth;
 	   tra[k].deptm=tshed[j].arrtm+t;
 	  }
 	  tra[k].arrth=tshed[j].depth;
 	  tra[k].arrtm=tshed[j].deptm;
 	  if(tra[k].flag==0)
 	      tra[k].flag=1;
 	   else
 	    tra[k].flag=0;
 	  break;
       }
 
 
      }
    }
    if(k==no)
    {
       if(tshed[j].arrtm+t>=60)
        {
 	tra[no].depth=tshed[j].arrth+1;
 	tra[no].deptm=tshed[j].arrtm+t-60;
 	}
        else
        {
 	tra[no].depth=tshed[j].arrth;
 	tra[no].deptm=tshed[j].arrtm+t;
        }
       if(tshed[j].flag==0)
       {
        tra[no].arrth=tshed[j].depth;
        tra[no].arrtm=tshed[j].deptm;
        tra[no].flag=1;
        noa++;
        no++;
       }
       else
       {
       tra[no].arrth=tshed[j].depth;
       tra[no].arrtm=tshed[j].deptm;
       tra[no].flag=0;
       no++;
       nob++;
      }
    }
 
   }
   //////////////////////////
 // printf("\n\n no of trains from A : %d",noa);
 // printf("\n\n no of trains from B : %d",nob);
  fprintf(fp1,"Case #%d: %d %d\n",i+1,noa,nob);
 // getch();
  //clrscr();
  }
  fclose(fp);
  fclose(fp1);
 }
 
 int comp(struct table temp1,struct table temp2)
 {
 int flag=0;
 if(temp1.depth<temp2.depth)
 flag=1;
 else if(temp1.depth==temp2.depth)
 {
  if(temp1.deptm<=temp2.deptm)
  flag=1;
  /*else if(temp1.deptm==temp2.deptm)
  {
    if(temp1.flag==0)
    flag=1;
  } */
 }
 return flag;
 }
