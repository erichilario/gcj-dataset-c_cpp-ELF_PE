#include <stdio.h>
 #include <math.h>
 #include <string.h>
 
 #define BUFF_SIZE 200
 
 typedef struct SEARCH_ENGINE
 {
 	char name[BUFF_SIZE];
 	unsigned char used;
 }SEARCH_ENGINE;
 
 void zeroEngines (SEARCH_ENGINE * sEngines, int qtdEngines)
 {
 	int i;
 	for (i=0;i<qtdEngines;i++)
 		sEngines[i].used = 0;
 }
 
 SEARCH_ENGINE * findEngine (SEARCH_ENGINE * sEngines, int qtdEngines, char * name)
 {
 	int i;
 
 	for (i=0;i<qtdEngines; i++)
 		if (strcmp (sEngines[i].name, name) == 0)
 			return &sEngines[i];
 	return NULL;
 }
 void saveUniverse (SEARCH_ENGINE * sEngines, int qtdEngines, char queries[1000][BUFF_SIZE], int qtdQueries, int * output)
 {
 	int i;
 	int j;
 	SEARCH_ENGINE * aux;
 
 	*output = 0;
 	for (i=0;i<qtdQueries;i++)
 	{
 		aux = findEngine(sEngines, qtdEngines, queries[i]);
 		if (aux->used == 0)
 		{
 			aux->used = 1;
 			for (j=0;j<qtdEngines;j++)
 				if (sEngines[j].used == 0)
 					break;
 			if (j == qtdEngines)
 			{
 				*output += 1;
 				zeroEngines(sEngines,qtdEngines);
 			}
 			aux->used = 1;
 		}
 	}
 }
 
 void main (void)
 {
 	FILE * inputFile;
 	FILE * outputFile;
 	int paramCount;
 	int i;
 	int j;
 	SEARCH_ENGINE sEngines[100];
 	int qtdEngines;
 	char queries[1000][BUFF_SIZE];
 	int qtdQueries;
 	int output;
 
 	inputFile = fopen ("input.txt", "rt");
 	if (inputFile == NULL)
 	{
 		puts ("File not found");
 		return;
 	}
 	outputFile = fopen ("output.txt", "wt");
 	if (outputFile == NULL)
 	{
 		puts ("Error creating file");
 		return;
 	}
 	fscanf (inputFile,"%d",&paramCount);
 
 	for (i=0;i<paramCount;i++)
 	{
 		fscanf (inputFile, "%d\n",&qtdEngines);
 		for (j=0;j<qtdEngines;j++)
 		{
 			fgets (sEngines[j].name,BUFF_SIZE,inputFile);
 			if (strlen(sEngines[j].name) >= 1 && (sEngines[j].name[strlen(sEngines[j].name) - 1] == 10 || sEngines[j].name[strlen(sEngines[j].name) - 1] == 13))
 				sEngines[j].name[strlen(sEngines[j].name) - 1] = 0;
 		}
 		fscanf (inputFile, "%d\n",&qtdQueries);
 		for (j=0;j<qtdQueries;j++)
 		{
 			fgets (queries[j],BUFF_SIZE,inputFile);
 			if (strlen(queries[j]) >= 1 && (queries[j][strlen(queries[j]) - 1] == 10 || queries[j][strlen(queries[j]) - 1] == 13))
 				queries[j][strlen(queries[j]) - 1] = 0;
 		}
 
 		zeroEngines(sEngines, qtdEngines);
 		saveUniverse(sEngines, qtdEngines, queries, qtdQueries, &output);
 		fprintf (outputFile, "Case #%d: %d\n",i+1, output);
 	}
 
 	fclose (inputFile);
 	fclose (outputFile);
 }
