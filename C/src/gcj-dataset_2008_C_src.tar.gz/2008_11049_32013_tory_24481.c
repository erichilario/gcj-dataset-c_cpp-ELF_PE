#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 struct trtime
 {
     int hour;
     int min;
 };
 
 struct problem_input_record
 {
     struct trtime turnaround;
 
     int tableA_no;
     struct trtime tableA_departure[100];
     struct trtime tableA_arrival[100];
 
     int tableB_no;
     struct trtime tableB_departure[100];
     struct trtime tableB_arrival[100];
 
     int trainA;
     int trainB;
 };
 
 
 void
 trtime_add(struct trtime A, struct trtime B, struct trtime *C)
 {
     C->hour = A.hour + B.hour;
     C->min  = A.min  + B.min;
 
     if (C->min > 60)
     {
 	C->hour++;
 	C->min -= 60;
     }
 }
 
 /*
  * if A > B, return 1
  * if A < B, return -1
  * if A = B, return 0
  */
 int
 trtime_cmp(struct trtime A, struct trtime B)
 {
     if (A.hour > B.hour) return 1;
     else if (A.hour < B.hour) return -1;
     else if (A.min > B.min) return 1;
     else if (A.min < B.min) return -1;
 
     return 0;
 }
 
 int 
 compare_trtime(const void *paramA, const void *paramB)
 {
     struct trtime *pA = (struct trtime *)paramA;
     struct trtime *pB = (struct trtime *)paramB;
 
     return trtime_cmp(*pA, *pB);
 }
 
 /* get the number of trains that should be started */
 int
 find_trains(struct trtime arrtable[], struct trtime deptable[], int arrcnt, int depcnt,
 	struct trtime turnaround)
 {
     struct trtime rdytable[100];
     int i;
     int rdyidx;
     int train;
 
     if (arrcnt == 0) return depcnt;
 
     for (i=0; i < arrcnt; i++)
     {
 	trtime_add(arrtable[i], turnaround, &rdytable[i]);
     }
 
     /* first sort each table */
     qsort(rdytable, arrcnt, sizeof(struct trtime), compare_trtime);
     qsort(deptable, depcnt, sizeof(struct trtime), compare_trtime);
 
     /* get the number of trains departed newly */
 
     train  = 0;
     rdyidx = 0;
     for (i = 0; i < depcnt; i++)
     {
 //	printf("=> %02d:%02d %02d:%02d\n",
 //		rdytable[rdyidx].hour,
 //		rdytable[rdyidx].min,
 //		deptable[i].hour,
 //		deptable[i].min
 //	      );
 
 	if (rdyidx == arrcnt
 		|| trtime_cmp(rdytable[rdyidx], deptable[i]) == 1)
 	{
 	    /* no train is ready yet. - start new one */
 	    train++;
 	}
 	else
 	{
 	    rdyidx++;
 	}
     }
 
     return train;
 }
 
 
 int
 get_an_answer(struct problem_input_record *record)
 {
     /* first find the number of trains from A */
     record->trainA =  find_trains(record->tableB_arrival, record->tableA_departure,
 	    record->tableB_no, record->tableA_no,
 	    record->turnaround);
 
     /* second find the number of trains from B */
     record->trainB =  find_trains(record->tableA_arrival, record->tableB_departure,
 	    record->tableA_no, record->tableB_no,
 	    record->turnaround);
 
     return 0;
 }
 
 
 int
 read_a_record(FILE *fp, struct problem_input_record *record)
 {
     char buf[256];
     int nread;
     int i;
     char *p;
 
     /* read turnaround time */
     nread = fscanf(fp, "%d", &record->turnaround.min);
     if (nread != 1) return -1;
 
 //    printf("%d: turnaround\n", record->turnaround.min);
 
     nread = fscanf(fp, "%d %d", &record->tableA_no, &record->tableB_no);
     if (nread != 2) return -1;
 
     /* read timetable A */
 //    printf("Table A\n");
     for (i=0; i<record->tableA_no; i++)
     {
 	nread = fscanf(fp, "%02d:%02d %02d:%02d\n",
 		&record->tableA_departure[i].hour,
 		&record->tableA_departure[i].min,
 		&record->tableA_arrival[i].hour,
 		&record->tableA_arrival[i].min);
 
 	if (nread != 4) return -1;
 
 //	printf("%02d:%02d %02d:%02d\n",
 //		record->tableA_departure[i].hour,
 //		record->tableA_departure[i].min,
 //		record->tableA_arrival[i].hour,
 //		record->tableA_arrival[i].min);
     }
     
     /* read timetable B */
 //    printf("Table B\n");
     for (i=0; i<record->tableB_no; i++)
     {
 	nread = fscanf(fp, "%02d:%02d %02d:%02d\n",
 		&record->tableB_departure[i].hour,
 		&record->tableB_departure[i].min,
 		&record->tableB_arrival[i].hour,
 		&record->tableB_arrival[i].min);
 
 	if (nread != 4) return -1;
 
 //	printf("%02d:%02d %02d:%02d\n",
 //		record->tableB_departure[i].hour,
 //		record->tableB_departure[i].min,
 //		record->tableB_arrival[i].hour,
 //		record->tableB_arrival[i].min);
     }
     
     return 0;
 }
 
 int
 solve_the_problem(char *filename)
 {
     FILE *fp;
     int i, n;
     struct problem_input_record *record;
 
     record = malloc(sizeof(struct problem_input_record));
 
     fp = fopen(filename, "r");
     if (fp == NULL) return -1;
 
     fscanf(fp, "%d\n", &n);
 
     for (i=0; i<n; i++)
     {
 	memset(record, 0, sizeof(struct problem_input_record));
 
 	if (read_a_record(fp, record) != 0)
 	{
 	    printf("failed to parse an input file\n");
 	    fclose(fp);
 	    return -2;
 	}
 
 	get_an_answer(record);
 
 	printf("Case #%d: %d %d\n", i+1, record->trainA, record->trainB);
     }
 
     fclose(fp);
 
     return 0;
 }
 
 
 int
 main(int argc, char *argv[])
 {
     int ret;
 
     /* load an input file */
     ret = solve_the_problem(argv[1]);
     if (ret != 0)
     {
 	printf("somthing wrong [%s].\n", argv[1]);
 	return -1;
     }
 
     return 0;
 }

