#include<stdio.h>
 typedef struct
 {
 	int hr;
 	int min;
 	char station;
 	int arrdep;
 }time;
 int main(int argc,char *argv[])
 {
 	time t[400],p;
 	char time[6];
 	int num,i,count=0,count1=0,j,k,tm,Acount[2]={0,0},Bcount[2]={0,0};
 	FILE *fp;
 	fp=fopen(argv[1],"r");
 	fscanf(fp,"%d",&num);
 	for(i=0;i<num;i++)
 	{
 		count=0,count1=0;
 		for(j=0;j<2;j++)
 		{
 			Acount[j]=Bcount[j]=0;
 		}
 		fscanf(fp,"%d",&tm);
 		fscanf(fp,"%d",&count1);
 		count=count1;
 		fscanf(fp,"%d",&count1);
 		for(j=0;j<2*count;j++)
 		{
 			fscanf(fp,"%s",time);
 			t[j].hr=(time[0]-48)*10+(time[1]-48);
 			t[j].min=(time[3]-48)*10+(time[4]-48);
 			if(j%2==0)
 			{
 				t[j].station='A';
 				t[j].arrdep=1;
 			}
 			else
 			{
 				t[j].min+=tm;
 				if(t[j].min>=60)
 				{
 					t[j].min=t[j].min-60;
 					t[j].hr++;
 				}
 				t[j].station='B';
 				t[j].arrdep=0;
 			}
 		}
 		for(j=2*count;j<2*count+2*count1;j++)
 		{
 			fscanf(fp,"%s",time);
 			t[j].hr=(time[0]-48)*10+(time[1]-48);
 			t[j].min=(time[3]-48)*10+(time[4]-48);
 			if(j%2==0)
 			{
 				t[j].station='B';
 				t[j].arrdep=1;
 			}
 			else
 			{
 				t[j].min+=tm;
 				if(t[j].min>=60)
 				{
 					t[j].min=t[j].min-60;
 					t[j].hr++;
 				}
 				t[j].station='A';
 				t[j].arrdep=0;
 			}
 		}
 		count=2*count+2*count1;
 /*		for(j=0;j<count;j++)
 		{
 			printf("%d:%d %c %d\n",t[j].hr,t[j].min,t[j].station,t[j].arrdep);
 		}
 		printf("\n");*/
 		for(k=0;k<count-1;k++)
 		{
 			for(j=0;j<count-k-1;j++)
 			{
 				if(t[j].hr>t[j+1].hr)
 				{
 					p=t[j];
 					t[j]=t[j+1];
 					t[j+1]=p;
 				}
 				else if(t[j].hr==t[j+1].hr)
 				{
 					if(t[j].min>t[j+1].min)
 					{
 						p=t[j];
 						t[j]=t[j+1];
 						t[j+1]=p;
 					}
 					else if(t[j].min==t[j+1].min)
 					{
 						if(t[j].arrdep==1&&t[j+1].arrdep==0)
 						{
 							p=t[j];
 							t[j]=t[j+1];
 							t[j+1]=p;
 						}
 					}
 				}
 			}
 		}
 /*		for(j=0;j<count;j++)
 		{
 			printf("%d:%d %c %d\n",t[j].hr,t[j].min,t[j].station,t[j].arrdep);
 		}*/
 		for(j=0;j<count;j++)
 		{
 			if(t[j].arrdep==1&&t[j].station=='A')
 			{
 				if(Acount[0]==0)
 					Acount[1]++;
 				else
 					Acount[0]--;
 			}		
 			else if(t[j].arrdep==1&&t[j].station=='B')
 			{
 				if(Bcount[0]==0)
 					Bcount[1]++;
 				else
 					Bcount[0]--;
 			}
 			else if(t[j].arrdep==0&&t[j].station=='A')
 				Acount[0]++;
 			else if(t[j].arrdep==0&&t[j].station=='B')
 				Bcount[0]++;
 		}		
 		printf("Case #%d: %d %d\n",i+1,Acount[1],Bcount[1]);
 	}
 }

