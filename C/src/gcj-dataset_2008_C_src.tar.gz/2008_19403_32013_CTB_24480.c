#include <stdio.h>
 
 // #define DEBUGINPUT
 // #define DEBUGPATHS
 // #define DEBUGCOSTS
 // #define DEBUGADDPATHS
 // #define DEBUGWARSHALL
 
 // infinity value (leave space for adding two infinity values)
 #define INF 1000000000
 
 char sen[101][1000];
 int  qry[1001];
 
 char buffer[1000];
 
 typedef struct sPath {
   int s, from, to;
 } Path;
 
 int lastqok[101];
 
 int npaths;
 Path path[101*1001];
 Path * curpath[101];
 
 int d[1001][1001];
 
 int debuginput(int s, int q)
 {
   int i,j;
 
   printf("s=%d\n", s);
   for (i = 1; i <= s; i++)
     printf("s[%d] = %s\n", i, sen[i]);
   printf("q=%d\n", q);
   for (i = 1; i <= q; i++)
     printf("q[%d] = s[%d] = %s\n", i, qry[i], sen[qry[i]]);
 }
 
 int debugpaths(int s)
 {
   int i,j;
 
   for (i = 1; i <= s; i++)
   {
     int comma;
     printf("s[%d] = %s: paths={", i, sen[i]);
     for (j = 0, comma = 0; j < npaths; j++)
       if (path[j].s == i)
         printf ("%s%d-%d", (comma++)?", ":"", path[j].from, path[j].to);
     printf("}\n");
   }
   for (j = 0; j < npaths; j++)
     printf ("%4d: s[%d] = %s, %d-%d\n", j+1, path[j].s, sen[path[j].s], path[j].from, path[j].to);
 }
 
 int debugcosts(int q)
 {
   int i,j;
 
   printf("    ");
   for (j = 1; j <= q; j++)
     printf(" %3d", j);
   printf("\n");
 
   for (i = 1; i <= q; i++)
   {
     printf("%3d ", i);
     for (j = 1; j <= q; j++)
     if (d[i][j] == INF)
       printf("  oo");
     else
       printf(" %3d", d[i][j]);
     printf("\n");
   }   
 }
 
 int solve(int c)
 {
   int s, q, i, j, k, l, cost;
 
   // parse input
   scanf("%d\n", &s);
   for (i = 1; i <= s; i++)
   {
     gets(sen[i]);
   }
 
   scanf("%d\n", &q); 
   for (j = 1; j <= q; j++)
   {
     gets(buffer);
     for (i = 1; i <= s; i++)
       if (strcmp(buffer, sen[i])==0) qry[j] = i;
   }
 
 #ifdef DEBUGINPUT
   debuginput(s, q);
 #endif 
   
   // compute paths which require 0 switches
   npaths = 0;
   for (j = 1; j <= s; j++)
   {
     lastqok[j]  = -1;
     curpath[j] = NULL;
   }
 
   for (i = 1; i <= q; i++)
   {
     for (j = 1; j <= s; j++)
     {
       if (qry[i] != j) // we can use j for query i
       {
         if (lastqok[j] < i-1)
         {
           path[npaths].s    = j;
           path[npaths].from = i;
           curpath[j] = &path[npaths];
           npaths++;
         }
         curpath[j]->to = i;
         lastqok[j] = i;
       }
     } 
   }
 
 #ifdef DEBUGPATHS
   debugpaths(s);
 #endif 
 
   // compute cost matrix using Floyd/Warshall algorithm
 
   // initialize cost matrix to infinity for i<>j, 0 for i==j
   for (i = 1; i <= q; i++)
     for (j = i; j <= q; j++)
        d[i][j] = (i==j)?0:INF;
 
   // add all computed paths and their subpaths which require 0 switches.
   for (i = 0; i < npaths; i++)
   {
 #ifdef DEBUGADDPATHS
     printf("from=%d to=%d\n", path[i].from, path[i].to);
 #endif
     for (k = path[i].from; k < path[i].to; k++)
       for (l = k; l <= path[i].to; l++)
       {
 #ifdef DEBUGADDPATHS
         printf("  k=%d l=%d d[%d][%d]=%d\n", k,l,k,l,0);
 #endif
          d[k][l] = 0;
       }
   }
 
 #ifdef DEBUGCOSTS
   debugcosts(q);
 #endif
 
   for (k = 1; k <= q; k++)
     for (i = 1; i <= k; i++)
       for (j = k+1; j <= q; j++)
       {
 #ifdef DEBUGWARSHALL
         printf("i=%d k=%d j=%d: d[%d][%d]=%d d[%d][%d]=%d\n", i,k,j, i,k,d[i][k],k+1,j, d[k+1][j]);
 #endif
         cost = d[i][k]+d[k+1][j]+1;
         if (cost < d[i][j])
         {
           d[i][j] = cost;
         }
       }
 
 #ifdef DEBUGCOSTS
   debugcosts(q);
 #endif 
  
   printf("Case #%d: %d\n", c, d[1][q]);
 }
 
 int main(int argc, char **argv)
 {
   int i, n;
   scanf("%d", &n);
   for (i = 1; i <= n; i++) solve(i);
 }

