#define _GNU_SOURCE
 #include <stdio.h>
 #include <stdlib.h>
 #include <assert.h>
 #include <string.h>
 #include "data.h"
 
 #define DEBUG_FILE stdout
 
 #if 0
 /** Change this accordingly */
 static void load_u_data(FILE *fp, user_data *u_data)
 {
     fscanf(fp,"%d %d %d %d %d %d\n",
                &u_data->x1,&u_data->y1,
                &u_data->x2,&u_data->y2,
                &u_data->x3,&u_data->y3);
 }
 static void debug_u_data(user_data *u_data)
 {
     fprintf(DEBUG_FILE,"%d %d %d %d %d %d\n",
                 u_data->x1, u_data->y1,
                 u_data->x2, u_data->y2,
                 u_data->x3, u_data->y3);
 }
 
 /* General functions */
 static g_data *allocate_data(int items)
 {
     g_data *r_data;
     r_data = (g_data *)malloc(sizeof(g_data)+sizeof(user_data)*items);
     assert(r_data);
     r_data->items = items;
 
     return r_data;
 }
 
 void free_data(g_data *data)
 {
     assert(data);
     free(data);
 }
 
 void debug_g_data(g_data *data)
 {
     int i;
     assert(data);
     fprintf(DEBUG_FILE,"%d\n",data->items);
     for(i=0;i<data->items;i++)
     {
         debug_u_data(&data->u_data[i]);
     }
 }
 #endif
 #define MAX_SERVERS     110
 #define MAX_QUERIES     1010
 char *servers[MAX_SERVERS];
 int nservers;
 char *queries[MAX_QUERIES];
 int nqueries;
 char server_list[MAX_SERVERS];
 int cq=0;
 
 void free_server_list(void)
 {
     int i;
     for(i=0;i<nservers;i++)
     {
         server_list[i] = 0;
     }
 }
 void freeall(void)
 {
     int i;
     for(i=0;i<nservers;i++)
     {
         free(servers[i]);
         servers[i] = NULL;
         server_list[i] = 0;
     }
 
     for(i=0;i<nqueries;i++)
     {
         free(queries[i]);
         queries[i] = NULL;
     }
     cq = 0;
 }
 void load_servers(FILE *fp)
 {
     int i;
     fscanf(fp,"%d\n",&nservers);
 
     for(i=0;i<nservers;i++)
     {
         size_t n=STR_LIMIT-1;
         int str_len;
         str_len=getline(&servers[i],&n,fp);
         if(str_len)
         {
             (servers[i])[str_len-1] = '\0';
         }
         //printf("\n%d:%s",i,servers[i]);
     }
 }
 void update_server_list(char *q, int *l, int *li, int ignorei)
 {
     int i;
     int least=0xFFFFF;
     int least_i=0;
     for(i=0;i<nservers;i++)
     {
         /* Ignore case */
         if(!strcasecmp(servers[i],q))
         {
             server_list[i]++;
         }
         if(least > server_list[i] && i != ignorei)
         {
             least = server_list[i];
             least_i = i;
         }
     }
     if(l && li)
     {
         *l = least;
         *li = least_i;
     }
 }
 void update_server_list_q(int q, int *l, int *li, int ignorei)
 {
     int i;
     for(i=q;i<nqueries;i++)
     {
         update_server_list(queries[i], l, li, ignorei);
     }
 }
 void load_queries(FILE *fp)
 {
     int i;
     fscanf(fp,"%d\n",&nqueries);
 
     for(i=0;i<nqueries;i++)
     {
         size_t n;
         int str_len;
         str_len = getline(&queries[i],&n,fp);
         if(str_len)
         {
             (queries[i])[str_len-1] = '\0';
         }
         //printf("\n\t %s",queries[i]);
 
         update_server_list(queries[i], NULL, NULL, -1);
     }
 }
 
 int run_algo(void)
 {
     int jumps=0;
     int i=0;
     int least, leasti;
     int cur_server=0;
 
     update_server_list_q(0,&least, &leasti, -1);
     cur_server = leasti;
 
     while(i<nqueries)
     {
         if(strcasecmp(queries[i],servers[cur_server]) == 0)
         {
             if(cur_server == leasti)
             {
                 update_server_list_q(i, &least, &leasti, cur_server);
             }
             else
             {
                 jumps++;
                 update_server_list_q(i, &least, &leasti, -1);
             }
             cur_server = leasti;
             continue;
         }
         leasti = -1;
         i++;
     }
 
 
     return jumps;
 }
 
 #include <pthread.h>
 pthread_t s_thread[MAX_SERVERS];
 char server_to_q[MAX_SERVERS][MAX_QUERIES];
 char jserver_to_q[MAX_SERVERS][MAX_QUERIES];
 int thread_work(int jumps, int starti, int cur_server)
 {
     int ret_jumps=0xFFFFF;
     int i, j;
     static int call=0, ret=0;
 
     call++;
     //printf("\n C: %d %d",call,ret);
 
     //if(server_to_q[cur_server][starti] != -1 && server_to_q[cur_server][starti] < jumps) 
     if(server_to_q[cur_server][starti] != -1) 
     {
         ret++;
         //printf("\n Found: %d %d %d %d",cur_server,starti,server_to_q[cur_server][starti], jumps);
         return server_to_q[cur_server][starti]+jumps;
     }
 
     for(i=starti;i<nqueries;i++)
     {
         if(strcasecmp(servers[cur_server], queries[i]) == 0)
         {
             /** Jump */
             break;
         }
     }
     //printf("\n Starti: %d %d %d %d %d",starti, cur_server,jumps,i,nqueries);
     if(i==starti)
     {
         /** Failed */
         ret++;
         return ret_jumps;
     }
     if(i<nqueries)
     {
         //printf("\n Cur Server: %s %d %d",servers[cur_server], i, nqueries);
         for(j=0;j<nservers;j++)
         {
             int r;
             if(j != cur_server)
             {
                 r=thread_work(jumps+1, i, j);
                 if(r < ret_jumps)
                     ret_jumps=r;
             }
         }
     }
     else
     {
         ret_jumps = jumps;
     }
     if((server_to_q[cur_server][starti] > ret_jumps-jumps) ||
         server_to_q[cur_server][starti] == -1)
     {
         //printf("\n J: %d:%d %d %d",cur_server, starti, ret_jumps,jumps);
         //if(ret_jumps != jumps)
             server_to_q[cur_server][starti] = ret_jumps-jumps;
         //else
         //    server_to_q[cur_server][starti] = ret_jumps;
         jserver_to_q[cur_server][starti] = jumps;
 
     }
     ret++;
     return ret_jumps;
 }
 void *server_thread(void *arg)
 {
     int jumps=0xFFFFF, r;
     int start_server=(int)arg;
 
 //printf("\n Start Server: %d",start_server);
     r=thread_work(0, 0, start_server);
     if(r<jumps)
         jumps = r;
 
 //printf("\n Jumps: %d:%d",start_server, jumps);
     pthread_exit((void *)jumps);
 }
 #define MAX_THREADS     1
 int run_algo2(void)
 {
     int jumps=0xFFFFF;
     int i=0,n=0;
 
     memset((void *)server_to_q,0xFF,MAX_SERVERS*MAX_QUERIES);
     memset((void *)jserver_to_q,0,MAX_SERVERS*MAX_QUERIES);
 
     while(n<nservers)
     {
         for(i=0;i<MAX_THREADS;i++)
         {
             int err;
             if(n+i >= nservers)
                 break;
 
             if((err=pthread_create(&s_thread[n+i], NULL,server_thread, (void *)(n+i))))
             {
                 printf("\n Thread Creation failed!!! %d 0x%X",i,err);
             }
         }
         for(i=0;i<MAX_THREADS;i++)
         {
             void *jump;
             if(n+i >= nservers)
                 break;
             pthread_join(s_thread[n+i], &jump);
             if(jumps > (int)jump)
                 jumps = (int)jump;
         }
         n = n+MAX_THREADS;
     }
     if(jumps == 0xFFFFF) jumps=0;
     return jumps;
 }
 
 g_data *load_file(char *filename)
 {
     g_data *data=NULL;
     int i,sets;
     FILE *fp;
 
     fp=fopen(filename,"rt");
     if(!fp)
     {
         printf("\n Error opening input file: %s",filename);
         return NULL;
     }
     
     fscanf(fp, "%d \n", &sets);
     for(i=0;i<sets;i++)
     {
         int result1, result2;
 
         /** Load servers */
         load_servers(fp);
 
         /** Load queries */
         load_queries(fp);
 
         /** Run algo */
         result1 = run_algo();
         result2 = run_algo2();
 
         /** Output solution */
         //printf("Case #%d: %d\n",i+1,result1);
         printf("Case #%d: %d\n",i+1,result2);
         //printf("Case #%d: %d\n",i+1,(result1<result2)?result1:result2);
 
         /** Free Data */
         freeall();
     }
     fclose(fp);
     return data;
 }

