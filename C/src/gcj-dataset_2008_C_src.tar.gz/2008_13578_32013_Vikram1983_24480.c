#include<stdio.h>
 #include<string.h>
 #include<malloc.h>
 
 int track_path(char server_name[100], char queries[1000][100], int no_queries, int start)
 {
    int ctr2 = 0;
    
    for(ctr2=start; ctr2<no_queries; ctr2++)
    {
       if(strcasecmp(server_name, queries[ctr2]) == 0)
       {
          break;
       }
    }
    return ctr2;
 }
 
 int best_path(char servers[100][100], char queries[1000][100], int no_servers, int no_queries, int start)
 {
    int best_path = 0;
    int ctr1 = 0;
    int path = 0;
    for(ctr1=0; ctr1<no_servers; ctr1++)
    {
       if(best_path < (path = track_path(servers[ctr1], queries, no_queries, start)))
       {
          best_path = path;
       }
    }
    return best_path;
 }
 
 int main(void)
 {
    char servers[100][100];
    char queries[1000][100];
    
    FILE *fp_in, *fp_out;
    int ctr1 = 0;
    int ctr2 = 0;
    int no_inputs = 0;
    int case_no = 0;
    int no_servers = 0;
    int no_queries = 0;
    int path = 0;
    int switches = 0;
    
    fp_in = fopen("A-large.in", "r");
    if(fp_in == NULL)
       printf("ERROR");
    
    fp_out = fopen("A-large.out", "w");
    
    fscanf(fp_in, "%d\n", &no_inputs);
    
    while(1)
    {
       // Read till the end of file
       if(feof(fp_in))
          break;
       else
       {
          // Reading the no. of servers
          fscanf(fp_in, "%d\n", &no_servers);
          if(feof(fp_in))
             break;
          else
          {
             case_no++;
             // Storing the servers in the array
             for(ctr1=0; ctr1<no_servers; ctr1++)
                fgets(servers[ctr1], 100, fp_in);
 
             // Reading the no. of Queries
             fscanf(fp_in, "%d\n", &no_queries);
             
             // Storing the queries in the array
             for(ctr2=0; ctr2<no_queries; ctr2++)
                fgets(queries[ctr2], 100, fp_in);
             
             while(1)
             {
                path = best_path(servers, queries, no_servers, no_queries, path);
                
                if(path == no_queries)
                {
                   fprintf(fp_out, "Case #%d: %d\n", case_no, switches);
                   path = 0;
                   switches = 0;
                   break;
                }
                else
                {
                   switches++;
                }
             }
         }
       }
    }
    fclose(fp_out);
    fclose(fp_in);
    return 0;
 }
 

