#include<stdio.h>
 #include<conio.h>
 struct engine
 {
  char name[102];
  int set;
 }s[100];
 void main()
 {
  FILE *fp,*fp1;
  int count=0;
  int noq;
  int nosw=0;
  int not;//not--no of testcases
  int nos;//nos--no of search engines
  int rem;
  int i,j,k,z;
  char q[102];
  clrscr();
  fp=fopen("input.txt","r");
  fp1=fopen("output.txt","w");
  fscanf(fp,"%d",&not);
  fp->curp++;
  for(z=0;z<not;z++)
  {
   fscanf(fp,"%d",&nos);
   fgetc(fp);
   for(i=0;i<nos;i++)
   {
    fgets(s[i].name,101,fp);
    s[i].name[strlen(s[i].name)-1]='\0';
   }
   fscanf(fp,"%d",&noq);
   fgetc(fp);
   for(j=0;j<noq;j++)
   {
    fgets(q,101,fp);
    q[strlen(q)-1]='\0';
    for(i=0;i<nos;i++)
    {
     if(!strcmp(q,s[i].name))
     {
      if(s[i].set==0)
      {
 
       count++;
       if(count==nos)
       {
        nosw++;
        for(k=0;k<nos;k++)
 	s[k].set=0;
        count=1;
       }
       s[i].set=1;
      }
      break;
     }
    }
   }
   for(i=0;i<nos;i++)
    s[i].set=0;
   count=0;
   fprintf(fp1,"Case #%d: %d\n",z+1,nosw);
   printf("\nCase #: %d",nosw);
   nosw=0;
  }
  getch();
  fclose(fp);
 }
