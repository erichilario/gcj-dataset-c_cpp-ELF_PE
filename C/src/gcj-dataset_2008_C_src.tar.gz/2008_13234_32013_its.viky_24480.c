#include<stdio.h>
 
 int n,s,q;
 char engine[100][100];
 char querry[1000][100];
 
 main(int argc, char *argv[])
 {
  int swt,use,count;
  int tcase,engno,qur;
  char ch;
  FILE *fr;
  char line[100];
  char cureng[100];
 
  fr = fopen(argv[1],"r");
  readline(fr,line);
  n = strtoi(line);
  //printf("%s\n",line);
  //printf("test cases = %d\n",n);
  for(tcase=0;tcase<n;tcase++)
  {
   swt = 0;
   readline(fr,line);
   s = strtoi(line);
   //printf("engines = %d\n",s);
   for(engno=0;engno<s;engno++)
   {
    readline(fr,line);
    strcpy(engine[engno],line);
   }//end copying eng names
   //printf("engine names copied...\n");
   readline(fr,line);
   q = strtoi(line);
   //printf("querries = %d\n",q);
   for(qur = 0;qur<q; qur++)
   {
    readline(fr,line);
     strcpy(querry[qur],line);
   }//end copying querries
   //printf("querries copied...\n");
 /*  for(engno=0;engno<s;engno++)
   {
    for(qur=0,count=0;qur<q;qur++)
    {
     if(!strcmp(engine[engno],querry[qur]))  
      break;
     count++;
    }
     counteng[engno]=count;
   }//fill distances of each engine
   for(engno=0,use=0; engno<s; engno++)
   {
    //printf("%d ",counteng[engno]);
    use = (counteng[engno]<counteng[use])?use:engno;
   }//find engine to be used
 */
   use = fillcount(0);
   //printf("engine used = %s\n",engine[use]);
   strcpy(cureng,engine[use]);
   for(swt=0,qur=0 ;qur<q;qur++)
   {
    while(!strcmp(cureng,querry[qur]))
    {
     swt++;
  //   printf("switching...\n");
     //use = (use<s)?use+1:0;
     use = fillcount(qur);
     strcpy(cureng,engine[use]);
    }//switch engine 
   }//end finding total switches
    
  printf("Case #%d: %d\n",tcase+1,swt);
  }//end test cases 
   //printf("%s\n",line);
 }//end main
 
 int readline(FILE *f, char *l)
 {
  int i=0;
  int c;
  while((c=fgetc(f))!='\n')
   if(c==-1)
    return 0;
   else
   l[i++]=c;
  l[i]='\0';
 return i; 
 }
 
 int strtoi(char *l)
 {
  int num =0 ;
  char ch; 
  while(ch=*l++)
   if(isprint(ch))
    num = (num*10)+(ch - '0');
 return num;
 }
 
 int fillcount(int pos)
 {
  int use,engno,qur,count;
  int counteng[100]={0};
  for(engno=0;engno<s;engno++)
  {
   for(qur=pos,count=0;qur<q;qur++)
   {
    if(!strcmp(engine[engno],querry[qur]))  
     break;
    count++;
   }
    counteng[engno]=count;
  }//fill distances of each engine
  for(engno=0,use=0; engno<s; engno++)
  {
   //printf("%d ",counteng[engno]);
   use = (counteng[engno]<counteng[use])?use:engno;
  }//find engine to be used
  return use;
 }

