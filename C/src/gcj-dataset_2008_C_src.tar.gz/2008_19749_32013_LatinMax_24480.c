#include <stdio.h>
 #include <string.h>
 #include <malloc.h>
 #include <stdlib.h>
 
 
 //#define argv[1] "A.in"
 #define ARCHIVO_SALIDA "A.out"
 
 
 
 int main(int argc, char *argv[]){
 
 	FILE *archivo;
 	FILE *archivo2;
 	char linea[250];
 	char* motores[100];
 	char* consultas[1000];
 	int distanciaMotor[100];
 	int cantCasos, cantConsultas, cantMotores;
 	int k, i, j, PRIMERO, cantCambiosBuscador;
 
 	if ((archivo=fopen(argv[1],"r"))==NULL){
 		printf("ERROR FATAL [1]. No se pudo abrir el archivo de entrada de datos \"%s\"\n",argv[1]);
 		exit(1);
 	}
 	else {
 		printf("Archivo de datos de entrada abierto correctamente [\"%s\"]\n",argv[1]);
 	}
 	
 	if ((archivo2=fopen(ARCHIVO_SALIDA,"w"))==NULL){
 		printf("ERROR FATAL [1]. No se pudo abrir el archivo de salida de datos \"%s\"\n",ARCHIVO_SALIDA);
 		exit(1);
 	}
 	else {
 		printf("Archivo de datos de salida abierto correctamente [\"%s\"]\n",ARCHIVO_SALIDA);
 	}
 
 	fgets (linea, 250, archivo);
 	cantCasos=atoi(linea);
 	printf ("La cantidad de casos es %i \n", cantCasos);
 	printf("-----------------Salida al archivo A.out------------------\n");
 
 	for (k=0;k<cantCasos;k++){
 	
 		//leo los motores de busqueda
 		fgets (linea, 250, archivo);
 		cantMotores = atoi(linea);
 		for (i=0;i<cantMotores;i++) {
 			fgets (linea, 250, archivo);
 			motores[i] = (char*)malloc(sizeof(char)*(strlen(linea)+1));
 			strcpy(motores[i], linea);
 		}
 		
 		//leo las consultas
 		fgets (linea, 250, archivo);
 		cantConsultas = atoi(linea);
 		for (i=0;i<cantConsultas;i++) {
 			fgets (linea, 250, archivo);
 			consultas[i] = (char*)malloc(sizeof(char)*(strlen(linea)+1));
 			strcpy(consultas[i], linea);
 		}
 		
 		PRIMERO=0;
 		cantCambiosBuscador=0;
 		
 		while (PRIMERO<cantConsultas) {
 			// guarda en distanciaMotor las distancias al motor mas proximo en la lista de consultas
 			for (i=0;i<cantMotores;i++) {
 				j=PRIMERO;
 				while ((j<cantConsultas) && strcmp(consultas[j],motores[i])) {
 					//printf("Valor j-(%i)\n",j);
 					//printf("%s-%s-(%i)\n\n",consultas[j],motores[i],strcmp(motores[i],consultas[j]));
 						j++;
 				} 
 				distanciaMotor[i]=j;
 			}
 			
 			for (i=0;i<cantMotores;i++) {
 				//printf("distanciaMotor[%i]=%i\n",i,distanciaMotor[i]);
 			}
 
 			//obtengo en j el indice del motor mas lejano en la lista de consultas
 			j=0;
 			for (i=0;i<cantMotores;i++) {
 				if (distanciaMotor[j]<distanciaMotor[i]) {
 					j=i;
 				}
 			}
 			
 			PRIMERO=distanciaMotor[j];
 			
 			if (PRIMERO<cantConsultas) cantCambiosBuscador++;
 			//printf("PRIMERO=%i\n----------------------------------\n",PRIMERO);
 
 			
 		}
 		
 		printf("Case #%i: %i\n",k+1,cantCambiosBuscador);
 		fprintf(archivo2,"Case #%i: %i\n",k+1,cantCambiosBuscador);
 		
 	}
 	
 
 
 	if (fclose(archivo)!=0){
 		printf("ERROR DE CIERRE [2]. No se pudo cerrar el archivo de entrada de datos \"%s\"\n",argv[1]);
 	}
 	
 	if (fclose(archivo2)!=0){
 		printf("ERROR DE CIERRE [3]. No se pudo cerrar el archivo de salida de datos \"%s\"\n","A.out");
 	}
 	else {
 		printf("---------------FIN EJECUCION---------------\n");
 	}
 
 	return 0;
 }

