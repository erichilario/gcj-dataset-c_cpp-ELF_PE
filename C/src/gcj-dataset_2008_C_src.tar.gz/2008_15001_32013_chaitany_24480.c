#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 int N;
 
 
 void update_indices(int S, int Q, int cur_q_index, char** search_engines, char** Queries, int* s_indices )
 {
 	int j;
 			for(j=0;j<S;j++)
 	 		{
 
 			int k;
 				
 			//printf(" \n *** CheckingB4 Updating index %s isequalto = %d cur_Q %d *** \n ",search_engines[j],s_indices[j],cur_q_index);
 			if(s_indices[j] <= cur_q_index)
 			{
 				s_indices[j] = -1;
 			
 				for (k = cur_q_index+1; k < Q;k++)
 				{
 					if(strcmp(search_engines[j],Queries[k]) == 0 )
 					{
 						s_indices[j] = k;
 
 						//printf(" \n *** Updating index %s isequalto = %d *** \n ",search_engines[j],s_indices[j]);
 						break;
 					}
 				}
 			}
 
 			}
 
 
 }
 
 int get_max_forward_edge_searchindex(int S, int* s_indices,int curr_index)
 {
 	int max_till_now = -2;
 	int index_till_now = 0;
 	int j;
 
 	for(j=0;j<S;j++)
 	{
 		if(j == curr_index) {continue;}
 		if(s_indices[j] == -1) {return j;}
 		if(s_indices[j] > max_till_now)
 		{
 			max_till_now = s_indices[j];
 			index_till_now = j;
 		}
 	}
 
 	return index_till_now;
 }
 
 
 int main(int argc, char** argv)
 {
   FILE* inpfile;
   int i;
 	 char* chumma_string;
 	 int len;
 
 	 chumma_string = (char*) malloc(1000);
 	
   inpfile = fopen(argv[1],"r");
 	
   getline(&chumma_string,&len,inpfile);
 	 sscanf(chumma_string,"%d",&N);
 
   for(i=0;i<N;i++)
   {
 	 char** search_engines;
 	 char** Queries;
 	 int cur_q_index = 0;
 	 int* s_indices;
 	 int S;
 	 int j,Q;
 	 int k;
 	 int min_switch_count = -1;
 
 
 	 getline(&chumma_string,&len,inpfile);
 	 sscanf(chumma_string,"%d",&S);
 
 	 s_indices = (int*) malloc(sizeof(int)*S);
 
 	 search_engines = (char**) malloc(sizeof(char*)*S);
 	 for(j=0;j<S;j++)
 	 {
 
 		s_indices[j] = -1;
 		 search_engines[j] = (char*) malloc(sizeof(char)*100);
 		 //fscanf(inpfile,"%s",search_engines[j]);
 		 getline(&search_engines[j],&len,inpfile);
 
     }
 		getline(&chumma_string,&len,inpfile);
 	 sscanf(chumma_string,"%d",&Q);
 
 
 	 Queries = (char**) malloc(sizeof(char*)*Q);
 	 for(j=0;j<Q;j++)
 	 {
 		 Queries[j] = (char*) malloc(sizeof(char)*100);
 
 		 getline(&Queries[j],&len,inpfile);
 
 		 //fscanf(inpfile,"%s",Queries[j]);
     }
 
 
 		for(j=0;j<S;j++)
 		{
 			int switch_count = 0;
 			int curr_search_engineindex = j;
 
 			 for(k=0;k<S;k++)
 			 {
 				s_indices[k] = -1;
 			 }
 
 //			update_indices(S,  Q, cur_q_index, search_engines, Queries,  s_indices );
 
 			for(k=0;k < Q; k++)
 			{
 				cur_q_index = k;
 
 				//printf("chumma k %d j %d Se %s Qr %s cur_sw %d\n",k,j,search_engines[curr_search_engineindex],Queries[k],switch_count);
 
 				if(strcmp(search_engines[curr_search_engineindex],Queries[k]) == 0)
 				{
 					//Evict needed ...
 					//printf("Conflict found \n");
 					update_indices(S,  Q, cur_q_index, search_engines, Queries,  s_indices);
 					{
 						int temp = curr_search_engineindex;
 					curr_search_engineindex = get_max_forward_edge_searchindex(S,s_indices,curr_search_engineindex);
 					if (temp != curr_search_engineindex) {
 						//printf("Incrementing switch count\n");
 						switch_count++;
 					}
 					}
 				}
 			}
 			
 
 			if(min_switch_count == -1) {min_switch_count = switch_count;}
 			else if(switch_count < min_switch_count) {min_switch_count = switch_count;}
 		}
 
 		printf("Case #%d: %d\n",i+1,min_switch_count);
 
 	 //Deallocation ...............
 
 	 for(j=0;j<S;j++)
 	 {
 		 free(search_engines[j]);
 	 }
 	 free(search_engines);
 	 for(j=0;j<Q;j++)
 	 {
 		 free(Queries[j]);
 	 }
 	 free(Queries);
 
 
 
   }
 }

