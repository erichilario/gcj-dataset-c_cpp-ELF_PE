#include <stdio.h>
 #include <stdlib.h>
 
 /**************************************
 Replace all ' ' white spaces with 
 '_'under score in the input file
 using any text editor 
 **************************************/
 
 int main()
 {
 	int nc,ne,nq,i,j,c=0, *a, no,s = 0,k=0;
 	char buff[100], e[100][1000];
 	FILE *inp ,*oup;
 	
 	inp = fopen("input.in", "r");
 	oup = fopen("out.in", "w");
 	fscanf(inp,"%d",&nc);
 
 	while(nc!=0)
 	{
 		c++;
 		s=0;		
 		fscanf(inp,"%d",&ne);
 		no = ne ;
 		j = ne;//printf("ne = %d\n",ne);
 		i = 0;
 		while(j!=0)
 		{
 			fscanf(inp,"%s", e[i]);//printf("e = %s\n", e[i]);
 			i++;
 			j--;//printf("je = %d\n",j);
 		}
 		fscanf(inp,"%d",&nq);
 		j = nq ;//printf("nq = %d\n",nq);
 		a = malloc(sizeof(int)*no);
 		for(i=0;i<ne;i++)
 		a[i]=1;
 		while(j!=0)
 		{
 			fscanf(inp,"%s", buff);
 			for(i = 0;i<ne;i++)
 			{
 				if((!strcmp(buff,e[i]))&a[i])
 				{
 					a[i] = 0;k=i;
 					no--;
 					break;
 				}
 			}
 			j--;//printf("buff = %s no = %d\n",buff,no);
 			if(no == 0 )
 			{
 				s++;
 				for(i=0;i<ne;i++)
 				a[i]=1;
 				a[k]=0;
 				no = ne-1;
 			}
 			
 		}
 		{
 			fprintf(oup,"Case #%d: %d\n",c,s);
 		}
 		nc--;
 		free(a);
 	}
 	close(inp);
 	close(oup);
 }

