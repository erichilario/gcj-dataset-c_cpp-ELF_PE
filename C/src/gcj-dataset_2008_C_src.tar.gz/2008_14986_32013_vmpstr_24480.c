#include <stdio.h>
 #include <string.h>
 
 int main(void)
 {
 	int cases, neng, cneng, nq, i, j, k, kk;
 	char eng[200][105], q[105];
 	int place[200] = {0};
 	int switches, restricted=-1;
 
 	scanf("%d\n", &cases);
 	for(i=0; i<cases; i++)
 	{
 		scanf("%d\n", &neng);
 		for(j=0; j<neng; j++)
 		{
 			fgets(eng[j], sizeof(eng[j]), stdin);
 			eng[j][strcspn(eng[j], "\n\r")] = 0;
 			
 		}
 		scanf("%d\n", &nq);
 		switches = 0;
 		cneng = 0;
 		for(j=0; j<200; j++)
 		{
 			place[j] = 0;
 		}
 		for(j=0; j<nq; j++)
 		{
 			fgets(q, sizeof q, stdin);
 			q[strcspn(q, "\r\n")] = 0;
 			for(k=0; k<neng; k++)
 			{
 				if(strcmp(q, eng[k]) == 0)
 				{
 					if(place[k] == 0)
 					{
 						place[k] = j+1;
 						cneng++;
 						if(cneng == neng)
 						{
 							switches++;
 							for(kk=0; kk<200; kk++)
 							{
 								place[kk] = 0;
 							}
 							place[k] = j+1;
 							cneng = 1;
 							break;
 						}
 					}
 					break;
 				}
 			}
 		}
 		printf("Case #%d: %d\n", i+1, switches);
 	}
 	return 0;
 }

