#include <stdio.h>
 struct info
 {
 char server[101];
 char status;
 };
 
 struct info *ptr;
 void main()
 {
 	int testcases;
 	int testcount= 1;
 	scanf("%d",&testcases);
 	//printf("%d\n",testcases);
 
 	while(testcount <= testcases)
 	{
 		int servers = 0;
 		int i = 0,j=0;
 		int q;
 		char server[101];
 		int count=0;
 		int switches=0;
 		scanf("%d ",&servers);
 		//printf("%d\n",servers);
 		
 		if (servers != 0)
 		{
 			ptr = malloc(sizeof(struct info) * servers);
 			memset(ptr, 0, sizeof(struct info) * servers);
 		}
 		while (i < servers)
 		{
 			gets(ptr[i].server);
 			//printf("%s\n",ptr[i].server);
 			ptr[i].status = 0;
 			i++;
 		}
 		
 		scanf("%d ",&q);
 		//printf("%d\n",q);
 		
 		while (q != 0)
 		{
 			gets(server);
 			//printf("got%s\n",server);
 			
 			for (i = 0; i<servers; i++)
 			{
 				if (0 == (strcmp(ptr[i].server, server)))
 				{
 					//printf("matched at %d\n", i);
 					if (ptr[i].status == 0)
 					{
 						count++;
 						if (count == servers)
 						{
 							//printf("value of switch %d\n", switches);
 							switches++;
 							count = 1;
 							for (j = 0; j<servers; j++)
 								ptr[j].status = 0;
 							
 						}
 						ptr[i].status = 1;
 						
 
 					}
 					break;
 				}
 			}
 			q--;
 		}
 		printf("Case #%d: %d\n",testcount,switches);
 		switches = 0;
 		count=0;
 		testcount++;
 		free(ptr);
 	}
 }
 
 

