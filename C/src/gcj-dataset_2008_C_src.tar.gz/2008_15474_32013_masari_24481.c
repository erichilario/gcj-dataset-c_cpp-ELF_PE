#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct Travel travel;
 struct Travel{
 	// times in minutes
 	int departure; 
 	int arrival;
 	int alreadyUsed;
 };
 
 int compare(travel *t1, travel *t2);
 
 int main()
 {
 	int numOfCases, turnTime, na, nb, trainsA, trainsB;
 	int i, j, k, hours, minutes;
 	travel * ab;
 	travel * ba;
 	
 	scanf("%d", &numOfCases);
 	for(i = 0; i < numOfCases; i++){
 		scanf("%d", &turnTime);
 		scanf("%d %d", &na, &nb);
 		ab = malloc(na*sizeof(travel));
 		ba = malloc(nb*sizeof(travel));
 		
 		for (j=0;j<na;j++){
 			scanf("%d:%d", &hours, &minutes);
 			ab[j].departure = hours*60 + minutes;
 			
 			scanf("%d:%d", &hours, &minutes);
 			ab[j].arrival = hours*60 + minutes;
 			ab[j].alreadyUsed = 0;
 		}
 		
 		for (j=0;j<nb;j++){
 			scanf("%d:%d", &hours, &minutes);
 			ba[j].departure = hours*60 + minutes;
 			
 			scanf("%d:%d", &hours, &minutes);
 			ba[j].arrival = hours*60 + minutes;
 			ba[j].alreadyUsed = 0;
 		}
 		
 		trainsA = na;
 		trainsB = nb;
 		
 		qsort(ab, na, sizeof(travel), (int (*)(const void *, const void *))compare);
 		qsort(ba, nb, sizeof(travel), (int (*)(const void *, const void *))compare);
 		
 		for (j=0;j<na;j++){
 			for(k = 0;k<nb;k++){
 				if ((ba[k].alreadyUsed == 0)&&(ab[j].departure >= ba[k].arrival+turnTime)){
 					ba[k].alreadyUsed = 1;
 					trainsA--;
 					break;
 				}
 			}
 		}
 		
 		for (j=0;j<nb;j++){
 			for(k = 0;k<na;k++){
 				if ((ab[k].alreadyUsed == 0)&&(ba[j].departure >= ab[k].arrival+turnTime)){
 					ab[k].alreadyUsed = 1;
 					trainsB--;
 					break;
 				}
 			}
 		}
 		
 		printf("Case #%d: %d %d\n", i+1, trainsA, trainsB);
 		free(ab);
 		free(ba);
 	}	
 	return 0;
 }
 
 //descending order
 int compare(travel *t1, travel *t2)
 {
 	if(t1->arrival > t2->arrival){
 		return -1;
 	}else{
 		if(t1->arrival < t2->arrival){
 			return 1;
 		}else{
 			return 0;
 		}
 	}
 }

