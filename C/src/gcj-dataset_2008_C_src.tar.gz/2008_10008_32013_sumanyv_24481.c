#include <stdio.h>
 #include <conio.h>
 
 void getinput(int **arr,int **dep,int trips);
 int stringtoint(char *buff);
 int power(int i,int j);
 void quicksort(int a, int b,int *A);
 int calctrain(int *arr,int *dep,int trip1,int trip2);
 
 //static variables
 static int no_of_cases = 0;
 static int turn_around_time = 0;
 
 static FILE * fp;
 
 static int * arr_A;
 static int * arr_B;
 static int * dep_A;
 static int * dep_B;
 
 static int trains_at_A=0;
 static int trains_at_B=0;
 
 
 int main()
 {
 	int tripA,tripB;
 	int len;
 	int case_id;
     char * buff = (char *) malloc(64 * sizeof(char));
 
 	FILE * fp_out = fopen("D:\\Suman\\Google CodeJAM\\Qualifying Round\\Train\\output.txt","w+");
 
 	buff[0] = '\0';
 
 	fp = fopen("D:\\Suman\\Google CodeJAM\\Qualifying Round\\Train\\input.txt","r+");
 
 	if(fp == NULL)
 	{
 		printf("Error opening the input file\n");
 		getch();
 		return 0;
 	}
 	
 	if(fgets(buff,64,fp))
 	{
 		int len1 = strlen(buff);
 		buff[len1-1]='\0';
 		 no_of_cases = stringtoint(buff);
 	}
 	
 
 
 	for(case_id=0;case_id<no_of_cases;case_id++)
 	{
 		//read the turn around time
 		if(fgets(buff,64,fp))
 		{
 			int len1 = strlen(buff);
 			buff[len1-1]='\0';
 			turn_around_time = stringtoint(buff);
 		}
 		// now read the number of lines for A and B
 		if(fgets(buff,64,fp))
 		{
 			int i=0,j=0;
 			char tmp[15];
 			while(buff[i] != ' ')
 			{
 				tmp[j] = buff[i];
 				i++;j++;
 			}
 			tmp[j]='\0';
 			tripA = stringtoint(tmp);
 			i++;
 			j=0;
 			
 			while((buff[i] != ' ') && (buff[i] != '\0'))
 			{
 				tmp[j] = buff[i];
 				i++;j++;
 			}
 			tmp[j-1]='\0';
 			tripB = stringtoint(tmp);
 		
 		}
 
 		// now read the input from the file ---Station A details
 		getinput(&arr_A,&dep_A,tripA);
 		getinput(&arr_B,&dep_B,tripB);
 		// sort all the arrays
 		quicksort(0, tripA-1,arr_A);
 		quicksort(0, tripA-1,dep_A);
 		quicksort(0, tripB-1,arr_B);
 		quicksort(0, tripB-1,dep_B);
 		//
 		trains_at_A = calctrain(arr_A,dep_B,tripA,tripB);
 		trains_at_B = calctrain(arr_B,dep_A,tripB,tripA);
 		//write output
 		if(fp_out)
 		{
 			fprintf(fp_out,"Case #%d: %d %d\n",case_id+1,trains_at_A,trains_at_B);
 			fflush(fp_out);
 		}
 
 	}
 
 		
 	fclose(fp);
 	fclose(fp_out);
 
 	getch();
 	return 0;
 }
 
 //
 int calctrain(int *arr,int *dep,int trip1,int trip2)
 {
 	int i,j=0,k;
 	int val;
 	int trains=0;
 
 	if((trip1 != 0) && (trip2 != 0))
 	{
 		for(i=0;i<trip1;i++)
 		{
 			val = arr[i] - turn_around_time;
 
 			while((dep[j]<val)&&(j<trip2))
 			{
 				trains++;
 				if(j<trip2)
 				{
 					j++;
 					break;
 				}
 			}
 		}
 	}
 	return (trip1 - trains);
     
 }
 
 
 
 
 
 // reads the input from the FILE
 void getinput(int **arr,int **dep,int trips)
 {
 	int i,j;
 	int time_hr,time_min;
 	char *buff = (char *) malloc(16*sizeof(char));
 	char *tbuff;
 	char tmp[4];
     buff[0] = '\0';
 	
 	tbuff = buff;
 
 
 	*arr = (int *) malloc(trips*sizeof(int));
 	*dep = (int *) malloc(trips*sizeof(int));
 
 	for(i=0;i<trips;i++)
 	{
 		buff =tbuff;
 		fgets(buff,16,fp);
 		
             tmp[0]=buff[0];
 			tmp[1]=buff[1];
 			tmp[2]='\0';
 			
 			arr[0][i]=60*(stringtoint(tmp));
 			buff =buff+3;
 
 			tmp[0]=buff[0];
 			tmp[1]=buff[1];
 			tmp[2]='\0';
 			
 			arr[0][i]=arr[0][i] + stringtoint(tmp);
 			buff =buff+3;
 
 			tmp[0]=buff[0];
 			tmp[1]=buff[1];
 			tmp[2]='\0';
 
 			dep[0][i]=60*(stringtoint(tmp));
 			buff =buff+3;
 
 			tmp[0]=buff[0];
 			tmp[1]=buff[1];
 			tmp[2]='\0';
 			
 			dep[0][i]=dep[0][i] + stringtoint(tmp);
 		
 	}
 
 }
 
 
 
 
 
 
 // converts string to int
 int stringtoint(char *buff)
 {
 	int i=0;
 	int val=0;
 	int size;
 	char ch;
 
 	size = strlen(buff);
 	//size = size -2;
 	i = size;
 
 
 	while(i>0)
 	{
 		ch = buff[i-1];
 		val =val + (((int) ch) - 48) * power(10, size-i) ;
 		//val = val - 48;
 
 		i--;
 	}
 
 	return val;
 }
 // power function
 int power(int i,int j)
 {
 	int t,val=1;
 	for(t=1;t<=j;t++)
 		val = val * i;
 
 	return val;
 }
 //QuickSort function
 void quicksort(int a, int b,int *A)
 { 
 	int rtidx=0,ltidx=0,k=a,l=0,pivot; 
 	int leftarr[1000],rtarr[1000];  
 	pivot=A[a]; 
 
 	if(a==b)
 		return; 
 	
 	while(k<b)
 	{
 		++k;
 		if(A[k]<A[a])
 		{
 			leftarr[ltidx]=A[k];
 			ltidx++;
 		}
 		else
 		{
 			rtarr[rtidx]=A[k];
 			rtidx++;
 		}
 	}
 
 	k=a;
 	
 	for(l=0;l<ltidx;++l)
 		A[k++]=leftarr[l];
 	A[k++]=pivot;
 	
 	for(l=0;l<rtidx;++l)
 		A[k++]=rtarr[l];
 
 	if(ltidx>0)
 		quicksort(a,a+ltidx-1,A);
 	
 	if(rtidx>0)
 		quicksort(b-rtidx+1,b,A);
 
 }

