#include<stdio.h>
 #include<malloc.h>
 #include<stdlib.h>
 #include<string.h>
 #define MAX 1000
 #define MAXSIZE 100
 
 struct s_engine
 {
        char *name;
        int occur;
        int found;
 
 }search_engine[MAXSIZE];
 
 
 
 int find_max(int dista[],int num)
 {
 
   int max,m,i;
    max=dista[0];
   m=0;
   for(i=0;i<num;i++)
   {
     if(max<dista[i])
      {
       max=dista[i];
       m=i;
      }
   }
   return m;
 }
 
 
 
 //**************************** MAIN*************************************
 main()
 {
 
    int f,i=0,j,ff,dist,k;
 
 
    int no_of_switch=0,no_of_engine,no_of_query,no_of_inputs,call,num=1,flag;
    char *query_string[MAX],buf[MAXSIZE];
    int distance[MAXSIZE];
    FILE *fp ,*fp1;
  
  if(( fp=fopen("c:\\test4.in","r"))==NULL)
  {
       printf("cant opn file");
       system("pause");
       return 1;
 }     
 if(( fp1=fopen("c:\\test.out","w"))==NULL)
  {
       printf("cant opn file");
       return 1;
 }     
 
 //printf("\n Enter the number of search engines : ");
 while(fgets(buf,100,fp))
 {
                         //gets(buf);
                         sscanf(buf,"%d",&no_of_inputs);
 while((no_of_inputs--)!=0)
 {
                           i=0;
                         dist=0;
                          flag=0;    
                          fgets(buf,100,fp);
                          sscanf(buf,"%d",&no_of_engine);
 //table initialization
                       while( i < no_of_engine )
                       {
 	                   search_engine[i].name=(char *)malloc(MAXSIZE*sizeof(char));
 	                   fgets(search_engine[i].name,100,fp);
 	//printf("%d",i);
 	                   search_engine[i].found=0;
 	                   i++;
                      }
 
 //printf("\n Enter the number of query strings \n");
 //gets(buf);
              fgets(buf,100,fp);
              sscanf(buf,"%d",&no_of_query);
 
 
 //printf("\n Start entering the query strings");
 
              for(i=0;i<no_of_query;i++)
              {
              query_string[i]=(char*)malloc(MAXSIZE*sizeof(char));
              fgets(query_string[i],100,fp);
              }
 
 
              no_of_switch=0;
              i=0;
              flag=0;
 while(i!= no_of_query)
 {
              ff=0;
              flag=0;
              while(ff!=no_of_engine)
              {
               dist=0;
 	                 for(j=i;j<no_of_query;j++)
 	                 {
                       if(strcmpi(search_engine[ff].name,query_string[j]) ) //table[ff]!=string[j])
 		              {
 			           dist++;
 		               }
                        else
 	                   {
 		                search_engine[ff].occur=j;
                         search_engine[ff].found=1;
 		                break;
 	                    }
                     }
 
 	                if(dist==no_of_query || search_engine[ff].found==0)
 	                {
 		            flag=1;
 		            break;
 	                }
 	                else
 	                {
 		            distance[ff]=dist;
 		            ++ff;
 	                }
                 }//end of while
 	         if( flag)
 		         break;
 
        call=find_max(distance,no_of_engine);
        i=search_engine[call].occur  ;
        for(k=0;k<no_of_engine;k++)
        {
 		search_engine[k].found=0;
 		search_engine[k].occur=0;
        }
        no_of_switch++;
 }
 fprintf(fp1,"Case #%d: %d\n" ,num, no_of_switch);
 num++;
 }
 }
 system("pause");
 return 0;
 }
 

