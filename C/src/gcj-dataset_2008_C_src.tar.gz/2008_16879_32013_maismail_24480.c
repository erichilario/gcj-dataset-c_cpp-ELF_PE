
 #include <stdio.h>
 #include <math.h>
  
 int getMinimum(int * flags, int size,int exclude);
 void computeFlags(int * flags,char ** searchEngineNames , char **queries ,int noOfSearchEngines ,int noOfQueries );
 int main (void )
 {
 
  int x;
  FILE* out = fopen("output.txt","w");
  FILE* f = fopen ("file.txt","r");
  int noOfSwitches = 0;
  if(f == 0) return 0;
  int j ,i , k;
  int noOfCases = 0 ;
  fscanf(f,"%d",&noOfCases);
 
 
  for( j= 0 ; j<noOfCases; j++)  
  {
   int noOfSearchEngines = 0 ;
   fscanf(f,"%d",&noOfSearchEngines);
 	//printf("no Of search %d\n",noOfSearchEngines);
   getc(f);
 	
   char ** searchEngineNames = malloc (noOfSearchEngines * sizeof(*searchEngineNames ));
   char c ;
   int counter = 0 ;
   for(i = 0 ; i<noOfSearchEngines; i++)
   {
 	searchEngineNames[i] = malloc (100);
 	counter = 0;
 	c = getc(f);
 	while ( c != '\n')
 	{
 		searchEngineNames[i][counter] = c;
 		counter ++;
 		c = getc(f);
 	}
   }
   
   int noOfQueries = 0;
   fscanf(f,"%d",&noOfQueries );
   getc(f);
    //printf("no Of Que %d\n",noOfQueries);
   char ** queries = malloc (noOfQueries * sizeof(*queries ));
   for (i = 0 ; i < noOfQueries ; i++)
   {
 	 queries[ i] = malloc(100) ;
 	counter = 0;
         c = getc(f);
 	while ( c != '\n')
 	{
 		queries[ i][counter] = c;
 		counter ++;
 		c = getc(f);
 	}
 	queries[ i][counter]  = '\0';
   }
 
  	int * flags = malloc (noOfSearchEngines*sizeof(int));
 	int currentSearchIndex  = -1;
 	while (noOfQueries > 0)
 	{
 		computeFlags(flags,searchEngineNames,queries,noOfSearchEngines,noOfQueries);
 		currentSearchIndex = getMaximum(flags,noOfSearchEngines,currentSearchIndex ) ; 
 		
 		if(flags[currentSearchIndex] == noOfQueries )
 		{
 			noOfSearchEngines = 0 ;
 			noOfQueries = 0 ;
 		}
 		else
 		{
 			noOfSwitches++;		
 			noOfQueries -= flags[currentSearchIndex];
 			queries += flags[currentSearchIndex];
 		}
 	}
 	fprintf(out,"Case #%d: %d\n",j+1,noOfSwitches);		
   	noOfSwitches = 0 ;
  }
 }
 
 void computeFlags(int * flags,char ** searchEngineNames , char **queries ,int noOfSearchEngines ,int noOfQueries )
 {
 	int k ,i;
 	for(k = 0 ; k<noOfSearchEngines; k++)
   	{
 		flags[k] = 0 ;
 		for(i = 0 ; i <noOfQueries; i++ )
 		{
 
 			if(strcmp(queries[i],searchEngineNames[k]) != 0)
 			{			
 				flags[k]++;
 			}
 			else
 			{
 				break;
 			}
 		}
   	}	
 	
 }
 int getMaximum(int * flags, int size,int exclude)
 {
 	
 	int i = 0 ;
 	int  max;
 	int index ;
 	if (exclude != 0)
 	{
 	 max = flags[0];
  	index = 0;
 	}
 	else 
 	{
 	 max = flags[1];
  	index = 1;
 	}
 	for ( i = 1 ; i < size; i++)
 	{	
 		
 		if(i == exclude)
 		continue;
 		if(flags[i] > max)
 		{	
 			max = flags[i];
 			index = i;
 
 		}
 	}	
 
 	return index;
 }

