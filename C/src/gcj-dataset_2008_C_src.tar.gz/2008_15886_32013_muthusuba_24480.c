#include <stdio.h>
 #include "data.h"
 
 
 void main(int dummy, char *argc[])
 {
     g_data *data;
     data = load_file(argc[1]);
 //    debug_g_data(data);
 //    free_data(data);
 }

