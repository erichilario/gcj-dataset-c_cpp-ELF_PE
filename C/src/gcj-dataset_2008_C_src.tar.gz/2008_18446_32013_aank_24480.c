#include<stdio.h>
 #include<string.h>
 #include<alloc.h>
 #include<conio.h>
 #define M1 120
 #define M2 1010
 
 
 int solution(char *[],char *[],int,int);
 
 void main()
 {
 	 FILE *f1,*f2;
 	 char *s[M1],*kword[M2],string[M1];
 	 int i,j,z=0,k,length,x,value,y;
 	 clrscr();
 
 	 f1=fopen("switch.txt","r");
 	 if(f1==NULL)
 	 {
 		  printf("\nCannot open input file...");
 	 }
 	 else
 	 {
 		  f2=fopen("ans.txt","w");
 		  if(f2==NULL)
 		  {
 				printf("\nCannot open output file");
 		  }
 
 
 		  else
 		  {
 				fscanf(f1," %[^\n]s",string);
 				fgetc(f1);
 				length=strlen(string);
 				for(i=0;i<length;i++)
 				{
 					z=z*10+(string[i]-48);
 				}
 				for(k=0;k<z;k++)
 				{
 					x=0;y=0;
 
 					fscanf(f1," %[^\n]s",string);
 					fgetc(f1);
 					length=strlen(string);
 					for(i=0;i<length;i++)
 					{
 						 x=x*10+(string[i]-48);
 					}
 					for(j=0;j<x;j++)
 					{
 						fscanf(f1," %[^\n]s",string);
 
 						fgetc(f1);
 						length=strlen(string);
 						s[j]=(char *)malloc((length+1)*sizeof(char));
 						if(s[j]==NULL)
 						{
 							printf("\ndont have enough memory");
 							break;
 						}
 						strcpy(s[j],string);
 
 					}
 					fscanf(f1," %[^\n]s",string);
 					fgetc(f1);
 					length=strlen(string);
 					for(i=0;i<length;i++)
 					{
 						 y=y*10+(string[i]-48);
 					}
 					for(j=0;j<y;j++)
 					{
 						fscanf(f1," %[^\n]s",string);	fgetc(f1);
 						length=strlen(string);
 						kword[j]=(char *)malloc((length+1)*sizeof(char));
 						if(kword[j]==NULL)
 						{
 							printf("\ndont have enough memory");
 							break;
 						}
 						strcpy(kword[j],string);
 					}
 
 					value=solution(s,kword,y,x);
 
 
 					for(i=0;i<y;i++)
 						free(kword[i]);
 
 					for(i=0;i<x;i++)
 						free(s[i]);
 
 
 
 					printf("\nCase #%d: %d",k+1,value);
 					fprintf(f2,"Case #%d: %d\n",k+1,value);
 				}
 		  }
 		  fclose(f2);
 	 }
 	 fclose(f1);
 	 getch();
 }
 
 int solution(char *s[],char *kword[],int i,int j)
 {
 	int num=0,k,a[M1]={0},value=0,p,l;
 
 	for(k=0;k<i;k++)
 	{
 		for(l=0;l<j;l++)
 		{
 			if(!strcmp(kword[k],s[l]))
 			{
 				if(a[l]==0)
 				{
 					num++;
 					a[l]=1;
 				}
 
 				if(num==j)
 				{
 					num=1;
 					for(p=0;p<j;p++)
 						a[p]=0;
 					value++;
 					a[l]=1;
 				}
 
 				break;
 			}
 		}
 	}
 	return value;
 }
