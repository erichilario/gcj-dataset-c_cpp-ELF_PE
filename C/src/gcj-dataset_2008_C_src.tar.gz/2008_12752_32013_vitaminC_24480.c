#include <stdio.h>
 #include <string.h>
 
 #define CLR_NL(str) \
 	do { \
 		int n; \
 		if ( str && (n=strlen(str)) && str[n-1] == '\n' ) \
 			str[n-1] = '\0'; \
 	} while(0)
 
 #define LINE_SZ 200
 #define NAME_SZ 101
 #define S_MAX 100
 #define Q_MAX 1000
 
 FILE *inf; 
 
 void getline(char *line)
 {
 	line[0] = '\0';
 	fgets(line, LINE_SZ, inf);
 	CLR_NL(line);
 	if(!line[0])
 	{
 		printf("Input file invalid\n");
 		exit(1);
 	}
 
 }
 
 int index_of(char *name, int S, char s_name[][NAME_SZ])
 {
 	int i;
 	for(i = 0; i < S; i++)
 		if(strcmp(name, s_name[i]) == 0)
 			return i;
 	return -1;
 }
 
 int get_max(int *arr, int num, int *max_indx)
 {
 	int i, max = arr[0];
        	*max_indx = 0;
 	for(i = 1; i < num; i++)
 		if(arr[i] > max)
 		{
 			max = arr[i];
 			*max_indx = i;
 		}
 	return max;
 }
 
 int getswno(int S, char s_name[][NAME_SZ], int Q, char q_name[][NAME_SZ])
 {
 	/* range is upto (not including) which index of query a search engine entry can service
 	 * without needing to switch */
 	int *range;
 	int i, lim = Q, j;
 	int swno = 0, max_range, start = 0, max_indx;
 
 
 	range = (int *)malloc(S * sizeof(int));
 
 
 	for(;; swno++)
 	{
 		/* initialize range */
 		for(i = 0; i < S; i++)
 			range[i] = lim;
 
 		for(i = start; i < Q; i++)
 		{
 			if((j = index_of(q_name[i], S, s_name)) >= 0)
 				if(range[j] == lim)
 					range[j] = i;
 		}
 		max_range = get_max(range, S, &max_indx);
 		/***************************************************/
 		/*
 		printf("from q indx %d to %d, use %s\n", start, max_range-1, s_name[max_indx]);
 		*/
 
 		if(max_range == lim) /* unique search engine exists which can cover all */
 			break;
 
 		start = max_range;
 	}
 
 	if(range)
 		free(range);
 	return swno;
 }
 
 int main(int argc, char *argv[])
 {
 
 	int N; /* num of tst cases */
 	int i;
 	char line[LINE_SZ];
 
 	if(argc != 2)
 	{
 		printf("Give 1st arg = input file name\n");
 		exit(1);
 	}
 
 	inf = fopen(argv[1], "r");
 	if(!inf)
 	{
 		printf("Could not open input file\n");
 		exit(1);
 	}
 
 	getline(line);
 	sscanf(line, "%d", &N);
 
 	for(i = 0; i < N; i++)
 	{
 		int S; /* max 100 */
 		char s_name[S_MAX][NAME_SZ];
 		int j;
 		int Q; /* max 1000 */
 		char q_name[Q_MAX][NAME_SZ];
 
 		getline(line);
 		sscanf(line, "%d", &S);
 
 		for(j = 0; j < S; j++)
 		{
 			getline(s_name[j]);	
 		}
 
 		getline(line);
 		sscanf(line, "%d", &Q);
 
 		for(j = 0; j < Q; j++)
 		{
 			getline(q_name[j]);	
 		}
 
 		/* output */
 		printf("Case #%d: %d\n", i+1, getswno(S, s_name, Q, q_name));
 	}
 	return 0;
 }
 

