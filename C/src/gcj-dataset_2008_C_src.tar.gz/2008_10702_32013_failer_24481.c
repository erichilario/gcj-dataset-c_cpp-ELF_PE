#include <stdio.h>
 
 enum {
 	MAXN = 100,
 	MAXVALUE = 99999
 };
 
 int astart[MAXN],  aend[MAXN];
 int bstart[MAXN],  bend[MAXN];
 int aqueuearr[MAXN],  bqueuearr[MAXN];
 int *aqueue, *bqueue;
 int aqlen, bqlen;
 
 void inqueue(int * queue, int value, int *plen)
 {
 	int idx, k;
 	int len = *plen;
 	for (idx=0; idx<len; idx++)
 	{
 		if (value < queue[idx])
 			break;
 	}
 	for (k=len;k>idx;k--)
 		queue[k]= queue[k-1];
 	queue[idx]=value;
 	(*plen)++;
 }
 
 void outqueue(int **pqueue, int *plen)
 {
 	(*pqueue) ++;
 	(*plen)--;
 }
 
 void quickSort(int* start, int *end,int startPos, int endPos,int t) 
 { 
     int i,j; 
     int ch, chend; 
     ch=start[startPos];
 	chend = end[startPos];
     i=startPos; 
     j=endPos; 
     if(t==0) 
     {
         while(i<j) 
         { 
             while(start[j]>=ch && i<j)--j; 
             start[i]=start[j];
 			end[i]=end[j];
             while(start[i]<=ch && i<j)++i; 
             start[j]=start[i];
 			end[j]=end[i]; 
         } 
         start[i]=ch; 
 		end[i]=chend; 
         if(i-1>startPos) quickSort(start, end,startPos,i-1,t); 
         if(endPos>i+1) quickSort(start, end,i+1,endPos,t); 
     } 
     else 
     { 
         while(i<j) 
         { 
             while(start[j]<=ch&&i<j) --j; 
             start[i]=start[j];
 			end[i]=end[j];
             while(start[i]>=ch&&i<j) ++i; 
             start[j]=start[i];
 			end[j]=end[i]; 
         } 
         start[i]=ch; 
 		end[i]=chend; 
         if(i-1>startPos) quickSort(start, end,startPos,i-1,t); 
         if(endPos>i+1) quickSort(start, end,i+1,endPos,t); 
     } 
 } 
 
 
 
 void main()
 {
 	int n, i, k;
 	int turnaround;
 	int na, nb;
 	int hour,minute;
 	int atrain, btrain;
 	int aready, bready;
 	int apos, bpos;
 	int now;
 	int turntime;
 	int atime, btime;
 
 	FILE *inf, *outf;
 
 	//aqueue[0] = bqueue[0] = MAXVALUE;
 
 	inf = fopen("train_in.txt","r");
 	outf = fopen("train_out.txt","w");
 
 	fscanf(inf,"%d", &n);
 	for (i=0; i<n; i++)
 	{
 		fscanf(inf,"%d",&turnaround);
 		fscanf(inf,"%d%d", &na, &nb);
 		for (k=0;k<na;k++)
 		{
 			fscanf(inf,"%d:%d",&hour,&minute);
 			astart[k] = hour * 60 + minute;
 			fscanf(inf,"%d:%d",&hour,&minute);
 			aend[k] = hour * 60 + minute + turnaround;
 		}
 		for (k=0;k<nb;k++)
 		{
 			fscanf(inf,"%d:%d",&hour,&minute);
 			bstart[k] = hour * 60 + minute;
 			fscanf(inf,"%d:%d",&hour,&minute);
 			bend[k] = hour * 60 + minute + turnaround;
 		}
 		quickSort(astart, aend, 0, na-1,0);
 		quickSort(bstart, bend, 0, nb-1,0);
 		atrain = btrain = 0;
 		aready = bready = 0;
 		apos = bpos = 0;
 		bqueue = bqueuearr;
 		aqueue = aqueuearr;
 		aqlen = bqlen = 0;
 		now = 0;
 
 		for (;(apos<na) || (bpos<nb);)
 		{
 			//жϷnow
 			if (apos<na)
 				atime = astart[apos];
 			else
 				atime = 9999;
 			if (bpos<nb)
 				btime = bstart[bpos];
 			else
 				btime = 9999;
 			if (atime < btime)
 			{//a start
 				now = atime;
 				//outqueue, ready
 				if (aqlen >0)
 				{
 					turntime = *aqueue;
 					if (turntime<=now)
 					{
 						aready++;
 						outqueue(&aqueue,&aqlen);
 					}
 				}
 
 				//atrain, inqueue, pos
 				if (aready>0)
 				{
 					aready--;
 				} else {
 					atrain++;
 				}
 				inqueue(bqueue, aend[apos], &bqlen);
 				apos++;
 			} else {//if (atime < btime)
 				//bstart
 				now = btime;
 				//outqueue, ready
 				if (bqlen >0)
 				{
 					turntime = *bqueue;
 					if (turntime<=now)
 					{
 						bready++;
 						outqueue(&bqueue,&bqlen);
 					}
 				}
 				//atrain, inqueue, pos
 				if (bready>0)
 				{
 					bready--;
 				} else {
 					btrain++;
 				}
 				inqueue(aqueue, bend[bpos], &aqlen);
 				bpos++;
 			}//if (atime < btime)
 		}//for (;(apos<na) || (bpos<nb);)
 		fprintf(outf, "Case #%d: %d %d\n", i+1, atrain, btrain);
 	}//for (i=0; i<n; i++)
 	
 	fclose(inf);
 	fclose(outf);
 }
