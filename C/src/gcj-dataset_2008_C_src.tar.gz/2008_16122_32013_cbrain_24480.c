#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define MAX_SEARCH_ENGINES 100
 static unsigned int number_of_search_engines;
 static char *search_engine_names[MAX_SEARCH_ENGINES];
 
 #define MAX_QUERIES 1000
 static unsigned int number_of_queries;
 static unsigned int queries[MAX_QUERIES];
 static unsigned int switches_up_to_query[MAX_QUERIES][MAX_SEARCH_ENGINES];
 
 unsigned int
 search_for_optimum(unsigned int current_search_engine,
 					unsigned int query_offset,
 					unsigned int switches,
 					unsigned int best_so_far)
 {
 	unsigned int search_engine;
 	unsigned int this_one;
 
 	while (query_offset < number_of_queries)
 	{
 		if (queries[query_offset] == current_search_engine)
 			break;
 
 		if (switches_up_to_query[query_offset][current_search_engine] <= switches)
 			return MAX_QUERIES;
 		switches_up_to_query[query_offset][current_search_engine] = switches;
 
 		query_offset++;
 	}
 	if (query_offset >= number_of_queries)
 		return switches;
 
 	if (switches_up_to_query[query_offset][current_search_engine] <= switches)
 		return MAX_QUERIES;
 	switches_up_to_query[query_offset][current_search_engine] = switches;
 
 	switches++;
 	if (switches > best_so_far)
 		return switches;
 
 	for (search_engine = 0;
 			search_engine < number_of_search_engines; search_engine++)
 	{
 		if (search_engine == current_search_engine)
 			continue;
 
 		this_one = search_for_optimum(search_engine,
 				query_offset, switches, best_so_far);
 		if (this_one < best_so_far)
 			best_so_far = this_one;
 	}
 
 	return best_so_far;
 }
 
 int
 main(void)
 {
 	char line[1024];
 	unsigned int number_of_test_cases;
 	unsigned int test_case_number;
 	unsigned int i, j;
 	unsigned int optimal_number_of_switches;
 	unsigned int number_of_switches;
 
 	fgets(line, sizeof line, stdin);
 	number_of_test_cases = (unsigned int)atoi(line);
 
 	for (test_case_number = 1; test_case_number <= number_of_test_cases;
 			test_case_number++)
 	{
 		fgets(line, sizeof line, stdin);
 		number_of_search_engines = (unsigned int)atoi(line);
 
 		for (i = 0; i < number_of_search_engines; i++)
 		{
 			fgets(line, sizeof line, stdin);
 			search_engine_names[i] = strdup(line);
 			if (!search_engine_names[i])
 				abort();
 		}
 
 		fgets(line, sizeof line, stdin);
 		number_of_queries = (unsigned int)atoi(line);
 
 		for (i = 0; i < number_of_queries; i++)
 		{
 			fgets(line, sizeof line, stdin);
 			queries[i] = number_of_search_engines;
 			for (j = 0; j < number_of_search_engines; j++)
 				switches_up_to_query[i][j] = MAX_QUERIES;
 			for (j = 0; j < number_of_search_engines; j++)
 			{
 				if (!strcmp(line, search_engine_names[j]))
 				{
 					queries[i] = j;
 					break;
 				}
 			}
 		}
 
 		optimal_number_of_switches = MAX_QUERIES;
 		for (i = 0; i < number_of_search_engines; i++)
 		{
 			fprintf(stderr, "Trying initial search engine %u ... ", i);
 			fflush(stderr);
 
 			number_of_switches = search_for_optimum(i,
 					0, 0, optimal_number_of_switches);
 			if (number_of_switches < optimal_number_of_switches)
 				optimal_number_of_switches = number_of_switches;
 
 			fprintf(stderr, "done (%u switches, %u optimal)\n",
 					number_of_switches, optimal_number_of_switches);
 		}
 
 		printf("Case #%d: %d\n", test_case_number, optimal_number_of_switches);
 
 		for (i = 0; i < number_of_search_engines; i++)
 			free(search_engine_names[i]);
 	}
 
 	return 0;
 }
 
 /* vim:ts=4:sw=4
  */

