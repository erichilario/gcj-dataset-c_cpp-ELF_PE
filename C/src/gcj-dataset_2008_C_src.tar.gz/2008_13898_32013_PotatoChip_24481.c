/*****************************************************/
 /* Date : 2008.07.17                                 */
 /* Author : HHJeon                                   */
 /* Description : Google Code Jam, Qualification Round, */
 /*               Train Timetable                     */
 /*****************************************************/
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define RET_OK 1
 #define RET_ERROR -1
 
 /*###################################################*/
 typedef struct _TIMETABLE{
 	int nDeparture;
 	int nArrival;
 	char bTrain;
 }TimeTable;
 
 typedef struct _LINK_TIMETABLE{
 	TimeTable Time_Train;
 	struct _LINK_TIMETABLE *pNext;
 }LinkTimeTable;
 
 int ProcTT(FILE *fpInFile, FILE *fpOutFile);
 int ComputeTrainCount(TimeTable *pATimeTable, int nNACount, TimeTable *pBTimeTable, int nNBCount, int nTurnAroundTime, int *pNATCount, int *pNBTCount);
 int FreeMemory(TimeTable *pATimeTable, TimeTable *pBTimeTable);
 #if 0
 int InsertTrain(LinkTimeTable *pLinkTimeTable, int nCurTime, int *pLinkCount);
 int MoveToTrain(LinkTimeTable *pLinkTimeTable1, int *pLinkCount1, LinkTimeTable *pLinkTimeTable2, int *pLinkCount2);
 int RemoveCurTime(LinkTimeTable *pLinkTimeTable, int nCurTime, int *pLinkCount);
 #endif
 #define SWAP(x,y,z) ((z)=(x), (x)=(y), (y)=(z))
 int SimpleSortArrivalASC(TimeTable *pTimeTable, int nCount);
 int SimpleSortDepartureASC(TimeTable *pTimeTable, int nCount);
 void PrintTimeTable(LinkTimeTable *pLinkTimeTable);
 /*###################################################*/
 
 int main(int argc, char* argv[])
 {
 	FILE *fpInFile, *fpOutFile;
 	char *sOutFileName = NULL;
 	int nOutFileNameSize = 0;
 	
 	/*+--------------------------------------------------*/
 	if(argc != 2)
 	{
 		if(NULL != strrchr(argv[0], '\\'))
 		{
 			printf("Usage %s input_file\n", strrchr(argv[0], '\\') + 1);
 		}
 		else
 		{
 			printf("Usage %s input_file\n", argv[0]);
 		}
 		return RET_ERROR;
 	}
 	/*---------------------------------------------------*/
 
 	/*+--------------------------------------------------*/
 	nOutFileNameSize = strlen(argv[1]) + 5;
 	sOutFileName = (char *)malloc(sizeof(char) * nOutFileNameSize);
 	if(sOutFileName == NULL)
 	{
 		printf("Insufficient memory available\n");
 		return RET_ERROR;
 	}
 	memset(sOutFileName, 0, nOutFileNameSize);
 	sprintf(sOutFileName, "%s.out", argv[1]);
 	/*---------------------------------------------------*/	
 
 	/*+--------------------------------------------------*/
 	fpInFile = (FILE *)fopen(argv[1], "r");
 	if(fpInFile == NULL)
 	{
 		printf("The file '%s' was not opened\n", argv[1]);
 		return RET_ERROR;
 	}
 	/*---------------------------------------------------*/
 
 	/*+--------------------------------------------------*/
 	fpOutFile = (FILE *)fopen(sOutFileName, "w");
 	if(fpOutFile == NULL)
 	{
 		printf("The file '%s' was not opened\n", sOutFileName);
 		return RET_ERROR;
 	}
 	/*---------------------------------------------------*/
 
 	/*###################################################*/
 	if(RET_ERROR == ProcTT(fpInFile, fpOutFile))
 	{
 		printf("Error.\n");
 	}
 	/*###################################################*/
 
 	/*+--------------------------------------------------*/
 	fclose(fpOutFile);
 
 	fclose(fpInFile);
 
 	free(sOutFileName);
 	/*---------------------------------------------------*/
 
 	return RET_OK;
 }
 
 int ProcTT(FILE *fpInFile, FILE *fpOutFile)
 {
 	int n = 0;
 	int i = 0, j = 0;
 	long nCount = 0;
 	int nTurnAroundTime = 0;
 	int nNACount = 0, nNBCount = 0;
 	int nNATCount = 0, nNBTCount = 0;
 	int nDHour = 0, nDMin = 0, nAHour = 0, nAMin = 0;
 	TimeTable *pATimeTable = NULL, *pBTimeTable = NULL;
 
 	/*+--------------------------------------------------*/
 	if(EOF == fscanf(fpInFile, "%ld\n", &nCount))
 	{
 		return RET_ERROR;
 	}
 	/*---------------------------------------------------*/
 	
 	/*+--------------------------------------------------*/
 	for(n = 0; n < nCount; n++)
 	{
 		fscanf(fpInFile, "%ld\n", &nTurnAroundTime);
 		fscanf(fpInFile, "%d %d\n", &nNACount, &nNBCount);
 //		printf("--------------------------------------------------------\n");
 //		printf("%d\n", nTurnAroundTime);
 //		printf("%d %d\n\n", nNACount, nNBCount);
 
 
 		pATimeTable = (TimeTable*)malloc(sizeof(TimeTable) * nNACount);
 		pBTimeTable = (TimeTable*)malloc(sizeof(TimeTable) * nNBCount);
 		if(pATimeTable == NULL || pBTimeTable == NULL)
 		{
 			printf("Insufficient memory available\n");
 			FreeMemory(pATimeTable, pBTimeTable);
 			return RET_ERROR;
 		}
 		for(i = 0; i < nNACount; i++)
 		{
 			fscanf(fpInFile, "%d:%d %d:%d\n", &nDHour, &nDMin, &nAHour, &nAMin);
 			pATimeTable[i].nDeparture = nDHour * 60 + nDMin;
 			pATimeTable[i].nArrival = nAHour * 60 + nAMin;
 			pATimeTable[i].bTrain = 0;
 		}
 		for(i = 0; i < nNBCount; i++)
 		{
 			fscanf(fpInFile, "%d:%d %d:%d\n", &nDHour, &nDMin, &nAHour, &nAMin);
 			pBTimeTable[i].nDeparture = nDHour * 60 + nDMin;
 			pBTimeTable[i].nArrival = nAHour * 60 + nAMin;
 			pBTimeTable[i].bTrain = 0;
 		}
 
 		ComputeTrainCount(pATimeTable, nNACount, pBTimeTable, nNBCount, nTurnAroundTime, &nNATCount, &nNBTCount);
 
 //		printf("Case #%d: %d %d\n", n+1, nNATCount, nNBTCount);
 //		printf("--------------------------------------------------------\n");
 
 		fprintf(fpOutFile, "Case #%d: %d %d\n", n+1, nNATCount, nNBTCount);
 		/*+--------------------------------------------------*/
 		FreeMemory(pATimeTable, pBTimeTable);
 		/*---------------------------------------------------*/
 	}
 	/*---------------------------------------------------*/
 
 	return RET_OK;
 }
 
 int ComputeTrainCount(TimeTable *pATimeTable, int nNACount, TimeTable *pBTimeTable, int nNBCount, int nTurnAroundTime, int *pNATCount, int *pNBTCount)
 {
 	int i = 0, j = 0, k = 0;
 	int nNAC = 0, nNBC = 0;
 	LinkTimeTable *pALinkTimeTable = NULL, *pBLinkTimeTable = NULL;
 	LinkTimeTable *pNewLinkTimeTable = NULL, *pCurLinkTimeTable = NULL, *pPrevLinkTimeTable = NULL;
 	int nALinkCount = 0, nBLinkCount = 0;
 	int nCurTime = 0, nArrivalTime = 0;
 	char bFirst = 0;
 
 	*pNATCount = 0;
 	*pNBTCount = 0;
 	nNAC = nNACount;
 	nNBC = nNBCount;
 
 	/*+--------------------------------------------------*/
 	SimpleSortDepartureASC(pATimeTable, nNACount);
 	SimpleSortDepartureASC(pBTimeTable, nNBCount);
 
 	for(i = 0; i < nNACount; i++)
 	{
 		if(i == 0)
 		{
 			pALinkTimeTable = (LinkTimeTable*)malloc(sizeof(LinkTimeTable));
 			pALinkTimeTable->Time_Train.nDeparture = pATimeTable[i].nDeparture;
 			pALinkTimeTable->Time_Train.nArrival = pATimeTable[i].nArrival;
 			pALinkTimeTable->Time_Train.bTrain = pATimeTable[i].bTrain;	
 			pALinkTimeTable->pNext = NULL;
 			pCurLinkTimeTable = pALinkTimeTable;
 		}
 		else
 		{
 			pCurLinkTimeTable->pNext = (LinkTimeTable*)malloc(sizeof(LinkTimeTable));
 			pCurLinkTimeTable = pCurLinkTimeTable->pNext;
 			pCurLinkTimeTable->Time_Train.nDeparture = pATimeTable[i].nDeparture;
 			pCurLinkTimeTable->Time_Train.nArrival = pATimeTable[i].nArrival;
 			pCurLinkTimeTable->Time_Train.bTrain = pATimeTable[i].bTrain;	
 			pCurLinkTimeTable->pNext = NULL;			
 		}
 	}
 	nALinkCount = nNACount;
 	for(i = 0; i < nNBCount; i++)
 	{
 		if(i == 0)
 		{
 			pBLinkTimeTable = (LinkTimeTable*)malloc(sizeof(LinkTimeTable));
 			pBLinkTimeTable->Time_Train.nDeparture = pBTimeTable[i].nDeparture;
 			pBLinkTimeTable->Time_Train.nArrival = pBTimeTable[i].nArrival;
 			pBLinkTimeTable->Time_Train.bTrain = pBTimeTable[i].bTrain;	
 			pBLinkTimeTable->pNext = NULL;
 			pCurLinkTimeTable = pBLinkTimeTable;
 		}
 		else
 		{
 			pCurLinkTimeTable->pNext = (LinkTimeTable*)malloc(sizeof(LinkTimeTable));
 			pCurLinkTimeTable = pCurLinkTimeTable->pNext;
 			pCurLinkTimeTable->Time_Train.nDeparture = pBTimeTable[i].nDeparture;
 			pCurLinkTimeTable->Time_Train.nArrival = pBTimeTable[i].nArrival;
 			pCurLinkTimeTable->Time_Train.bTrain = pBTimeTable[i].bTrain;	
 			pCurLinkTimeTable->pNext = NULL;			
 		}
 	}
 	nBLinkCount = nNBCount;
 	/*---------------------------------------------------*/
 	
 	while((nNAC > 0) || (nNBC > 0))
 	{
 		nCurTime = -1;
 		for(pCurLinkTimeTable = pALinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 		{
 			if(pCurLinkTimeTable->Time_Train.bTrain == 0)
 			{
 				nCurTime = pCurLinkTimeTable->Time_Train.nDeparture;
 				break;
 			}
 		}
 		for(pCurLinkTimeTable = pBLinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 		{
 			if(pCurLinkTimeTable->Time_Train.bTrain == 0)
 			{
 				if((nCurTime == -1) || (nCurTime > pCurLinkTimeTable->Time_Train.nDeparture))
 				{
 					nCurTime = pCurLinkTimeTable->Time_Train.nDeparture;
 				}
 				break;
 			}
 		}
 
 		bFirst = 0;
 		for(pCurLinkTimeTable = pALinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 		{
 			if(pCurLinkTimeTable->Time_Train.bTrain == 0)
 			{
 				if(bFirst == 0)
 				{
 					if(nCurTime == pCurLinkTimeTable->Time_Train.nDeparture)
 					{
 						bFirst = 1;
 						nArrivalTime = pCurLinkTimeTable->Time_Train.nArrival;
 					}					
 					break;
 				}
 			}
 		}
 		if(bFirst)
 		{		
 			if(pALinkTimeTable->Time_Train.bTrain == 0)
 			{
 				//InsertTrain(pALinkTimeTable, nCurTime + nTurnAroundTime, &nALinkCount);
 				pNewLinkTimeTable = (LinkTimeTable*)malloc(sizeof(LinkTimeTable));
 				pNewLinkTimeTable->Time_Train.nDeparture = nArrivalTime + nTurnAroundTime;
 				pNewLinkTimeTable->Time_Train.nArrival = -1;
 				pNewLinkTimeTable->Time_Train.bTrain = 1;	
 				pNewLinkTimeTable->pNext = pALinkTimeTable;
 				pALinkTimeTable = pNewLinkTimeTable;
 				nALinkCount += 1;
 
 				*pNATCount += 1;
 			}
 			else
 			{
 				pALinkTimeTable->Time_Train.nDeparture = nArrivalTime + nTurnAroundTime;
 			}
 /*
 			printf("[A]\n");
 			PrintTimeTable(pALinkTimeTable);
 			printf("[B]\n");
 			PrintTimeTable(pBLinkTimeTable);
 			printf("\n");
 */
 			//MoveToTrain(pALinkTimeTable, &nALinkCount, pBLinkTimeTable, &nBLinkCount);
 			pNewLinkTimeTable = pALinkTimeTable;
 			pALinkTimeTable = pALinkTimeTable->pNext;
 			pNewLinkTimeTable->pNext = NULL;
 			nALinkCount -= 1;
 			nNAC--;
 
 			pPrevLinkTimeTable = NULL;
 			for(pCurLinkTimeTable = pBLinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 			{
 				if(pCurLinkTimeTable->Time_Train.nDeparture >= pNewLinkTimeTable->Time_Train.nDeparture)
 				{
 					if(pPrevLinkTimeTable == NULL)
 					{
 						pBLinkTimeTable = pNewLinkTimeTable;
 					}
 					else
 					{
 						pPrevLinkTimeTable->pNext = pNewLinkTimeTable;
 					}
 					pNewLinkTimeTable->pNext = pCurLinkTimeTable;
 
 					nBLinkCount += 1;
 					break;
 				}
 
 				pPrevLinkTimeTable = pCurLinkTimeTable;
 			}
 			if(pCurLinkTimeTable == NULL)
 			{
 				free(pNewLinkTimeTable);
 				pNewLinkTimeTable = NULL;
 			}
 /*
 			printf("[A]\n");
 			PrintTimeTable(pALinkTimeTable);
 			printf("[B]\n");
 			PrintTimeTable(pBLinkTimeTable);
 			printf("\n");
 */
 			//RemoveCurTime(pALinkTimeTable, nCurTime, &nALinkCount);
 			pPrevLinkTimeTable = NULL;
 			for(pCurLinkTimeTable = pALinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 			{
 				if(pCurLinkTimeTable->Time_Train.bTrain == 0)
 				{
 					if(pCurLinkTimeTable->Time_Train.nDeparture == nCurTime)
 					{
 						if(pPrevLinkTimeTable == NULL)
 						{
 							pALinkTimeTable = pCurLinkTimeTable->pNext;
 						}
 						else
 						{
 							pPrevLinkTimeTable->pNext = pCurLinkTimeTable->pNext;
 						}
 						pCurLinkTimeTable->pNext = NULL;
 						free(pCurLinkTimeTable);
 						pCurLinkTimeTable = NULL;
 
 						nALinkCount -= 1;
 						break;
 					}
 				}
 
 				pPrevLinkTimeTable = pCurLinkTimeTable;
 			}
 /*
 			printf("[A]\n");
 			PrintTimeTable(pALinkTimeTable);
 			printf("[B]\n");
 			PrintTimeTable(pBLinkTimeTable);
 			printf("\n");
 */
 		}
 
 		bFirst = 0;
 		for(pCurLinkTimeTable = pBLinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 		{
 			if(pCurLinkTimeTable->Time_Train.bTrain == 0)
 			{
 				if(bFirst == 0)
 				{
 					if(nCurTime == pCurLinkTimeTable->Time_Train.nDeparture)
 					{
 						bFirst = 1;
 						nArrivalTime = pCurLinkTimeTable->Time_Train.nArrival;
 					}					
 					break;
 				}
 			}
 		}
 		if(bFirst)
 		{
 			if(pBLinkTimeTable->Time_Train.bTrain == 0)
 			{
 				//InsertTrain(pBLinkTimeTable, nCurTime + nTurnAroundTime, &nBLinkCount);
 				pNewLinkTimeTable = (LinkTimeTable*)malloc(sizeof(LinkTimeTable));
 				pNewLinkTimeTable->Time_Train.nDeparture = nArrivalTime + nTurnAroundTime;
 				pNewLinkTimeTable->Time_Train.nArrival = -1;
 				pNewLinkTimeTable->Time_Train.bTrain = 1;	
 				pNewLinkTimeTable->pNext = pBLinkTimeTable;
 				pBLinkTimeTable = pNewLinkTimeTable;
 				nBLinkCount += 1;
 
 				*pNBTCount += 1;
 			}
 			else
 			{
 				pBLinkTimeTable->Time_Train.nDeparture = nArrivalTime + nTurnAroundTime;
 			}
 /*
 			printf("[A]\n");
 			PrintTimeTable(pALinkTimeTable);
 			printf("[B]\n");
 			PrintTimeTable(pBLinkTimeTable);
 			printf("\n");
 */
 			//MoveToTrain(pBLinkTimeTable, &nBLinkCount, pALinkTimeTable, &nALinkCount);
 			pNewLinkTimeTable = pBLinkTimeTable;
 			pBLinkTimeTable = pBLinkTimeTable->pNext;
 			pNewLinkTimeTable->pNext = NULL;
 			nBLinkCount -= 1;
 			nNBC--;
 
 			pPrevLinkTimeTable = NULL;
 			for(pCurLinkTimeTable = pALinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 			{
 				if(pCurLinkTimeTable->Time_Train.nDeparture >= pNewLinkTimeTable->Time_Train.nDeparture)
 				{
 					if(pPrevLinkTimeTable == NULL)
 					{
 						pALinkTimeTable = pNewLinkTimeTable;
 					}
 					else
 					{
 						pPrevLinkTimeTable->pNext = pNewLinkTimeTable;
 					}
 					pNewLinkTimeTable->pNext = pCurLinkTimeTable;
 
 					nALinkCount += 1;
 					break;
 				}
 
 				pPrevLinkTimeTable = pCurLinkTimeTable;
 			}
 			if(pCurLinkTimeTable == NULL)
 			{
 				free(pNewLinkTimeTable);
 				pNewLinkTimeTable = NULL;
 			}
 /*
 			printf("[A]\n");
 			PrintTimeTable(pALinkTimeTable);
 			printf("[B]\n");
 			PrintTimeTable(pBLinkTimeTable);
 			printf("\n");
 */
 			//RemoveCurTime(pBLinkTimeTable, nCurTime, &nBLinkCount);		
 			pPrevLinkTimeTable = NULL;
 			for(pCurLinkTimeTable = pBLinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 			{
 				if(pCurLinkTimeTable->Time_Train.bTrain == 0)
 				{
 					if(pCurLinkTimeTable->Time_Train.nDeparture == nCurTime)
 					{
 						if(pPrevLinkTimeTable == NULL)
 						{
 							pBLinkTimeTable = pCurLinkTimeTable->pNext;
 						}
 						else
 						{
 							pPrevLinkTimeTable->pNext = pCurLinkTimeTable->pNext;
 						}
 						pCurLinkTimeTable->pNext = NULL;
 						free(pCurLinkTimeTable);
 						pCurLinkTimeTable = NULL;
 
 						nBLinkCount -= 1;
 						break;
 					}
 				}
 
 				pPrevLinkTimeTable = pCurLinkTimeTable;
 			}
 /*
 			printf("[A]\n");
 			PrintTimeTable(pALinkTimeTable);
 			printf("[B]\n");
 			PrintTimeTable(pBLinkTimeTable);
 			printf("\n");
 */
 		}
 	}
 
 	return RET_OK;
 }
 
 int FreeMemory(TimeTable *pATimeTable, TimeTable *pBTimeTable)
 {
 	if(pATimeTable != NULL)
 	{
 		free(pATimeTable);
 		pATimeTable = NULL;
 	}
 	
 	if(pBTimeTable != NULL)
 	{
 		free(pBTimeTable);
 		pBTimeTable = NULL;
 	}
 
 	return RET_OK;
 }
 
 int SimpleSortArrivalASC(TimeTable *pTimeTable, int nCount)
 {
     int i, j, temp, flag;
 
     for(i = 0; i < nCount-1; i++)
     {
         flag = 0;
         for(j = 0; j < nCount-1-i; j++)
 		{
             if(pTimeTable[j].nArrival > pTimeTable[j+1].nArrival)
             {
                 SWAP(pTimeTable[j].nDeparture, pTimeTable[j+1].nDeparture, temp);
 				SWAP(pTimeTable[j].nArrival, pTimeTable[j+1].nArrival, temp);
 				SWAP(pTimeTable[j].bTrain, pTimeTable[j+1].bTrain, temp);
                 flag = 1;
             }
 			else if(pTimeTable[j].nArrival == pTimeTable[j+1].nArrival)
 			{
 				if(pTimeTable[j].nDeparture > pTimeTable[j+1].nDeparture)
 				{
 					SWAP(pTimeTable[j].nDeparture, pTimeTable[j+1].nDeparture, temp);
 					SWAP(pTimeTable[j].nArrival, pTimeTable[j+1].nArrival, temp);
 					SWAP(pTimeTable[j].bTrain, pTimeTable[j+1].bTrain, temp);
 					flag = 1;
 				}
 			}
 		}
         if(flag == 0)
 		{
 			break;
 		}
     }
 
 	return RET_OK;
 }
 
 int SimpleSortDepartureASC(TimeTable *pTimeTable, int nCount)
 {
     int i, j, temp, flag;
 
     for(i = 0; i < nCount-1; i++)
     {
         flag = 0;
         for(j = 0; j < nCount-1-i; j++)
 		{
             if(pTimeTable[j].nDeparture > pTimeTable[j+1].nDeparture)
             {
                 SWAP(pTimeTable[j].nDeparture, pTimeTable[j+1].nDeparture, temp);
 				SWAP(pTimeTable[j].nArrival, pTimeTable[j+1].nArrival, temp);
 				SWAP(pTimeTable[j].bTrain, pTimeTable[j+1].bTrain, temp);
                 flag = 1;
             }
 			else if(pTimeTable[j].nDeparture == pTimeTable[j+1].nDeparture)
 			{
 				if(pTimeTable[j].nArrival > pTimeTable[j+1].nArrival)
 				{
 					SWAP(pTimeTable[j].nDeparture, pTimeTable[j+1].nDeparture, temp);
 					SWAP(pTimeTable[j].nArrival, pTimeTable[j+1].nArrival, temp);
 					SWAP(pTimeTable[j].bTrain, pTimeTable[j+1].bTrain, temp);
 					flag = 1;
 				}
 			}
 		}
         if(flag == 0)
 		{
 			break;
 		}
     }
 
 	return RET_OK;
 }
 
 #if 0
 int InsertTrain(LinkTimeTable *pLinkTimeTable, int nCurTime, int *pLinkCount)
 {
 	LinkTimeTable *pNewLinkTimeTable = NULL;
 
 	pNewLinkTimeTable = (LinkTimeTable*)malloc(sizeof(LinkTimeTable));
 	pNewLinkTimeTable->Time_Train.nDeparture = nCurTime;
 	pNewLinkTimeTable->Time_Train.nArrival = -1;
 	pNewLinkTimeTable->Time_Train.bTrain = 1;	
 	pNewLinkTimeTable->pNext = pLinkTimeTable;
 	pLinkTimeTable = pNewLinkTimeTable;
 	*pLinkCount += 1;
 
 	return RET_OK;
 }
 
 int MoveToTrain(LinkTimeTable *pLinkTimeTable1, int *pLinkCount1, LinkTimeTable *pLinkTimeTable2, int *pLinkCount2)
 {
 	LinkTimeTable *pNewLinkTimeTable = NULL, *pCurLinkTimeTable = NULL, *pPrevLinkTimeTable = NULL;
 
 	pNewLinkTimeTable = pLinkTimeTable1;
 	pLinkTimeTable1 = pLinkTimeTable1->pNext;
 	pNewLinkTimeTable->pNext = NULL;
 	*pLinkCount1 -= 1;
 
 	for(pCurLinkTimeTable = pLinkTimeTable2; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 	{
 		if(pCurLinkTimeTable->Time_Train.nDeparture >= pNewLinkTimeTable->Time_Train.nDeparture)
 		{
 			pPrevLinkTimeTable->pNext = pNewLinkTimeTable;
 			pNewLinkTimeTable->pNext = pCurLinkTimeTable;
 
 			*pLinkCount2 += 1;
 			break;
 		}
 
 		pPrevLinkTimeTable = pCurLinkTimeTable;
 	}
 
 	return RET_OK;
 }
 
 int RemoveCurTime(LinkTimeTable *pLinkTimeTable, int nCurTime, int *pLinkCount)
 {
 	LinkTimeTable *pCurLinkTimeTable = NULL, *pPrevLinkTimeTable = NULL;
 
 	for(pCurLinkTimeTable = pLinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 	{
 		if(pCurLinkTimeTable->Time_Train.bTrain == 0)
 		{
 			if(pCurLinkTimeTable->Time_Train.nDeparture == nCurTime)
 			{
 				pPrevLinkTimeTable->pNext = pCurLinkTimeTable->pNext;
 				pCurLinkTimeTable->pNext = NULL;
 				free(pCurLinkTimeTable);
 				pCurLinkTimeTable = NULL;
 
 				*pLinkCount -= 1;
 				break;
 			}
 		}
 
 		pPrevLinkTimeTable = pCurLinkTimeTable;
 	}
 
 	return RET_OK;
 }
 #endif
 
 /*
 void PrintTimeTable(LinkTimeTable *pLinkTimeTable)
 {
 	LinkTimeTable *pCurLinkTimeTable = NULL;
 
 	for(pCurLinkTimeTable = pLinkTimeTable; pCurLinkTimeTable != NULL; pCurLinkTimeTable = pCurLinkTimeTable->pNext)
 	{
 		printf("[%d]%d\t%d\n", pCurLinkTimeTable->Time_Train.bTrain, pCurLinkTimeTable->Time_Train.nDeparture, pCurLinkTimeTable->Time_Train.nArrival);
 	}
 }
 */
