/* This Code solves the Fly Swatter Problem of Google Code Jam Competition */
 #include <stdio.h>
 #include <string.h>
 #include <math.h>
 
 #define MAX_ARRAY     2000
 #define FALSE    0
 #define TRUE     1
 
 
 double find_hit_prob(double fly_radius,double racket_radius,double thickness,double string_radius, double string_gap);
 
 int main()
 {
     char s[200];
     int ncase;
     int i;
     double fly_radius;
     double thickness;
     double racket_radius;
     double string_gap;
     double string_radius;
     double hit_prob;
     
 
 
 
     /* Read number of cases*/
     scanf("%d",&ncase);
  
     /* Solve for each case */
     for (i=0;i<ncase;i++)
     {
         /* Read  fly radius, racket radius, thickness, string radius and inter string gap */ 
         scanf("%lg %lg %lg %lg %lg",&fly_radius, &racket_radius, &thickness, &string_radius, &string_gap);
         hit_prob = find_hit_prob(fly_radius,racket_radius,thickness,string_radius,string_gap);
         printf("Case #%d: %f\n",(i+1), hit_prob);
     }
     
     
 
     return 0;
 }
 
 double find_hit_prob(double fly_radius,double racket_radius,double thickness,double string_radius, double string_gap)
 {
     int i,j;
     double eff_inner_rad;
     double rad_sq;
     double gap_proj_on_axis[MAX_ARRAY];
     double right_x, right_y, bottom_x, bottom_y, above_x, above_y, top_x, top_y;
     double eff_gap;
     double total_area, cur_gap_area,total_gap_area;
     double cur_gap_cord;
     double bottom_dist_sq, top_dist_sq, above_dist_sq, right_dist_sq;
     int ngap=0;
     double vert_point, hor_point;
     double hit_prob;
     double theta;
     double vert_point_above, vert_point_top;
     double hor_point_right, hor_point_top;
     double gap_start;
 
     eff_inner_rad = racket_radius - thickness - fly_radius;
     rad_sq = eff_inner_rad*eff_inner_rad;
     gap_start = string_radius+fly_radius;
 
     eff_gap = string_gap-2*fly_radius;  /* Beyond this radius fly will touch racket */
     cur_gap_cord = gap_start;
     while (cur_gap_cord<eff_inner_rad)
     {
          gap_proj_on_axis[ngap] = cur_gap_cord;
          ngap++;
          cur_gap_cord =  cur_gap_cord + eff_gap + 2*fly_radius + 2*string_radius;
     }
     
     total_gap_area = 0;
     for (i=0;i<ngap;i++)
     {
         for (j=0;j<ngap;j++)
         {
             /* For the pair of gap along x-axis and y-axis find 4 corner co-ordinates
                These points are bottom, right above and top */
                
             bottom_x = gap_proj_on_axis[i];
             bottom_y = gap_proj_on_axis[j];
             right_x = bottom_x+eff_gap;
             right_y = bottom_y;
             above_x = bottom_x;
             above_y = bottom_y+eff_gap;
             top_x = right_x;
             top_y = above_y;
 
             /* Calculate square of distance of right above and top point from center of racket */
             top_dist_sq = top_x*top_x+top_y*top_y;
             above_dist_sq = above_x*above_x+above_y*above_y;
             right_dist_sq = right_x*right_x+right_y*right_y;
             bottom_dist_sq = bottom_x*bottom_x+bottom_y*bottom_y;
 
 
 
             /* Calculate area of this gap */
             /* Case 0: Bottom out of circle of interest */
             if (bottom_dist_sq>rad_sq)
             {
                 cur_gap_area = 0;
             }
             /* Case 1: top is within effective inner radius, Full gap is within area of interest */
             else if (top_dist_sq<=rad_sq)
             {
                 cur_gap_area = eff_gap*eff_gap;
             }
             /* Case 2: Both above and right point are out of the circle of interest */
             else if ((above_dist_sq>rad_sq) && (right_dist_sq>rad_sq))
             {
                 vert_point = sqrt(rad_sq - bottom_x*bottom_x);
                 hor_point = sqrt(rad_sq-bottom_y*bottom_y);
                 theta = fabs(asin(bottom_y/eff_inner_rad) - acos(bottom_x/eff_inner_rad));
                 cur_gap_area = rad_sq*0.5*(theta-sin(theta)) + 0.5*(vert_point-bottom_y)*(hor_point-bottom_x);
 
             }
             /* Case 3: Above point is out of circle of interest */
             else if (above_dist_sq>rad_sq)
             {
                 vert_point_above = sqrt(rad_sq - bottom_x*bottom_x);
                 vert_point_top = sqrt(rad_sq - right_x*right_x);
                 theta = fabs(acos(bottom_x/eff_inner_rad) - acos(right_x/eff_inner_rad));
                 cur_gap_area = rad_sq*0.5*(theta-sin(theta)) + 0.5*(vert_point_above-vert_point_top)*eff_gap+
                            eff_gap*(vert_point_top-right_y);
             }
 
             /* Case 4: Right point is out of circle of interest */
             else if (right_dist_sq>rad_sq)
             {
                 hor_point_right = sqrt(rad_sq - bottom_y*bottom_y);
                 hor_point_top = sqrt(rad_sq - above_y*above_y);
                 theta = fabs(asin(above_y/eff_inner_rad) - asin(bottom_y/eff_inner_rad));
                 cur_gap_area = rad_sq*0.5*(theta-sin(theta)) + 0.5*(hor_point_right-hor_point_top)*eff_gap+
                            eff_gap*(hor_point_top-above_x);
             }
             else
             {
                 hor_point_top = sqrt(rad_sq - above_y*above_y);
                 vert_point_top = sqrt(rad_sq - right_x*right_x);
                 theta = fabs(asin(above_y/eff_inner_rad) - asin(vert_point_top/eff_inner_rad));
                 cur_gap_area = rad_sq*0.5*(theta-sin(theta)) + eff_gap*eff_gap - 0.5*(top_x-hor_point_top)*(top_y-vert_point_top);
 
             }
             total_gap_area = total_gap_area+cur_gap_area;
        }
     }
     total_area=M_PI*0.25*racket_radius*racket_radius;
     hit_prob = (total_area-total_gap_area)/total_area;
     return hit_prob;
 }
 
             
           

