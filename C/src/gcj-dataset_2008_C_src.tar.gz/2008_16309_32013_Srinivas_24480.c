#include<stdio.h>
 #include<stdlib.h>
 int checkzero(int count[],int n,int s)
 {
 	int i,flag=0;
 	for(i=0;i<n;i++)
 	{
 		if(count[i]==0 && i!=s)
 		{
 			flag=1;
 			break;
 		}
 	}
 	return flag;
 }
 main()
 {
 	int num,i,j,k,check,total=0,pres;
 	scanf("%d",&num);
 	for(i=0;i<num;i++)
 	{
 		int no;
 		pres=-1;
 		scanf("%d",&no);
 		char engine[no][100];
 		for(j=0;j<no;j++)
 			scanf(" %[^\n]",engine[j]);
 		int noq;
 		scanf("%d",&noq);
 		char query[noq][100];
 		for(j=0;j<noq;j++)
 			scanf(" %[^\n]",query[j]);
 		int count[no];
 		for(j=0;j<no;j++)
 			count[j]=0;
 		for(j=0;j<noq;j++)
 		{
 			for(k=0;k<no;k++)
 			{
 				if(strcmp(query[j],engine[k])==0)
 				{
 					count[k]++;
 					break;
 				}
 			}
 			check = checkzero(count,no,pres);
 			if(check == 0)
 			{
 				total++;
 				pres=k;
 				for(k=0;k<no;k++)
 					count[k]=0;
 			}
 		}
 		printf("Case #%d: %d\n",i+1,total);
 		total = 0;
 	}
 }

