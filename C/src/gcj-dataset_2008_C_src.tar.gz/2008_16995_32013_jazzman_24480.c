#include <stdio.h>
 #include <string.h>
 
 #define NMAX	21
 #define SMAX	101
 #define QMAX	1001
 #define SLENMAX	101
 
 
 int n, s, q;
 char engines[SMAX][SLENMAX];
 int searched[SMAX];
 int available, sol;
 
 void read_engine(char *engine)
 {
     fgets(engine, SLENMAX - 1, stdin);
     if (engine[strlen(engine) - 1] == '\n')
 	engine[strlen(engine) - 1] = 0;
 }
 
 void reset()
 {
     int i;
     
     available = s;
     for (i = 0; i < s; i++)
 	searched[i] = 0;
 }
 
 
 int main(int argc, char **argv)
 {
     int k, i, j;
     char tline[SLENMAX];
 
     scanf("%d", &n);
     for (k = 0; k < n; k++) {
 	scanf("%d", &s);
 	read_engine(tline);
 	for (i = 0; i < s; i++)
 	    read_engine(engines[i]);
 	    
 	reset();
 	sol = 0;
 	
 	scanf("%d", &q);
 	read_engine(tline);
 	for (i = 0; i < q; i++) {
 	    read_engine(tline);
 	    for (j = 0; j < s; j++)
 		if (!strcmp(tline, engines[j])) {
 		    if (!searched[j]) {
 			if (available == 1) {
 			    reset();
 			    sol++;
 			}
 			searched[j] = 1;
 			available--;
 		    }
 		    
 		    break;
 		}
 	}
 	
 	printf("Case #%d: %d\n", k + 1, sol);
     }
 
     return 0;
 }

