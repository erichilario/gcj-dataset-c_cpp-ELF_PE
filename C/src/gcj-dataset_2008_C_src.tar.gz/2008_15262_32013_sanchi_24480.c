/* This Code solves the save universe Problem of Google Code Jam Competition */
 #include <stdio.h>
 #include <string.h>
 
 #define MAX_ENGINE   100
 #define MAX_NAME_LENGTH 128
 #define MAX_NUMBER_OF_QUERY 1000
 #define LARGE_NUM 30000
 
 /* Prototypes */
 void read_engine_names(int num_engines, char en[][MAX_NAME_LENGTH]);
 void read_queries(int num_queries, int num_engines, int queries[], char en[][MAX_NAME_LENGTH]);
 int  get_optimal_number_of_switch(int num_engines, int queries[], int num_queries);
 
 
 
 int main()
 {
     char engine_names[MAX_ENGINE][MAX_NAME_LENGTH];    /* Search engine names */
     char qn[1000][MAX_NAME_LENGTH];    /* Search engine names */
     int queries[MAX_NUMBER_OF_QUERY];
     int i,j;
     int ncase;
     int num_queries;
     int num_engines;
     int opt_num_switch;
     char s[20];
 
 
     /* Read number of cases*/
     gets(s);
     ncase = atoi(s);
  
     /* Solve for each case */
     for (i=0;i<ncase;i++)
     {
 
         /* Read number of engines */
         gets(s);
         num_engines = atoi(s);
 
         /* Read name of engines and store */
         read_engine_names(num_engines,engine_names);
 
         /* Read number of queries */
         gets(s);
         num_queries = atoi(s);
 
         /* Read queries, match with engine names and put the corresponding index in query array */
         read_queries(num_queries, num_engines, queries, engine_names);
         
         /* Get optimal number of switches */
         opt_num_switch=get_optimal_number_of_switch(num_engines, queries, num_queries);
 
         /* Output */
         printf("Case #%d: %d\n",(i+1),opt_num_switch);
 /*
         printf("Engines %d:\n",num_engines);
         for (j=0;j<num_engines;j++)
         {
              puts(engine_names[j]);
         }
         printf("Query %d:\n",num_queries);
         for (j=0;j<num_queries;j++)
         {
              puts(engine_names[queries[j]]);
         }
        
 
 */
 
     }
 
     return 0;
 }
 
 int  get_optimal_number_of_switch(int num_engines, int queries[], int num_queries)
 {
      int min_num_of_switches;
      int switches[MAX_ENGINE];
      int i,j,curr_min;
 
      if (num_queries<2)
      {
           min_num_of_switches=0;
      }
      else
      {
           /* Intialize switch array */
           for (i=0;i<num_engines;i++)
           {
                switches[i]=0;
           }
           switches[queries[0]] = LARGE_NUM;  /* Indicate that first query can not go to corresponding engine. i.e block this engine  */
 
 
           /* For all other queries keep updating switch array */
           /* Rule 1: additional switch required for previously blocked engine */
           /*         This will be one more than current minimum number of switches */
           /* Rule 2: Block the engine corresponding to current query */
           for (i=1;i<num_queries;i++)
           {
                /* Find the current minimum */ 
                curr_min = switches[0];
                for (j=1;j<num_engines;j++)
                {
                     if (switches[j]<curr_min)
                     {
                           curr_min = switches[j];
                     }
                 }
 
                 /* Apply Rule 1 */
                 for (j=0;j<num_queries;j++)
                 {
                      if (switches[j]==LARGE_NUM)
                      {
                          switches[j] = curr_min+1;
                      }
                  }
                  /* Apply Rule 2 */
 
                  switches[queries[i]] = LARGE_NUM;
            }
            /* Find minimum number of switches */
            min_num_of_switches = switches[0];
            for (i=0;i<num_engines;i++)
            {
                if (switches[i]<min_num_of_switches)
                {
                     min_num_of_switches = switches[i];
                }
            }
       }
       return (min_num_of_switches);
 }
 
 
    
 void read_engine_names(int num_engines, char en[][MAX_NAME_LENGTH])
 {
     int i;
 
     for (i=0;i<num_engines;i++)
     {
         gets(en[i]);
     }
     return;
 }
 
 void read_queries(int num_queries, int num_engines, int queries[], char en[][MAX_NAME_LENGTH])
 {
      int i,query_index;
      char s[MAX_NAME_LENGTH];
 
      for (i=0;i<num_queries;i++)
      {
          gets(s);
          /* Match in the engine name list */
          query_index = 0;
          while (strcmp(s,en[query_index]))
          { 
               query_index++;
               if (query_index>=num_engines)
               {
                    printf("Error: Invalid query\n");
                    exit(-1);
               }
          }
          queries[i]=query_index;
      }
      return;
 }
  

