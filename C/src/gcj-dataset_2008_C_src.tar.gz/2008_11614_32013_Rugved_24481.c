#include<stdio.h>
 
 #define MAX 100
 
 
 void PrintArray(int a[], int cnt)
 {
 	int i;
 	
 	printf("\n");
 	for(i=0;i<cnt;i++)
 		printf("%d  ", a[i]);
 	printf("\n");
 }
 
 void Sort(int a[], int cnt)
 {
 	int i,j,t;
 	
 	for(i=0;i<cnt;i++)
 	{
 		for(j=i+1;j<cnt;j++)
 		{
 			if(a[j] < a[i])
 			{
 				t = a[j];
 				a[j] = a[i];
 				a[i] = t;
 			}
 		}
 	}
 //	PrintArray(a,cnt);
 }
 
 void Solve(FILE *fp, int caseNum)
 {
 	int T, NA, NB, A_cnt=0, B_cnt=0;
 	int A_DT[MAX], A_AT[MAX], B_DT[MAX], B_AT[MAX];
 	int A_ptr=0, B_ptr=0;
 	int i, num, time;
 	char ch;
 	
 	fscanf(fp, "%d", &T);
 	fscanf(fp, "%d", &NA);
 	fscanf(fp, "%d", &NB);
 	
 //	printf("\nT=%d,NA=%d,NB=%d\n", T,NA,NB);
 	
 	for(i=0;i<NA;i++)
 	{
 		fscanf(fp, "%d", &num);
 		time = num * 60;
 		fscanf(fp, "%c", &ch);		// ignore ':'
 		fscanf(fp, "%d", &num);
 		A_DT[i] = time + num;		// store time in minutes
 		
 		fscanf(fp, "%c", &ch);		// ignore ' '
 		fscanf(fp, "%d", &num);
 		time = num * 60;
 		fscanf(fp, "%c", &ch);		// ignore ':'
 		fscanf(fp, "%d", &num);
 		B_AT[i] = time + num + T;		// store time in minutes
 	}
 
 	for(i=0;i<NB;i++)
 	{
 		fscanf(fp, "%d", &num);
 		time = num * 60;
 		fscanf(fp, "%c", &ch);		// ignore ':'
 		fscanf(fp, "%d", &num);
 		B_DT[i] = time + num;		// store time in minutes
 		
 		fscanf(fp, "%c", &ch);		// ignore ' '
 		fscanf(fp, "%d", &num);
 		time = num * 60;
 		fscanf(fp, "%c", &ch);		// ignore ':'
 		fscanf(fp, "%d", &num);
 		A_AT[i] = time + num + T;		// store time in minutes
 	}
 	
 //	PrintArray(A_DT, NA);
 //	PrintArray(A_AT, NB);
 //	PrintArray(B_DT, NB);
 //	PrintArray(B_AT, NA);
 	
 	Sort(A_DT, NA);
 	Sort(A_AT, NB);
 	Sort(B_DT, NB);
 	Sort(B_AT, NA);
 	
 	for(i=0;i<NA;i++)
 	{
 		if(A_ptr < NB && A_AT[A_ptr] <= A_DT[i])
 			A_ptr++;
 		else
 			A_cnt++;
 	}
 
 	for(i=0;i<NB;i++)
 	{
 		if(B_ptr < NA && B_AT[B_ptr] <= B_DT[i])
 			B_ptr++;
 		else
 			B_cnt++;
 	}
 	
 	printf("Case #%d: %d %d\n", caseNum, A_cnt, B_cnt);
 }
 
 int main(int argc, char* argv[])
 {
 	int i,n;
 	FILE *fp;
 
 	if(argc <= 1)
 	{
 		printf("Usage: a.out <input_file>\n");
 		return 0;
 	}
 	
 	fp = fopen(argv[1], "r");
 
 	fscanf(fp, "%d", &n);
 //	printf("\nn = %d\n",n);
 	
 	for(i=0;i<n;i++)
 		Solve(fp, i+1);
 
 	return 0;
 }
 

