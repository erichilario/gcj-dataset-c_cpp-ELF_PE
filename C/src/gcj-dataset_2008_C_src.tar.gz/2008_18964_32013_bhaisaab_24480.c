#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 struct info
 {
 int S;
 char seng[100][80];
 int Q;
 char name[1000][80];
 
 int min_switch;
 };
 
 struct mat
 {
 short int matrix[1000][100];//the ultimate PART of the structure
 };
 
 int main()
 {
 
 struct info data[20];
 struct mat data2[20];
 int N = 0;
 FILE *fp;
 FILE *output;
 int i,j,k,z=0;
 int TEMP, FLAG, ROW=0;
 int COUNTER[100];//for counting no. of zeroes.
 int TOT_SWITCH;
 
 fp = fopen("A-small-attempt1.in","r");
 
 fscanf(fp,"%d",&N);
 //printf("%d\n",N);
 for( i=0; i < N ;i++ )
 {
 	fscanf(fp,"%d",&data[i].S);
 	for(j=0;j<=(data[i].S);j++)
 		{
 			fgets(data[i].seng[j],79,fp);//stores search engines
 		}
 	//Important when changing this sjhit
 	fscanf(fp,"%d",&data[i].Q);
 	for(j=0;j<=data[i].Q;j++)
 		{
 			fgets(data[i].name[j],79,fp);
 		}
 }
 fclose(fp);
 
 for(i=0;i<N;i++)
 {
 //Testing input
 printf("Case::%d",i+1);
 printf("Total each engines S=%d\n",data[i].S);
 	for(j=1;j<=data[i].S;j++)
 		{
 			printf("%s",data[i].seng[j]);
 		}
 	printf("Queries=%d\n",data[i].Q);
 	for(j=1;j<=data[i].Q;j++)
 		{
 			printf("%s",data[i].name[j]);
 		}	
 }
 
 
 for(i=0;i<N;i++)
 {
 	for(k=1;k<=(data[i].Q);k++)
 	{
 		for(j=1;j<=(data[i].S);j++)
 		{
 			FLAG = strcmp(data[i].name[k],data[i].seng[j]);
 			//printf("%d ",FLAG);
 			if(FLAG!=0)
 				data2[i].matrix[k-1][j-1] = 0;
 			else
 				data2[i].matrix[k-1][j-1] = 1;
 			printf("%d ",data2[i].matrix[k-1][j-1]);
 		}
 		printf("\n");
 	}
 }
 ROW=0;
 for(i=0;i<N;i++)
 {
 	TOT_SWITCH = 0;
 	ROW = 0;
 	
 	while( ROW < data[i].Q )
 	{
 		for(j=0;j<(data[i].S);j++)
 		{
 			z=0;
 			for(k=ROW;k<(data[i].Q);k++)
 			{
 				if(data2[i].matrix[k][j] != 1)
 				z++;
 				else
 				break;
 			}
 			COUNTER[j] = z;
 		}
 		TEMP = 0;
 		for(z=0;z<(data[i].S);z++)
 		{
 			//printf("%d ",COUNTER[z]);
 			if(COUNTER[TEMP] < COUNTER[z])
 				TEMP = z;
 		}
 		ROW = ROW + COUNTER[TEMP];
 		if( ROW < data[i].Q )
 			TOT_SWITCH++;
 		//printf("%d ",TOT_SWITCH);
 	}
 	data[i].min_switch = TOT_SWITCH;
 }
 
 output = fopen("output.txt","w");
 for(i=0;i<N;i++)
 {
 printf("Case #%d: %d\n",i+1,data[i].min_switch);
 fprintf(output,"Case #%d: %d\n",i+1,data[i].min_switch);
 }
 
 fclose(output);
 
 return 0;
 }

