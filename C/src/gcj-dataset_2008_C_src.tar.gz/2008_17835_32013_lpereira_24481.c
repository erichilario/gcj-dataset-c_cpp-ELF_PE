#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <malloc.h>
 #define MIN(a,b) (((a)<(b))?(a):(b))
 
 int compint(int* a, int* b) {
   return(*a - *b);
 }
 
 int main(void) {
   int c, tc;
   scanf(" %d",&tc);
   for(c=1;c<=tc;c++){
     int puta[128], putb[128], takea[128], takeb[128];
     int na, nb, i, t, j, cp, ct;
     int ca, cb, mina, minb;
     printf("Case #%d: ",c);
     scanf(" %d",&t);
     scanf(" %d %d",&na,&nb);
     for(i=0;i<na;i++) {
       int ha,ma,hb,mb,ta,tb;
       scanf(" %d:%d %d:%d",&ha,&ma,&hb,&mb);
       ta = ha*60 + ma; tb = hb*60+mb+t;
       takea[i] = ta;
       putb[i] = tb;
     }
     for(i=0;i<nb;i++) {
       int ha,ma,hb,mb,ta,tb;
       scanf(" %d:%d %d:%d",&hb,&mb,&ha,&ma);
       ta = ha*60 + ma + t; tb = hb*60 + mb;
       takeb[i] = tb;
       puta[i] = ta;
     }
     qsort(takea,na,sizeof(int),compint);
     qsort(takeb,nb,sizeof(int),compint);
     qsort(puta,nb,sizeof(int),compint);
     qsort(putb,na,sizeof(int),compint);
     
     mina = 0; ca = 0; i=0; cp = 0; ct = 0;
     for(j=0;j<=24*60 + 60;j++) {
       while(takea[ct] == j && ct < na) {
 	ca--; ct++;
       }
       while(puta[cp] == j && cp < nb) {
 	ca++; cp++;
       }
       mina = MIN(ca,mina);
     }
     minb = 0; cb = 0; i=0; cp = 0; ct = 0;
     for(j=0;j<=24*60 + 60;j++) {
       while(takeb[ct] == j && ct < nb) {
 	cb--; ct++;
       }
       while(putb[cp] == j && cp < na) {
 	cb++; cp++;
       }
       minb = MIN(cb,minb);
     }
     printf("%d %d\n",-mina,-minb);
     
   }
   return(0);
 }

