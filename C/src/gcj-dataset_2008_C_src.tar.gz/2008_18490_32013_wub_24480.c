#include <stdio.h>
 #include <string.h>
 
 typedef struct {
 	char	buf[101];
 	int	flag;
 } string;
 
 string unsort[100], server[100];
 char query[1000][101];
 int sn, qn;
 
 FILE *fp;
 
 #define DEBUG 0
 
 int cmpserver(char *q)
 {
 	int head = 0;
 	int tail = sn - 1;
 	int mid = sn / 2;
 	int r;
 	while(1) {
 		r = strcmp(server[mid].buf, q);
 		if(r == 0)
 			return mid;
 
 		if(head >= tail)
 			return -1;
 
 		if(r < 0) {
 			head = mid + 1;
 			mid = (mid + tail + 1) / 2;
 		} else {
 			tail = mid - 1;
 			mid = (head + mid) / 2;
 		}
 	}
 	return -1;
 }
 
 int run()
 {
 	int i, j, first;
 	int counter = 0;
 	string *p;
 	int ser_nr;
 	int ret;
 	char buf[100];
 
 	/* get server. */
 	fscanf(fp, "%d", &sn);
 	fgets(buf, 1000, fp);
 	for(i = 0; i < sn; i++) {
 		fgets(unsort[i].buf, 1000, fp);
 		unsort[i].flag = 0;
 	}
 
 	/* get query. */
 	fscanf(fp, "%d", &qn);
 	fgets(buf, 1000, fp);
 	for(i = 0; i < qn; i++) {
 		fgets(query[i], 1000, fp);
 	}
 
 	/* sort server. */
 	for(i = 0; i < sn; i++) {
 		first = 0;
 		for(j = 0; j < sn; j++ ) {
 			if(unsort[j].flag == 1)
 				continue;
 
 			if(first == 0) {
 				p = &unsort[j];
 				first = 1;
 			} else {
 				if(strcmp(p->buf, unsort[j].buf) > 0) {
 					p = &unsort[j];
 				}
 			}
 		}
 		p->flag = 1;
 		strcpy(server[i].buf, p->buf);
 		server[i].flag = 0;
 	}
 
 	/* do it. */
 	ser_nr = 0;
 	for(i = 0; i < qn; i++) {
 		ret = cmpserver(query[i]);
 #if DEBUG
 	printf("ret: %d\n", ret);
 #endif
 		if(ret == -1)
 			continue;
 
 		if(server[ret].flag == 1)
 			continue;
 
 		ser_nr++;
 		if(ser_nr == sn) {
 			for(j = 0; j < sn; j++)
 				server[j].flag = 0;
 			ser_nr = 1;
 			counter++;
 		}
 		server[ret].flag = 1;
 	}
 
 	return counter;
 }
 
 int main()
 {
 	int n;
 	int i;
 
 	fp = fopen("data", "r");
 	if(fp == NULL) {
 		printf("error in open file!\n");
 		return 0;
 	}
 
 	fscanf(fp, "%d", &n);
 	for(i = 0; i < n; i++) {
 		printf("Case #%d: %d\n", i + 1, run());
 	}
 	return 0;
 }

