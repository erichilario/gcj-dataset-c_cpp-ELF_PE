#include<stdio.h>
 #include<conio.h>
 #include<string.h>
 #define SIZE 1000
 int main()
 {  
    int testcase,output[SIZE]; 
    char server[SIZE][SIZE];
    char query[SIZE][SIZE];
    FILE *fp;
    fp=fopen("output.txt","w");
    int server_size,query_size,index,i,j,no_switch,m,k,max,l;
    int a[SIZE];
    scanf("%d",&testcase);
    fflush(stdin);
    for(l=0;l<testcase;l++)
    {
     scanf("%d",&server_size);
     fflush(stdin);
     for(m=0;m<server_size;m++)
     {
      gets(server[m]);
                        //       fflush(stdin);
     }                          
     scanf("%d",&query_size);
     fflush(stdin);
     for(m=0;m<query_size;m++)
     gets(query[m]);
     j=0;
     
     no_switch=-1;
     while(j<query_size)
     {
       for(i=0;i<server_size;i++)
       {
          index=i;
          for(k=j;k<query_size;k++)
          {
             if(strcmp(server[index],query[k])==0)
             {
                   printf("Index for %s=%d\n",server[index],k);
                   break;
             }      
          }
 
          a[index]=k;
       }
       max=a[0];
       for(m=1;m<server_size;m++)
       {
          if(max < a[m])
             max=a[m];
       }
       printf("max=%d\n",max);  
       j=max;
       no_switch++;
     }                    
     if(no_switch == -1)
        no_switch=0;             
     output[l]=no_switch;
   }
   for(k=0;k<testcase;k++)
   {
   fprintf(fp,"Case #%d: %d\n",k+1,output[k]);
   }
   fclose(fp);
   getch();                          
 }

