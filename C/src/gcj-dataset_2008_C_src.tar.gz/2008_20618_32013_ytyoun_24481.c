#include <stdio.h>
 #include <stdlib.h>
 
 #define NA 102
 #define NB 102
 #define LENGTH NA+NB
 
 /* define the direction as a type */
 typedef enum DIREC_
 {
 	A,
 	B
 } direction;
 
 typedef struct train_
 {
 	direction d;
 	int start;
 } train;
 
 typedef struct schedule_
 {
 	direction d;
 	int start;
 	int end;
 } schedule;
 
 /* array of schedules */
 schedule S[LENGTH];
 int S_size;
 /* array of trains */
 train T[LENGTH];
 int T_size;
 /* turnaround time */
 int turnaround;
 /* number of trains from A and B*/
 int from_A, from_B;
 
 /**
  * used for qsort
  */
 int cmp(schedule *a, schedule *b)
 {
 	if (a->start != b->start)
 		return a->start - b->start;
 	else
 		a->end - b->end;
 }
 /*
 int old_cmp(const void *a, const void *b)
 {
 	if (((schedule *)a->start) != ((schedule *)b->start))
 		return ((schedule *)a->start) - ((schedule *)b->start);
 	else
 		return ((schedule *)a->end) - ((schedule *)b->end);
 }
 */
 
 /**
  * Convert hour:min to min
  */
 int convert(int hour, int min)
 {
 	return 60*hour + min;
 }
 
 /**
  * Only for debugging
  */
 void show_schedule()
 {
 	int i;
 
 	for (i = 0; i < S_size; i++)
 	{
 		printf(" to %c %d:%d ~ %d:%d\n", 'A' + S[i].d,
 					 S[i].start / 60, S[i].start % 60, S[i].end / 60, S[i].end % 60);
 	}
 }
 
 /**
  * Returns the index of compatible train. If not, returns -1.
  */
 int find_compatible(schedule s)
 {
 	int i;
 
 	for (i = 0; i < T_size; i++)
 	{
 		if (T[i].start <= s.start && T[i].d == s.d)
 			return i;
 	}
 
 	return -1;
 }
 
 void show_trains()
 {
 	int i;
 	for (i = 0; i < T_size; i++)
 		printf("  train %d: to %c after %d:%d\n",
 					 i+1, 'A' + T[i].d, T[i].start / 60, T[i].start % 60);
 	printf("  ---\n");
 }
 
 int allocate()
 {
 	/* temporary index */
 	int i;
 	/* train index */
 	int tr;
 
 	for (i = 0; i < S_size; i++)
 	{
 		tr = find_compatible(S[i]);
 		if (tr == -1)
 			/* there is no matching train. add a new train */
 		{
 			/* switch the direction */
 			T[T_size].d = 1 - S[i].d;
 			T[T_size].start = S[i].end + turnaround;
 			T_size++;
 
 			/* increment the number of trains */
 			if (S[i].d == A)
 				from_B++;
 			else
 				from_A++;
 		}
 		else
 			/* find a matching train. update the information */
 		{
 			/* switch the direction */
 			T[tr].d = 1 - T[tr].d;
 			T[tr].start = S[i].end + turnaround;
 		}
 		
 /*		show_trains(); */
 	}
 
 	return 0;
 }
 
 int main()
 {
 	int N;
 	int na, nb;
 	/* index varialbe */
 	int i, j;
 	/* depature hour and minute */
 	int d_h, d_m;
 	/* arrival hour and minute */
 	int a_h, a_m;
 
 	scanf("%d", & N);
 
 	for (i = 1; i <= N; i++)
 	{
 		/* initialize schedule size and train size */
 		S_size = 0;
 		T_size = 0;
 		from_A = 0;
 		from_B = 0;
 
 		scanf("%d", &turnaround);
 
 		scanf("%d %d", &na, &nb);
 
 		/* schedule from A to B */
 		for (j = 0; j < na; j++)
 		{
 			scanf("%d:%d %d:%d", &d_h, &d_m, &a_h, &a_m);
 			S[S_size].d = B;
 			S[S_size].start = convert(d_h, d_m);
 			S[S_size].end = convert(a_h, a_m);
 			S_size++;
 		}
 
 		/* schedule from B to A */
 		for (j = 0; j < nb; j++)
 		{
 			scanf("%d:%d %d:%d", &d_h, &d_m, &a_h, &a_m);
 			S[S_size].d = A;
 			S[S_size].start = convert(d_h, d_m);
 			S[S_size].end = convert(a_h, a_m);
 			S_size++;
 		}
 
 		/* sort the schedules */
 		qsort(S, S_size, sizeof(schedule), cmp);
 
 /*		show_schedule();*/
 
 		allocate(S_size);
 
 		printf("Case #%d: %d %d\n", i, from_A, from_B);
 	}
 
 	return 0;
 }

