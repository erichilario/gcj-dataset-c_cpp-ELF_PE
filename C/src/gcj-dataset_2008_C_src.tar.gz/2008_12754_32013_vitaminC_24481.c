#include <stdio.h>
 #include <string.h>
 
 #define CLR_NL(str) \
 	do { \
 		int n; \
 		if ( str && (n=strlen(str)) && str[n-1] == '\n' ) \
 			str[n-1] = '\0'; \
 	} while(0)
 
 #define LINE_SZ 200
 #define OUTF_NAME "output.txt"
 #define SORT_ARR  0
 #define SORT_DEP  1
 
 /* time table entry */
 typedef struct _ttentry
 {
 	int start_HH, start_MM; /* departure time */
 	int end_HH, end_MM; /* arrival time */
 	int start_mins, end_mins; /* converted to minutes */
 	char sent_back; /* marked 1 when train used for next journey */
 } ttentry;
 
 /* wrapper list for time table entry */
 typedef struct _ttent_list
 {
 	struct _ttent_list *next;
 	ttentry *ent;
 
 } ttent_list;
 
 FILE *inf, *outf; 
 int debug = 0;
 
 void getline(char *line)
 {
 	line[0] = '\0';
 	fgets(line, LINE_SZ, inf);
 	CLR_NL(line);
 	if(!line[0])
 	{
 		printf("Input file invalid\n");
 		exit(1);
 	}
 
 }
 
 void free_list(ttentry **list, int num)
 {
 	int i;
 
 	for(i = 0; i < num; i++)
 		if(list[i])
 			free(list[i]);
 	free(list);
 }
 
 /* return departure or arrival time(in minutes) value depending on mode */
 int get_time(ttentry *ent, char mode)
 {
 	if(mode == SORT_DEP)
 		return ent->start_mins;
 	else
 		return ent->end_mins;
 }
 
 void swap_entry(ttentry **arr, int i, int j)
 {
 	ttentry *temp;
 	temp = arr[i];
 	arr[i] = arr[j];
 	arr[j] = temp;
 }
 
 int partition_list(ttentry **list, int left, int right, int piv_index, char mode)
 {
 	int store_index, i ;
 	ttentry *piv = list[piv_index];
 	swap_entry(list, piv_index, right);
 
 	for(i = left, store_index = left; i < right; i++)
 		if(get_time(list[i], mode) <= get_time(piv, mode) )
 			swap_entry(list, i, store_index++);
 	swap_entry(list, store_index, right);
 
 	return store_index;
 }
 
 void qsort_list(ttentry **list, int left, int right, char mode)
 {
 	int pivot_index = left, new_piv_index;
 
 	if(left >= right)
 		return;
 
 	new_piv_index = partition_list(list, left, right, pivot_index, mode);
 	qsort_list(list, left, new_piv_index - 1, mode);
 	qsort_list(list, new_piv_index + 1, right, mode);
 
 }
 
 /* get a train that has arrived before the time given 
  * and which has not been sent back*/
 ttentry *prev_train_ent(ttentry **list, int num, int time)
 {
 	int i;
 
 	if(num <= 0 || time < 0 || !list)
 		return NULL;
 
 	for(i = 0; i < num; i++)
 	{
 		if(list[i]->end_mins <= time && !list[i]->sent_back)
 			return list[i];
 	}
 
 	return NULL;
 }
 
 int main(int argc, char *argv[])
 {
 
 	int N; /* num of tst cases */
 	int i;
 	char line[LINE_SZ];
 	ttentry *ent;
 	ttent_list *entlist;
 
 	if(argc != 2)
 	{
 		printf("Give 1st arg = input file name\n");
 		exit(1);
 	}
 
 	inf = fopen(argv[1], "r");
 	if(!inf)
 	{
 		printf("Could not open input file\n");
 		exit(1);
 	}
 
 	outf = fopen(OUTF_NAME, "w");
 	if(!outf)
 	{
 		printf("Could not open output file for writing\n");
 		exit(1);
 	}
 
 	getline(line);
 	sscanf(line, "%d", &N);
 
 	for(i = 0; i < N; i++)
 	{
 		int T, NA, NB, j, a_start, b_start;
 	        ttentry **a_dep_list, **b_dep_list;	
 		
 		a_dep_list = b_dep_list = NULL;
 
 		getline(line);
 		sscanf(line, "%d", &T);
 
 		getline(line);
 		sscanf(line, "%d %d", &NA, &NB);
 
 		if(NA > 0)
 			a_dep_list = (ttentry **)calloc(NA , sizeof(ttentry *)); /* using array */
 		for(j = 0; j < NA; j++)
 		{
 			getline(line);
 			ent = (ttentry *)calloc(1, sizeof(ttentry));
 			sscanf(line, "%d:%d %d:%d", &ent->start_HH, &ent->start_MM, &ent->end_HH, &ent->end_MM);
 			ent->start_mins = ent->start_HH * 60 + ent->start_MM;
 			ent->end_mins = ent->end_HH * 60 + ent->end_MM;
 			a_dep_list[j] = ent;
 			
 		}
 
 		if(NB > 0)
 			b_dep_list = (ttentry **)calloc(NB , sizeof(ttentry *)); /* using array */
 		for(j = 0; j < NB; j++)
 		{
 			getline(line);
 			ent = (ttentry *)calloc(1, sizeof(ttentry));	
 			sscanf(line, "%d:%d %d:%d", &ent->start_HH, &ent->start_MM, &ent->end_HH, &ent->end_MM);
 			ent->start_mins = ent->start_HH * 60 + ent->start_MM;
 			ent->end_mins = ent->end_HH * 60 + ent->end_MM;
 			b_dep_list[j] = ent;	
 		}
 
 
 		/******For A */
 		/* sort the lists according to time */
 		qsort_list(a_dep_list, 0, NA-1, SORT_DEP);
 		qsort_list(b_dep_list, 0, NB-1, SORT_ARR); /* B's departure is A's arrival */
 		
 		if(debug)
 			printf("from A to B:\n"); /************************/
 		for(j = 0, a_start = 0; j < NA; j++)
 		{
 			ttentry *prev_ent;
 
 			ent = a_dep_list[j];
 			prev_ent = prev_train_ent(b_dep_list, NB, ent->start_mins - T);
 			if(prev_ent) /* train found that can be sent back , no start needed */
 				prev_ent->sent_back = 1;
 			else
 				a_start++;  /* new train has to start from A */
 
 			/***************************/
 			if(debug)
 			   if(prev_ent)
 				printf("	sending back : %d:%d(B) -> %d:%d(A) as %d:%d(A) -> %d:%d(B)\n", prev_ent->start_HH, prev_ent->start_MM, prev_ent->end_HH, prev_ent->end_MM, ent->start_HH, ent->start_MM, ent->end_HH, ent->end_MM);
 			   else
 				printf("	new start at A : %d:%d(A) -> %d:%d(B)\n", ent->start_HH, ent->start_MM, ent->end_HH, ent->end_MM);
 		}
 
 		if(debug)
 			printf("from B to A:\n"); /************************/
 		/******For B */
 		/* sort the lists according to time */
 		qsort_list(b_dep_list, 0, NB-1, SORT_DEP);
 		qsort_list(a_dep_list, 0, NA-1, SORT_ARR); /* A's departure is B's arrival */
 		
 		for(j = 0, b_start = 0; j < NB; j++)
 		{
 			ttentry *prev_ent;
 
 			ent = b_dep_list[j];
 			prev_ent = prev_train_ent(a_dep_list, NA, ent->start_mins - T);
 			if(prev_ent) /* train found that can be sent back , no start needed */
 				prev_ent->sent_back = 1;
 			else
 				b_start++;  /* new train has to start from B */
 
 			/***************************/
 			if(debug)
 			  if(prev_ent)
 				printf("	sending back : %d:%d(A) -> %d:%d(B) as %d:%d(B) -> %d:%d(A)\n", prev_ent->start_HH, prev_ent->start_MM, prev_ent->end_HH, prev_ent->end_MM, ent->start_HH, ent->start_MM, ent->end_HH, ent->end_MM);
 			  else
 				printf("	new start at B : %d:%d(B) -> %d:%d(A)\n", ent->start_HH, ent->start_MM, ent->end_HH, ent->end_MM);
 		}
 
 		/* output */
 		fprintf(outf, "Case #%d: %d %d\n", i+1, a_start, b_start);
 		printf("Case #%d: %d %d\n", i+1, a_start, b_start);
 
 
 		/* free memory */
 		if(a_dep_list)
 			free_list(a_dep_list, NA);
 		if(b_dep_list)
 			free_list(b_dep_list, NB);
 	}
 	return 0;
 }
 

