#include <stdio.h>
 #include <limits.h>
 #include <string.h>
 #include <stdlib.h>
 
 #define SMAX 100
 struct area {
     int filled;
     int begin;
     int end;
 };
 
 struct tree {
     int index;
     int ws;
     struct tree *prev;
     struct tree *next[SMAX];
 };
 
 void
 init_tree(struct tree *t)
 {
     int i;
     memset(t, 0, sizeof(*t));
     for (i = 0; i < SMAX; i++) t->next[i] = NULL;
     t->prev = NULL;
 }
 
 #define chomp(s) do { (s)[strlen(s) - 1] = 0; } while (0)
 
 int
 calc(struct area *area, int areas, int tail)
 {
     int stack[1000];
     int used[1000];
     int u;
     int depth;
     int i, j;
     int t;
     int min = INT_MAX;
     int n, m;
     int endmin;
 
     memset(stack, 0, sizeof(stack));
     memset(used, 0, sizeof(used));
     depth = 0;
     t = 0;
     //for (i = 0; i < areas; i++) used[i] = -1;
 
     for (i = 0; i < areas; i++) {
         n = -1;
         endmin = 0;
         for (m = 0; m < areas; m++) {
             //printf("(%d-%d)\n", area[m].begin, area[m].end);
             for (u = 0, j = 0; j < i; j++) {
                 if (m == used[j]) {
                     u = 1;
                     break;
                 }
             }
             //printf("%d\n",__LINE__);
             if (u) continue;
             //printf("%d\n",__LINE__);
             if (i == 0 && area[m].begin != 0) continue;
             //printf("%d\n",__LINE__);
             if (i > 0 && area[m].begin > area[used[i - 1]].end) continue;
             //printf("%d:%d, %d\n",__LINE__,endmin,area[m].end);
             if (endmin < area[m].end) {
                 endmin = area[m].end;
                 n = m;
             }
             if (endmin == tail) {
                 return i;
             }
         }
         if (n >= 0) {
             //printf("EEE:(%d-%d)\n", area[n].begin, area[n].end);
             used[i] = n;
         } else {
             //printf("XXX\n");
             exit(-1);
         }
     }
 
     return -100;
 }
 
 int
 main()
 {
     char SearchEngine[SMAX][100];
     char Word[1000][100];
     int SE_Stack[1000];
     int testcase, tc;
     int searchengines, se;
     int words, ws;
     int line, l;
     int i;
     int ret;
 
     struct tree root;
     struct tree *current, *tmp;
 
     char str[100];
 
     struct area area[1000];
     int areas;
     int new;
 
     fgets(str, 100, stdin);
     str[strlen(str) - 1] = '\0';
     testcase = atoi(str);
     //scanf("%d", &testcase);
 
     for (tc = 0; tc < testcase; tc++) {
         //scanf("%d", &searchengines);
         fgets(str, 100, stdin);
         str[strlen(str) - 1] = '\0';
         searchengines = atoi(str);
         for (se = 0; se < searchengines; se++) {
             fgets(SearchEngine[se], 100, stdin);
             chomp(SearchEngine[se]);
         }
         //scanf("%d", &words);
         fgets(str, 100, stdin);
         str[strlen(str) - 1] = '\0';
         words = atoi(str);
         for (ws = 0; ws < words; ws++) {
             fgets(Word[ws], 100, stdin);
             chomp(Word[ws]);
         }
         if (words == 0) {
             printf("Case #%d: 0\n", tc + 1);
             continue;
         }
 
         areas = 0;
         memset(area, 0, sizeof(area));
         for (se = 0; se < searchengines; se++) {
             new = 1;
             for (ws = 0; ws < words; ws++) {
                 //printf("%d:%s, %s, %d\n", ws,Word[ws], SearchEngine[se], new);
                 if (new && strcmp(Word[ws], SearchEngine[se])) {
                     new = 0;
                     //printf("%d\n",__LINE__);
                     area[areas].begin = ws;
                 }
                 if (!new && !strcmp(Word[ws], SearchEngine[se])) {
                     int j;
                     new = 1;
 
                     for (j = 0; j < areas; j++) {
                         if (area[j].begin <= area[areas].begin && area[j].end >= ws) break;
                     }
                     if (j == areas) {
                         area[areas].end = ws;
                         //printf("%d-%d:%s\n", area[areas].begin, area[areas].end, SearchEngine[se]);
                         areas++;
                     }
                     //printf("%d\n",__LINE__);
                 }
             }
             if (!new) {
                 area[areas].end = words;
                 //printf("%d-%d:%s\n", area[areas].begin, area[areas].end, SearchEngine[se]);
                 areas++;
             }
         }
         
         ret = calc(area, areas, words);
         printf("Case #%d: %d\n", tc + 1, ret);
         fprintf(stderr, "Case #%d: %d\n", tc + 1, ret);
     }
 
     return 0;
 }
 

