#include <sys/types.h>
 #include <sys/stat.h>
 #include <fcntl.h>
 #include <stdio.h>
 #include <pwd.h>
 #include <string.h>
 #include <errno.h>
 #include <stdlib.h>
 
 #include <crypt.h>
 #include <unistd.h>
 #include <dirent.h>
 
 #define MAX_NAME_LEN	100
 #define A_STATION	1
 #define B_STATION	2
 typedef struct tag_trip
 {
     char		start[6];
     char		arriv[6];
 	int			train;		//0 : no train 
 	int			direct;	// A -> B= 0; B -> A = 1;
 
 }TAG_TRIP;
 
 typedef struct tag_train
 {
     char		valid_time[6];
 	int			local;		//A = 0; B = 1;
 
 }TAG_TRAIN;
 
 
 static TAG_TRIP tripAB[100];
 static TAG_TRIP tripBA[100];
 static TAG_TRAIN trains[200];
 
 static int	tr = 0;
 static int	NA = 0;
 static int	NB = 0;
 static int	A_start = 0;
 static int	B_start = 0;
 
 void init_data()
 {
 	bzero(tripAB, sizeof(tripAB));
 	bzero(tripBA, sizeof(tripBA));
 	bzero(trains, sizeof(trains));
 	A_start = 0;
 	B_start = 0;
 }
 
 void show_train(TAG_TRAIN *train)
 {
 	printf("new train info: ");
 	printf("A_start = %d, B_start = %d; ", A_start, B_start);
 	printf("%s at %s\n", train->valid_time,
 			(train->local == A_STATION) ? "A" : "B");
 }
 
 void show_arrays()
 {
 	int i;
 	
 	printf("%d %d\n", NA, NB);
 	for(i = 0; i < NA; i++)
 	{
 		printf("%s %s\n", tripAB[i].start, tripAB[i].arriv);
 	}
 
 	for(i = 0; i < NB; i++)
 	{
 		printf("%s %s\n", tripBA[i].start, tripBA[i].arriv);
 	}
 }
 
 char * ltrimstr(char *buf)
 {
 
 	int	len;
 	int	i;
 	char *	p;
 
 	len = strlen(buf);
 	if (len <= 0)	return buf;
 
 	p = buf;
 	for (i = 0; i < len; i++)
 	{
 		if (buf[i] == ' ' || buf[i] == '\t')
 			p = buf + i;
 		else
 			break;
 	}
 
 	return p;
 
 }
 
 /************************************************************************
  * 
  ************************************************************************/
 char * rtrimstr(char *buf)
 {
 
 	int	len;
 	int	i;
 
 	len = strlen(buf);
 	if (len <= 0)	return buf;
 
 	for (i = len - 1; i >= 0; i--)
 	{
 		if (buf[i] == ' ' || buf[i] == '\r' || buf[i] == '\n')
 		{
 			buf[i] = '\0';
 		}
 		else	break;
 	}
 
 	return buf;
 
 }
 char *readline(FILE *fp, char *line, int len)
 {
 	char *start;
 
 	if(fgets(line, len, fp) == NULL)
 	{
 		printf("fgets error\n");
 		return NULL;
 	}
 	
 	start = ltrimstr(line);
 	rtrimstr(start);
 
 	return start;
 }
 
 TAG_TRIP *find_notrain(TAG_TRIP *trip, int len)
 {
 	int i;
 
 	for(i = 0; i < len; i++)
 	{
 		if(trip[i].train == 0)
 		{
 			return &trip[i];
 		}
 	}
 
 	return NULL;
 }
 
 TAG_TRIP *find_earliest()
 {
 	int i, j;
 	TAG_TRIP	*earliest;
 
 	if(NA != 0)
 	{
 		earliest = find_notrain(&tripAB[0], NA);
 		if(earliest == NULL)
 		{
 			earliest = find_notrain(&tripBA[0], NB);
 		}
 	
 
 	}
 	else
 	{
 		if(NB != 0)
 		{
 			earliest = find_notrain(&tripBA[0], NB);
 		}
 		else
 		{
 			return NULL;
 		}
 	}
 
 	if(earliest == NULL)
 	{
 		printf("earliest == NULL\n");
 		return NULL;
 	}
 
 	/* find out earliest trip between A and B */
 	for(i = 0; i < NA; i++)
 	{
 		if(tripAB[i].train == 0)
 		{
 			if(strcmp(tripAB[i].start, earliest->start) < 0)
 			{
 				earliest = &tripAB[i];
 			}
 			
 			if(strcmp(tripAB[i].start, earliest->start) == 0)
 			{
 				if(strcmp(tripAB[i].arriv, earliest->arriv) < 0)
 				{
 					earliest = &tripAB[i];
 				}
 			}
 		}
 	}
 
 	for(i = 0; i < NB; i++)
 	{
 		if(tripBA[i].train == 0)
 		{
 //			printf("%s ? %s\n", tripBA[i].start, earliest->start);
 			if(strcmp(tripBA[i].start, earliest->start) < 0)
 			{
 				earliest = &tripBA[i];
 			}
 			
 			if(strcmp(tripBA[i].start, earliest->start) == 0)
 			{
 				if(strcmp(tripBA[i].arriv, earliest->arriv) < 0)
 				{
 					earliest = &tripBA[i];
 				}
 			}
 		}
 
 	}
 
 	return earliest;
 }
 
 TAG_TRAIN *check_train(int station, const char *time)
 {
 	int i;
 	
 	for(i = 0; i < A_start + B_start; i++)	
 	{
 //		printf("trains[%d].local = %d, %d\n", i, trains[i].local, station);
 		if(trains[i].local == station)
 		{
 //			printf("%s ? %s\n", trains[i].valid_time, time);
 			if(strcmp(trains[i].valid_time, time) <= 0)
 			{
 				return &trains[i];
 			}
 		}
 	}
 
 	return NULL;
 }
 
 void count_valid_time(char *result, const char *time)
 {
 	char	time1[6];
 	char	*start;
 	int		h, m;
 
 	strcpy(time1, time);
 
 	start = strtok(time1, ":");
 	h = strtoul(start, NULL, 10);
 
 	start = strtok(NULL, ":");
 	m = strtoul(start, NULL, 10);
 
 	if(m + tr >= 60)
 	{
 		h++;
 		m = m + tr - 60;
 	}
 	else
 	{
 		m = m + tr;
 	}
 
 	sprintf(result, "%.2d:%.2d", h, m);
 }
 
 void count_trains_n()
 {
 	TAG_TRIP *trip;
 	TAG_TRAIN *train;
 	int	i;
 
 	for(i = 0; i < NA + NB; i++)
 	{
 		trip = find_earliest();
 		if(!(trip->direct))
 		{
 			printf("A -> B: ");
 			printf("%s -> %s\n", trip->start, trip->arriv);
 			if((train = check_train(A_STATION, trip->start)) != NULL)
 			{
 				/* exist train */
 				train->local = B_STATION;	
 				count_valid_time(train->valid_time, trip->arriv);
 				printf("exist train: %s at %s\n", train->valid_time,
 						(train->local == A_STATION) ? "A" : "B");
 			}
 			else
 			{
 				/* new train */
 				train = &trains[A_start + B_start];
 				A_start++;
 				train->local = B_STATION;
 				count_valid_time(train->valid_time, trip->arriv);
 				show_train(train);
 			}
 		}
 		else
 		{
 			printf("B -> A: ");
 			printf("%s -> %s\n", trip->start, trip->arriv);
 			if((train = check_train(B_STATION, trip->start)) != NULL)
 			{
 				/* exist train */
 				train->local = A_STATION;	
 				count_valid_time(train->valid_time, trip->arriv);
 				printf("exist train: %s at %s\n", train->valid_time,
 						(train->local == A_STATION) ? "A" : "B");
 	
 			}
 			else
 			{
 				/* new train */
 				train = &trains[A_start + B_start];
 				B_start++;
 				train->local = A_STATION;
 				count_valid_time(train->valid_time, trip->arriv);
 				show_train(train);
 			}
 		}
 
 		
 
 		trip->train = 1;
 
 	}
 
 
 }
 int main()
 {
  	FILE            *fp_r, *fp_w;
 	char            line[MAX_NAME_LEN];
 	int				i, j, lines = 0;
 	char			*start;
 	int				cases = 0;
 
 
 	fp_r = fopen("./input", "r");
 	fp_w = fopen("./output", "w+");
 	if(!fp_r || !fp_w)
 	{
 		printf("open file error\n");
 		return 1;
 	}
 
 	start = readline(fp_r, line, sizeof(line));
 	cases = strtoul(start, NULL, 0);
 
 
 	for(i = 0; i < cases; i++)
 //	for(i = 0; i < 1; i++)
 	{
 		char *p;
 
 		init_data();
 		start = readline(fp_r, line, sizeof(line));
 		tr = strtoul(start, NULL, 0);
 		
 		start = readline(fp_r, line, sizeof(line));
 		p = strtok(start, " ");
 		NA = strtoul(p, NULL, 0);
 		p = strtok(NULL, " ");
 		NB = strtoul(p, NULL, 0);
 		for(j = 0; j < NA; j++)
 		{
 			start = readline(fp_r, line, sizeof(line));
 			p = strtok(start, " ");			
 			strcpy(tripAB[j].start, p);
 
 			p = strtok(NULL, " ");			
 			strcpy(tripAB[j].arriv, p);
 			tripAB[j].train = 0;
 			tripAB[j].direct = 0;
 
 		}
 
 		for(j = 0; j < NB; j++)
 		{
 			start = readline(fp_r, line, sizeof(line));
 			p= strtok(start, " ");			
 			strcpy(tripBA[j].start, p);
 
 			p = strtok(NULL, " ");			
 			strcpy(tripBA[j].arriv, p);
 
 			tripBA[j].train = 0;
 			tripBA[j].direct = 1;
 		}
 
 		printf("Case #%d:\n", i + 1);
 		printf("turnaround : %d\n", tr);
 		show_arrays();
 		printf("========================\n");
 		count_trains_n();
 		fprintf(fp_w, "Case #%d: %d %d\n", i + 1, A_start, B_start);	
 		
 
 	}
 
 
 	fclose(fp_r);
 	fclose(fp_w);
 	return 0;
 }

