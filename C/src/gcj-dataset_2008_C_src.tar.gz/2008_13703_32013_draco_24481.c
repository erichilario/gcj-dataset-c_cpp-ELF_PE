#include<stdlib.h>
 #include<string.h>
 #include<stdio.h>
 
 #define MAX 1441
 
 int process_t(char[]);
 
 main() {
 
 int n,array1[MAX],array2[MAX],i,j,h,NA,NB,sum,k1,k2;
 char departure[100],arrival[100];
 
 scanf("%d", &n);
 
 for(j=1;j<=n;j++) {
 
 // Init the arrays
 
 	for(i=0;i<MAX;i++) {
 		array1[i]=0;
 		array2[i]=0;
 	}
 
 	scanf("%d %d %d",&h,&NA,&NB);
 
 //Process timetable for A to B
 
 	for(i=0;i<NA;i++) {
 		scanf("%s %s",departure,arrival);
 		array1[process_t(departure)-1]++;
 		array2[process_t(arrival)+h-1]--;
 	}
 
 //Process timetable for B to A
 
 	for(i=0;i<NB;i++) {
 		scanf("%s %s",departure,arrival);
 		array2[process_t(departure)-1]++;
 		array1[process_t(arrival)+h-1]--;
 	}
 
 //Calculating trains in A
 
 	for(i=0,sum=0,k1=0;i<MAX;i++) {
 		sum+=array1[i];
 		if(sum>k1)
 			k1=sum;
 	}
 
 //Calculating trains in B
 
 	for(i=0,sum=0,k2=0;i<MAX;i++) {
 		sum+=array2[i];
 		if(sum>k2)
 			k2=sum;
 	}
 
 	printf("Case #%d: %d %d\n",j,k1,k2);
 }
 
 }
 
 int process_t(char timestr[])
 {
 	int time;
 	time=(timestr[0]-'0')*600+(timestr[1]-'0')*60+(timestr[3]-'0')*10+(timestr[4]-'0');
 }
 

