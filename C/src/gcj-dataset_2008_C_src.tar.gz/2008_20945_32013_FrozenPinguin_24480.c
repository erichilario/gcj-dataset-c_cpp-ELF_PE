#include <stdio.h>
 #include <stdlib.h>
 #include <strings.h>
 
 #define NAME_LEN 105
 #define MAX_NAMES 100
 
 //#define DEBUG1
 //#define DEBUG2
 
 char names[MAX_NAMES][NAME_LEN], nextQuery[NAME_LEN], inbuf[NAME_LEN];
 unsigned char met[MAX_NAMES];
 
 int main(void)
 {
 	unsigned int casesQty, casesCnt, namesQty, namesCnt, queriesQty, queriesCnt;
 	unsigned int metCnt, switchesCnt, switchAt;
 	
 	FILE *infile = fopen("test.in", "rt");
 
 	fgets(inbuf, NAME_LEN, infile);
 	sscanf(inbuf, "%i", &casesQty);
 
 #ifdef DEBUG1
 	printf("%i\n", casesQty);
 #endif
 
 
 	for(casesCnt = 0; casesCnt < casesQty; casesCnt++)
 	{
 		fgets(inbuf, NAME_LEN, infile);
 		sscanf(inbuf, "%i", &namesQty);
 		
 		switchesCnt = 0;
 
 #ifdef DEBUG1
 		printf("%i\n", namesQty);
 #endif
 		
 		for(namesCnt = 0; namesCnt < namesQty; namesCnt++)
 		{
 			fgets(names[namesCnt], NAME_LEN, infile);
 			names[namesCnt][strlen(names[namesCnt]) - 1] = '\0'; //remove '\n'
 			met[namesCnt] = 0;
 		}
 		names[namesCnt][0] = '\0'; //put mark for the end of the names list
 		met[namesCnt] = -1;
 		metCnt = 0;
 			
 #ifdef DEBUG1
 		for(namesCnt = 0; namesCnt < namesQty; namesCnt++)
 			printf("%s @ %i\n", names[namesCnt], namesCnt);
 #endif
 		
 		fgets(inbuf, NAME_LEN, infile);
 		sscanf(inbuf, "%i", &queriesQty);
 #ifdef DEBUG1
 		printf("%i\n", queriesQty);
 #endif
 		
 		for(queriesCnt = 0; queriesCnt < queriesQty; queriesCnt++)
 		{
 			fgets(inbuf, NAME_LEN, infile);
 			inbuf[strlen(inbuf) - 1] = '\0'; //remove '/n'
 			
 #ifdef DEBUG1
 			printf("%s\n", inbuf);
 #endif
 			
 			//sort out the new query
 			//if not marked yet, mark it as met and increase metCnt
 			//when metCnt == namesCnt, it's time to switch
 			
 			for(namesCnt = 0; strcmp(inbuf, names[namesCnt]) != 0; namesCnt++)
 				;
 			
 			if(met[namesCnt] == 0)
 			{
 				met[namesCnt] = 1;
 				metCnt++;
 #ifdef DEBUG1
 				printf("Met %s\n", names[namesCnt]);
 #endif
 			}
 
 			if(metCnt == namesQty) //time to switch
 			{
 #ifdef DEBUG2
 				printf("Switch at %s\n", names[namesCnt]);
 #endif
 				switchesCnt++;
 				metCnt = 1;
 				switchAt = namesCnt;
 				for(namesCnt = 0; namesCnt < namesQty; namesCnt++)
 					met[namesCnt] = 0;
 				
 				met[switchAt] = 1; //switched to that engine; already met
 			}
 			
 		} //for(queries)
 		
 		printf("Case #%i: %i\n", casesCnt+1, switchesCnt);
 		
 	} //for(cases)
 			
 	
 	fclose(infile);
 	
 	return 0;
 }

