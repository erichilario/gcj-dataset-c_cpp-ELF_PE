#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int compare (const void * a, const void * b)
 {
   return ( *(int*)a - *(int*)b );
 }
 
 
 int main(){
     int N, NA, NB, T;
 	int i, j , k, l;
 	int trip[150][3];
 	int train[300][2], trainNum, ans[2];
 	int h, m;
 
 	scanf("%d", &N);
 
 	for(i = 0; i < N; i++){
 		scanf("%d %d %d", &T, &NA, &NB);
 
 		for(j = 0; j < NA; j++){
 			scanf("%d:%d", &h, &m);
 			trip[j][0] = h*60 + m;
 
 			scanf("%d:%d", &h, &m);
 			trip[j][1] = h*60 + m;
 
 			trip[j][2] = 0;
 		}
 
 		for(k = 0; k < NB; k++, j++){
 			scanf("%d:%d", &h, &m);
 			trip[j][0] = h*60 + m;
 
 			scanf("%d:%d", &h, &m);
 			trip[j][1] = h*60 + m;
 
 			trip[j][2] = 1;
 		}
 
 		qsort (trip, j, sizeof(trip[0]), compare);
 
 		trainNum = ans[0] = ans[1] = 0;
 
 		for(k = 0; k < j; k++){
 			for(l = 0; l < trainNum; l++){
 				if(train[l][0] == trip[k][2] && train[l][1] <= trip[k][0]){
 					train[l][0] = !train[l][0];
 					train[l][1] = trip[k][1] + T;
 					break;
 				}
 			}
 			if(l == trainNum){
 				train[trainNum][0] = !trip[k][2];
 				train[trainNum][1] = trip[k][1] + T;
 				ans[trip[k][2]]++;
 				trainNum++;
 			}
 		}		
 		printf("Case #%d: %d %d\n", i+1, ans[0], ans[1]);
 	}
 
     return 0;
 }

