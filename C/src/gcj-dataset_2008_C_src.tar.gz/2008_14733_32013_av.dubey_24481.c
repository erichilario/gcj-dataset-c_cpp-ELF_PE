#include<stdlib.h>
 #include<string.h>
 #include<stdio.h>
 
 
 
 int function(char[]);
 
 main() {
 
 int n,get[1441],put[1441],i,j,h,NA,NB,sum,q,w;
 char dep[100],arr[100];
 
 scanf("%d", &n);
 
 for(j=1;j<=n;j++) {
 
 for(i=0;i<1441;i++) {
 		get[i]=0;
 		put[i]=0;
 	}
 
 	scanf("%d %d %d",&h,&NA,&NB);
 
 for(i=0;i<NA;i++) {
 		scanf("%s %s",dep,arr);
 		get[function(dep)-1]++;
 		put[function(arr)+h-1]--;
 	}
 
 for(i=0;i<NB;i++) {
 		scanf("%s %s",dep,arr);
 		put[function(dep)-1]++;
 		get[function(arr)+h-1]--;
 	}
 
 for(i=0,sum=0,q=0;i<1441;i++) {
 		sum+=get[i];
 		if(sum>q)
 			q=sum;
 	}
 
 for(i=0,sum=0,w=0;i<1441;i++) {
 		sum+=put[i];
 		if(sum>w)
 			w=sum;
 	}
 
 	printf("Case #%d: %d %d\n",j,q,w);
 }
 
 }
 
 int function(char variabl[])
 {
 	int ghgh;
 	ghgh=(variabl[0]-'0')*600+(variabl[1]-'0')*60+(variabl[3]-'0')*10+(variabl[4]-'0');
 }
 

