#include<stdio.h>
 
 #define SUCCESS 1
 #define FAILURE 0
 
 #define MIN_LIMIT_N 1
 #define MAX_LIMIT_N 100
 
 
 #define MIN_LIMIT_NA 0
 #define MAX_LIMIT_NA 100
 
 #define MIN_LIMIT_NB 0
 #define MAX_LIMIT_NB 100
 
 int rtt = 0;
 
 typedef struct train_t_{
   int start_time;
   int start_station;
   struct train_t_ *next;
 }train_t;
 typedef struct schedule_t_{
   int start_time;
   int end_time;
   int start_station;
   struct schedule_t_ *next;
 }schedule_t;
 
 schedule_t * alloc_schedule(){
   schedule_t *new = NULL;
 
   new = (schedule_t *)malloc(sizeof(schedule_t));
 
   if(new == NULL){
     printf("Memory allocation for schedule failed\n");
     exit(0);
   }
   memset((void*)new,0,sizeof(schedule_t));
   return new;
 }
 
 void insert_schedule(schedule_t *head, schedule_t *new_elem){
   schedule_t *prev=NULL, *next=NULL;
 
   prev = head;
   next = head->next;
 
   while((next!=NULL) && (next->start_time < new_elem->start_time)){
 	  if((next->start_time == new_elem->start_time) && ((new_elem->end_time - new_elem->start_time)<= (next->end_time - next->start_time))){
 		  break;
 	  }
     prev = next;
     next = prev->next;
   }
   new_elem->next = prev->next;
   prev->next = new_elem;
 }
 
 void free_schedule(schedule_t *head_schedule){
   schedule_t *next_schedule = head_schedule->next,*tmp = NULL;
 
   while(next_schedule){
     tmp = next_schedule;
     next_schedule = next_schedule->next;
     free(tmp);
   }
 }
 
 train_t * alloc_train(){
   train_t *new = NULL;
 
   new = (train_t *)malloc(sizeof(train_t));
 
   if(new == NULL){
     printf("Memory allocation for train failed\n");
     exit(0);
   }
   memset((void*)new,0,sizeof(train_t));
   return new;
 }
 
 void insert_train(train_t *head, train_t *new_elem){
   train_t *prev=NULL, *next=NULL;
 
   prev = head;
   next = head->next;
 
   while((next!=NULL) && (next->start_time < new_elem->start_time)){
 
     prev = next;
     next = prev->next;
   }
   new_elem->next = prev->next;
   prev->next = new_elem;
 }
 
 void free_train(train_t *head_train){
   train_t *next_train = head_train->next,*tmp = NULL;
 
   while(next_train){
     tmp = next_train;
     next_train = next_train->next;
     free(tmp);
   }
 }
 
 train_t * find_and_remove_train(train_t *head_train, schedule_t *schedule){
 	  train_t *prev=NULL, *next=NULL;
 
   prev = head_train;
   next = head_train->next;
 
   while(next!=NULL){
 
 	  if((next->start_time <= schedule->start_time) && (next->start_station == schedule->start_station)){
 		  prev->next = next->next;
 		  next->next = NULL;
 		  return next;
 	  }
     prev = next;
     next = prev->next;
   }
   return NULL;
 }
 
 void parse_input_file(FILE *input, schedule_t *head_schedule);
 
 int main (int argc, char *argv[])
 {
  
   int num_entries = 0, count = 1;
   int ret_val = 0;
   FILE *input = NULL, *output = NULL;
   schedule_t head_schedule, *next_schedule = NULL;
   train_t head_train, *train_elem = NULL;
   int num_train_a = 0, num_train_b = 0;
 
   if(argc != 3){
     printf("Usage: ./a.out <input_file_name> <output_file_name> \n");
     return 1;
   }
 
   input = fopen(argv[1], "r");
   if(input == NULL){
     printf("Error opening input file: %s\n", argv[1]);
   }
 
   output = fopen(argv[2], "w");
   if(output == NULL){
     printf("Error opening input file: %s\n", argv[2]);
   }
 
 
   ret_val = fscanf(input,"%d",&num_entries);
 
   if(ret_val == EOF){
     printf("The input file was empty!!\n");
     exit(0);
   }
 
   printf("Number of entries: %d\n",num_entries);
 
   if((num_entries < MIN_LIMIT_N) || (num_entries>MAX_LIMIT_N)){
     printf("Invalid number of input entries!!\n");
     exit(0);
   }
 
   while(num_entries){
     memset((void *)&head_schedule,0,sizeof(schedule_t));
     memset((void *)&head_train,0,sizeof(train_t));
     rtt = 0;
     num_train_a = 0;
     num_train_b = 0;
 
     parse_input_file(input, &head_schedule);
 
     next_schedule = head_schedule.next;
 
     while(next_schedule){
       printf("%d:%d:%d\n",next_schedule->start_time,next_schedule->end_time,next_schedule->start_station);
 
 
       train_elem = find_and_remove_train(&head_train, next_schedule);
       if(train_elem == NULL){
 	      printf("No train found\n");
 	train_elem = alloc_train();
 	if(next_schedule->start_station == 1){
 	  num_train_a++;
 	}
 	else{
 	  num_train_b++;
 	}
       }else{
 	      printf("Train found: start_time %d, start_station %d\n",train_elem->start_time, train_elem->start_station);
       }
 
       train_elem->start_time = next_schedule->end_time + rtt;
       if(next_schedule->start_station == 1){
 	train_elem->start_station = 2;
       }
       else{
         train_elem->start_station = 1;
       }
 
       
       insert_train(&head_train, train_elem);
       
       next_schedule = next_schedule->next;
     }
  
     fprintf(output,"Case #%d: %d %d\n",count,num_train_a,num_train_b);
 
     count++;
     free_schedule(&head_schedule);
     free_train(&head_train);
     
     num_entries--;
   }
   fclose(output);
   fclose(input);
   
   return 0;
 }
 
 void parse_input_file(FILE *input, schedule_t *head_schedule)
 {
   int ret_val = 0;
   int na = 0, nb = 0;
   int start_hr=-1,start_min = -1, end_hr = -1, end_min = -1;
   int start_time=0,end_time=0;
   schedule_t *new_elem = NULL;
   
   ret_val = fscanf(input,"%d",&rtt);
   if(ret_val == EOF){
     printf("Invalid input file!!\n");
     exit(0);
   }
 
   printf("The rtt is %d\n",rtt);
   
   if((rtt<0) || (rtt>60)){
     printf("Invalid round trip time\n");
     exit(0);
   }
   
   ret_val = fscanf(input,"%d%d",&na,&nb);
   if(ret_val == EOF){
     printf("Invalid input file!!\n");
     exit(0);
   }
 
   if((na<MIN_LIMIT_NA || na>MAX_LIMIT_NA) || (nb<MIN_LIMIT_NB || nb>MAX_LIMIT_NB)){
     printf("Invalid round trip time\n");
     exit(0);
   }
 
   printf("NA: %d, NB: %d\n",na,nb);
   
   while(na){
     ret_val = fscanf(input,"%d:%d%d:%d",&start_hr,&start_min,&end_hr,&end_min);
 
     if(ret_val == EOF){
       printf("Invalid input file!!\n");
       exit(0);
     }
 
     printf("Station A: start hr: %d, start min: %d, end_hr: %d, end_min: %d\n",start_hr,start_min,end_hr,end_min);
     
     if((start_hr<0) || (start_hr>23) || (end_hr <0) || (end_hr > 23) || 
         (start_min<0) || (start_min > 59) || (end_min<0) || (end_min > 59)){
       printf("Invalid time!!\n");
       exit(0);
     }
     
     start_time = (start_hr * 60) + start_min;
     end_time = (end_hr * 60) + end_min;
     
     printf("Start time in min: %d, end_time in mins: %d\n",start_time, end_time);
     if(start_time > end_time){
       printf("Invalid input time: start time > end time!!\n");
       exit(0);
     }
 
     new_elem = alloc_schedule();
 
     new_elem->start_time = start_time;
     new_elem->end_time = end_time;
     new_elem->start_station = 1;
 
     insert_schedule(head_schedule, new_elem);
     
     na--;
   }
 
   while(nb){
 
     ret_val = fscanf(input,"%d:%d%d:%d",&start_hr,&start_min,&end_hr,&end_min);
 
     if(ret_val == EOF){
       printf("Invalid input file!!\n");
       exit(0);
     }
 
     printf("Station B: start hr: %d, start min: %d, end_hr: %d, end_min: %d\n",start_hr,start_min,end_hr,end_min);
 
     if((start_hr<0) || (start_hr>23) || (end_hr <0) || (end_hr > 23) || 
         (start_min<0) || (start_min > 59) || (end_min<0) || (end_min > 59)){
       printf("Invalid time!!\n");
       exit(0);
     }
     
     start_time = (start_hr * 60) + start_min;
     end_time = (end_hr * 60) + end_min;
     
     printf("Start time in min: %d, end_time in mins: %d\n",start_time, end_time);
     if(start_time > end_time){
       printf("Invalid input time: start time > end time!!\n");
       exit(0);
     }
 
     new_elem = alloc_schedule();
 
     new_elem->start_time = start_time;
     new_elem->end_time = end_time;
     new_elem->start_station = 2;
 
     insert_schedule(head_schedule, new_elem);
     nb--;
   }
 }

