
 /* This Code solves the Train time table Problem of Google Code Jam Competition */
 #include <stdio.h>
 #include <string.h>
 
 #define MAX_TRAINS   100
 #define MIN_PER_HOUR  60
 #define FROMA    0
 #define FROMB    1
 #define FALSE    0
 #define TRUE     1
 
 
 void sort_by_departures(int n, int dep[], int arr[]);
 
 int main()
 {
     char s[20];
     int ncase;
     int natob,nbtoa;   /* Number of trains from A to B, and B to A respectively */
     int turn_around_time;
     int i,j;
     int hh_dep, mm_dep, hh_arr, mm_arr;
     int dep_a[MAX_TRAINS];
     int arr_a[MAX_TRAINS];
     int dep_b[MAX_TRAINS];
     int arr_b[MAX_TRAINS];
     int a_i,b_i;
     int av_at_a[MAX_TRAINS];
     int av_at_b[MAX_TRAINS];
     int train_req_at_a;
     int train_req_at_b;
     int n_av_a;
     int n_av_b;
     int k,l;
     int nexttrain,av_time;
     int train_available;
 
 
 
     /* Read number of cases*/
     gets(s);
     ncase = atoi(s);
  
     /* Solve for each case */
     for (i=0;i<ncase;i++)
     {
         /* Intialize number of trains required and avilable to 0 */
         n_av_a=0;
         n_av_b=0;
         train_req_at_a=0;
         train_req_at_b=0;
         /* Read turn around time */
         gets(s);
         turn_around_time = atoi(s);
 
         /* Read number of trains from A and B */
         gets(s);
         sscanf(s,"%d %d",&natob,&nbtoa);
 
 
         /* Read train schedule from A to B */
         for (j=0;j<natob;j++)
         {
              gets(s);
              sscanf(s,"%d:%d %d:%d",&hh_dep, &mm_dep, &hh_arr, &mm_arr);
              dep_a[j] = MIN_PER_HOUR*hh_dep + mm_dep;
              arr_a[j] = MIN_PER_HOUR*hh_arr + mm_arr;
         }
         for (j=0;j<nbtoa;j++)
         {
              gets(s);
              sscanf(s,"%d:%d %d:%d",&hh_dep, &mm_dep, &hh_arr, &mm_arr);
              dep_b[j] = MIN_PER_HOUR*hh_dep + mm_dep;
              arr_b[j] = MIN_PER_HOUR*hh_arr + mm_arr;
         }
         sort_by_departures(natob,dep_a,arr_a);
         sort_by_departures(nbtoa,dep_b,arr_b);
 
         a_i = 0;
         b_i = 0;
 
         while ((a_i<natob) || (b_i<nbtoa))
         {
              /* Choose the train from A or B, whichever departs earlier */
              if (a_i==natob)
                 nexttrain = FROMB;
              else if (b_i==nbtoa)
                 nexttrain = FROMA;
              else if (dep_a[a_i]<=dep_b[b_i])   
                 nexttrain = FROMA;
              else
                 nexttrain = FROMB;
                 
 
              if (nexttrain==FROMA)
              {
 
                   /* If train is available at this time then use it else start a new train
                      Make this train available at B at arrival time + turn around time */
                   train_available = FALSE;
                   if (n_av_a>0) /* Check if trains are available at A */
                   {
                        if (av_at_a[n_av_a-1]<=dep_a[a_i])
                        { 
                              /* Train is available on or before departure */
                              train_available = TRUE;
 
                              /* Delete this train from available list */
                              n_av_a--;
                         }
                   }
                   if (train_available==FALSE)
                   {
                        train_req_at_a++;  /* Start a new train */
                   }
                   /* Add this train to available at b */
                   av_time = arr_a[a_i]+turn_around_time;
 
                   /* Find appropriate place for available train so that it is in descending order */
                   k = 0;
 
                   while (k<n_av_b) 
                   {
                       if (av_at_b[k]>av_time)
                       {
                            k++;
                       }
                       else
                       {
                            break;
                       }
                   }
 
                   for (l=n_av_b-1;l>=k;l--)
                   {
                        av_at_b[l+1]=av_at_b[l];
                   }
                   av_at_b[k] = av_time;
                   n_av_b++;
                   a_i++;
              }
              else
              {
                   /* If train is available at this time then use it else start a new train
                      Make this train available at A at arrival time + turn around time */
                   train_available = FALSE;
                   if (n_av_b>0) /* Check if trains are available at B */
                   {
                        if (av_at_b[n_av_b-1]<=dep_b[b_i])
                        { 
                              /* Train is available on or before departure */
                              train_available = TRUE;
 
                              /* Delete this train from available list */
                              n_av_b--;
                         }
                   }
                   if (train_available==FALSE)
                   {
                        train_req_at_b++;  /* Start a new train */
                   }
                   /* Add this train to available at A */
                   av_time = arr_b[b_i]+turn_around_time;
 
                   /* Find appropriate place for available train so that it is in descending order */
                   k = 0;
 
                   while (k<n_av_a) 
                   {
                       if (av_at_a[k]>av_time)
                       {
                            k++;
                       }
                       else
                       {
                            break;
                       }
                   }
 
                   for (l=n_av_a-1;l>=k;l--)
                   {
                        av_at_a[l+1]=av_at_a[l];
                   }
                   av_at_a[k] = av_time;
                   n_av_a++;
                   b_i++;
               }
          }
          printf("Case #%d: %d %d\n",(i+1),train_req_at_a,train_req_at_b);
      
     }
     
     
 
     return 0;
 }
 
 void sort_by_departures(int n, int dep[], int arr[])
 {
      int i,j,tmp;
 
      for (i=0; i<n-1; i++) 
      {
          for (j=0; j<n-1-i; j++)
          {
              if (dep[j+1] < dep[j])   /* compare the two neighbors */
              {
                  tmp = dep[j];         /* swap dep[j] and dep[j+1]      */
                  dep[j] = dep[j+1];
                  dep[j+1] = tmp;
 
                  tmp = arr[j];         /* swap arr[j] and arr[j+1]      */
                  arr[j] = arr[j+1];
                  arr[j+1] = tmp;
              }
          }
       }
       return;
 }
 
 

