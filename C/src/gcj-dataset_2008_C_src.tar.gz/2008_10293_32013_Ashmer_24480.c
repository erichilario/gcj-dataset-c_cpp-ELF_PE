#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define aDEBUG
 
 char search[100][128];
 int snum[100];
 
 int main (int argc , char * argv[])
 {
     int n , i , c , j , k;
     int min , zero , count;
     int engine , query;
     char str[128];
     if (argc == 1)
 	freopen("./input.in","r" , stdin);
     else
 	freopen(argv[1] , "r" , stdin);
     scanf ("%d" , &n);
     for (c = 0 ; c < n ; c ++)
     {
 	count = 0;
 	scanf ("%d" , &engine);
 	gets(str );
 	zero = engine;
 	for (i = 0 ; i < engine ; i++)
 	{
 	    gets(search[i]);
 	}
 	scanf ("%d" , &query);
 	gets(str);
 	for (i = 0 ; i < engine ; i++)
 	    snum[ i ] = 0;
 	for (i = 0 ; i < query ; i++)
 	{
 	    gets(str);
 	    for (j = engine - 1 ; j > 0 ; j --)
 		if (strcmp(search[j] , str) == 0)
 		    break;
 		if ( snum[j] == 0 )
 		{
 		    zero --;
 		    if (zero == 0)
 		    {
 			count ++;
 			zero = engine - 1;
 			for (k = 0 ; k < engine ; k++)
 			    snum[ k ] = 0;
 		    }
 		}
 		snum[ j ] += 1;
 	}
 	printf ("Case #%d: %d\n" , c + 1 , count);
     }
     return 0;
 }
 

