#include<stdio.h>
 #include<stdio.h>
 #define MAX_SEARCH_EN  120
 #define MAX_SEARCH 250
 #define MAX_SE 101
 #define MAX_Q 1001
 char sen[MAX_SE][MAX_SEARCH_EN];
 char sq[MAX_Q][MAX_SEARCH];
 int se[MAX_SE];
 int a,b;
 void read(void)
 {    int i;
      scanf("%d",&a);getchar();
      /*printf("%d",a);*/
      for(i=0;i<a;++i)
       {scanf("%[^\n]%*c",sen[i]);
         /*printf("%s\n",sen[i]);*/
         }  
     scanf("%d",&b);getchar();
     /*printf("%d",b);*/
       for(i=0;i<b;++i)
     {  
         scanf("%[^\n]%*c",sq[i]);
         /*printf("%s\n",sq[i]);*/
         }
         
       for(i=0;i<a;++i)
       se[i]=0;
     return;    
 }   
 int main()
 {
     int i,j;
     scanf("%d",&i);
     /*printf("%d",i);*/
     for(j=0;j<i;++j)
      {  int sw=0,k=0;
         read();
         while(k<b)
          { int x,y;
            for(x=0;x<a;++x)
              if(strcmp(sq[k],sen[x])==0)
                if(se[x]==0)
                 { se[x]=1;
                  y=x;
                 }   
            for(x=0;x<a;++x)
             if(se[x]==1)
              continue;
             else
              break;
           if(x==a)
            { ++sw;
              for(x=0;x<a;++x)
              se[x]=0;
              se[y]=1;
            }    
            ++k;
         }     
         printf("Case #%d: %d\n",j+1,sw);     
      }
     return 0;
 }   

