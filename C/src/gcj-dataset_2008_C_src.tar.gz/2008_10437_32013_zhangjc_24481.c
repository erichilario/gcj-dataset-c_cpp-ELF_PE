#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 struct time1
 {
 	int depart;
 	int arriv;
 }Node;
 
 int Cmpdep(const void *a,const void *b)
 {
 
 	return (*(struct time1 *)a).depart > (*(struct time1 *)b).depart?1:-1;
 
 }
 
 int Cmparr(const void *a,const void *b)
 
 {
 
 	return (*(struct time1 *)a).arriv > (*(struct time1 *)b).arriv?1:-1;
 
 }
 
 
 
 
 struct time1 natime[100],nbtime[100];
 
 int n,na,nb,t,dept[100],arr[100],tempa,tempb;
 	FILE *fp,*out;
 
 void input()
 {
 
         int j,t1,t2;
 		char a;
 
 		fscanf(fp,"%d",&t);
 
 		fscanf(fp,"%d%d",&na,&nb);
         tempa=na;
 		tempb=nb;
         fgetc(fp);
 		for(j=0;j<na;j++)
 		{
 			t1=(((a=fgetc(fp))-'0')*10+((a=fgetc(fp))-'0'))*60;
 			a=fgetc(fp);
 		
 			t2=((a=fgetc(fp))-'0')*10+((a=fgetc(fp))-'0');
            
 			natime[j].depart=t1+t2;
 
 			a=fgetc(fp);
 			t1=(((a=fgetc(fp))-'0')*10+((a=fgetc(fp))-'0'))*60;
 				a=fgetc(fp);
 			
 			t2=((a=fgetc(fp))-'0')*10+((a=fgetc(fp))-'0');
 			natime[j].arriv=t1+t2;
 				a=fgetc(fp);
 		}
 
 
 		for(j=0;j<nb;j++)
 		{
 			t1=(((a=fgetc(fp))-'0')*10+((a=fgetc(fp))-'0'))*60;
 			a=fgetc(fp);
 		
 			t2=((a=fgetc(fp))-'0')*10+((a=fgetc(fp))-'0');
            
 			nbtime[j].depart=t1+t2;
 
 				a=fgetc(fp);
 			t1=(((a=fgetc(fp))-'0')*10+((a=fgetc(fp))-'0'))*60;
 			a=fgetc(fp);
 		
 			t2=((a=fgetc(fp))-'0')*10+((a=fgetc(fp))-'0');
 			nbtime[j].arriv=t1+t2;
 				a=fgetc(fp);
 		}
 }
 
 
 
 void proce()
 {
 	int pa=0,pb=0;
 
 	qsort(nbtime,nb,sizeof(Node),Cmpdep);
 	qsort(natime,na,sizeof(Node),Cmparr);
 
 	for(;pa<na&&pb<nb;)
 	{
 		if(nbtime[pb].depart-t>=natime[pa].arriv)
 		{
 			pb++;
 		    pa++;
 			tempb--;
 		}
 		else 
 
               pb++;
 	}
 
 	qsort(nbtime,nb,sizeof(Node),Cmparr);
 	qsort(natime,na,sizeof(Node),Cmpdep);
 	pa=0;pb=0;	
     for(;pa<na&&pb<nb;)
 	{
 		if(natime[pa].depart-t>=nbtime[pb].arriv)
 		{
 			pb++;
 		    pa++;
 			tempa--;
 		}
 		else 
 
               pa++;
 	}
 }
 
 
 
 
 
 
 
 int main()
 {
 
 	int i;
 
 	fp=fopen("small.in","r");
     out=fopen("out.out","w");
 	fscanf(fp,"%d",&n);
 	for(i=0;i<n;i++)
 	{
 		input();
 
 		proce();
 		dept[i]=tempa;
 		arr[i]=tempb;
 	}
 
 		for(i=0;i<n;i++)
 	{
 		fprintf(out,"Case #%d: %d %d\n",i+1,dept[i],arr[i]);
 	}
     fclose(fp);
 	return 0;
 
 }
 
 
 
 
 
 
 
 
 
 
 
 		
 
 

