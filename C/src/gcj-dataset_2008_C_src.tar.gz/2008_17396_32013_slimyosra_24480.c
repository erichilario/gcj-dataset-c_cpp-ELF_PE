// code compiled with MS vc++ 6
 #include<stdio.h>
 #include<string.h>
 #include<cstdlib>
 //struct declaration 
 typedef struct list
 {
 	char *name;
 	unsigned int searched;
 	struct list *prev;
 	struct list *next;
 } list ;
 
 
 //define 
 //#define EXIT_SUCCESS 0
 //#define EXIT_FAILURE -1
 #define EMPTY_QUERY 0
 #define MAX_SE 100
 #define MAX_Q 1000
 
 //function declaration 
 FILE *openInput( char* );
 void output( int,int  );
 int getInt( void );
 int loadList( list** );
 void listDec( list**  );
 void listInc( list**  );
 void listRewind( list** );
 int listFindMin( list* );
 void listFree( list** );
 int listInsert( char*, list** );
 void flushMx( void );
 int getMax(  int , int);
 //globals
 FILE *hIn = NULL;
 list *se = NULL;
 list *q = NULL;
 int mx[MAX_SE][MAX_Q];//S Q 
 
 int main( int argc, char ** argv[] )
 {
 	//Local vars
 	int n=0;// number of cases
 	int x=0;// current case number
 	int y=0;//number of switches
 	int S;
 	int Q;
 	int pos;
 	int i, j;
 	if( argc < 2 )
 	{
 		printf("error in parameters");
 		return EXIT_FAILURE;
 	}
 
 	hIn = openInput( argv[argc-1] );
 
 	if( hIn == NULL )
 	{
 		printf("error reading input");
 		return EXIT_FAILURE;
 	}
 	
 	n = getInt();
 
 	if( n<= 0 )
 	{
 		printf("error number of cases null or negative");
 		return EXIT_FAILURE;
 	}
 
 	for( x=0; x<n; x++)
 	{
 		
 		S = loadList( &se );
 		if( S < 2 )
 		{
 			printf("error loading list se");
 			return EXIT_FAILURE;
 		}
 		
 		Q = loadList( &q );
 		if( Q < 0 )
 		{
 			printf("error loading list q");
 			return EXIT_FAILURE;
 		}
 		if( Q == EMPTY_QUERY )
 		{
 			listFree(&se);
 			output(x,1);
 			continue;
 			
 		}
 		for( i = 0;i<S; i++)
 		{
 			for( j = 0; j< Q; j++)
 			{
 				if( strcmp(se->name,q->name) ==  0 )
 				{
 					mx[i][j]=0;
 				}
 				else
 				{
 					mx[i][j]=1;
 				}
 				if( j != Q-1 )
 				{
 					listInc( &q );
 				}
 			}
 			listRewind( &q );
 			if( i != S-1 )
 			{
 				listInc( &se );
 			}
 		}
 		for( i = 0;i<S; i++)
 		{
 			for(  j = Q-2; j>= 0; j--)
 			{
 				if( mx[i][j] != 0 )
 					mx[i][j]=mx[i][j+1] + 1;
 			}
 		}
 		y=0;
 		pos = 0;
 		while( pos < Q )
 		{
 			pos += getMax(  pos, S );
 			y++;
 		}
 
 #ifdef old
 		while(1)
 		{	
 			if( strcmp(se->name,q->name) ==  0 )
 			{
 				se->searched++;
 			}
 
 			if( q->next != NULL )//did not reach the last query
 			{
 				listInc( &q );
 			}
 			else
 			{
 				if( se->next != NULL )// move to the next search
 				{
 					if( se->searched == 0 )
 					{
 						// all the query cqn be executed by this SE with any switch no need to look further
 						break;
 					}
 					listInc ( &se );
 					listRewind( &q );
 					
 				}
 				else
 				{
 					break;
 				}
 			}
 		}
 #endif
 
 		
 		listRewind( &se );
 		output(x,y);
 		listFree( &se );
 		listFree( &q );
 	}
 	fclose(hIn);
 
 	return EXIT_SUCCESS;
 }
 
 void listFree( list ** l )
 {
 	list * tmp;
 	listRewind( l );
 	while( (*l) )
 	{
 		tmp = (*l)->prev;
 		free((*l));
 		(*l) = tmp;
 	}
 }
 FILE *openInput( char* file )
 {
 	hIn = fopen ( file,"r");
 	if (hIn ==NULL)
 	{
 		return NULL;
 	}
 	return hIn;
 
 }
 
 void output( int x,int y  )
 {
 	FILE* h = fopen("output.txt","a+");
 	if( h == NULL )
 	{
 		return;
 	}
 	fprintf(h, "Case #%d: %d\n",x+1,y-1);
 	fclose(h);
 
 }
 
 int getInt( void )
 {
 	char *str = malloc( 5 );
 	int n;
 	fgets(str,5,hIn );
 	n = atoi( str );
 	free( str );
 	return n;
 }
 
 int loadList( list** l)
 {
 	int size;
 	int retval;
 	char* buffer = malloc( 100 ) ;// the max size 
 	//first read the list size
 	size = getInt();
 	retval = size;
 	if( size == 0 )
 	{
 		return EMPTY_QUERY;
 	}
 	while( size > 0 )
 	{
 		memset(buffer,0,100);
 		fgets(buffer,100,hIn);
 		if ( listInsert(buffer, l) == EXIT_FAILURE )
 		{
 			return -1;
 		}
 		size--;
 	}
 	listRewind( l );
 	free(buffer);
 	return retval;
 }
 
 int listInsert( char * str , list **l)
 {
 	list* tmp = (list*)malloc( sizeof(list));
 	if( tmp == NULL )
 	{
 		return EXIT_FAILURE;
 	}
 	tmp->searched = 0;
 	tmp->name = (char*)malloc(strlen(str));
 	if( tmp->name == NULL )
 	{
 	
 		return EXIT_FAILURE;
 	}
 	strcpy(tmp->name,str);
 	
 	if( *l == NULL ) // first one
 	{
 		*l = tmp;
 		(*l)->prev = NULL;
 		(*l)->next = NULL;
 	}
 	else
 	{
 		(*l)->next = tmp;
 		tmp->prev = *l;
 		tmp->next = NULL;
 		(*l) = tmp;
 	}
 
 	return EXIT_SUCCESS;
 
 }
 void listInc( list **l )
 {
 	if( !(*l) )
 	{
 		return;
 	}
 	(*l) = (*l)->next;
 
 }
 
 void listDec( list **l  )
 {
 	if( !(*l) )
 	{
 		return;
 	}
 	(*l) = (*l)->prev;
 
 }
 void listRewind( list **l)
 {
 	while( (*l)->prev )
 	{
 		(*l) = (*l)->prev;
 	}
 }
 
 int listFindMin( list* l)
 {
 	unsigned int min = 0xFFFFFFFF;
 	while( l  )
 	{
 		if( min > l->searched )
 		{
 			min = l->searched;
 		}
 		listDec( &l );
 	}
 	return min;
 }
 
 
 
 
 void flushMx( void )
 {
 	int i,j;
 	for( i = 0;i<MAX_SE; i++)
 		for( j = 0; j< MAX_Q; j++)
 			mx[i][j]=0;
 }
 
 int getMax( int j, int size )
 {
 	int i;
 	unsigned int max = 0;
 	for( i = 0; i< size; i++)
 	{
 		if( max < mx[i][j])
 		{
 			max = mx[i][j];
 		}
 	}
 	return max;
 }
 
 
 
 
 
 //EOF
