#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int ncasos, nbusc, nquery;
 char busca[102][105];
 char query[1001][105];
 int visitados[102];
 int faltan_visitar;
 int cambios;
 
 void imprime() {
   int i;
   printf("Buscadores %d: \n", nbusc);
   for (i = 0 ; i < nbusc ; i++) {
     printf("%s\n", busca[i]);
   }
 
   printf("Queries %d: \n", nquery);
   for (i = 0 ; i < nquery ; i++) {
     printf("%s\n", query[i]);
   }
 
 }
 
 void inicializa_visitados() {
   int i;
   for( i = 0 ; i < nbusc ; i++ ) 
     visitados[i] = 0;
   cambios++;
   faltan_visitar = nbusc;
 }
 
 int posicion(char * query) {
   int i;
   for( i = 0 ; i < nbusc ; i++ ) {
     if (!strcmp(query, busca[i]))
       return i;
   }
 }
 
 
 int main (int argc, char * argv []) {
 
   int i, j, k, pos_act;
 
   scanf("%d\n", &ncasos);
 
   for( i = 0 ; i < ncasos ; i++ ) {
     
     scanf("%d\n", &nbusc);
     
     for(j = 0 ; j < nbusc ; j++ ) 
       fgets(busca[j], 104, stdin);
     
     scanf("%d\n", &nquery);
 
     for(j = 0 ; j < nquery ; j++ ) 
       fgets(query[j], 104, stdin);
 
     /* Fichero leido. */
 
     /*  imprime(); */
 
     cambios = -1;
     inicializa_visitados();
 
     for ( k = 0 ; k < nquery ; k++ ) {
       pos_act = posicion(query[k]);
       if (!visitados[pos_act]) {
 	if (faltan_visitar > 1) {
 	  visitados[pos_act] = 1;
 	  faltan_visitar--;
 	} else {
 	  inicializa_visitados();
 	  k--;
 	}
       }
     }
 
     printf("Case #%d: %d", i + 1, cambios);
     if (i < ncasos - 1) printf("\n");
 
   }
 
 
   return 0;
 }

