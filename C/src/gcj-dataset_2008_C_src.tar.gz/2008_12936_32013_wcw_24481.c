#include <stdio.h>
 #include <stdlib.h>
 
 int cmp(const void *x, const void *y)
 {
 	int *i1 = (int *)x;
 	int *i2 = (int *)y;
 	return *i1 - *i2;
 //	return i2 - i1;
 }
 
 int getdigit(const char *s)
 {
 	const char *c = s;
 	int res = 0;
 	res += (*c - '0') * 1000;
 	c++;
 	res += (*c - '0') * 100;
 	c++; c++;
 	res += (*c - '0') * 10;
 	c++;
 	res += (*c - '0');
 	
 	return res;
 }
 
 void print_sorted(const int *a, const int *b, int n)
 {
 	int i;
 	for (i = 0; i < n; i++){
 		printf("%d %d\n", *(a + i), *(b + i));
 	}
 	printf("\n");
 }
 
 int getres(int na, int nb, const int *sa, const int *ra, int t)
 {
 	
 	int index, x, y, res;
 	res = index = 0;
 
 	for (x = 0; x < na; x++){
 		for (y = index; y < nb; y++){
 			if (sa[x] - t >= ra[y]){
 				index ++;
 				break;
 			}
 		}
 		if (y == nb)
 			res++;
 	/*	if (index == nb){
 			res += na -1 - x;
 		}
 		*/
 	}
 
 	return res;
 }
 
 int main()
 {
 	int n, na, nb, t, i, j;
 	int *sa, *rb, *sb, *ra;
 	char s1[6], s2[6];
 	int res1, res2;
 	res1 = res2 = 0;
 
 	scanf("%d", &n);
 	for (i = 1; i <= n; i++){
 		scanf("%d%d%d", &t, &na, &nb);
 		sa = (int*) malloc (sizeof(int) * na);
 		rb = (int*) malloc (sizeof(int) * na);
 		sb = (int*) malloc (sizeof(int) * nb);
 		ra = (int*) malloc (sizeof(int) * nb);
 		
 		for (j = 0; j < na; j++){
 			scanf("%s%s", s1, s2);
 			sa[j] = getdigit(s1);
 			rb[j] = getdigit(s2);
 		}
 		qsort(sa, na, sizeof(int), cmp);
 		qsort(rb, na, sizeof(int), cmp);
 //print_sorted(sa, rb, na);	
 		for (j = 0; j < nb; j++){
 			scanf("%s%s", s1, s2);
 			sb[j] = getdigit(s1);
 			ra[j] = getdigit(s2);
 		}
 		qsort(sb, nb, sizeof(int), cmp);
 		qsort(ra, nb, sizeof(int), cmp);
 //print_sorted(sb, ra, nb);	
 		res1 = getres(na, nb, sa, ra, t);
 		res2 = getres(nb, na, sb, rb, t);
 		printf("Case #%d: %d %d\n", i, res1, res2);
 		res1 = res2 = 0;
 	}
 }

