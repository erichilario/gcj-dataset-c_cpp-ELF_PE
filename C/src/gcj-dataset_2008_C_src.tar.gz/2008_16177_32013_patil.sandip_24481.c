#include<stdio.h>
 
 
 int L[100],R[100];
 void Merge(int A[],int p,int q,int r)
 {
 int n1=q-p+1;
 int n2=r-q;
 int i,j,k;
 
 for(i=0;i<n1;i++)
    L[i]=A[p+i];
 
 for(j=0;j<n2;j++)
    R[j]=A[q+j+1];
 
 i=j=0;
 
 for(k=p;k<=r;k++)
    {
    if(L[i] <= R[j])
      {
      A[k]=L[i];
      i++;
      }
    else
      {
      A[k]=R[j];
      j++;
      }
 
      if(i==n1)
      {
      k++;
      for(;j<n2;j++)
 	A[k++]=R[j];
      break;
      }
      if(j==n2)
      {
      k++;
      for(;i<n1;i++)
 	A[k++]=L[i];
      break;
      }
    }
 
 
 }
 
 void Merge_Sort(int A[],int p, int r)
 {
 if(p<r)
   {
   int q=(p+r)/2;
   Merge_Sort(A,p,q);
   Merge_Sort(A,q+1,r);
   Merge(A,p,q,r);
   }
 }
 
 void main()
 {
 int train_A,train_B,i;
 int AA[100],DA[100],AB[100],DB[100],AA_cnt,DA_cnt,AB_cnt,DB_cnt;
 int cnt_A,cnt_B,h1,m1,h2,m2;
 int crt_testcase,N,turnaround;
 FILE *fp,*fpout;
 clrscr();
 
 if ((fp = fopen("d:\\san\\codejam\\2\\input.txt", "rt"))
     == NULL)
 {
    fprintf(stderr, "Cannot open input file.\n");
    return;
 }
 
 if ((fpout = fopen("d:\\san\\codejam\\2\\output.txt", "wt"))
     == NULL)
 {
    fprintf(stderr, "Cannot open input file.\n");
    return;
 }
 
 fscanf(fp,"%d\n",&N);
 
 crt_testcase=0;
 while(crt_testcase++<N)
 {
 	fprintf(fpout,"Case #%d: ",crt_testcase);
 
 	fscanf(fp,"%d\n",&turnaround);
 	fscanf(fp,"%d\n",&cnt_A);
 	fscanf(fp,"%d\n",&cnt_B);
 	printf("%d\n%d %d",turnaround,cnt_A,cnt_B);
 
 	for(i=0;i<cnt_A;i++)
 	{
 		fscanf(fp,"%d:%d %d:%d\n",&h1,&m1,&h2,&m2);
 		DA[i]=h1*60+m1;
 		AB[i]=h2*60+m2+turnaround;
 		printf("%d:%d %d:%d   %d  %d\n",h1,m1,h2,m2,DA[i],AB[i]);
 	}
 
 	for(i=0;i<cnt_B;i++)
 	{
 		fscanf(fp,"%d:%d %d:%d\n",&h1,&m1,&h2,&m2);
 		DB[i]=h1*60+m1;
 		AA[i]=h2*60+m2+turnaround;
 		printf("%d:%d %d:%d   %d  %d\n",h1,m1,h2,m2,DB[i],AA[i]);
 	}
 
 
 	train_A=calculate(AA,DA,cnt_B,cnt_A);
 	train_B=calculate(AB,DB,cnt_A,cnt_B);
 	fprintf(fpout,"%d %d\n",train_A,train_B);
 }
 
 }
 
 int calculate(int A[],int D[],int A_cnt,int D_cnt)
 {
 int traincnt=0,A_ptr=0,D_ptr=0;
 Merge_Sort(A,0,A_cnt-1);
 Merge_Sort(D,0,D_cnt-1);
 
 while(A_ptr<A_cnt && D_ptr<D_cnt)
 {
 	if(A[A_ptr]<=D[D_ptr])
 	{
 		A_ptr++;
 		D_ptr++;
 	}
 	else
 	{
 		traincnt++;
 		D_ptr++;
 	}
 }
 
 if(A_ptr==A_cnt&&D_ptr<D_cnt)
 {
 	traincnt = traincnt + D_cnt - D_ptr;
 }
 return traincnt;
 }
 

