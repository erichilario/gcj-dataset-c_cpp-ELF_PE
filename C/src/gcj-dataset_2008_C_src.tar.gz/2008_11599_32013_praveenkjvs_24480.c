#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 //#define debug 1
 
 //function definitions
 int readNoOfcases(void);
 int readCase(void);
 int processCase(void);
 int updateDB(const char*);
 void resetDB(void);
 void showResults(void);
 
 //global Variables
 int iflag = 0;
 int iNoOfCases = 0;
 int iNoOfSearchEngines = 0;
 int iNoOfQueries = 0;
 int iDBSEN[100];
 int iResults[20];
 int iCurrentCase;
 char cSEN[100][100];
 char cQueries[1000][100];
 char cGlobalTemp[100];
 FILE *ptrInputFile = NULL;
 
 
 
 int main(void){
      
      int iFunc_readNoOfcases = 0;
      int iFunc_readCase = 0;
      int iTemp = 0;
      
      //open file to read input
      ptrInputFile = fopen("A-large.in", "r");
      if(ptrInputFile == NULL){
         printf("\n Error Opening Input File. Existing.");
         getchar();
         return(1);
      }
      
      iFunc_readNoOfcases = readNoOfcases();
      #ifdef debug
      if(iFunc_readNoOfcases != 0)
                  printf("\nError Reading File. Error in function: readNoOfcases()\n");
      #endif
      
      
      //loop for each case
      for (iTemp = 1; iTemp <= iNoOfCases; iTemp++)
      {
          printf("\ncurrent case = %d", iTemp);
          if (iTemp == iNoOfCases) iflag = 1;
          iCurrentCase = iTemp - 1;
          iFunc_readCase = readCase();
      }
      
      fclose(ptrInputFile);
      
      //displaying results
      showResults();
      
      getchar();
      return 0;
 }
      
      
 int readNoOfcases(){
     
     char *cReturnCode;
     
     //reading no of cases
     cReturnCode = fgets(cGlobalTemp, 100, ptrInputFile);
     //check for char *cReturnCode; == NULL for error in reading
     cGlobalTemp[strlen(cGlobalTemp)-1] = '\0';   
     iNoOfCases = atoi(cGlobalTemp);
     
     
     #ifdef debug
     printf("iNoOfCases = %d",iNoOfCases);
     #endif
     
     return 0;
     
 }
 
 int readCase(void){
     
     int iTemp = 0;
     int iReturn = 0;
     char *cReturnCode;
     
     //reading no of search Engines
     cReturnCode = fgets(cGlobalTemp, 100, ptrInputFile);
     cGlobalTemp[strlen(cGlobalTemp)-1] = '\0';
     //check for char *cReturnCode; == NULL for error in reading
     iNoOfSearchEngines = atoi(cGlobalTemp);
     
     
     #ifdef debug
     printf("\niNoOfSearchEngines = %d",iNoOfSearchEngines);
     #endif
         
     
     for (iTemp = 1; iTemp <= iNoOfSearchEngines; iTemp++)
     {
         cReturnCode = fgets(cGlobalTemp, 100, ptrInputFile);
         cGlobalTemp[strlen(cGlobalTemp)-1] = '\0';
         //check for char *cReturnCode; == NULL for error in reading
         
         strcpy(cSEN[iTemp-1], cGlobalTemp);
         iDBSEN[iTemp - 1] = 0;
         
         #ifdef debug
         printf("\nSearch Engine = %s", cSEN[iTemp-1]);
         #endif
     }
     
     //getting number of queries
     cReturnCode = fgets(cGlobalTemp, 100, ptrInputFile);
     cGlobalTemp[strlen(cGlobalTemp)-1] = '\0';
     //check for char *cReturnCode; == NULL for error in reading
     iNoOfQueries = atoi(cGlobalTemp);
     
     
     #ifdef debug
     printf("\niNoOfQueries = %d",iNoOfQueries);
     #endif
     
     // reading the query queue
     
     for (iTemp = 1; iTemp <= iNoOfQueries; iTemp++)
     {
         /*if ((iflag == 1) && (iTemp == iNoOfQueries))
         {
            fscanf(ptrInputFile, "%s", cGlobalTemp);
            
            #ifdef debug
            printf("\n******************\n");
            printf("Query = %s", cGlobalTemp);
            printf("\n******************\n");
            #endif
            
            strcpy(cQueries[iTemp-1], cGlobalTemp);
            continue;
         }
         */
         cReturnCode = fgets(cGlobalTemp, 100, ptrInputFile);
         cGlobalTemp[strlen(cGlobalTemp)-1] = '\0';
         //check for char *cReturnCode; == NULL for error in reading
         
         strcpy(cQueries[iTemp-1], cGlobalTemp);
         
         #ifdef debug
         printf("\nQuery = %s", cQueries[iTemp-1]);
         #endif
         
         
     }
     
     
     iReturn = processCase();
     iResults[iCurrentCase] = iReturn;
     
     #ifdef debug
     printf("\n iNoOfSwitches = %d", iReturn);
     getchar();  
     #endif 
     
     return 0;
 }
 
 int processCase(void){
     
     int iTemp = 0;
     int iRemain = 0;
     int iNoOfSwitches = -1;
     char cCSEN[100];
     char cCQ[100];
     int iReturnUpdateDB;
     
     iRemain = iNoOfSearchEngines;
     
     
     for (iTemp = 1; iTemp <= iNoOfQueries; iTemp++)
     {
         
         strcpy(cCQ, cQueries[iTemp-1]);
         iReturnUpdateDB = updateDB(cCQ);
         
         if (iReturnUpdateDB == 1)
         {
            iRemain--;
            if (iRemain == 0)
            {
               iNoOfSwitches++;
               iTemp--;
               iRemain = iNoOfSearchEngines;
               resetDB();
            }
         }
         if (iReturnUpdateDB == -1)
         {
            printf("\n Fatal Error in function updateDB(). Existing.");
            getchar();
            exit(0);
         }
     }
     
     return (iNoOfSwitches+1);
  
 }
 
 int updateDB(const char *SEN)
 {
     
     int iTemp = 0;
     int iCompare = 0;
     int iEarlierValue = -1;
     
     for (iTemp = 1; iTemp <= iNoOfSearchEngines; iTemp++)
     {
         iCompare = strcmp(SEN, cSEN[iTemp-1]);
         
         #ifdef debug
         //printf("\n SEN = %s\n cSEN = %s",SEN,cSEN[iTemp-1]);
         //printf("iCompare = %d", iCompare);
         #endif
         
         if (iCompare == 0)
         {
            iEarlierValue = iDBSEN[iTemp-1];
            
            if (iEarlierValue == 0)
            {
               iDBSEN[iTemp-1] = 1;
               return 1;
            }
            else
                return 0;
         }
     }
     
     return -1;
 }
 
 void resetDB(void){
      
      int iTemp = 0;
      
      for (iTemp = 1; iTemp <= iNoOfSearchEngines; iTemp++)
      {
          iDBSEN[iTemp-1] = 0;
      }
 }
 
 void showResults(void){
      
      int iTemp = 0;
      
      FILE *ptrOutputFile;
      
      ptrOutputFile = fopen("output.txt", "w");
      
      for (iTemp = 1; iTemp <= iNoOfCases; iTemp++)
      {
          if (iTemp == iNoOfCases)
             fprintf(ptrOutputFile, "Case #%d: %d", iTemp, iResults[iTemp-1]);
          else
              fprintf(ptrOutputFile, "Case #%d: %d\n", iTemp, iResults[iTemp-1]);
      }
      fclose(ptrOutputFile);
 }

