/*
  	CODED BY DAVID RIOS PUIG
 	FOR GOOGLE CODE JAM
 	17/07/2008
 */
 
 #include <stdio.h>
 #include <string.h>
 
 void getname(char *name, FILE *fin);
 
 void main(int argc, char **argv)
 {
 	if (argc != 2)
 	{
 		printf("Usage: ./stu A-small.in\n");
 		exit(0);
 	}
 	
 	//File input & File output
 	FILE *fin, *fout;
 
 	//Number of case
 	int ncase;
 
 	//Number os search engines and querys
 	int nse,nquerys;
 
 	//Struct of search engines
 	struct se { int pos; char name[100]; } *se_array;
 
 	//Struct of querys
 	struct que { char name[100]; } *que_array;
 
 	//Iterators and controls
 	int i, j, k, final=0, act=0;
 
 	//Number of switchs and actual max
 	int sw; char *aname;
 
 	//Opening input file
 	if((fin=fopen(argv[1],"r")) == NULL)
 	{
 		printf("Error opening input file\n");
 		exit(-1);
 	}
 
 	//Setting number of case
 	fscanf(fin,"%d", &ncase);
 
 	//Opening output file
 	if((fout=fopen("A-small.out","w")) == NULL)
 	{
 		printf("Error opening output file\n");
 		exit(-1);
 	}
 
 	for(k=0;k<ncase; k++)
 	{
 		//Init switchs
 		sw = 0;
 
 		//Init act
 		act = 0;
 		
 		//Init final
 		final = 0;
 
 		//Reading number of Search Engines
 		fscanf(fin,"%d\n", &nse);
 		se_array = malloc(nse * sizeof(struct se));
 
 		//Init Search Engines		
 		for(i=0;i<nse;i++)
 		{
 			getname(se_array[i].name,fin);
 			se_array[i].pos = -1;
 		}
 		
 		//Reading number of Querys
 		fscanf(fin,"%d\n",&nquerys);
 
 		if(nquerys > 0)
 		{
 			que_array = malloc(nquerys * sizeof(struct que));
 	
 			//Init Querys
 			for(i=0;i<nquerys;i++)
 			{
 				getname(que_array[i].name,fin);		
 			}
 			
 			//Algorithm
 			while(final == 0)
 			{
 				for(i=0;i<nse;i++)
 				{
 					for(j=act;j<nquerys;j++)
 					{
 						if(!strcmp(se_array[i].name,que_array[j].name))
 						{
 							se_array[i].pos = j;
 							j=nquerys;
 						}
 					}
 
 					if(se_array[i].pos == -1)
 					{
 						i = nse;
 						final = 1;
 					}			
 				}
 				if (final == 0)
 				{
 					act = se_array[0].pos;
 					se_array[0].pos = -1;
 
 					for(i=1;i<nse;i++)
 					{
 						if(se_array[i].pos>act)
 						{
 							act = se_array[i].pos;
 						}
 						se_array[i].pos = -1;
 					}
 					sw++;
 				}
 			}
 			free(que_array);
 			free(se_array);
 		}
 		fprintf(fout,"Case #%d: %d\n", k+1, sw);
 	}
 	fclose(fout);
 	fclose(fin);
 	exit(0);
 }
 
 void getname(char *name, FILE *fin)
 {
 	char c;
 	int i=0;
 	
 	while(1)
 	{
 		if(fscanf(fin,"%c",&c) != EOF)
 		{
 			if(c!= '\n')
 			{
 				name[i++]=c;
 			}
 			else
 			{
 				name[i]='\0';
 				break;
 			}
 		}
 		else
 		{
 			name[i]='\0';
 			break;
 		}
 	}
 }
