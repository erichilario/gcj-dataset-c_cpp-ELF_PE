// Excuse for an ugly looking code :)))
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <strings.h>
 
 #define SEnameMax 100
 
 char SEnames[100][SEnameMax];
 char Queries[1000][SEnameMax];
 
 int SeCanExecuteQueries[100];
 
 int N = 0;
 int S = 0;
 int Q = 0;
 
 int QryStrt = 0;
 
 int CanExecute ( int SEidx )
 {
     int res = 0;
 
     int i = 0;
     for ( i = QryStrt; i < Q; i++ )
     {
         if ( strcmp ( SEnames[SEidx], Queries[i] ) != 0 )
         {
             res++;
         }
         else
         {
             break;
         }
     }
 
     return res;
 }
 
 void select ( int SEidx )
 {
     QryStrt = QryStrt + SeCanExecuteQueries[SEidx];
 }
 
 int main(int argc, char * argv[])
 {
     if ( argc < 1 )
     {
         printf ( "Error: please specify name of an input set file\n" );
     }
 
     FILE *fin;
     FILE *fout;
 
     fin=fopen (argv[1],"r");
     if (fin==NULL)
     {
         puts ("Error reading input file");
         exit(EXIT_FAILURE);
     }
 
     int j = 0;
     char tmp[100];
 
     fout = fopen ("set.out","w");
 
 
     fgets(tmp, 100, fin);
     N = atoi(tmp);
 
     for ( j = 0; j < N; j++)
     {
         QryStrt = 0;
         memset(SEnames, 0, sizeof(SEnames) );
         memset(Queries, 0, sizeof(Queries) );
         memset(SeCanExecuteQueries, 0, sizeof(SeCanExecuteQueries) );
 
         fgets(tmp, 100, fin);
         S = atoi(tmp);
 
         int i = 0;
 
         for ( i = 0; i < S; i++ )
         {
             fgets(SEnames[i], SEnameMax, fin);
         }
 
         fgets(tmp, 100, fin);
         Q = atoi(tmp);
 
         for ( i = 0; i < Q; i++ )
         {
             fgets(Queries[i], SEnameMax, fin);
         }
 
         for ( i = 0; i < S; i++ );
         {
                 SeCanExecuteQueries[i] = 0;
         }
 
         int cnt = -1;
         if ( Q == 0 )
         {
             cnt = 0;
         }
 
         while ( QryStrt < Q )
         {
             for ( i = 0; i < S; i++ )
             {
                 SeCanExecuteQueries[i] = CanExecute(i);
             }
 
             int k = 0;
             for ( i = 1; i < S; i++ )
             {
                 if ( SeCanExecuteQueries[k] < SeCanExecuteQueries[i] )
                 {
                     k = i;
                 }
             }
 
             select(k);
             cnt++;
         }
 
         sprintf(tmp, "Case #%i: %i\n", j + 1, cnt );
         fputs(tmp, fout);
     }
 
     fclose ( fin );
     fclose ( fout );
 
     return 0;
 }

