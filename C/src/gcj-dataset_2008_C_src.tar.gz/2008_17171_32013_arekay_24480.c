#include "genlogfile.h"
 /**************************************************************************************
 /* this file contains the methods for logging the flow the program into the logfile
 /* Three functions are initially planned
 /* The first function is supposed to create the log file 
 /* The second function appends a line of program into the logfile
 /* The third clears the log file after an iteration is over
 **************************************************************************************/
 
 //this creates the logfile that is to be used for analysis
 //returns 0 if the file is not created
 //returns 1 if the file has been created
 int fncreatelogfile()
 {
 	FILE *fplogfile;
 
 	fplogfile = fopen(LOGFILE,"w");
 	if (fplogfile==NULL)
 	{
 		return (0);//the logfile could not be created error
 	}
 	fclose(fplogfile);
 	return(1);//success
 }
 
 //this function logs the function name in the logfile
 //if direction is 1 it means entry
 //if direction is 0 it means exit
 void fnlogfnname(char *fnname,int direction)
 {
 	#ifndef LBL_RUNNING
 	FILE *fplogfile;
 
 	fplogfile = fopen(LOGFILE,"a");//open in the mode for appending
 	if (direction == 1)
 	{
 		fprintf(fplogfile,"Entry :: %s\n",fnname);
 	}
 	else
 	{
 		fprintf(fplogfile,"Exit  :: %s\n",fnname);
     }
 	fclose(fplogfile);
 	#endif //compile the code only if it is for testing 
 }
 
 //this function clears the logfile 
 //this can be used once we know an iteration is over
 void fnclearlog()
 {
 	FILE *fplogfile;
 
 	fplogfile = fopen(LOGFILE,"w");
 	fclose(fplogfile);
 }

