#include <stdio.h>
 #include <stdlib.h>
 
 struct Trip{
 	int s,e;
 	int d;
 	struct Trip *next;
 };
 
 int tra(char *t){
 	return((t[0]-'0')*600+(t[1]-'0')*60+(t[3]-'0')*10+t[4]-'0');
 };
 
 int comp(const void *x,const void *y){
 	struct Trip *t1,*t2;
 	t1=(struct Trip *)x;
 	t2=(struct Trip *)y;
 	if(t1->s < t2->s) return -1;
 	if(t1->s == t2->s) return 0;
 	else return 1;
 };
 
 main(int argc, char **argv){
 	struct Trip trip[200];
 	int n,N,NA,NB,T,na,nb,e,d;
 	int remain,rtable[200];
 	int i,j,k;
 	char t1[8],t2[8];
 	FILE *in,*out;
 	in=fopen(argv[1],"r");
 	out=fopen(argv[2],"w");
 	fscanf(in,"%d",&N);
 	for(n=0;n<N;n++){
 		fscanf(in,"%d %d %d",&T,&NA,&NB);
 		for(i=0;i<NA+NB;i++){
 			fscanf(in,"%s %s",t1,t2);
 			trip[i].s=tra(t1);
 			trip[i].e=tra(t2)+T;
 			trip[i].d=(i<NA)?1:-1;
 		}
 		qsort(trip, NA+NB, sizeof(struct Trip), comp);
 		na=0;
 		nb=0;
 		remain=NA+NB;
 		for(i=0;i<NA+NB;i++) rtable[i]=0;
 		while(remain){
 			i=0;
 			while(rtable[i]) i++;
 			rtable[i]=1;
 			d=trip[i].d;
 			e=trip[i].e;
 			(d>0)?na++:nb++;
 			remain--;
 			i++;
 			d=-d;
 			while(remain && i<NA+NB){
 				if(!rtable[i] && trip[i].d==d && trip[i].s>=e){
 					rtable[i]=1;
 					e=trip[i].e;
 					remain--;
 					d=-d;
 				}
 				i++;
 			}
 		}
 		fprintf(out,"Case #%d: %d %d\n",n+1,na,nb);
 
 	}
 }
 
 			
 			
 			
 		
 	
 	
 	

