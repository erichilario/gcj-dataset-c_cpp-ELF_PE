#include <stdio.h>
 #include <stdlib.h>
 #include<ctype.h>
 
 
 #define MAXBUSCADORES 10
 #define MAXBUSQUEDAS  200
 #define MAXCASOS      20
 
 
 int main(int argc, char *argv[])
 {
   FILE *infile;
   FILE *outfile;
 
   int i,j,k,l;
   
   int cantidadCasos;
   int cantidadMotores;
   int cantidadBusquedas;
   
   int mapabusquedas[MAXBUSQUEDAS];
   int cantidadBuscadoresDescartados;
   int esPosibleBuscador[MAXBUSCADORES];
   
   char motores[MAXBUSCADORES][100];
   char busquedas[MAXBUSQUEDAS][100];
   char tmp_cadena[100];
   
   int buscadorActual;
   int buscadoresPosibles;
   int cantidadCambios[MAXCASOS];
 
   if((infile = fopen("c:\\A-small-attempt1.in", "r")) == NULL) {
     printf("Error Opening File.\n");
     exit(1);
   }
   
   fgets(tmp_cadena, 100, infile);
   cantidadCasos = atoi(tmp_cadena);
 
   for(i=0;i!=cantidadCasos;i++)
   {
 
      fgets(tmp_cadena, 100, infile);
      cantidadMotores = atoi(tmp_cadena);
 
      for(j=0;j!=cantidadMotores;j++)
     {
       fgets(motores[j],100,infile);
     }
     fgets(tmp_cadena, 100, infile);
     cantidadBusquedas = atoi(tmp_cadena);
 
    
     for(j=0;j!=cantidadBusquedas;j++) 
     {
       fgets(busquedas[j], 100, infile);
 
     }
     
     for(l=0;l!=cantidadMotores;l++)
     {
         esPosibleBuscador[l]=1;
     }
     buscadoresPosibles=cantidadMotores;
     cantidadCambios[i]=0;
     
     for(j=0;j!=cantidadBusquedas;j++)
     {
     
       for(k=0;k!=cantidadMotores;k++)
       {
           if(strcmp(motores[k],busquedas[j])==0 && esPosibleBuscador[k]==1)
           {
               esPosibleBuscador[k] = 0;
               buscadoresPosibles--;
           
               if(buscadoresPosibles==0)
               {
                   cantidadCambios[i]++;
                   for(l=0;l!=cantidadMotores;l++)
                   {
                       esPosibleBuscador[l]=1;
                   }
                   buscadoresPosibles=cantidadMotores-1;
               esPosibleBuscador[k] = 0;
               }
           }
       }
     }  
   }
 
 
   if((outfile = fopen("c:\\salida.in", "w")) == NULL) {
     printf("Error Creating File.\n");
     exit(1);
   }
   
   for(k=0;k!=cantidadCasos;k++)
   {
       fputs("Case #",outfile);
       fputs(itoa(k+1,tmp_cadena,10),outfile);
       fputs(": ",outfile);
       fputs(itoa(cantidadCambios[k],tmp_cadena,10),outfile);     
       fputs("\n",outfile);
 //      printf(itoa(cantidadCambios[k],tmp_cadena,10));
   }
 
   
      
   system("PAUSE");	
   fclose(infile);  /* Close the file */
   return 0;
 }

