#include <stdio.h>
 #include <string.h>
 #define MAX 101
 #define TAM 102
 
 char browser[MAX][TAM];
 
 int binsearch(char x[], int n)
 {
    int valor, low, high, mid;
    low = 0;
    high = n - 1;
    while (low <= high) 
    {
       mid = (low+high)/2;
       if ((valor = strcmp(x, browser[mid])) < 0)
          high = mid - 1;
       else if (valor > 0)
          low = mid + 1;
       else /* found match */
          return mid;
    }
    return -1; /* no match */
 }
 
 void shellsort(int n)
 {
    int gap, i, j;
    char temp[TAM];
    for (gap = n/2; gap > 0; gap /= 2)
       for (i = gap; i < n; i++)
          for (j=i-gap; j>=0 && strcmp(browser[j], browser[j+gap]) > 0; j-=gap) 
          {
             strcpy(temp, browser[j]);
             strcpy(browser[j], browser[j+gap]);
             strcpy(browser[j+gap], temp);
          }
    return;
 }
 
 int main()
 {
     int i, j, k, casos, s, q, cont, suma, indice, flags[MAX];
     char query[TAM];
     scanf("%d\n", &casos);
     for(k = 1; k <= casos; k++){
         scanf("%d\n", &s);/*numero de browsers*/
         for(i = 0; i < s; i++){
             for(j = 0; (browser[i][j] = getchar()) != '\n'; j++);
             browser[i][j] = '\0';
         }
         shellsort(s);
 /*        for(i = 0; i < s; i++)
             printf("%s'\n", browser[i]);*/
         suma = cont = 0;
         for(i = 0; i < s; i++)
             flags[i] = 0;
         scanf("%d\n", &q);/*numero de consultas*/
         for(i = 0; i < q; i++){
             for(j = 0; (query[j] = getchar()) != '\n' && query[j] != EOF; j++);
             query[j] = '\0';
             indice = binsearch(query, s);
             if(indice != -1){
                 if(flags[indice] == 0){
                     flags[indice] = 1;
                     suma++;
                 }
                 if(suma == s){
                     for(j = 0; j < s; j++)
                         flags[j] = 0;
                     flags[indice] = 1;
                     cont++;
                     suma = 1;
                 }
             }
 /*            for(j = 0; j < s; j++)
                 printf("%d ", flags[j]);
             printf("\n%3d suma = %3d indice = %3d %s'\n\n", i+1, suma, indice, query);*/
         }
         printf("Case #%d: %d\n", k, cont);
     }
     return 0;
 }

