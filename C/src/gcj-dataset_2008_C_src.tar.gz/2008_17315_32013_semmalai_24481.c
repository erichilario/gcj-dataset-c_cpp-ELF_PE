#include<stdio.h>
 struct temp
 {
 int t,v;
 }tmp,a[1000];
 int ata,atb,na,nb,turn,a1,a2,a3,a4,i,j,k,nc,inc,ta,tb;
 void main()
 {
 scanf("%d",&nc);
 for(i=0;i<nc;i++)
 {
 scanf("%d",&turn);
 scanf("%d%d",&na,&nb);
 inc=0;
 for(j=0;j<na;j++)
 {
 scanf("%d:%d%d:%d",&a1,&a2,&a3,&a4);
 a[inc].t=a1*60+a2;
 a[inc++].v=-1;
 a[inc].t=a3*60+a4+turn;
 a[inc++].v=2;
 }
 for(j=0;j<nb;j++)
 {
 scanf("%d:%d%d:%d",&a1,&a2,&a3,&a4);
 a[inc].t=a1*60+a2;
 a[inc++].v=-2;
 a[inc].t=a3*60+a4+turn;
 a[inc++].v=1;
 }
 for(k=0;k<inc-1;k++)
 for(j=k+1;j<inc;j++)
 
 if((a[k].t>a[j].t)||(a[k].t==a[j].t&&a[k].v<a[j].v))
 {
 tmp=a[k];
 a[k]=a[j];
 a[j]=tmp;
 }
 
 ata=0;atb=0;
 ta=0;tb=0;
 for(j=0;j<inc;j++)
 {
 //printf("\n%d:%d-- %d\n",a[j].t/60,a[j].t%60,a[j].v);
 if(a[j].v==-1)
 if(ta==0)
 ata++;
 else
 ta--;
 else if(a[j].v==-2)
 if(tb==0)
 atb++;
 else
 tb--;
 else if(a[j].v==2)
 tb++;
 else
 ta++;
 }
 printf("Case #%d: %d %d\n",i+1,ata,atb);
 }
 }
 

