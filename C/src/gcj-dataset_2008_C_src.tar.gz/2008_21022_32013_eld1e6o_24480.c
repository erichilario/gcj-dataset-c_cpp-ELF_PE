#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define Nmax 20
 #define Smax 100
 #define Qmax 1000
 #define Lmax 101
 
 int main()
 {
     int n,s,q,temp,cuenta,sact,qact,regr,cambio=0,memoria;
     char motores[Smax][Lmax];
     char cadtemp[Lmax];
     int flags[Smax];
     char nums[10];
     FILE *archivo,*salida;
 	char nombre[] = "A-large.in\0";
 	archivo=fopen(nombre,"r");
 	salida=fopen("salida2.txt","w");
 	if(!archivo){
 		printf("No se pudo abrir el archivo de entrada\n");
 		return 1;
 	}
 
 	if(!salida){
 		printf("No se pudo abrir el archivo de salida\n");
 		return 1;
 	}
     n=0;
 //	fscanf(archivo,"%d\t",&n);//maximo de casos
 	fgets(nums,5,archivo);
 	printf("gets ok");
 	puts(nums);
 	temp=0;
 	printf("antes %d %d\n",nums[temp],'0');
 	while(nums[temp]<'0' || nums[temp]>'9')temp++;
 	while((nums[temp]>='0') && (nums[temp]<='9')){
 	    n=n*10;n=n+nums[temp]-'0';temp++;//printf(" %d",temp);
 	    }
 
 	printf("N: %d",n);
 	for(cuenta=1;cuenta<=n;cuenta++){ //mete en la matriz los nombres de los buscadores
 	    cambio=0;
     	fgets(nums,7,archivo);
         temp=0;
         s=0;
         while(nums[temp]<'0' || nums[temp]>'9')temp++;
         while((nums[temp]>='0') && (nums[temp]<='9')){
             s=s*10;s=s+nums[temp]-'0';temp++;//printf(" %d",temp);
             }//obtiene s
 //	    fscanf(archivo,"%d\n",&s);
         printf("S: %d\n",s);
 	    for(sact=0;sact<s;sact++){
 	        fgets(motores[sact], Lmax, archivo);puts(motores[sact]);
         }
         fgets(nums,7,archivo);
         temp=0;
         q=0;
         while(nums[temp]<'0' || nums[temp]>'9')temp++;
         while((nums[temp]>='0') && (nums[temp]<='9')){
             q=q*10;q=q+nums[temp]-'0';temp++;//printf(" %d",temp);
             }//obtiene q
         printf("Q: %d\n",q);
 
         regr=s; //para saber cual es el último en buscar
 
         printf("Empieza la busqueda\n");
         for(temp=0;temp<Smax;temp++)flags[temp]=0;//borra flags
         for(qact=0;qact<q;qact++){ //por cada consulta verifica si se repite
             fgets(cadtemp,Lmax, archivo);//obtiene consulta
             for(temp=0;temp<s;temp++){
                 if(strcmp(cadtemp,motores[temp])==0 && flags[temp]==0){//si la consulta es igual a un buscador
                     flags[temp]=1;//marca el flag como inutilizable
                     memoria=temp;
                     temp=s+1;//para que deje de comparar esa cadena
                     regr--; //una posibilidad menos
 
                 }
             }
             if(regr==0){
                 cambio++;
                 printf("Encontrado: ");
                 puts(cadtemp);
                 for(temp=0;temp<Smax;temp++)flags[temp]=0;
                 regr=s-1;//porque hay un server anulado
                 flags[memoria]=1;//modificado para que no pueda usare mismo server 2 veces
             }
 //	}
     }
     printf("Para N= %d necesitamos %d cambios\n",cuenta,cambio);
     fprintf(salida,"Case #%d: %d\n",cuenta,cambio);
 
 }
 	/*debug
 
 	printf("N: %d, S: %d\n",n,s);
 	for(temp=0;temp<s;temp++)puts(motores[temp]);
 */
     return 0;
 }

