#include <stdio.h>
 #include <math.h>
 
 //#define DEBUG
 
 double f, R, t, r, g;
 double realr;
 
 inline double calsegment(double radius, double angle){
 	return radius*radius*( angle/2 - cos(angle/2)*sin(angle/2) );
 }
 
 double calculate(double left, double right, double top, double bottom){
 	int insidelt, insiderb;
 	double bigangle, smallangle; 
 
 #ifdef DEBUG
 	fprintf(stderr, "left:%lf right:%lf top:%lf bottom:%lf\n", left, right, top, bottom);
 #endif
 	if(sqrt(left*left+bottom*bottom) > realr)
 		return 0;
 
 	if(sqrt(right*right+top*top) <= realr){
 		return (right - left) * (top - bottom);
 	}
 	else{
 		insidelt = sqrt(left*left+top*top) <= realr;
 		insiderb = sqrt(right*right+bottom*bottom) <= realr;
 		if(insidelt && insiderb){
 			smallangle = acos(right/realr);
 			bigangle = asin(top/realr);
 			return calsegment(realr, bigangle - smallangle)
 			+ (top-bottom) *(right-left) - (top-realr*sin(smallangle))*(right-realr*cos(bigangle))/2;
 		}
 		if(insidelt && !insiderb){
 			smallangle = asin(bottom/realr);
 			bigangle = asin(top/realr);
 			return calsegment(realr, bigangle - smallangle)
 			+ (realr*cos(bigangle) - left + realr*cos(smallangle) - left)*(top-bottom)/2;
 		}
 		if(insiderb && ! insidelt){
 			smallangle = acos(right/realr);
 			bigangle = acos(left/realr);
 			return calsegment(realr, bigangle - smallangle)
 			+ (realr*sin(bigangle) - bottom + realr*sin(smallangle) - bottom) * (right - left)/2;
 		}
 		if(!insiderb && !insidelt){
 			smallangle = asin(bottom/realr);
 			bigangle = acos(left/realr);
 			return calsegment(realr, bigangle - smallangle)
 			+ (realr*cos(smallangle) - left) * (realr*sin(bigangle) - bottom) /2;
 		}
 	}
 	//fprintf(stderr, "how did you get here?\n");
 }
 
 int main()
 {
 	double x, y;
 	double bottom, top, left, right;
 	double ans;
 
 	int icase, ncase;
 	scanf("%d", &ncase);
 	for(icase=0; icase<ncase; ++icase){
 		scanf("%lf%lf%lf%lf%lf", &f, &R, &t, &r, &g);
 		realr = R - t - f;
 		ans = 0;
 		for(x=r; x<=realr; x += g+2*r){
 			for(y=r; y<=realr; y += g+2*r){
 				if(sqrt(x*x+y*y)>realr)
 					break;
 				bottom = y+f;
 				left = x+f;
 				right = (x+g <= R-t) ? x+g-f : x+g;
 				top = (y+g <= R-t) ? y+g-f : y+g;
 				ans += calculate(left, right, top, bottom);
 				//fprintf(stderr, "%lf\n", ans);
 			}
 		}
 
 		printf("Case #%d: %lf\n", icase+1, 1 - ans*4/(R*R*M_PI));
 	}
 	return 0;
 }
 

