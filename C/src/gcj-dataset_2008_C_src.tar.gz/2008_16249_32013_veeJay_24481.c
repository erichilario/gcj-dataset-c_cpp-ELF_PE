#include<stdio.h>
 #define convert(x,y) x*60+y
 void modified(int *);
 void checka(int);
 void checkb(int);
 void sort(int [],int);
 void swapa(int);
 void swapb(int);
 int t;
 int n,na,nb;
 int flaga[100],flagb[100];
 int sa[100],sb[100],db[100],da[100];
 main()
 {
 	int sah,sam,dbh,dbm;
 	int sbh,sbm,dah,dam;
 	int i,j,k=1;
 	int counta,countb;
     scanf("%d",&n);
     for(i=1;i<=n;i++)
     {
 		scanf("%d",&t);
 		scanf("%d %d",&na,&nb);
 		for(j=1;j<=na;j++)
 		{
 			scanf("%d:%d %d:%d",&sah,&sam,&dbh,&dbm);
 			flaga[j]=1;
 			sa[j]=convert(sah,sam);
 			db[j]=convert(dbh,dbm);
 			modified(&db[j]);
 //			printf("%d\n",db[j]);
 		}
 		for(j=1;j<=nb;j++)
 		{
 			scanf("%d:%d %d:%d",&sbh,&sbm,&dah,&dam);
 			flagb[j]=1;
 			sb[j]=convert(sbh,sbm);
 			da[j]=convert(dah,dam);			
 			modified(&da[j]);
 //			printf("%d\n",da[j]);
 		}
 		sort(sa,na);
 		sort(sb,nb);
 		sort(da,nb);
 		sort(db,na);
 		counta=0;
 		countb=0;
 		// flag =1 means new train requird
 		//flag =0 means no new train required
 		for(j=1;j<=na;j++)
 		{
 			//if(flagb[j]!=0)
 			checkb(j);
 		}
 		for(j=1;j<=nb;j++)
 		{
 
 			//if(flaga[j]!=0)
 			checka(j);
 		}		
 		for(j=1;j<=na;j++)
 		{
 			if(flaga[j]==1)
 				counta++;
 		}
 		for(j=1;j<=nb;j++)
 		{
 			if(flagb[j]==1)
 				countb++;
 		}
 		printf("Case #%d: %d %d \n",i,counta,countb);
 	}
     getch();
 }
 
 void modified(int *y)
 {
 	*y=*y+t;
 /*	if(*y>=1440)
 	{
 		*y=*y%1440;
 	}*/
 }
 
 void checkb(int x)
 {
 	int i;
 	for(i=1;i<=nb;i++)
 	{
 		if(flagb[i]!=0)
 		{
 			if(db[x] <= sb[i])
 			{
 				flagb[i]=0;
 			//	printf("hi\n");
 			//	checka(i);
 				break;
 			}
 			else
 			{//printf("hello\n");
             }
 		}
 	}
 }
 
 void checka(int x)
 {
 	int i;
 	for(i=1;i<=na;i++)
 	{
 		if(flaga[i]!=0)
 		{
 			if(da[x] <= sa[i])
 			{
 				flaga[i]=0;
 			//	checkb(i);
 				break;
 			}
 		}
 	}
 }	
 
 void sort(int sa[],int na)
 {
 	int i,j;
 	for(i=1;i<=na;i++)
 	{
 		for(j=1;j<=na-i;j++)
 		{
 			if(sa[j]>=sa[j+1])
 			{
 			sa[j]=sa[j]+sa[j+1];
 			sa[j+1]=sa[j]-sa[j+1];
 			sa[j]=sa[j]-sa[j+1];
 			}
 		}
 	}	/*	for(j=1;j<=na;j++)
 		{
 		  printf("%d \n",sa[j]);
 		  }
 		  printf("\n \n");*/
 
 }
 
 
 
 /* void swapa(int x)
 {
 	sa[x]=sa[x]+sa[x+1];
 	sa[x+1]=sa[x]-sa[x+1];
 	sa[x]=sa[x]-sa[x+1];
 	
 	db[x]=db[x]+db[x+1];
 	db[x+1]=db[x]-db[x+1];
 	db[x]=db[x]-db[x+1];
 }
 
 void swapb(int x)
 {
 	sb[x]=sb[x]+sb[x+1];
 	sb[x+1]=sb[x]-sb[x+1];
 	sb[x]=sb[x]-sb[x+1];
 	
 	da[x]=da[x]+da[x+1];
 	da[x+1]=da[x]-da[x+1];
 	da[x]=da[x]-da[x+1];
 	
 }
  */

