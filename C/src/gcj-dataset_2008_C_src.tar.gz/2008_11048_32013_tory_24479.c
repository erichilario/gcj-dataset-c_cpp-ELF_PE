#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 struct problem_input_record
 {
     double f;
     double R;
     double t;
     double r;
     double g;
 
     double prob;
 };
 
 double
 my_sqrt(double value)
 {
     if (value < 0) return value;
     return sqrt(value);
 }
 
 /* get space for arc */
 double 
 space_of_arc(double x, double y, double r)
 {
     double X, Y;
 
     Y = my_sqrt(r*r - x*x);
     X = my_sqrt(r*r - y*y);
 
     return r*r*(atan(Y/x) - atan(y/X))/2 - (x*Y + X*y)/2 + x*y;
 }
 
 /* get space */
 double
 space_of_square(double x, double y, double l, double r)
 {
     double cX, cY;
     double x1, y1;
     double space;
 
     x1 = x+l;
     y1 = y+l;
 
     cY = my_sqrt(r*r - x1*x1);
     cX = my_sqrt(r*r - y1*y1);
 
     /* we have 5 cases */
     if (x1 < cX && y1 < cY)
     {
 	// sqaure case
 	return l*l;
     }
     else if (cX > x && cY > y)
     {
 	// case 1
 	space = (cX-x)*(y1-y) + (cY-y)*(x1-x) - (cX-x)*(cY-y) + space_of_arc(cX, cY, r);
     }
     else if (cX > x && cY < y)
     {
 	// case 2
 	cY = y;
 	space = (cX-x)*(y1-y) + space_of_arc(cX, cY, r);
     }
     else if (cX < x && cY > y)
     {
 	// case 3
 	cX = x;
 	space = (cY-y)*(x1-x) + space_of_arc(cX, cY, r);
     }
     else if (cX < x && cY < y)
     {
 	// case 4 
 	cX = x;
 	cY = y;
 	space = space_of_arc(cX, cY, r); 
     }
 
     return space;
 }
 
 int
 get_an_answer(struct problem_input_record *record)
 {
     int i, j;
     double x, y, r, l, in_R, maxX, maxY;
     double space;
 
     i = j = 0;
 
     in_R = record->R - record->t - record->f;
     l    = record->g - 2*record->f;
     space = 0;
 
     while(1)
     {
 	x = (record->r+record->f) + i*(record->g+2*record->r);
 	y = (record->r+record->f) + j*(record->g+2*record->r);
 
 	maxY = my_sqrt(in_R * in_R - x * x);
 	maxX = my_sqrt(in_R * in_R - y * y);
 
 //	printf("(%d,%d) Pos(%.6f,%.6f) Max(%.6f,%.6f)\n",
 //		i, j, 
 //		x, y,
 //		maxX, maxY);
 	if (x> maxX && y > maxY)
 	{
 	    if (j == 0) 
 	    {
 		/* now, we can finish it */
 		break;
 	    }
 
 	    /* move to the next column */
 	    j = 0;
 	    i++;
 	    continue;
 	}
 
 	space += space_of_square(x, y, l, in_R);
 	j++;
 
 //	printf("(%d,%d) %.6f\n", i, j, space);
     }
 
     space = space * 4;
 
     record->prob = 1 - space / ((4*atan(1)) * record->R * record->R);
     return 0;
 }
 
 
 int
 read_a_record(FILE *fp, struct problem_input_record *record)
 {
     char buf[256];
     int nread;
     int i;
     char *p;
 
     /* read f, R, t, r and g */
     nread = fscanf(fp, "%lf %lf %lf %lf %lf",
 	    &record->f,
 	    &record->R,
 	    &record->t,
 	    &record->r,
 	    &record->g);
 
     if (nread != 5) return -1;
 
 
 //    printf("read(%.6f,%.6f,%.6f,%.6f,%.6f)\n",
 //	    record->f,
 //	    record->R,
 //	    record->t,
 //	    record->r,
 //	    record->g);
 
     return 0;
 }
 
 int
 solve_the_problem(char *filename)
 {
     FILE *fp;
     int i, n;
     struct problem_input_record *record;
 
     record = malloc(sizeof(struct problem_input_record));
 
     fp = fopen(filename, "r");
     if (fp == NULL) return -1;
 
     fscanf(fp, "%d\n", &n);
 
     for (i=0; i<n; i++)
     {
 	memset(record, 0, sizeof(struct problem_input_record));
 
 	if (read_a_record(fp, record) != 0)
 	{
 	    printf("failed to parse an input file\n");
 	    fclose(fp);
 	    return -2;
 	}
 
 	get_an_answer(record);
 
 	printf("Case #%d: %.6f\n", i+1, record->prob);
     }
 
     fclose(fp);
 
     return 0;
 }
 
 
 int
 main(int argc, char *argv[])
 {
     int ret;
 
     /* load an input file */
     ret = solve_the_problem(argv[1]);
     if (ret != 0)
     {
 	printf("somthing wrong [%s].\n", argv[1]);
 	return -1;
     }
 
     return 0;
 }

