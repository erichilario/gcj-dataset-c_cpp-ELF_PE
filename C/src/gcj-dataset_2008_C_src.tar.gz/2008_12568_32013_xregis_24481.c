/*
  * Macete:
  * comea com init_a e init_b iguais a 0
  * se available_x fica menor que zero
  * seta init_x pra init_x + 1
  * seta available_x pra 0
  */
 
 #include <stdio.h>
 #include <string.h>
 
 
 #define LEAVES_A 4
 #define ARRIVES_B 2
 #define LEAVES_B 3
 #define ARRIVES_A 1
 
 struct event 
 {
 	int time;
 	int ocurrence;
 };
 typedef struct event event_type;
 
 int hour_minute_to_int(int hour, int minute);
 void sortbytime(event_type event[], int size);
 void print_events(event_type event[], int size);
 
 int main(void)
 {
 	int caseCounter, naCounter, nbCounter, eventCounter, totalEvents;
 	int n; //test cases
 	int turn_around; //turn around time
 	int na; //number of departures from a
 	int nb; //number of departures from b
 	
 	int hour; //the hour of an event
 	int minute; //the minute of an event
 	
 	int available_a, available_b;
 	int init_a, init_b;
 	event_type event[500]; //to handle large_dataset...
 	
 	
 	//time to get started
 	scanf("%d", &n); //reads number of cases
 	for(caseCounter = 0; caseCounter < n; caseCounter++)
 	{
 		available_a = available_b = 0;
 		init_a = init_b = 0;
 		//get params for case
 		scanf("%d", &turn_around); //gets turn_around
 		scanf("%d %d", &na, &nb);
 		//printf("Turn Around: %d, NA: %d, NB: %d\n", turn_around, na, nb);
 		//fill events vector:
 		eventCounter = 0;
 		for(naCounter = 0; naCounter < na && !feof(stdin); naCounter++)
 		{
 			//two events for each line
 			scanf("%d:%d", &hour, &minute);
 			//printf("%d:%d -> %d\n", hour, minute, hour_minute_to_int(hour, minute));
 			event[eventCounter].time = hour_minute_to_int(hour, minute);
 			event[eventCounter].ocurrence = LEAVES_A;
 			eventCounter++;
 			scanf("%d:%d", &hour, &minute);
 			//printf("%d:%d -> %d\n", hour, minute, hour_minute_to_int(hour, minute));
 			event[eventCounter].time = hour_minute_to_int(hour, minute + turn_around);
 			event[eventCounter].ocurrence = ARRIVES_B;
 			eventCounter++;
 		}
 		//eventCounter--;
 		for(nbCounter = 0; nbCounter < nb && !feof(stdin); nbCounter++)
 		{
 			//two events for each line (again)
 			scanf("%d:%d", &hour, &minute);
 			//printf("%d:%d -> %d\n", hour, minute, hour_minute_to_int(hour, minute));
 			event[eventCounter].time = hour_minute_to_int(hour, minute);
 			event[eventCounter].ocurrence = LEAVES_B;
 			eventCounter++;
 			scanf("%d:%d", &hour, &minute);
 			//printf("%d:%d -> %d\n", hour, minute, hour_minute_to_int(hour, minute));
 			event[eventCounter].time = hour_minute_to_int(hour, minute + turn_around);
 			event[eventCounter].ocurrence = ARRIVES_A;
 			eventCounter++;
 		}
 		//eventCounter--;
 		
 		//sorts events vector based on field time:
 		//print_events(event,eventCounter);
 		sortbytime(event, eventCounter);
 		
 		
 			
 		//processes events:
 		totalEvents = eventCounter;
 		for(eventCounter = 0; eventCounter < totalEvents; eventCounter++) 
 		{
 			switch(event[eventCounter].ocurrence)
 			{
 			case LEAVES_A:
 				available_a -= 1;
 				if(available_a < 0)
 				{
 				//nao pode ser um sai e um chega... 
 				//os eventos "chega" devem ser processados antes...	
 					init_a += 1;
 					available_a = 0;
 				}
 				break;
 			case LEAVES_B:
 				available_b -= 1;
 				if(available_b < 0)
 				{
 					init_b += 1;
 					available_b = 0;
 				}
 				break;
 			case ARRIVES_A:
 				available_a += 1;
 				break;
 			case ARRIVES_B:
 				available_b += 1;
 				break;
 			}
 		}
 		// display output line:
 		printf("Case #%d: %d %d\n", caseCounter+1, init_a, init_b);
 	}
 	return 0;
 }
 
 int hour_minute_to_int(int hour, int minute)
 {
 	while(minute > 60)
 	{
 		minute -= 60;
 		hour += 1;
 	}
 	return 100*hour + minute;
 }
 
 void sortbytime(event_type event[], int size)
 {
 	//vetor pequeno: bubblesort
 	int i, j;
 	int auxtime, auxocur;
 	for(i = size - 1; i > 0 - 1; i--)
 	{
 		for(j = 0; j < i; j++)
 		{
 			if(event[j].time > event[j+1].time || (event[j].time == event[j+1].time && event[j].ocurrence > event[j+1].ocurrence))
 			{
 				auxtime = event[j].time;
 				auxocur = event[j].ocurrence;
 				event[j].time = event[j+1].time;
 				event[j].ocurrence = event[j+1].ocurrence;
 				event[j+1].time = auxtime;
 				event[j+1].ocurrence = auxocur;
 			}
 		}
 	} //fim do bubblesort
 	//agora ordenar pelo "chega"
 	for(i = 0; i < size; i++)
 	return;
 }
 void print_events(event_type event[], int size)
 {
 	int i;
 	for(i = 0; i < size; i++)
 	{
 		printf("Hora: %4d, Tipo: %d\n", event[i].time, event[i].ocurrence);
 	}
 }

