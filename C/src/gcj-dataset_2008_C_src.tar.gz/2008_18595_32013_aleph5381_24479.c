#include <stdio.h>
 #include <string.h>
 #include <math.h>
 #define PI 3.1415926535
 #define SQ(X) (X)*(X)
 
 int main(int argc, char* argv[])
 {
 	int n, n2=0;
 	if (argc < 2)
 		exit(0);
 	FILE *fp = fopen(argv[1],"r");
 	if (!fp)
 		exit(0);
 	fscanf(fp,"%d\n",&n);
 	while (n--) {
 		double f, R, t, r, g, P;
 		fscanf(fp,"%lf %lf %lf %lf %lf",&f,&R,&t,&r,&g);
 		if (g > 2*f) {
 			//P = 1 - (g-2*f)*(g-2*f)/((g+2*r)*(g+2*r));
 			double D = PI*R*R/4;
 			double N = 0;
 			double R2 = R - t - f;
 			double d = g/2 - f;
 			double x0, y0, x, y;
 			x0 = y0 = r + g/2;
 			for (x=x0; ; x+=(g+2*r)) {
 				if (x+d < R2) {
 					int n0 = sqrt(SQ(R) - SQ(x+d)) / (g+2*r);
 					N += n0*4*d*d;
 					y = y0 + (g+2*r)*n0;
 				} else {
 					y = y0;
 				}
 				for (; ; y+=(g+2*r)) {
 					double ub, rb, bb, lb;
 					ub = y + d;
 					rb = x + d;
 					bb = y - d;
 					lb = x - d;
 					if (SQ(rb)+SQ(ub) <= SQ(R2)) {
 						N += 4*d*d;
 					} else if (SQ(lb)+SQ(bb) >= SQ(R2)) {
 						break;
 					} else {
 						double x1,x2,y1,y2;
 						int type = 0;
 						if (SQ(R2) - SQ(ub) > SQ(lb)) {
 							x1 = sqrt(SQ(R2) - SQ(ub));
 							y1 = ub;
 						} else {
 							x1 = lb;
 							y1 = sqrt(SQ(R2) - SQ(lb));
 							type += 1;
 						}
 						if (SQ(R2) - SQ(rb) > SQ(bb)) {
 							x2 = rb;
 							y2 = sqrt(SQ(R2) - SQ(rb));
 						} else {
 							x2 = sqrt(SQ(R2) - SQ(bb));
 							y2 = bb;
 							type += 2;
 						}
 						double l = sqrt(SQ(x1-x2)+SQ(y1-y2));
 						double theta = acos((2*R2*R2-l*l)/(2*R2*R2));
 						N += R2*R2*(theta-sin(theta))/2;
 						switch (type) {
 							case 0:
 								N += 4*d*d - (rb-x1)*(ub-y2)/2;
 								break;
 							case 1:
 								N += ((y1-bb)+(y2-bb))*d;
 								break;
 							case 2:
 								N += ((x1-lb)+(x2-lb))*d;
 								break;
 							case 3:
 								N += (y1-bb)*(x2-lb)/2;
 								break;
 						}
 					}
 				}
 				if (x-g/2+f > R2) {
 					break;
 				}
 			}
 			P = 1 - N/D;
 		} else {
 			P = 1;
 		}
 		//
 		printf("Case #%d: %f\n",++n2,P);
 	}
 	fclose(fp);
 	return 0;
 }
 

