/*
  * Programmer : Kookiat Suetrong (kookiatsuetrong@gmail.com)
  * Compiler   : Visual C++ / ISO C++ / ANSI C
  * Date       : 2008/07/17
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 #include <ctype.h>
 
 
 #define MAX_MINUTE	(25*60)
 
 #define MAX_T		(61)
 #define MAX_NA		(101)
 #define MAX_NB		(101)
 
 
 void minute2clock(int minute, int * h, int * m)
 {
 	*h = minute / 60;
 	*m = minute % 60;
 }
 
 int clock2minute(int h, int m)
 {
 	return h * 60 + m;
 }
 
 typedef struct _sched {
 	int start, stop;
 } sched;
 
 int T;
 int NA;
 int NB;
 sched SA[MAX_NA];
 sched SB[MAX_NB];
 
 int sort_function(void *a, void *b)
 {
 	sched *x = (sched*)a;
 	sched *y = (sched*)b;
 	if (x->start < y->start) return -1;
 	if (x->start > y->start) return 1;
 
 	if (x->stop < y->stop) return -1;
 	if (x->stop > y->stop) return 1;
 
 	// equal
 	return 0;
 }
 
 typedef struct _TRAIN
 {
 	char startPlatform; // 'A' or 'B'
 	char currentPlatform; // 'A' or 'B' or
 	int status[MAX_MINUTE]; // 0 = available
 } TRAIN;
 
 int nTrain = 0;
 TRAIN aTrain[MAX_NA + MAX_NB];
 
 void startAtPlatformA(int a)
 {
 	int found = -1;
 	int i;
 
 	for (i = 0; i < nTrain; i++)
 	{
 		if (0 == aTrain[i].status[SA[a].start] &&
 			'A' == aTrain[i].currentPlatform)
 		{
 			found = i;
 			break;
 		}
 	}
 	
 	if (-1 == found)
 	{
 		// create a new train
 		found = nTrain;
 		aTrain[nTrain].startPlatform = 'A';
 		for (i = 0; i < MAX_MINUTE; i++)
 		{
 			aTrain[nTrain].status[i] = 0; // available
 		}
 		nTrain++;
 	}
 	
 	aTrain[found].currentPlatform = 'B';
 	for (i = SA[a].start; i < SA[a].stop; i++)
 	{
 		aTrain[found].status[i] = 1; // A->B
 	}
 }
 
 void startAtPlatformB(int b)
 {
 	int found = -1;
 	int i;
 
 	for (i = 0; i < nTrain; i++)
 	{
 		if (0 == aTrain[i].status[SB[b].start] &&
 			'B' == aTrain[i].currentPlatform)
 		{
 			found = i;
 			break;
 		}
 	}
 
 	if (-1 == found)
 	{
 		// create a new train
 		found = nTrain;
 		aTrain[nTrain].startPlatform = 'B';
 		for (i = 0; i < MAX_MINUTE; i++)
 		{
 			aTrain[nTrain].status[i] = 0; // available
 		}
 		nTrain++;
 	}
 
 	aTrain[found].currentPlatform = 'A';
 	for (i = SB[b].start; i < SB[b].stop; i++)
 	{
 		aTrain[found].status[i] = -1; // A<-B
 	}
 
 }
 
 void process()
 {
 	int a, b;
 	int nA, nB;
 	int i;
 	
 	// sort
 	qsort(SA, NA, sizeof(sched), sort_function);
 	qsort(SB, NB, sizeof(sched), sort_function);
 
 	// init
 	nTrain = 0;
 	a = 0;
 	b = 0;
 
 	while (a < NA || b < NB)
 	{
 		if (SA[a].start == SB[b].start)
 		{
 			// start both A,B
 			startAtPlatformA(a);
 			startAtPlatformB(b);
 			a++;
 			b++;
 		}
 		else if (SA[a].start < SB[b].start)
 		{
 			// start at A
 			startAtPlatformA(a);
 			a++;
 		}
 		else
 		{
 			// start at B
 			startAtPlatformB(b);
 			b++;
 		}
 	}
 
 	nA = nB = 0;
 	for (i = 0; i < nTrain; i++)
 	{
 		if ('A' == aTrain[i].startPlatform)
 			nA++;
 		if ('B' == aTrain[i].startPlatform)
 			nB++;
 	}
 
 	printf("%d %d\n", nA, nB);
 }
 
 int main(int argc, char ** argv)
 {
 	int n;
 	int i;
 	FILE * f = fopen(argv[1], "r");
 
 	if (!f) return -1;
 
 	fscanf(f, "%d\n", &n);
 	for (i = 0; i < n; i++)
 	{
 		int h0, h1, m0, m1;
 		int j;
 
 		// read data for this case
 		fscanf(f, "%d\n", &T);
 		fscanf(f, "%d %d\n", &NA, &NB);
 
 		for (j = 0; j < NA; j++)
 		{
 			fscanf(f, "%d:%d %d:%d\n", &h0, &m0, &h1, &m1);
 			SA[j].start = clock2minute(h0, m0);
 			SA[j].stop = clock2minute(h1, m1);
 			SA[j].stop += T;
 		}
 		SA[j].start = clock2minute(25, 0);
 
 		for (j = 0; j < NB; j++)
 		{
 			fscanf(f, "%d:%d %d:%d\n", &h0, &m0, &h1, &m1);
 			SB[j].start = clock2minute(h0, m0);
 			SB[j].stop = clock2minute(h1, m1);
 			SB[j].stop += T;
 		}
 		SB[j].start = clock2minute(25, 0);
 
 		// output the result of this case
 		printf("Case #%d: ", i + 1);
 
 		// solve the test case
 		process();
 
 	}
 
 	fclose(f);
 
 	return 0;
 }

