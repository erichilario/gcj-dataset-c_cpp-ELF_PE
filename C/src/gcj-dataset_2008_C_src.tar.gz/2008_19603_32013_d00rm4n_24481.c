#include <stdio.h>
 #include <math.h>
 #include <stdlib.h>
 #include <malloc.h>
 #include <string.h>
 #include <pthread.h>
 #include <ctype.h>
 #include "list.h"
 
 
 #define FOR( iter, end, statement )          for( iter = 0; iter < end; iter++ ) statement
 #define FOR_LIST( iter, lhead, statement )   for( iter = lhead; iter; iter = ( iter )->next ) statement
 #define MALLOC( type, count )                ( ( type * )malloc( sizeof( type ) * count ) )
 
 
 #define MAX_THREADS       10
 #define THREAD_FREE       0
 #define THREAD_BUSY       1
 #define THREAD_FINISHED   2
 
 #define ST_NOT_STARTED    0
 #define ST_STARTED        1
 #define ST_FINISHED       2
 #define ST_DONE           3
 
 #define MAX_PAUSE         5
 
 #define MINS_IN_DAY       1440
 #define MINS_IN_HOUR      60
 #define HOURS_IN_DAY      24
 
 #define TABLE_SIZE        ( MINS_IN_DAY + MAX_PAUSE )
 
 
 struct mthread {
 	pthread_t thr;
 	int current_block;
 	int status;
 };
 
 struct input {
 	struct list *a_to_b;
 	struct list *b_to_a;
 	unsigned short pause;
 	unsigned short na;
 	unsigned short nb;
 	int status;
 };
 
 struct minute {
 	unsigned int a_dep;
 	unsigned int a_arr;
 	unsigned int b_dep;
 	unsigned int b_arr;
 	unsigned int used;
 };
 
 typedef struct mthread thread_t;
 typedef struct input input_t;
 
 
 thread_t thread[MAX_THREADS];
 
 input_t *data;
 int data_count;
 
 
 void *thread_job( void *ptr );
 void thread_manager();
 void route( input_t *schedule );
 void read_input( FILE *fp );
 void write_output( FILE *fp );
 
 
 void *thread_job( void *ptr ) {
 	
 	int tid = *( ( int * )ptr );
 	
 	thread[tid].status = THREAD_BUSY;
 	
 	route( &data[thread[tid].current_block] );
 	
 	thread[tid].status = THREAD_FINISHED;
 	
 }
 
 
 void thread_manager() {
 	
 	int i, j, done;
 	int index[MAX_THREADS];
 	
 	memset( thread, 0, sizeof( thread_t ) * MAX_THREADS );
 	
 	for( i = 0; i < MAX_THREADS; i++ )
 		index[i] = i;
 	
 	while( 1 == 1 ) {
 		for( i = 0; i < MAX_THREADS; i++ ) {
 			if( thread[i].status == THREAD_FREE ) {
 				for( j = 0; j < data_count; j++ ) {
 					if( data[j].status == ST_NOT_STARTED ) {
 						data[j].status = ST_STARTED;
 						thread[i].current_block = j;
 						pthread_create( &thread[i].thr, NULL, thread_job, ( void *)&index[i] );
 						break;
 					}
 				}
 			}
 			if( thread[i].status == THREAD_FINISHED ) {
 				pthread_join( thread[i].thr, NULL );
 				thread[i].status = THREAD_FREE;
 				data[thread[i].current_block].status = ST_DONE;
 			}
 		}
 		done = 0;
 		for( i = 0; i < data_count; i++ )
 			if( data[i].status == ST_DONE )
 				done++;
 		if( done == data_count )
 			break;
 	}
 	
 }
 
 
 /********************************
  *                              *
  *    TRAIN ROUTE FUNCTIONS     *
  *                              *
  ********************************/
 
 
 void translate_table( input_t *sch, struct minute *tbl ) {
 	
 	struct lnode *node;
 	int hh, mm;
 	
 	FOR_LIST( node, sch->a_to_b->head, {
 		sscanf( node->start, "%02d%*c%02d", &hh, &mm );
 		tbl[hh * MINS_IN_HOUR + mm].a_dep++;
 		tbl[hh * MINS_IN_HOUR + mm].used = 1;
 		sscanf( node->end, "%02d%*c%02d", &hh, &mm );
 		tbl[hh * MINS_IN_HOUR + mm + sch->pause].a_arr++;
 		tbl[hh * MINS_IN_HOUR + mm + sch->pause].used = 1;
 	} )
 	
 	FOR_LIST( node, sch->b_to_a->head, {
 		sscanf( node->start, "%02d%*c%02d", &hh, &mm );
 		tbl[hh * MINS_IN_HOUR + mm].b_dep++;
 		tbl[hh * MINS_IN_HOUR + mm].used = 1;
 		sscanf( node->end, "%02d%*c%02d", &hh, &mm );
 		tbl[hh * MINS_IN_HOUR + mm + sch->pause].b_arr++;
 		tbl[hh * MINS_IN_HOUR + mm + sch->pause].used = 1;
 	} )
 	
 	destroy( sch->a_to_b->head );
 	destroy( sch->b_to_a->head );
 	
 }
 
 
 void route( input_t *schedule ) {
 	
 	int i, trains_in_a = 0, trains_in_b = 0;
 	struct minute table[TABLE_SIZE];
 	
 	memset( table, 0, sizeof( struct minute ) * TABLE_SIZE );
 	schedule->na = schedule->nb = 0;
 	
 	translate_table( schedule, table );
 	
 	FOR( i, TABLE_SIZE, {
 		if( table[i].used == 0 )
 			continue;
 		//printf( "## %02d:%02d ## # A # dep: %2d arr: %2d # B # dep: %2d arr: %2d\n", i / 60, i % 60, table[i].a_dep, table[i].a_arr, table[i].b_dep, table[i].b_arr );
 		/// trains leaving A
 		if( table[i].a_dep > 0 ) {
 			if( table[i].b_arr > 0 )
 				trains_in_a += table[i].b_arr;
 			if( table[i].a_dep > trains_in_a ) {
 				schedule->na += table[i].a_dep - trains_in_a;
 				trains_in_a = table[i].a_dep;
 			}
 			trains_in_a -= table[i].a_dep;
 		}
 		/// trains coming to B
 		if( table[i].a_arr > 0 ) {
 			trains_in_b += table[i].a_arr;
 		}
 		/// trains leaving B
 		if( table[i].b_dep > 0 ) {
 			if( table[i].b_dep > trains_in_b ) {
 				schedule->nb += table[i].b_dep - trains_in_b;
 				trains_in_b = table[i].b_dep;
 			}
 			trains_in_b -= table[i].b_dep;
 		}
 		/// trains coming to A
 		if( table[i].b_arr > 0 ) {
 			if( table[i].a_dep == 0 )
 				trains_in_a += table[i].b_arr;
 		}
 	} )
 	
 }
 
 
 /************************************
  *                                  *
  *     INPUT / OUTPUT FUNCTIONS     *
  *                                  *
  ************************************/
 
 
 void read_input( FILE *fp ) {
 	
 	int i, j, no_a, no_b;
 	char dep[MAX_DIST], arr[MAX_DIST];
 	
 	fscanf( fp, "%d%*c", &data_count );
 	
 	/// allocate the memory space
 	data = ( input_t * )malloc( data_count * sizeof( input_t ) );
 	memset( data, 0, data_count * sizeof( input_t ) );
 	
 	/// read the file
 	FOR( i, data_count, {
 		init_list( &data[i].a_to_b );
 		init_list( &data[i].b_to_a );
 		fscanf( fp, "%d%*c", &data[i].pause );
 		fscanf( fp, "%d%*c%d%*c", &no_a, &no_b );
 		FOR( j, no_a, {
 			fscanf( fp, "%s%*c%s%*c", dep, arr );
 			add_to_list( data[i].a_to_b, dep, arr, NULL );
 		} )
 		FOR( j, no_b, {
 			fscanf( fp, "%s%*c%s%*c", dep, arr );
 			add_to_list( data[i].b_to_a, dep, arr, NULL );
 		} )
 	} )
 	
 }
 
 
 void write_output( FILE *fp ) {
 	
 	int i;
 	
 	for( i = 0; i < data_count; i++ ) {
 		fprintf( fp, "Case #%d: %d %d\n", i + 1, data[i].na, data[i].nb );
 	}
 	
 }
 
 
 /*************************
  *                       *
  *     MAIN FUNCTION     *
  *                       *
  *************************/
 
 
 int main( int argc, char **argv ) {
 	
 	FILE *fin, *fout;
 	int i;
 	
 	/// check the command-line arguments
 	if( argc != 3 ) {
 		printf( "Usage: %s file_in file_out\n", argv[0] );
 		return EXIT_FAILURE;
 	}
 	
 	/// open the input and output files
 	fin = fopen( argv[1], "r" );
 	fout = fopen( argv[2], "w" );
 	if( ( fin == NULL ) || ( fout == NULL ) ) {
 		if( fin == NULL )
 			printf( "Cannot open input file...\n" );
 		else
 			printf( "Cannot open output file...\n" );
 		fcloseall();
 		return EXIT_FAILURE;
 	}
 	
 	/// read the input file
 	read_input( fin );
 	
 	/// start the jobs
 	thread_manager();
 	
 	/// write the output
 	write_output( fout );
 	
 	fcloseall();
 	
 	free( data );
 	
 	return EXIT_SUCCESS;
 	
 }

