#include <stdio.h>
 #include <stdlib.h>
 
 #define MAX_SEARCH_ENGINES 100
 #define MAX_QUERIES 1000
 #define MAX_NAME_LEN 100
 
 char SearchEngine[MAX_SEARCH_ENGINES][MAX_NAME_LEN + 1];
 int SearchEngineFlag[MAX_SEARCH_ENGINES] = {0};
 char Query[MAX_QUERIES][MAX_NAME_LEN + 1];
 
 int
 main()
 {
   FILE *fi;
   FILE *fo;
   int nTestcases;
   int nSearchEngines;
   int nQueries;
   int i, j, k, l;
   int nSwitches;
   int nSearchEnginesFlagged;
 
   fi = fopen("in1", "r");
   fo = fopen("out1", "w");
 
   fscanf(fi, "%d\n", &nTestcases);
   for (i = 1; i <= nTestcases; i++)
   {
     nSwitches = 0;
     nSearchEnginesFlagged = 0;
 
     fscanf(fi, "%d\n", &nSearchEngines);
     for (j = 0; j < nSearchEngines; j++)
     {
       fgets(SearchEngine[j], MAX_NAME_LEN, fi);
       SearchEngineFlag[j] = 0;
     }
 
     fscanf(fi, "%d\n", &nQueries);
     for (j = 0; j < nQueries; j++)
     {
       fgets(Query[j], MAX_NAME_LEN, fi);
       for (k = 0; k < nSearchEngines; k++)
       {
         if (strcmp(Query[j], SearchEngine[k]) == 0)
         {
           if (SearchEngineFlag[k] == 0)
           {
             if (++nSearchEnginesFlagged == nSearchEngines)
             {
               nSwitches++;
               for (l = 0; l < nSearchEngines; l++)
                 SearchEngineFlag[l] = 0;
               nSearchEnginesFlagged = 1;
             }            
             SearchEngineFlag[k] = 1;
           }    
           break;
         }
       }
     }
     fprintf(fo, "Case #%d: %d\n", i, nSwitches);
   }
   fclose(fi);
   fclose(fo); 
 }

