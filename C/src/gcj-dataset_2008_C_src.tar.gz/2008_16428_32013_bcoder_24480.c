#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int isallOne(int a[],int s);
 int runonce();
 //FILE *fp;
 
 int main()
 {
 	int n;
 	int i;
   /*	FILE *op;
 
 	fp = fopen("trial.in","r");
 	op = fopen("output.txt","w");
 	*/
 	/*if(!fp || !op)
 	{
 			  printf("unable to open or make gile ... ");
 			  return 0;
 	} */
 	fflush(stdin);
 	scanf("%d",&n);
 	fflush(stdin);
 
 	//printf("\n\nn = %d",n);
 	int x;
 
 	for(i=0;i<n;i++)
 	{
 		fflush(stdin);		
 		x = runonce();
 		printf("Case #%d: %d\n",i+1,x);
 	}
 	//getchar();
 	//fclose(fp);
 	//fclose(op);
 	return 0;
 }
 
 int isallOne(int a[],int s)
 {
 	int i=0;
 	for(i=0;i<s;i++)
 	{
 		if(a[i]==0)
 			return 0;
 	}
 	return 1;
 }
 
 int runonce()
 {
 	char **str,query[103];
 	int s,q;
 	int *arr_index;
 	int swtch=0,i;
 
 	fflush(stdin);
 	scanf("%d",&s);
 	getchar();	
 	//fflush(stdin);
 
 	//assert(s>0);
 	//printf("\ns = %d\n",s);
 	fflush(stdin);	
 	str = (char**)malloc(sizeof(char*)*s);
 	arr_index = (int*)malloc(sizeof(int)*s);
 	if(!arr_index)
 	{
 		printf("\nerror in 1...");
 	}
 	for(i=0;i<s;i++)
 		arr_index[i]=0;
 
 	if(!str)
 	{
 			printf("error in memory allocation");
 	}
 
 	for(i=0;i<s;i++)
 	{
 			str[i] = (char*)malloc(sizeof(char)*101);
 			if(!str[i])
 			{
 			  	printf("error ... ");
 			}
 	}
 	
 	fflush(stdin);
 	for(i=0;i<s;i++)
 	{
 					fflush(stdin);
 					fgets(str[i],100,stdin);
 					fflush(stdin);
 					
 					//printf("\ni = %d, s = %d str = %s\n",i,s,str[i]);
 	}
 
 	int j;
 
 	fflush(stdin);
 	scanf("%d",&q);
 	fflush(stdin);
 	getchar();
 	//printf("\nq = %d",q);
 	for(i=0;i<q;i++)
 	{
 
 				   fflush(stdin);
 					fgets(query,102,stdin);
 				   //printf("\nq = %d, i = %d query\n",q,i);
 				   fflush(stdin);
 				  //getchar();
 					for(j=0;j<s;j++)
 					{
 										   if(strcmp(query,str[j])==0)
 										   {
 											arr_index[j]=1;
 											break;
 											}
 					}
 				  //  fflush(stdin);
 					int temp=j;
 					if(isallOne(arr_index,s))
 					{
 											swtch++;
 											for(j=0;j<s;j++)
 													arr_index[j]=0;
 					}
 					if(temp<s)
 						   arr_index[temp]=1;
 	}
 	free(arr_index);
 	for(i=0;i<s;i++)
 		free(str[i]);
 	free(str);
 	return swtch;
 }

