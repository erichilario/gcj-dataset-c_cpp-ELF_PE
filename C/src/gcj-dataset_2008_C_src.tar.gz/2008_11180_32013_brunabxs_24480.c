#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <math.h>
 
 typedef struct _SEARCHENGINE
 {
 	int casos;
 	char nome[128];
 	int distancia, query;
 }SEARCHENGINE;
 
 SEARCHENGINE searchEngines[128];
 char queries[1024][128];
 
 int compara (const void * a, const void * b)
 {
 	SEARCHENGINE se1 = *(SEARCHENGINE*) a;
 	SEARCHENGINE se2 = *(SEARCHENGINE*) b;
 	
   return (se1.casos - se2.casos);
 }
 
 int main (void)
 {
 	int i, j, k, n, s, q, maiorDistancia, query, teste;
 	int numSwitches=0;
 
 	scanf("%d",&n);
 	for (teste=0; teste<n; teste++)
 	{
 		numSwitches=0;
 		scanf("%d",&s);
 		getchar();
 		// LEITURA DAS SEARCH ENGINES
 		for (j=0; j<s; j++)
 		{
 			gets(searchEngines[j].nome);
 			searchEngines[j].casos = 0;
 			searchEngines[j].distancia = 0;
 			searchEngines[j].query = 0;
 		}
 		scanf("%d",&q);
 		getchar();
 		// LEITURA DAS QUERIES
 		for (j=0; j<q; j++)
 		{
 			gets(queries[j]);
 			for (k=0; k<s; k++)
 			{
 				if (!strcmp(queries[j],searchEngines[k].nome))
 				{
 					searchEngines[k].casos++;
 					break;
 				}
 			}
 			
 		}
 		// ORDENANDO O VETOR DE SEARCH ENGINES
 		qsort(searchEngines,s,sizeof(SEARCHENGINE),compara);
 		j=0;
 		maiorDistancia=0;
 		query=0;
 		while(j<q)
 		{
 			for (i=0; i<s; i++)
 			{
 				j=query;	
 				while (strcmp(searchEngines[i].nome,queries[j]) && j<q)
 				{
 					j++;
 				}
 				searchEngines[i].query=j;
 				searchEngines[i].distancia = j;
 			}
 			maiorDistancia = searchEngines[0].distancia;
 			query = searchEngines[0].query;
 			for (i=0; i<s; i++)
 			{
 				if (maiorDistancia < searchEngines[i].distancia)
 				{
 					maiorDistancia = searchEngines[i].distancia;
 					query = searchEngines[i].query;			
 				}
 			}
 			numSwitches++;
 			j = query;
 		}	
 		numSwitches--;
 		
 		if (numSwitches<0)
 		{
 			numSwitches=0;
 		}
 		
 		
 		
 		
 		printf("Case #%d: %d\n",teste+1,numSwitches);
 		
 	}
 
 	return 0;
 }
 
 

