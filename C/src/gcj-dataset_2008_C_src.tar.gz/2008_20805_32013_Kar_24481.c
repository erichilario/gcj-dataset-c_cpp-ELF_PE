#include <stdio.h>
 #include <string.h>
 #include <time.h>
 //#define DISP 1
 
 void printtm(struct tm t) {
   printf("%02d:%02d", t.tm_hour, t.tm_min);
 }
 
 void clear_array(int *array, int num) {
   int i;
 
   for(i=0; i<num; i++) 
     array[i]=0;
 }
 
 int strsize(char *str) {
   int retval=0;
   
   while(str[retval++]!='\0');
   
   return (retval-1);
 }
 
 void freadline(char *s, FILE *f) {
   int i=0;
   while((s[i++] = fgetc(f)) != '\n');
   
   s[i-1]='\0';
   return;
 }
 
 int is_set(int *sa, int s) {
   int i, retval=1;
   
   for(i=0;i<s; i++) {
     if(sa[i] == 0) {
       retval=0;
       break;
     }
   }
   
   return retval;
 }
 
 // simple bubble sort on start times
 void sort_times(struct tm *t1, struct tm *t2, int n) {
   int tmp1, tmp2, i, j;
   for(i=0; i< n; i++) {
     for(j=i+1; j<n; j++) {
       if((t1[i].tm_hour > t1[j].tm_hour) || ((t1[i].tm_hour == t1[j].tm_hour) && (t1[i].tm_min > t1[j].tm_min))) {
 	tmp1 = t1[i].tm_hour;
 	tmp2 = t1[i].tm_min;
 	t1[i].tm_hour = t1[j].tm_hour; 
 	t1[i].tm_min = t1[j].tm_min; 
 	t1[j].tm_hour = tmp1; 
 	t1[j].tm_min = tmp2; 
 	
 	tmp1 = t2[i].tm_hour;
 	tmp2 = t2[i].tm_min;
 	t2[i].tm_hour = t2[j].tm_hour; 
 	t2[i].tm_min = t2[j].tm_min; 
 	t2[j].tm_hour = tmp1; 
 	t2[j].tm_min = tmp2; 
       }
     }
   }
 }
 
 int nexttrip(struct tm *t, struct tm st, int *sched, int tutime, int n) {
   int i=0;
 
   if(n==0)
     return -1;
   
   st.tm_min+=tutime;
   if(st.tm_min > 60) {
     st.tm_min%=60;
     st.tm_hour++;
   }
   
   while((i<n) && ((sched[i] != 0) || ((t[i].tm_hour < st.tm_hour) || ((t[i].tm_hour == st.tm_hour) && (t[i].tm_min < st.tm_min))))) 
     i++;
   
   if(i==n)
     i=-1;
   
   return i;
 }
 
 int num_trips(int who, struct tm *af, struct tm *at, struct tm *bf, struct tm *bt, int *as, int *bs, int na, int nb, int tutime, int real) {
   struct tm *firstf, *secondf, *firstt, *secondt; 
   int cnt=0, stime=0, *firsts, *seconds, i, j, k, fn, sn, fs[100], ss[100];
   char str;
 
   if(who==0) {
     firstf=af;
     firstt=at;
     secondf=bf;
     secondt=bt;
     firsts=as;
     seconds=bs;
     fn=na;
     sn=nb;
     str='A';
   }
   else {
     firstf=bf;
     firstt=bt;
     secondf=af;
     secondt=at;
     firsts=bs;
     seconds=as;
     fn=nb;
     sn=na;
     str='B';
   }
 
   i=-1;
   while(i<fn)
     fs[i]=firsts[i++];
 
   i=-1;
   while(i<sn)
     ss[i]=seconds[i++];
 
 
   i=-1;
   while((i<fn) && (firsts[++i]!=0));
   if(i==fn) return 0;
   cnt=1;
   fs[i]=1;
   stime=i;
   if(real) {
     firsts[i]=1;
 #ifdef DISP
     printf("  %c: start: ", str);
     printtm(firstf[stime]);
     printf("  end: ");
     printtm(firstt[stime]);
       if(str == 'A')
 	str='B';
       else
 	str='A';
 #endif
   }
   while(1) {
     stime=nexttrip(secondf, firstt[stime], ss, tutime, sn); 
     if(stime == -1) 
       break;
     ss[stime]=1;
     if(real) {
       seconds[stime]=1;
 #ifdef DISP
       printf("  %c: start: ", str);
       printtm(secondf[stime]);
       printf("  end: ");
       printtm(secondt[stime]);
       if(str == 'A')
 	str='B';
       else
 	str='A';
 #endif
     }
     cnt++;
     stime=nexttrip(firstf, secondt[stime], fs, tutime, fn); 
     if(stime == -1) 
       break;
     cnt++;
     fs[stime]=1;
     if(real) {
       firsts[stime]=1;
 #ifdef DISP
       printf("  %c: start: ", str);
       printtm(firstf[stime]);
       printf("  end: ");
       printtm(firstt[stime]);
       if(str == 'A')
 	str='B';
       else
 	str='A';
 #endif
     }
   }
 
   return cnt;
 }
 
 void main(int argc, char **argv) {
 
   FILE *f1;
   char tmp[80], *a;
   long n, na, nb, tutime;
   int i, j, ta=0, tb=0, asched[100], bsched[100], alegs, blegs;
   
   struct tm aftimes[100], bftimes[100], attimes[100], bttimes[100];
   
   f1=fopen(argv[1], "r");
   
   freadline(tmp, f1);
   n=strtol(tmp, &a, 10);
   
   for(i=0; i<n; i++) {
     ta=0;
     tb=0;
     freadline(tmp, f1);
     tutime=strtol(tmp, &a, 10);
 
     freadline(tmp, f1);
     na=strtol(tmp, &a, 10);
     nb=strtol(a, &a, 10);
     
     clear_array(asched, na);
     clear_array(bsched, nb);
     //read train A's schedule
     for(j=0; j<na; j++) {
       freadline(tmp, f1);
       aftimes[j].tm_hour=(int)strtol(tmp, &a, 10);
       a++;
       aftimes[j].tm_min=(int)strtol(a, &a, 10);
 
       attimes[j].tm_hour=(int)strtol(a, &a, 10);
       a++;
       attimes[j].tm_min=(int)strtol(a, &a, 10);
     }
 
     for(j=0; j<nb; j++) {
       freadline(tmp, f1);
       bftimes[j].tm_hour=(int)strtol(tmp, &a, 10);
       a++;
       bftimes[j].tm_min=(int)strtol(a, &a, 10);
 
       bttimes[j].tm_hour=(int)strtol(a, &a, 10);
       a++;
       bttimes[j].tm_min=(int)strtol(a, &a, 10);
     }
 
     //algo
     sort_times(aftimes, attimes, na);
     sort_times(bftimes, bttimes, nb);
 
     //int num_trips(int who, struct tm *af, struct tm *at, struct tm *bf, struct tm *bt, int *as, int *bs, int na, int nb, int tutime, int real) {
     while(!is_set(asched, na) || !is_set(bsched, nb)) {
       alegs=num_trips(0, aftimes, attimes, bftimes, bttimes, asched, bsched, na, nb, tutime, 0);
       blegs=num_trips(1, aftimes, attimes, bftimes, bttimes, asched, bsched, na, nb, tutime, 0);
       
       if(alegs > blegs) {
 	alegs=num_trips(0, aftimes, attimes, bftimes, bttimes, asched, bsched, na, nb, tutime, 1);
 	ta++;
       }
       else {
 	blegs=num_trips(1, aftimes, attimes, bftimes, bttimes, asched, bsched, na, nb, tutime, 1);
 	tb++;
       }
 #ifdef DISP
       printf("\n");
 #endif
     }
 
     printf("Case #%d: %d %d\n", (i+1), ta, tb);
   }
 }
 
 
 
 

