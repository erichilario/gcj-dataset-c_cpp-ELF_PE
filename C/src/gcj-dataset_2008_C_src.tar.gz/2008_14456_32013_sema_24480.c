#include <stdio.h>
 #include <string.h>
 
 
 void schit(FILE *f,char s[])
 {
  int j;    
  j=-1;
  do
  {
   j++;    
   fscanf(f,"%c",&s[j]);
  } 
  while (s[j]>16); 
  s[j]=0;  
 }
 
 int main()
 {
  FILE *f,*f1,*f2;
  int a[1002][101];
  char name[100][101],sn[101];
  int n,s,i,j,q,z,l,t;
  f=fopen("Universe.in","r");
  f1=fopen("Universe.out","w"); 
  f2=fopen("otl.out","w");
  fscanf(f,"%d",&n);
  for (t=1;t<=n;t++)
  {
   fscanf(f,"%d",&s);
   schit(f,name[0]);
   for (i=0;i<s;i++)
   {
    schit(f,name[i]);
  //  fprintf(f2,"%s\n",name[i]);
   } 
   fscanf(f,"%d",&q);
   z=q+1;
   for (j=0;j<s;j++)
    a[z][j]=0;
   schit(f,sn); 
   for (;q;q--)
   {
    schit(f,sn);
    for (i=0;strcmp(sn,name[i]);i++);
    z=q+1;
    for (j=0;j<s;j++)
     a[q][j]=5000;
    for (j=0;j<s;j++)
     for (l=0;l<s;l++)
      if (l!=j) 
      {
       if (a[z][j]+1<a[q][l])
        a[q][l]=a[z][j]+1;
      } 
           else if (a[q][l]>a[z][j]) a[q][l]=a[z][j];
    a[q][i]=5000;   
 //   for (j=0;j<s;j++)
 //    fprintf(f2,"%d ",a[q][j]);
 //   fprintf(f2,"%s %d %s\n",sn,q,name[i]); 
    z++;    
   }
   q=a[1][0];
   for (j=1;j<s;j++)
    if (q>a[1][j]) q=a[1][j];
   fprintf(f2,"\n");  
   fprintf(f1,"Case #%d: %d\n",t,q); 
  }
  fclose(f1);
  fclose(f2);
  fclose(f);
 }

