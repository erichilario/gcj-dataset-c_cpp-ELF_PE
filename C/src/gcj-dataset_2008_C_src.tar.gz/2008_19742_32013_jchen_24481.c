#include <stdio.h>
 
 typedef struct
 {
 	int hour;
 	int min;
 }CT;
 
 CT aout[100], bout[100], aready[100], bready[100];
 char ar[100], br[100];
 
 int N,NA,NB,T;
 
 char before(CT c1, CT c2)
 {
 	return (c1.hour<c2.hour)||((c1.hour==c2.hour)&&(c1.min<=c2.min));
 }
 
 void sort(CT c[], int n)
 {
 	int i,j;
 	int buf;
 	for(i=0;i<n-1;i++)
 		for(j=i+1;j<n;j++)
 		{
 			if(before(c[j],c[i]))
 			{
 				buf= c[j].hour;
 				c[j].hour= c[i].hour;
 				c[i].hour= buf;
 				buf= c[j].min;
 				c[j].min= c[i].min;
 				c[i].min= buf;
 			}
 		}
 }
 
 int main(void)
 {
 	int index;
 	int i,j,ca, cb;
 	scanf("%d\n", &N);
 	for(index=1;index<=N;index++)
 	{
 		scanf("%d\n", &T);
 		scanf("%d %d\n", &NA, &NB);
 		for(i=0;i<NA;i++)
 		{
 			scanf("%d:%d %d:%d\n", &aout[i].hour, &aout[i].min, &aready[i].hour, &aready[i].min);
 			aready[i].min+=T;
 			if(aready[i].min>59)
 			{
 				aready[i].hour++;
 				aready[i].min-=60;
 			}
 		}
 		sort(aout, NA);
 		sort(aready, NA);
 		for(i=0;i<NB;i++)
 		{
 			scanf("%d:%d %d:%d\n", &bout[i].hour, &bout[i].min, &bready[i].hour, &bready[i].min);
 			bready[i].min+=T;
 			if(bready[i].min>59)
 			{
 				bready[i].hour++;
 				bready[i].min-=60;
 			}
 		}
 		sort(bout, NB);
 		sort(bready, NB);
 		ca= cb= 0;
 		for(i=0;i<NA;i++)
 			ar[i]= 1;
 		for(i=0;i<NB;i++)
 			br[i]= 1;
 		
 		for(i=0;i<NA;i++)
 		{
 			for(j=0;j<NB;j++)
 				if(br[j] && before(bready[j], aout[i]))
 				{
 					br[j]= 0;
 					break;
 				}
 			if(j==NB)ca++;
 		}
 		
 		for(i=0;i<NB;i++)
 		{
 			for(j=0;j<NA;j++)
 				if(ar[j] && before(aready[j], bout[i]))
 				{
 					ar[j]= 0;
 					break;
 				}
 			if(j==NA)cb++;
 		}
 		
 			
 		printf("Case #%d: %d %d\n",index, ca, cb);
 	}
 	
 	return 0;
 }

