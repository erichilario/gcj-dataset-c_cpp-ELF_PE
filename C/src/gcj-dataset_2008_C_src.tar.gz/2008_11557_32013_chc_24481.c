#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <time.h>
 
 #define STATION_A 1
 #define STATION_B 2
 #define USED 9999999
 
 struct {
 //  int start;
   int pos;
   int arr_t;
 } train[1000];
 
 
 typedef struct {
   int station; 
   int dep_t; 
   int arr_t; 
   int id; 
   int train_id; 
 } M;
 
 M line[200];
 
 int my_cmp(const void *c, const void *d) {
   M *a=c, *b=d;
 
   return(a->dep_t - b->dep_t);
 }
 
 int solve(int a, int b)
 {
   int i,j ;
   int n=0, f=0;
   int train_a=0;
   int train_b=0;
 
   qsort(line, a+b, sizeof(M), my_cmp);
 
   for (i=0; i<a+b; i++) {
     int station = line[i].station;
     // printf("%d %d %d %d\n", line[i].dep_t, line[i].station, line[i].id, line[i].train_id);
 
     f=0;
     for (j=0; j<n; j++) {
       if (train[j].pos == station && train[j].arr_t <= line[i].dep_t) {
 // printf("old train %d station=%d time=%d\n", j, train[j].pos, train[j].arr_t);
         train[j].pos = (station==STATION_A)?STATION_B:STATION_A;
         train[j].arr_t = line[i].arr_t;
 // printf("new train %d station=%d time=%d\n", j, train[j].pos, train[j].arr_t);
         f=1;
         break;
       }
     }
     if (f==0) {
       train[n].pos = (station==STATION_A)?STATION_B:STATION_A;
       train[n].arr_t = line[i].arr_t;
       n++;
       if (station == STATION_A)
         train_a++;
       else
         train_b++;
     }
   }
   printf("%d %d", train_a, train_b);
 }
 
 main(int argc, char *argv[])
 {
   char *fname;
   char buf[1024], data[80];
   FILE *fp;
   int i, num, j, t, a, b;
   int h,m,h2,m2;
 
   if (argc<2)
     fname = "A-small.in";
   else
     fname = argv[1];
 
   fp = fopen(fname, "r");
   if (!fp) {
     fprintf(stderr, "unable to open %s\n", fname);
     exit(-1);
   }
 
   fgets(buf, sizeof(buf), fp);
   num = atoi(buf);
 
   for (i=0; i<num; i++) {
     printf("Case #%d: ",i+1);
 
     fgets(buf, sizeof(buf), fp);
     t= atoi(buf);
     fscanf(fp,"%d %d\n", &a, &b);
 
     for (j=0; j<a; j++) {
       fscanf(fp,"%d:%d %d:%d\n", &h, &m, &h2, &m2);
       line[j].station = STATION_A;
       line[j].id = j;
       line[j].dep_t = h*60+m;
       line[j].arr_t = h2*60+m2 + t;
     }
     for (j=0; j<b; j++) {
       fscanf(fp,"%d:%d %d:%d\n", &h, &m, &h2, &m2);
 
       line[a+j].station = STATION_B;
       line[a+j].id = a+j;
       line[a+j].dep_t = h*60+m;
       line[a+j].arr_t = h2*60+m2 + t;
     }
     solve(a, b);
     printf("\n",i+1);
   }
 
   fclose(fp);
 }

