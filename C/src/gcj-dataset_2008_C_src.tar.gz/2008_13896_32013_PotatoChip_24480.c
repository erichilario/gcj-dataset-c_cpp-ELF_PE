/*****************************************************/
 /* Date : 2008.07.17                                 */
 /* Author : HHJeon                                   */
 /* Description : Google Code Jam, Qualification Round, */
 /*               Saving the Universe                 */
 /*****************************************************/
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define RET_OK 1
 #define RET_ERROR -1
 
 /*###################################################*/
 #define MAX_SEARCH_NAME_LEN 100
 
 int ProcStU(FILE *fpInFile, FILE *fpOutFile);
 int ComputeSwitchCount(char **pSEName, int nSECount, char **pQSeries, int nQSCount, int *pMinSwitch);
 int FreeMemory(char **pSEName, int nSECount, char **pQSeries, int nQSCount);
 /*###################################################*/
 
 int main(int argc, char* argv[])
 {
 	FILE *fpInFile, *fpOutFile;
 	char *sOutFileName = NULL;
 	int nOutFileNameSize = 0;
 	
 	/*+--------------------------------------------------*/
 	if(argc != 2)
 	{
 		if(NULL != strrchr(argv[0], '\\'))
 		{
 			printf("Usage %s input_file\n", strrchr(argv[0], '\\') + 1);
 		}
 		else
 		{
 			printf("Usage %s input_file\n", argv[0]);
 		}
 		return RET_ERROR;
 	}
 	/*---------------------------------------------------*/
 
 	/*+--------------------------------------------------*/
 	nOutFileNameSize = strlen(argv[1]) + 5;
 	sOutFileName = (char *)malloc(sizeof(char) * nOutFileNameSize);
 	if(sOutFileName == NULL)
 	{
 		printf("Insufficient memory available\n");
 		return RET_ERROR;
 	}
 	memset(sOutFileName, 0, nOutFileNameSize);
 	sprintf(sOutFileName, "%s.out", argv[1]);
 	/*---------------------------------------------------*/	
 
 	/*+--------------------------------------------------*/
 	fpInFile = (FILE *)fopen(argv[1], "r");
 	if(fpInFile == NULL)
 	{
 		printf("The file '%s' was not opened\n", argv[1]);
 		return RET_ERROR;
 	}
 	/*---------------------------------------------------*/
 
 	/*+--------------------------------------------------*/
 	fpOutFile = (FILE *)fopen(sOutFileName, "w");
 	if(fpOutFile == NULL)
 	{
 		printf("The file '%s' was not opened\n", sOutFileName);
 		return RET_ERROR;
 	}
 	/*---------------------------------------------------*/
 
 	/*###################################################*/
 	if(RET_ERROR == ProcStU(fpInFile, fpOutFile))
 	{
 		printf("Error.\n");
 	}
 	/*###################################################*/
 
 	/*+--------------------------------------------------*/
 	fclose(fpOutFile);
 
 	fclose(fpInFile);
 
 	free(sOutFileName);
 	/*---------------------------------------------------*/
 
 	return RET_OK;
 }
 
 int ProcStU(FILE *fpInFile, FILE *fpOutFile)
 {
 	int n = 0;
 	int i = 0, j = 0;
 	long nCount = 0;
 	int nSECount = 0;
 	int nQSCount = 0;
 	int nMinSwitch = 0;
 	char **pSEName = NULL;
 	char **pQSeries = NULL;
 	char ch;
 	
 	/*+--------------------------------------------------*/
 	if(EOF == fscanf(fpInFile, "%ld\n", &nCount))
 	{
 		return RET_ERROR;
 	}
 	/*---------------------------------------------------*/
 	
 	/*+--------------------------------------------------*/
 	for(n = 0; n < nCount; n++)
 	{
 		nMinSwitch = 0;
 
 		fscanf(fpInFile, "%ld\n", &nSECount);
 		pSEName = (char**)malloc(sizeof(char*) * nSECount);
 		if(pSEName == NULL)
 		{
 			printf("Insufficient memory available\n");
 			FreeMemory(pSEName, nSECount, pQSeries, nQSCount);
 			return RET_ERROR;
 		}
 		for(i = 0; i < nSECount; i++)
 		{
 			pSEName[i] = (char*)malloc(sizeof(char) * (MAX_SEARCH_NAME_LEN + 1));
 			if(pSEName[i] == NULL)
 			{
 				printf("Insufficient memory available\n");
 				FreeMemory(pSEName, nSECount, pQSeries, nQSCount);
 				return RET_ERROR;
 			}
 			memset(pSEName[i], 0x00, sizeof(char) * (MAX_SEARCH_NAME_LEN + 1));
 			for(j = 0; j < MAX_SEARCH_NAME_LEN; j++)
 			{
 				ch = fgetc(fpInFile);
 				if((ch == '\n') || (ch == EOF))
 				{
 					break;
 				}
 				pSEName[i][j] = ch;
 			}
 		}
 
 		fscanf(fpInFile, "%ld\n", &nQSCount);
 		pQSeries = (char**)malloc(sizeof(char*) * nQSCount);
 		if(pQSeries == NULL)
 		{
 			printf("Insufficient memory available\n");
 			FreeMemory(pSEName, nSECount, pQSeries, nQSCount);
 			return RET_ERROR;
 		}
 		for(i = 0; i < nQSCount; i++)
 		{
 			pQSeries[i] = (char*)malloc(sizeof(char) * (MAX_SEARCH_NAME_LEN + 1));
 			if(pQSeries[i] == NULL)
 			{
 				printf("Insufficient memory available\n");
 				FreeMemory(pSEName, nSECount, pQSeries, nQSCount);
 				return RET_ERROR;
 			}
 			memset(pQSeries[i], 0x00, sizeof(char) * (MAX_SEARCH_NAME_LEN + 1));
 			for(j = 0; j < MAX_SEARCH_NAME_LEN; j++)
 			{
 				ch = fgetc(fpInFile);
 				if((ch == '\n') || (ch == EOF))
 				{
 					break;
 				}
 				pQSeries[i][j] = ch;
 			}
 		}
 
 		ComputeSwitchCount(pSEName, nSECount, pQSeries, nQSCount, &nMinSwitch);
 
 		fprintf(fpOutFile, "Case #%d: %d\n", n+1, nMinSwitch);
 
 		/*+--------------------------------------------------*/
 		FreeMemory(pSEName, nSECount, pQSeries, nQSCount);
 		/*---------------------------------------------------*/
 	}
 	/*---------------------------------------------------*/
 
 	return RET_OK;
 }
 
 int ComputeSwitchCount(char **pSEName, int nSECount, char **pQSeries, int nQSCount, int *pMinSwitch)
 {
 	int i = 0, j = 0, k = 0;
 	int *pSENameCount = NULL;
 	int nSum = 0;
 
 	*pMinSwitch = 0;
 	pSENameCount = (int*)malloc(sizeof(int) * nSECount);
 	memset(pSENameCount, 0, sizeof(int) * nSECount);
 
 	for(i = 0; i < nQSCount; i++)
 	{
 		for(j = 0; j < nSECount; j++)
 		{
 			if((0 == strcmp(pQSeries[i], pSEName[j])) &&
 				(strlen(pQSeries[i]) == strlen(pSEName[j])))
 			{
 				pSENameCount[j] = 1;
 				nSum = 0;
 				for(k = 0; k < nSECount; k++)
 				{
 					nSum += pSENameCount[k];
 				}
 				if(nSum == nSECount)
 				{
 					memset(pSENameCount, 0, sizeof(int) * nSECount);
 					pSENameCount[j] = 1;
 					*pMinSwitch += 1;
 				}
 			}
 		}
 	}
 
 	return RET_OK;
 }
 
 int FreeMemory(char **pSEName, int nSECount, char **pQSeries, int nQSCount)
 {
 	int i = 0;
 
 	if(pSEName != NULL)
 	{
 		for(i = 0; i < nSECount; i++)
 		{
 			if(pSEName[i] != NULL)
 			{
 				free(pSEName[i]);
 				pSEName[i] = NULL;
 			}
 		}
 		free(pSEName);
 		pSEName = NULL;
 	}
 	
 	if(pQSeries != NULL)
 	{
 		for(i = 0; i < nQSCount; i++)
 		{
 			if(pQSeries[i] != NULL)
 			{
 				free(pQSeries[i]);
 				pQSeries[i] = NULL;
 			}
 		}
 		free(pQSeries);
 		pQSeries = NULL;
 	}
 
 	return RET_OK;
 }
