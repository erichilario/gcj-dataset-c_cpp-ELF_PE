#include <stdio.h>
 #include <string.h>
 
 #define fori(a,b) for(a=0; a<b; a++ )
 
 int getVal( char *ptr ) {
 	int h = (*ptr - '0')*10 + (*(ptr+1)-'0');
 	return h*60 + ((*(ptr+3)-'0')*10 + (*(ptr+4)-'0'));
 }
 int main() {
 	int i,T,N,inst,NA,NB,valA,valB;
 	int linA[1560];
 	int linB[1560];
 	char h1[8], h2[8];
 
 	scanf("%d",&N);
 	for( inst=1; inst<=N; inst++ ) {
 		scanf("%d %d %d",&T, &NA, &NB);
 		fori( i, 1560 ) linA[i]=linB[i]=0;
 		while( NA-- ) {
 			scanf("%s %s",h1,h2);
 			linA[ getVal(h1) ]++;
 			linB[ getVal(h2) + T ]--;
 		}
 		while( NB-- ) {
 			scanf("%s %s",h1,h2);
 			linB[ getVal(h1) ]++;
 			linA[ getVal(h2) + T]--;
 		}
 		valA = valB = 0;
 		for( i=1559; i>-1; i-- ) {
 			if( linA[i] > 0 ) break;
 		}
 		while( i>-1 ) {
 			if( linA[i]>0 ) valA+=linA[i];
 			else if( linA[i]<0 ) valA+=linA[i];
 			if( valA<0 ) valA=0;
 			i--;
 		}
 		for( i=1559; i>-1; i-- ) {
 			if( linB[i] > 0 ) break;
 		}
 		while( i>-1 ) {
 			if( linB[i]>0 ) valB+=linB[i];
 			else if( linB[i]<0 ) valB+=linB[i];
 			if( valB<0 ) valB=0;
 			i--;
 		}
 		printf("Case #%d: %d %d\n",inst,valA,valB);
 	}
 	return 0;
 }

