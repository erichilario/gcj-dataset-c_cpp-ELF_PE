#include "mainfile.h"
 #define MAXINPLEN 100
 
 void fnReadsearchenginenames(char *Datafname,char **sSearchenginename,int *iHashsearchengine,int iNumsearchengines,int iNumskip);
 void fnSkipelements(FILE *fp,int iNumskip);
 void fnCleararr(int *iProcessarr, int iNumsearchengines);
 
 int main(int argc, char **argv)
 {
 	FILE *fpDatafile;
 	int iNumcases,iNumsearchengines;int index;
 	char **sSearchengine;int *iHashsearchengine;
 	int *iProcessarr; //tells whether the array element has been processed
 
 	//test cases
 	int iNumtestcase;int iNumskip;int iLen;int freeindex;
 	int iNumleft;
 	char sStr[MAXINPLEN];
 	int testcaseno,srchengno;
 	int *iSwitchno;
 	FILE *fpOpt;
 	int caseno;
 
 
 	fncreatelogfile(); //create the log file
 	fnlogfnname( __FUNCTION__ ,1);//entry and exit information for the log file in main
 
 
 	if (argc!= 2)
 	{
 			printf ("\nUsage:: savingtheuniverse.exe <filename>");
 			exit(1);
 	 }
 
 	fpDatafile = fopen(argv[1],"r");
 	fscanf(fpDatafile,"%d",&iNumcases);
 	iNumskip = 1;
 	iSwitchno = (int*)calloc(iNumcases,sizeof(int));
 	fclose(fpDatafile);
 
 	iNumskip = 1;
 
 	for (caseno=0;caseno<iNumcases;caseno++)
 	{
 		fpDatafile = fopen(argv[1],"r");
 		fnSkipelements(fpDatafile,iNumskip);
 		fscanf(fpDatafile,"%d",&iNumsearchengines);
 		//printf("%d\n",iNumsearchengines);
 		iNumskip = iNumskip + 1;
 		//printf("%d\n",iNumskip);
 		fclose(fpDatafile);
 
 		//allocate the memory for reading the searchengine names
 		sSearchengine = (char**)calloc(iNumsearchengines,sizeof(char**));
 		for (index=0;index<iNumsearchengines;index++)
 			*(sSearchengine+index) = (char*)calloc(MAXINPLEN,sizeof(char*));
 
 		iHashsearchengine = (int*)calloc(iNumsearchengines,sizeof(int));
 		iProcessarr = (int*)calloc(iNumsearchengines,sizeof(int));
 		fnCleararr(iProcessarr,iNumsearchengines);
 		fnReadsearchenginenames(argv[1],sSearchengine,iHashsearchengine,iNumsearchengines,iNumskip);
 		iNumskip = iNumskip + iNumsearchengines;
 
 		iNumleft = iNumsearchengines;
 
 		fpDatafile = fopen(argv[1],"r");
 		fnSkipelements(fpDatafile,iNumskip);
 		fscanf(fpDatafile,"%d",&iNumtestcase);
 		//printf("\n%d\n",iNumtestcase);
 		iNumskip = iNumskip + 1;
 		//printf("\n\n\n%d",iNumtestcase);
 		fgets(sStr,MAXINPLEN,fpDatafile);//one to read the enter after reading the number
 		for (testcaseno = 0;testcaseno < iNumtestcase;testcaseno++)
 		{
 		fgets(sStr,MAXINPLEN,fpDatafile);
 		//puts(sStr);
 		iLen = strlen(sStr) - 1;
 		for (srchengno = 0;srchengno<iNumsearchengines;srchengno++)
 		{
 			if (*(iHashsearchengine+srchengno) == iLen)
 			{
 				if (stricmp(*(sSearchengine+srchengno),sStr) == 0)
 				{
 					if 	(*(iProcessarr+srchengno) == 0)
 					{
 						*(iProcessarr + srchengno) = 1;
 						iNumleft = iNumleft - 1;
 						if (iNumleft == 0)
 						{
 							*(iSwitchno+caseno) = *(iSwitchno + caseno) + 1;
 							fnCleararr(iProcessarr,iNumsearchengines);
 							*(iProcessarr + srchengno) = 1;
 							iNumleft = iNumsearchengines - 1;
 						  }
 					  }
 				  }
 
 			  }
 		  }
 	      }
 		  iNumskip = iNumskip + iNumtestcase;
 		  fclose(fpDatafile);
 
 		  printf("%d\n",*(iSwitchno+caseno));
 
 		//deallocate the memory
  		for (freeindex=0;freeindex<iNumsearchengines;freeindex++)
 				  		free(*(sSearchengine+freeindex)) ;
 	    free(sSearchengine);
 		free(iProcessarr);
 		free(iHashsearchengine);
 
  	   }
 
 	fpOpt = fopen("Output.vec","w");
 	for (index = 0;index<iNumcases;index++)
 	{
 		fprintf(fpOpt,"Case #%d: %d\n",index+1,*(iSwitchno+index));
 	}
 	fclose(fpOpt);
 
 	free(iSwitchno);
 
 	fnlogfnname(__FUNCTION__,0);//exit
 
 	return(0);
 }
 
 
 void fnReadsearchenginenames(char *Datafname,char **sSearchenginename,int *iHashsearchengine,int iNumsearchengines,int iNumskip)
 {	//this function reads the search engine names hashes it and sends it back
 	int index;
 	int itemp;
 	char sStr[MAXINPLEN];
 	FILE *fpDatafile;
 
 	fnlogfnname( __FUNCTION__ ,1);
 	fpDatafile = fopen(Datafname,"r");
 	//read the first element
 	//iNumskip = 2; //for the number of elements
 	//printf("%d\n",iNumskip);
 	fnSkipelements(fpDatafile,iNumskip);
 
 	//fscanf(fpDatafile,"%s",*sSearchenginename);
 	//puts(*sSearchenginename);
 
 	for (index=0;index<iNumsearchengines;index++)
 	{
 		fgets(*(sSearchenginename+index),MAXINPLEN,fpDatafile);
 		*(iHashsearchengine+index) = strlen(*(sSearchenginename+index)) - 1;
 		//puts(*(sSearchenginename+index));
 		//printf("%d\n",*(iHashsearchengine+index));
 	 }
 	fnlogfnname( __FUNCTION__ ,0);
 	fclose(fpDatafile);
 }
 
 
 
 void fnSkipelements(FILE *fp,int iNumskip)
 {
 	int index;
 	char sStr[MAXINPLEN];
 
 	fnlogfnname( __FUNCTION__ ,1);
 
 	for (index = 0; index < iNumskip;index++)
 	{
 		fgets(sStr,MAXINPLEN,fp);
 	 }
 
 	fnlogfnname( __FUNCTION__ ,0);
 
 }
 
 
 
 void fnCleararr(int *iProcessarr, int iNumsearchengines)
 {
 	int index;
 
 	fnlogfnname( __FUNCTION__ ,1);
 	for (index=0;index<iNumsearchengines;index++)
 	{
 		*(iProcessarr+index) = 0;
  	 }
  	 fnlogfnname( __FUNCTION__ ,0);
 
 }
 

