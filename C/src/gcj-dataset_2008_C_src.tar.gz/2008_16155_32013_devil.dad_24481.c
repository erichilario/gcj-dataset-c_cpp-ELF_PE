#include<stdio.h>
 #include<process.h>
 #include<conio.h>
 void sort(int a[100][2],int l)
 {
 	int  i,j,temp;
 	for(i=0;i<l;i++)
 	{
 		for(j=1;j<l-i;j++)
 		{
 			if((a[j-1][0]>a[j][0])||((a[j-1][0]==a[j][0])&&(a[j-1][1]>a[j][1])))
 			{
 				temp=a[j-1][0];
 				a[j-1][0]=a[j][0];
 				a[j][0]=temp;
 				temp=a[j-1][1];
 				a[j-1][1]=a[j][1];
 				a[j][1]=temp;
 			}
 		}
 	}
 }
 
 int search(int t,int dep[100][2],int j,int nb,int arl[100][2])
 {
 	int k=-1,i,d=0,dif;
 	for(i=0;i<nb;i++)
 	{
 		if(arl[i][0]!=-1)
 		{
 			if(arl[i][0]==dep[j][0])
 			{
 				if(arl[i][1]<=(dep[j][1]-t))
 				{
 					dif=dep[j][1]-arl[i][1];
 					if(dif>=d)
 					{
 						k=i;
 						d=dif;
 					}
 				}
 			}
 			else if(arl[i][0]<dep[j][0])
 			{
 				dif=dep[j][0]-arl[i][0];
 				dif*=60;
 				dif+=dep[j][1]-arl[i][1];
 				if(dif>=t && dif>=d)
 				{
 					k=i;
 					d=dif;
 				}
 			}
 		}
 	}
 	if(k!=-1)
 	{
 		arl[k][0]=-1;
 		arl[k][1]=-1;
 	}
 	return(k);
 }
 
 void main()
 {
 	int i,j,na,nb,n,t,dpta[100][2],arla[100][2],dptb[100][2],arlb[100][2];
 	int cta,ctb,k;
 	FILE *fp;
 	clrscr();
 	scanf("%d",&n);
 	fp=fopen("output.txt","w");
 	for(i=0;i<n;i++)
 	{
 		cta=0;
 		ctb=0;
 		scanf("%d",&t);
 		scanf("%d %d",&na,&nb);
 		for(j=0;j<na;j++)
 			scanf("%d:%d %d:%d",&dpta[j][0],&dpta[j][1],&arla[j][0],&arla[j][1]);
 		for(j=0;j<nb;j++)
 			scanf("%d:%d %d:%d",&dptb[j][0],&dptb[j][1],&arlb[j][0],&arlb[j][1]);
 		sort(dpta,na);
 		sort(dptb,nb);
 		sort(arla,na);
 		sort(arlb,nb);
 		for(j=0;j<na;j++)
 		{
 			k=search(t,dpta,j,nb,arlb);
 			if(k==-1)
 				cta++;
 		}
 		for(j=0;j<nb;j++)
 		{
 			k=search(t,dptb,j,na,arla);
 			if(k==-1)
 				ctb++;
 		}
 		fprintf(fp,"Case #%d: %d %d\r",i+1,cta,ctb);
 		printf("Case #%d: %d %d",i+1,cta,ctb);
 	}
 	fclose(fp);
 }

