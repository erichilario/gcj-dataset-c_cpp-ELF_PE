#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int minNumSwitches();
 
 int numCases;
 int curNumEngines;
 int curNumQueries;
 char engines[100][101];
 char queries[1000][101];
 
 int res[100][1000];
 
 
 int main(int argc, char **argv)
 {
 	FILE *f;
 	int t;
 	char buffer[256];
 	char *s;
 	int i, j;
 	
 	if(argc < 2)
 	{
 		fprintf(stderr, "Needs an argument\n");
 		exit(1);
 	}
 
 	if((f = fopen(argv[1], "r")) == NULL)
 	{
 		fprintf(stderr, "File doesn't exist\n");
 		exit(2);
 	}
 
 	fgets(buffer, 256, f);
 	sscanf(buffer, "%d", &numCases);
 
 
 	for(i = 0; i < numCases; i++)
 	{
 		fgets(buffer, 256, f);
 		sscanf(buffer, "%d", &curNumEngines);
 		
 		for(j = 0; j < curNumEngines; j++)
 		{
 			fgets(engines[j], 101, f);
 			if((s = strchr(engines[j], '\n')))
 				*s = '\0';
 		}
 
 		fgets(buffer, 256, f);
 		sscanf(buffer, "%d", &curNumQueries);
 		
 		for(j = 0; j < curNumQueries; j++)
 		{
 			fgets(queries[j], 101, f);
 			if((s = strchr(queries[j], '\n')))
 				*s = '\0';
 		}
 
 		printf("Case #%d: %d\n", i + 1, (t = minNumSwitches()));
 	fprintf(stderr, "Case #%d: %d\n", i + 1, t);
 	}
 
 	return 0;
 }
 
 int minNumSwitches()
 {
 	int q, e, prevMin, curMin;
 
 	if(curNumQueries <= 1) return 0;
 
 	q = curNumQueries - 1;
 
 	for(e = 0; e < curNumEngines; e++)
 	{
 		if(strcmp(engines[e], queries[q]) == 0)
 			res[e][q] = -1;
 		else
 			res[e][q] = 0;
 	}
 
 	prevMin = 0;
 	curMin = -1;
 
 	for(q = curNumQueries - 2; q >= 0; q--)
 	{
 		curMin = -1;
 		for(e = 0; e < curNumEngines; e++)
 		{
 			if(strcmp(engines[e], queries[q]) == 0)
 				res[e][q] = -1;
 			else
 			{
 				if(res[e][q + 1] == -1)
 					res[e][q] = prevMin + 1;
 				else
 					res[e][q] = res[e][q + 1];
 
 				if(res[e][q] < curMin || curMin == -1)
 					curMin = res[e][q];
 			}
 
 		}
 		prevMin = curMin;
 	}
 
 	return prevMin;
 }
 

