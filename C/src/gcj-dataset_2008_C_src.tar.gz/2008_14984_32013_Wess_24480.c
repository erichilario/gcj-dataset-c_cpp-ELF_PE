#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 #define TAM_LINE 255
 
 int stringHash(char *);
 int min(int *, int, int);
 
 int main(int argc, char *argv[]) {
 
   char aux[TAM_LINE], **search_eng; FILE *fl;
   int i, j, k, nsearch_eng, nqueries, ntest, mn, resg = 0, *vector;;
 
   fl = fopen(argv[1], "r");
 
   fgets(aux, TAM_LINE, fl);
   sscanf(aux, "%d", &ntest);
 
   for(i = 0; i < ntest; i++) {
 
     fgets(aux, TAM_LINE, fl);
     sscanf(aux, "%d", &nsearch_eng);
 
     search_eng = (char **) malloc(sizeof(char *) * nsearch_eng);
     vector = (int *) calloc(nsearch_eng, sizeof(int));
 
     for(j = 0; j < nsearch_eng; j++) {
       search_eng[j] = (char *) malloc(sizeof(char) * TAM_LINE);
       fgets(aux, TAM_LINE, fl); strcpy(search_eng[j], aux);
     }
 
     fgets(aux, TAM_LINE, fl);
     sscanf(aux, "%d", &nqueries);
 
     if(nqueries > 0) {
       fgets(aux, TAM_LINE, fl);
       for(j = 0; j < nsearch_eng; j++)
         if(!strcmp(search_eng[j], aux)) vector[j] = nqueries + 1;
     }
 
     for(k = 1; k < nqueries; k++) {
       fgets(aux, TAM_LINE, fl);
 
       for(j = 0; j < nsearch_eng; j++)
         if(!strcmp(search_eng[j], aux)) resg = j;
         else vector[j] = min(vector, nsearch_eng, j);
       vector[resg] = nqueries + 1;
     }
 
     mn = vector[0];
     for(j = 0; j < nsearch_eng; j++) 
       if(vector[j] < mn) mn = vector[j];
 
     printf("Case #%d: %d\n", (i+1), mn);
 
     //free(vector);
     //free(search_eng);
   }
 
   fclose(fl);
   return 0;
 }
 
 int min(int *vector, int limit, int pos) {
   int i, min;
 
   if(pos == 0) min = vector[0];
   else min = vector[0] + 1;
 
   for(i = 0; i < limit; i++)
     if((vector[i] + 1) < min && i != pos)  min = vector[i] + 1;
     else if(vector[i]  < min && i == pos) min = vector[i];
 
   return min;
 }
 
 int stringHash(char *string) {
   int i, j, k, value;
 
   j = strlen(string);
   for(i = 0, value = 0, k = 1; i < j; i++, k *= 10) value += (string[i] * k);
   return value;
 }

