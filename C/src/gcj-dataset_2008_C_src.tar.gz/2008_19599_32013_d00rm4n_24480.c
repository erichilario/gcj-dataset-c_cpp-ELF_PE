#include <stdio.h>
 #include <math.h>
 #include <stdlib.h>
 #include <malloc.h>
 #include <string.h>
 #include <pthread.h>
 #include <ctype.h>
 #include "list.h"
 
 
 #define FOR( iter, end, statement )          for( iter = 0; iter < end; iter++ ) statement
 #define FOR_LIST( iter, lhead, statement )   for( iter = lhead; iter; iter = ( iter )->next ) statement
 #define MALLOC( type, count )                ( ( type * )malloc( sizeof( type ) * count ) )
 
 
 #define MAX_THREADS       10
 #define THREAD_FREE       0
 #define THREAD_BUSY       1
 #define THREAD_FINISHED   2
 
 #define ST_NOT_STARTED    0
 #define ST_STARTED        1
 #define ST_FINISHED       2
 #define ST_DONE           3
 
 
 struct mthread {
 	pthread_t thr;
 	int current_block;
 	int status;
 };
 
 struct input {
 	struct list *engines;
 	struct list *queries;
 	int switches;
 	int status;
 };
 
 typedef struct mthread thread_t;
 typedef struct input input_t;
 
 
 thread_t thread[MAX_THREADS];
 
 input_t *data;
 int data_count;
 
 
 void *thread_job( void *ptr );
 void thread_manager();
 void switcher( input_t *path );
 void read_input( FILE *fp );
 void write_output( FILE *fp );
 
 
 void *thread_job( void *ptr ) {
 	
 	int tid = *( ( int * )ptr );
 	
 	thread[tid].status = THREAD_BUSY;
 	
 	switcher( &data[thread[tid].current_block] );
 	
 	thread[tid].status = THREAD_FINISHED;
 	
 }
 
 
 void thread_manager() {
 	
 	int i, j, done;
 	int index[MAX_THREADS];
 	
 	memset( thread, 0, sizeof( thread_t ) * MAX_THREADS );
 	
 	for( i = 0; i < MAX_THREADS; i++ )
 		index[i] = i;
 	
 	while( 1 == 1 ) {
 		for( i = 0; i < MAX_THREADS; i++ ) {
 			if( thread[i].status == THREAD_FREE ) {
 				for( j = 0; j < data_count; j++ ) {
 					if( data[j].status == ST_NOT_STARTED ) {
 						data[j].status = ST_STARTED;
 						thread[i].current_block = j;
 						pthread_create( &thread[i].thr, NULL, thread_job, ( void *)&index[i] );
 						break;
 					}
 				}
 			}
 			if( thread[i].status == THREAD_FINISHED ) {
 				pthread_join( thread[i].thr, NULL );
 				thread[i].status = THREAD_FREE;
 				data[thread[i].current_block].status = ST_DONE;
 			}
 		}
 		done = 0;
 		for( i = 0; i < data_count; i++ )
 			if( data[i].status == ST_DONE )
 				done++;
 		if( done == data_count )
 			break;
 	}
 	
 }
 
 
 /********************************
  *                              *
  *      SWITCHER FUNCTIONS      *
  *                              *
  ********************************/
 
 
 void tie_lists( struct list *engines, struct list *queries ) {
 	
 	int i, all = -1;
 	struct lnode *e_node, *q_node;
 	
 	FOR_LIST( e_node, engines->head, {
 		i = 0;
 		all = -1;
 		FOR_LIST( q_node, queries->head, {
 			all++;
 			if( q_node->ref != NULL ) {
 				if( q_node->ref == e_node ) {
 					i++;
 					if( i == 1 )
 						e_node->distance = all;
 				}
 			} else if( strcmp( e_node->name, q_node->name ) == 0 ) {
 				i++;
 				q_node->ref = e_node;
 				if( i == 1 )
 					e_node->distance = all;
 			}
 		} )
 		e_node->count = i;
 		if( e_node->count == 0 )
 			e_node->distance = MAX_QUERIES + 1;
 	} )
 	
 }
 
 
 struct lnode *get_min_count( struct list *lst, struct lnode *not_allowed ) {
 	
 	struct lnode *node, *min_count;
 	
 	min_count = lst->head;
 	if( min_count == not_allowed )
 		min_count = min_count->next;
 	
 	FOR_LIST( node, lst->head, {
 		if( node == not_allowed )	
 			continue;
 		if( node->distance > min_count->distance )
 			min_count = node;
 	} )
 	
 	return min_count;
 	
 }
 
 
 struct lnode *consume_query( struct list *engines, struct list *queries ) {
 	
 	struct lnode *node, *ret = queries->head->next;
 	
 	delete_from_list( queries, queries->head );
 	
 	tie_lists( engines, queries );
 	
 	return ret;
 	
 }
 
 
 void switcher( input_t *path ) {
 	
 	struct lnode *node, *min, *curr;
 	
 	path->switches = 0;
 	
 	tie_lists( path->engines, path->queries );
 	
 	curr = min = get_min_count( path->engines, NULL );
 	
 	node = path->queries->head;
 	while( node ) {
 		if( node->ref != curr ) {
 			node = consume_query( path->engines, path->queries );
 			continue;
 		}
 		path->switches++;
 		node = consume_query( path->engines, path->queries );
 		curr = get_min_count( path->engines, curr );
 	}
 	
 }
 
 
 /************************************
  *                                  *
  *     INPUT / OUTPUT FUNCTIONS     *
  *                                  *
  ************************************/
 
 
 void read_input( FILE *fp ) {
 	
 	int i, j, no;
 	char string[MAX_NAME];
 	
 	fscanf( fp, "%d%*c", &data_count );
 	
 	/// allocate the memory space
 	data = ( input_t * )malloc( data_count * sizeof( input_t ) );
 	memset( data, 0, data_count * sizeof( input_t ) );
 	
 	/// read the file
 	FOR( i, data_count, {
 		init_list( &data[i].engines );
 		init_list( &data[i].queries );
 		fscanf( fp, "%d%*c", &no );
 		FOR( j, no, {
 			fscanf( fp, "%100[^\n]%*c", string );
 			add_to_list( data[i].engines, string, NULL );
 		} )
 		fscanf( fp, "%d%*c", &no );
 		FOR( j, no, {
 			fscanf( fp, "%100[^\n]%*c", string );
 			add_to_list( data[i].queries, string, NULL );
 		} )
 	} )
 	
 }
 
 
 void write_output( FILE *fp ) {
 	
 	int i;
 	struct lnode *node;
 	
 	for( i = 0; i < data_count; i++ ) {
 		fprintf( fp, "Case #%d: %d\n", i + 1, data[i].switches );
 		/*FOR_LIST( node, data[i].engines->head, {
 			printf( "%s\n", node->name );
 		} )
 		printf( "\n" );*/
 	}
 	
 }
 
 
 /*************************
  *                       *
  *     MAIN FUNCTION     *
  *                       *
  *************************/
 
 
 int main( int argc, char **argv ) {
 	
 	FILE *fin, *fout;
 	int i;
 	
 	/// check the command-line arguments
 	if( argc != 3 ) {
 		printf( "Usage: %s file_in file_out\n", argv[0] );
 		return EXIT_FAILURE;
 	}
 	
 	/// open the input and output files
 	fin = fopen( argv[1], "r" );
 	fout = fopen( argv[2], "w" );
 	if( ( fin == NULL ) || ( fout == NULL ) ) {
 		if( fin == NULL )
 			printf( "Cannot open input file...\n" );
 		else
 			printf( "Cannot open output file...\n" );
 		fcloseall();
 		return EXIT_FAILURE;
 	}
 	
 	/// read the input file
 	read_input( fin );
 	
 	/// start the jobs
 	thread_manager();
 	
 	/// write the output
 	write_output( fout );
 	
 	fcloseall();
 	
 	return EXIT_SUCCESS;
 	
 }

