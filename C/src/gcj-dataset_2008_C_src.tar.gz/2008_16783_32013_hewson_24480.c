#include<math.h>
 #include<stdio.h>
 #include<malloc.h>
 
 struct node{
        char *strptr;
        int index;
        struct node *ptr;
 };
 # define SIZE 101
 char stream[SIZE];
 struct node *htab[SIZE];
 void insert(char *str,int index);
 void init();
 void mfree();
 # define PRIME 101
 void insert(char *str,int index){
      int num=hash(str);
      struct node *curr=htab[num];
      struct node *temp;
      if(curr==NULL){
                    temp=(struct node *)malloc(sizeof(struct node));
                    temp->strptr=(char *)malloc(strlen(str)+1);
                    strcpy(temp->strptr,str);
                    temp->index=index;
                    temp->ptr=NULL;
                    htab[num]=temp;
                    return;
      }
      else{
           while(curr->ptr!=NULL){
                                  curr=curr->ptr;
           }
           temp=(struct node *)malloc(sizeof(struct node));
           temp->strptr=(char *)malloc(strlen(str)+1);
           strcpy(temp->strptr,str);
           temp->index=index;
           temp->ptr=NULL;
           curr->ptr=temp;
      }
      return;
 }
 int lookup(char *str){
     struct node *curr=htab[hash(str)];
     while(strcmp(curr->strptr,str))
     curr=curr->ptr;
     return curr->index;
 }
 int hash (const char *name){
   unsigned int g, h = 0;
   while (*name){
     h = (h << 4) + *name;
     if ((g = h & 0xF0000000) != 0){
       h ^= g >> 24;
       h ^= g;}
     ++ name;
   }
   return h % PRIME;
 }
 void init(){
      int i;
      for(i=0;i<SIZE;i++)
                         htab[i]=NULL;
 }
 void mfree(){
      struct node *cur,*temp;
      int i;
      for(i=0;i<SIZE;i++){
      cur=htab[i];
                  while(cur){
                  temp=cur->ptr;
                  free(cur->strptr);
                  free(cur);
                  cur=temp;}
                  htab[i]=NULL;
      }
 }                                
 int main(){
     int N,S,Q;
     int i,j,k;
     FILE *fip,*fop;
     unsigned check=0,val;
     char *inpath="C:\\A-small-attempt0.in";                                            
     char *outpath="C:\\result.txt";                                           
     fip=fopen(inpath,"r");
     fop=fopen(outpath,"w");
     fgets(stream,SIZE,fip);
     sscanf(stream,"%d",&N);
     i=j=k=0;
     init();
     int counter=0,temp;
     while(i<N){
     fgets(stream,SIZE,fip);
     sscanf(stream,"%d",&S);
     val=pow(2,S)-1;
                while(j<S){
                fgets(stream,SIZE,fip);
                stream[strlen(stream)-1]='\0';
                insert(stream,j);
                j++;}
                j=0;
                fgets(stream,SIZE,fip);
                sscanf(stream,"%d",&Q);
                check=0;
                while(k<Q){
                           fgets(stream,SIZE,fip);
                           stream[strlen(stream)-1]='\0';
                           temp=pow(2,lookup(stream));
                           check = check | temp;                                                                       
                           if(check==val){
                           check=0;
                           check=check | temp;
                           counter++;}
                           k++;}
     k=0; 
     fprintf(fop,"Case #%d: %d\n",i+1,counter);
     counter=0;
     mfree();
     i++;
     }
     fclose(fip);
     fclose(fop);
 }

