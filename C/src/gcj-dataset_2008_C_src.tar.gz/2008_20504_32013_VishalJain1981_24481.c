#include<stdio.h>
 #include<conio.h>
 #include<string.h>
 #include<stdlib.h>
 
 #define MAX_NA 20 // NA is number of Dep from A
 #define MIN_NA 0
 #define MAX_NB 20 // NB is number of Dep from B
 #define MIN_NB 0
 #define MAX_N  100 // Test cases for Small Input
 #define MIN_N 1
 #define MAX_T 5
 #define MIN_T 0
 
 
 // Errors
 typedef enum ERROR_e
 {
   NO_ERROR,
   ERROR_OPENING_FILE,
   ERROR_OUT_OF_BOUND_INPUT
 }Error_t;
 
 
 #if 0
 // Server Name max length
 #define serverNameLenghtMax 100
 #define numServerMax 100
 #define numServerMin 2
 #define numQueriesMax 1000
 
 // Errors
 typedef enum ERROR_e
 {
   NO_ERROR,
   ERROR_OPENING_FILE,
   ERROR_MORE_THAN_MAX_SERVER,
   ERROR_LESS_THAN_MIN_SERVER,
   ERROR_MORE_THAN_MAX_QUERIES
 }Error_t;
 
 #define INF 0xFFFFFFF
 
 /* Model problem as "most late used in future" */
 typedef struct querySet // This is one test case
 {
     int countQuery;
 	int countServer;
 	char ServerName[numServerMax][serverNameLenghtMax];
 	char QueryList[numQueriesMax][serverNameLenghtMax];
 }querySet_t;
 
 typedef enum status_e
 {
    DONE,
    NOT_DONE
 }status_t;
 
 querySet_t q;
 
 int getMaxIndex(int * array)
 {
     int max=array[0],index=0;
     int itr=0;
     for(itr=0;itr<q.countServer;itr++)
     {
        if(max<array[itr])
        {
           max=array[itr];
           index=itr;
        }
     }
     return max;
 }
 
 int updateTimeStamp(int * timeStamp,int startIndex,int countQuery,int countServer)
 {
      int itrCountQuery = countQuery,itrCountServer=countServer;
 
 	 // Make all time INF
 	 itrCountServer = q.countServer;
 	 while(itrCountServer--)
 	 {
 		 timeStamp[itrCountServer]=INF;
 	 }
      itrCountServer=countServer;
      if(startIndex>countQuery)
      {
        return DONE;
      }
      // traverse from end and go to index and update itr into timeStamp
      while(itrCountServer--!=0)
      {
        itrCountQuery=countQuery;
        while(itrCountQuery-->startIndex)
        {
          if(!strcmp(q.ServerName[itrCountServer],q.QueryList[itrCountQuery]))
 		 	timeStamp[itrCountServer]=itrCountQuery;
        }
 	 }
 
 }
 #endif
 // Always keep Available first in list and then departure it they happen at same time
 // so that we can increse available before departure
 int AvailableAtA;
 int AvailableAtB;
 int NewIntroducedAtA;
 int NewIntroducedAtB;
 
 typedef enum
 {
 	UNINITIALIZED,
     DEPARTURE,
 	NEWAVAILABLE
 }Flag_t;
 
 typedef struct EventList
 {
     int Time;
     Flag_t event;
 }EventList_t;
 
 EventList_t EventListA[MAX_NA+MAX_NB];
 EventList_t EventListB[MAX_NA+MAX_NB];
 
 int getMin(int Hr,int Min)
 {
     return Hr*60+Min;
 }
 int main(void)
 {
 	int itrCountServer=0,itrCountQuery=0,index=0,maxValue=0;
 	int nextServiceIndex=0;
 	int leftOverReq,switchIndex,switchCount;
 	int numTests,numTestsItr;
 	int * timeStamp=NULL;
 	char ch;
 	FILE  * fp;
 	FILE  * fpOUT;
 
     fp=fopen("d://input.txt","r") ;
 	if(!fp)
 		exit(ERROR_OPENING_FILE);
 
     fpOUT=fopen("d://output.txt","w");
 	if(!fpOUT)
     	exit(ERROR_OPENING_FILE);
 
     // Read number of tests
 	fscanf(fp,"%d",&numTests);
 
     // For each test case do
     for(numTestsItr=1;numTestsItr<=numTests;numTestsItr++)
     {
         int turnAroundTime=0;
 		int numDeparturesFromA=0,numDeparturesFromB=0;
 		int itrDeparturesFromA=0,itrDeparturesFromB=0;
 		char ch;
 		int itrEventList=0;
 
 		// Reset the event list for next test case
 		memset(EventListA,0,sizeof(EventList_t)*(MAX_NA+MAX_NB));
         memset(EventListB,0,sizeof(EventList_t)*(MAX_NA+MAX_NB));
 
         // Read server Count
         fscanf(fp,"%d",&turnAroundTime);
         fscanf(fp,"%d",&numDeparturesFromA);
 		fscanf(fp,"%d",&numDeparturesFromB);
 
 
         // Make event list for Station A and Station B out of dep from A
         for(itrDeparturesFromA=0;itrDeparturesFromA<numDeparturesFromA;++itrDeparturesFromA)
         {
             int depFromAHr=0,depFromAMin=0,arrAtBHr=0,arrAtBMin=0;
             int itrEventListA=0,itrEventListB=0,departureTimefromAInMin,arrivalTimeAtBInMin;
 
             fscanf(fp,"%d",&depFromAHr);
             fscanf(fp,"%c",&ch);
             fscanf(fp,"%d",&depFromAMin);
             fscanf(fp,"%c",&ch);
             fscanf(fp,"%d",&arrAtBHr);
             fscanf(fp,"%c",&ch);
             fscanf(fp,"%d",&arrAtBMin);
 
 			// Get these local variables converted into mins and update EventList
 			departureTimefromAInMin=getMin(depFromAHr,depFromAMin);
 
             // Insert this departure time into event list of A
             while(EventListA[itrEventListA].event!=UNINITIALIZED && EventListA[itrEventListA].Time<=departureTimefromAInMin)
             {
                   itrEventListA++; // if arrival and dep at the dame time then dep should take place after arrival : Boundry condition
 			}
 			// Got index from above - the correct position of new Time
             if(EventListA[itrEventListA].event == UNINITIALIZED)
             {
                  EventListA[itrEventListA].event = DEPARTURE;
                  EventListA[itrEventListA].Time=departureTimefromAInMin;
 			}
 			else // Time is greater than departure time from A, also skipped any arrival with equal to in above condition
 			{
 			     int x=0;
 			     // List has got itrDepartureFromA number of elements so just add new element's space by moving leftover elements
 			     for(x=itrDeparturesFromA+1;x>itrEventListA;x--)
 				 	EventListA[x]=EventListA[x-1];
 
 				 // Update new inserted node
 				 EventListA[itrEventListA].Time=departureTimefromAInMin;
                  EventListA[itrEventListA].event=DEPARTURE;
 			}
 
 			// Update list of B as well for the same
 
 			// Get min for arrival at B
 			arrivalTimeAtBInMin=getMin(arrAtBHr,arrAtBMin);// Take not os TurnAround time in below Loop
 
             // Get the node and insert
             while(EventListB[itrEventListB].event!=UNINITIALIZED && EventListB[itrEventListB].Time<(arrivalTimeAtBInMin+turnAroundTime))
             {
                   itrEventListB++; // if arrival and dep at the same time then dep should take place after arrival : Boundry condition
 			}
 
 			// Got index from above - the correct position of new Time
             if(EventListB[itrEventListB].event == UNINITIALIZED)
             {
                  EventListB[itrEventListB].event = NEWAVAILABLE;// This is not arrival it is available
                  EventListB[itrEventListA].Time=arrivalTimeAtBInMin+turnAroundTime;
 			}
 			else // Time is greater than departure time from A, also skipped any arrival with equal to in above condition
 			{
 			     int x=0;
 			     // List has got itrDepartureFromA number of elements so just add new element's space by moving leftover elements
 			     for(x=itrDeparturesFromA;x>itrEventListB;x--)
 				 	EventListB[x]=EventListB[x-1];
 
 				 // Update new inserted node
 				 EventListB[itrEventListB].Time=arrivalTimeAtBInMin+turnAroundTime;
                  EventListB[itrEventListB].event=NEWAVAILABLE;
 			}
 
 		}
 
         // Make event list for Station A and Station B out of dep from A
         for(itrDeparturesFromB=0;itrDeparturesFromB<numDeparturesFromB;++itrDeparturesFromB)
         {
             int depFromBHr=0,depFromBMin=0,arrAtAHr=0,arrAtAMin=0;
             int itrEventListA=0,itrEventListB=0,departureTimefromBInMin,arrivalTimeAtAInMin;
 
             fscanf(fp,"%d",&depFromBHr);
             fscanf(fp,"%c",&ch);
             fscanf(fp,"%d",&depFromBMin);
             fscanf(fp,"%c",&ch);
             fscanf(fp,"%d",&arrAtAHr);
             fscanf(fp,"%c",&ch);
             fscanf(fp,"%d",&arrAtAMin);
 
 			// Get these local variables converted into mins and update EventList
 			departureTimefromBInMin=getMin(depFromBHr,depFromBMin);
 
             // Insert this departure time into event list of B
             while(EventListB[itrEventListB].event!=UNINITIALIZED && EventListB[itrEventListB].Time<=departureTimefromBInMin)
             {
                   itrEventListB++; // if arrival and dep at the dame time then dep should take place after arrival : Boundry condition
 			}
 			// Got index from above - the correct position of new Time
             if(EventListB[itrEventListB].event == UNINITIALIZED)
             {
                  EventListB[itrEventListB].event = DEPARTURE;
                  EventListB[itrEventListB].Time=departureTimefromBInMin;
 			}
 			else // Time is greater than departure time from B, also skipped any arrival with equal to in above condition
 			{
 			     int x=0;
 
 			     // List has got itrDepartureFromA number of elements so just add new element's space by moving leftover elements
 			     for(x=itrDeparturesFromB+numDeparturesFromA+1;x>itrEventListB;x--)
 				 	EventListB[x]=EventListB[x-1];
 
 				 // Update new inserted node
 				 EventListB[itrEventListB].Time=departureTimefromBInMin;
                  EventListB[itrEventListB].event=DEPARTURE;
 			}
 
 			// Update list of B as well for the same
 
 			// Get min for arrival at A
 			arrivalTimeAtAInMin=getMin(arrAtAHr,arrAtAMin);// Take not os TurnAround time in below Loop
 
             // Get the node and insert
             while(EventListA[itrEventListA].event!=UNINITIALIZED && EventListA[itrEventListA].Time<(arrivalTimeAtAInMin+turnAroundTime))
             {
                   itrEventListA++; // if arrival and dep at the same time then dep should take place after arrival : Boundry condition
 			}
 
 			// Got index from above - the correct position of new Time
             if(EventListA[itrEventListA].event == UNINITIALIZED)
             {
                  EventListA[itrEventListA].event = NEWAVAILABLE;// This is not arrival it is available
                  EventListA[itrEventListA].Time=arrivalTimeAtAInMin+turnAroundTime;
 			}
 			else // Time is greater than departure time from A, also skipped any arrival with equal to in above condition
 			{
 			     int x=0;
 			     // List has got itrDepartureFromA number of elements so just add new element's space by moving leftover elements
 			     for(x=itrDeparturesFromB+numDeparturesFromA;x>itrEventListA;x--)
 				 	EventListA[x]=EventListA[x-1];
 
 				 // Update new inserted node
 				 EventListA[itrEventListA].Time=arrivalTimeAtAInMin+turnAroundTime;
                  EventListA[itrEventListA].event=NEWAVAILABLE;
 			}
            printf("Debug");
 		}
         AvailableAtA=AvailableAtB=NewIntroducedAtA=NewIntroducedAtB=0;
         // We have now sorted list on the basis of time now we can go ahead and calculate number of Trains needed
         for(itrEventList=0;itrEventList<(numDeparturesFromB+numDeparturesFromA);++itrEventList)
         {
            if(EventListA[itrEventList].event==NEWAVAILABLE)
            {
               AvailableAtA++;
 		   }
 		   if(EventListA[itrEventList].event==DEPARTURE)
 		   {
               if(AvailableAtA)
 			  	AvailableAtA--;
 			  else
 			  	NewIntroducedAtA++;
 		   }
 		   if(EventListA[itrEventList].event==UNINITIALIZED)
 		   {}
 
 		   if(EventListB[itrEventList].event==NEWAVAILABLE)
 		   {
               AvailableAtB++;
 		   }
 		   if(EventListB[itrEventList].event==DEPARTURE)
 		   {
               if(AvailableAtB)
 			  	AvailableAtB--;
 			  else
 			  	NewIntroducedAtB++;
 		   }
 
 		}
 		 // One case over so print result
 		 fprintf(fpOUT,"Case #%d: %d %d\n",numTestsItr,NewIntroducedAtA,NewIntroducedAtB);
 
     }
 
    fclose(fpOUT);
    fclose(fp);
 
     return 0;
 }
 

