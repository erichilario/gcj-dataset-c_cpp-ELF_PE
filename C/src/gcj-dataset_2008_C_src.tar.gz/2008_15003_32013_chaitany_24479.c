#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 #define PI (3.141592653589793)
 
 double distance(double x1, double y1, double x2, double y2)
 {
 	return sqrt( (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
 
 }
 
 double area_triangle(double x1, double y1, double x2, double y2, double x3, double y3)
 {
 	double a,b,c,s;
 
 	a = distance(x1,y1,x2,y2);
 	b = distance(x1,y1,x3,y3);
 	c = distance(x3,y3,x2,y2);
 	s = (a+b+c)/2.0;
 
 	return sqrt(s*(s-a)*(s-b)*(s-c));
 
 }
 
 double area_sector(double radius, double x1, double y1, double x2, double y2)
 {
  double mid_chord_x;
  double mid_chord_y;
  double theta;
 
  mid_chord_x = (x1+x2)/2.0;
  mid_chord_y = (y1+y2)/2.0;
 	
  theta = 2.0*atan( distance(x1,y1,mid_chord_x,mid_chord_y)/distance(0.0,0.0,mid_chord_x,mid_chord_y));
  
  return (radius*radius*(theta/2.0  ) );
 
 }
 
 //in the positve quadrant
 double calculate_area(double circle_radius, double sq_x, double sq_y, double sq_len)
 {
 	double leftdown_x = sq_x - (sq_len/2.0);
 	double leftdown_y = sq_y - (sq_len/2.0);
 	double leftup_x = sq_x - (sq_len/2.0);
 	double leftup_y = sq_y + (sq_len/2.0);
 	double rightdown_x = sq_x + (sq_len/2.0);
 	double rightdown_y = sq_y - (sq_len/2.0);
 	double rightup_x = sq_x + (sq_len/2.0);
 	double rightup_y = sq_y + (sq_len/2.0);
 
 	if(circle_radius >= distance(0.0,0.0,rightup_x,rightup_y) ) { return  sq_len*sq_len;}
 	if(circle_radius <= distance(0.0,0.0,leftdown_x,leftdown_y) ) { return  0.0;}
 
    if( ( distance(0.0,0.0,leftup_x,leftup_y) <= circle_radius  ) && ( distance(0.0,0.0,rightdown_x,rightdown_y) <= circle_radius ))  // only the right up edge is missing ....
 	{
 		double area = 0.0;
 		double left_sector_intersect_x;
 		double left_sector_intersect_y;
 		double right_sector_intersect_x;
 		double right_sector_intersect_y;
 		double left_square_intersect_x;
 		double left_square_intersect_y;
 		double right_square_intersect_x;
 		double right_square_intersect_y;
 
 		left_sector_intersect_x = sqrt( circle_radius*circle_radius - leftup_y*leftup_y);
 		left_sector_intersect_y = leftup_y;
 		right_sector_intersect_x = rightup_x;
 		right_sector_intersect_y = sqrt( circle_radius*circle_radius - rightup_x*rightup_x);
 		
 		left_square_intersect_x = leftup_x;
 		left_square_intersect_y = leftup_x * ( left_sector_intersect_y/left_sector_intersect_x);
 	
 		right_square_intersect_x = rightdown_y * ( right_sector_intersect_x/right_sector_intersect_y );
 		right_square_intersect_y = rightdown_y;
 
 		if((left_sector_intersect_y/left_sector_intersect_x) < ( leftdown_y/leftdown_x ))
 		{
 			left_square_intersect_x = rightdown_y * ( left_sector_intersect_x/left_sector_intersect_y );
 		   left_square_intersect_y = rightdown_y;
 
 			area += area_triangle(leftup_x, leftup_y, left_sector_intersect_x, left_sector_intersect_y, left_square_intersect_x, left_square_intersect_y );
 		
 			area += area_triangle(leftup_x, leftup_y, leftdown_x, leftdown_y, left_square_intersect_x, left_square_intersect_y );
 
 			area += area_triangle(rightdown_x, rightdown_y, right_sector_intersect_x, right_sector_intersect_y, right_square_intersect_x, right_square_intersect_y );
 
 			area += area_sector(circle_radius, left_sector_intersect_x, left_sector_intersect_y, right_sector_intersect_x, right_sector_intersect_y );
 			area -= area_triangle(0.0,0.0,left_square_intersect_x, left_square_intersect_y, right_square_intersect_x, right_square_intersect_y );
 
 		}
 		else if((right_sector_intersect_y/right_sector_intersect_x) > ( leftdown_y/leftdown_x ))
 		{
 				right_square_intersect_x = leftup_x;
 				right_square_intersect_y = leftup_x * ( right_sector_intersect_y/right_sector_intersect_x);
 
 				area += area_triangle(leftup_x, leftup_y, left_sector_intersect_x, left_sector_intersect_y, left_square_intersect_x, left_square_intersect_y );
 				area += area_triangle(rightdown_x, rightdown_y, right_sector_intersect_x, right_sector_intersect_y, right_square_intersect_x, right_square_intersect_y );
 				area += area_triangle(rightdown_x, rightdown_y, leftdown_x, leftdown_y, right_square_intersect_x, right_square_intersect_y );
 
 				area += area_sector(circle_radius, left_sector_intersect_x, left_sector_intersect_y, right_sector_intersect_x, right_sector_intersect_y );
 
 				area -= area_triangle(0.0,0.0,left_square_intersect_x,left_square_intersect_y,right_square_intersect_x, right_square_intersect_y);
 
 		}
 		else{
 
 				area += area_triangle(leftup_x, leftup_y, left_sector_intersect_x, left_sector_intersect_y, left_square_intersect_x, left_square_intersect_y );
 		
 
 				area += area_triangle(rightdown_x, rightdown_y, right_sector_intersect_x, right_sector_intersect_y, right_square_intersect_x, right_square_intersect_y );
 
 				area += area_sector(circle_radius, left_sector_intersect_x, left_sector_intersect_y, right_sector_intersect_x, right_sector_intersect_y );
 
 				area -= area_triangle(0.0,0.0,leftdown_x,leftdown_y,left_square_intersect_x, left_square_intersect_y);
 				area -= area_triangle(0.0,0.0,leftdown_x,leftdown_y,right_square_intersect_x, right_square_intersect_y);
 		}
 
 		if(area < 0) { printf("1st case area %lf  rad %lf sq_x %lf sq_y %lf sq_len %lf\n",area,circle_radius,sq_x,sq_y,sq_len );
 		
 		printf("first area %lf\n", area_triangle(leftup_x, leftup_y, left_sector_intersect_x, left_sector_intersect_y, left_square_intersect_x, left_square_intersect_y ));
 
 		printf("second area %lf\n", area_triangle(rightdown_x, rightdown_y, right_sector_intersect_x, right_sector_intersect_y, right_square_intersect_x, right_square_intersect_y ) );
 
 		printf("third area %lf lsix %lf lsiy %lf rsix %lf rsiy %lf\n", area_sector(circle_radius, left_sector_intersect_x, left_sector_intersect_y, right_sector_intersect_x, right_sector_intersect_y ),left_sector_intersect_x,left_sector_intersect_y,right_sector_intersect_x,right_sector_intersect_y);
 
 		printf("fourth area %lf\n",area_triangle(0.0,0.0,leftdown_x,leftdown_y,left_square_intersect_x, left_square_intersect_y));
 		printf("fifth area %lf\n",area_triangle(0.0,0.0,leftdown_x,leftdown_y,right_square_intersect_x, right_square_intersect_y));
 
 		}
 
 		return area;
 	}
 	else if( ( distance(0.0,0.0,leftup_x,leftup_y) > circle_radius  ) && ( distance(0.0,0.0,rightdown_x,rightdown_y) > circle_radius )) // only the leftdown  edge is remaining ....
 	{
 		double area = 0.0;
 		double left_sector_intersect_x;
 		double left_sector_intersect_y;
 		double right_sector_intersect_x;
 		double right_sector_intersect_y;
 
 		left_sector_intersect_x = leftup_x;
 		left_sector_intersect_y = sqrt( circle_radius*circle_radius - leftup_x*leftup_x);
 		right_sector_intersect_x = sqrt( circle_radius*circle_radius - rightdown_y*rightdown_y);
 		right_sector_intersect_y = rightdown_y;
 
 		area += area_sector(circle_radius, left_sector_intersect_x, left_sector_intersect_y, right_sector_intersect_x, right_sector_intersect_y );
 
 		area -= area_triangle(0.0,0.0,leftdown_x,leftdown_y,left_sector_intersect_x, left_sector_intersect_y);
 		area -= area_triangle(0.0,0.0,leftdown_x,leftdown_y,right_sector_intersect_x, right_sector_intersect_y);
 	
 		if(area < 0) { printf("2nd case area %lf  rad %lf sq_x %lf sq_y %lf sq_len %lf\n",area,circle_radius,sq_x,sq_y,sq_len ); }
 		return area;
 	}
 	else if( ( distance(0.0,0.0,leftup_x,leftup_y) <= circle_radius  ) && ( distance(0.0,0.0,rightdown_x,rightdown_y) > circle_radius)) // only the rightup and rightdown edges are missing ....
 	{
 			double area = 0.0;
 		double left_sector_intersect_x;
 		double left_sector_intersect_y;
 		double right_sector_intersect_x;
 		double right_sector_intersect_y;
 		double left_square_intersect_x;
 		double left_square_intersect_y;
 		double right_square_intersect_x;
 		double right_square_intersect_y;
 
 		left_sector_intersect_x = sqrt( circle_radius*circle_radius - leftup_y*leftup_y);
 		left_sector_intersect_y = leftup_y;
 		right_sector_intersect_x = sqrt( circle_radius*circle_radius - rightdown_y*rightdown_y);
 		right_sector_intersect_y = rightdown_y;
 		
 		left_square_intersect_x = leftup_x;
 		left_square_intersect_y = leftup_x * ( left_sector_intersect_y/left_sector_intersect_x);
 	
 		right_square_intersect_x = right_sector_intersect_x ;
 		right_square_intersect_y = right_sector_intersect_y ;
 
 		area += area_triangle(leftup_x, leftup_y, left_sector_intersect_x, left_sector_intersect_y, left_square_intersect_x, left_square_intersect_y );
 
 //		area += area_triangle(rightdown_x, rightdown_y, right_sector_intersect_x, right_sector_intersect_y, right_square_intersect_x, right_square_intersect_y );
 
 		area += area_sector(circle_radius, left_sector_intersect_x, left_sector_intersect_y, right_sector_intersect_x, right_sector_intersect_y );
 
 		area -= area_triangle(0.0,0.0,leftdown_x,leftdown_y,left_square_intersect_x, left_square_intersect_y);
 		area -= area_triangle(0.0,0.0,leftdown_x,leftdown_y,right_square_intersect_x, right_square_intersect_y);
 	
 		if(area < 0) { printf("3rd case area %lf  rad %lf sq_x %lf sq_y %lf sq_len %lf\n",area,circle_radius,sq_x,sq_y,sq_len ); }
 		return area;
 
 	}
 	else if( ( distance(0.0,0.0,leftup_x,leftup_y) > circle_radius  ) && ( distance(0.0,0.0,rightdown_x,rightdown_y) <= circle_radius)) // only the rightup and leftup edges are missing ....
 	{
 			double area = 0.0;
 		double left_sector_intersect_x;
 		double left_sector_intersect_y;
 		double right_sector_intersect_x;
 		double right_sector_intersect_y;
 		double left_square_intersect_x;
 		double left_square_intersect_y;
 		double right_square_intersect_x;
 		double right_square_intersect_y;
 
 
 		left_sector_intersect_x = leftup_x;
 		left_sector_intersect_y = sqrt( circle_radius*circle_radius - leftup_x*leftup_x);
 
 		right_sector_intersect_x = rightup_x;
 		right_sector_intersect_y = sqrt( circle_radius*circle_radius - rightup_x*rightup_x);
 		
 		left_square_intersect_x = left_sector_intersect_x;
 		left_square_intersect_y = left_sector_intersect_y;
 	
 		right_square_intersect_x = rightdown_y * ( right_sector_intersect_x/right_sector_intersect_y );
 		right_square_intersect_y = rightdown_y;
 
 
 //		area += area_triangle(leftup_x, leftup_y, left_sector_intersect_x, left_sector_intersect_y, left_square_intersect_x, left_square_intersect_y );
 
 		area += area_triangle(rightdown_x, rightdown_y, right_sector_intersect_x, right_sector_intersect_y, right_square_intersect_x, right_square_intersect_y );
 
 		area += area_sector(circle_radius, left_sector_intersect_x, left_sector_intersect_y, right_sector_intersect_x, right_sector_intersect_y );
 
 		area -= area_triangle(0.0,0.0,leftdown_x,leftdown_y,left_square_intersect_x, left_square_intersect_y);
 		area -= area_triangle(0.0,0.0,leftdown_x,leftdown_y,right_square_intersect_x, right_square_intersect_y);
 	
 		if(area < 0) { printf("4rth case area %lf  rad %lf sq_x %lf sq_y %lf sq_len %lf\n",area,circle_radius,sq_x,sq_y,sq_len ); }
 		return area;
 
 	}
 
 }
 
 int main(int argc, char** argv)
 {
 	
 	FILE* inpfile;
 	int N;
 	int i;
 
 	inpfile = fopen(argv[1],"r");
 	fscanf(inpfile,"%d",&N);
 
 	for(i=0;i<N;i++)
 	{
 		double f,R,t,r,g;
 		double x1,y1;
 		double area = 0.0;
 		double prob;
 		
 		fscanf(inpfile,"%lf %lf %lf %lf %lf",&f,&R,&t,&r,&g);
 
 		//printf("input values %lf %lf %lf %lf %lf\n",f,R,t,r,g);
 
 		for(x1 = r+(g/2.0); x1 < R+t+g; x1 = x1 + g + 2.0*r)
 		{
 			for(y1 = r+(g/2.0); y1 < R+t+g; y1 = y1 + g + 2.0*r)
 			{
 				//printf("For x1 %lf y1 %lf ..area is %lf\n",x1,y1,calculate_area(R-t-f,x1,y1,g-(2.0*f)));
 				area += calculate_area(R-t-f,x1,y1,g-(2.0*f));
 			}
 		}
 
 		area = area*(4.0);
 		
 		prob = 1.0 - (area/( PI*R*R ));
 
 		printf("Case #%d: %lf\n",i+1,prob);
 	}
 
 }
 
 

