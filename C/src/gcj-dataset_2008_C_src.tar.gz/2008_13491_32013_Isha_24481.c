#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 static void scan_time(int * t)
 {
 	char instr[10], str[10];
 
 	scanf("%s", instr);
 	memset(str, 0, sizeof(str));
 	strncpy(str, instr, 2);
 	*t = atoi(str);
 	strncpy(str, instr+3, 2);
 	*t = (*t) * 60 + atoi(str);
 }
 
 int compare( const void *a, const void *b)
 {
 	return (*(int*)a) - (*(int*)b);
 }
 
 int main(){
 	int nr, te;
 
 	int ta;
 	int na, nb;
 
 	int at_dep[100], at_arr[100], bt_dep[100], bt_arr[100];
 	int aswa, aswb;
 
 	int i;
 
 	int ai = 0;
 	int bi = 0;
 
 	scanf("%d", &te);
 
 	for ( nr = 0; nr < te; nr++ )
 	{
 		printf("Case #%d: ", nr+1);
 
 		aswa = 0;
 		aswb = 0;
 
 		scanf("%d", &ta);
 		scanf("%d%d", &na, &nb);		
 
 		for ( i = 0; i < na; i++ )
 		{
 			scan_time(&at_dep[i]);
 			scan_time(&at_arr[i]);
 		}
 		for ( i = 0; i < nb; i++ )
 		{
 			scan_time(&bt_dep[i]);
 			scan_time(&bt_arr[i]);
 		}
 		
 		qsort(at_dep, na, sizeof(int), compare);
 		qsort(at_arr, na, sizeof(int), compare);
 		qsort(bt_dep, nb, sizeof(int), compare);
 		qsort(bt_arr, nb, sizeof(int), compare);
 
 		ai = 0;
 		bi = 0;
 			
 		for ( i = 0; i < na; i++ )
 		{
 			if (bi >= nb) {
 				aswa += na - i;
 				break;
 			}
 
 			if (at_dep[i] < bt_arr[bi] + ta)
 				aswa++;
 			else 
 				bi++;
 		}
 
 		for ( i = 0; i < nb; i++ )
 		{
 			if (ai >= na) {
 				aswb += nb - i;
 				break;
 			}
 			
 			if (bt_dep[i] < at_arr[ai] + ta)
 				aswb++;
 			else 
 				ai++;
 		}			
 		
 		printf("%d %d\n", aswa, aswb);
 
 	}
 	return 0;
 }

