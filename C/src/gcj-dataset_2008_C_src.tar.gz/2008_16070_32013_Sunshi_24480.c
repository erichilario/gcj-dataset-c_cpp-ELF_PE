#include <stdio.h>
 #include <string.h>
 
 int main(int argc, char** argv){
 	int i,j,k,l,m;
 	int N;
 	int S;
 	int Q;
 	int nswitch;
 	int ifswitch;
 	char S_set[101][101];
 	char check[101];
 	char str_to_cmp[101];
 
 	scanf("%d",&N);	
 	for(i=0;i<N;i++){
 		ifswitch=0;
 		nswitch=0;
 		memset(S_set,0,101*101);
 		scanf("%d",&S);
 		getc(stdin);
 		for(j=0;j<S;j++)
 			gets(S_set[j]);
 		/* debug */
 		  /* for(j=0;j<S;j++)
 		                   printf("%s\n",S_set[j]);*/
 		scanf("%d",&Q);
 		getc(stdin);
 		//printf("Q=%d\n",Q);
 		if(Q<=S){
 			printf("Case #%d: 0\n",i+1);
 			continue;
 		}
 		else{
 			memset(check,0,101);
 			for(j=0;j<Q;j++){
 				gets(str_to_cmp);
 				//printf("%s\n",str_to_cmp);
 				for(k=0;k<S;k++){
 					if( strcmp(str_to_cmp,S_set[k])==0 ){
 						check[k]=1;
 						break;
 					}
 				}
 				/* check is full? then switch once */
 				for(l=0;l<S;l++){
 					if(check[l]==0)
 					{
 						ifswitch=0;
 						break;
 					}
 					else
 						ifswitch=1;
 				}
 				if(ifswitch)
 				{
 					nswitch+=1;
 					memset(check,0,101);
 					for(k=0;k<S;k++){
 					if( strcmp(str_to_cmp,S_set[k])==0 ){
 						check[k]=1;
 						break;
 					}				}
 					//printf("%s\n",S_set[k]);
 				}
 			}
 			printf("Case #%d: %d\n",i+1,nswitch);
 		}		
 	}
 	return 0;
 }

