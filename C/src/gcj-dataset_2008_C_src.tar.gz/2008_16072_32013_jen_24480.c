#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 
 int main(void)
 {
 
 	FILE *fp;
 	int caseno, engines, ANS, qno;
 	int i, j, k, m;
 	char enginename[100][100];
 	char query[1000][100];
 	int store[100];
 	char temp[100];
 
 	fp = fopen("A-small.in", "r");
 	fscanf(fp, "%d", &caseno);
 
 	for (i = 0; i <caseno; i++) {
 		ANS=0;
 		fscanf(fp, "%d", &engines);
 		fgets(temp,100,fp);
 		for (j=0; j<engines; j++){
 			fgets(enginename[j], 100, fp);
 		}
 		fscanf(fp, "%d", &qno);
 		fgets(temp,100,fp);
 		for (j=0; j<qno; j++){
 			fgets(query[j], 100, fp);
 		}
 
                 for (k=0; k<engines; k++){
                		 store[k]=0;
                 }
 
 
 		for (j=0, m=0;j<qno;j++ )
 		{
 			for(k=0; k<engines; k++){
 			if (strcmp(query[j],enginename[k]) ==0){
 				if (store[k]==0){
 				 	store[k]=1;
 					m++;
 				}
 				k = engines;
 			}
 			}
 			if (m==engines){
 				j--;
 				m=0;
 				ANS++;
 				for (k=0; k<engines; k++){
 					store[k]=0;
 				}
 			
 			}
 			
 
 		}
 		printf("Case #%d: %d\n", i+1, ANS);
 	}
 
 
 	fclose(fp);
 }

