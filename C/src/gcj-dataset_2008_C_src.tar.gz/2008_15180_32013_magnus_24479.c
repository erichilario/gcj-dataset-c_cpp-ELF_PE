#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 /*
  Description:
  Calculate swatter hit probability
  
  Arguments:
  f - fly radius
  R - swatter outer radius
  t - swatter outer ring thickness
  r - 1/2 string thickness
  g - swatter net hole size
  */
 double swatterHitProbability(
 	  double f,
 	  double R,
 	  double t,
 	  double r,
 	  double g
 	  )
 {
 	double	innerR			= R - t - f;
 	double  innerRSquare    = innerR * innerR;
 	double	netUnitSize		= g + 2 * r;
 	double  emptyUnitSize   = g - 2 * f;
 	double	emptyUnitArea	= emptyUnitSize * emptyUnitSize;
 	int		maxSquare		= ceil(innerR / netUnitSize);
 	
 	double emptyArea = 0;
 	int sqrIndexX, sqrIndexY;
 	for(sqrIndexX = 0; sqrIndexX < maxSquare; sqrIndexX++) {
 		for(sqrIndexY = 0; sqrIndexY < maxSquare; sqrIndexY++) {
 			double tOffset, bOffset, lOffset, rOffset;
 			lOffset = netUnitSize * sqrIndexX + r + f;
 			rOffset = netUnitSize * (sqrIndexX + 1) - r - f;
 			bOffset = netUnitSize * sqrIndexY + r + f;
 			tOffset = netUnitSize * (sqrIndexY + 1) - r - f;
 			
 			// Test if this is full empty area inside 
 			if(sqrt(rOffset * rOffset + tOffset * tOffset) < innerR) {
 				emptyArea += emptyUnitArea;
 				continue;
 			}
 
 			// Test if this is outbounds empty area 
 			if(sqrt(lOffset * lOffset + bOffset * bOffset) > innerR) {
 				continue;
 			}
 			
 			//
 			// This empty unit are intersects with inner radius
 			//
 			
 			// Compute intersection points
 			double tlInterX, tlInterY;
 			double brInterX, brInterY;
 			if(sqrt(tOffset * tOffset + lOffset * lOffset) < innerR) {
 				tlInterY = tOffset;
 				tlInterX = sqrt(innerRSquare - tOffset * tOffset);
 			}
 			else {
 				tlInterX = lOffset;
 				tlInterY = sqrt(innerRSquare - lOffset * lOffset);
 			}
 
 			if(sqrt(bOffset * bOffset + rOffset * rOffset) < innerR) {
 				brInterX = rOffset;
 				brInterY = sqrt(innerRSquare - rOffset * rOffset);
 			}
 			else {
 				brInterY = bOffset;
 				brInterX = sqrt(innerRSquare - bOffset * bOffset);
 			}
 
 			// Compute empty unit area
 			double unitArea = 0;
 			{
 				double arcDx = brInterX - tlInterX;
 				double arcDy = tlInterY - brInterY;
 				double arcAngle = 2 * asin(sqrt(arcDx*arcDx + arcDy*arcDy) / 2 / innerR);
 				unitArea += (tlInterX - lOffset) * (tOffset - brInterY);
 				unitArea += (tlInterX - lOffset) * (brInterY - bOffset);
 				unitArea += (rOffset - tlInterX) * (brInterY - bOffset);
 				unitArea += arcDx*arcDy/2;
 				unitArea += innerRSquare/2*(arcAngle - sin(arcAngle));
 			}
 			
 			emptyArea += unitArea;
 		}
 	}
 		
 	double ringFactor = (innerR > 0) ? innerR/R : 0;
 	double pRing = 1. - ringFactor*ringFactor;
 	double pNet = 1 - 4. * emptyArea / M_PI / innerRSquare;
 	
 	return pRing + pNet - pRing * pNet;
 }
 
 
 int main (int argc, const char * argv[]) {
 	int entryCount = 0;
 	int entryIdx;
 	
 	if(fscanf(stdin, "%i", &entryCount) != 1) {
 		fprintf(stderr, "Error: Could not scan entry count\n");
 		exit(1);
 	}
 	
 	for(entryIdx=1; entryIdx<=entryCount; entryIdx++) {
 		double f, innerR, t, r, g, p;
 		if(fscanf(stdin, " %lf %lf %lf %lf %lf \n", &f, &innerR, &t, &r, &g) != 5) {
 			fprintf(stderr, "Error: Could not scan all parameters for entry: %d\n", entryIdx);
 			exit(1);
 		}
 		p = swatterHitProbability(f, innerR, t, r, g);
 		printf("Case #%d: %.6lf\n", entryIdx, p);
 	}
 	while (!feof(stdin));
 }

