#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define MAX_SEARCH_ENGINES  128
 #define MAX_NAME_SIZE       128
 #define MAX_QUERIES        1024
 
 static int S, Q;
 static char search_engines[MAX_SEARCH_ENGINES][MAX_NAME_SIZE];
 static int queries[MAX_QUERIES];
 
 
 int cmp_names (const void *ptr1, const void *ptr2)
 {
   char *name1 = (char *) ptr1;
   char *name2 = (char *) ptr2;
   return strcmp (name1, name2);
 }
 
 static int  solution[MAX_SEARCH_ENGINES];
 
 int solve (void)
 {
   int i, j;
   int oldmin, min;
   for (i = 0; i < S; i++) {
     if (queries[0] != i) solution[i] = 0;
     else solution[i] = -1;
   }
   min = 0;
   for (j = 1; j <= Q; j++) {
     oldmin = min;
     min = oldmin + 1;
     for (i = 0; i < S; i++) {
       if (queries[j] == i) solution[i] = -1;
       else {
         if (solution[i] == -1)
           solution[i] = oldmin + 1;
         else {
           if (solution[i] == oldmin) {
             min = oldmin;
           }
         }
       }
     }
   }
   return min;
 }
 
 int main (int argc, char **argv)
 {
   int t, N;
   char buf[MAX_NAME_SIZE];
   scanf (" %d ", &N);
   for (t = 1; t<= N; t++) {
     int i, j, k;
     scanf (" %d ", &S);
     for (i = 0; i < S; i++) {
       fgets (search_engines[i], MAX_NAME_SIZE, stdin);
     }
     qsort (search_engines, S, MAX_NAME_SIZE, &cmp_names);
 
     scanf (" %d ", &Q);
     for (i = 0; i < Q; i++) {
       fgets (buf, MAX_NAME_SIZE, stdin);
        
       for (k = j = 0; buf[k] != '\0'; ) {
         if (buf[k] == search_engines[j][k]) k++;
         else j++;
       }
       queries[i] = j;
     }
     queries[Q] = -1;
      
     printf ("Case #%d: %d\n", t, solve ());
   }
   return 0;
 }

