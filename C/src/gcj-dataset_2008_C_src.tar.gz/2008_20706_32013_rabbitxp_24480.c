#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 main(int argc, char **argv){
 	int N,S,Q,n,s,q;
 	char Sname[100][256];
 	char line[256];
 	int Query[1000];
 	int Stable[100];
 	int M,sw;
 	FILE *in,*out;
 	in=fopen(argv[1],"r");
 	out=fopen(argv[2],"w");
 	fscanf(in,"%d",&N);
 	for(n=0;n<N;n++){
 		fscanf(in,"%d",&S);
 		fgets(line,255,in);
 		for(s=0;s<S;s++) fgets(Sname[s],255,in);
 		fscanf(in,"%d",&Q);
 		fgets(line,255,in);
 		for(q=0;q<Q;q++){
 			fgets(line,255,in);
 			for(s=0;s<S;s++){
 				if(!strcmp(Sname[s],line)){
 					Query[q]=s;
 					break;
 				}
 			}
 		}
 		q=0;
 		sw=-1;
 		while(q<Q){//??
 			M=S;	//??
 			for(s=0;s<S;s++) Stable[s]=1;
 			while(M && q<Q){
 				if(Stable[Query[q]]){
 					M--;
 					Stable[Query[q]]=0;
 				}
 				if(M) q++;
 			}
 			sw++;
 		}
 		if(sw==-1) sw=0;
 		fprintf(out,"Case #%d: %d\n",n+1,sw);
 	}
 }

