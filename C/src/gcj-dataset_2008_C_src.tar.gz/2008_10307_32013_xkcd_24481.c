#include<stdio.h>
 #include<stdlib.h>
 #include"train.h"
 
 int main(){
 
   int ncases;
   int tTime;
   int AtoB;
   int BtoA;
   int i,k;
   scanf("%d",&ncases);
   for(i=0;i<ncases;i++){
     scanf("%d %d %d",&tTime,&AtoB,&BtoA);
     int numA=0,numB=0;
 
     Train **allTrains = (Train **)malloc((AtoB+BtoA)*sizeof(Train*));
     for(k=0;k<AtoB;k++){
       int hourD,minuteD,hourA,minuteA;
       Train *temp=(Train*)malloc(sizeof(Train));
       scanf("%d:%d %d:%d",&hourD,&minuteD,&hourA, &minuteA);
       temp->departTime = 60*hourD+minuteD;
       temp->arriveTime = 60*hourA+minuteA;
       temp->accountedFor=FALSE;
       temp->Atrain =TRUE;
       
       allTrains[k]=temp;
     }
     for(k=AtoB;k<BtoA+AtoB;k++){
       int hourD,minuteD,hourA,minuteA;
       Train *temp=(Train*)malloc(sizeof(Train));
       scanf("%d:%d %d:%d",&hourD,&minuteD,&hourA, &minuteA);
       temp->departTime = 60*hourD+minuteD;
       temp->arriveTime = 60*hourA+minuteA;
       temp->accountedFor=FALSE;
       temp->Atrain=FALSE;
       allTrains[k]=temp;
     }
     while(!AllAccountedFor(allTrains,AtoB,BtoA)){
       Train *tempMin = FindOverallMin(allTrains, AtoB,BtoA);
       
       if(tempMin->Atrain==TRUE)
 	numA++;
       else
 	numB++;
       
       while(GetNextTrain(allTrains,&tempMin,AtoB,BtoA,tTime)==1);
       
     } 
     printf("Case #%d: %d %d\n",i+1,numA,numB);
   }
   return 0;
 }
   
   
 int GetNextTrain(Train **allTrains,Train **prevMin,int AtoB, int BtoA,int timeWait){
   int i;
   Train *tempMin = *prevMin;
 
   for(i=0;i<AtoB+BtoA;i++){
     if((*prevMin)->Atrain!=allTrains[i]->Atrain && allTrains[i]->accountedFor==FALSE){
       if(tempMin==*prevMin){
 	if(tempMin->arriveTime+timeWait<=allTrains[i]->departTime)
 	  tempMin = allTrains[i];
       }
       else{
 	if(allTrains[i]->departTime>=((*prevMin)->arriveTime+timeWait)){
 	  if(allTrains[i]->departTime<tempMin->departTime)
 	    tempMin=allTrains[i];
 	  else if(allTrains[i]->departTime==tempMin->departTime){
 	    if(allTrains[i]->arriveTime<tempMin->arriveTime)
 	      tempMin=allTrains[i];
 	  }
 	}
       }
     }
   }
   
   if(tempMin!=*prevMin){
     tempMin->accountedFor=TRUE;
     *prevMin=tempMin;
     return 1;
   }
   else
     return -1;
 }
 
 Train *FindOverallMin(Train **allTrains, int AtoB, int BtoA){
   int k;
   int minTime;
   minTime = 23*60 + 59;
   Train *minTrain = allTrains[0];
 
   for (k=0;k<AtoB+BtoA;k++){
     if(allTrains[k]->departTime<minTime && allTrains[k]->accountedFor==FALSE){
       minTime = allTrains[k]->departTime;
       minTrain = allTrains[k];
     }
     else if(allTrains[k]->departTime==minTime && allTrains[k]->arriveTime<minTrain->arriveTime && allTrains[k]->accountedFor==FALSE){
       minTrain=allTrains[k];
     }
   }
   
   minTrain->accountedFor=TRUE;
   return minTrain;
 }
   
 BOOLEAN AllAccountedFor(Train ** allTrains,int AtoB,int BtoA){
   int k;
   for(k=0;k<AtoB+BtoA;k++)
     if(allTrains[k]->accountedFor==FALSE)
       return FALSE;
   
   return TRUE;
 }
 

