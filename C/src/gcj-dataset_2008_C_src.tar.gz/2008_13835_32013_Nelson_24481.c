#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct {
 	int a,b;
 } Tschedule;
 
 int A[1500], B[1500];
 int nA, nB;
 
 Tschedule NA[105], NB[105];
 int sizeA, sizeB;
 int t,tk;
 int TR;
 int a,b,c,d;
 
 int comp(const void *a, const void *b){
 	Tschedule *m, *n;
 	m = (Tschedule*)a;
 	n = (Tschedule*)b;
 	
 	if(m->a < n->a)return -1;
 	else if(m->a > n->a)return 1;
 	else if(m->b <= n->b)return -1;
 	else return 1;
 }
 
 void simulate(void){
 	int i,j;
 	int x=0,y=0;
 	
 	nA = 0; nB=0;
 	
 	for(i= ((NA[0].a<NB[0].a)?(NA[0].a):(NB[0].a)) ; i<=1440; i++){
 		while(NA[x].a==i && x<sizeA){
 			if(A[i]==0){ A[i]=1; nA++; }
 			A[i]--; B[NA[x].b + TR]++;
 			x++;
 		}
 		
 		while(NB[y].a==i && y<sizeB){
 			if(B[i]==0){ B[i]=1; nB++; }
 			B[i]--; A[NB[y].b + TR]++;
 			y++;
 		}
 		
 		A[i+1] += A[i];
 		B[i+1] += B[i];
 		
 		if(x==sizeA && y==sizeB)break;
 	}
 }
 
 int main(){
 	int	i;
 	
 	scanf("%d",&tk);
 	for(t=1;t<=tk;t++){
 		scanf("%d",&TR);
 		scanf("%d %d",&sizeA, &sizeB);
 		for(i=0;i<sizeA;i++){
 			scanf("%d:%d %d:%d",&a,&b,&c,&d);
 			NA[i].a = (a*60) + b;
 			NA[i].b = (c*60) + d;
 		}
 		for(i=0;i<sizeB;i++){
 			scanf("%d:%d %d:%d",&a,&b,&c,&d);
 			NB[i].a = (a*60) + b;
 			NB[i].b = (c*60) + d;
 		}
 		for(i=0;i<=1440;i++){ A[i]=0; B[i]=0; }
 		qsort(NA, sizeA, sizeof(Tschedule), comp);
 		qsort(NB, sizeB, sizeof(Tschedule), comp);
 		simulate();
 		
 		printf("Case #%d: %d %d\n",t, nA, nB);
 	}
 
 	return 0;
 }
