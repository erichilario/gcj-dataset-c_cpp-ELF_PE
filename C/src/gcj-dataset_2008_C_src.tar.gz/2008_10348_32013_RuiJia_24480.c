#include <stdio.h>
 #include <string.h> 
 
 #define MAX_LINE 260 
 
 
 int main()
 {
     int caseCount=0;
     int engineCount=0;
     int queryCount=0; 
     int ci,j,k,p; 
     int* queryNameCode;    
     int* flag; int x,tempMint,currentX,currentY; 
     int* resultTemp;
     char line[MAX_LINE]; 
     FILE* fp;FILE* fout;
     char* engineName;
     
     fp = fopen("input.in","r");
     fout = fopen("output.out","w");
     fgets(line,MAX_LINE,fp);
     caseCount = atoi(line); 
     //printf("caseCount %d",caseCount); 
     for(ci=0;ci<caseCount;ci++)
     {
         fgets(line,MAX_LINE,fp);                       
         engineCount=atoi(line);//get engine count
         engineName = (char*)malloc(sizeof(char)*engineCount*MAX_LINE);
         for(j=0;j<engineCount;j++) //handle engine name
         {
             fgets(line,MAX_LINE,fp);
             strcpy(engineName+j*MAX_LINE,line); 
             //printf("  %s",engineName+j*MAX_LINE);
         }
         fgets(line,MAX_LINE,fp);
         queryCount=atoi(line);//get query count
         //  printf("queryCount %d\n",queryCount);
         
         if(queryCount<engineCount||engineCount==1||queryCount==0)
         {
             //printf("case #%d : %d\n",ci+1,0);
             sprintf(line,"Case #%d: %d\n",ci+1,0);
             fputs(line,fout);
             continue;
         }
         if(queryCount!=0)
             queryNameCode =(int*)malloc(sizeof(int)*queryCount);
         for(j=0;j<queryCount;j++)
         {
             fgets(line,MAX_LINE,fp); 
            // printf("l    %s",line);
             for(x =0;x<engineCount;x++)
             {
                 if(strcmp(line,engineName+x*MAX_LINE)==0)
                     queryNameCode[j] = x;    
             }
                                
         }
         //record query name 
          
         //for(j=0;j<queryCount;j++)
            // printf("queryNumber %d\n",queryNameCode[j]);
             
         if(queryCount!=0)
             resultTemp = (int*)malloc(sizeof(int)*queryCount*queryCount);
         for(j=0;j<queryCount*queryCount;j++)
             resultTemp[j]=0;
         
             
         flag = (int*)malloc(sizeof(int)*engineCount);
         for(j=0;j<engineCount;j++) flag[j]=0;
          
         for(j=engineCount-1;j<queryCount;j++){
              currentX=0;currentY=j;
              for(;currentX<queryCount&&currentY<queryCount;currentX++,currentY++)
              {
                  for(k=0;k<engineCount;k++) flag[k]=0;                                                                 
                  for(k=currentX;k<=currentY;k++) flag[queryNameCode[k]] = 1;
                  for(k=0;k<engineCount;k++){if(flag[k]==0) break;} 
                  if(k==engineCount)
                  {
                     //printf("currentX %d\n",currentX);
                     //printf("currentY %d\n",currentY);
                     tempMint = resultTemp[currentX*queryCount+currentX]+resultTemp[currentX*queryCount+queryCount+currentY]+1;
                     //printf("first min %d\n",tempMint);
                     for(p=currentX+1;p<currentY;p++)
                     {
                        if(resultTemp[currentX*queryCount+p]+resultTemp[p*queryCount+queryCount+currentY]+1 < tempMint)
                        {
                            tempMint = resultTemp[currentX*queryCount+p]+resultTemp[p*queryCount+queryCount+currentY]+1 ;
                            //if(j==queryCount-1) printf("position %d\n",p);
                        }
                     } 
                     resultTemp[currentX*queryCount+currentY] = tempMint;
                  } 
                  
                  else resultTemp[currentX*queryCount+currentY]=0; 
              }
         } 
         //printf("case #%d : %d\n",ci+1,resultTemp[queryCount-1]);
         sprintf(line,"Case #%d: %d\n",ci+1,resultTemp[queryCount-1]);
         fputs(line,fout);
         free(queryNameCode);
         free(flag);
         free(resultTemp);
         free(engineName);
     } 
     fclose(fp);
     fclose(fout);
     //getchar();
     return 0; 
      
 } 

