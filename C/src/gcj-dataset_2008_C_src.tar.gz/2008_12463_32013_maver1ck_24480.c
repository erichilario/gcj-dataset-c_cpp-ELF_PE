#include <stdio.h>
 #include <stdlib.h>
 
 struct input
 {
     int ncases;
     int nsearch_engines;
     char search_engines[100][101];
     int se_occ[100];
     int se_dis[100];
     int nqueries;
     char queries[1000][101];
 }inp;
     
 #define SE_LEN 101    
 
 
 int get_se_index(char *str)
 {
     int loop = 0;
     for (loop =0; loop < inp.nsearch_engines;loop++)
     {
         if(!strcmp(str,inp.search_engines[loop]))
 		return loop;
     }
     return -1;
 }
 
 char * read_input(FILE *fptr)
 {
     int se_cnt = 0, q_cnt = 0;
     char *tmp_sptr = NULL,  /* Temp string ptr - Used to populate the search engines & querry array */ 
 	 ch;
     fscanf(fptr,"%d\n",&inp.nsearch_engines);
 #ifdef __DEBUG__
     printf("No of search Engines = %d\n",inp.nsearch_engines);
 #endif //__DEBUG__
 //    search_engines = (char *) malloc(inp.nsearch_engines*SE_LEN);   
     
     while(se_cnt < inp.nsearch_engines)
     {
 	 tmp_sptr = inp.search_engines[se_cnt];
          while((ch = fgetc(fptr)) != '\n' && ch != EOF)
          {
             *tmp_sptr = ch;
             tmp_sptr++;
 	 }
 	 if(ch == EOF)
 	 {
 		 printf("Incomplete Input File\n");
 		 exit(0);
 	 }
          *tmp_sptr = '\0';
 /* Initialize distance and occurance to 0 */
         inp.se_occ[se_cnt] = 0;
         inp.se_dis[se_cnt] = 0;
         se_cnt++; 
     }
 #ifdef __DEBUG__
 
     for(se_cnt = 0 ; se_cnt < inp.nsearch_engines; se_cnt++)
     {
         printf("%s\n",inp.search_engines[se_cnt]);
     }    
 
 #endif //__DEBUG__    
     
     fscanf(fptr,"%d\n",&inp.nqueries);
 #ifdef __DEBUG__
     printf("No of queries = %d\n",inp.nqueries);
 #endif //__DEBUG__
 
 
     while(q_cnt < inp.nqueries)
     {
         tmp_sptr = inp.queries[q_cnt];
 	while((ch = fgetc(fptr)) != '\n' && ch != EOF)
 	{
 		*tmp_sptr = ch;
 		tmp_sptr++;
 	}
 	if(ch == EOF)
         {
 	    printf("Incomplete Input File\n");
 	    exit(0);
         }
 	*tmp_sptr = '\0';
         q_cnt++;
     }
 
 
 #ifdef __DEBUG__
 
     for(q_cnt = 0 ; q_cnt < inp.nqueries ;q_cnt++)
     {
         printf("%s\n",inp.queries[q_cnt]);
     }
 
 #endif //__DEBUG__    
 
 
    return;
 } 
 
 
 void process_input(int case_cnt)
 {
     int index = -1, q_cnt =0, tmp_cnt = 0;
     int sel_se_num = 0;
     int switches=0;
 
 
 /* Calculate the occurance and distance for each SE in the queries */
     for(q_cnt = 0; q_cnt < inp.nqueries; q_cnt++)
     {
          if((index = get_se_index(inp.queries[q_cnt]) ) != -1)
          {
 	     inp.se_occ[index]++;
 	     if(inp.se_dis[index] == 0)
 		inp.se_dis[index] = q_cnt+1;                    
          }
     } 
 
 #ifdef __DEBUG__
     for(q_cnt = 0; q_cnt < inp.nsearch_engines; q_cnt++)
         printf("Occ = %d , Dist = %d\n", inp.se_occ[q_cnt],inp.se_dis[q_cnt]);
 #endif //__DEBUG__
 
 /* Select the first SE based on dist and occ */
     for(index =0; index < inp.nsearch_engines;index++)
     {
         if(inp.se_occ[index] == 0) 
         {
             sel_se_num = index;
             break;
         }
         if(inp.se_dis[index] > inp.se_dis[sel_se_num])
 	    sel_se_num = index;
     }
 
 #ifdef __DEBUG__
 printf("Select SE = %s\n",inp.search_engines[sel_se_num]);
 #endif
 
 /* Process individual queries & switch if same SE is hit */
     for(q_cnt = 0; q_cnt < inp.nqueries; q_cnt++)
     {
 	if(!(strcmp(inp.queries[q_cnt],inp.search_engines[sel_se_num])))
         {
 	/* Hit the same search Engine - Switch */
 	    switches++;
 	/* update the distaces */
             for(tmp_cnt = 0 ;tmp_cnt < inp.nsearch_engines; tmp_cnt++)
             {
                 inp.se_dis[tmp_cnt] = 0;
             }
             for(tmp_cnt = q_cnt; tmp_cnt < inp.nqueries; tmp_cnt++)
 	    {
 		    if((index = get_se_index(inp.queries[tmp_cnt]) ) != -1)
 		    {
 			    if(inp.se_dis[index] == 0)
 				    inp.se_dis[index] = tmp_cnt+1;                    
 		    }
             }
 
 #ifdef __DEBUG__
 	    for(tmp_cnt = 0; tmp_cnt < inp.nsearch_engines; tmp_cnt++)
 		    printf(" Occ = %d , Dist = %d\n", inp.se_occ[tmp_cnt],inp.se_dis[tmp_cnt]);
 #endif //__DEBUG__
  
 /*Select the next Search engine based on occurance and distance */
 	    sel_se_num = 0;
 	    for(index =0; index < inp.nsearch_engines;index++)
 	    {
 		    if(inp.se_occ[index] == 0)
 		    {
 			    sel_se_num = index;
 			    break;
 		    }
 		    if(inp.se_dis[index] > inp.se_dis[sel_se_num])
 			    sel_se_num = index;
 	    }
 
 #ifdef __DEBUG__
 	printf("Switch : Processing query = %s, Select SE = %s\n",inp.queries[q_cnt],inp.search_engines[sel_se_num]);
 #endif
 
         }
 	/* End of Switching logic */
 
         inp.se_occ[get_se_index(inp.queries[q_cnt])]--;
         
     }        
 
 /* Done with processing the queries print the output*/
     printf("Case #%d: %d\n",case_cnt,switches);
     return;
 }
   
 
 
 int main(int argc, char *argv[])
 {
 
     FILE *ifptr = NULL;
     int case_cnt = 0;
 
     if(argc < 2)
     {
         printf (" Please enter the input file name\n Usage ./sav_univ <input_file>\n");
         exit(0);
     }
 /* Open the input file */
     if((ifptr = fopen(argv[1],"r")) == NULL)
     {
         perror("Input file not found\n");
         exit(0);
     }
 
 /* Read the num of cases */
     fscanf(ifptr,"%d\n",&inp.ncases);
     
 #ifdef __DEBUG__
     printf("No of cases = %d\n",inp.ncases);
 #endif /* __DEBUG__ */
 
     while(case_cnt++ < inp.ncases)
     {
          read_input(ifptr);
          process_input(case_cnt);
 /*         write_output(case_cnt);
   */
     }
  
     fclose(ifptr);
     
     return 0;
 }

