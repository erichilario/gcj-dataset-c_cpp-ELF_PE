/* Give the filename as parameter */
 #include <stdio.h>
 #include <string.h>
 int N,noe,i,t,nq,op;
 int sw,z;
 char S[1100][200];
 char line[200];
 char Q[1100][200];
 FILE *fp;
 
 void main(int argc, char *argv[])
 {
 int c;
 fp=fopen(argv[1],"r");
 fgets(line, sizeof(line), fp );
 N=atoi(line);
 for(c=0;c<N;c++)
 {
 fun();
 fun9();
 printf("Case #%d: %d\n",c+1,op);
 }
 
 fclose(fp);
 }
 
 fun()
 {
 fgets(line, sizeof(line), fp );
 noe=atoi(line);
 
 for (i=0;i<noe;i++)
 {
 fgets(line, sizeof(line), fp );
 strcpy(S[i],line);
 }
 
 fgets(line, sizeof(line), fp );
 nq=atoi(line);
 printf("\n");
 for (i=0;i<nq;i++)
 {
 fgets(line, sizeof(line), fp );
 strcpy(Q[i],line);
 }
 }
 
 int fun9()
 {
 int index;
 int h=0;
 char *eng;
 op=0;
 if (nq==0)  return;
 index=swit(0);
 strcpy(eng, S[index]);
 for (h=0;h<nq;h++)
 {
         if (strcmp(Q[h],eng) == 0)
         {
         index=swit(h);
         strcpy(eng,S[index]);
         op++;
         }
 }
 
 }
 
 int swit(int h)
 {
 int count[1000];
 int ret;int u,y;
 for(y=0;y<1000;y++)
 count[y]=1000;
         for (y=0;y<noe;y++)
         {
                 for (u=h;u<nq;u++)
                 {
                 if(strcmp(Q[u],S[y])==0)
                 {
                         count[y]=u-h+1;
                         break;
                 }
                 }
         }
 
 ret= count[0];
 /* for (u=0;u<noe;u++)
 printf(" %d ",count[u]); */
 
 for (u=0; u<noe; u++)
 if (count[u]>ret)
 ret = count[u];
 
 for (u=0;u<noe;u++)
 if (count[u]==ret)
 {
 ret=u;
 break;
 }
 /*printf("%s ",S[ret]);*/
 return ret;
 }
 

