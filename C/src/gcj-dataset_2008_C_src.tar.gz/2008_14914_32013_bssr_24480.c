#include<stdlib.h>
 #include<string.h>
 int getInd(char SE[][102], char *E, int len)
 {
    int i;
    for(i=0;i<len;i++)
    {
      if(strcmp(SE[i],E)==0)
        return i;
    }
    return 0;
 }
 main()
 {
   int N,S,Q,i,j,inp[1001];
   int cnt=0,swt=0;
   char se[101][102],str[102],arr[101]={0};
   scanf("%d",&N);
   for(i=0;i<N;i++)
   {
     scanf("%d",&S);
     //printf("S=%d:\n",S);
     for(j=0;j<S;j++)
     {
       getchar();
       scanf("%[A-Za-z0-9 ]",se[j]);
     //printf("%s:\n",se[j]);
     }
     scanf("%d",&Q);
     //printf("Q=%d:\n",Q);
     for(j=0;j<Q;j++)
     {
       getchar();
       scanf("%[A-Za-z0-9 ]",str);
     //printf("%s:\n",str);
       inp[j] = getInd(se,str,S);
     }
     cnt=0,swt=0;
     memset(arr,0,S+1);
     for(j=0;j<Q;j++)
     {
       if(arr[inp[j]] == 0)
       {
         cnt++;
         if(cnt == S)
         {
           swt++;
           memset(arr,0,S+1);
           cnt = 1;
         }
         arr[inp[j]] = 1;
       }
     }
     printf("Case #%d: %d\n",i+1,swt);
   }
   return 0;
 }

