#include <stdio.h>
 #include <string.h>
 int main() {
     int i, j, k, l, Q, S, N, used_engine[20] = {0}, used_count = 0, ans = 0, len;
     char engine[100][110], query[1000][110];
     scanf("%d", &N);
     for(i = 1; i <= N; i++) {
 	ans = 0;
 	used_count = 0;
 	for(j = 0; j < 20; j++) {
 	    used_engine[j] = 0;
 	}
 	scanf("%d%*c", &S);
 	for(j = 0; j < S; j++) {
 	    fgets(engine[j], 110, stdin);
 	    len = strlen(engine[j]);
 	    engine[j][len - 1] = '\0';
 	}
 	scanf("%d%*c", &Q);
 	for(j = 0; j < Q; j++) {
 	    fgets(query[j], 110, stdin);
 	    len = strlen(query[j]);
 	    query[j][len - 1] = '\0';
 	}
 	for(j = 0; j < Q; j++) {
 	    for(k = 0; k < S; k++) {
 		if (strcmp(query[j], engine[k]) == 0 && used_engine[k] == 0) {
 		    if (used_count == S - 1) {
 			ans++;
 			used_count = 0;
 			for(l = 0; l < 20; l++) {
 			    used_engine[l] = 0;
 			}
 		    }
 		    used_engine[k] = 1;
 		    used_count++;
 		} else if (strcmp(query[j], engine[k]) == 0 && used_engine[k] == 1) {
 		    continue;
 		}
 	    }
 	}
 	printf("Case #%d: %d\n", i, ans);
     }
     return 0;
 }

