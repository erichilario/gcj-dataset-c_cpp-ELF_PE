#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 
 typedef struct _Station
 {
   struct _Station * Next;
   int AvailTime;
 } TStation;
 
 typedef struct _ListTrain
 {
   struct _ListTrain * Next;
   int Salida;
   int Llegada;
   int Station;
 } TListTrain;
  
 
 TListTrain * ListTrain = NULL;
 TStation * StationA = NULL;
 TStation * StationB = NULL;
 
 
 void AddExit(int Salida, int Llegada, int Station)
 {
   TListTrain * ptr, * ptrtmp;
   ptr = calloc(1, sizeof(TListTrain));
   if (ptr != NULL)
   {
     ptr->Llegada = Llegada;
     ptr->Salida = Salida;
     ptr->Station = Station;
     if (ListTrain == NULL)
     {
       ListTrain = ptr;
     }
     else
     {
       if (Salida < ListTrain->Salida)
       {
         ptr->Next = ListTrain;
         ListTrain = ptr;
       }
       else
       {
         ptrtmp = ListTrain;
         while ((ptrtmp->Next != NULL) && (ptrtmp->Next->Salida < Salida))
         {
           ptrtmp = ptrtmp->Next;
         }
         ptr->Next = ptrtmp->Next;
         ptrtmp->Next = ptr;
       }
     }
   }
 }
 
 
 void AddTrain(TStation ** Station, int AvailTime)
 {
   TStation * ptr, * ptrtmp;
   ptr = calloc(1, sizeof(TStation));
   if (ptr != NULL)
   {
     ptr->AvailTime = AvailTime;
     if (*Station == NULL)
     {
       *Station = ptr;
     }
     else
     {
       if (AvailTime < (*Station)->AvailTime)
       {
         ptr->Next = *Station;
         *Station = ptr;
       }
       else
       {
         ptrtmp = *Station;
         while ((ptrtmp->Next != NULL) && (ptrtmp->Next->AvailTime < AvailTime))
         {
           ptrtmp = ptrtmp->Next;
         }
         ptr->Next = ptrtmp->Next;
         ptrtmp->Next = ptr;
       }
     }
   }
 }
 
 
 void main()
 {
   FILE * f;
   f = fopen("c:\\data\\B-small-attempt1.in", "r");
 //  f = fopen("c:\\data\\data2.txt", "r");
   if (f != NULL)
   {
     int N;
     int n;
     fscanf(f, "%d\n", &N);
     for (n=0; n<N; n++)
     {
       int T, NA, NB, i;
       int NTrainsA = 0, NTrainsB = 0;
       TListTrain * ptrtrain;
       fscanf(f, "%d\n", &T);
       fscanf(f, "%d %d\n", &NA, &NB);
       for (i=0; i<NA; i++)
       {
         int hour0, hour1, min0, min1;
         fscanf(f, "%02d:%02d %02d:%02d\n", &hour0, &min0, &hour1, &min1);
         AddExit(hour0*60+min0, hour1*60+min1, 'A');
       }
       for (i=0; i<NB; i++)
       {
         int hour0, hour1, min0, min1;
         fscanf(f, "%02d:%02d %02d:%02d\n", &hour0, &min0, &hour1, &min1);
         AddExit(hour0*60+min0, hour1*60+min1, 'B');
       }
       ptrtrain = ListTrain;
       while (ptrtrain != NULL)
       {
         ListTrain = ListTrain->Next;
         if (ptrtrain->Station == 'A')
         {
           AddTrain(&StationB, ptrtrain->Llegada + T);
           if (StationA == NULL)
           {
             NTrainsA++;
           }
           else
           {
             if (StationA->AvailTime > ptrtrain->Salida)
             {
               NTrainsA++;
             }
             else
             {
               if (StationA != NULL)
               {
                 TStation * ptr  = StationA;
                 StationA = StationA->Next;
                 free(ptr);
               }
             }
           }
         }
         else
         {
           AddTrain(&StationA, ptrtrain->Llegada + T);
           if (StationB == NULL)
           {
             NTrainsB++;
           }
           else
           {
             if (StationB->AvailTime > ptrtrain->Salida)
             {
               NTrainsB++;
             }
             else
             {
               if (StationB != NULL)
               {
                 TStation * ptr  = StationB;
                 StationB = StationB->Next;
                 free(ptr);
               }
             }
           }
         }
         free(ptrtrain);
         ptrtrain = ListTrain;
       }
       printf("Case #%d: %d %d\n", n+1, NTrainsA, NTrainsB);
       {
         TStation * ptr;
         while (StationA != NULL)
         {
           ptr = StationA;
           StationA = StationA->Next;
           free(ptr);
         }
         while (StationB != NULL)
         {
           ptr = StationB;
           StationB = StationB->Next;
           free(ptr);
         }
       }
     }
     fclose(f);
   }
 }
 
  
 
  
 
  
