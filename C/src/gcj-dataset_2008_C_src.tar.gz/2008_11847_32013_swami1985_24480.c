#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 int doCase(FILE* fin)
 {
 int S=0;
 	fscanf(fin,"%d\n",&S);
 	//printf("%d",S);
 	char eng[S][100];
 	char temp;
 	for(int i=0;i<S;i++) 
 	{
 		fgets(eng[i],100,fin);
 		//printf("%s",eng[i]);
 	}
 	
 	
 	
 	int Q;
 	
 	fscanf(fin,"%d\n",&Q);
 	printf("\n%d",Q);
 	char query[Q][100];
 	
 	for(int i=0;i<Q;i++) 
 	{
 		fgets(query[i],100,fin);
 		//printf("%s",query[i]);
 	}
 	
 	
 	
 	//all queries read
 	
 	
 	int flag[S];int curr=-1;
 	for(int i=0;i<S;i++) flag[i]=0;
 	int no_sw=0;
 	for(int i=0;i<Q;i++) //for each q
 	{
 	 // setFlag(query[i],eng,flag);//set flag corres to q[i]
 	  int cureng=-1;
 	  	for(int j=0;j<S;j++)
 	  	{
 	  		if(strcmp(eng[j],query[i])==0) 
 	  		{ flag[j]=1;cureng=j; break;}
 	  	}
 	  	
 	  	int cnt=0;
 	  	for(int j=0;j<S;j++)
 	  	{
 	  		if(flag[j]==0){curr=j; cnt++;}
 	  	}
 	  	if(cnt==0) //found pick
 	  	{
 	  	//check for each possible curr and choose one with max i.
 	  	//int i2max=0,curmax=0;
 	  	 //for(int k=0;k<S;k++)
 	  	 //{
 	  	 //if(flag[k]==0) {curr=k;
 		  //int i2=i;
 		  
 	  	 //while(i<Q && strcmp(query[i],eng[curr])!=0 ) {i++;}
 	  	
 	  	 //if(i2>i2max){ i2max=i2;curmax=curr;}
 	  	  
 	  	 //}
 	  	 //curr=curmax;
 	  	 //i=i2max;
 	  	 //if(i==Q) break;
 	  	 no_sw++;
 	  	 for(int j=0;j<S;j++) flag[j]=0;
 	  	 flag[cureng]=1;
 	  	//set flaG of deppest engine
 	  	
 	  	
 	  	
 	  	
 	  	
 	  	
 	  	}
 	  	
 	  	
 	  		 
 
 
 	  }
 	  
 	
 	
 	
 	
 	return no_sw;
 }
 	
 	
 
 
 int main()
 {
 FILE *fin,*fout;
 int N;
 fin=fopen("A-small-attempt8.in","rw");
 fout=fopen("output","w");
 fscanf(fin,"%d\n",&N);
 //printf("%d",N);
 for(int i=0;i<N;i++) fprintf(fout,"Case #%d: %d\n",i+1,doCase(fin));
 fclose(fin);
 fclose(fout);
 return 0;
 }

