#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 
 #define MAX_N 20
 #define MIN_N 0
 #define MAX_S 100
 #define MIN_S 2
 #define MAX_Q 0
 #define MIN_Q 1000
 #define MAX_LEN 1000
 #define MARKED 1
 #define UNMARKED 0
 #define EMPTY_BUFFER       while((c=fgetc(data_f))!='\n'&&c!=EOF)
 
 
 /* 
   Function that empties the board that has the engine-names 
   that have been queried 
 */
 void CleanBoard(int *marked, int se_num);
 int GetEngineID(char* engine, char engines[][MAX_LEN], int se_num);
 
 
 int main(int argc, char** argv)
 {
 	FILE* data_f;
 	FILE* output;
 	char c; /* used to clean buffer */
 	int se_num;
 	int cases;
 	int querie_num;
 	char se[MAX_S][MAX_LEN];
 	char querie[MAX_LEN];
 	int marked[MAX_S]; 
 	int counter=0;
 	int i, j, k; //counters
 	int engineID;
 	int switches;
 	
 
 	if(argc!=3){
 		fprintf(stdout, "%s input_file output_file\n", argv[0]);
 		return 0;
 	}
 	if((data_f=fopen(argv[1], "r"))==NULL){
 		fprintf(stdout, "Error opening file %s\n", argv[1]);
 		return 0;
 	}
 	if((output=fopen(argv[2], "w"))==NULL){
 		fprintf(stdout, "Error opening file %s\n", argv[2]);
 		return 0;
 	}
 
 	fscanf(data_f, "%d", &cases);
 
 	for(i=0; i<cases; i++){
 		switches=0;
 		if(i==12)
 			putchar('0');
 		fscanf(data_f, "%d", &se_num);
 		EMPTY_BUFFER;
 		for(j=0; j<se_num; j++){
 			fgets(se[j], MAX_LEN, data_f);
 			se[j][strlen(se[j])-1]=0; /* fgets leaves a '\n' at the end */
 		}
 		fscanf(data_f, "%d", &querie_num);
 		EMPTY_BUFFER;
 		CleanBoard(marked, se_num); 
 		counter=se_num;
 		for(k=0; k<querie_num; k++){
 			if(counter==0){
 				switches++;
 				counter=se_num-1; /* restart coutner of queried engines */
 				CleanBoard(marked, se_num);
 				marked[GetEngineID(querie, se, se_num)]=MARKED; /* The last one goes to the new engine */
 			}
 			//EMPTY_BUFFER;
 			fgets(querie, MAX_LEN, data_f);
 			querie[strlen(querie)-1]=0; /* fgets leaves a '\n' at the end */
 			engineID=GetEngineID(querie, se, se_num);
 			if(marked[engineID]!=MARKED){
 				counter--;
 				marked[engineID]=MARKED;
 			}
 
 		}
 		if(counter==0)
 			switches++;
 		fprintf(output, "Case #%d: %d\n", i+1, switches);
 	}
 	fclose(data_f);
 	fclose(output);
 	
 	return 0;
 }
 
 void 
 CleanBoard(int *marked, int se_num)
 {
 	int i;
 	for(i=0; i<se_num; i++)
 		marked[i]=UNMARKED;
 	return;
 }
 
 int 
 GetEngineID(char* engine, char engines[][MAX_LEN], int se_num)
 {
 	int id=-1;
 	int i;
 	for(i=0; id==-1 && i<se_num; i++){
 		if(strcmp(engine, engines[i])==0)
 			id=i;
 	}
 	return id;
 }
 

