#include <stdio.h>
 struct engine{
     int rank;
     char name[200];
 };
 typedef struct engine engline;
 struct query{
     char name[200];
 };
 typedef struct query query;
 void init_eng(engline *Ename, int E){
     int i;
     for(i = 0 ; i < E ; i++)
 	Ename[i].rank = 99999;
 }
 
 int self_search(query Qone, engline *Ename, int E){
     int i = -1;
     for(i = 0 ; i < E ; i++)
 	if( strcmp(Qone.name, Ename[i].name) == 0)
 	    return i;
 }
 
 
 int count(engline *Ename, query *Qname, int E, int Q){
     int loc_ptr = 0;
     int ANS = 0;
     int i, j, val;
     int laster;
     while(loc_ptr < Q){
 	init_eng(Ename, E);
 	for( i = loc_ptr ; i < Q ; i++){
 	    val = self_search(Qname[i], Ename, E);
 	    if(val >= 0)
 		if(Ename[val].rank == 99999)
 		    Ename[val].rank = i;
 	}
 //	for(i = 0 ; i < E ; i++ )
 //	    printf("=== %s %d === \n", Ename[i].name, Ename[i].rank);	
 	for( j = 0, laster = 0 ; j < E ; j++){
 	    if(Ename[j].rank > Ename[laster].rank)
 		laster = j;
 	}
 	if(Ename[laster].rank <= Q)
 	    ANS++;
 	loc_ptr = Ename[laster].rank;
     }
     return ANS;
 }
 
 int main(void){
     int N, E, Q;
     engline Ename[100];
     query Qname[1005];
     int i, j;
 
     scanf("%d\n", &N);
     for(i = 0 ; i < N ; i++){
 	printf("Case #%d: ", i+1);
 	scanf("%d\n", &E);
 
 //	printf("%d\n", E);
 	for(j = 0  ; j < E ; j++){
 	    fgets(Ename[j].name, 200, stdin);
 //	    printf("%s", Ename[j].name);
 	}
 	scanf("%d\n", &Q);
 	for(j = 0 ;  j < Q ; j++){
 	    fgets(Qname[j].name, 200, stdin);
 //	    printf("%s", Qname[j].name);
 	}
 //	printf("a.........\n");
 	printf("%d\n", count(Ename, Qname, E, Q));
     }
     
 
 
 
     return 0;
 }

