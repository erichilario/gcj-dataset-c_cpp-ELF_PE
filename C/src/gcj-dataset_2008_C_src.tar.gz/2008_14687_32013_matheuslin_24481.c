#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 void update(int *h, int *m, int t){
 	(*h) += ((*m) + t) / 60;
 	(*m) = ((*m) + t) % 60;
 }
 
 
 typedef struct{
 	char io; /*0 = ready to leave, 1 = leave*/
 	int h, m;
 }stamp;
 
 
 void sort(stamp A[203], int n){
 
 	int i, j;
 	stamp aux;
 	for(i = 1; i < n; i++){
 		if((A[i].h < A[i-1].h) || ((A[i].h == A[i-1].h) && (A[i].m <= A[i-1].m))) {
 			/*Exchange*/
 			j = i;
 			aux = A[i];
 			while((j > 0) && ((aux.h < A[j-1].h) || ((aux.h == A[j-1].h) && (aux.m < A[j-1].m)))) {
 				A[j] = A[j-1];
 				j--;
 			}
 			while((j > 0) && (aux.h == A[j-1].h) && (aux.m == A[j-1].m) && (aux.io < A[j-1].io)) {
 				A[j] = A[j-1];
 				j--;
 			}
 			A[j] = aux;
 		}
 	}
 }
 
 int analyze(stamp A[203], int k){
 	int n = 0, i, need = 0;
 
 	for(i = 0; i < k; i++){
 		if(A[i].io == 0){
 			n++;
 		}
 		else if(A[i].io == 1){
 			if(n > 0){
 				n--;
 			}
 			else{
 				need++;
 			}
 		}
 	}
 
 	return need;
 }
 
 
 int main(){
 	int t, na, nb, n, i, j, k, ta, tb;
 	stamp A[203], B[203];
 	char line[40];
 	FILE *in, *out;
 
 	printf("input file: ");
 	scanf("%s", line);
 	in = fopen(line, "r");
 	while(!in){
 		printf("Missing input file. Try again!\n");
 		printf("input file: ");
 		scanf("%s", line);
 		in = fopen(line, "r");
 	}
 
 	strcat(line, "_out");
 	out = fopen(line, "w");
 
 	fgets(line, 40, in);
 	sscanf(line, "%d", &n);
 	for(i = 1; i <= n; i++){
 		fgets(line, 40, in);
 		sscanf(line, "%d", &t);
 		fgets(line, 40, in);
 		sscanf(line, "%d %d", &na, &nb);
 		k = 0;
 
 		for(j = 0; j < na; j++){
 			fgets(line, 40, in);
 			sscanf(line, "%d:%d %d:%d", &A[k].h, &A[k].m, &B[k].h, &B[k].m);
 			update(&B[k].h, &B[k].m, t);
 			A[k].io = 1;
 			B[k].io = 0;
 			k++;
 		}
 
 		for(j = 0; j < nb; j++){
 			fgets(line, 40, in);
 			sscanf(line, "%d:%d %d:%d", &B[k].h, &B[k].m, &A[k].h, &A[k].m);
 			update(&A[k].h, &A[k].m, t);
 			B[k].io = 1;
 			A[k].io = 0;
 			k++;
 		}
 		sort(A, k);
 
 		sort(B, k);
 
 		ta = analyze(A, k);
 		tb = analyze(B, k);
 
 		fprintf(out, "Case #%d: %d %d\n", i, ta, tb);
 
 	}
 
 	fclose(in);
 	fclose(out);
 
 	return 0;
 }

