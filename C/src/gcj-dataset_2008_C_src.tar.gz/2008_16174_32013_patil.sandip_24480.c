#include<stdio.h>
 
 FILE *fp,*fpout;
 
 struct SearchEng
 {
 char Name[102];
 int checked;
 };
 
 struct SearchEng se[100];
 int s_count=0;
 
 int mark(char * str)
 {
 int i;
 
 for(i=0;i<s_count;i++)
 {
 	if(strcmp(se[i].Name,str)==0)
 	{
 	if(se[i].checked==1)
 	return -1;
 	else
 	se[i].checked=1;
 	return i;
 	}
 }
 return -1;
 }
 
 void clear_set_se(int index)
 {
 int i;
 for(i=0;i<s_count;i++)
 {
 	if(index==i)
 	se[i].checked=1;
 	else
 	se[i].checked=0;
 }
 }
 
 void main()
 {
 int N,i,crt_testcase,q_count;
 char str[102];
 int secount=0,se_index,max_se,cnt_checked,no_of_switch=0;
 
 clrscr();
 
 if ((fp = fopen("d:\\san\\codejam\\1\\input.txt", "rt"))
     == NULL)
 {
    fprintf(stderr, "Cannot open input file.\n");
    return;
 }
 
 if ((fpout = fopen("d:\\san\\codejam\\1\\output.txt", "wt"))
     == NULL)
 {
    fprintf(stderr, "Cannot open input file.\n");
    return;
 }
 
 fscanf(fp,"%d\n",&N);
 
 crt_testcase=0;
 while(crt_testcase++<N)
 {
 	fprintf(fpout,"Case #%d: ",crt_testcase);
 
 	fscanf(fp,"%d\n",&s_count);
 
 	for(i=0;i<s_count;i++)
 	{
 		se[secount].checked=0;
 		fgets(se[secount].Name,101,fp);
 		secount++;
 	}
 
 	fscanf(fp,"%d\n",&q_count);
 	for(i=0;i<q_count;i++)
 	{
 		fgets(str,101,fp);
 
 		if((se_index=mark(str))>=0)
 		{
 			max_se = se_index;
 			cnt_checked++;
 		}
 		else
 		{
 			continue;
 		}
 
 		if(cnt_checked == s_count)
 		{
 			no_of_switch++;
 			clear_set_se(max_se);
 			cnt_checked=1;
 		}
 	}
 
 	fprintf(fpout,"%d\n",no_of_switch);
 
 	secount=0;
 	no_of_switch=0;
 	cnt_checked=0;
 }
 }
