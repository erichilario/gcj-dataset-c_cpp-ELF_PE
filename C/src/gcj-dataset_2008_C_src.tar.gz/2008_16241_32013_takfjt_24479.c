#include <stdio.h>
 #include <math.h>
 
 #define N (1000000)
 
 #define STRINGS_LIMIT (1000)
 
 // cos to sin, sin to cos, what is good name?
 #define c2s(r, c) sqrt((r) * (r) - (c) * (c))
 #define s2c(r, s) sqrt((r) * (r) - (s) * (s))
 
 double
 integral(
         double begin, double end,
         double r,
         double hlim, double llim
         )
 {
     int i;
     double a, f;
     double h;
 
     double ans = 0.0;
 
     double prev;
     
     //printf("I:%lf %lf %lf %lf %lf\n", begin, end, r, hlim, llim);
     if (begin > end || begin > r) return 0.0;
     h = (end - begin) / (double)N;
     //h = 0.0001;
 
 #if 0
     a = begin;
     f = c2s(r, a);
     if (f > hlim) f = hlim;
     f -= llim;
     if (f < 0.0) f = 0.0;
     ans = f;
 
     for (i = 1; i < N; i++) {
         a = begin + h * i;
         if (a > end) break;
         if (a > r) break;
         f = c2s(r, a);
         if (f > hlim) f = hlim;
         f -= llim;
         if (f < 0.0) f = 0.0;
         
         if (i % 2) {
             ans += 4.0 * f;
         } else {
             ans += 2.0 * f;
         }
     }
     a = end;
     if (a < r) {
         f = c2s(r, a);
         if (f > hlim) f = hlim;
         f -= llim;
         if (f < 0.0) f = 0.0;
         ans += f;
     }
     ans *= h / 3.0;
 #else
     a = begin;
     f = c2s(r, a);
     if (f > hlim) f = hlim;
     f -= llim;
     if (f < 0.0) f = 0.0;
     prev = f;
 
     for (i = 1; i < N; i++) {
         //a = begin + h * i;
         a = begin + h * i;
         if (a > end) break;
         if (a + h > r) break;
         f = c2s(r, a);
         if (f > hlim) f = hlim;
         f -= llim;
         if (f < 0.0) f = 0.0;
         //printf("%lf\n", f);
         ans += (prev + f);
         prev = f;
     }
     ans /= 2.0;
     ans *= h;
 #endif
 
     //printf("INT:%lf\n", ans);
     //printf("%.20lf\n", M_PI);
     return ans;
 }
 
 double
 calc(double f, double R, double t, double r, double g)
 {
 #define ONE_BLOCK (2.0 * r + g)
     int i, j;
 
     double area;
 
     double hole = 0.0;
 
     double block_area;
 
     double I1, I2, J1, J2;
 
     double RI; // inner R
 
     RI = R - t - f;
     block_area = (g - 2.0 * f) * (g - 2.0 * f);
     //printf("BA:%lf\n", block_area);
 
     if (g - 2.0 * f <= 0.0) return 1.0;
     for (i = 0; i < STRINGS_LIMIT; i++) {
         I1 = (double)i * ONE_BLOCK + (r + f);
         I2 = (double)i * ONE_BLOCK + (r + f) + g - 2.0 * f;
         //printf("%lf %lf\n", I2 - I1, g - f - f);
         if (I1 > RI) break;
         for (j = 0; j < STRINGS_LIMIT; j++) {
             J1 = (double)j * ONE_BLOCK + (r + f);
             J2 = (double)j * ONE_BLOCK + (r + f) + g - 2.0 * f;
 
             if (J1 > s2c(RI, I1)) break;
 
             if (I2 < RI && J2 < s2c(RI, I2)) {
                 hole += block_area;
                 //printf("X:%lf %lf\n", integral(J1, J2, RI, I2, I1), block_area);
                 //printf("Qhole: %lf\n", hole);
             } else {
                 hole += integral(J1, J2, RI, I2, I1);
             }
         }
     }
 
     //printf("hole: %lf\n", hole);
     area = R * R * M_PI / 4.0;
     //printf("area: %lf\n", area);
     return 1.0 - hole / area;
 }
 
 
 int
 main()
 {
     int line, l;
     float f, R, t, r, g;
 
     double ret;
     scanf("%d", &line);
 
     for (l = 0; l < line; l++) {
         scanf("%f %f %f %f %f", &f, &R, &t, &r, &g);
         ret = calc((double)f, (double)R, (double)t, (double)r, (double)g);
         printf("Case #%d: %1.6lf\n", l + 1, ret);
     }
 
     return 0;
 }
 
 

