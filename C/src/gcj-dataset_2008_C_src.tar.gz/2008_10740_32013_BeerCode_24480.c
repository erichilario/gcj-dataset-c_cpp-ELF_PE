/*
  * Programmer : Kookiat Suetrong (kookiatsuetrong@gmail.com)
  * Compiler   : Visual C++ / ISO C++ / ANSI C
  * Date       : 2008/07/17
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 #include <ctype.h>
 
 #define MAX_S		(100)
 #define MAX_Q		(1000)
 #define MAX_STRING	(100)
 
 char s[MAX_S][MAX_STRING + 1];
 char q[MAX_Q][MAX_STRING + 1];
 int ns;
 int nq;
 
 void process()
 {
 	int i;
 	int j;
 	int curEngine = -1;
 	int can[MAX_Q][MAX_S];
 	int minSwitch = 0;
 
 	for (i = 0; i < nq; i++)
 	{
 		for (j = 0; j < ns; j++)
 		{
 			int cmp = strcmp(q[i], s[j]);
 			if (0 == cmp)
 			{
 				can[i][j] = 0;
 			}
 			else
 			{
 				can[i][j] = 1;
 			}
 		}
 	}
 
 /*
 printf("\n");
 for (i = 0; i < nq; i++)
 {
 	printf("%d\t", i);
 	for (j = 0; j < ns; j++)
 	{
 		printf("%d\t", can[i][j]);
 	}
 	printf("\n");
 }
 */
 	
 
 
 	i = 0;
 	while (i < nq)
 	{
 		int bestEngine = 0;
 		int score[MAX_S];
 		memset(score, 0, sizeof(int) * MAX_S);
 		
 		for (j = 0; j < ns; j++)
 		{
 			if (j != curEngine)
 			{
 				int k = 0;
 				while (i + k < nq &&
 					can[i + k][j])
 				{
 					k++;
 				}
 				score[j] = k;
 				if (score[bestEngine] < score[j])
 				{
 					bestEngine = j;
 				}
 			}
 		}
 
 		curEngine = bestEngine;
 
 		if (i + score[bestEngine] >= nq)
 		{
 //printf("Engine %d at %d score = %d\n", bestEngine, i, score[bestEngine]);
 			break;
 		}
 		else
 		{
 //printf("Engine %d at %d score = %d\n", bestEngine, i, score[bestEngine]);
 			i += score[bestEngine];
 			minSwitch++;
 		}
 	}
 
 //printf("\nMinSwitch = %d\n", minSwitch);
 	printf("%d\n", minSwitch);
 }
 
 //int main(void)
 int main(int argc, char ** argv)
 {
 	int n;
 	int i;
 	FILE *f = fopen(argv[1], "r");
 	if (!f)
 		return 0;
 
 	fscanf(f, "%d\n", &n);
 	for (i = 0; i < n; i++)
 	{
 		int j;
 
 		// read data for this case
 		fscanf(f, "%d\n", &ns);
 		for (j = 0; j < ns; j++)
 		{
 			fgets(s[j], MAX_STRING, f);
 		}
 
 		fscanf(f, "%d\n", &nq);
 		for (j = 0; j < nq; j++)
 		{
 			fgets(q[j], MAX_STRING, f);
 		}
 
 		// output the result of this case
 		printf("Case #%d: ", i + 1);
 
 		// solve the test case
 		process();
 	}
 
 	fclose(f);
 
 	return 0;
 }

