#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <ctype.h>
 #define MAXn 200
 #define MAXc 200
 
 int foi[MAXn];
 char nome[MAXn][MAXc];
 int n,m;
 
 int procura(char *s){
   int meio, esq,dir, cmp;
 
   esq=0; dir=n-1;
   while(esq<=dir){
     meio=(esq+dir)/2;
     cmp=strcmp(s,nome[meio]);
 
     if(cmp==0) return meio;
     if(cmp<0) dir=meio-1;
     else esq=meio+1;
   }
 
   return -1;
 }
 
 int verify(){
   int i;
 
   for(i=0 ; i<n ; i++)
     if(foi[i]==0) return 0;
 
   return 1;
 }
 
 int main(){
   int nt,nt0;
   int i,j,k, cont;
   char query[MAXc];
 
   scanf(" %d", &nt0);
   for(nt=1 ; nt<=nt0 ; nt++){
     cont=0;
 
     scanf(" %d%*c", &n);
     for(i=0 ; i<n ; i++){
       gets(nome[i]);
       foi[i]=0;
     }
 
     qsort(nome,n,MAXc*sizeof(char),strcmp);
 
     scanf(" %d%*c", &m);
     for(i=0 ; i<m ; i++){
       gets(query);
       k=procura(query);
 
       foi[k]=1;
       if(verify()){
 	for(j=0 ; j<n ; j++) foi[j]=0;
 	foi[k]=1;
 	cont++;
       }
 
     }
 
     printf("Case #%d: %d\n", nt, cont);
   }
 
   return 0;
 }

