#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 double a,b,c,d;
 
 double function(double x){
 	double xx,dd,v;
 	dd=sqrt(d*d-x*x);
 	v=0.0;
 	for(x=b;x<dd;x+=c){
 		xx=(x+a>dd)?dd-x:a;
 		v+=xx;
 	}
 	return v;
 }
 
 double simpson(double s,double e,double (*f)(double)){
 	double I2n,h,T2n,In,Tn;
 	int n,k;
 	double sigma;
 	I2n=0.0;
 	h=e-s;
 	T2n=0.5*h*(f(e)+f(s));
 	In=T2n;
 	for(n=1;(I2n-In)*(I2n-In)>1.0e-15;n*=2,h*=0.5){
 		In=I2n;
 		Tn=T2n;
 		sigma=0.0;
 		for(k=0;k<n;k++) sigma+=f(s+(k+0.5)*h);
 		T2n=0.5*(Tn+h*sigma);
 		I2n=(4.0*T2n-Tn)/3.0;
 	}
 	return I2n;
 }
 		
 main(int argc, char **argv){
 	double f,t,R,r,g;
 	int N,n;
 	double p,x,xx;
 	FILE *in,*out;
 	in=fopen(argv[1],"r");
 	out=fopen(argv[2],"w");
 	fscanf(in,"%d",&N);
 	for(n=0;n<N;n++){
 		fscanf(in,"%le %le %le %le %le",&f,&R,&t,&r,&g);
 		a=(g-2.0*f)/R;
 		b=(r+f)/R;
 		c=a+2.0*b;
 		d=(R-t-f)/R;
 		p=1.0;
 		if(a>0.0 && d>1.414*b ){
 			p=0.0;
 			for(x=b;x<d;x+=c){
 				xx=(x+a>d)?d:x+a;
 				p+=simpson(x,xx,function);
 			}
 			p=1.0-p/atan(1.0);
 		}
 		fprintf(out,"Case #%d: %9.6f\n",n+1,p);
 	}
 }

