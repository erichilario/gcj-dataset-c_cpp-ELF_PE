#include <stdio.h>
 #include <strings.h>
 
 int lastappearance(int query[], int numEngines, int numQueries) {
   int switches = 0;
 
   int checklist[numEngines];
   for (int i = 0; i < numEngines; i++) {
     if (checklist[i] != 0) 
       checklist[i]=0;
   }
  
     
   
   int checkdif = numEngines-1;
 
   for (int i = 0; i < numQueries; i++) {
 
     checklist[query[i]]++;
     if (checklist[query[i]] > 1)
       checkdif++;
     if (i >= checkdif) { //if we go past the number of search engines we have
       //for (int j = 0; j <= checkdif; j++) {
 	/*
 	  if (zeroIndexs(checklist, numEngines) != NULL) {//if there is an engine that hasn't been used
 	  
 	}
 	*/
 	//else { //if all engines are used, the last engine must have been the one
 	  //do process again from beginning:
 	  //reset checklist
 	  //  mark the last query
 	  //reset checkdif
 	  //increase switches
       //printf("in!\n");
       for (int k = 0; k < numEngines; k++)
 	checklist[k] = 0;
       
       checklist[query[i]] = 1;
       checkdif = i+numEngines-1;
       
       switches++;
       //if (switches == 1)
       //	printf("Started with %d\n", query[i]);
       //else
       //	printf("Switched to %d\n", query[i]);
       
 	  //}
     }
     //printf("ok!\n");
   }
 
   return switches;
 }
 
 //retrurns an array of all of the indexes that have 0s if 0s are found, null otherwise.
 //int* zeroIndexes() {
 
 
 
 int main() {
   FILE *fp;
   FILE *new;
   fp = fopen("A-small.in", "rt");
   new = fopen("test2.txt", "w");
 
   char line[100];
   
   int cases = atoi(fgets(line, 100, fp));
 
 
   for (int i = 1; i <= cases; i++) {
 
     int numEngines = atoi(fgets(line, 100, fp));
     char engines[numEngines][100];
 
     //names search engines
     for (int j = 0; j < numEngines; j++) {
       strcpy(engines[j], (fgets(line, 100, fp)));
     }
     
     int query = atoi(fgets(line, 100, fp));
 
     
     int numberedquery[query];
     //makes an array numberedquery where every name is switched with  numbers.
     for (int k = 0; k < query; k++) {
       fgets(line, 100, fp); //
 
       for (int l = 0; l < numEngines; l++) {
 	if (strcmp(line, engines[l]) == 0) {
 	  numberedquery[k] = l;
 
 	  break;
 	}
 
       }
     
     }
 
     
     fprintf(new, "Case #%d: %d\n", i, lastappearance(numberedquery, numEngines, query));
     
   }
 
   
   
   return 0;
 }

