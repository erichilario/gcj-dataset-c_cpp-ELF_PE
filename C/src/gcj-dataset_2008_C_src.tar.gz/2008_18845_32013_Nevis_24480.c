#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 char A[100][200];
 char Str[200];
 
 int B[1000];
 
 int Map[100][1000];
 
 int N,S,Q,I;
 
 int main()
 {
 	int i,j,k,m,min;
 	scanf("%d",&N);
 	for(i=1;i<=N;i++)
 	{
 		scanf("%d",&S);
 		gets(Str);
 		for(j=0;j<S;j++)
 			gets(A[j]);
 		scanf("%d",&Q);
 		gets(Str);
 		for(j=0;j<Q;j++)
 		{
 			gets(Str);
 			for(k=0;k<S;k++)
 			{
 				if(strcmp(Str,A[k])==0)
 				{
 					B[j]=k;
 					break;
 				}
 			}
 		}
 		for(j=0;j<Q;j++)
 		{
 			if(j==0)for(k=0;k<S;k++)
 			{
 				if(B[j]==k)Map[k][j]=1;
 				else Map[k][j]=0;
 			}
 			else for(k=0;k<S;k++)
 			{
 				if(B[j]==k)
 				{
 					min=-1;
 					for(m=0;m<S;m++)
 					{
 						if(m==k)continue;
 						if(Map[m][j-1]<min || min==-1)
 						{
 							min=Map[m][j-1];
 						}
 						Map[k][j]=min+1;
 					}
 				}
 				else Map[k][j]=Map[k][j-1];
 			}
 		}
 		/*for(j=0;j<S;j++)
 		{
 			for(k=0;k<Q;k++)
 				printf("%d",Map[j][k]);
 			printf("\n");
 		}*/
 		min=-1;
 		for(j=0;j<S;j++)
 		{
 			if(min==-1 || min>Map[j][Q-1])
 			{
 				min=Map[j][Q-1];
 			}
 		}
 		printf("Case #%d: %d\n",i,min);
 		
 	}
 	return 0;
 }

