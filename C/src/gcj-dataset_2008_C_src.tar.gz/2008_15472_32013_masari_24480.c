#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 /* typedef struct Ref ref;
 struct Ref{
 	int freq;
 	int index;
 }; */
 
 char * read();
 
 int main()
 {
 	int numOfCases, numOfSearchEngines, numOfQueries, numOfSwitches;
 	int counter, i, j, k, num;
 	char ** enginesArray;
 	char * strAux;
 	int * freqArray;
 	
 	strAux = malloc(100*sizeof(char));
 	
 	scanf("%d", &numOfCases);
 	for(i = 0; i < numOfCases; i++){
 		scanf("%d", &numOfSearchEngines);
 		enginesArray = malloc(numOfSearchEngines*sizeof(char *));
 		freqArray = calloc(numOfSearchEngines, sizeof(int));
 		//read the search engines
 		getchar();
 		for (j = 0; j<numOfSearchEngines; j++){ 
 			enginesArray[j] = malloc(sizeof(char)*100);
 			enginesArray[j] = read();
 		}
 		
 		qsort(enginesArray, numOfSearchEngines, sizeof(char *), (int (*)(const void *, const void *))strcmp);
         
 		//read the input queries
 		scanf("%d", &numOfQueries);
 		counter = 0;
 		numOfSwitches = 0;
 		getchar();
 		for (j = 0; j<numOfQueries; j++){
 			strAux = read();
  			k = 0;
 			while (strcmp(strAux, enginesArray[k]) != 0){
 				k++;
 			}
 			if (freqArray[k] == 0){
 				counter++;
 			}
 			freqArray[k]++;
 			if (counter == numOfSearchEngines){
 				numOfSwitches++;
 				num = k;
 				for(k = 0; k < numOfSearchEngines; k++){
 					freqArray[k] = 0;
 				}
 				freqArray[num]++;
 				counter = 1;
 			}
 		}
 		
 		printf("Case #%d: %d\n", i+1, numOfSwitches);
 		//free(enginesArray);
 		//free(freqArray);
 	}	
 	return 0;
 }
 
 
 char * read()
 {
 	char * str;
 	char c;
 	int i = -1;
 	
 	str = malloc(sizeof(char)*100);
 	do{
 		i++;
 		c = getchar();
 		str[i] = c;
 	}while (c != '\n');
 	
 	str[i] = '\0';
 	
 	return str;
 }

