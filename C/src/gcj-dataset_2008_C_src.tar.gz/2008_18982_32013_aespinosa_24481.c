#include <stdio.h>
 #include <stdlib.h>
 
 int to_mins(int hr, int min)
 {
 	return hr * 60 + min;
 }
 
 int comp(const int * a,const int * b)
 {
 	if (*a==*b)
 		return 0;
 	else
 		if (*a < *b)
 			return -1;
 		else
 			return 1;
 }
 
 int main()
 {
 	int sa[1440], sb[1440];
 	int N;
 	int zz;
 	scanf("%d", &N);
 	for(zz = 1; zz <= N; zz++)
 	{
 		int T;
 		int NA, NB;
 		int i;
 		int ara[100], arb[100];
 		for( i = 0; i < 1440; i++ )
 		{
 			sa[i] = 0;
 			sb[i] = 0;
 		}
 		for( i = 0; i < 100; i++ )
 		{
 			ara[i] = 0;
 			arb[i] = 0;
 		}
 		scanf("%d", &T);
 		scanf("%d", &NA);
 		scanf("%d", &NB);
 		printf("Case #%d: ", zz);
 		for(i = 0; i < NA; i++)
 		{
 			char c;
 			int hr, min;
 			scanf("%d", &hr);
 			scanf("%c", &c);
 			scanf("%d", &min);
 			sa[to_mins(hr, min)]++;
 			scanf("%d", &hr);
 			scanf("%c", &c);
 			scanf("%d", &min);
 			arb[i] = to_mins(hr, min) + T;
 		}
 		for(i = 0; i < NB; i++)
 		{
 			char c;
 			int hr, min;
 			scanf("%d", &hr);
 			scanf("%c", &c);
 			scanf("%d", &min);
 			sb[to_mins(hr, min)]++;
 			scanf("%d", &hr);
 			scanf("%c", &c);
 			scanf("%d", &min);
 			ara[i] = to_mins(hr, min) + T;
 		}
 		qsort(arb, NA, sizeof(int),comp) ;
 		qsort(ara, NB, sizeof(int),comp) ;
 		for(i = 0; i < NA; i++)
 		{
 			int j;
 			for(j = arb[i]; j < 1440; j++)
 			{
 				if( sb[j] )
 				{
 					sb[j]--;
 					break;
 				}
 			}
 		}
 		for(i = 0; i < NB; i++)
 		{
 			int j;
 			for(j = ara[i]; j < 1440; j++)
 			{
 				if( sa[j] )
 				{
 					sa[j]--;
 					break;
 				}
 			}
 		}
 		int suma = 0;
 		int sumb = 0;
 		for(i = 0; i < 1440; i++)
 		{
 			suma = sa[i] + suma;
 			sumb = sb[i] + sumb;
 		}
 		printf("%d %d\n", suma, sumb);
 	}
 	return 0;
 }

