#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define MAX_LINE_LENGTH 50
 #define MAX_TEST_CASES 100
 #define MAX_TRAINS 100
 
 void process_testcase(FILE *, FILE *, int, int);
 void time_sort(int *, int *, int *, int *, int);
 
 
 main()
 {
 
 	char str_buf[MAX_LINE_LENGTH + 2];
 	FILE *filePtr = NULL;
 	FILE *outfile = NULL;
 	char line[MAX_LINE_LENGTH + 2];
 	int input_number, testcases, i;
 
 	printf("Enter input type (1 for small, 2 for large):\n");
 	fgets(str_buf, MAX_LINE_LENGTH + 1, stdin);
 	sscanf(str_buf, "%d", &input_number);
 	if (input_number == 1)
 	{
 		filePtr = fopen("B-small.in", "r");
 	}
 	else if (input_number == 2)
 	{
 		filePtr = fopen("B-large.in", "r");
 	}
 	if (filePtr == NULL)
 	{
 		fprintf(stderr, "Error: input file not found.\n");
 		return;
 	}
 
 	outfile = fopen("qual.out", "w");
 
 	while (fgets(line, MAX_LINE_LENGTH + 1, filePtr) != NULL)
 	{
 		sscanf(line, "%d", &testcases);
 
 		if (testcases < 1 || testcases > MAX_TEST_CASES)
 		{
 			fprintf(stderr, "Error: invalid number of test cases, must be between 1 and %d inclusive.\n", MAX_TEST_CASES);
 			return;
 		}
 
 		for (i=0; i<testcases; i++)
 		{
 			process_testcase(filePtr, outfile, i+1, input_number);
 		}
 	}
 
 	fclose(filePtr);
 	fclose(outfile);
 	
 	return;
 }
 
 void process_testcase(FILE *filePtr, FILE *outfile, int test_case, int input_number)
 {
 	char line[MAX_LINE_LENGTH + 2];
 	int turnaround, na, nb, i, j;
 	int a_hrs_arrive[MAX_TRAINS];
 	int b_hrs_arrive[MAX_TRAINS];
 	int a_mins_arrive[MAX_TRAINS];
 	int b_mins_arrive[MAX_TRAINS];
 	int a_hrs_depart[MAX_TRAINS];
 	int b_hrs_depart[MAX_TRAINS];
 	int a_mins_depart[MAX_TRAINS];
 	int b_mins_depart[MAX_TRAINS];
 	int a_saved[MAX_TRAINS];
 	int b_saved[MAX_TRAINS];
 	int a_needed, b_needed;
 
 	fgets(line, MAX_LINE_LENGTH + 1, filePtr);
 	sscanf(line, "%d", &turnaround);
 	
 	// error checking
 	
 	fgets(line, MAX_LINE_LENGTH + 1, filePtr);
 	sscanf(line, "%d %d", &na, &nb);
 	
 	a_needed = na;
 	b_needed = nb;
 	
 	// error checking
 	
 	for (i=0; i<na; i++)
 	{
 		fgets(line, MAX_LINE_LENGTH + 1, filePtr);
 		sscanf(line, "%d:%d %d:%d", &a_hrs_depart[i], &a_mins_depart[i], &a_hrs_arrive[i], &a_mins_arrive[i]);
 		a_saved[i] = 0;
 	}
 
 	for (i=0; i<nb; i++)
 	{
 		fgets(line, MAX_LINE_LENGTH + 1, filePtr);
 		sscanf(line, "%d:%d %d:%d", &b_hrs_depart[i], &b_mins_depart[i], &b_hrs_arrive[i], &b_mins_arrive[i]);
 		b_saved[i] = 0;
 	}
 	
 	time_sort(a_hrs_arrive, a_mins_arrive, a_hrs_depart, a_mins_depart, na);
 	time_sort(b_hrs_depart, b_mins_depart, b_hrs_arrive, b_mins_arrive, nb);
 
 	
 	for (i=0; i<na; i++)
 	{
 		a_mins_arrive[i] += turnaround;
 		if (a_mins_arrive[i] > 59)
 		{
 			a_mins_arrive[i] -= 60;
 			a_hrs_arrive[i] += 1;
 		}
 		for (j=0; j<nb; j++)
 		{
 			if (time_compare(a_hrs_arrive[i], a_mins_arrive[i], b_hrs_depart[j], b_mins_depart[j]) <= 0 && b_saved[j] == 0)
 			{
 				b_saved[j] = 1;
 				b_needed--;
 				break;
 			}
 		}
 	}
 	
 	time_sort(b_hrs_arrive, b_mins_arrive, b_hrs_depart, b_mins_depart, nb);
 	time_sort(a_hrs_depart, a_mins_depart, a_hrs_arrive, a_mins_arrive, na);
 	
 	for (i=0; i<nb; i++)
 	{
 		b_mins_arrive[i] += turnaround;
 		if (b_mins_arrive[i] > 59)
 		{
 			b_mins_arrive[i] -= 60;
 			b_hrs_arrive[i] += 1;
 		}
 		for (j=0; j<na; j++)
 		{
 			if (time_compare(b_hrs_arrive[i], b_mins_arrive[i], a_hrs_depart[j], a_mins_depart[j]) <= 0 && a_saved[j] == 0)
 			{
 				a_saved[j] = 1;
 				a_needed--;
 				break;
 			}
 		}
 	}
 	
 	fprintf(outfile, "Case #%d: %d %d\n", test_case, a_needed, b_needed);
 	
 	return;
 }
 
 int time_compare(int a_hrs, int a_mins, int b_hrs, int b_mins)
 {
 	if (a_hrs < b_hrs)
 		return -1;
 	else if (a_hrs > b_hrs)
 		return 1;
 	else
 	{
 		if (a_mins < b_mins)
 			return -1;
 		else if (a_mins > b_mins)
 			return 1;
 		else if (a_mins == b_mins)
 			return 0;
 	}
 
 }
 
 void time_sort(int *hours_1, int *mins_1, int *hours_2, int *mins_2, int size)
 {
 	int i, j;
 	int temp_h1, temp_m1, temp_h2, temp_m2;
 
 	for (i=1; i<size; i++)
 	{
         temp_h1 = hours_1[i]; temp_m1 = mins_1[i];
 		temp_h2 = hours_2[i]; temp_m2 = mins_2[i];
         j = i-1;
         while (j >= 0 && time_compare(hours_1[j], mins_1[j], temp_h1, temp_m1) > 0)
         {
 			hours_1[j+1] = hours_1[j]; mins_1[j+1] = mins_1[j];
 			hours_2[j+1] = hours_2[j]; mins_2[j+1] = mins_2[j];
 			j = j-1;
         }
 		hours_1[j+1] = temp_h1; mins_1[j+1] = temp_m1;
 		hours_2[j+1] = temp_h2; mins_2[j+1] = temp_m2;
     }
 
 }

