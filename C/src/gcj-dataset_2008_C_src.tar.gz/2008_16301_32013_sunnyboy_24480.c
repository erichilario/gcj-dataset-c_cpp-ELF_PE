#include<stdio.h>
 #include<string.h>
 int main(void)
 {
     FILE *fin  = fopen ("A-large.in", "r");
     FILE *fout = fopen ("A-large.out", "w");
     
     int num,t,n,m,k,i,j,ans;
     char c[120];
     fscanf(fin,"%d",&num);
     for(t=1;t<=num;t++){
         char s[120][120];
         int a[120]={0};
         fscanf(fin,"%d ",&n);
         for(i=1;i<=n;i++){
             fgets(s[i],1024,fin);
         }    
         ans=0;
         a[0]=n;
         fscanf(fin,"%d ",&m);
         for(j=1;j<=m;j++){
             fgets(c,1024,fin);
             for(i=1;i<=n;i++)
                 if(a[i]==ans){
                     if(strcmp(s[i],c)==0){
                         a[i]++;
                         a[0]--;
                         if(a[0]==0){
                             a[0]=n-1; 
                             ans++;
                             a[i]++;
                         }    
                         break;
                     }    
                 }    
         }    
         fprintf(fout,"Case #%d: %d\n",t,ans);
     }    
     return 0;
 }    

