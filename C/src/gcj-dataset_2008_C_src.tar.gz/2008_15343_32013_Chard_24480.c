#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 typedef struct QueEntryStruct
 {
     struct QueEntryStruct *NextPtr;
     struct QueEntryStruct *PrevPtr;
     char EngineName[102];
 } QUE_ENTRY_STRUCT;
 
 typedef struct QueCtrlStruct
 {
     struct QueEntryStruct *NextPtr;
     struct QueEntryStruct *PrevPtr;
     unsigned long Counter;
 } QUE_CTRL_STRUCT;
 
 QUE_CTRL_STRUCT InUse;
 QUE_CTRL_STRUCT NotInUse;
 QUE_ENTRY_STRUCT Entry[100];
 
 QUE_CTRL_STRUCT *UseIt;
 QUE_CTRL_STRUCT *DontUse;
 QUE_CTRL_STRUCT *TmpQ;
 int SwitchCnt;
 
 
 void insert(QUE_ENTRY_STRUCT *QueEntry,
             QUE_CTRL_STRUCT *QueCtrl)
 {
     QueEntry->NextPtr = (QUE_ENTRY_STRUCT *)QueCtrl;
     QueEntry->PrevPtr = QueCtrl->PrevPtr;
     QueCtrl->PrevPtr->NextPtr = QueEntry;
     QueCtrl->PrevPtr = QueEntry;
     QueCtrl->Counter++;
 }
 
 void moveq(QUE_ENTRY_STRUCT *QueEntry)
 {
     QueEntry->NextPtr->PrevPtr = QueEntry->PrevPtr;
     QueEntry->PrevPtr->NextPtr = QueEntry->NextPtr;
     UseIt->Counter--;
     
     QueEntry->NextPtr = (QUE_ENTRY_STRUCT *)DontUse;
     QueEntry->PrevPtr = DontUse->PrevPtr;
     DontUse->PrevPtr->NextPtr = QueEntry;
     DontUse->PrevPtr = QueEntry;
     DontUse->Counter++;
 }
 
 
 void searchQ(char *Query)
 {
     QUE_ENTRY_STRUCT *CurrEntry;
     int Result;
 
     CurrEntry = UseIt->NextPtr;
 
     do
     {
         Result=strcmp(CurrEntry->EngineName, Query);
         if (Result == 0)
         {
             if (UseIt->Counter>1)
             {
                 moveq(CurrEntry);
             }
             else
             {
                 SwitchCnt++;
                 TmpQ = UseIt;
                 UseIt = DontUse;
                 DontUse = TmpQ;
             }
             
             return;
         }
         
 
         CurrEntry = CurrEntry->NextPtr;
     }
     while(CurrEntry != (QUE_ENTRY_STRUCT *)UseIt);
 }
 
 void main()
 {
     int i,N;
     int S;
     int SCntr;
     int Q;
     int QCntr;
     char StrTmp[102];
 
     gets(StrTmp);
     N=atoi(StrTmp);
 
     
     for (i=1;i<=N; i++)
     {
         
         SwitchCnt=0;
 
         InUse.NextPtr = (QUE_ENTRY_STRUCT *)&InUse;
         InUse.PrevPtr = (QUE_ENTRY_STRUCT *)&InUse;
         InUse.Counter = 0;
         UseIt = &InUse;
 
         NotInUse.NextPtr = (QUE_ENTRY_STRUCT *)&NotInUse;
         NotInUse.PrevPtr = (QUE_ENTRY_STRUCT *)&NotInUse;        
         NotInUse.Counter = 0;
         DontUse = &NotInUse;
 
         gets(StrTmp);
         S=atoi(StrTmp);
         for (SCntr=0; SCntr<S; SCntr++)
         {
             gets(Entry[SCntr].EngineName);
             insert(&Entry[SCntr], &InUse);
         }
 
         gets(StrTmp);
         Q=atoi(StrTmp);
         for (QCntr=0; QCntr<Q; QCntr++)
         {
             gets(StrTmp);
             searchQ(StrTmp);
         }
 
 
         printf("Case #%i: %i\n", i, SwitchCnt);
     }
 }

