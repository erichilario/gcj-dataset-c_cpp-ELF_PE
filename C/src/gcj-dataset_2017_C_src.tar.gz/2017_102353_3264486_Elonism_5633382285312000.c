#include<stdio.h>
 #include<math.h>
 
 int main(void)
 {
     int t, k;
     scanf(" %d", &t);
     for(int i = 1, c = 0; i <= t; i++){
         printf("");
         scanf(" %d", &k);
         int num = k;
         while(num != 0){
             num = num/10;
             c++;
         }
         for(int j = 0; j < c; j++){
             int n = k/pow(10,j);
             while(n%10< (n/10)%10){
                 k--;
                 n=k/pow(10,j);
             }
         }
         printf("Case #%d: %d\n", i, k);
     }
 }
