#include <stdio.h>
 #include <math.h>
 #include <string.h>
 
 void tring(char s[], long long int num)
 {
     int i, rem, len = 0, n;
  
     n = num;
     while (n != 0)
     {
         len++;
         n /= 10;
     }
     for (i = 0; i < len; i++)
     {
         rem = num % 10;
         num = num / 10;
         s[len - (i + 1)] = rem + '0';
     }
     s[len] = '\0';
 }
  
  
 int main(void) {
 int t,te;
 scanf("%d",&t);
 te=1;
 while(te<=t){
     char s[19];
     scanf("%s",s);
         
     long long int num,k;
     int i,tmp;
     
 naveen:
 num=0;tmp=0;
     for(i=0;s[i+1]!='\0';i++){
         if(s[i]>s[i+1]){
             tmp=i+1;
             break;
         }
     }
     if(tmp==0){
         printf("case #%d: %s\n",te,s);
     }
     else
     {
         tmp=strlen(s)-tmp;
         for(i=0;s[i]!='\0';i++){
             num=num*10+(s[i]-'0');
         }
         k=pow(10,tmp);
         k=num%k;
         num=num-(k+1);
          tring( s, num);
          for(i=0;s[i+1]!='\0';i++){
         if(s[i]>s[i+1]){
             goto naveen;
         }
        }
         
         printf("case #%d: %lld\n",te,num);
     }
     te++;
 }
 	return 0;
 }
 

