#include<stdio.h>
 #include<stdlib.h>
 int issorted(int n);
 int evaluate (int n);
 int main(){
 int n,i,j,no;
 scanf("%d",&n);
 for(i=0;i<n;i++){
 no=0;
 scanf("%d",&no);
 printf("Case #%d: ",i+1);
 j=evaluate(no);
 
 
 printf("%d\n",j);
 }
 //issorted(121);
 
 }
 
 int evaluate (int n){
 if(issorted(n)) {return n;}
 	int *a=(int *)malloc(sizeof(int)*(n));
 	
 	int i,j,temp;
 	for(i=0;i<n;i++){
 		a[i]=i+1;
 		
 	}
 		for(i=n-1;i>=0;i--){
 		temp=issorted(a[i]);
 		if(temp==1){ return a[i];}
 		
 	}
 	
 	
 	
 }
 
 int issorted(int n){
 int i,temp,k,b[4],flag=1;
 i=0;
 temp=n;
 int temp2[4];
 while( temp!=0  ){
 	
 k=temp%10;
 temp2[i]=k;
 temp=temp/10;
 i++;
 }
 
 
 
 for(k=0;k<i-1 && flag!=0;k++){
 if(temp2[k]==0) flag=0;
 else{	
 if(temp2[k]>=temp2[k+1]) flag=1;
 else flag=0;
 
 }
 }
 return flag;
 
 
 }

