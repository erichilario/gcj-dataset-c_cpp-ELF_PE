#include <stdio.h>
 #include <string.h>
 
 int main()
 {
 	int casos;
 	long long numeros, ultimo;
 	
 	scanf("%d", &casos);
 	for(unsigned int i = 1; i <= casos; i++)
 	{
 		scanf("%lld", &numeros);
 		for(long long j = numeros; j >= 1;j--)
 		{
 			if(j >= 10)
 			{
 				long long numero = j;
 				int situacao = 1;
 				int algarismoanterior = numero % 10;
 				numero /= 10;
 				while(numero > 0)
 				{
 					unsigned int algarismo = numero % 10;
 					numero /= 10;
 					if(algarismoanterior < algarismo)
 					{
 						situacao = 0;
 						break;
 					}
 					algarismoanterior = algarismo;
 				}
 				if(situacao)
 				{
 					ultimo = j;
 					break;
 				}
 			}
 			else
 			{
 				ultimo = j;
 				break;
 			}
 		}
 		printf("Case #%d: %lld\n", i, ultimo);
 	}
 	
 	return 0;
 }

