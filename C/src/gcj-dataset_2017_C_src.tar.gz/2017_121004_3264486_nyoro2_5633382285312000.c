//
 // qual_b.c
 //
 
 #include <stdio.h>
 
 
 int main()
 {
 	int t;
 	int i, j, k;
 	long long number;
 	char digit[32];
 	int nrof_digit;
 
 	fscanf(stdin,"%d\n",&t);
 	for(i = 0; i < t; i++) {
 		// input data
 		fscanf(stdin,"%lld\n",&number);
 //		fprintf(stderr,"%lld\n",number);
 		nrof_digit = 0;
 		while(1) {
 			digit[nrof_digit] = number % 10;
 			nrof_digit++;
 			number /= 10;
 			if(number == 0) {
 				break;
 			}
 		}
 		// calc
 		while(1) {
 			for(j = nrof_digit-1; j > 0; j--) {
 				if(digit[j] > digit[j-1]) {
 					digit[j]--;
 					for(k = j-1; k >= 0; k--) {
 						digit[k] = 9;
 					}
 					break;
 				}
 			}
 			if(j == 0) {
 				break;
 			}
 		}
 		if(digit[nrof_digit-1] == 0) {
 			nrof_digit--;
 		}
 		// output result
 		printf("Case #%d: ", i+1);
 		for(j = nrof_digit-1; j >= 0; j--) {
 			printf("%1d", digit[j]);
 		}
 		printf("\n");
 	}
 
 	return 0;
 }
 
 // End of qual_b.c

