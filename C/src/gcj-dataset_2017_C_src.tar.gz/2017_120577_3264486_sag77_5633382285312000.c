#include <stdio.h>
 
 int main() {
 	int t,c,i,digit,a[t],k,n,j,prev,l=0,count=1;
 
 	scanf("%d\n",&t);
     
 	
 	while(t>0)
 	{
 	    scanf("%d",&n);
 	  
 	    c=0,k=1;
 	    for(i=n;i>0;i--)
 	    
 	    {
 	     
 	       
 	        for(j=i;j>0;j=j/10)
 	        {
 	           digit=j%10;
 	           if(c!=0)
 	           {
 	              if(digit>prev)
 	              {
 	              
 	              k=0;
 	              break;
 	              }
                    
 	           }
 	           else
 	           c=1;
               prev=digit;
               //printf("di");
             }
             c=0;
             if(k!=0)
             {
             a[l]=i;
            
             //printf("%d",a[l]);
         	printf("Case #%d: %d\n",count++,a[l]);
                  l++;
                 
             break;
             }
             k=1;
           
 	    }
 	    t--;
 	    
 	}
 
 	return 0;
 }
 

