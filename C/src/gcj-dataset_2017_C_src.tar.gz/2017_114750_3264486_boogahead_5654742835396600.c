#include <stdio.h>
 
 int main(void)
 {
 	FILE *ifp, *ofp;
 	ifp = fopen("C-small-1-attempt0.in", "r");
 	ofp = fopen("output.txt", "w");
 	int times,res,i,j;
 	int sit[100][1000];
 	int sim[100][1000] = { 0 };
 	int ls, rs,remainder;
 	int mem = 0;
 	int neew = 0;
 	res = fscanf(ifp, "%d", &times);
 	for (i = 0; i < times; i++)
 	{
 		res = fscanf(ifp, "%d %d", &sit[i][0], &sit[i][1]);
 	}
 	for (i = 0; i < times; i++)
 	{
 		if (sit[i][0] == sit[i][1])
 		{
 			fprintf(ofp,"Case #%d: 0 0\n", i+1);
 		}
 		else
 		{
 			remainder = sit[i][0];
 			for (j = 0; j < sit[i][1]; j++)
 			{
 				if (remainder % 2)
 				{
 					neew = mem + (remainder / 2) + 1;
 					ls = neew - mem-1;
 					rs = sit[i][0] - neew;
 					mem = neew;
 					remainder = sit[i][0] - mem;
 				}
 				else
 				{
 					neew = mem + (remainder / 2);
 					ls = neew - mem;
 					rs = sit[i][0] - neew-1;
 					mem = neew;
 					remainder = sit[i][0] - mem;
 				}
 
 			}
 			if (rs > ls)
 			{
 				fprintf(ofp, "Case #%d: %d %d\n", i+1, rs, ls);
 			}
 			else
 			{
 				fprintf(ofp, "Case #%d: %d %d\n", i+1, ls, rs);
 			}
 			mem = 0;
 			neew = 0;
 		}
 	}
 	fclose(ifp);
 	fclose(ofp);
 	return 0;
 }
