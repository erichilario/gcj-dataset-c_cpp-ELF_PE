#include<stdio.h>
 #include<string.h>
 
 int t,i,n,k,j,l,c,f;
 char a[1005];
 
 void xchg(char *s)
 {
 int q=0;
 for(q=0;q<k;++q)
 if(s[q]=='-')s[q]='+';
 else s[q]='-';
 return;
 }
 
 int main()
 {
 scanf("%d",&t);
 
 for(i=0;i<t;++i)
 {
 c=0;
 f=0;
 scanf("%s%d",a,&k);
 n = strlen(a);
 for(j=0;j<=(n-k);++j)
 if(a[j]=='-'){xchg(a+j);c++;}
 
 while(j<n)
 {
 if(a[j]=='-'){f=1;break;}
 j++;
 }
 if(f==1)
 printf("Case #%d: IMPOSSIBLE\n",i+1);
 else printf("Case #%d: %d\n",i+1,c);
 
 }
 
 return 0;
 }
 

