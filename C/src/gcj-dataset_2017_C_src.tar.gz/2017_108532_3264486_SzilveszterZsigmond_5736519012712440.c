#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char sz_flip(char *S, int index){
     if(S[index] == '+'){
         return '-';
     } else {
         return '+';
     }
 }
 
 int main(){
     freopen("A-large.in", "r", stdin);
     freopen("A-large.out", "w", stdout);
 
     int T,K, i, j,q,w, flips;
     char S[1000];
 
     scanf("%i", &T);
 
     for(i=0; i<T; i++){
         scanf("%s", &S);
         scanf("%i", &K);
 
         q = strlen(S) - 1;
         j = 0;
         flips = 0;
 
         while(1){
             if(j+K-1 > q){ // done
                 char solution = 1;
                 for(w=j-1; w<=q; w++){ // check if in the remaining pancakes are negatives
                     if(S[w] == '-'){
                         solution = 0;
                     }
                 }
                 if(solution){
                     printf("Case #%i: %i\n", i+1, flips);
                 } else {
                     printf("Case #%i: IMPOSSIBLE\n", i+1);
                 }
                 break;
             }
 
             if(S[j] == '-'){
                 if(j+K-1 > q){
                     // there is at least one negative, but no solution
                     printf("Case #%i: IMPOSSIBLE\n", i+1);
                     break;
                 } else { // flip
                     for(w=j; w< j+K; w++){
                         S[w] = sz_flip(S, w);
                     }
                     flips++;
                 }
             }
             j++;
 
             if(S[q] == '-'){
                 if(q-K+1 < j){
                     // there is at least one negative, but no solution
                     printf("Case #%i: IMPOSSIBLE\n", i+1);
                     break;
                 } else { // flip
                     for(w=q; w> q-K; w--){
                         S[w] = sz_flip(S, w);
                     }
                     flips++;
                 }
             }
             q--;
         }
     }
 
     return 0;
 }

