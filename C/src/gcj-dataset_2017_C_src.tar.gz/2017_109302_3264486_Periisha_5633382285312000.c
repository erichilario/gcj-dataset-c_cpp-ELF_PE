#include <stdio.h>
 #include <string.h>
 
 int solve(int n);
 int keta(char num[]);
 
 int main(void){
     int t,n=0;
     scanf("%d%*c",&t);
     while(t){
         solve(++n);
         t--;
     }
     return 0;
 }
 
 int solve(int n){
     int i,j,k,o=20;
     char num[20];
     
     for(i=0;i<20;i++){
         num[i]='\0';
     }
     
     scanf("%[0-9]%*c",num);
     
     k=keta(num);
     while(o--){
         for(i=0;i<k-1;i++){
             if(num[i]>num[i+1]){
                 num[i]-=1;
                 for(j=i+1;j<k;j++){
                     num[j]='9';
                 }
             }
         }
     }
     if(num[0]=='0') for(i=0;i<k;i++) num[i]=num[i+1];
 
     printf("Case #%d: %s\n",n,num);
 
     return 0;
 }
 
 int keta(char num[]){
     int k=0;
     while(num[k]!='\0') k++;
     return k;
 }
