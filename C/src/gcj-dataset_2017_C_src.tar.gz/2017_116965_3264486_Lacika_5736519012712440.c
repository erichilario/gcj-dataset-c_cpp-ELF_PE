#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main()
 {
     int nrT, k, nrC = 1, i, j, len, x, contor, zeros = 0, ok = 0, r;
     char s[11];
     FILE* f, *df;
     if((f=fopen("A-small-attempt4.in", "r"))==NULL){
         perror("A-small-attempt4.in");
         exit(0);
     }
     if((df=fopen("output.in", "w"))==NULL){
         perror("output.in");
         exit(0);
     }
     fscanf(f, "%d", &nrT);
     while(nrT--)
     {
         x = 0;
         contor = 0;
         fscanf(f, "%s", s);
         fscanf(f, "%d", &k);
         len = strlen(s);
         for(i=len-1, j=0 ; i>=0; i--, j++)
         {
             x |= s[i]=='+' ? 1<<j: 0;
         }
         ok =1;
         while(x!=((1<< len) -1) && ok ==1)
         {
             ok=0;
             zeros = 0;
             for(i=len-1; i>=k-1; i--)
             {
                 if( (x & (1 << i)) ==0)
                 {
                     for(j=i; j>i-k; j--)
                     {
                         x^= 1<<j;
                     }
                     ok=1;
                     contor++;
                    // printf("x= %d", x);
                 }
             }
 
             for(i=0; i<len; i++)
             {
                 if( (x & (1 << i)) ==0)
                 {
                     zeros++;
                 }
             }
           //  printf("zeros = %d\n", zeros);
             if(zeros==1) break;
 
             zeros=0;
             for(i=0; i<k && i+k<len; i++)
             {
                 if( (x & (1 << i)) ==0)
                 {
                     for(j=i; j<i+k; j++)
                     {
                         x^= 1<<j;
                     }
                     ok=1;
                     contor++;
                    // printf("x= %d", x);
                 }
             }
             for(i=0; i<len; i++)
             {
                 if( (x & (1 << i)) ==0)
                 {
                     zeros++;
                 }
             }
           //  printf("zeros = %d\n", zeros);
             if(zeros==1) break;
             if(zeros<k)
             for(i=0;i<len;i++){
                 if((x & (1<<i)) == 0){
                     r=0;
                     for(j=i;j<i+zeros;j++)
                         if((x & (1<<j))==1)
                             r=1;
                     if(r==0)
                         ok=0;
                     break;
                 }
             }
          //  _sleep(100);
         }
 
 
 
         if((zeros==1 || ok == 0) && x!=((1<< len) -1))
         {
             fprintf(df, "Case #%d: IMPOSSIBLE\n", nrC);
         }
         else
         {
             fprintf(df, "Case #%d: %d\n", nrC, contor);
         }
 
         nrC++;
 
     }
     return 0;
 }

