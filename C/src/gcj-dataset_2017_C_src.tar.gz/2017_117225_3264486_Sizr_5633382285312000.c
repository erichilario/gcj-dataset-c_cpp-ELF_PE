#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 #include <string.h>
 
 typedef long long ll;
 #define MOD 1000000007
 #define INF 2000000000
 
 int main(){
 	ll t,tc;
 	scanf("%lld",&t);
 	tc = t;
 	ll n,i,digit,tmp,flag,dig,counter;
 	while(tc--){
 		printf("Case #%lld: ",t-tc);
 		scanf("%lld",&n);
 		for(i=n;i>0;--i){
 			tmp = i;
 			flag = 1;
 			dig = INF;
 			counter = 0;
 			while(tmp > 0){
 				//printf("%lld : %lld %lld\n",tmp,digit,dig);
 				digit = tmp%10;
 				if(digit > dig){
 					//i -= 1*pow(10,counter-1)+1;
 					flag = 0;
 					break;
 				}
 				tmp /= 10;
 				++counter;
 				dig = digit;
 			}
 			if(flag){
 				break;
 			}
 		}
 		printf("%lld\n",i);
 	}
 	return 0;
 }
 

