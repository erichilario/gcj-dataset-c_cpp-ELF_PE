#include <bits/stdc++.h>
 using namespace std;
 long long int t,k,size=0,arr[20],countl=0,prev,next,index,countp=0,d,j,i;
 int flag=0;
 void func(long long int);
 int main()
 {
 	scanf("%lld",&t);
 	for(i=0;i<t;i++)
 	{
 		long long int n;
 		scanf("%lld",&n);
 		countl=0;
 		size=0;
 		countp=0;
 		flag=0;
 		func(n);
 		printf("Case #%lld: ",i+1);
 		if(flag==1 && size!=1)
 		{
 			for(j=size;j>=index+countl+1;j--)
 			{
 				printf("%lld",arr[j]);
 				countp++;	
 			}
 			
 		if(prev-1!=0)
 		{
 			printf("%lld",prev-1);
 			countp++;
 		}
 		
 		if(countp==0)
 			d=size-countp-1;
 		else
 			d=size-countp;
 		for(j=0;j<d;j++)
 			printf("%lld",9);
 		}
 		else
 		{
 			for(j=size;j>=1;j--)
 			{
 				printf("%lld",arr[j]);
 			}
 		}
 		
 		printf("\n");
 	}
 	return 0;
 }
 
 void func(long long int m)
 {
 
 
 	while(m>0)
 			{
 				k = m%10;
 				size++;
 				arr[size]=k;
 				m=m/10;	
 						
 			}
 
 	for(j=size;j>=1;j--)
 	{
 		
 		prev=arr[j];
 		if(j!=1)
 			next=arr[j-1];
 		
 		if(prev==next)
 			countl++;
 			
 		if(prev!=next && prev<next)
 		{
 			countl=0;
 	
 		}
 
 
 		if(prev>next)
 		{
 			index=j;
 			flag=1;
 			break;
 		}
 		
 	}
 	return;
 
 
 
 }
