#include <stdio.h>
 #include <stdlib.h>
 
 int calculate_best(int* arr,int size,int *min, int *max){
 	int *arrmin = malloc((size)*sizeof(int));
 	int *arrmax = malloc((size)*sizeof(int));
 	int i;
 	//printf("Starting with min max\n");
 	for (i=1;i<size-1;i++){
 		//printf("chacking %d\n" , i);
 		if (arr[i] == 1){
 			arrmin[i] = -1;
 			arrmax[i] = -1;
 		}else{
 			//printf("no zero\n");
 			int left,right;
 			left = right = 0;
 			int k = i-1;
 			while (k>=0){
 				if (arr[k] == 1)
 					break;
 				left++;
 				k--;
 			}
 			k =  i + 1;
 			while (k<size){
 				if (arr[k] == 1)
 					break;
 				right++;
 				k++;
 			}
 			if (left > right){
 				arrmin[i] = right;
 				arrmax[i] = left;
 			}else if (right > left){
 				arrmin[i] = left;
 				arrmax[i] = right;
 			}else{
 				arrmin[i] = arrmax[i] = left;
 			}
 		}
 	}
 	//printf("finished with min max\n");
 	int allmin = -1;
 	int allmax = -1;
 	int position = 0;
 	for (i=1;i<size-1;i++){
 		if (arrmin[i] > allmin || (arrmin[i] == allmin && arrmax[i] > allmax)){
 			allmin = arrmin[i];
 			allmax = arrmax[i];
 			position = i;
 		}
 	}
 	*min = allmin;
 	*max = allmax;
 	//printf("Best found at position %d min %d max %d\n" , position , allmin , allmax);
 	return position;
 }
 
 int main(){
 	int T,i;
 	scanf("%d", &T);
 	for (i=1;i<=T;i++){
 		int N,K;
 		scanf("%d %d" , &N , &K);
 		int *arr = malloc((N+2)*sizeof(int));
 		arr[0] = 1;
 		arr[N+1] = 1;
 		int j;
 		for (j=1;j<N+1;j++)
 			arr[j] = 0;
 		int min,max;
 		for (j=0;j<K;j++){
 			int best = calculate_best(arr,N+2,&min,&max);
 			//printf("added new to position %d\n" , best);
 			arr[best] = 1;
 		}
 		printf("Case #%d: %d %d\n" , i , max , min);
 		free(arr);
 	}
 	return 0;
 }
