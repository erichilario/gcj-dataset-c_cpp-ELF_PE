#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 #define log_2(x)    (int)(log((double)x)/log((double)2.0))
 #define pow_2(x)    (int)(pow((double)2.0, (double)x))
 
 int main()
 {
     int T, t;
     long long K, N, min, max, empty, groups, num_max;
     int depth, i;
 
     scanf( "%d\n", &T );
     for( t = 1 ; t <= T ; t++ )
     {
         scanf( "%lld %lld\n", &N, &K );
 
         depth = log_2( K )+1;
 
         min = N;
         for( i = 0 ; i < depth-1 ; i++ )
             min = (min-1)/2;
 
         empty = N - pow_2(depth-1) + 1;
 
         groups = pow_2(depth-1);
 
         num_max = empty - groups*min;
         if( num_max )
             max = min + 1;
         else
             max = min;
 
         K -= pow_2(depth-1) - 1;
 
         if( K > num_max )
             N = min;
         else
             N = max;
 
         min = (N-1)/2;
         if( N%2 )
             max = min;
         else
             max = min+1;
 
         printf( "Case #%d: %lld %lld\n", t, max, min );
     }
 
     return 0;
 }

