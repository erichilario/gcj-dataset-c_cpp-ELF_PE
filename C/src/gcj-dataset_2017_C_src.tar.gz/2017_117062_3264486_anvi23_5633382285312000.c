#include<stdio.h>
 #include<math.h>
 
 int main()
 {
     FILE *fpi,*fpo;
     int n,r,flag=0,f2=0,i;
     long long temp,k;
     fpi=fopen("sub1.txt","r");
     fpo=fopen("output1.txt","w");
     fscanf(fpi,"%d",&n);
    // printf("%d",n);
     for(i=1 ;  i<=n ; i++)
     {
         fscanf(fpi,"%lld",&k);
       //  printf("k : %lld",k);
 
         if(k<10 ){
     fprintf(fpo,"Case #%d: %lld\n",i,k);
   //  printf("%lld",k);
    }
         else
         {
             while(k>=10)
             {
                temp=k;
                 while(temp>0)
                 {
                     r=temp%10;
                     temp=temp/10;
                     if(r < temp%10)
                         {
                          flag=1;
                          break;
                         }
 
                 }
                 if(flag==0)
                 {
                      f2=1;
                      fprintf(fpo,"Case #%d: %lld\n",i,k);
                   //   printf("%lld",k);
                      break;
                 }
             k--;
             flag=0;
             }
             if(f2==0)
             {
                  fprintf(fpo,"Case #%d: %lld\n",i,k);
 
                  break;
             }
         }
     }
     fclose(fpo);
     fclose(fpi);
     return 0;
 
 
 }

