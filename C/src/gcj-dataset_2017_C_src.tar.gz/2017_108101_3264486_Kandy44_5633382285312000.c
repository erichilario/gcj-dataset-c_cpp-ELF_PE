#include<stdio.h>
 int areSorted(long long int n)
 {
     // Note that digits are traversed from last to first
     int next_digit = n%10;
     n = n/10;
     while (n)
     {
         int digit = n%10;
         if (digit > next_digit)
             return 0;
         next_digit = digit;
         n = n/10;
     }
  
     return 1;
 }
  
 int main()
 {
 	int t,i;
     long long int n,j,temp=0;
 	scanf("%d",&t);
 	for(i=0;i<t;i++)
 	{
 		scanf("%lld",&n);
 		while(temp!=1){if(areSorted(n)==0){temp=0;}else{temp=1;}--n;}
 		printf("Case #%d: %lld\n",i+1,n+1);temp=0;
 	}
     return 0;
 }
