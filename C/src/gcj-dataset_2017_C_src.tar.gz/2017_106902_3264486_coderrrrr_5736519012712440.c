#include<stdio.h>
 #include<limits.h>
 #include<string.h>
 
 int main()
 {
     int i,j,k,z,l,m,s,n,t,flag;
     char a[1001];
     scanf("%d",&t);
     for(z=1;z<=t;z++)
     {
         flag=1;
         s=0;
     scanf("%s%d",&a,&k);
    // printf("%s%d",a,k);
     l=strlen(a);
     for(i=0;i<l;i++)
     {
         if(a[i]=='-')
         {
             s++;
             for(j=i;j<k+i&&i+k-1<l;j++)
             {
                 if(a[j]=='-')
                     a[j]='+';
                 else a[j]='-';
             }
 
         }
     }
     for(i=0;i<l;i++)
         if(a[i]=='-')
     {
 
         flag=0;
         break;
     }
     if(flag)
         printf("Case #%d: %d\n",z,s);
     else
     printf("Case #%d: IMPOSSIBLE\n",z);
 
     }
 
 }

