#include <stdio.h>
 #include <stdlib.h>
 
 int main(){
     freopen("C-small-1-attempt2.in", "r", stdin);
     freopen("C-small-1-attempt2.out", "w", stdout);
 
     int T, i,k;
     long long N, K, j;
 
     scanf("%i", &T);
     for(i=0; i<T; i++){
         scanf("%lli %lli", &N, &K);
 
         char exponent[65] = { 0 };
         long long tN = K;
         int it = 0;
         while(1){
             if(tN == 0){
                 break;
             }
 
             if(tN % 2 == 1){
                 exponent[it] = '1';
             } else {
                 exponent[it] = '0';
             }
             it++;
             tN /= 2;
         }
         exponent[it] = 0;
 
         int start = 0;
         for(j=64; j>=0; j--){
             if(exponent[j] == '1'){
                 start = j;
                 break;
             }
         }
 
         long long number = N;
         long long left, right;
         for(j=start; j>=0; j--){
             left = right = number/2;
             if( right != 0 && number % 2 == 0 ){
                 right--;
             }
 
             if(j==0) break;
             if(exponent[j-1] == '0'){ // left
                 number = left;
             } else { // right
                 number = right;
             }
         }
         printf("Case #%i: %lli %lli\n", i+1, left, right);
     }
 
     return 0;
 }

