#include<stdio.h>
 #include<string.h>
 
 void singh(char *gram,int len)
 {
 
 
 int i=0,j=0,mark=0;
 
 if(gram[0]=='0')
 {	
 for(i=1;i<=len;i++)
 {
 	gram[i-1]=gram[i];
 	
 	
 }
 
 //Putting gram of i-1 with gram of i
 }
 
 
 
 
 
 }
 
 
 
 void jasjyot(int i,char *data,int len )
 {int j=0;
 	if(data[i]=='0')
 	{
 		data[i]='9';
 		data[i-1]=data[i-1]-1;
 	}
 	else
 	{
 		data[i]--;
 	}
 	for(j=len-1;j>i;j--)
 	{
 		data[j]='9';
 	}
 }
 
 
 void king(FILE *sdd,FILE *hdd ,int counter )
 {
 	char gram[25];
 	int len;
 	int i;
 	fscanf(hdd,"%s",&gram);
 
 	len=strlen(gram);
 	//strlen is used 
 	here:
 	for(i=len-1;i>0;i--)
 	{
 		if(gram[i-1]>gram[i])
 		{
 			jasjyot(i,&gram[0],len);
 			goto here;
 		}
 	}
 	singh(&gram[0],len);
 
 fprintf(sdd,"Case #%d: %s\n",counter+1,gram);
 }
 
 main()
 {
 	
 	
 	int thermo=0;
 	int fan=0;
 	
 	FILE* sdd = fopen("result.txt", "w");
 	FILE* hdd = fopen ("input1.txt", "r");
 	
 	fscanf(hdd,"%d",&thermo);
 	
 	for(fan=0;fan<thermo;fan++)
 	//while(fan<thermo)
 	{
 		king(sdd,hdd,fan);
 		//fan++;
 	}
 }
 

