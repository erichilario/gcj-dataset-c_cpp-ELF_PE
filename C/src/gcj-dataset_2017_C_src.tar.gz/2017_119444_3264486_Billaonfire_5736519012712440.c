#include <stdio.h>
 #include <string.h>
 
 void flipend(char s[], int l, int k){
     //printf("flipend\n");
     int i;
     for(i=l-1;i>(l-k-1);i--){
         if(s[i]=='-'){
             s[i]='+';
         }
         else{
             s[i]='-';
         }
     }
     return ;
 }
 
 /*void flip(char s[], int k){
     int i;
     for(i=0;i<k;i++){
         if(s[i]=='-'){
             s[i]='+';
         }
         else{
             s[i]='-';
         }
     }
     return ;
 }*/
 
 void min(char s[], int l, int k, int j,int count){
     if(l==0){
         //printf("l=0\n");
         printf("Case #%d: %d\n",j,count);
         return ;
     }
     int i,p;
     if(l<k){
         //printf("l<k\n");
         for(i=0;i<l;i++){
             if(s[i]!='+'){
                 break;
             }
         }
         if(i==l){
             printf("Case #%d: %d\n",j,count);
             return;
         }
         else{
             printf("Case #%d: IMPOSSIBLE\n",j);
             return ;
         }
     }
     if((l<((2*k)-1)) && l>=k){
         //printf("l<2*k-1\n");
 	    for(i=k-1;(i>(l-k) && i>=0);i--){
 	        if(s[i]!=s[i-1]){
 	            printf("Case #%d: IMPOSSIBLE\n",j);
 	            return ;
 	        }
 	    }
 	}
 	for(i=0;i<l;i++){
 	    //printf("checking_start\n");
 	    if(s[i]=='+'){
 	        continue;
 	    }
 	    else{
 	        break;
 	    }
 	}
 	if(i==l){
 	    //printf("all +\n");
 	    printf("Case #%d: %d\n",j,count);
 	    return ;
 	}
 	else if(i!=0){
 	    //printf("some +\n");
 	    for(p=0;p<(l-i);p++){
 	        s[p]=s[p+i];
 	    }
 	    l=l-i;
 	    min(s,l,k,j,count);
 	}
 	else{
 	    //printf("no +\n");
     	p=l-1;
     	while(p>0){
     	    //printf("checking_end\n");
     	    if(s[p]=='+'){
     	        p--;
     	    }
     	    else{
     	        break;
     	    }
     	}
     	if(p!=(l-1)){
     	    //printf("some + at end\n");
     	    l=p+1;
     	    min(s,l,k,j,count);
     	}
         else{
             //printf("no + at end\n");
         	for(i=0;i<k;i++){    
         	    if(s[i]!='-'){
         	        break;
         	    }
         	}
         	if(i>k-1){
         	    //printf(" greater than k - at start\n");
         	    count ++;
         	    //printf("%d\n",count);
         	    for(i=i;i<l;i++){
         	        if(s[i]!='+'){
         	            break;
         	        }
         	    }
         	    //printf("%d",i);
         	    for(p=0;p<l-i;p++){
         	        s[p]=s[p+i];
         	    }
         	    l=l-i;
         	    min(s,l,k,j,count);
         	    
         	}
         	
         	else{
         	    flipend(s,l,k);
         	    count ++;
         	    //printf("%d\n",count);
         	    min(s,l,k,j,count);
             }   
         }
 	}
 	return ;
 }
 
 int main() {
 	int t,k,j,l;
 	char s[1000];
 	scanf("%d\n",&t);
 	for(j=1;j<=t;j++){
 	    scanf("%s %d",s,&k);
 	    l=strlen(s);
 	    min(s,l,k,j,0);
 	}
 	return 0;
 }
 

