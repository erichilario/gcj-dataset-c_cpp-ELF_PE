#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main()
 {
     int T, t;
     int K, num, len, i, j;
     char S[1001];
 
     scanf( "%d\n", &T );
     for( t = 1 ; t <= T ; t++ )
     {
         scanf( "%s %d\n", S, &K );
 
         len = strlen(S);
         num = 0;
         for( i = 0 ; i < len-K+1 ; i++ )
         {
             if( S[i] == '-' )
             {
                 for( j = 0 ; j < K ; j++ )
                 {
                     if( S[i+j] == '-' )
                         S[i+j] = '+';
                     else
                         S[i+j] = '-';
                 }
                 num++;
             }
         }
 
         for( ; i < len ; i++ )
         {
             if( S[i] == '-' )
             {
                 num = -1;
                 break;
             }
         }
 
         if (num >=0)
             printf( "Case #%d: %d\n", t, num );
         else
             printf( "Case #%d: IMPOSSIBLE\n", t );
     }
 
     return 0;
 }

