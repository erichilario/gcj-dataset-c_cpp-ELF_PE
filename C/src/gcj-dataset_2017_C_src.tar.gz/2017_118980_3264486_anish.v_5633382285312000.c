#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 int main() {
 
     int T;
 
     long long int N,tidy;
 
     int wrong = -1;
 
     char S[25],tidyS[25];
 
     scanf("%d", &T);
     //printf("%d\n",T);
 
     for (int i=1;i<=T;i++) {
         scanf("%s", S);
         
         N=atol(S);
         //printf("%lld\n", N);
         //
       
         if (N < 99999999) { 
             //Small inputs
             for (tidy=N; tidy>=1; tidy--) {
                 sprintf(tidyS,"%lld",tidy);
                 //Logic
                 if (tidy < 10) break;
                 wrong=0;
                 for (int i=0;i<strlen(tidyS)-1;i++) {
                     if (tidyS[i] > tidyS[i+1]) {
                         wrong=1;
                         break;
                     }
                 } 
                 if (wrong==0) break;
                 //End logic
             }
 
         } 
         else 
         {
             //Large inputs
             for (tidy=N; tidy>=N-(N%100); tidy--) {
                 sprintf(tidyS,"%lld",tidy);
                 //printf("\nHere0 %s\n",tidyS);
                 //Logic
                 wrong=-1;
                 for (int i=0;i<strlen(tidyS)-1;i++) {
                     if (tidyS[i] > tidyS[i+1]) {
                         wrong=i;
                         break;
                     }
                 } 
                 if (wrong==-1) break;
                 //End logic
             }
             
             if (tidy<N) tidy=N; 
 
             if (wrong != -1) {
 
                 sprintf(tidyS,"%lld",tidy);
                 //printf("\nHere %d, %s\n",wrong,tidyS);
                 //printf("%s\n", tidyS);
                 //sprintf(tidyS,"%lld",N);
                 wrong = -1;
                 for (int i=0;i<strlen(tidyS)-1;i++) {
                     if (tidyS[i] > tidyS[i+1]) {
                         //wrong=i+1;
                         wrong=i;
                         break;
                     }
                 }
                 if (wrong != -1) {
                     //for (int i=wrong;i<strlen(tidyS)-1;i++) {
                     //    tidyS[i]='0';
                     //}
 
                     //Now gets 1111111111111111100
                     //printf("\nHere2 %d, %s\n",wrong,tidyS);
                     int firstsmall = -1;
                     if (wrong != 0) {
                         for (int i=wrong-1; i>=0;i--) {
                             if (tidyS[i] < tidyS[wrong]) {
                                 firstsmall = i;
                                 break;
                             }
                         }
                     }
 
                     //printf("\n%d, %d: %s\n",wrong,firstsmall,tidyS);
 
                     tidyS[firstsmall+1]=tidyS[firstsmall+1]-1;
                     for (int i=firstsmall+2; i<strlen(tidyS);i++) {
                         tidyS[i]='9';
                     }
                     //printf("\n%d, %d: %s\n",wrong,firstsmall,tidyS);
                     //
 
                     tidy=atol(tidyS);
                     for (; tidy>=1; tidy--) {
                         sprintf(tidyS,"%lld",tidy);
                         //Logic
                         wrong=0;
                         for (int i=0;i<strlen(tidyS)-1;i++) {
                             if (tidyS[i] > tidyS[i+1]) {
                                 wrong=1;
                                 break;
                             }
                         } 
                         if (wrong==0) break;
                         //End logic
                     }
                 }
             }
         }
         printf("Case #%d: %s\n", i, tidyS);
     }
 
 }

