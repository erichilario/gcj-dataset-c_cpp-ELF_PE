/* Sachin Chandani */
 
 #include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 #include<math.h>
 #include<stdbool.h>
 #include<limits.h>
 #include<assert.h>
 #include<time.h>
 #define INF INT_MAX
 #define rep(i,a,b) for(i=a;i<=b;i++)
 #define inp(x) scanf("%d",&x)
 int min(int a,int b);
 int max(int a,int b);
 int cmp(const void * a,const void *b);
 bool check(long long int n)
 {
 	long long prev=LONG_MAX;
 	int rem;
 	long long temp=n;
 	while(temp!=0)
 	{
 		rem=temp%10;
 		if(rem<=prev)
 		{
 			prev=rem;
 		}
 		else return false;
 		temp/=10;
 	}
 	return true;
 
 }
 
 int main()
 {
 	int t;
 	int a[100]={0};
 	inp(t);
 	long long int n;
 	for(int one=1;one<=t;one++)
 	{
 		scanf("%lld",&n);
 		printf("Case #%d: ",one);
 		long long temp=n;
 		long long new=n;
 		int i=0,j=0;
 		while(temp!=0)
 		{
 			a[j++]=temp%10;
 			temp/=10;
 		}
 		temp=0;
 		while(1)
 		{
 //			printf("in\n");
 			if(check(new)==true)
 			{
 				printf("%lld\n",new);
 				break;
 			}
 			else
 			{
 				temp+=a[i]*pow(10,i);
 				i++;
 				new=n-temp-1;
 //				printf("%lld\n",new);
 			}
 		}
 	}
 //	qsort( , ,sizeof(int),cmp);
 	return 0;
 }
 int min(int a,int b)
 {
 	return (a>b?b:a);
 }
 
 int max(int a,int b)
 {
 	return (a<b?b:a);
 }
 
 int cmp(const void * a,const void *b)
 {
 	return(*(int*)a-*(int*)b);
 }
 

