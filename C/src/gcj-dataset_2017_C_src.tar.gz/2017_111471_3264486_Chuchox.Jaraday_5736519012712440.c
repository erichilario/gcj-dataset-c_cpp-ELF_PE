#include <stdio.h>
 
 int main(void){
     int cases, casos;
     char cadena[1000];
     int flip, volteos, success, i, j, k;
     char c;
 
     scanf("%d\n",&cases);
     for(casos=1;casos<=cases;casos++){
         i = 0;
         while((c=getchar())!=' '){
             cadena[i] = c;
             i++;
             //putchar(cadena[i-1]);
         }
         scanf("%d\n",&flip);
         //printf("%d %d\n",flip,i);
         volteos = 0;
         for(j=0;j<=(i-flip);j++){
             if(cadena[j] == '-'){
                 for(k=0;k<flip;k++){
                     if(cadena[j+k] == '-'){
                         cadena[j+k] = '+';
                     }else{
                         cadena[j+k] = '-';
                     }
                 }
                 volteos++;
                 /*for(k=0;k<i;k++){
                     putchar(cadena[k]);
                 }
                 putchar('\n');*/
             }
         }
         success = 1;
         for(j=(i-flip);j<i;j++){
             if(cadena[j] == '-'){
                 success = 0;
             }
         }
         if(success){
             printf("Case #%d: %d\n",casos,volteos);
         }else{
             printf("Case #%d: IMPOSSIBLE\n",casos);
         }
     }
 
     return(0);
 }

