#include<stdio.h>
 #include<stdlib.h>
 int l,r;
 void findit(char *a,int n)
 {
 int max=0,count=0,i,l1=0;
 	for(i=0;i<n;i++)
 	{
 		if(a[i]=='1')
 		{
 		if(max<count)
 		{	
 		l1=i-count-1;
 		max=count;
 		//printf("%d ",max);
 		}
 		count=0;
 		}
 		else
 		count++;
 	}
 	if(count>max)
 	{
 	l1=i-count-1;
 	max=count;
 	}
 	a[l1+(max+1)/2]='1';
 	l=((max+1)/2)-1;
 	r=max-(max+1)/2;
 	//for(i=0;i<n;i++)
 	//printf("%c",a[i]); 
 	//printf("\n");
 
 }
 int main()
 {
 FILE* fpi=fopen("input.in","r");
 FILE* fpo=fopen("out.in","w");
 char *a;
 int i,j,t,n,k;
 fscanf(fpi,"%d",&t);
 	for(i=0;i<t;i++)
 	{
 	fprintf(fpo,"Case #%d: ",i+1);
 	fscanf(fpi,"%d %d",&n,&k);
 	a=(char*)malloc(n*sizeof(char));
 		for(j=0;j<n;j++)
 		a[j]='0';
 		a[(n-1)/2]='1';
 		l=(n-1)/2;
 		r=n-1-(n-1)/2;
 		for(j=1;j<k;j++)
 		{
 		findit(a,n);
 		}
 	fprintf(fpo,"%d %d\n",r,l);
 	}
 fclose(fpi);
 fclose(fpo);
 return 0;
 }
