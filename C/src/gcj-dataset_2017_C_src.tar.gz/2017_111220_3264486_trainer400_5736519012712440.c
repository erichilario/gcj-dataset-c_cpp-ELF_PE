#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 int main(){
     FILE * input;
     FILE * output;
     int iterazioni;
     int pancake;
     int contatore;
     int i, j, k;
     int contatore_giri = 0;
     int ciclo_attivo = 1;
     char stringa[100];
     char stringa_finita[100];
     input = fopen("input.in", "r");
     output = fopen("output.txt", "w+");
     fscanf(input, "%d", &iterazioni);
 
 
     for(contatore = 0; contatore < iterazioni; contatore++){
         fscanf(input, "%s", stringa);
         fscanf(input, "%d", &pancake);
         ciclo_attivo = 1;
         contatore_giri = 0;
         for(i = 0; i < strlen(stringa); i++){
             stringa_finita[i] = '+';
         }
         stringa_finita[strlen(stringa)] = '\0';
         while(ciclo_attivo == 1){
             for(j = 0; j < strlen(stringa); j++){
                 char carattere = stringa[j];
                 if(carattere != '+'){
                     if((j + pancake) <= strlen(stringa)){
                         contatore_giri++;
                         for(k = 0; k < pancake; k++){
                             char carattere2 = stringa[j + k];
                             if (carattere2 == '+'){
                                 stringa[j+k] = '-';
                             }else{
                                 stringa[j+k] = '+';
                             }
                         }
                     }else{
                         fprintf(output, "Case #%d: IMPOSSIBLE\n", contatore+1);
                         ciclo_attivo = 0;
                         break;
                     }
                 }
             }
             if(strcmp(stringa, stringa_finita) == 0){
                 fprintf(output, "Case #%d: %d\n", contatore+1, contatore_giri);
                 ciclo_attivo = 0;
                 break;
             }
         }
     }
     fclose(input);
     fclose(output);
     return 0;
 }

