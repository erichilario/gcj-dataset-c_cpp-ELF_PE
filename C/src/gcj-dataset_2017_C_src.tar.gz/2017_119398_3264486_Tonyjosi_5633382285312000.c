#include<stdio.h>
 void main()
 {
 	unsigned long int j=0,num,copy,count;
 	int tc,i=0,a,b,c;
 	scanf("%d",&tc);
 	for(i=0;i<tc;i++)
 	{
 		//printf("Hello\n");
 		scanf("%ld",&num);
 		for(j=num;j>=1;j--)
 		{
 			b=10;
 			c=0;
 			copy=j;
 			while(copy>0)
 			{
 				a=copy%10;
 				copy=copy/10;
 				if(b>=a)
 				{
 					b=a;
 				}
 				else
 				{
 					c=1;
 					break;
 				}
 			}
 			if(c==0)
 			{
 				count=j;
 				break;
 			}
 		}
 		printf("Case #%d: %ld\n",i+1,count);
 	}
 }
