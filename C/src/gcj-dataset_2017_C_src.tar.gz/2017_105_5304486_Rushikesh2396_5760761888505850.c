#include <stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int main()
 {
     int t,z=0;
     scanf("%d",&t);
     while(t--)
     {
         z++;
         int r, c;
         scanf("%d%d",&r,&c);
         char cake[26][26];
         int i,j,k,l;
         for(i=0;i<r;i++)
         {
             for(j=0;j<c;j++)
                 scanf(" %c",&cake[i][j]);
         }
 
         int rr=0,rl=0,cr=0,cl=0;
         char x;
         for(i=0;i<r;i++)
         {
             for(j=0;j<c;j++)
             {
 
                 if(cake[i][j] != '?')
                 {
                     rr = 0;
                     rl = 0;
                     x = cake[i][j];
                     for(k=j+1;k<c;k++)
                     {
                         if(cake[i][k] == '?')
                         {
                             rr++;
                         }
                         else
                             break;
                     }
                    // printf("%d",rr);
                     for(k=j-1;k>=0;k--)
                     {
                         if(cake[i][k] == '?')
                         {
                             rl++;
                         }
                         else
                             break;
                     }
                     for(k=j-rl;k<=j+rr;k++)
                     {
                         cake[i][k] = x;
                     }
                 }
             }
         }
         printf("Case #%d:\n",z);
         for(i=0;i<r;i++)
         {
             for(j=0;j<c;j++)
             {
                 if(cake[i][j]!='?')
                     printf("%c",cake[i][j]);
                 else
                 {
                     if(i>0)
                     {
                         for(k=i-1;k>=0;k--)
                         {
                             if(cake[k][j] != '?')
                                 break;
                         }
                         cake[i][j] = cake[k][j];
                         printf("%c",cake[k][j]);
                     }
                     else
                     {
 
                         for(k=i+1;k<c;k++)
                             if(cake[k][j] != '?')
                                 break;
                         cake[i][j] = cake[k][j];
                         printf("%c",cake[k][j]);
                     }
                 }
 
             }
             printf("\n");
         }
 
 
     }
 
 	return 0;
 }

