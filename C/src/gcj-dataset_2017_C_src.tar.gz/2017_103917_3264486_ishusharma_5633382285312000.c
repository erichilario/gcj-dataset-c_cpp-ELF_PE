#include<stdio.h>
 int main()
 {
     int t,n,i,j,k,l=1,m,b,h;
 
     freopen("C:\\Users\\raghav\\Desktop\\B-small-attempt4.in","r",stdin);
     freopen("C:\\Users\\raghav\\Desktop\\out.out","w",stdout);
     scanf("%d",&t);
 
     while(t--)
     {
         scanf("%d",&n);
         for(i=n;i>0;i--)
         {
             k=0;
             h=i;
             m=h%10;
             h=h/10;
            while(h!=0)
            {
                b=h%10;
                h=h/10;
               // printf("%d %d\n",m,b);
                if(m<b)
                {
                    k++;
                    break;
                }
                m=b;
            }
 
             if(k==0)
             {
                 printf("Case #%d: %d\n",l,i);
                 l++;
                 break;
             }
 
         }
     }
 }

