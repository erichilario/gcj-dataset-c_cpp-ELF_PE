#include<stdio.h>
 int po(int nn,int mm){
   int k=nn;
   for(int i=0;i<mm;i++){
     nn=nn*k;
   }
   return nn;
 }
 int main(){
   int t;
   scanf("%d",&t);
   int c=t;
   while(t--){
     int s;
     scanf("%d",&s);
     if (s<10){
       printf("Case #%d: %d\n",c-t,s);
     }
     else {
       int count =1;
       int res=0;
       int num=0;
       int sum=s;
       while(s>=(po(10,num))){
         num++;
         //printf("%d\n",num);
       }
       num=num+1;
       for(int i=0;i<num;i++){
         if ((s%10)<((s%100)/10)){
           res=count;
           count++;
           s=s-(s%(po(10,res-1))+1);
           //printf("if %d\n",count);
         }
         else {
           count++;
         //  printf("else %d\n",count);
         }
         s=s/10;
       }
       if (res!=0)
          sum = sum - (sum%(po(10,res-1))+1);
       printf("Case #%d: %d\n",c-t,sum);
     }
   }
   return 0;
 }

