#include <stdio.h>
 
 // Google Code Jam 2017 - Problem B. Tidy Numbers
 // Antonio Prado, 2017
 
 // Objetivo: encontrar último número tidy.
 
 int main(){
     long unsigned int T, N, candidato;
     long unsigned int i, ultimo_digito, sucesso;
 
     scanf("%d", &T); // Número de casos de teste
 
     for (i=0; i<T; i++){
         scanf("%d\n", &N); // Último número contado
         while (N > 0){
             candidato = N;
             sucesso = 1;
             while (candidato > 0){
                 ultimo_digito = candidato % 10;
                 candidato = candidato / 10;
                 if ((candidato % 10) <= ultimo_digito ){
                     ultimo_digito = candidato % 10;
                 }
                 else{
                     sucesso = 0;
                     break;
                 }
             }
             if (sucesso == 1){
                 printf("Case #%d: %d\n", i+1, N);
                 break;
             }
             N = N - 1;
        }
     }
 }

