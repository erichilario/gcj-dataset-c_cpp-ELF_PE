#include<stdio.h>
 #include<math.h>
 
 int main()
 {
     int z;
     scanf("%d",&z);
     long long int n=0;
     while(n<z)
     {
         int num,newNum=0,count=1;
         scanf("%d",&num);
         int star=num%10;
         newNum=star;
         num/=10;
         while(num!=0)
         {
             int a=num%10;
             if(a>star)
             {
                 newNum=a-1;
                 if(newNum<0)
                     newNum=9;
                 int count1=count;
                 while(count1--)
                 {
                     newNum*=10;
                     newNum+=9;
                 }
                 star=a-1;
             }
             else{
             newNum +=pow(10,count)*(a);
             star=a;
                 
             }
             count++;
             num/=10;
         }
         
         printf("Case #%lld: %d\n",n+1,newNum);
         
         n++;
         
     }
     
     
     return 0;
 }

