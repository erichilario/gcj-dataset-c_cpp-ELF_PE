/*
    ============================================================================
 Name        : Code.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
  */
 #include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 
 //char max_digit(char* number, int* pos){
 //	int i = 0 ;
 //	char max_digit = '0';	
 //	while(number[i] != '\0'){
 //		if(number[i] >= max_digit){
 //			max_digit = number[i];
 //			*pos = i;
 //		}
 //		++i;
 //	}
 //	return max_digit;
 //}
 
 bool is_tidy(long long number){
 	int max_digit = number %10;
 	while(number != 0){
 		int digit = number  % 10;
 	//	printf("digit ->%d\n",digit);
 		number = number / 10;
 		if(digit > max_digit) return false;
 		else max_digit = digit;
 	}
 	return true;
 } 
 
 int main(void){
 	int t = 1; int N,T;
 	//char* number = (char*) malloc(20*sizeof(char));
 	long long number = 0;
 	scanf("%d",&T);
 	for (t=1;t<=T;t++) {
 		scanf("%lld",&number);
 		//long long  pos = 1000000000000000000;
 		//char max = max_digit(number,&pos);
 		while(!is_tidy(number)) number--;	
 		printf("Case #%d: %lld\n",t,number);
 		//printf("%lld\n", pos);
 	}
 	//free(number);
 	return 0;
 }

