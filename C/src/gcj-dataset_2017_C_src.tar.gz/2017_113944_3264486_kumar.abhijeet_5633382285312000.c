#include <stdio.h>
 #include <string.h>
 #include <math.h>
 #include <stdlib.h>
 
 
 
 int main()
     {
     int t,k;
     scanf("%d",&t);
 
     for(k=1;k<=t;k++){
     char s[20];
     scanf("%s",s);
     int l=strlen(s);int ctr=0,flag=0;int i=0,j=0;
     do{
         for(i=0;i<l-1;i++)
             {
             if(s[i]>s[i+1])
                 {
                 s[i]=s[i]-1;
                 for(j=i+1;j<l;j++) s[j]='9';
                 break;
             }
         }
         
             ctr=0;
     for(i=0;i<l-1;i++){
         if(s[i]<=s[i+1]) ctr++;
     }
         if (ctr==l-1){ flag=1; if (s[0]!='0') printf("Case #%d: %s\n",k,s);
                       else { printf("Case #%d: ",k);for(i=1;i<l;i++) printf("%c",s[i]);printf("\n");};}
             else flag =0;
         }while(flag==0);
     
     }}

