#include<stdio.h>
 int main()
 {int a,h=0;
     scanf("%d",&a);
     while(h<a)
     {
         unsigned long long x;int i=0;int a[50];int flag=0;int j=0;int pos=0;int b=0;
     scanf("%llull",&x);
 while(x!=0)
 {
     a[i]=x%10;
     x=x/10;
     i++;
 }
     for (j=i-2; j>=0; j--) {
         if(a[j]<a[j+1]&&flag==0)
         {b=j+1;
             while(a[b]==a[b+1]&&(b)!=i)
         {
           if(a[b+2]<a[b+1])
           {
               a[b+1]=a[b+1]-1;flag=1;pos=b+1;
           }b++;
         }if(flag==0){a[j+1]=a[j+1]-1;flag =1;pos=j+1;}}
         if(flag==1)
             a[j]=9;
     }
     if(a[i-1]==0)
         flag=0;
     else
         flag=1;
         printf("Case #%d: ",h+1);
     for (j=i-1; j>=0; j--) {
         if(a[j]==0&&flag==0)
             flag=0;
         else
             flag=1;
         if(flag==1){
             if(j>=pos)
             printf("%d",a[j]);
             else printf("9");}
     }printf("\n");
         h++;}}

