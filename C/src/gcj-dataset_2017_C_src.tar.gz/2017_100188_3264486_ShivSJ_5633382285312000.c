#include<stdio.h>
 #include<stdlib.h>
 
 int check(int );
 int tidy(int );
 
 void main()
 {
     int t;
     scanf("%d",&t);
     int n;
     int i=0;
     for(i=0;i<t;i++){
         scanf("%d",&n);
         printf("Case #%d:",i+1);
         printf(" %d\n",tidy(n) );
     }
 }
 
 int tidy(int n)
 {
     while(!check(n)) n--;
     return n;
 }
 
 int check(int n)
 {
     while(n>0){
         if(n%10 < ((n/10)%10) ) return 0;
         n=n/10;
     }
     return 1;
 }

