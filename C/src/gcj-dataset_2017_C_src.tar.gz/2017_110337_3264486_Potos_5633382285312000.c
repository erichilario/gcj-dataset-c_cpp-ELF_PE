#include <stdio.h>
 #include <stdlib.h>
 
 int istidy(int k){
 	int fromlast;
 	int last = k % 10;
 	k = k / 10;
 	while(k>0){
 		fromlast = k % 10;
 		if (fromlast > last)
 			return 0;
 		last = fromlast;
 		k = k / 10;
 	}
 	return 1;
 }
 
 int main(){
 	int T,i;
 	scanf("%d", &T);
 	for (i=1;i<=T;i++){
 		int N;
 		scanf("%d", &N);
 		int j;
 		for(j=N;j>=1;j--){
 			if (istidy(j))
 				break;
 		}
 		printf("Case #%d: %d\n",i,j);
 	}
 	return 0;
 }
