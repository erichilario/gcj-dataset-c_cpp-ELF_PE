/* ************************************************************************** */
 /*                                                                            */
 /*                                                        :::      ::::::::   */
 /*   mikim42_a.c                                        :+:      :+:    :+:   */
 /*                                                    +:+ +:+         +:+     */
 /*   By: mikim <mikim@student.42.us.org>            +#+  +:+       +#+        */
 /*                                                +#+#+#+#+#+   +#+           */
 /*   Created: 2017/04/07 17:06:28 by mikim             #+#    #+#             */
 /*   Updated: 2017/04/07 19:24:19 by mikim            ###   ########.fr       */
 /*                                                                            */
 /* ************************************************************************** */
 
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 void	check_happy(char *s, int x, int cnt)
 {
 	int i;
 
 	i = -1;
 	while (s[++i] != '\0')
 		if (s[i] == '-')
 		{
 			printf("Case #%d: IMPOSSIBLE\n", x);
 			return ;
 		}
 	printf("Case #%d: %d\n", x, cnt);
 }
 
 int		check_flipable(char *s, int k)
 {
 	int i;
 
 	i = -1;
 	while (++i < k)
 		if (s[i] == '+')
 			break ;
 	if (i == k)
 		return (1);
 	return (0);
 }
 
 int		check_possible(char *s, int k)
 {
 	int	i;
 	int	cnt;
 	int	possible;
 
 	i = -1;
 	cnt = 0;
 	possible = 0;
 	while (s[++i] != '\0')
 	{
 		cnt += (s[i] == '-' ? 1 : 0);
 		if (i + k <= (int)strlen(s))
 			possible += (check_flipable(s + i, k));
 	}
 	if (cnt == k && possible == 1)
 		return (1);
 	return (0);
 }
 
 int		check_valid(char *s, int k, int x)
 {
 	int i;
 	int	tmp;
 
 	i = -1;
 	tmp = 0;
 	while (s[++i] != '\0')
 	{
 		tmp = (tmp == 0 ? s[i] : tmp);
 		if (tmp != s[i])
 			break ;
 		if (s[i + 1] == '\0' && tmp == '+')
 			return (printf("Case #%d: 0\n", x));
 		else if (s[i + 1] == '\0' && tmp == '-' && k == (int)strlen(s))
 			return (printf("Case #%d: 1\n", x));
 	}
 	if (k >= (int)(strlen(s) / 2) + (int)(strlen(s) % 2))
 	{
 		if (check_possible(s, k))
 			return (printf("Case #%d: 1\n", x));
 	}
 	return (0);
 }
 
 int		flip(char *s, int k)
 {
 	int i;
 
 	i = -1;
 	while (++i < k)
 		s[i] = (s[i] == '+' ? '-' : '+');
 	return (1);
 }
 
 void	flips(char *s, int k, int x)
 {
 	int i;
 	int cnt;
 
 	cnt = 0;
 	if (check_valid(s, k, x) != 0)
 		return ;
 	i = -1;
 	while (s[++i + k - 1] != '\0')
 	{
 		if (s[i] == '-' ? flip(s + i, k) : 0)
 		{
 			i = -1;
 			cnt++;
 		}
 	}
 	check_happy(s, x, cnt);
 }
 
 int		main(void)
 {
 	char	s[10000];
 	int		t, t_i, k;
 
 	scanf("%d", &t);
 	t_i = -1;
 	while (++t_i < t)
 	{
 		scanf("%s %d", s, &k);
 		flips(s, k, t_i + 1);
 	}
 }

