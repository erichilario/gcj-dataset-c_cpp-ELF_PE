#include <stdio.h>
 #include <string.h>
 
 int s, l, k;
 int total, mask;
 
 /*void print(int st) {
 	int i;
 	for(i = l-1; i >= 0; i--) {
 		putchar(((st >> i) & 1)? '+' : '-');
 	}
 }*/
 
 int mem[1100];
 #define EMPTY -1
 #define NONE -2
 #define WORKING -3
 
 int flip(int state, int count) {
 	//if(count > 0 && state == s) return -1;
 	//static int exec = 1;
 	//printf("%d<%d>: %d, %d, ", exec++, count, state, mem[state]);print(state);putchar('\n');
 	if(mem[state] >= 0 || mem[state] == NONE) return mem[state];
 	if(state == total) return count;
 	int min = NONE;
 	int i, n;
 	int m;
 	if(mem[state] == WORKING) return NONE;
 	mem[state] = WORKING;
 	for(i = 0, m = mask; i <= l - k; i++, m <<= 1) {
 		//if(mem[state ^ m] == 0) continue;
 		n = flip(state ^ m, count + 1);
 		if(n != NONE) {
 			min = (min == NONE || n + 1 < min)? n + 1 : min;
 		}
 	}
 	return mem[state] = min;
 }
 
 int main() {
 	int t, cs;
 	int i;
 	char c;
 
 	scanf("%d", &t);
 	for(cs = 1; cs <= t; cs++) {
 		s = 0;
 		l = 0;
 		while((c = getchar()) != '+' && c != '-');
 		while(c == '+' || c == '-') {
 			s <<= 1;
 			s |= (c == '+')? 1 : 0;
 			l++;
 			c = getchar();
 		}
 		memset(mem, EMPTY, sizeof(int) * (1 << l));
 		scanf("%d", &k);
 		mask = 0;
 		total = 0;
 		for(i = 0; i < k; i++) {
 			mask <<= 1;
 			mask |= 1;
 			total <<= 1;
 			total |= 1;
 		}
 		for(; i < l; i++) {
 			total <<= 1;
 			total |= 1;
 		}
 
 		mem[total] = 0;
 		i = flip(s, 0);
 
 		printf("Case #%d: ", cs);
 		if(i == NONE) {
 			printf("IMPOSSIBLE\n");
 		} else {
 			printf("%d\n", i);
 		}
 		/*for(i = 0; i <= total; i++) {
 			putchar('[');
 			print(i);
 			printf("]:%d\n", mem[i]);
 		}*/
 	}
 }
