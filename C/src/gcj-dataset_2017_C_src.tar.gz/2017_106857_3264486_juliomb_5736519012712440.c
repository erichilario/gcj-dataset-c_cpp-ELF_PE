#include <stdio.h>
 #include <string.h>
 
 int main() {
     int n, k, i, j, m, flips, valid, len;
     char seq[1234];
     scanf("%d", &n);
     for(i = 0; i < n; ++ i) {
         scanf("%s %d", seq, &k);
         flips = 0;
         len = strlen(seq); 
         for(j = 0; j < len - k + 1; ++ j) {
             if(seq[j] == '-') {
                 ++ flips;
                 for(m = 0; m < k; ++ m)  
                     if(seq[j + m] == '-') {
                         seq[j + m] = '+';
                     } else
                         seq[j + m] = '-';
             }
         }
         valid = 1;
         for(j = 0; j < len; ++ j)
             if(seq[j] == '-')
                 valid = 0;
         printf("Case #%d: ", i + 1);
         if (valid)
             printf("%d\n", flips);
         else
             printf("IMPOSSIBLE\n");
     }
     return 0;
 }

