#include <stdio.h>
 #include <math.h>
 int main(void) {
 	int t,i,j,k;
 	long long int num;
 	scanf("%d",&t);
 	for(i=1;i<=t;i++)
 	{
 		scanf("%lld",&num);
 		long long int res = num;
 		int tem = ((int ) log10(num));
 		int l = (int)(tem + 1);
 		int arr[l];
 		j=0;
 		while(num>0)
 		{
 			arr[j++] = num%10;
 			num/=10;
 		}
 		j = 0;
 		k = l-1;
 		while(j<k)
 		{
 			int temp = arr[j];
 			arr[j] = arr[k];
 			arr[k] = temp;
 			j++;
 			k--;
 		}
 		
 		int flag = 0;
 		for(j=0; j < l-1; j++)
 		{
 			if(arr[j] > arr[j+1])
 			{
 				flag =1;
 				break;
 			}
 		}
 		if(flag==0)
 		{
 			printf("Case #%d: %lld\n",i, res);
 			continue;
 		}
 		//int f = 0;
 		for(j=0; j<l-1; j++)
 		{
 			if(arr[j] < arr[j+1])
 			continue;
 			else if(arr[j] == arr[j+1])
 			{
 				int c1 = j;
 				while(j < l && arr[j] == arr[c1])
 				j++;
 				if(arr[j] > arr[c1])
 				j--;
 				else
 				{
 					j--;
 					int c2 = j;
 					
 					if(arr[c1]==1)
 					{
 						int pkp;
 						arr[c1] = 0;
 						for(pkp = c1+1; pkp<l; pkp++)
 						arr[pkp] = 9;
 						j=pkp;
 						//continue;
 					}
 					
 					else
 					{
 						int pkp;
 						arr[c1] --;
 						for(pkp = c1+1; pkp<l; pkp++)
 						arr[pkp] = 9;
 						j=pkp;
 					}
 				}
 				
 			}
 			else
 			{
 				arr[j] --;
 				for(k = j+1 ; k < l ; k++)
 				arr[k] = 9;
 				j=k;
 			}
 		}
 		j = 0;
 		while(arr[j] <= 0)
 		j++;
 		printf("Case #%d: ", i);
 		while(j<l)
 		{
 			printf("%d",arr[j]);
 			j++;
 		}
 		printf("\n");
 	}
 	// your code goes here
 	return 0;
 }

