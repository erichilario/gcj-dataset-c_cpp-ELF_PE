#include <stdio.h>
 
 int main(int argc,char *argv[])
 	{
 	unsigned long long int num_tests,t,n,k;
 	unsigned long long int max,min,i,p,l,r;
 	
 	scanf("%u\n",&num_tests);
 	
 	for(t=0;t<num_tests;t++)
 		{
 		scanf("%llu %llu\n",&n,&k);
 		min=n;max=0;
 		
 		while((k)&&(k!=n))
 			{
 			fprintf(stderr,"%llu %llu ",k,n);
 			l=n/2;
 			r=(n-1)-l;
 			fprintf(stderr,"%llu %llu\n",l,r);
 			
 			if((k % 2)&&(k>1))
 				{
 				n=(l>=r ? r : l);
 				}
 			else
 				{
 				n=(l>=r ? l : r);
 				}
 			k=k/2;
 			}
 		if(k==n)
 			{
 			fprintf(stderr,"%d %d\n",k,n);
 			max=min=0;
 			}
 		else
 			{
 			max=(l > r ? l : r);
 			min=(l > r ? r : l);
 			}
 		printf("Case #%u: %u %u\n",t+1,max,min);
 		}
 	}

