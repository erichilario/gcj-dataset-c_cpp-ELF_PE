/* ************************************************************************** */
 /*                                                                            */
 /*                                                        :::      ::::::::   */
 /*   alphacake.c                                        :+:      :+:    :+:   */
 /*                                                    +:+ +:+         +:+     */
 /*   By: mikim <mikim@student.42.us.org>            +#+  +:+       +#+        */
 /*                                                +#+#+#+#+#+   +#+           */
 /*   Created: 2017/04/14 18:07:02 by mikim             #+#    #+#             */
 /*   Updated: 2017/04/14 20:13:54 by mikim            ###   ########.fr       */
 /*                                                                            */
 /* ************************************************************************** */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 void	destroy(char **k, int r)
 {
 	int i;
 
 	i = -1;
 	while (++i < r)
 		free(k[i]);
 	free(k);
 	k = NULL;
 }
 
 int		cmp(char *s, int len)
 {
 	int i;
 
 	i = -1;
 	while (++i < len)
 		if (s[i] != '?')
 			return (0);
 	return (1);
 }
 
 void	print_out(char **k, int casenum)
 {
 	int i;
 
 	printf("Case #%d:\n", casenum);
 	i = -1;
 	while (k[++i])
 		printf("%s\n", k[i]);
 }
 
 void	check_right(char **k, int r, int c)
 {
 	int y;
 	int x;
 
 	y = -1;
 	while (++y < r)
 	{
 		x = -1;
 		while (++x < c - 1)
 		{
 			if (k[y][x] == '?' && k[y][x + 1] != '?')
 			{
 				k[y][x] = k[y][x + 1];
 				x = -1;
 			}
 		}
 	}
 }
 
 void	check_up(char **k, int r, int c)
 {
 	int		y;
 	int		x;
 	int		i;
 	int		j;
 	char	tmp;
 
 	y = -1;
 	while (++y < r)
 	{
 		x = -1;
 		while (++ x < c)
 		{
 			if (k[y][x] != '?')
 			{
 				tmp = k[y][x];
 				i = 0;
 				while (x + i < c && k[y][x + i] == tmp)
 					i++;
 				j = 1;
 				while (y - j >= 0 && cmp(k[y - j] + x, i))
 					strncpy(k[y - j++] + x, k[y] + x, i);
 				x += i - 1;
 			}
 		}
 	}
 }
 
 void	check_down(char **k, int r, int c)
 {
 	int		y;
 	int		x;
 	int		i;
 	int		j;
 	char	tmp;
 
 	y = -1;
 	while (++y < r)
 	{
 		x = -1;
 		while (++ x < c)
 		{
 			if (k[y][x] != '?')
 			{
 				tmp = k[y][x];
 				i = 0;
 				while (x + i < c && k[y][x + i] == tmp)
 					i++;
 				j = 1;
 				while (y + j < r && cmp(k[y + j] + x, i))
 					strncpy(k[y + j++] + x, k[y] + x, i);
 				x += i - 1;
 			}
 		}
 	}
 }
 
 void	check_left(char **k, int r, int c)
 {
 	int x;
 	int y;
 
 	y = r;
 	while (--y >= 0)
 	{
 		x = c;
 		while (--x > 0)
 		{
 			if (k[y][x] == '?' && k[y][x - 1] != '?')
 			{
 				k[y][x] = k[y][x - 1];
 				x = c;
 			}
 		}
 	}
 }
 
 int		check_finish(char **k, int r, int c)
 {
 	int x;
 	int y;
 
 	y = -1;
 	while (++y < r)
 	{
 		x = -1;
 		while (++x < c)
 		{
 			if (k[y][x] == '?')
 				return (1);
 		}
 	}
 	return (0);
 }
 
 void	solve(char **k, int r, int c, int casenum)
 {
 	while (check_finish(k, r, c))
 	{
 		check_right(k, r, c);
 		check_down(k, r, c);
 		check_up(k, r, c);
 		check_left(k, r, c);
 	}
 	print_out(k, casenum);
 }
 
 int		main(void)
 {
 	int t, t_i = -1;
 	int r, c;
 	char **k;
 	
 	scanf("%d", &t);
 	while (++t_i < t)
 	{
 		scanf("%d %d", &r, &c);
 		k = (char**)malloc(sizeof(char*) * r + 1);
 		k[r] = 0;
 		int k_i = -1;
 		while (++k_i < r)
 		{
 			k[k_i] = (char*)malloc(sizeof(char) * c + 1);
 			scanf("%s", k[k_i]);
 		}
 		solve(k, r, c, t_i + 1);
 		destroy(k, r);
 	}
 	return (0);
 }

