#include <stdio.h>
 #define N 1001
 
 char str[N];
 
 int main() {
 	int t; scanf("%d", &t);
 	for(int z = 1 ; z <= t ; z++) {
 		int k; scanf(" %s %d", str, &k);
 		int i; for(i = 0 ; str[i] != '\0' ; i++); int len = i;
 		int c = 0, ans = 0, no_flag = 0;
 		for(i = 0 ; str[i] != '\0' ; i++) {
 			// printf("%d : %s\n", i, str);
 			if(str[i] == '-') {
 				c++; // printf("%d %d\n", i, c);
 				if(c == k) { ans++; c = 0; }
 			}
 			else {
 				if(!c) continue;
 				if(len - i < k) { no_flag = 1; break; }
 				if(c == k) { ans++; c = 0; }
 				else {
 					c = k - c; int temp = i; ans++;
 					while(c--) if(str[temp] == '+') str[temp++] = '-'; else str[temp++] = '+';
 					c = 1;
 				}
 			}
 		}
 		if(c == k) ans++; else if(c && c < k) no_flag = 1;
 		printf("Case #%d: ", z);
 		no_flag ? printf("IMPOSSIBLE\n") : printf("%d\n", ans);
 	}
 	return 0;
 }
