#include<stdio.h>
 
 int main()
 {
   short t = 0;
   long long int n = 0;
   scanf("%hi", &t);
   short i = 0;
   for (i = 0; i < t; i++)
   {
     scanf("%lli", &n);
     do
     {
       short item_prev = n % 10;
       long long int x = n / 10;
       do
       {
         short item = x % 10;
         if (item > item_prev)
         {
           break;
         }
         item_prev = item;
         x = x / 10;
       } while (x);
       if ( x == 0 )
       {
         printf("Case #%d: %lli\n", i+1, n);
         break;
       }
     } while(n--);
   }
   return 0;
 }

