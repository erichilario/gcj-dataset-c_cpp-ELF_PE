#include <stdio.h>
 #include <stdlib.h>
 
 int handleCase() {
 	int buffer_size = 19;
 	char* buffer = calloc(buffer_size, sizeof(char));
 	fscanf(stdin, "%s\n", buffer);
 
 	int i;
 	for (i = 0; i < buffer_size; i++){
 		char current = buffer[i];
 		char next = buffer[i+1];
 		if (next && next <current)
 			break;
 	}
 	if (i< buffer_size)
 		for (; i >=0; --i) {
 			--buffer[i];
 			if(!i || buffer[i] >= buffer[i-1])
 				break;
 		}
 
 	for(i=i+1;i<buffer_size;++i) {
 		if (buffer[i])
 			buffer[i]='9';
 	}
 	fprintf(stdout, "%s", buffer + (buffer[0]=='0'));
 
 	free(buffer);
 	return 0;
 }
 
 void main () {
 	int ncases,i;
 	fscanf(stdin, "%i ", &ncases);
 
 	for(i=0; i<ncases; i++) {
 		fprintf(stdout, "Case #%i: ", i+1);
 		handleCase();
 		fprintf(stdout, "\n");
 	}
 }

