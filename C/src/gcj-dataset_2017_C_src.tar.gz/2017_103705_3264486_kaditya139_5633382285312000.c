#include<stdio.h>
 int main(){
     freopen("input.in","r",stdin);
     freopen("output.txt","w",stdout);
     int t,i,j,k,count;
     scanf("%d",&t);
     long long int n,temp;
     for(i=1;i<=t;i++){
         scanf("%lld",&n);
         int arr[20],arr1[20];
         for(j=0;j<20;j++)
             arr[j]=-1;
         temp=n;k=0;count=0;
         while(temp!=0){
             arr[k++]=temp%10;
             temp/=10;
             count++;
         }
         for(j=0;j<count-1;j++){
             for(k=j+1;k<count;k++){
                 int flag=0;
                 if(arr[k]==0){
                     int f;
                     for(f=k+1;f<count;f++){
                         if(arr[f]>0){
                             flag=1;break;
                         }
                     }
                 }
                 if(arr[k]>arr[j] || flag==1){
                     arr[j]=9;
                     if(arr[j+1]!=0)
                         arr[j+1]--;
                     else{
                         int m=j+1;
                         while(arr[m]==0)
                             arr[m++]=9;
                         arr[m]--;
                     }
                 }
             }
             j==0;
         }
         for(k=0;k<count-1;k++){
             if(arr[k]<arr[k+1]){
                 arr[k]=arr[k+1];
                 k=0;
             }
         }
         printf("Case #%d: ",i);
         if(arr[count-1]==0){
             for(j=0;j<count-1;j++)
                 arr1[count-j-2]=arr[j];
             for(j=0;j<count-1;j++)
                 printf("%d",arr1[j]);
             printf("\n");
         }
         else{
             for(j=0;j<count;j++)
                 arr1[count-j-1]=arr[j];
             for(j=0;j<count;j++)
                 printf("%d",arr1[j]);
             printf("\n");
         }
     }
     fclose(stdout);
 }

