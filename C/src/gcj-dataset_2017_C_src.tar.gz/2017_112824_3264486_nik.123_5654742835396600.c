#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 typedef long long int 	LL;
 
 #define si(n) scanf("%d",&n)
 #define dout(n) printf("%d\n",n)
 #define sll(n) scanf("%lld",&n)
 #define lldout(n) printf("%lld\n",n)
 #define FOR(i, a, b) for (int i = (a); i < (b); ++i)
 
 typedef struct node
 {
 	int Ls, Rs, min,max;
 }node;
 
 node T[1000010];
 
 int main()
 { 		
 	int x = 1;
 	int t;
 	si(t);
 	for(x=1;x<=t;x++)
 	{
 		int n,k;
 		si(n); si(k);
 		int i=0,j=0;
 		for(i=1;i<=n;i++)
 		{
 			{
 				T[i].Ls = i-1; 
 				T[i].Rs = n-i;
 				T[i].min = (T[i].Ls > T[i].Rs)? T[i].Rs:T[i].Ls;	
 				T[i].max = (T[i].Ls < T[i].Rs)? T[i].Rs:T[i].Ls;	
 			}
 		}
 		int max, min,Ians;
 		for(j=1;j<=k;j++)
 		{ 
 			max = -1, min = -1;
 			for(i=1;i<=n;i++)
 			{
 				if(T[i].min > min && T[i].Ls!=-1)
 				   min = T[i].min;
 			}
 			// printf("%d %d\n",max,min);
 			int flag=0, fmax=0, fmin=0, Imax, Imin;
 			for(i=1;i<=n;i++)
 			{
 				if(min == T[i].min)
 				{
 				    fmin++;				    
 				    Imin = i;
 				    if(T[i].max > max)
 				    {
 				    	max = T[i].max;
 				    }
 				}
 			}
 			if(fmin == 1)
 				Ians = Imin;
 			else 
 			{
 				for(i=1;i<=n;i++)
 				{
 					if(min == T[i].min && max == T[i].max)
 					{
 						if(flag == 0)
 						{
 							Ians = i;
 							flag = 1;
 						}
 					}
 				}
 			}
 			if(j == k)
 			{
 				break;
 			}
             
 			   	T[Ians].Ls = -1; 
 				T[Ians].Rs = -1;
 				T[Ians].min = 2000000000;
 				T[Ians].max = -1;
 		    
 			for(i=1;i<=n;i++)
 			{
 				if(i < Ians && T[i].Ls !=-1)
 				{
 					if(Ians - i - 1 < T[i].Rs)
 					{
 					   T[i].Rs = Ians - i -1;
 					   T[i].min = (T[i].Ls > T[i].Rs)? T[i].Rs:T[i].Ls;
 					   T[i].max = (T[i].Ls < T[i].Rs)? T[i].Rs:T[i].Ls;
 					}
 				}
 				else if(i > Ians && T[i].Ls !=-1)
 				{
 					if(i - Ians - 1 < T[i].Ls)
 					{
 					   T[i].Ls = i - Ians - 1;
 					   T[i].min = (T[i].Ls > T[i].Rs)? T[i].Rs:T[i].Ls;
 					   T[i].max = (T[i].Ls < T[i].Rs)? T[i].Rs:T[i].Ls;
 					}
 				}
 			}
 		}
 		printf("Case #%d: ",x);
 		printf("%d %d\n",T[Ians].max,T[Ians].min);
 	}
 	return 0;
 }
