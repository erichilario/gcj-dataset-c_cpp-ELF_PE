#include <stdio.h>
 
 int min (int x, int y){
 	if(x<=y){
 		return x;
 	}	
 	else{
 		return y;
 	}
 }
 
 int max(int x, int y){
 	if(x>=y){
 		return x;
 	}
 	else{
 		return y;
 	}
 }
 
 int main(void) {
 	int t;
 	scanf("%d\n",&t);
 	int n,k,i,j,p,b,val;
 	for(i=1;i<=t;i++){
 		scanf("%d %d\n",&n,&k);
 		int x[n][3];
 		for(j=0;j<n;j++){
 			x[j][0]=-1;
 			x[j][1]=j;
 			x[j][2]=n-j-1;
 			}
 		for(j=0;j<k;j++){
 			b=0;
 			while(x[b][0]!=-1){
 				b++;
 			}
 			val = min(x[b][1],x[b][2]);
 			for(p=b+1;p<n;p++){
 				if(x[p][0]==-1){
 					if (val == min(x[p][1],x[p][2])){
 						if(max(x[p][1],x[p][2]) > max(x[b][1],x[b][2])){
 							b=p;
 						}
 					}
 					else if(min(x[p][1],x[p][2]) > val){
 						b=p;
 						val = min(x[p][1],x[p][2]);
 					}
 				}
 			}
 			x[b][0]=1;
 			for(p=0;p<b;p++){
 				x[p][2]=min(x[p][2],b-p-1);
 			}
 			for(p=b+1;p<n;p++){
 				x[p][1]=min(x[p][1],p-b-1);
 			}
 		}
 		printf("Case #%d: %d %d\n",i,max(x[b][1],x[b][2]),min(x[b][1],x[b][2]));
 	}
 	return 0;
 }

