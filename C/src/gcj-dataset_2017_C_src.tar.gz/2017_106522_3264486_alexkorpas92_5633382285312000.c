#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int count_digits (unsigned long long int n) {
   int count = 0;
   while (n != 0)  {
     n /= 10;
     count++;
   }
 
   return count;
 }
 
 int* digit_array (unsigned long long int n, int d) {
   int* num = malloc(d * sizeof(int));
   while (n != 0){
     num[--d] = n % 10;
     n /= 10;
   }
   
   return num;
 }
 
 int main () {
   int i, j, T;
   
   if (scanf("%d\n", &T)) {};
   for (i = 0; i < T; i++) {
     unsigned long long int N;
     int digits;
     int *number;
     char input[50];
     
     if (fgets(input, sizeof(input), stdin)) {};
     sscanf(input, "%llu", &N);
     digits = count_digits(N);
 
     number = digit_array(N, digits);
     for (j = digits-1; j > 0; j--) {
       if (number[j] < number[j-1]) {
 	  int k;
 	  number[j-1]--;
 	  for (k = j; k < digits; k++)
 	    number[k]=9;
 	}
     }
     printf("Case #%d: ", i+1);
     for (j = 0; j < digits; j++)
       if (j!=0 || number[0]!=0)
 	printf("%d", number[j]);
     printf("\n");
   }
   return 0;
 }

