#include<stdio.h>
 int main()
 {
     int x[18],t,i=1,j=0,y,flag;
     long long int n;
     scanf("%d",&t);
     while(i<=t)
     {
         scanf("%lld",&n);
         flag=0;
         j=0;y=0;
         while(n)
         {
             x[j++]=n%10;
             n/=10;
         }
         y=--j;
         while(j>0)
         {
             if(x[j]>x[j-1])
             {
                 x[j]--;
                 x[j-1]=9;
                 flag=1;
             }
             j--;
             if(flag)
             {
                 while(j>=0)
                 {
                     x[j]=9;
                     j--;
                 }
             }
         }
         j=0;
         while(j<y)
         {
             if(x[j]<x[j+1])
             {
                 x[j]=9;
                 x[j+1]--;
             }
             j++;
         }
         if(x[y]==0)
             y--;
         printf("Case #%d: ",i);
         while(y>=0)
             printf("%d",x[y--]);
         printf("\n");
         i++;
     }
 }

