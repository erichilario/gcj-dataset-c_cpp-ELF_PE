#include<stdio.h>
 int tidy(int n)
 {
     int m=n;
     int count=0;
     int t2,t1;
     while(m!=0)
     {
         count++;
         m=m/10;
     }
     t1=n%10;
     while(n!=0)
     {
         n=n/10;
         t2=n%10;
         if(t2>t1)
             return 0;
         t1=n%10;
     }
     return 1;
 }
 void main()
 {
     int i,j,t;
     FILE *fp1;
     fp1=fopen("b.txt","w");
     scanf("%d",&t);
     int n[t],sol[t];
     for(i=1;i<=t;i++)
         scanf("%d",&n[i]);
     for(j=1;j<=t;j++)
     {
     for(i=n[j];i>=1;i--)
     {
         if(tidy(i))
         {
             sol[j]=i;
             break;
         }
     }
     }
     for(i=1;i<=t;i++)
         fprintf(fp1,"Case #%d: %d\n",i,sol[i]);
 }

