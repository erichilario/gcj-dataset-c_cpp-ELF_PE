#include<stdio.h>
 #include<string.h>
 
 char s[1001];
 
 void flip(int i,int n)
 {
 	int j;
 	for(j=i;j<i+n;j++)
 	{
 		if(s[j]=='+')
 		s[j]='-';
 		else
 		s[j]='+';
 	}
 }
 
 void main()
 {
 	int n,len,t,i,j,count,a[101];
 	scanf("%d",&t);
 	for(i=0;i<t;i++)
 	{
 		count=0;
 		scanf("%s",s);
 		scanf("%d",&n);
 		len=strlen(s);
 		for(j=0;j<len;j++)
 		{
 			if(s[j]=='-')
 			{
 				if(j+n>len)
 				{
 					count=-1;
 					break;
 				}
 				flip(j,n);
 				count++;
 			}
 		}
 		a[i]=count;
 	}
 	for(i=0;i<t;i++)
 	{
 		printf("Case #%d: ",i+1);
 		if(a[i]==-1)
 		printf("IMPOSSIBLE\n");
 		else
 		printf("%d\n",a[i]);
 	}
 }

