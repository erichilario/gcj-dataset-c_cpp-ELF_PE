#include<stdio.h>
 #include<math.h>
 FILE *in=NULL,*out=NULL;
 
 int lp(int a)
 {
     int c=0;
     while(a!=0)
     {
         a=a>>1;
         c++;
     }
     return c-1;
 }
 
 
 int ip(int n)
 {
     int c = pow(2,lp(n+1));
     if(c==n+1)
         return 1;
     return 0;
 }
 
 
 int count(int *a,int v,int n)
 {
     int i,c=0;
     for(i=0; i<n; i++)
     {
         if(a[i]==v)
             c++;
     }
     return c;
 }
 
 void f1(int n,int k,int cae)
 {
     int a1,m,i,c1,c2,j,res,h1,h = lp(n)+1;
     int **a,**r;
     a = (int**)malloc(h*sizeof(int*));
     for(i=0; i<h; i++)
     {
         j=pow(2,i);
         a[i] = (int*)malloc(sizeof(int)*j);
     }
 
     a[0][0]=n;
     for(i=1; i<h; i++)
     {
         m=pow(2,i);
         for(j=0; j<m; j+=2)
         {
             if(a[i-1][j/2]%2!=0)
             {
                 a[i][j]=(a[i-1][j/2]/2);
                 a[i][j+1]=(a[i-1][j/2]/2);
             }
             else
             {
                 a[i][j]=((a[i-1][j/2]/2) - 1);
                 a[i][j+1]=(a[i-1][j/2]/2);
             }
         }
     }
     h1= lp(k);
     i=k-pow(2,h1);
     res = a[h1][0];
     c1 = count(a[h1],res,pow(2,h1)+1);
     c2 = count(a[h1],res+1,pow(2,h1)+1);
 
     if(i<c2)
         res = res+1;
     if(res==0)
         fprintf(out,"Case #%d: 0 0\n",cae+1);
     else if(res%2==0)
         fprintf(out,"Case #%d: %d %d\n",cae+1,(res/2),(res/2)-1);
     else
         fprintf(out,"Case #%d: %d %d\n",cae+1,(res/2),res/2);
 }
 
 int main()
 {
     int t,a1,n,k,j,r;
     in = fopen("d2.in","r");
     out = fopen("d2.out","w");
     fscanf(in,"%d",&t);
     for(a1=0; a1<t; a1++)
     {
         fscanf(in,"%d %d",&n,&k);
         if(ip(n))
         {
             j = lp(k);
             r = (n)/(pow(2,j+1));
             fprintf(out,"Case #%d: %d %d\n",a1+1,r,r);
         }
         else if(n>k)
             f1(n,k,a1);
         else
             fprintf(out,"Case #%d: 0 0\n",a1+1);
     }
     fclose(in);
     fclose(out);
     return 0;
 }
 

