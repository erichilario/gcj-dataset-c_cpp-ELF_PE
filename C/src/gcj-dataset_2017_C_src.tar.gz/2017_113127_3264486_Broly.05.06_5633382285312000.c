#include <stdio.h>
 #define ll long long 
 
 char str[20];
 
 int main() {
 	int t; scanf("%d", &t);
 	int z;
 	for(z = 1 ; z <= t ; z++) {
 		scanf(" %s", str);
 		int i; for(i = 0 ; str[i] != '\0' ; i++)
 		; int len = i;
 		ll ans = str[len - 1] - '0', tp = 1;
 		for(i = len - 2 ; i >= 0 ; i--) {
 			tp *= 10;
 			if(str[i] <= str[i + 1]) {
 				ll temp = tp / 10;
 				// printf("str[i] = %d ans = %lld temp = %lld\n", str[i] - '0', ans, temp);
 				if(str[i] - '0' > ans / temp) {
 					ans = (str[i] - '0' - 1) * tp + (tp - 1);
 				}
 				else ans = (str[i] - '0') * tp + ans;
 			}
 			else {
 				ans = (str[i] - '0' - 1) * tp + (tp - 1);
 			}
 		}
 		printf("Case #%d: %lld\n", z, ans);
 	}
 	return 0;
 }
