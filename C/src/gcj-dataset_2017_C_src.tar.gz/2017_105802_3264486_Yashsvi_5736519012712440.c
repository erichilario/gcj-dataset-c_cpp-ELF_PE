#include<stdio.h>
 #include<string.h>
 
 char anti(char ch)
 {
     if(ch=='+') return '-';
     return '+';
 }
 int main()
 {
     int t,i,T,k,l,j,moves,flag;
     FILE* f;
     FILE* ff;
     f=fopen("output.txt","w");
 
     fscanf(ff,"%d",&t);
     T=t;
     char a[1008];
     while(t--)
     {
         flag=1;
         moves=0;
         fscanf(ff,"%s",a);
         fscanf(ff,"%d",&k);
         l=strlen(a);
         for(i=0;i<=l-k;i++)
         {
             if(a[i]=='+')
                 continue;
             else
             {
                 moves++;
                 for(j=0;j<k;j++)
                 {
                     a[i+j]=anti(a[i+j]);
                 }
             }
         }
 
         for(j=0;j<k-1;j++)
         {
 
            if(a[l-1-j]=='-')
            {
                flag=0;
                break;
            }
         }
 
         if(flag==0)
             fprintf(f,"Case #%d: IMPOSSIBLE\n",T-t);
         else
             fprintf(f,"Case #%d: %d\n",T-t,moves);
     }
 }

