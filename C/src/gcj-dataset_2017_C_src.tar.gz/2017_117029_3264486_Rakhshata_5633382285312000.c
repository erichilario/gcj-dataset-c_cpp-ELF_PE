#include<bits/stdc++.h>
 using namespace std;
 typedef long long int ll;
 typedef unsigned long long int ull;
 const int MOD = 1000000007;
 #define op(x) (x&(-x))
 #define trace1(x)                cerr << #x << ": " << x << endl;
 #define trace2(x, y)             cerr << #x << ": " << x << " | " << #y << ": " << y << endl;
 #define trace3(x, y, z)          cerr << #x << ": " << x << " | " << #y << ": " << y << " | " << #z << ": " << z << endl;
 #define trace4(a, b, c, d)       cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << endl;
 #define trace5(a, b, c, d, e)    cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << endl;
 #define trace6(a, b, c, d, e, f) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << " | " << #f << ": " << f << endl;
 #define FOR(i,a,b) for(int i=a;i<b;i++)
 #define si(n) scanf("%d",&n)
 #define s2i(x,y) scanf("%d %d",&x,&y);
 #define s3i(x,y,z) scanf("%d %d %d",&x,&y,&z);
 #define s4i(x,y,z,w) scanf("%d %d %d %d",&x,&y,&z,&w);
 #define print(a,n) for(int i=0;i<n;i++) cout<<a[i]<<" "; cout<<endl;
 #define print2d(a,n,m) for(int i=0;i<n;i++) {for(int j=0;j<m;j++) cout<<a[i][j]<<" "; cout<<endl;}
 
 FILE *fin = freopen("B-small-attempt0.in","r",stdin);
 FILE *fout = freopen("out1","w",stdout);
 
 int val(char x){return x - '0';}
 bool istidy(string y)
 {
 	for(int i=1;i<y.length();i++)
 		if(val(y[i]) < val(y[i-1]))
 			return false;
 	return true;
 }
 
 int main()
 {
 	int t;
 	cin >> t;
 	FOR(T,1,t+1)
 	{
 		string x,y;
 		cin >> x;
 		cout << "Case #" << T << ": ";
 		if(istidy(x)) {cout << x << endl; continue ;}
 		for(int i=x.length()-1;i>=0;i--)
 		{
 			if(x[i] == '0') continue;
 			y = x;
 			for(int j=i+1;j<x.length();j++)
 				y[j] = '9';
 			y[i] = val(y[i]) - 1 + '0';
 			if(istidy(y)) break;
 		}
 		x = y;
 		if(x[0] == '0') x.erase(x.begin());
 		cout << x << endl;
 	}
 	return 0;
 }
