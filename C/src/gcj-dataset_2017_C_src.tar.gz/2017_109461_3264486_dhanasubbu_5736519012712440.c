#include <stdio.h>
 #include <errno.h>
 #include <string.h>
 #include <stdlib.h>
 
 #define BUFLEN  1024
 #define SMALL_S 10
 #define LARGE_S 1000
 #define T_LIMIT 100
 
 #ifdef DEBUG
     #define     LOG     fprintf
 #else
     #define     LOG
 #endif
 
 typedef int bool;
 enum { false, true };
 
 static bool S[1000];
 static int max_s;
 static FILE *fo;
 
 
 static void flip_pan(bool *s, int k_val) 
 {
     int i;
 
     for(i = 0; i < k_val; i++) {
         s[i] = (s[i])? false : true;
     }
     for (i = 0; i < max_s; i++) {
         LOG(fo, "%c ", S[i]? 'T' : 'F');
     }
     LOG(fo, "\n");
 }
 
 static void flip (int tc, bool *s, int max_s, int k_val, int flip_cnt)
 {
     int i = 0;
 
     if (max_s < k_val) {
         fprintf(fo, "Case #%d: IMPOSSIBLE\n", tc);
         return;
     }
     while(*s && max_s) {
         s++;
         max_s--;
     } 
     while(max_s && s[max_s-1]) {
         max_s--;
     }
 
     if (0 == max_s) {
         fprintf(fo, "Case #%d: %d\n", tc, flip_cnt);
         return;
     }
     if (max_s >= k_val) {
         LOG(fo, "Flipping front : ");
         flip_pan(s, k_val);    
         flip_cnt++;
         s++;
         max_s--;
     }
 
     if (max_s >= k_val) {
         LOG(fo, "Flipping back  : ");
         flip_pan(&s[max_s - k_val], k_val);
         flip_cnt++;
         max_s--;
     }
     if ( max_s < k_val) {
         int i;
         for(i = 0; i < max_s; i++) {
             if(s[i] == false) {
                 fprintf(fo, "Case #%d: IMPOSSIBLE\n", tc);
                 return;
             }
         }
         fprintf(fo, "Case #%d: %d\n", tc, flip_cnt);
         return;
     }
     flip(tc, s, max_s, k_val, flip_cnt);
 }
 
 main ()
 {
     FILE *fp = fopen("input.txt", "r");
     int tc = 0;
     int k_val;
     char buf[BUFLEN];
     
     if (fp == NULL) {
         LOG(fo, "Error opening input file %s\n", strerror(errno));
         exit(EXIT_FAILURE);
     }
     fo = fopen("output.txt", "w");
     if (fgets(buf, BUFLEN, fp) == NULL) {
         LOG(fo, "Error in reading number of test cases %s\n", strerror(errno));
         exit(EXIT_FAILURE);
     }
     LOG(fo, "Number of testcases %s\n", buf);
     sscanf(buf, "%d", &tc);
     if (tc > T_LIMIT) {
         LOG(fo, "No. of testcases > %d\n", T_LIMIT);
         exit(EXIT_FAILURE);
     }
         
     int line_no;
     for (line_no = 0; line_no <  tc; line_no++) {
         bool status = true;
         int i;
 
         if(fgets(buf, BUFLEN, fp) == NULL) {
             LOG(fo, "Error reading i/p (%d) - %s\n", line_no+1, strerror(errno));
             exit(EXIT_FAILURE);
         }
         LOG(fo, "Input line %d -> %s\n", line_no+1, buf);
 
         for(i = 0; buf[i] != ' '; i++){
            if (i == 1000) {
                 status = false; 
                 LOG(fo, "Input S is > 1000\n");
                 fprintf(fo, "Case #%d: IMPOSSIBLE\n", line_no+1);
                 break;
             }
             if (buf[i] != '+' && buf[i] != '-') {
                 status = false; 
                 LOG(fo, "TC %d has invalid input\n", i);
                 fprintf(fo, "Case #%d: IMPOSSIBLE\n", line_no+1);
                 break;
             }
             S[i] = (buf[i] == '+')? true : false;
         }
         if (status == false) {
             continue;
         }
         if (i < 2) {
             LOG(fo, "Lenght of S is %d\n", i);
             fprintf(fo, "Case #%d: IMPOSSIBLE\n", line_no+1);
             continue;
         }
             
         max_s = i;
         i += 1;
         sscanf(&buf[i], "%d", &k_val); 
         LOG(fo, "Length of S is %d & val of k is %d\n", max_s, k_val);
         
         flip(line_no+1, S, max_s, k_val, 0);
     } 
     fclose(fp);
 } 

