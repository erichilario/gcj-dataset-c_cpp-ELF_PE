#include<stdio.h>
 #include<process.h>
 char a[30][30],b[30][30];
 long long int l[30],l1[30];
 int main() {
    FILE * fp1, * fp2;
    long long int r,c,i,j,k,u,u1,t,f,p;
    fp1=fopen("C:\\Users\\subham7\\Downloads\\A-small-attempt1 (1).in", "r");
    fp2=fopen("E:\\file8.txt", "w");
    fscanf(fp1,"%lld",&t);
    for(i=1;i<=t;i++)
    {
    	fscanf(fp1,"%lld%lld",&r,&c);
    	f=1;
    	u1=0;
    	for(j=0;j<r;j++)
    	{
    		fscanf(fp1,"%s",a[j]);
    		u=0;
    		for(k=0;k<c;k++)
    		{
    			if(a[j][k]!='?')
    			{
    				l[u]=k;
    				u++;
 			}
 		}
 		p=0;
 		if(u==0)
 		{
 			if(f==0)
 			{
 			    for(k=0;k<c;k++)
 			    {
 				    b[j][k]=b[j-1][k];
 			    }
 			}
 			else
 			l1[u1++]=j;
 		}
 		else
 		{
 			f=0;
 			for(k=0;k<c;k++)
 			{
 				if(a[j][k]!='?')
 				{
 				    b[j][k]=a[j][l[p]];
 				    if(p!=(u-1))
 				    p=p+1;
 			    }
 			    else
 			    b[j][k]=a[j][l[p]];
 			}
 		}
 	}
 	for(j=u1-1;j>=0;j--)
 	{
 		for(k=0;k<c;k++)
 		{
 			b[l1[j]][k]=b[l1[j]+1][k];
 		}
 	}
 	fprintf(fp2,"Case #%d:\n",i);
 	for(j=0;j<r;j++)
 	{
 		for(k=0;k<c;k++)
 		fprintf(fp2,"%c",b[j][k]);
 		fprintf(fp2,"\n");
    	}
    }
    fclose(fp1);
    fclose(fp2);
    return 0;
 }

