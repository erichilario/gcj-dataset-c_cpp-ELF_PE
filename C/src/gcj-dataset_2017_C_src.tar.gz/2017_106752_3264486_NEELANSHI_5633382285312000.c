#include<stdio.h>
 
 int main()
 {
     long long int i=0,num;
     int x[18],n,t,l,j;
     scanf("%d",&t);
     for(l=1;l<=t;l++)
     {
         scanf("%lld",&num);
         for(i=17;num;i--)
         {
             x[i]=num%10;
             num/=10;
         }
         i++;
         n=i;
         for(i;i<17;i++)
         {
             if(x[i]>x[i+1])
             {
                 x[i]-=1;
                 for(j=i+1;j<18;j++)
                     x[j]=9;
                 break;
             }
         }
         for(i=17;i>n;i--)
         {
             if(x[i]<x[i-1])
             {
                 x[i]=9;
                 x[i-1]-=1;
             }
         }
         if(x[n]==0)
             n++;
         printf("Case #%d: ",l);
         for(i=n;i<18;i++)
             printf("%d",x[i]);
         printf("\n");
     }
 }

