#include<stdio.h>
 #include<limits.h>
 #include<string.h>
 #include<math.h>
 /*
 int main()
 {
     int i,j,k,z,l,m,s,n,t,flag;
     char a[1001];
     scanf("%d",&t);
     for(z=1;z<=t;z++)
     {
         flag=1;
         s=0;
     scanf("%s%d",&a,&k);
    // printf("%s%d",a,k);
     l=strlen(a);
     for(i=0;i<l;i++)
     {
         if(a[i]=='-')
         {
             s++;
             for(j=i;j<k+i&&i+k-1<l;j++)
             {
                 if(a[j]=='-')
                     a[j]='+';
                 else a[j]='-';
             }
 
         }
     }
     for(i=0;i<l;i++)
         if(a[i]=='-')
     {
 
         flag=0;
         break;
     }
     if(flag)
         printf("Case #%d: %d\n",z,s);
     else
     printf("Case #%d: IMPOSSIBLE\n",z);
 
     }
 
 }
 
 
 int main()
 {
 
     long long int i,j,k,s,z,t,l,m,n;
     long long int a[20];
     scanf("%lld",&t);
     for(z=1;z<=t;z++)
     {
 
         scanf("%lld",&n);
        for(j=0;j<=19;j++)
         a[j]=0;
        // for(j=0;j<=19;j++)
     //printf("%lld",a[j]);
     //printf("\n");
 
         i=19;
          while(n)
          {
 
              a[i--]=n%10;
              n=n/10;
          }
           //for(j=i;j<=19;j++)
     //printf("%lld",a[j]);
     //printf("\n");
 
          j=19;
          k=a[j--];
          while(j>i)
          {
              if(a[j]<=k)
                {
                    k=a[j];
                 j--;
                }
              else{
                 a[j]--;
                 k=a[j];
                 for(l=j+1;l<=19;l++)
                     a[l]=9;
 
              }
 
          }
          if(a[j]>k)
          {
              a[j]--;
            for(l=j+1;l<=19;l++)
                     a[l]=9;
 
          }
 
    //for(j=i;j<=19;j++)
     //printf("%lld",a[j]);
 
 
          s=0;
          for(j=i;j<=19;j++)
             s=s*10+a[j];
 
          printf("Case #%lld: %lld\n",z,s);
     }
 }
 
 */
 int main()
 {
     long long int i,j,k,l,flag,px,max,min,minnn,m,n,z,t,x,y;
     scanf("%lld",&t);
     for(z=1;z<=t;z++){
        flag=0;
         scanf("%lld%lld",&n,&k);
         x=1;
         px=0;
         max=n;
         minnn=n;
         y=0;
         //k-=x;
         /**if(n==4&&k==2)
         {
             max=1;
             min=0;
             printf("Case #%lld: %lld %lld\n",z,max,min);
             continue;
         }**/
         while(minnn>0&&k>0)
         {
 
            m=(minnn/2);
      // printf("%lld ",minnn);
 
 
            max=m;
            min=max-1;
             if(minnn%2)
              min++;
 
              if(y>=k)
            {
                k=0;
                if(minnn%2==0)
                min++;
               else max++;
                break;
            }
 
 
 
            if(minnn%2==0)
           {
           y+=x;
           }
             //printf("%lld\t  %lld\t %lld\t %lld\n",max,min,x,y);
            minnn=min;
           //printf("%lld %lld\n",max,minnn);
           k=k-x;
 
           px=x;
           x=x*2;
 
         }
         if(k>0)
             max=0;
          printf("Case #%lld: %lld %lld\n",z,max,min);
     }
 
 }
 

