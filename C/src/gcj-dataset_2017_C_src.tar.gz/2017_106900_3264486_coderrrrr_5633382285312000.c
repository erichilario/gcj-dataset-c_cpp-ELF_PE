#include<stdio.h>
 #include<limits.h>
 #include<string.h>
 /*
 int main()
 {
     int i,j,k,z,l,m,s,n,t,flag;
     char a[1001];
     scanf("%d",&t);
     for(z=1;z<=t;z++)
     {
         flag=1;
         s=0;
     scanf("%s%d",&a,&k);
    // printf("%s%d",a,k);
     l=strlen(a);
     for(i=0;i<l;i++)
     {
         if(a[i]=='-')
         {
             s++;
             for(j=i;j<k+i&&i+k-1<l;j++)
             {
                 if(a[j]=='-')
                     a[j]='+';
                 else a[j]='-';
             }
 
         }
     }
     for(i=0;i<l;i++)
         if(a[i]=='-')
     {
 
         flag=0;
         break;
     }
     if(flag)
         printf("Case #%d: %d\n",z,s);
     else
     printf("Case #%d: IMPOSSIBLE\n",z);
 
     }
 
 }
 */
 
 int main()
 {
 
     long long int i,j,k,s,z,t,l,m,n;
     long long int a[20];
     scanf("%lld",&t);
     for(z=1;z<=t;z++)
     {
 
         scanf("%lld",&n);
        for(j=0;j<=19;j++)
         a[j]=0;
         /*  for(j=0;j<=19;j++)
     printf("%lld",a[j]);
     printf("\n");
     */
         i=19;
          while(n)
          {
 
              a[i--]=n%10;
              n=n/10;
          }
           /*for(j=i;j<=19;j++)
     printf("%lld",a[j]);
     printf("\n");
     */
          j=19;
          k=a[j--];
          while(j>i)
          {
              if(a[j]<=k)
                {
                    k=a[j];
                 j--;
                }
              else{
                 a[j]--;
                 k=a[j];
                 for(l=j+1;l<=19;l++)
                     a[l]=9;
 
              }
 
          }
          if(a[j]>k)
          {
              a[j]--;
            for(l=j+1;l<=19;l++)
                     a[l]=9;
 
          }
          /*
    for(j=i;j<=19;j++)
     printf("%lld",a[j]);
     */
 
          s=0;
          for(j=i;j<=19;j++)
             s=s*10+a[j];
 
          printf("Case #%lld: %lld\n",z,s);
     }
 }
 

