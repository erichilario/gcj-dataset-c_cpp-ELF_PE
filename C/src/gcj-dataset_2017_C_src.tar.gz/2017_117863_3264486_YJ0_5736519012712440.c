#include <stdio.h>
 
 int N = 0;
 int K;
 char S[1024];
 int cnt;
 int bad;
 
 int main()
 {
     scanf("%d", &N);
     for (int n = 0; n < N; ++n)
     {
         scanf("%s %d", S, &K);
         cnt = 0;
         bad = 0;
         for (char *p = S; *p != '\0'; ++p) {
             if (*p == '-') {
                 ++cnt;
                 for (char *q = p; q < (p + K); ++q)
                 {
                     if (*q == '\0') {
                         bad = 1;
                         break;
                     } else if (*q == '-') *q = '+';
                     else *q = '-';
                 }
                 if (bad) break;
             }
         }
         if (!bad) printf("Case #%d: %d\n", n + 1, cnt);
         else printf("Case #%d: IMPOSSIBLE\n", n + 1);
     }
     return 0;
 }

