/*
    ============================================================================
 Name        : Code.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
  */
 #include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 
 bool flip(char* c, int K){
 	for(int i = 0 ; i < K; ++i ){
 		if(c[i] == '\0') return false;
 		if(c[i]=='-') c[i]='+';
 		else if(c[i] == '+') c[i] = '-';	
 	}
 	return true;
 }
 
 int main(void){
 	int t = 1; int T; int K;
 	char* str = (char*) malloc(1001*sizeof(char));
 	scanf("%d",&T);
 	for (t=1;t<=T;t++) {
 		scanf("%s %d",str,&K);
 		int i = 0;
 		int n = 0;
 		while(str[i] != '\0'){
 			if(str[i] == '-'){
 				if(flip(&str[i],K))	++n;
 				else {
 					n = -1;
 					break;
 				}
 				//printf("%s\n",str);
 			}
 			i++;
 		}
 		//printf("Case #%d: %s %d %d\n",t,str,K, n);
 		if(n == -1) 
 		printf("Case #%d: IMPOSSIBLE\n",t);
 		else
 		printf("Case #%d: %d\n",t,n);
 
 	}
 	free(str);
 	return 0;
 }

