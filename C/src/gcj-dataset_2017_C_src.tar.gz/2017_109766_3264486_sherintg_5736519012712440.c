#include <stdio.h>
 #include <string.h>
 int main()
 {
 	int T, K, len, i, j , count;
 	char S[1000], *ptr;
 	scanf("%d\n", &T);
 	for(i=1;i<=T;i++) {
 		scanf("%s %d\n", S, &K);
 		len = strlen(S);
 		ptr = S;
 		count = 0;
 		while (ptr < &S[len-1]) {
 			ptr = strchr(ptr, '-');
 			if (ptr == NULL) {
 				printf("Case #%d: %d\n", i, count);
 				break;;
 			}
 			if (strlen(ptr) < K) {
 				printf("Case #%d: IMPOSSIBLE\n", i);
 				break;;
 			}
 			for(j=0;j<K;j++) {
 				if (ptr[j] == '-')
 					ptr[j] = '+';
 				else
 					ptr[j] = '-';
 			}
 			count++;
 		}
 	}
 }

