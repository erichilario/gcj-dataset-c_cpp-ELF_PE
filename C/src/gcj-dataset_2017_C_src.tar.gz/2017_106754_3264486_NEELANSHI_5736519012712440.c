#include <stdio.h>
 int main()
 {
     int T,K=2,n=0,j,i,c=0,l=1;
     char S[1001];
     scanf("%d",&T);
     while(l<=T)
     {
         n=0;
         c=0;
         fflush(stdin);
         scanf("%s",S);
         scanf("%d",&K);
         while(S[n]!='\0')
         {
             n++;
         }
         for(i=0; i<=n-K; i++)
         {
             if(S[i]=='-')
             {
                 for(j=0; j<K; j++)
                 {
                     if(S[i+j]=='-')
                         S[i+j]='+';
                     else
                         S[i+j]='-';
                 }
                 c++;
             }
         }
         while(i<n)
         {
             if(S[i]=='-')
                 break;
             i++;
         }
         if(i==n)
             printf("\n Case #%d: %d",l,c);
         else
             printf("\n Case #%d: IMPOSSIBLE",l);
         l++;
     }
 return 0;
 }
 
 

