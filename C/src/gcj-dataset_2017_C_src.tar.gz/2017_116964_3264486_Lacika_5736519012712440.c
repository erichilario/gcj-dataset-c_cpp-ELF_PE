#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int nrZeros(char x[]){
     int i;
     int len;
     int counter =0;
     len=strlen(x);
     for(i=0;i<len;i++){
         if(x[i]=='-')
             counter++;
     }
     return counter;
 }
 int main()
 {
     int nrT, k, nrC = 1, i, j, len,  contor, zeros = 0, ok = 0, r;
     char x[1001];
     FILE* f, *df;
     if((f=fopen("A-large.in", "r"))==NULL){
         perror("A-large.in");
         exit(0);
     }
     if((df=fopen("output.in", "w"))==NULL){
         perror("output.in");
         exit(0);
     }
     fscanf(f, "%d", &nrT);
     while(nrT--)
     {
         contor = 0;
         x[0]='\0';
         fscanf(f, "%s", x);
      //   printf("%s %d\n", x, nrZeros(x));
         fscanf(f, "%d", &k);
         len= strlen(x);
         ok =1;
         while(nrZeros(x)!=0 && ok ==1)
         {
             ok=0;
             zeros = 0;
             for(i=0; i<=len-k; i++)
             {
                 if(x[i]=='-')
                 {
                     for(j=i; j<i+k; j++)
                     {
                         x[j]= x[j]=='+'?'-':'+';
                     }
                     ok=1;
                     contor++;
                 }
             }
 
             zeros=nrZeros(x);
             //printf("zeros = %d\n", zeros);
             if(zeros==1) break;
 
             zeros=0;
             for(i=len-1; i>=k && i-k>=0; i--)
             {
                 if(x[i]=='-')
                 {
                     for(j=i; j>i-k; j--)
                     {
                         x[j]= x[j]=='+'?'-':'+';
                     }
                     ok=1;
                     contor++;
                   //  printf("x= %d", 2);
                 }
             }
             zeros=nrZeros(x);
           //  printf("zeros = %d\n", zeros);
             if(zeros==1) break;
             if(zeros<k)
             for(i=0;i<len;i++){
                 if(x[i]=='-'){
                     r=0;
                     for(j=i;j<i+zeros;j++)
                         if(x[j]=='+')
                             r=1;
                     if(r==0)
                         ok=0;
                     break;
                 }
             }
          //  _sleep(100);
         }
 
 
 
         if((zeros==1 || ok == 0) && nrZeros(x)!=0)
         {
             fprintf(df, "Case #%d: IMPOSSIBLE\n", nrC);
         }
         else
         {
             fprintf(df, "Case #%d: %d\n", nrC, contor);
 
         }
 
         nrC++;
 
     }
     return 0;
 }

