#include <stdio.h>
 
 
 int check( long num){
 	long  l = num%10;
 	while(num != 0){
 		if((num%10) > l){
 			return 0;
 		}
 		l = num%10;
 		num /=10;
 	}
 	return 1;
 }
 
 int main(){
 	int n,i;
 	scanf("%d",&n);
 	long  num,t;
 
 	for ( i = 0; i < n; ++i)
 	{	
 		scanf("%ld",&num);
 		t = 10;
 		while(!check(num)){
 			num = (((num/t) - 1)*t) + t - 1;
 			t *= 10;
 		}
 		printf("Case #%d: %ld\n",i+1,num );
 	}
 	return 0;
 }
