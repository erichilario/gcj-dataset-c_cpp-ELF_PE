//
 //  main.c
 //  gcj2017_qualification_B
 //
 //  Created by Kookheon Kim on 2017. 4. 8..
 //  Copyright © 2017년 heonie. All rights reserved.
 //
 
 #include <stdio.h>
 #include <string.h>
 
 int decrease(char *N, int p, int n) {
     int a;
     if(p < 0) {
         return 0;
     }
     if(N[p]-'0' < n) {
         a = decrease(N, p-1, 1);
         if(a == 0) {
             return 0;
         }
         N[p] = N[p] + 10 - n;
     }
     else {
         N[p] -= n;
     }
     return 1;
 }
 int checkTidyNum(const char *s, int until) {
     int i = 0;
     char min = '1';
     while(s[i] == '0') {
         i++;
     }
     for(; i<=until; i++) {
         if(s[i] < min) {
             return 0;
         }
         if(s[i] > min) {
             min = s[i];
         }
     }
     return 1;
 }
 
 int main(int argc, const char * argv[]) {
     int T, t, len, i, j;
     char sN[20];
     
     scanf("%d", &T);
     for(t=1; t<=T; t++) {
         scanf("%s", sN);
         len = (int)strlen(sN);
 
         j = len-1;
         while(j > 0) {
             if(checkTidyNum(sN, j)) {
                 break;
             }
             if(!decrease(sN, j, (sN[j]-'0')+1)) {
                 break;
             }
             if(sN[j] == '9') {
                 j--;
             }
         }
         
         printf("Case #%d: ", t);
         j = 0;
         for(i=0; i<len; i++) {
             if(j == 1 || sN[i] > '0') {
                 j = 1;
                 printf("%c", sN[i]);
             }
         }
         printf("\n");
     }
     
     return 0;
 }

