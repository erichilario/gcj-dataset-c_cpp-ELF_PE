#include<stdio.h>
 #include<math.h>
 #include<string.h>
 #include<stdlib.h>
 long tidy(long n)
 {
     long count=0;
     if(n%10 >=(n/10)%10 && (n/10)%10 >= n/100)
         count=1;
     return count;
 }
 long main()
 {
     long t,i;
     scanf("%ld",&t);
     for(i=0;i<t;i++)
     {
         long n;
     scanf("%ld",&n);
     while(n>0)
     {
         if(tidy(n)==1)
         {
             printf("Case #%ld: %ld\n",i+1,n);
             break;
         }
         n--;
     }
     }
 }

