#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 
 
 
 
 int isTidyNumber(char *number){
 
 	int tam, i;
 
 	tam = strlen(number);
 
 	for(i = 0; i < (tam - 1); i++){
 		if( (int)number[i] > (int)number[i+1]){
 			return i;
 		}
 	}
 
 	return -1;
 }
 
 void lowerNumber(char *number, int hint){
 
 	int tam, i, iChange;
 
 	//printf("number = %s hint = %d\n", number, hint);
 
 	tam = strlen(number);
 
 
 	for(i = hint+1; i < tam; i++){
 		number[i] = '0';
 	}
 
 
 	//printf("Tam = %d - AAA %s\n", tam, number);
 
 	for( i = tam-1; i >= 0; i--){
 		if(number[i] > '0'){
 	//		printf("C[%d] -> %c\n", i, number[i]);
 			number[i] = number[i] - 1;
 	//		printf("C[%d] -> %c\n", i, number[i]);
 			iChange = i+1;
 			break;
 		}else{
 			
 		}
 	}
 
 	for(i = iChange; i < tam; i++){
 		number[i] = '9';
 	}
 
 	if(number[0] == '0' && tam > 1){
 		for(i = 0; i < tam; i++){
 			number[i] = number[i+1];
 		}
 	}
 
 	//printf("AAA %s\n", number);
 
 
 
 }
 
 
 
 
 int main(void){
 
 	int nTests, iCase, hint;
 
 	char *number;
 
 	number = malloc(20*sizeof(char));
 
 	scanf("%d", &nTests);
 
 
 
 	for(iCase = 0; iCase < nTests; iCase++){
 
 
 		scanf("%s", number);
 
 
 		while(1){
 			//printf("%s\n", number);
 			hint = isTidyNumber(number);
 			if(hint < 0){
 				break;
 			}
 			lowerNumber(number, hint);
 		}
 
 		printf("Case #%d: %s\n", iCase+1, number);
 
 	}
 
 
 	return 0;
 
 }
