#include<stdio.h>
 
 
 void calculate(int *p,int *q,int *r,int n)
 {
 	int left,right;
 	for(int x=1;x<=n;x++)
 		if(*(p+x) == 1)
 		{
 			left=0,right=0;
 			int *rt=p+x+1,*lt=p+x-1;
 			while(*rt != 0)
 			{
 				rt++;
 				right++;
 			}
 			while(*lt != 0)
 			{
 				lt--;
 				left++;
 			}
 			*(q+x)=left;
 			*(r+x)=right;
 		}
 }
 
 int max_min(int *r,int *p,int *q,int n)
 {
 	int s,max=-1,flag=0;
 	for(int i=1;i<=n;i++)
 	{
 		int min=n;
 		if(*(r+i)==1)
 		{
 			min = *(p+i);
 			if(*(q+i)<min)
 				min=*(q+i);
 			if(min > max)
 			{
 				max=min;
 				s=i;
 			}
 			else if(min == max)
 					flag=-1;
 		}
 	}
 	if(flag == -1)
 		return -s;
 	return s;
 }
 
 int max_max(int *r,int *p,int *q,int n,int a)
 {
 	int s=a,max=-1,l_max=*(p+a),l_min = *(p+a),flag=0;
 			
 	if(*(q+a) > l_max)
 				l_max=*(q+a);
 	if(*(q+a) < l_min)
 				l_min=*(q+a);
 	for(int i=a+1;i<=n;i++)
 		if(*(r+i)==1 && (*(p+i)==l_min || *(q+i)==l_min))
 		{
 			max = *(p+i);
 			if(*(q+i)>max)
 				max=*(q+i);
 			if(l_max < max)
 			{
 				l_max=max;
 				s=i;
 			}
 			else if(l_max == max)
 				flag = -1;
 		}
 	if(flag == -1)
 		return -s;
 	return s;	
 }
 int main()
 {
 	int tc;
 	scanf("%d",&tc);
 	for(int i=1;i<=tc;i++)
 	{
 		int n,k;
 		scanf("%d %d",&n,&k);
 		int arr[n+2],ls[n+1],rs[n+1];
 		
 		arr[0]=arr[n+1]=0;
 		for(int x=1;x<n+1;x++)
 			arr[x]=1;
 		
 		calculate(arr,ls,rs,n);
 		int a;
 		for(int j=1;j<=k;j++)
 		{
 			a=max_min(arr,ls,rs,n);
 			if(a < 0)
 			{
 				a=max_max(arr,ls,rs,n,-a);
 				if(a < 0)
 					a = -a;
 			}			
 			arr[a]=0;
 			calculate(arr,ls,rs,n);
 		}
 
 		int min=ls[a],max=ls[a];
 		if(rs[a] < min)
 			min = rs[a];
 		if(rs[a] > max)
 			max = rs[a];
 
 		printf("Case #%d: %d %d\n",i,max,min);
 	}
 	return 0;
 }
