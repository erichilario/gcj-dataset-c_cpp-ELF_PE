#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <assert.h>
 
 void
 print_num(char *aux)
 {
 	int len = 0, itr = 0;
 	int lzero = 0;
 
 	len = strlen(aux);
 
 	for (itr = 0; itr < len; itr++)
 	{
 		if (aux[itr] == '0' && itr == 0)
 			lzero = 1;
 		if (aux[itr] != '0')
 			lzero = 0;
 		if (!lzero)
 			printf("%c", aux[itr]);
 	}
 	printf("\n");
 }
 
 void
 print_tidy(char *number)
 {
 	int len = 0, itr = 0;
 	int max = number[0] - 48;
 	char aux[1024] = {'\0',};
 	len = strlen(number);
 
 	for (itr = 0; itr < len; itr++)
 	{
 		if (max <= (number[itr]-48))
 		{
 			max = (number[itr]-48);
 			aux[itr] = number[itr];
 			continue;
 		} else if (max > number[itr]- 48) {
 			int t_itr = itr;
 			char temp_char = aux[t_itr-1];
 
 			if (t_itr >= 2 && (aux[t_itr-1] != aux[t_itr-2]))
 				aux[t_itr-1] = aux[t_itr-1] - 1;
 			else {
 				while (t_itr >= 1 && (aux[t_itr-1] == temp_char))
 				{
 					if (aux[t_itr-1] == '1' && t_itr != 1)
 						aux[t_itr-1] = '9';
 					else if (aux[t_itr-1] == '1')
 						aux[t_itr-1] = '0';
 					else if (aux[t_itr-1] != '1' && t_itr != 1 )
 						aux[t_itr-1] = '9';
 					else if (aux[t_itr-1] != '1' && t_itr == 1 )
 						aux[t_itr-1] = temp_char - 1;
 					t_itr--;
 				}
 			}	
 			for (; itr < len ; itr++)
 			{
 				aux[itr] = 57;
 			}
 			break;
 		}
 	}
 	//print array without leading zeros
 	print_num(aux);
 }
 
 int main()
 {
 	FILE* fp;
 	char buffer[1024] = {'\0',};
 	int len = 0;
 	int T = 0, itr = 0;
 	int temp_itr = 0;
 
 	fp = fopen("B-small-attempt2.in", "r");
 
 	fgets(buffer, 1024, (FILE*) fp);
 
 	len = strlen(buffer);
 	buffer[len-1] = '\0';
 
 	T = atoi(buffer);
 
 	for (itr = 0; itr < T; itr++)
 	{
 		int K = 0;
 
 		fgets(buffer, 1024, (FILE*) fp);
 
 		len = strlen(buffer);
 		buffer[len-1] = '\0';
 
 		printf("Case #%d: ", (itr+1));
 		print_tidy(buffer);
 	}
 	fclose(fp);
 }

