#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <inttypes.h>
 
 #define MAX(a, b) ((a > b) ? a: b)
 
 char bf[1024];
 
 void
 do_bath (const	int num, int kk)
 {
 	int l, r;
 
 	memset (bf, 0, sizeof bf);
 	bf[num+1] = '1';
 	while (kk--) {
 		int i;
 		int cm = 0;
 		int max = 0;
 		int imx = 0;
 		int mxi = 0;
 
 		for (i = 1; i <= num+1; i++) {
 			if (!bf[i]) {
 				if (cm == 0) {
 					imx = i;
 				}
 				++cm;
 			} else {
 				if (cm > max) {
 					max = cm;
 					mxi = imx;
 				}
 				cm = 0;
 			}
 		}
 		l = max/2;
 		r = (max-1)/2;
 		bf[mxi+l] = 1;
 	}
 	
 	printf ("%d %d\n", l, r);
 	return ;
 }
 
 int 
 main ()
 {
 	int	ix, ntests;
 	int	kk, num;
 
 	scanf ("%d", &ntests);
 
 	for (ix = 1; ix <= ntests; ++ix) {
 
 		scanf("%d%d", &num, &kk);
 
 		printf ("Case #%d: ", ix);
 		do_bath (num, kk);
 	}
 
 }

