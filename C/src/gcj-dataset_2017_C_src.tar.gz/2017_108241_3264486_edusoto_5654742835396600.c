#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 FILE *fin, *fout;
 
 //tidy numbers
 
 
 int main(int argc, char *argv[]){
 	int abcd, i, j, r, s, N, K, vec[1000], max, smax;
 
 	fin=fopen(argv[1], "r");
 	fout=fopen("out.txt", "w");
 	if (fin==NULL || fout == NULL)
 	{
 		printf("ERROR WITH FILE.\n");
 	}
 	else 
 	{
 		fscanf(fin, "%d", &abcd);
 		for (i = 0; i<abcd; i++){
 			fscanf(fin, "%d", &N);
 			fscanf(fin, "%d", &K);
 			vec[0]=N;
 			if(N==K){
 				fprintf(fout, "Case #%d: 0 0\n", i+1);
 			}else{
 			for(j=0; j<K; j++){
 				max=0;
 				for(s=0; s<j+1; s++){
 					if(vec[s]>max){
 						max=vec[s];
 						smax=s;
 					}
 				}
 				vec[smax]=(max-1)/2;
 				for(r=j+1; r>smax+1; r--){
 					vec[r]=vec[r-1];
 				}
 				vec[smax+1]=max/2;
 			}
 			fprintf(fout, "Case #%d: %d %d\n", i+1, max/2, (max-1)/2);
 			}			
 		}
 		fclose(fin);
 		fclose(fout);
 	}
 	return 0;
 }

