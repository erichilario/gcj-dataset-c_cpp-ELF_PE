#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 typedef long long ll;
 
 
 void
 do_pan (char	*pn, int	kk)
 {
 	char	*p;
 	char	*end;
 	int	flips = 0;
 
 	p = pn;
 	end = pn + strlen(pn);
 
 	while (*p) {
 
 		if (*p == '-') {
 			if (p+kk <= end) {
 
 				char	*tt = p;
 
 				while (tt < p+kk) {
 					if (*tt == '-') {
 						*tt = '+';
 					} else {
 						*tt = '-';
 					}
 					++tt;
 				}
 				++flips;
 			} else {
 				puts ("IMPOSSIBLE");
 				return;
 			}
 		} 
 		++p;
 	}
 	printf ("%d\n", flips);
 }
 
 int 
 main ()
 {
 	int	ix, ntests;
 	int	k;
 	char	pan[128];
 
 	scanf ("%d", &ntests);
 
 	for (ix = 1; ix <= ntests; ++ix) {
 
 		scanf("%s %d", pan, &k);
 
 		printf ("Case #%d: ", ix);
 		do_pan (pan, k);
 	}
 }

