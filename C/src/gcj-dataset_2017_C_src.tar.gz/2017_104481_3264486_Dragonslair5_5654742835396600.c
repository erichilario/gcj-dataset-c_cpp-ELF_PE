#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <stdint.h>
 #include <inttypes.h>
 
 
 
 
 
 
 
 
 int main(void){
 
 
 	int nTests, iCase;
 	uint64_t N, K, dividers, x;
 
 
 	scanf("%d", &nTests);
 
 	for(iCase = 0; iCase < nTests; iCase++){
 
 		scanf("%" SCNu64 " %" SCNu64"", &N, &K);
 
 		//printf("N = %" PRIu64 " K = %" PRIu64 " \n", N, K);
 
 		if(N == K){
 			printf("Case #%d: %d %d\n", iCase+1, 0, 0);
 			continue;
 		}
 
 
 		/*dividers = (K-1) / 2;
 
 		dividers = K - dividers;
 
 		if(dividers > 0){
 			x = K / (dividers * 2);
 		}else{
 			x = N;
 		}*/
 
 		x = N / (K);
 
 		if(x%2 == 0){
 			if(x > 0){
 				printf("Case #%d: %" PRIu64 " %" PRIu64 "\n", iCase+1, x/2, (x/2)-1);
 			}else{
 				printf("Case #%d: %d %d\n", iCase+1, 0, 0);
 				continue;
 			}
 		}else{
 			if(N%2 == 0){
 				printf("Case #%d: %" PRIu64 " %" PRIu64 "\n", iCase+1, x/2, x/2);
 			}else{
 				printf("Case #%d: %" PRIu64 " %" PRIu64 "\n", iCase+1, x/2 +1, x/2);
 			}
 			
 		}
 
 
 
 	}
 
 
 	return 0;
 }
