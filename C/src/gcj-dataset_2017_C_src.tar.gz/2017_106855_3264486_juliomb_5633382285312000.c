#include <stdio.h>
 int main() {
     int t, i, j, d, k, final_d;
     long long unsigned int n;
     int digits[123];
     scanf("%d", &t);
     for (i = 0; i < t; ++ i) {
         for(j = 0; j < 20; ++ j)
             digits[j] = -1;
         scanf("%llu", &n);
 
         for(d = 0; n > 0; n/=10, ++ d) 
             digits[d] = n%10;
 
         for(j = 0; j + 1 < d; ++ j)
             if(digits[j] < digits[j+1]) {
                 -- digits[j+1];
                 for(k = 0; k <= j; ++ k)
                     digits[k] = 9;
             }
 
         for(final_d = 0; digits[final_d] > 0; ++ final_d);
 
             
         printf("Case #%d: ", i + 1);
         for(j = final_d - 1; j >= 0; -- j)
             printf("%d", digits[j]);
         printf("\n");
     }
     return 0;
 }

