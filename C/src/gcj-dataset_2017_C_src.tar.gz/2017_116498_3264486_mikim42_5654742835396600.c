/* ************************************************************************** */
 /*                                                                            */
 /*                                                        :::      ::::::::   */
 /*   mikim42_c.c                                        :+:      :+:    :+:   */
 /*                                                    +:+ +:+         +:+     */
 /*   By: mikim <mikim@student.42.us.org>            +#+  +:+       +#+        */
 /*                                                +#+#+#+#+#+   +#+           */
 /*   Created: 2017/04/07 23:54:32 by mikim             #+#    #+#             */
 /*   Updated: 2017/04/08 10:41:15 by mikim            ###   ########.fr       */
 /*                                                                            */
 /* ************************************************************************** */
 
 #include <stdio.h>
 #include <string.h>
 #include <stdint.h>
 #include <stdlib.h>
 
 typedef	struct		s_list
 {
 	int64_t			n;
 	int64_t			k;
 	int64_t			i;
 	int64_t			odd;
 	int64_t			even;
 }					t_list;
 
 int		print(t_list *list, int index)
 {
 	int64_t max;
 	int64_t min;
 
 	if (list->k <= list->odd)
 	{
 		max = list->n / 2;
 		min = (list->n % 2 == 1 ? list->n / 2 : list->n / 2 - 1);
 		min < 0 ? min = 0 : 0;
 		return (printf("Case #%d: %lld %lld\n", index, max, min));
 	}
 	list->n = (list->odd == 0 ? list->n : list->n - 1);
 	max = (list->n) / 2;
 	min = (list->n % 2 == 1 ? list->n / 2 : list->n / 2 - 1);
 	min < 0 ? min = 0 : 0;
 	return (printf("Case #%d: %lld %lld\n", index, max, min));
 }
 
 void	set_oddeven(t_list *list)
 {
 	int64_t tmp;
 
 	if (list->n > 4 && (list->n - 1) / 2 % 2 == 1)
 		list->odd = list->odd * 2 + list->even;
 	else
 	{
 		tmp = list->even;
 		list->even = list->odd * 2 + list->even;
 		list->odd = tmp;
 	}
 }
 
 void	stalls(t_list *list, int index)
 {
 	if (list->k > list->i)
 	{
 		set_oddeven(list);
 		list->k -= list->i;
 		list->n /= 2;
 		list->i *= 2;
 		return (stalls(list, index));
 	}
 	print(list, index);
 }
 
 void	init_list(t_list *list)
 {
 	list->i = 1;
 	list->odd = (list->n % 2 == 1 ? 1 : 0);
 	list->even = (list->n % 2 == 0 ? 1 : 0);
 }
 
 int		main(void)
 {
 	int		t, t_i;
 	t_list	list;
 
 	scanf("%d", &t);
 	t_i = -1;
 	while (++t_i < t)
 	{
 		scanf("%lld %lld", &list.n, &list.k);
 		if (list.n == list.k)
 			printf("Case #%d: 0 0\n", t_i + 1);
 		else
 		{
 			init_list(&list);
 			stalls(&list, t_i + 1);
 		}
 	}
 	return (0);
 }

