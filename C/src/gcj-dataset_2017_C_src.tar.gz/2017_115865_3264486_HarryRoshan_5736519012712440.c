#include<stdio.h>
 #include<string.h>
 int main()
 {   
     int t;
     scanf("%d",&t);
     int k[t],i,j,count[t],length,remain,z,flag;
     char str[t][11];
     for(i=0;i<t;i++)
     {
         scanf("%s %d",&str[i],&k[i]);
     }
     for(i=0;i<t;i++)
     {
         length=strlen(str[i]);
         remain=length;
         j=0;
         count[i]=0;
         flag=0;
         while(str[i][j]!='\0')
         {
             if(str[i][j]=='-' && remain>=k[i])
             {
                 for(z=0;z<k[i];z++)
                 {
                     //if(str[i][j+z]!='\0')
                     //{
                         if(str[i][j+z]=='-')
                             str[i][j+z]='+';
                         else
                            str[i][j+z]='-';
                     //}
                  //   else
                   //  {
                     //    flag=1;
                   //      break;
                 //    }
                 }
                 count[i]++;
                 remain--;
                 j++;
             }
             else
             {
                 if(str[i][j]=='-')
                 {
                     count[i]=-1;
                     break;
                 }
                 remain--;
                 j++;
             }
             if(flag==1)
             {
                 count[i]=-1;
                 break;
             }
         }
     }
     for(i=0;i<t;i++)
     {
         if(count[i]!=-1)
             printf("Case #%d: %d\n",i+1,count[i]);
         else
             printf("Case #%d: IMPOSSIBLE\n",i+1);
     }
     return 0;
 }

