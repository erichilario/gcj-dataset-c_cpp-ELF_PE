#include<stdio.h>
 #include<stdlib.h>
 int main(){
     int T,case_no;
     FILE *fin,*fo;
     fin=fopen("A-small-attempt0.in","r");
     fo=fopen("A-small-attempt0.out","w");
     fscanf(fin,"%d",&T);
     for(case_no=0;case_no<T;case_no++){
         char str[1001];
         int K;
         fscanf(fin,"%s%d",str,&K);
         int len=0;
         while(str[len]!='\0'){
             len++;
         }
         int i,j,flag=0;
         for(i=0;i<=(len-K);i++){
             if(str[i]!='+'){
                 flag++;
                 for(j=0;j<K;j++){
                     if(str[i+j]=='+')
                         str[i+j]='-';
                     else
                         str[i+j]='+';
                 }
             }
         }
         for(i=(len-K+1);i<len;i++){
             if(str[i]=='-'){
                 flag=-1;
                 break;
             }
         }
         fprintf(fo,"Case #%d: ",case_no+1);
         if(flag==-1)
             fprintf(fo,"IMPOSSIBLE\n");
         else
             fprintf(fo,"%d\n",flag);
     }
     fclose(fin);
     fclose(fo);
     return 0;
 }

