#include<stdio.h>
 
 int check(int n)
 {
 	int r;
 	while(n>0)
 	{
 		r = n%10;
 		n = n/10;
 		if(r >= (n%10))
 			;
 		else
 			return 0;
 	}
 	return 1;
 }
 
 int main()
 {
 	int t;
 	scanf("%d",&t);
 	for(int q=0 ; q<t ; q++)
 	{
 		int n;
 		scanf("%d",&n);
 		int dif;
 		while((dif = check(n)) != 1)
 			n--;
 		printf("Case #%d: %d\n",q+1,n);
 	}
 	
 	
 	
 	return 0;
 }
