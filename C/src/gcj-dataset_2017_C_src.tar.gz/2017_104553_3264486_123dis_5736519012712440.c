#include <stdio.h>
 
 
 
 #define PRIN2
 
 
 
 int solve(const char *, int);
 
 int splitk(char *);
 
 
 
 int main(int argc, char ** argv)
 
 {
 
   char buf[1];
 
   int result;
 
   int bc;
 
   char * inputFileName;
 
   FILE * fd;
 
   int t;
 
   char line[1050];
 
   int lp;
 
   int out;
 
   lp = 0;
 
   t = -1;
 
   out = 0;
 
   if(argc < 2)
 
   {
 
     printf("Please specify input file name.\n");
 
     return 1;
 
   }
 
   inputFileName = argv[1];
 
 
 
 /*  printf("<%s>\n", inputFileName);*/
 
 
 
 
 
 
 
   /*inputFileName = "Input.txt";*/
 
   fd = fopen(inputFileName, "rb");
 
   while(!feof(fd))
 
   {
 
     bc = fread(buf, 1, 1, fd);
 
     if(bc > 0)
 
     {
 
       if(buf[0] != '\r' && buf[0] != '\n')
 
       {
 
         line[lp] = buf[0];
 
         line[++lp] = '\0';
 
       }
 
       else if(lp > 0)
 
       {
 
         if(t == -1)
 
           t = atoi(line);
 
         else if(t-- >= 0)
 
         {
 
         //  printf("%s %d\n", line, splitk(line));
 
           result = solve(line, splitk(line));
 
           out++;
 
   if(result >= 0)
 
     printf("Case #%d: %d\n", out, result);
 
   else
 
     printf("Case #%d: %s\n", out, "IMPOSSIBLE");
 
         }
 
         lp = 0;
 
       }
 
 //      printf("%c", buf[0]);
 
     }
 
   }
 
   fclose(fd);
 
 
 
       if(lp > 0)
 
       {
 
         if(t == -1)
 
           t = atoi(line);
 
         else if(t-- >= 0)
 
         {
 
 //          printf("%s %d\n", line, splitk(line));
 
           result = solve(line, splitk(line));
 
   out++;
 
   if(result >= 0)
 
     printf("Case #%d: %d", out, result);
 
   else
 
     printf("Case #%d: %s", out, "IMPOSSIBLE");
 
         }
 
         lp = 0;
 
       }
 
 
 
 /*
 
   printf("\n");
 
 
 
   result = solve("---+-++-", 3);
 
   printf("Case #1: %d\n", result);
 
 
 
   result = solve("+++++", 4);
 
   printf("Case #2: %d\n", result);
 
 
 
   result = solve("-+-+-", 4);
 
   if(result >= 0)
 
     printf("Case #3: %d\n", result);
 
   else
 
     printf("Case #3: %s\n", "IMPOSSIBLE");
 
 */
 
   return 0;
 
 }
 
 
 
 int splitk(char * line)
 
 {
 
   char * ptr;
 
   int result;
 
   ptr = line;
 
   while(*ptr != ' ')
 
     ptr++;
 
   *ptr = '\0';
 
   ptr++;
 
   result = atoi(ptr);
 
   return result;
 
 }
 
 
 
 
 
 int solve(const char * test, int k)
 
 {
 
   int moves;
 
   int i;
 
   int j;
 
   char s[1001];
 
   int ln;
 
   moves = 0;
 
   strcpy(s, test);
 
   ln = strlen(s);
 
 #ifdef PRIN1
 
   printf("<%s><k=%d><ln=%d>\n", s, k, ln);
 
 #endif
 
 
 
   i = 0;
 
   while(i >= 0 && i < ln - k)
 
   {
 
     while(s[i] == '+')
 
       i += 1;
 
     if(i >= 0 && i <= ln - k)
 
     {
 
       for(j = i; j < i + k; j++)
 
         s[j] = s[j] == '+' ? '-' : '+';
 
       moves++;
 
     }
 
 #ifdef PRIN1
 
   printf("<%s><%d><%d>\n", s, k, i);
 
 #endif
 
 
 
   }
 
 
 
   for(j = 0; j < ln && moves >= 0; j++)
 
     if(s[j] == '-')
 
       moves = -1;
 
 
 
   return moves;
 
 }
 

