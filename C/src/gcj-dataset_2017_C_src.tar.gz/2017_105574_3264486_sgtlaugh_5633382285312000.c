#include <stdio.h>
 #include <string.h>
 #include <stdbool.h>
 
 #define clr(ar) memset(ar, 0, sizeof(ar))
 #define read() freopen("lol.txt", "r", stdin)
 #define write() freopen("out.txt", "w", stdout)
 
 int len;
 char str[22];
 long long lim, dp[22][10][2];
 
 long long F(int i, int l, int flag){
     if (i == len) return 1;
     if (dp[i][l][flag] != -1) return dp[i][l][flag];
 
     int d, lim = 9;
     long long res = 0;
     if (flag == 0) lim = str[i] - 48;
 
     for (d = l; d <= lim; d++){
         res += F(i + 1, d, flag || (d < lim));
     }
 
     return (dp[i][l][flag] = res);
 }
 
 long long count(long long v){
     memset(dp, -1, sizeof(dp));
     sprintf(str, "%lld", v);
     len = strlen(str);
     return F(0, 0, 0);
 }
 
 int main(){
     read();
     write();
     int T = 0, t, i, j, k;
     long long low, high, mid, res;
 
     scanf("%d", &t);
     while (t--){
         scanf("%lld", &lim);
         low = 1, high = lim;
         while ((low + 1) < high){
             mid = (low + high) >> 1;
             if (count(mid) == count(lim)) high = mid;
             else low = mid;
         }
 
         res = high;
         if (count(low) == count(lim)) res = low;
 
         printf("Case #%d: %lld\n", ++T, res);
     }
     return 0;
 }

