#include"stdio.h"
 #include <stdlib.h>
 #include <string.h>
 
 int main () {
 int i,e,j,t,cnt,fl;
 int k;
 char s[1001];
 
 	scanf("%d",&t);
 
 	for(j = 1; j<= t ; j++) {
 		scanf("%s %d",s,&k);
 i=0;
 cnt=0;
 while (i<(strlen(s)-k+1)){
 if(s[i]=='-'){
 cnt++;
 for(e=0;e<k;e++){
 	if(s[i+e]=='-') {
 		s[i+e]='+';
 	} else {
 		s[i+e]='-';
 	}
 }
 } else {
 i++;
 }
 }
 
 fl=0;
 for(i=0;i<strlen(s);i++)
 { if (s[i]=='-') { fl =1 ; break; }
 }
 		if(fl==0) {
 		printf("Case #%d: %d\n",j,cnt);	
 		} else { printf("Case #%d: IMPOSSIBLE\n",j);	}
 	}
 
 	return 0;
 }

