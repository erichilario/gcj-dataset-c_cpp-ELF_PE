#include <stdio.h>
 #include <string.h>
 
 int main(void)
 {
 	int t,i,j,count,k,len,flip,flag;
 	char s[1001];
 	scanf("%d",&t);
 	count=1;
 	while(count<=t)
 	{
 		flag=0;
 		flip=0;
 		scanf("%s %d",s,&k);
 		len = strlen(s);
 		for(i=0;i<len;i++)
 		{
 			while(s[i]=='+')
 				i++;
 			if(i>=len)
 				break;
 			
 			if(i+k<=len)
 			{
 				for(j=i;j<i+k;j++)
 				{
 					if(s[j]=='+')	
 						s[j]='-';
 					else
 						s[j]='+';
 				}
 				flip++;
 			}
 			else
 				break;
 		}
 		for(i=0;i<len;i++)
 			if(s[i]=='-')
 			{
 				flag=1;
 				break;
 			}
 		if(!flag)
 			printf("Case #%d: %d\n",count,flip);
 		else
 			printf("Case #%d: IMPOSSIBLE\n",count);
 		count++;
 	}
 	return 0;
 }

