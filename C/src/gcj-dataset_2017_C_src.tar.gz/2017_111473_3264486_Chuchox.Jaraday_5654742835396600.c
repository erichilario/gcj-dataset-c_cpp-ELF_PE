#include <stdio.h>
 #define MAXESP 1000
 
 int main(void){
     long long cases, casos, lugares, persons, casi;
     long long temp, vecindades;
     long long espacios[2][MAXESP];
     long long i, j, k;
 
     scanf("%I64d\n",&cases);
     for(casos=1;casos<=cases;casos++){
         printf("Case #%d: ",casos);
         scanf("%I64d %I64d",&lugares,&persons);
         espacios[0][0] = lugares;
         espacios[1][0] = 1;
         vecindades = 1;
         for(i=1;i<MAXESP;i++){
             espacios[0][i] = espacios[1][i] = 0;
         }
         //casi = persons - 1;
         i = 0;
         j = 0;
         //for(i=0;i<casi;i++){
         while((i+espacios[1][j])<persons){
             //printf(" %I64d",espacios[0][j]);
             if(espacios[0][j] % 2){
                 //printf("i");
                 temp = espacios[0][j] / 2;
                 for(k=j+1;k<vecindades;k++){
                     if(espacios[0][k] == temp){
                         espacios[1][k] += (2*espacios[1][j]);
                         break;
                     }
                 }
                 if(k == MAXESP){
                     fprintf(stderr,"el arreglo fue muy chico, usuario %I64d de %I64d\n",i+1,persons);
                     return(0);
                 }
                 if(k==vecindades){
                     while(espacios[0][k-1]<temp){
                         espacios[0][k]=espacios[0][k-1];
                         espacios[1][k]=espacios[1][k-1];
                         k--;
                     }
                     espacios[0][k]=temp;
                     espacios[1][k]=2*espacios[1][j];
                     vecindades++;
                 }
             }else{
                 //printf("p");
                 temp = espacios[0][j] / 2;
                 for(k=j+1;k<vecindades;k++){
                     if(espacios[0][k] == temp){
                         espacios[1][k] += espacios[1][j];
                         break;
                     }
                 }
                 if(k == MAXESP){
                     fprintf(stderr,"el arreglo fue muy chico, usuario %I64d de %I64d\n",i+1,persons);
                     return(0);
                 }
                 if(k==vecindades){
                     while(espacios[0][k-1]<temp){
                         espacios[0][k]=espacios[0][k-1];
                         espacios[1][k]=espacios[1][k-1];
                         k--;
                     }
                     espacios[0][k]=temp;
                     espacios[1][k]=espacios[1][j];
                     vecindades++;
                 }
                 temp--;
                 for(1;k<vecindades;k++){
                     if(espacios[0][k] == temp){
                         espacios[1][k] += espacios[1][j];
                         break;
                     }
                 }
                 if(k == MAXESP){
                     fprintf(stderr,"el arreglo fue muy chico, usuario %I64d de %I64d\n",i+1,persons);
                     return(0);
                 }
                 if(k==vecindades){
                     while(espacios[0][k-1]<temp){
                         espacios[0][k]=espacios[0][k-1];
                         espacios[1][k]=espacios[1][k-1];
                         k--;
                     }
                     espacios[0][k]=temp;
                     espacios[1][k]=espacios[1][j];
                     vecindades++;
                 }
             }
             i += espacios[1][j];
             j++;
         }
         //printf(" %I64d\n",espacios[0][j]);
         if(espacios[0][j] % 2){
             temp = espacios[0][j] / 2;
             printf("%I64d %I64d\n",temp,temp);
         }else{
             temp = espacios[0][j] / 2;
             if(temp){
                 printf("%I64d %I64d\n",temp,temp-1);
             }else{
                 printf("0 0\n");
             }
         }
         /*i=0;
         while(espacios[0][i] != 0){
             printf("%I64d ",espacios[0][i]);
             i++;
         }
         printf("%I64d",espacios[0][i]);
         printf("\n");
         i=0;
         while(espacios[0][i] != 0){
             printf("%I64d ",espacios[1][i]);
             i++;
         }
         printf("%I64d",espacios[1][i]);
         printf("\n");*/
     }
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 

