#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 void convert(char *arr,int *num)
 {
     int i=0;
     for(;i<strlen(arr);i++)
     {
         switch(arr[i])
         {
         case 0:
             num[i]=0;
         case 1:
             num[i]=1;
         case 2:
             num[i]=2;
         case 3:
             num[i]=3;
         case 4:
             num[i]=4;
         case 5:
             num[i]=5;
         case 6:
             num[i]=6;
         case 7:
             num[i]=7;
         case 8:
             num[i]=8;
         case 9:
             num[i]=9;
         default:
             return;
         }
         i++;
     }
     return;
 }
 
 int check_tidy(char *arr)
 {
     int i=strlen(arr)-1;
     for(;i>=1;i--)
     {
         if(arr[i]<arr[i-1])
             return 0;
     }
     return 1;
 }
 
 char decrease(char a)
 {
     if(a!='0')
         --a;
     else if(a=='0')
     {
         a = '9';
     }
     return a;
 }
 void subtract_num(char *arr)
 {
     int i = strlen(arr)-1;
 
     if(arr[i]!='0'&& i!=0)
         arr[i] = decrease(arr[i]);
 
     else if(arr[i]=='0' && i!=0)
     {
         arr[i]= '9';
         int j=i-1;
         for(;j>=0;j--)
         {
             if(arr[j]!='0')
             {
                 arr[j] = decrease(arr[j]);
                 break;
             }
             arr[j] = decrease(arr[j]);
 
         }
     }
 
     if(arr[0]=='0')
     {
         for(i=0;i<=strlen(arr)-1;i++)
             arr[i]=arr[i+1];
     }
     return;
 }
 
 void max_tidy(char *arr)
 {
     int check;
     check = check_tidy(arr);
     if(check)
     {
         return;
     }
     subtract_num(arr);
     max_tidy(arr);
     return;
 }
 
 int main()
 {
     FILE *fr,*fw;
     fr = fopen("B-small-attempt0.in","r");
     fw = fopen("Output.txt","w");
     if(fr==NULL)
     {
         printf("error");
         fclose(fr);
         fclose(fw);
         return 0;
     }
 
     int t;
     fscanf(fr,"%d",&t);
     int i=0;
     for(;i<t;i++)
     {
         char *arr;
 
         arr = (char *)malloc(sizeof(char)*5);
         fscanf(fr,"%s",arr);
 
         max_tidy(arr);
 fprintf(fw,"Case #%d: %s\n",i+1,arr);
     }
     fclose(fr);
     fclose(fw);
     return 0;
 }

