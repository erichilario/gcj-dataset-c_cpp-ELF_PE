#include <stdio.h>
 #include <stdlib.h>
 #include "math.h"
 
 void test(int t, FILE* );
 int left(int a[], int j);
 int right(int a[], int j);
 
 int main()
 {FILE *file = fopen("E:\\downloadsssss\\C-small-1-attempt1.in", "r");
     int i,t;
     fscanf(file,"%d",&t);
     for(i = 1;i<=t; i++)
         test(i,file);
 
         fclose(file);
     return 0;
 }
 
 void test(int t,FILE* file)
 {FILE *fpIn;
  fpIn = fopen("E:\\bathroom.txt", "a");
 
     int n,k,i = 0,j,l,r, index;
     fscanf(file,"%d",&n);
     n += 2;
     fscanf(file,"%d",&k);
     k += 2;
     int a[n];
     for(i = 0; i<n; i++)
         a[i] = 0;
     a[0] = 1; a[n-1] = 1;
     for(i = 3; i<= k; i++)
     {  index = 0; int l1 = 0, ans = n, r1 = 0;
         for(j = 1; j<= n-2; j++)
         {
             if(a[j] == 0)
             {
                 l = left(a,j);
             r = right(a, j);
             //printf("%d          %d\n",l,r);
             int z = fabs(l-r);
             //printf("%d*\n",z);
             if(z < ans && (l > l1 || r > r1))
             {
                 l1 = l ; r1 = r;
                 ans = fabs(l-r);
                 //printf("%d *** %d\n",l1,r1);
                 index = j;
             }
             else if(l1 == l && r1 == r)
                  {
                 l1 = l ; r1 = r;
                 index = j;
             }
             }
         }
         if(i == k)
         {
             if(l1>r1){
            printf("Case #%d: %d %d\n",t,l1,r1);
            fprintf(fpIn,"Case #%d: %d %d\n",t,l1,r1);
             }
            else {printf("Case #%d: %d %d\n",t,r1,l1);
            fprintf(fpIn,"Case #%d: %d %d\n",t,r1,l1);
            }
                         //return;
         }
         a[index] = 1;
     }
 }
 
 int left(int a[], int j)
 {
     int l = 0;
     while(a[j] != 1)
     {
         l++;
         j--;
     }
     return l-1;
 }
 
 int right(int a[], int j)
 {
     int r = 0;
     while(a[j] != 1)
     {
         r++;
         j++;
     }
     return r-1;
 }

