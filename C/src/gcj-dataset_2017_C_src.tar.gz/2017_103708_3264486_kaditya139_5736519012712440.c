#include<stdio.h>
 #include<string.h>
 int main(){
     freopen("input.txt","r",stdin);
     freopen("output.txt","w",stdout);
     int t,i,j,l,k,flag=0,count=0;
     scanf("%d",&t);
     for(l=1;l<=t;l++){
         char str[1001];
         for(i=0;i<1001;i++)
             str[i]='\0';
         scanf("%s",str);
         int size=strlen(str);
         scanf("%d",&k);
         count=0;flag=0;
         for(i=0;i<size;i++){
             if(str[i]=='-'){
                 for(j=i;j<i+k;j++){
                     if(str[j]=='+')
                         str[j]='-';
                     else
                         str[j]='+';
                     if(j>=size){
                         flag=1;break;
                     }
                 }
                 count++;
                 if(flag==1)
                     break;
             }
         }
         if(flag==1)
             printf("Case #%d: IMPOSSIBLE\n",l);
         else
             printf("Case #%d: %d\n",l,count);
     }
     fclose(stdout);
 }

