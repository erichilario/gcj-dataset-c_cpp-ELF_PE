/*
 					------------------Oversized Pancake Flipper-------------------------------------
 					-------------------Author: Gurpreet Gandhi(Garry)----------------------------
 					--------------------Date: 09/04/2017--------------------------------------------
 					===================Functions Used ===============================================
 					->happyPanCake
 					-> main
 					->Print
  	*/
 					//------create a data structure
 					struct node
 					{
 						char arr[100];
 						int flips;
 						
 					}set[100];
 					
 					//-------header files
 					
 				#include<stdio.h>
 				#include<stdlib.h>
 				#include<string.h>
 				
 				happyPanCake(int test,char* str,int flips)
 				{
 					
 					int i=0,j=0;
 					int size=strlen(str);
 					int count =0;
 					
 				//	printf("size %d",size);
 					
 					while(i<size)
 					{
 						
 						if(str[i]=='+')
 						i++;
 						
 						else if(str[i]=='-' && i<=size-flips)
 						{
 							for(j=i;j<i+flips;j++)
 							{
 							if(str[j]=='-')
 							str[j]='+';
 							else
 							str[j]='-';	
 								
 							}
 						count++;
 						i++;	
 						}
 						
 					else if(str[i]=='-' && i>size-flips)
 					{
 							count=-10;
 						break;
 					}
 					
 				}
 				//	printf("count %d",count);
 					return count;
 						
 				}
 				
 				
 				
 				main()
 				{
 					int i,j,res;
 					
 					int test_case;
 					scanf("%d",&test_case);
 					
 					
 					for(i=0;i<test_case;i++){
 						
 						scanf("%s",&set[i].arr);
 						
 						scanf("%d",&set[i].flips);
 						
 						
 					}
 					
 					for(i=0;i<test_case;i++)
 					{
 					res=0;
 						res=happyPanCake(i,set[i].arr,set[i].flips);
 						if(res==-10)
 						{
 							printf("case #%d IMPOSSIBLE",i+1);
 						}
 						else
 						printf("case #%d %d",i+1,res);
 						
 					}
 					
 					return 0;
 				}

