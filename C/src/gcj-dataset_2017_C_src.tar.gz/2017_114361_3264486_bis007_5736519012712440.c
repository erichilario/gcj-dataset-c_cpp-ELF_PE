#include<stdio.h>
 #include<string.h>
 
 int main()
 {
     int z;
     scanf("%d",&z);
     int n=0;
     while(n<z)
     {
         char s[1005];
         scanf("%s",s);
         int i,j,k,flag=0,count=0;
         scanf("%d",&k);
         
         //printf("%lu\n",strlen(s));
         for(i=k-1;i<strlen(s);i++)
         {
             if(s[i-k+1]!='+')
             {
                 if(i+1>strlen(s)){
                     j=i;
                     break;
                 }
                 for(int t=0;t<=k-1;t++)
                 {
                     
                     if(s[i-k+1+t]=='+')
                         s[i-k+1+t]='-';
                     else
                         s[i-k+1+t]='+';
                 }
                 count++;
             }
           // printf("%s\n",s);
         }
         
         
         int l=j;
         while(l!=strlen(s))
         {
             if(s[l]!='+')
             {
                 flag=2;
                 break;
             }
             l++;
         }
         if(flag==0)
             printf("Case #%d: %d\n",n+1,count);
         
         else
             printf("Case #%d: IMPOSSIBLE\n",n+1);
         
         n++;
         
     }
     
     
     return 0;
 }

