#include <stdio.h>
 #include <stdlib.h>
 #include <time.h>
 #include <string.h>
 
 #define INFILE "C-small-attempt1.in"
 #define OUTFILE "C-small-attempt1.out"
 
 long T;
 FILE *fin;
 
 long long Hd, Hd0, Ad, Hk, Ak, B, D;
 long long last_Hk, last_Ak;
 
 long long steps = 0;
 
 void read_problem()
 {
 	fscanf(fin, "%lld", &Hd);
 	fscanf(fin, "%lld", &Ad);
 	fscanf(fin, "%lld", &Hk);
 	fscanf(fin, "%lld", &Ak);
 	fscanf(fin, "%lld", &B);
 	fscanf(fin, "%lld", &D);
 	Hd0 = Hd;
 }
 
 long long myceiling(long long Hk, long long Ad)
 {
 	long long ret = Hk / Ad;
 	if (Hk%Ad > 0)
 		ret++;
 	return ret;
 }
 
 void solve_problem()
 {
 	steps = 0;
 	last_Hk = Hk;
 	last_Ak = Ak;
 
 	while (Hk > 0)
 	{
 		if (Hk <= Ad)	// Victory!!!
 		{
 			Hk = 0;
 		}
 		else if (Hd <= Ak - D)	// shoud cure!!!
 		{
 			Hd = Hd0-Ak;
 			if (Ak == last_Ak && Hk == last_Hk)
 			{
 				steps = -1;
 				return;
 			}
 
 			last_Hk = Hk;
 			last_Ak = Ak;
 		}
 		else if (Hd <= Ak)	// decrease knight's power
 		{
 			Ak = Ak - D;
 			Hd = Hd - Ak;
 		}
 		else if (myceiling(Hk,Ad)> Hk/(Ad+B) + 1)	// increase dragon's power
 		{
 			Ad = Ad + B;
 			Hd = Hd - Ak;
 		}
 		else	// attach knight
 		{
 			Hk = Hk - Ad;
 			Hd = Hd - Ak;
 		}
 		steps++;
 	}
 }
 
 void read_file()
 {
 	long problem;
 	fin = fopen(INFILE, "r");
 	fscanf(fin, "%d\n", &T);
 	FILE *fout;
 	fout = fopen(OUTFILE, "w");
 
 	for (problem = 0;problem < T;problem++)
 	{
 		read_problem();
 		solve_problem();
 		if (steps >= 0)
 		{
 			printf("Case #%ld: %lld\n", problem + 1, steps);
 			fprintf(fout, "Case #%ld: %lld \n", problem + 1, steps);
 		}
 		else
 		{
 			printf("Case #%ld: IMPOSSIBLE\n", problem + 1);
 			fprintf(fout, "Case #%ld: IMPOSSIBLE\n", problem + 1);
 		}
 	}
 	fclose(fin);
 	fclose(fout);
 }
 
 
 long main()
 {
 	read_file();
 
 	return 1;
 }

