#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int isTidy(int x){
     int aux1;
     while(x!=0){
         aux1= x% 10;
         x= x/10;
         if(x==0)
             break;
         if(aux1< x %10)
             return 0;
     }
     return 1;
 }
 int main()
 {
     int nrT, nrC = 1, x;
     FILE* f, *df;
     if((f=fopen("B-small-attempt0.in", "r"))==NULL){
         perror("B-small-attempt0.in");
         exit(0);
     }
     if((df=fopen("output.in", "w"))==NULL){
         perror("output.in");
         exit(0);
     }
     fscanf(f, "%d", &nrT);
     while(nrT--)
     {
         fscanf(f, "%d", &x);
         while(isTidy(x)==0){
             x--;
         }
         fprintf(df, "Case #%d: %d\n", nrC, x);
         nrC++;
     }
 
     return 0;
 }

