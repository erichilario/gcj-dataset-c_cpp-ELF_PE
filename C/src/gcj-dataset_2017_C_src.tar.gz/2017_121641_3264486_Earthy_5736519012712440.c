#include "libft/libft.h"
 #include <stdio.h>
 
 void	backtrack(char *data, int k)
 {
 	int i;
 	int j;
 	int count;
 	int mark;
 	int temp;
 
 	i = 0;
 	while (data[i])
 	{
 		if (data[i] == '-')
 		{
 			j = 0;
 			temp = i;
 			while (j < k && data[temp])
 			{
 				if (data[temp] == '-')
 					data[temp] = '+';
 				else if (data[i] == '+')
 					data[temp] = '-';
 				temp++;
 				j++;
 			}
 			if (j != k)
 			{
 				while (j)
 				{
 					temp--;
 					if (data[temp] == '-')
 						data[temp] = '+';
 					else if (data[i] == '+')
 						data[temp] = '-';
 					j--;
 				}
 			}
 			count++;
 		}
 		i++;
 	}
 	i = 0;
 	while (data[i])
 	{
 		if (data[i] == '-')
 			mark = 1;
 		i++;
 	}
 	if (mark == 1)
 		printf("IMPOSSIBLE\n");
 	else
 		printf("%d\n", count);
 	i = 0;
 }
 
 void	solve(char *str, int num)
 {
 	char **temp;
 	char *data;
 	int k;
 	int s;
 	int i;
 
 	i = 0;
 	temp = ft_strsplit(str, ' ');
 	k = ft_atoi(temp[1]);
 	data = temp[0];
 	printf("Case #%d: ", num);
 	backtrack(data, k);
 }
 
 int		main(int argc, char **argv)
 {
 	char buf[1024];
 	char *temp;
 	char **str;
 	int i;
 
 	temp = ft_strnew(0);
 	while (read(0, buf, 1024))
 		temp = ft_strjoin(temp, buf);
 	str = ft_strsplit(temp, '\n');
 	i = 1;
 	while (i < ft_atoi(str[0]) + 1)
 	{
 		solve(str[i], i);
 		i++;
 	}
 	return (0);
 }

