#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <assert.h>
 
 int
 get_max_seg_ind(int *room, int tot)
 {
 	int itr = 0;
 	int max_ind = 0;
 	int max = room[0];
 	int next_ind = 0;
 	int seg_len = 0;
 
 	for (itr = 0; itr < tot-1; )
 	{
 		int seg = 0;
 		seg_len = room[itr];
 		if (max < seg_len) {
 			max = seg_len;
 			max_ind = itr;
 		}
 		itr = itr + room[itr] + 1;
 	}
 	return max_ind;
 }
 
 void
 print_max_min(int N, int K)
 {
 	int *room = NULL, L = NULL, R = NULL;
 	int tot = N+2;
 	int start_ind = 0;
 	int end_ind = N+1;
 	int itr = 0;
 
 	room = (int*)calloc(tot, sizeof(int));
 
 	room[start_ind] = tot-2;
 	room[end_ind] = 0;
 
 	for (itr = 0; itr < K; itr ++)
 	{
 		int new_ind = 0, max_ind = 0;
 		int seg_len = 0, new_seg = 0;
 
 		max_ind = get_max_seg_ind(room, tot);
 
 		seg_len = room[max_ind];
 		if (seg_len % 2 == 0)
 			new_seg = (seg_len/2) -1;
 		else
 			new_seg = (seg_len / 2);
 		new_ind = max_ind + new_seg + 1;
 
 		room[max_ind] = new_seg;
 		room[new_ind] = seg_len - new_seg - 1;
 		if (itr == K-1)
 		{
 			if (room[new_ind] >= room[max_ind]) 
 				printf("%d %d\n", room[new_ind], room[max_ind]);
 			else
 				printf("%d %d\n", room[max_ind], room[new_ind]);
 		}
 	}
 }
 
 int main()
 {
 	FILE* fp;
 	char buffer[1024] = {'\0',};
 	int len = 0;
 	int T = 0, itr = 0;
 	int temp_itr = 0;
 
 	fp = fopen("C-small-1-attempt0.in", "r");
 	
 	fgets(buffer, 1024, (FILE*) fp);
 
 	len = strlen(buffer);
 	buffer[len-1] = '\0';
 
 	T = atoi(buffer);
 
 	for (itr = 0; itr < T; itr++)
 	{
 		int K = 0;
 		char row[1024] = {'\0',};
 		char *token = NULL;
 		int N = 0;
 
 		fgets(buffer, 1024, (FILE*) fp);
 
 		len = strlen(buffer);
 		buffer[len-1] = '\0';
 
 		token = strtok(buffer, " ");
 		strcpy(row, token);
 
 		N = atoi(row);
 		token = strtok(NULL, " ");
 		K = atoi(token);
 
 		printf("Case #%d: ", (itr+1));
 		print_max_min(N, K);
 	}
 
 	fclose(fp);
 
 }

