#include<stdio.h>
 int main()
 {
     int i,T,t=1,count1=0,count2=0,r;
     long long n,n1;
     int a[18]={0};
     scanf("%d",&T);
     while(t<=T)
     {
         scanf("%ld",&n);
         n1=n;
         while(n>0)
         {
                     i=0;
         count1=0;
         count2=0;
 
             n1=n;
             //printf("%d",n1);
 
         while(n1>0)
         {
             r=n1%10;
             a[i]=r;
             n1=n1/10;
             i=i+1;
             count1=count1+1;
         }
         //for(i=0;i<count1;i++)
             //printf("\n%d",a[i]);
         for(i=1;i<count1;i++)
         {
             //printf("%d",a[count1-i]);
             if(a[count1-i]<=a[count1-i-1])
                 count2=count2+1;
                 else
                 {
                     break;
                 }
         }
         if(count1==count2+1)
            {
             break;
            }
         else
         {
             n=n-1;
         }
     }
                    printf("Case #%d: %lld\n", t, n);
     t=t+1;
     }
   return 0;
 }

