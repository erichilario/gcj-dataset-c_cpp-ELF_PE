#include <stdio.h>
 
 int main(int argc, char const *argv[]) {
   int num_of_tests;
   scanf("%d", &num_of_tests);
 
   // read inputs
   for (int t = 0; t < num_of_tests; t++) {
     int row, column;
     char cake[25][25];
     scanf("%d %d", &row, &column);
 
     for (int i = 0; i < row; i++) {
       for (int j = 0; j < column; j++) {
         scanf(" %c", &cake[i][j]);
       }
     }
 
     char letter;
 
     for (int i = 0; i < row; i++) {
       letter = '.'; // . means undefined
       for (int j = 0; j < column; j++) {
         if (cake[i][j] != '?') {
           letter = cake[i][j];
 
           for (int k = 0; k < j; k++) {
             if (cake[i][k] == '?') {
               cake[i][k] = letter;
             }
           }
         } else if (letter != '.') {
           cake[i][j] = letter;
         }
       }
     }
 
     // if there are rows with all ?s
     for (int i = 0; i < row; i++) {
       if (cake[i][0] == '?') {
         int l;
         if (i >= 1) {
           l = i - 1;
         }  else {
           l = i + 1;
           while (cake[l][0] == '?') {
             l++;
           }
         }
         for (int j = 0; j < column; j++) {
           cake[i][j] = cake[l][j];
         }
       }
     }
 
     printf("Case #%d:\n", t + 1);
     for (int i = 0; i < row; i++) {
       for (int j = 0; j < column; j++) {
           printf("%c", cake[i][j]);
       }
       printf("\n");
     }
   }
 
   return 0;
 }

