#include <stdio.h>
 
 void main() {
     int count, cur;
     cur = 1;
     scanf("%d%*c", &count);
     while (cur <= count) {
         char inp[1001];
         int siz, flips = 0;
         scanf("%[^ ]%*c%d%*c", (char*)&inp, &siz);
         for (int i = 0; inp[i + siz - 1] != 0; i++) {
             if (inp[i] == '-') {
                 for (int l = 0; l < siz; l++) {
                     if (inp[i+l] == '+')
                         inp[i+l] = '-';
                     else
                         inp[i+l] = '+';
                 }
                 flips++;
             }
         }
         for (int i = 0; inp[i] != 0; i++)
             if (inp[i] == '-') {
                 flips = -1;
                 break;
             }
         if (flips != -1)
             printf("Case #%d: %d\n", cur++, flips);
         else
             printf("Case #%d: IMPOSSIBLE\n", cur++);
     }
 }

