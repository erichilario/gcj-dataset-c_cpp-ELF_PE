#include<stdio.h>
 #include<string.h>
 char str[105];
 int main()
 {
   int i, T, len, k,count, j;
   scanf("%d",&T);
   for (i=1; i<=T; i++) {
     scanf("%s %d",str,&k);
     len = strlen(str);
     count = 0;
     for (j=1; j<len-k; j++) {
       if (str[j] != str[j-1]) {
 	count++;
       }
     }
     if (count%2==0 && str[0]=='-') {
       count++;
     }
     if (count%2==1 && str[0]=='+') {
       count++;
     }
     if(len-k==count)
     printf("Case #%d: IMPOSSIBLE\n", i);
     else
             printf("Case #%d: %d\n", i, count);
 
   }
   return 0;
 }

