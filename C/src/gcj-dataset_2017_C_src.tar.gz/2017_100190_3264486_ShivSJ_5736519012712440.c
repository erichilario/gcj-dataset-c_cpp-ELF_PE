#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int pancake(char *, int);
 int isminus(char *);
 
 void main()
 {
     char text[50];
     int t;						//number of test cases
     scanf("%d",&t);
     int i;
     for(i=0;i<t;i++){
 	    scanf("%s",text);
     	int k;
     	scanf("%d",&k);
     	int ans=pancake(text,k);
     	printf("Case #%d:",i+1);
     	if(isminus(text)) printf(" IMPOSSIBLE\n");
     	else printf(" %d\n",ans);
     }
 }
 
 int isminus(char * text)
 {
     int i;
     for(i=0;i<strlen(text);i++) if(text[i]=='-') return 1;
     return 0;
 }
 
 int pancake(char * text, int k)
 {
     int l=strlen(text);
     int i,j;
     int count=0;
     for(i=0;i<l-k+1;i++){
         if(text[i]=='-'){
             count++;
             for(j=i;j<i+k;j++){
                 if(text[j]=='-') text[j]='+';
                 else text[j]='-';
             }
         }
     }
     return count;
 }

