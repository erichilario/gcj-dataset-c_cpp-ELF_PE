#include <stdio.h>
 
 int N = 0;
 char num[20];
 char st[20];
 int i;
 int done;
 
 int main()
 {
     scanf("%d", &N);
     for (int n = 0; n < N; ++n)
     {
         scanf("%s", num);
         for (char *last = num + 1; *last != '\0'; ++last)
         {
             for (char *p = last; p > num; --p)
             {
                 if (*p < *(p - 1))
                 {
                     for (char *i = p; *i != '\0'; ++i) *i = '9';
                     *(p - 1) -= 1;
                 }
             }
         }
         printf("Case #%d: ", n + 1);
         for (char *q = num; *q != '\0'; ++q) if (*q != '0') printf("%c", *q);
         printf("\n");
     }
     return 0;
 }

