/* ************************************************************************** */
 /*                                                                            */
 /*                                                        :::      ::::::::   */
 /*   mikim42_b.c                                        :+:      :+:    :+:   */
 /*                                                    +:+ +:+         +:+     */
 /*   By: mikim <mikim@student.42.us.org>            +#+  +:+       +#+        */
 /*                                                +#+#+#+#+#+   +#+           */
 /*   Created: 2017/04/07 20:03:04 by mikim             #+#    #+#             */
 /*   Updated: 2017/04/07 23:49:03 by mikim            ###   ########.fr       */
 /*                                                                            */
 /* ************************************************************************** */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int		not_tidy(char *n, int i, int x)
 {
 	n[i] = '9';
 	n[i - 1] -= 1;
 	if (n[i - 1] < '0' || n[i - 1] < n[i - 2])
 		return (not_tidy(n, i - 1, x));
 	while (n[++i] != '\0')
 		n[i] = '9';
 	return (printf("Case #%d: %ld\n", x, atol(n)));
 }
 
 int		is_tidy(char *n, int x)
 {
 	int	i;
 
 	i = -1;
 	while (++i < (int)strlen(n) - 1)
 		if (n[i] > n[i + 1])
 			return (not_tidy(n, i + 1, x));
 	return (printf("Case #%d: %ld\n", x, atol(n)));
 }
 
 int		main(void)
 {
 	int		t, t_i;
 	char	n[20];
 
 	scanf("%d", &t);
 	t_i = -1;
 	while (++t_i < t)
 	{
 		scanf("%s", n);
 		is_tidy(n, t_i + 1);
 	}
 	return (0);
 }

