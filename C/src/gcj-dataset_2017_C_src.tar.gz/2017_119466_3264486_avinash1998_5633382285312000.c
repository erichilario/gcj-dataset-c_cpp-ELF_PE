#include<stdio.h>
 int main()
 {
     long long int t,n,i,j,ans,a[20],poi,temp;
     scanf("%lld",&t);
     for(i=0;i<t;i++)
     {
         scanf("%lld",&n);
         temp = n;
         poi=0;
         while(temp>0)
         {
             a[poi]=temp%10;
             temp=temp/10;
             poi++;
         }
         for(j=0;j<poi;j++)
         {
             if(j<poi-1)
             {
                 if(a[j]<a[j+1])
                 {
                     for(temp=j;temp>=0;temp--)
                         a[temp]=9;
                     a[j+1]=a[j+1]-1;
                 }
             }
         }
         ans=0;
         for(j=poi-1;j>=0;j--)
         {
             if(a[j]==0)
                 continue;
             else
                 break;
         }
         for(temp=j;temp>=0;temp--)
         {
             ans=ans*10+a[temp];
         }
         printf("Case #%lld: %lld\n",i+1,ans);
     }
     return 0;
 }

