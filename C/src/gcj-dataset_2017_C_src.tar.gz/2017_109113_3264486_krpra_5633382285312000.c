#include<stdio.h>
 #include<conio.h>
 #include<math.h>
 
 int main()
 {
 	int arr[20],T,num,i,c,cont=0,s;
 	long int final,N,dup,count;
 	
 	FILE *fp,*fd;
 	fp=fopen("input.in","r");
 	fscanf(fp,"%d",&count);
 	while(count>=1){
 		T=0;
 		for(i=0;i<10;i++) 
 		arr[i]=0;
 	cont++;
 	fscanf(fp,"%d",&N);
 	if (N/10==0)
 	{
 		fd=fopen("output.txt","a");
 		fprintf(fd,"Case #%d: %d\n",cont,N);
 	}		
 	else
 	{
 		final=N;
 		while(T==0){	
 			dup=final--;
 			s=0;
 			do{
 				num=dup%10;
 				arr[s++]=num;
 				dup/=10;
 			}while(dup!=0);
 				for(i=0;i<s-1;i++){
 					if(arr[i]>=arr[i+1]){
 						T=1;
 					}
 					else{ 
 						T=0;
 						break;
 					}				
 				}
 				if(T!=1)
 		         ;
 		}
 		fd=fopen("output.txt","a");
 		fprintf(fd,"Case #%d: %d\n",cont,final+1);
 	}
 	count--;
 	}
 	return 0;
 }
