#include <stdio.h>
 #include <stdlib.h>
 
 void test(int t, FILE* );
 
 int main()
 {  FILE *file = fopen("E:\\downloadsssss\\A-small-attempt3.in", "r");
     int t,i;
     fscanf(file,"%d",&t);
     //printf("t = %d\n",t);
     for(i = 1; i<= t; i++)
         test(i,file);
 
         fclose(file);
     return 0;
 }
 
 void test(int t, FILE* file)
 {
      FILE *fpIn;
  fpIn = fopen("E:\\newcodejam.txt", "a");
     int i = 0,k,flips = 0,j,p = 0,m = 0,no = 0;
     char a[10001];
     fflush(stdin);
     fscanf(file,"%s",a);
     fscanf(file,"%d",&k);
 
         while(a[i] != '\0'){
                 j = 0;
         while(a[i] == '+')
         i++;
     while(a[i] == '-')
         {
             i++;j++;
         }
         if(j>=k)                      //---+-++-   3
         {
             flips = flips + (j/k);
             j -= (k*(j/k));
         }
         if(j == 0 )
         {continue;}
 
         while(a[i] == '+')
         {
             p++; i++;
         }
         //if(p != x*(k-j) )
         if(p%(k-j) != 0)
             {printf("Case #%d: IMPOSSIBLE\n",t); no = 1;
         fprintf(fpIn, "Case #%d: IMPOSSIBLE\n",t);
      fclose(fpIn);
          return;}
         else {
                 if(a[i] != '\0')
             {while(m <= j && a[i] == '-')
         {
             i++; m++;
         }}
         if(m != j) {printf("Case #%d: IMPOSSIBLE\n",t);no = 1;
      fprintf(fpIn, "Case #%d: IMPOSSIBLE\n",t);
      fclose(fpIn);
          return;}
         else{ flips += p/(k-j) + 1; //printf("flips = %d\n",flips);
         }
         }
         }
 if(no == 0){ printf("Case #%d: %d\n",t,flips);
      fprintf(fpIn, "Case #%d: %d\n",t,flips);
      flips = 0;
      fclose(fpIn);
      }
 }

