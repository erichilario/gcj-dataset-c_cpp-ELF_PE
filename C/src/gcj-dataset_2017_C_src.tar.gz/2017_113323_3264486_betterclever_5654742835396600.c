#include <stdio.h>
 #include <math.h>
 
 long long int log2cus(long long int x){
     int result = 0;
     while(x >>= 1){
         result++;
     }
     return result;
 }
 
 long long int pow2cus(long long int x){
     int result = 1;
     while(x--){
         result <<= 1;
     }
     //printf("%lld\n", result);
     return result;
 }
 
 int main()
 {
     int t;
     scanf("%d",&t);
     int x = 1;
     while(t--){
         long long int n,k;
         scanf("%lld%lld",&n,&k);
         //long long int xc = log(k)/log(2);
         long long int xc = log2cus(k);
         //printf("xc %d\n",xc);
         long long int l = pow2cus(xc);
         long long int q = n-k;
         long long int yc = q/l;
         yc+=1;
         //printf("yc: %d\n",yc);
         printf("Case #%d: %lld %lld\n",x,yc/2,(yc-1)/2);
         x++;
     }
 }

