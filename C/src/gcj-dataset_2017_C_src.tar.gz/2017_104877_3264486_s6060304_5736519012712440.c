#include<stdio.h>
 #include<string.h>
 #include <stdlib.h>
 #include <fcntl.h>
 
 int main()
 {
     int numOfInputData;
     freopen("A-large.in","r",stdin);
     freopen("A.out","w",stdout);
     scanf("%d",&numOfInputData);
     int i ;
     for(i = 0 ; i<numOfInputData; i++)
     {
         //fwrite(str , 1 , sizeof(str) , fp );
         printf("Case #%d: ",i+1);
 
         char inputData[10000];
         int LenOfLift;
         scanf("%s",inputData);
         scanf("%d",&LenOfLift);
         //printf("%s %d\n",inputData,inputDataLen);
 
         int timesOfLift = 0;
         int Success =1;
         int stillHaventDone;
         int currentHeader = 0;
         while(1)
         {
             stillHaventDone = 0;
             int i;
             for (i = currentHeader ; i < strlen(inputData); i++)
             {
                 if(inputData[i] == '-'){
                     currentHeader = i;
                     stillHaventDone = 1;
                     Success = 0;
                     break;
                 }
             }
             currentHeader = i;
             if( currentHeader + LenOfLift > strlen(inputData))
             {
                 if(Success == 1)
                     printf("0\n");
                 else if(stillHaventDone == 0)
                     printf("%d\n",timesOfLift);
                 else
                     printf("IMPOSSIBLE\n");
                 break;
             }
 
             int j;
             for(j=currentHeader; j <  currentHeader + LenOfLift ; j++)
             {
                 if(inputData[j] == '-')
                     inputData[j] = '+';
                 else if(inputData[j] == '+')
                     inputData[j] = '-';
             }
             //printf("%s ",inputData);
             timesOfLift ++;
         }
 
 
     }
 }

