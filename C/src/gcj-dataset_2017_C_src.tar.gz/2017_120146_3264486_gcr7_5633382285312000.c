#include <bits/stdc++.h>
 using namespace std;
 long long int t,n,m,o,k,prev;
 long long int func(long long int);
 int main()
 {
 	scanf("%lld",&t);
 	for(long long int i=0;i<t;i++)
 	{
 		scanf("%lld",&n);
 		m=n;
 		o=n;
 		prev=m%10;
 		printf("Case #%lld: %lld\n",i+1,func(m));
 	}
 	return 0;
 }
 
 long long int func(long long m)
 {
 
 	while(m>0)
 			{
 				k = m%10;
 				
 				if(prev<k)
 				{
 					m=o-1;
 					o=m;
 					prev=m%10;
 					continue;
 				}
 				else
 				{
 					prev=k;
 					m=m/10;	
 				}
 						
 			}
 
 			return o;
 
 }
