#include<stdio.h>
 #define ll long long
 ll n, k;
 ll getStall(ll arr[][5]);
 ll leftUnoccupied(ll arr[][5], ll i);
 ll rightUnoccupied(ll arr[][5], ll i);
 ll min(ll x, ll y);
 ll max(ll x, ll y);
 ll setStall(ll arr[][5]);
 void fillMinMax(ll arr[][5]);
 void solve(ll i, ll n, ll k, FILE *fi, FILE *fo);
 ll main(){
   FILE *fi, *fo;
   fi = fopen("C-small-1-attempt1.in", "r");
   fo = fopen("C-small-1-attempt1.out", "w");
 
   ll t;
   fscanf(fi, "%lld", &t);
   for(ll i=1; i<=t; i++){
     fscanf(fi, "%lld %lld", &n, &k);
     solve(i, n, k, fi, fo);
   }
 
   fclose(fi);
   fclose(fo);
   return 0;
 }
 
 void solve(ll i, ll n, ll k, FILE *fi, FILE *fo){
   if(n == k){
     fprintf(fo, "Case #%lld: 0 0\n", i);
     return;
   }
   ll stall[n+2][5], lastStall;
   for(ll z=0; z<=n; z++){
     for(ll l=0; l<5; l++){
       stall[z][l]=0;
     }
   }
   while(k>0){
     lastStall = getStall(stall);
     k--;
   }
   fprintf(fo, "Case #%lld: %lld %lld\n", i, stall[lastStall][4], stall[lastStall][3]);
 }
 
 ll getStall(ll arr[][5]){
   ll stall;
   for(ll i=1; i<=n; i++){
     if(arr[i][0] != -1){
       arr[i][1] = leftUnoccupied(arr, i);
       arr[i][2] = rightUnoccupied(arr, i);
     }
   }
   fillMinMax(arr);
   stall = setStall(arr);
   arr[stall][0] = -1;
   return stall;
 }
 
 ll leftUnoccupied(ll arr[][5], ll i){
   ll rtn=-1;
   for(ll j=i; j>0; j--){
     if(arr[j][0] != -1){
       rtn++;
     }else{
       break;
     }
   }
   return rtn;
 }
 
 ll rightUnoccupied(ll arr[][5], ll i){
   ll rtn=-1;
   for(ll j=i; j<=n; j++){
     if(arr[j][0] != -1){
       rtn++;
     }else{
       break;
     }
   }
   return rtn;
 }
 
 ll min(ll x, ll y){
   if(x >= y){
     return y;
   }
   return x;
 }
 
 ll max(ll x, ll y){
   if(x <= y){
     return y;
   }
   return x;
 }
 
 void fillMinMax(ll arr[][5]){
   for(ll i=1; i<=n; i++){
     if(arr[i][0] != -1){
       arr[i][3] = min(arr[i][1], arr[i][2]);
       arr[i][4] = max(arr[i][1], arr[i][2]);
     }
   }
 }
 
 ll setStall(ll arr[][5]){
   ll stall, maxV=-1, sameStall=0;
   for(ll i=1; i<=n; i++){
     if(arr[i][0] != -1){
       if(arr[i][3] > maxV){
         maxV = arr[i][3];
         stall = i;
         sameStall=0;
       }else if(maxV == arr[i][3]){
         sameStall++;
       }
     }
   }
   if(sameStall > 1){
     maxV = -1;
     for(ll i=1; i<=n; i++){
       if(arr[i][0] != -1){
         if(arr[i][4] > maxV){
           maxV = arr[i][4];
           stall = i;
           sameStall=0;
         }else if(maxV == arr[i][4]){
           sameStall++;
         }
       }
     }
   }
   return stall;
 }

