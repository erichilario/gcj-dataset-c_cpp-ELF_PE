#include<stdio.h>
 void main()
 {
 
 int tc,t,a[200],d1,d2,p,i=0,j;
 scanf("%d",&tc);
 for(i=0;i<tc;i++)
 scanf("%d",&a[i]);
 for(i=0;i<tc;i++)
 {
 	t=a[i];
 	p=1;
 	d2=0;
 	while(t!=0)
 	{
 		d1=t%10;
 		t=t/10;
 	  if((d1>d2)&&(p!=1))
 		{
 			a[i]--;
 			t=a[i];
 			d2=0;
 			p=1;
 		}
 		else
 		{
 			d2=d1;
 			p=0;
 
 		}
 
 	}
 	printf("Case #%d: %d\n",i+1,a[i]);
   }
 
 
 }

