#include<stdio.h>
 #include<string.h>
 int turn(char* p,int s,int len);
 int main()
 {
 	int T,size,val,tc,i,j,sol[100];
 	char pan[1000];
 	scanf("%d",&T);
 	tc=T;
 	while(T!=0)
 	{
 		scanf("%s",pan);
 		scanf("%d",&size);
 		val=turn(pan,size,strlen(pan));
 		T--;
 		sol[T]=val;
 	}
 	for(i=tc-1,j=1;i>=0;--i,++j)
 	{	printf("\nCase #%d: ",j);
 		if(sol[i]==-1)
 			printf("IMPOSSIBLE");
 		else
 			printf("%d",sol[i]);
 	}
 	return 0;
 }
 int turn(char* p,int s,int len)
 {	int count=0,i,j,l;
 	for(i=0;i<len;++i)
 	{
 		if(p[i]=='-')
 		{	
 			if(i+s-1<len)
 			{	count++;
 				for(j=i;j<s+i;++j)
 				{
 					if(p[j]=='-')
 						p[j]='+';
 					else
 						p[j]='-';
 					
 				}
 			}
 			else
 				return -1;
 		}
 	}
 	return count;
 }

