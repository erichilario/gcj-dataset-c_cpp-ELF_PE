#include "stdio.h"
 #include "stdlib.h"
 #include "string.h"
 
 int main(int argc, char** argv) {
     char* line = NULL;
     size_t size = 0;
 
     getline(&line, &size, stdin);
 
     int numCases = atoi(line);
 
     for(int i = 1; i <= numCases; i++) {
         getline(&line, &size, stdin);
 
         int rows;
         int columns;
 
         sscanf(line, "%i %i", &rows, &columns);
 
         char m[rows][columns];
 
         for(int j = 0; j < rows; j++) {
             getline(&line, &size, stdin);
 
             strncpy(m[j], line, columns);
 
         }
 
         // right
         for(int r = 0; r < rows; r++) {
             char p = m[r][0];
 
             for(int c = 1; c < columns; c++) {
                 if(m[r][c] == '?') {
                     m[r][c] = p;
                 }
 
                 p = m[r][c];
             }
         }
 
         // left
         for(int r = (rows - 1); r >= 0; r--) {
             char p = m[r][columns - 1];
 
             for(int c = (columns - 2); c >= 0; c--) {
                 if(m[r][c] == '?') {
                     m[r][c] = p;
                 }
 
                 p = m[r][c];
             }
         }
 
         // down
         for(int c = 0; c < columns; c++) {
             char p = m[0][c];
 
             for(int r = 1; r < rows; r++) {
                 if(m[r][c] == '?') {
                     m[r][c] = p;
                 }
 
                 p = m[r][c];
             }
         }
 
         // up
         for(int c = (columns - 1); c >= 0; c--) {
             char p = m[rows - 1][c];
 
             for(int r = (rows - 2); r >= 0; r--) {
                 if(m[r][c] == '?') {
                     m[r][c] = p;
                 }
 
                 p = m[r][c];
             }
         }
 
         printf("Case #%i:\n", i);
 
         for(int r = 0; r < rows; r++) {
             for(int c = 0; c < columns; c++) {
                 printf("%c", m[r][c]);
 
             }
             printf("\n");
         }
     }
 
     return 0;
 }

