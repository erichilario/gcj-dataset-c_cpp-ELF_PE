
 #include <stdio.h>
 
 int istidy(int n) {
     int last=10,d;
     while (n) {
         d=n %10;
         n=n/10;
         if (d>last) return 0;
         last=d;
     }
     return 1;
 }
 
 int problem(void) {
     int n;
     scanf("%d",&n);
     while (! istidy(n)) n--;
     return n;
 }
 
 int main(int argc, char **argv) {
     int i,tc;
     scanf("%d",&tc);
     for (i=1;i<=tc;i++) {
         printf("Case #%d: %d\n",i, problem());
     }
     return 0;
 }

