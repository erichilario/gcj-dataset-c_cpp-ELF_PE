//gcj #B
 #include <math.h>
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 int main() {
     int t, i, last, last2;
     scanf("%d", &t);
     unsigned long long int k, n, tmp, ans[100]; //max 100
     for(i=0; i<t; i++) {
         scanf("%llu", &n);
         while(n) {
         	if(n%10==0) {
         		n--;
         		continue;
         	}
         	if(n/10==0) {
         		ans[i]=n;
         		break;
         	}
         	tmp=n;
         	while(tmp) {
 	        	last=(int)(tmp%10);
 	        	tmp/=10;
 	        	last2=(int)(tmp%10);
 	        	if(last2>last) {
 	        		n--;
 	        		break;
 	        	}
         	}
         	if(tmp==0) {
         		ans[i]=n;
         		break;
         	}
         }
     } 
     for(i=0; i<t; i++) {
         printf("Case #%d: %llu\n", i+1, ans[i]);
     }
     return 0;
 }
