#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 int main()
 {
 int i,j,t,k;
 char no[100];
 FILE* fpi=fopen("input.in","r");
 FILE* fpo=fopen("out.in","w");
 fscanf(fpi,"%d",&t);
 	for(i=0;i<t;i++)
 	{
 	fprintf(fpo,"Case #%d: ",i+1);
 	fscanf(fpi,"%s",no);
 	printf("%s ",no);
 		for(j=strlen(no)-1;j>=1;j--)
 		{
 		if(no[j]=='0')
 		{
 
 			for(j=strlen(no)-1;no[j]=='0';j--)
 			no[j]='9';
 		no[j]--;
 		j++;
 		}
 		}
 		for(j=strlen(no)-1;j>=1;j--)
 		{
 			if(no[j]<no[j-1])
 			{
 				for(k=j;no[k]!='\0';k++)
 				no[k]='9';
 			no[j-1]--;
 			}
 		}
 		printf("%s\n",no);
 		if(no[0]!='0')
 		fprintf(fpo,"%s\n",no);
 		else
 		{
 			for(j=1;no[j]!='\0';j++)
 			fprintf(fpo,"%c",no[j]);
 		fprintf(fpo,"\n");
 		}			
 	}
 return 0;
 }
