#include <stdio.h>
 #include <string.h>
 
 int n,style,beststyle;
 char grid[10000];
 char result[10000];
 char row[100],col[100],rowlegal[100],collegal[100];
 char seh[100],sev[100],sehlegal[100],sevlegal[100];
 char swh[100],swv[100],swhlegal[100],swvlegal[100];
 
 #define Grid(X,Y) grid[(X)+((Y)*n)]
 #define Result(X,Y) result[(X)+((Y)*n)]
 #define DiagRight(X,Y) ((X)>=(Y) ? seh[(X)-(Y)] : sev[(Y)-(X)])
 #define DiagLeft(X,Y) ((X)+(Y)<n ? swh[(X)+(Y)] : swv[(Y)-(n-(X))+1])
 #define DiagRightLegal(X,Y) ((X)>=(Y) ? sehlegal[(X)-(Y)] : sevlegal[(Y)-(X)])
 #define DiagLeftLegal(X,Y) ((X)+(Y)<n ? swhlegal[(X)+(Y)] : swvlegal[(Y)-(n-(X))+1])
 
 void setdiagright(int x,int y,int v)
 	{
 	if(x>=y)
 		{
 		seh[x-y]=v;
 		}
 	else
 		{
 		sev[y-x]=v;
 		}
 	}
 
 void setdiagleft(int x,int y,int v)
 	{
 	if(x+y<n)
 		{
 		swh[x+y]=v;
 		}
 	else
 		{
 		swv[y-(n-x)+1]=v;
 		}
 	}
 
 void setdiagrightlegal(int x,int y,int v)
 	{
 	if(x>=y)
 		{
 		sehlegal[x-y]=v;
 		}
 	else
 		{
 		sevlegal[y-x]=v;
 		}
 	}
 
 void setdiagleftlegal(int x,int y,int v)
 	{
 	if(x+y<n)
 		{
 		swhlegal[x+y]=v;
 		}
 	else
 		{
 		swvlegal[y-(n-x)+1]=v;
 		}
 	}
 
 void setgrid(int x,int y,char model)
 	{
 	if(Grid(x,y)!='.')
 		{
 		switch(Grid(x,y))
 			{
 		case '+':
 			rowlegal[y]--;
 			collegal[x]--;
 			style--;
 		break;
 		case 'x':
 			setdiagrightlegal(x,y,DiagRightLegal(x,y)-1);
 			setdiagleftlegal(x,y,DiagLeftLegal(x,y)-1);
 			style--;
 		break;
 		case 'o':
 			style -= 2;
 		break;
 		default:
 		break;
 			}
 		if(model=='.')
 			{
 			row[y]--;
 			col[x]--;
 			setdiagright(x,y,DiagRight(x,y)-1);
 			setdiagleft(x,y,DiagLeft(x,y)-1);
 			}
 		}
 	else
 		{
 		row[y]++;
 		col[x]++;
 		setdiagright(x,y,DiagRight(x,y)+1);
 		setdiagleft(x,y,DiagLeft(x,y)+1);
 		}
 	Grid(x,y)=model;
 	switch(model)
 		{
 	case '+':
 		rowlegal[y]++;
 		collegal[x]++;
 		style++;
 	break;
 	case 'x':
 		setdiagrightlegal(x,y,DiagRightLegal(x,y)+1);
 		setdiagleftlegal(x,y,DiagLeftLegal(x,y)+1);
 		style++;
 	break;
 	case 'o':
 		style += 2;
 	break;
 	default:
 	break;
 		}
 	}
 
 int main(int argc,char *argv[])
 	{
 	int num_tests;
 	int m,t,i,num_models;
 	int x,y;
 	char model;
 	
 	scanf("%d\n",&num_tests);
 	for(t=0;t<num_tests;t++)
 		{
 		scanf("%d %d\n",&n,&m);
 		style=0;
 		memset(grid,'.',n*n);
 		memset(row,0,n);
 		memset(rowlegal,0,n);
 		memset(col,0,n);
 		memset(collegal,0,n);
 		memset(seh,0,n);
 		memset(sehlegal,0,n);
 		memset(sev,0,n);
 		memset(sevlegal,0,n);
 		memset(swh,0,n);
 		memset(swhlegal,0,n);
 		memset(swv,0,n);
 		memset(swvlegal,0,n);
 		for(i=0;i<m;i++)
 			{
 			scanf("%c %d %d\n",&model,&y,&x);
 			setgrid(x-1,y-1,model);
 			}
 		memcpy(result,grid,n*n);
 		beststyle=0;
 		
 		for(y=0;y<n;y++)
 			{
 			for(x=0;x<n;x++)
 				{
 				if(Grid(x,y)=='.')
 					{
 					if((col[x]==collegal[x])&&
 						(row[y]==rowlegal[y])&&
 						(DiagRight(x,y)==DiagRightLegal(x,y))&&
 						(DiagLeft(x,y)==DiagLeftLegal(x,y)))
 						{
 						setgrid(x,y,'o');
 						}
 					else if((col[x]==collegal[x])&&
 						(row[y]==rowlegal[y])&&
 						(DiagRight(x,y)-DiagRightLegal(x,y)<2)&&
 						(DiagLeft(x,y)-DiagLeftLegal(x,y)<2))
 						{
 						setgrid(x,y,'x');
 						}
 					else if((col[x]-collegal[x]<2)&&
 						(row[y]-rowlegal[y]<2)&&
 						(DiagRight(x,y)==DiagRightLegal(x,y))&&
 						(DiagLeft(x,y)==DiagLeftLegal(x,y)))
 						{
 						setgrid(x,y,'+');
 						}
 					}
 				else if(Grid(x,y)=='+')
 					{
 					if((col[x]==collegal[x])&&
 						(row[y]==rowlegal[y])&&
 						(DiagRight(x,y)-DiagRightLegal(x,y)<2)&&
 						(DiagLeft(x,y)-DiagLeftLegal(x,y)<2))
 						{
 						setgrid(x,y,'o');
 						}
 					}
 				else if(Grid(x,y)=='x')
 					{
 					if((col[x]-collegal[x]<2)&&
 						(row[y]-rowlegal[y]<2)&&
 						(DiagRight(x,y)==DiagRightLegal(x,y))&&
 						(DiagLeft(x,y)==DiagLeftLegal(x,y)))
 						{
 						setgrid(x,y,'o');
 						}
 					}
 				}
 			}
 		
 		num_models=0;
 		for(y=0;y<n;y++)
 			{
 			for(x=0;x<n;x++)
 				{
 				if(Grid(x,y)!=Result(x,y))
 					{
 					num_models++;
 					}
 				}
 			}
 		printf("Case #%d: %d %d\n",t+1,style,num_models);
 		for(y=0;y<n;y++)
 			{
 			for(x=0;x<n;x++)
 				{
 				if(Grid(x,y)!=Result(x,y))
 					{
 					printf("%c %d %d\n",tolower(Grid(x,y)),y+1,x+1);
 					}
 				}
 			}
 		}
 	}

