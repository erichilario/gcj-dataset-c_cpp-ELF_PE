#include <stdio.h>
 #include <string.h>
 int main()
 {
 	int T, N;
 	int i, j, k;
 	char S[19];
 	scanf("%d\n",&T);
 	for(i=1;i<=T;i++) {
 		scanf("%s\n", S);
 		N = strlen(S);
 		for(j=N-2; j >= 0 ; j--) {
 			if (S[j] > S[j+1]) {
 				S[j]--;
 				for(k=j+1;k < N; k++) {
 					S[k] = '9';
 				}
 			}
 		}
 		j=0;
 		while(S[j] == '0') j++;
 		printf("Case #%d: %s\n", i, &S[j]);
 		
 	}
 
 
 }

