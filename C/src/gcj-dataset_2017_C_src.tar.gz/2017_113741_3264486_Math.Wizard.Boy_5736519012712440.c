#include <stdio.h>
 #include <string.h>
 
 
 int main(void) {
   int T, K, L, C, t, l, k;
   char S[1001], F[256];
 
   F['-'] = '+';
   F['+'] = '-';
 
   scanf("%d", &T);
   for (t = 0; t++ < T; ) {
     C = 0;
     scanf("%s %d", S, &K);
     L = strlen(S);
     for (l = 0; l + K <= L; ++l) {
       if (S[l] == '-') {
         ++C;
         for (k = 0; k < K; ++k) {
           S[l + k] = F[S[l + k]];
         }
       }
     }
     for (; l < L; ++l) {
       if (S[l] == '-') {
         break;
       }
     }
     if (l == L) {
       printf("Case #%d: %d\n", t, C);
     } else {
       printf("Case #%d: IMPOSSIBLE\n", t);
     }
   }
   
   return 0;
 }

