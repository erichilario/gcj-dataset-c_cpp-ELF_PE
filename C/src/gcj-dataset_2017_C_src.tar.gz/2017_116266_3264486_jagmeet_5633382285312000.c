#include<stdio.h>
 #include<conio.h>
 main()
  {
    
    int N,i,k,j,l,T;
    scanf("%d",&T);
    printf("\n");
    for(l=1;l<=T;l++)
     {
       scanf("%d",&N);
       k=N;
       abc:
       i=k%10;
       k=k/10;
       while(k!=0)
       {
        j=i;
        i=k%10;
        if(j<i)
 	break;
        else
 	k=k/10;
       }
       if(k==0)
        printf("\nCase #%d: %d",l,N);
       else
       {
        N=N-1;
        k=N;
        goto abc;
       }
     }
     getch();
  return 0;
  }

