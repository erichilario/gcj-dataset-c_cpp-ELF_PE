#include <stdint.h>
 #include <stdio.h>
 #include <math.h>
 //Compile the program with -lm
 //cc problem3.c -o problem3 -lm
 int main()
 {
 	int T, n, i;
 	uint64_t N, K, p2, q, r, highcnt;
 	double val;
 	scanf("%d\n", &T);
 	for (i=1;i<=T;i++) {
 		scanf("%lu %lu\n", &N, &K);
 
 		if (K == 1) {
 			printf("Case #%d: %lu %lu\n", i, N/2, (N-1)/2);
 			continue;
 		}
 		p2 = pow(2,floor(log(K)/log(2)));
 
 		q = (N - (p2 - 1))/p2;
 		r = (N - (p2 - 1))%p2;
 
 		if (K > (p2 - 1 + r))
 			printf("Case #%d: %lu %lu\n", i, q/2, (q-1)/2);
 		else
 			printf("Case #%d: %lu %lu\n", i, (q+1)/2, q/2);
 	}
 }

