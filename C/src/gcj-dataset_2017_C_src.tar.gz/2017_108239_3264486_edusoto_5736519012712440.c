#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 FILE *fin, *fout;
 
 //sheeps problem
 
 
 int main(int argc, char *argv[]){
 	int abcd, i, j, m, n[1000], l, k, cont, que;
 	char s[1002];
 
 	fin=fopen(argv[1], "r");
 	fout=fopen("out.txt", "w");
 	if (fin==NULL || fout == NULL)
 	{
 		printf("ERROR WITH FILE.\n");
 	}
 	else 
 	{
 		fscanf(fin, "%d", &abcd);
 		for (i = 0; i<abcd; i++){
 			fscanf(fin, "%s", s);
 			fscanf(fin, "%d", &k);
 			l=strlen(s);
 			
 			cont=0;
 			que=0;
 
 			for (m=0; m<l; m++){
 				if(s[m]=='+')
 					n[m]=1;
 				if(s[m]=='-')
 					n[m]=-1;
 			}
 			for(m=0; m < l-k+1; m++){
 				if(n[m]==-1){
 					for(j=m; j<m+k; j++)
 						n[j]*=-1;
 					cont++;
 				}
 			}
 			for(m=l-k+1; m<l; m++){
 				if(n[m]==-1)
 					que=-1;
 			}
 			if(que==-1){
 				fprintf(fout, "Case #%d: IMPOSSIBLE\n", i+1);
 
 			}else{
 				fprintf(fout, "Case #%d: %d\n", i+1, cont);
 			}
 		}
 		fclose(fin);
 		fclose(fout);
 	}
 	return 0;
 }

