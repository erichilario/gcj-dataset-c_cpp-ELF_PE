#include<stdio.h>
 #include<string.h>
 
 void convert(char* a,long long num)
 {
     //printf("coming with : %lld",num);
     int l,i;
     long long n=num;
     l=0;
     while(num!=0)
     {
         num=num/10;
         l++;
     }
     //printf("length %lld - %d\n",n,l);
     a[l]='\0';
     for(i=l-1;i>=0;i--)
     {
 
         a[i]=(char)(n%10+48);
       //  printf("%c",a[i]);
         n=n/10;
     }
     //printf("\n");
     return ;
 }
 int main()
 {
 
     FILE* fw;
     fw=fopen("output.txt","w");
     int l,t,T,i,j,flag;
     scanf("%d",&t);
     T=t;
     long long num;
     char a[25];
     char ans[25];
     while(t--)
     {
         flag=0;
         scanf("%lld",&num);
         convert(a,num);
         l=strlen(a);
         for(i=0;i<l;i++)
         {
             if(i==l-1)
             {
                 ans[i]=a[i];
                 ans[l]='\0';
                 break;
             }
             if(a[i+1]>a[i])
                 ans[i]=a[i];
             else
             {
                 ans[i]=(char)((int)a[i]-1);
                 for(j=i+1;j<l;j++)
                     ans[j]='9';
                 ans[l]='\0';
                 break;
             }
         }
         fprintf(fw,"Case #%d: ",T-t);
         for(i=0;i<l;i++)
         {
             if(ans[i]=='0'&&flag==0)
                 continue;
             fprintf(fw,"%c",ans[i]);
             flag=1;
         }
         fprintf(fw,"\n");
     }
 }

