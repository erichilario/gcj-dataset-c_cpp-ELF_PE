#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 int main(){
 	int t,k, len,i,j,l,n;
 	char str[1005];
 	FILE *fin, *fout;
 	fin = fopen("A-small-attempt0.in", "r");
 	fout = fopen("outputA.txt", "w+");
 	
 	fscanf(fin, "%d",&t);
 	n=1;
 	while(t--){
 		fscanf(fin, "%s", str);
 		len = strlen(str);
 		fscanf(fin, "%d",&k);
 		l=0;
 		for(i=0;i<(len-k)+1;i++){
 			if(str[i] == '-'){
 				l++;
 				j=0;
 				while(j<k){
 					if(str[i+j] == '+'){
 						str[i+j] = '-';
 					}else{
 						str[i+j] = '+';
 					}
 					j++;
 				}
 			}
 		}
 		//printf("%s\n", str);
 		for(i=len-1;i>=0;i--){
 			if(str[i] == '-')
 				break;
 		}
 		
 		if(i >= 0){
 			fprintf(fout, "Case #%d: IMPOSSIBLE\n", n++);
 		}else{
 			fprintf(fout,"Case #%d: %d\n",n++, l);
 		}
 	}
 	return 0;
 }

