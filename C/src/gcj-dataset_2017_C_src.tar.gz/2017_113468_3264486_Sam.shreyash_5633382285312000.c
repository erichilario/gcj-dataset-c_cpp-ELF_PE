#include<stdio.h>
 
 int check(int n)
 {
 	while(n>9)
 	{
 		if(n%10<(n/10)%10)
 		return 0;
 		n/=10;
 	}	
 	return 1;
 }
 int main()
 {
 int t,c,i=0;
 scanf("%d",&t);
 while(i<t)
 {
 scanf("%d",&c);
 c++;
 while(!check(--c))
 {
 }
 printf("Case #%d: %d\n",(i+1),c);
 i++;
 }
 return 0;
 }

