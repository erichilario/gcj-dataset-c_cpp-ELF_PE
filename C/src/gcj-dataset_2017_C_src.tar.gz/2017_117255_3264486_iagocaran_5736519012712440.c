#include <stdio.h>
 #include <string.h>
 
 int main()
 {
 	int casos, linha, tamanhoflipper, tamanholinha, mudancas, correto;
 	char situacao[100];
 	
 	scanf("%d", &casos);
 	for(int i = 1; i <= casos; i++)
 	{
 		mudancas = 0;
 		correto = 1;
 		scanf("%s %d", &situacao[0], &tamanhoflipper);
 		for(int j = 0; j <= strlen(situacao) - tamanhoflipper; j++)
 		{
 			if(situacao[j] == '-')
 			{
 				mudancas ++;
 				for(int k = j; k < j+tamanhoflipper; k++)
 				{
 					if(situacao[k] == '-')
 						situacao[k] = '+';
 					else
 						situacao[k] = '-';
 				}
 			}
 		}
 		//printf("%s\n", situacao);
 		for(int j = 0; j < strlen(situacao); j++)
 		{
 			if(situacao[j] =='-')
 			{
 				correto = 0;
 				break;
 			}
 		}
 		if(correto)
 			printf("Case #%d: %d\n", i, mudancas);
 		else
 			printf("Case #%d: IMPOSSIBLE\n", i);
 	}
 	
 	return 0;
 }

