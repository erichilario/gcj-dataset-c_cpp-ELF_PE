#include <stdio.h>
 #include <string.h>
 
 int main()
 {
     int t, i, l, ti, j;
     char s[ 19 ];
     scanf( "%d", &t );
     for( ti = 0; ti < t; ti ++ )
     {
         scanf( "%s", s );
         l = strlen( s );
         for( i = l - 1; i > 0; i -- )
         {
             if( s[ i ] < s[ i - 1 ] )
             {
                 s[ i - 1 ] --;
                 for( j = i; j < l; j ++ )
                     s[ j ] = '9';
             }
         }
         for( i = 0; i < l && s[ i ] == '0'; i ++ );
         printf( "Case #%d: %s\n", ti + 1, s + i );
     }
     return 0;
 }

