#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 
 
 
 
 int main(void){
 
   int nTests, i, j, z, nFlips, tam;
   
   
   scanf("%d", &nTests);
   
   char *S;
   int K;
   
   S = malloc(1001 * sizeof(char));
   
   for(i = 0; i < nTests; i++){
     scanf("%s %d", S, &K);
     
     tam = strlen(S);
     nFlips = 0;
     for( j = 0; j < tam; j++){
       if(S[j] == '-'){
         if(j+K-1 >= tam){
           nFlips = -1;
           break;
         }
         
         for(z = j; z < j+K; z++){
           if(S[z] == '-'){
             S[z] = '+';
           }else{
             S[z] = '-';
           }
         }
         
         nFlips++;
       }
       
     }
     
     if(nFlips < 0){
       printf("Case #%d: IMPOSSIBLE\n", i+1);
     }else{
       printf("Case #%d: %d\n", i+1, nFlips);
     }
     
   }
 
   free(S);
 
   return 0;
 }

