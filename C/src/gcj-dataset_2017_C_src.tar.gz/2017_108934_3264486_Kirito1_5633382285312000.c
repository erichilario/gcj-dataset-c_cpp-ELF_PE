#include<stdio.h>
 #include<math.h>
 unsigned long long check(unsigned long long x,int *flg)
 {	int last=10,rem;
 	//unsigned long long temp=*x;
 	int power=0;
 	while(x!=0)
 	{
 		rem=x%10;
 		if(rem>last)
 		{
 			x--;
 			*flg=power;
 			
 			break;
 		}
 		power++;
 		last=rem;
 		x/=10;
 	}
 	return x;
 }
 				
 int main()
 {
 	unsigned long long a,i,ad,res[100];
 	unsigned int T;
 	int flag=0,j=0;
 	scanf("%u",&T);
 	while(T!=0)
 	{	
 		scanf("%llu",&a);
 		for(i=a;i>=0,flag!=1;--i,flag=0)
 		{
 			a=i;
 			i=check(i,&flag);
 			if(!flag)
 			{
 				res[j++]=a;
 				break;
 			}
 			i=i*pow(10,flag);
 
 			while(flag!=0)
 			{
 				ad=9*pow(10,--flag);
 				i+=ad;
 			}
 			++i;
 			
 		}
 		T--;
 	}
 	for(i=0;i<j;++i)
 	{	printf("Case #%llu: %llu\n",i+1,res[i]);}
 }

