#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main()
 {
     FILE *fr,*fw;
     fr = fopen("A-small-attempt0.in","r");
     fw = fopen("Output.txt","w");
     if(fr==NULL)
     {
         printf("error");
         fclose(fr);
         fclose(fw);
         return 0;
     }
 
     int t;
     fscanf(fr,"%d",&t);
     int i=0;
     for(;i<t;i++)
     {
         char *arr;
         int k;
         arr=(char *)malloc(sizeof(char)*1000);
         fscanf(fr,"%s %d",arr,&k);
 
         int flag=0;
         if(k>strlen(arr))
             {
                 fprintf(fw, "Case #%d: IMPOSSIBLE\n",i+1);
                 return 0;
             }
 
         int p=0;
         int count=0;
         for(;p<strlen(arr);p++)
         {
             if(arr[p]=='-')
             {
                 arr[p]= '+';
                 if(arr[p+k-1])
                 {
                     int q=1;
                     for(;q<=k-1;q++)
                         (arr[p+q]=='-')?(arr[p+q]='+'):(arr[p+q]='-');
                 }
                 else
                 {
                     fprintf(fw, "Case #%d: IMPOSSIBLE\n",i+1);
                     flag++;
                     break;
                 }
                 count++;
             }
         }
         for(;p<=0;--p)
         {
             if(arr[p]=='-')
             {
                 fprintf(fw, "Case #%d: IMPOSSIBLE\n",i+1);
                 flag++;
                 break;
             }
         }
 
         if(flag==0)
             fprintf(fw, "Case #%d: %d\n",i+1,count);
     }
     fclose(fr);
     fclose(fw);
     return 0;
 }

