//
 //  main.c
 //  gcj2017_qualification_A
 //
 //  Created by Kookheon Kim on 2017. 4. 8..
 //  Copyright © 2017년 heonie. All rights reserved.
 //
 
 #include <stdio.h>
 #include <string.h>
 
 int main(int argc, const char * argv[]) {
     int T, K, len, Answer, t, i;
     char S[1001];
     
     scanf("%d", &T);
     for(t=1; t<=T; t++) {
         scanf("%s %d", S, &K);
         len = (int)strlen(S);
         Answer = 0;
         for(i=0; i<len-K+1; i++) {
             if(S[i] == '-') {
                 for(int j=i; j<i+K; j++) {
                     if(S[j] == '-') {
                         S[j] = '+';
                     }
                     else if(S[j] == '+') {
                         S[j] = '-';
                     }
                 }
                 Answer += 1;
             }
         }
         for( ; i<len; i++) {
             if(S[i] == '-') {
                 Answer = -1;
                 break;
             }
         }
         
         if(Answer >= 0) {
             printf("Case #%d: %d\n", t, Answer);
         }
         else {
             printf("Case #%d: IMPOSSIBLE\n",t );
         }
     }
     
     return 0;
 }

