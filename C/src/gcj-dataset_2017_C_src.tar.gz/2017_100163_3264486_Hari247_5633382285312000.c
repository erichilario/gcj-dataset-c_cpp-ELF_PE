#include<stdio.h>
 #include<stdlib.h>
 
 void func(long long int ,int );
 int main()
 {
   long long int *a;
   int i,n;
   scanf("%d",&n);
   a=(long long int*)malloc(sizeof(long long int)*n);
   for(i=0;i<n;i++)
     scanf("%lld",&a[i]);
   for(i=0;i<n;i++)
     func(a[i],i+1);
 }
 
 void func(long long int a,int i)
 {
   int k,j;
   long long int b,c;
   c=a;
   while(1)
   {
     b=c;
     while(b/10 !=0)
     {
       k=b%10;
       b=b/10;
       j=b%10;
       if(k<j)
         break;
     }
     if(k>=j)
       break;
     c--;
   }
   printf("Case #%d: %lld\n",i,c);
 }
