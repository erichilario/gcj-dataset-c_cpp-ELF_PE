#include <stdio.h>
 #include <string.h>
 
 int main() {
 	int t, T;
 
 	scanf("%d", &T);
 	for (t = 1; t <= T; t++) {
 		static char aa[32], bb[32];
 		long long x;
 		int n, i, d;
 
 		scanf("%s", aa);
 		n = strlen(aa);
 		x = 0;
 		memset(bb, 0, sizeof bb);
 		d = 0;
 		for (i = 0; i < n; i++) {
 			for (; d <= 9; d++) {
 				memset(bb + i, d + '0', n - i);
 				if (strcmp(aa, bb) < 0)
 					break;
 			}
 			d--;
 			memset(bb + i, d + '0', n - i);
 			x = x * 10LL + d;
 		}
 		printf("Case #%d: %lld\n", t, x);
 	}
 	return 0;
 }

