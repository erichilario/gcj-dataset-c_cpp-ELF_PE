#include <stdio.h>
 #include <string.h>
 
 int main()
 {
     int T, kase;
     char N[21], S[21];
     int i, j, k, len, flag;
 
     scanf("%d", &T);
     for (kase = 1; kase <= T; kase++) {
         scanf("%s", N);
         len = strlen(N);
         flag = 1;
         while (flag) {
             flag = 0;
             for (i = 0; i < len -1; i++) {
                 if (N[i] == '0') {
                     continue;
                 }
                 if (N[i] > N[i+1]) {
                     flag = 1;
                     if (N[i+1] == '0') {
                         N[i] = ((N[i] - '0') - 1) + '0';
                         for (j = i + 1; j < len; j++) {
                             N[j] = '9';
                         }
                         N[j] = 0;
                     }
                     else {
                         N[i] = ((N[i] - '0') - 1) + '0';
                         for (j = i + 1; j < len; j++) {
                             N[j] = '9';
                         }
                         N[j] = 0;
                     }
                 }
                 //printf("%s\n", N);
             }
         }
         for (i = 0; i < len; i++) {
             if (N[i] != '0') {
                 break;
             }
         }
         k = 0;
         for(j = i; j < len; j++) {
             S[k++] = N[j];
         }
         S[k] = 0;
         printf("Case #%d: %s\n", kase, S);
     }
 }
