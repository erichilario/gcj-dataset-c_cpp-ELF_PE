#include <stdio.h>
 #include <string.h>
 #include <stdbool.h>
 
 #define MAX 1000010
 #define clr(ar) memset(ar, 0, sizeof(ar))
 #define read() freopen("lol.txt", "r", stdin)
 #define write() freopen("out.txt", "w", stdout)
 
 int n, k;
 char str[MAX];
 
 void flip(int l, int r){
     int i;
     for (i = l; i <= r; i++){
         if (str[i] == '+') str[i] = '-';
         else str[i] = '+';
     }
 }
 
 bool happy(){
     int i;
     for (i = 0; i < n; i++){
         if (str[i] == '-') return false;
     }
     return true;
 }
 
 int main(){
     read();
     write();
     int T = 0, t, i, j, res;
 
     scanf("%d", &t);
     while (t--){
         scanf("%s %d", str, &k);
         res = 0, n = strlen(str);
         for (i = 0; (i + k) <= n; i++){
             if (str[i] == '-'){
                 res++;
                 flip(i, i + k - 1);
             }
         }
 
         if (happy()) printf("Case #%d: %d\n", ++T, res);
         else printf("Case #%d: IMPOSSIBLE\n", ++T);
     }
     return 0;
 }

