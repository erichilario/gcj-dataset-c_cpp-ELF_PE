#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #define MAXLEN 1024
 
 int compute(char* str, int strlen, int flipsize, int acc);
 
 int main(void) {
     int N;
     fscanf(stdin, "%d", &N);
     for (int i = 0; i < N; i ++) {
         char str[MAXLEN];
         int flipsize;
         int res;
         fscanf(stdin, "%s %d", str, &flipsize);
         
         res = compute(str, (int)strlen(str), flipsize, 0);
         if (res < 0)
             printf("Case #%d: IMPOSSIBLE\n", i + 1);
         else
             printf("Case #%d: %d\n", i + 1, res);
     }
     
     return 0;
 }
 
 int compute(char* str, int strlen, int flipsize, int acc) {
     if (strlen == 0)
         return acc;
     else if (str[0] == '+')
         return compute(str + 1, strlen - 1, flipsize, acc);
     else {
         if (strlen < flipsize)
             return -1;
         
         for (int i = 0; i < flipsize; i ++)
             str[i] = (str[i] == '-' ? '+' : '-');
         
         return compute(str + 1, strlen - 1, flipsize, acc + 1);
     }
 }

