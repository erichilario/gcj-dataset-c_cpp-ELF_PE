#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>	
 
 int main()
 {
 	int t, i;
 	scanf("%d",&t);
 	char **s=(char**)malloc(sizeof(char*)*t);
 	for(i=0;i<t;i++)
 	{
 		char s[i]=(char*)malloc(sizeof(char)*100);
 		scanf("%s",s[i]);
 	}
 	
 	for(i=0;i<t;i++)
 	{
 		
 	}
 	
 	return 0;
 }

