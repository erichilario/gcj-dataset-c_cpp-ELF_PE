#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <stdarg.h>
 #include <math.h>
 
 int isTidy(int num)
 {
 	int digit1, digit2;
 	int tidyYes;
 
 	tidyYes = 1;
 	digit1 = num % 10;
 
 	while (num >= 10)
 	{
 		num /= 10;
 
 		digit2 = num % 10;
 
 		if (digit2 <= digit1)
 		{
 			digit1 = digit2;
 		}
 		else
 		{
 			tidyYes = 0;
 			break;
 		}
 	}
 
 	return tidyYes;
 }
 
 void main(int argc, char **argv)
 {
 	FILE *f_InpFile;
 	unsigned int u_i, u_j, u_w;
 	long T, N; 
 
 	fopen_s(&f_InpFile, argv[1], "r");
 
 	if(f_InpFile == NULL)
 	{
 		printf("Input File %s not found\n", argv[1]);
 		exit(-1);
 	}
 
 	fscanf(f_InpFile, "%ld", &T);
 
 	u_w = 1;
 
 	while(T-- != 0)
 	{
 		fscanf(f_InpFile, "%ld", &N);
 
 		while (N != 0)
 		{
 			if (isTidy(N))
 			{
 				printf("Case #%d: %d", u_w++, N);
 				break;
 			}
 			else
 			{
 				N--;
 				continue;
 			}
 		}
 
 		if(T != 0)
 			printf("\n");
 	}
 }
