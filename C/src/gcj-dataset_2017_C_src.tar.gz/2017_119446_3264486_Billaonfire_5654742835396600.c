#include <stdio.h>
 #include <math.h>
 
 int index(int k ){
 	int i=0;
 	int power = pow(2,i);
 	while(power<=k){
 		i++;
 		power = pow(2,i);
 	}
 	return i;
 }
 
 
 int main(){
 	int t;
 	scanf("%d\n",&t);
 	int i,n,k,j,p;
 	for(i=1;i<=t;i++){
 		scanf("%d %d\n",&n,&k);
 		p = index(k);
 		int div = pow(2,p-1);
 		div = n/div;
 		if((div%2)==0){
 			j=div/2;
 			printf("Case #%d: %d %d\n",i,j,(j-1));
 		}
 		else{
 			j=div/2;
 			printf("Case #%d: %d %d\n",i,j,j);
 		}
 	}
 	
 	return 0;
 }
