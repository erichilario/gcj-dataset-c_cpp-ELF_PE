#include<stdio.h>
 int tidy(int n)
 {
     int m,temp=9999;
     int n1=n;
     while(n1)
     {
       m=n1%10;
       if(m==0)
         return tidy(n-1);
       if(m>temp)
         return tidy(n-1);
       temp=m;
       n1=n1/10;
     }
  
     return n;
 }
 
 int main()
 {
     int n[200],n1,i,n2;
   
     scanf("%d",&n2);
     
     for(i=0;i<n2;i++)
        scanf("%d",&n[i]);
    printf("\n output \n");
     for(i=0;i<n2;i++)
     {
       n1=tidy(n[i]);
       printf("case #%d: %d\n",i+1,n1);
     }
 
     return 0;
 }
 

