#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <inttypes.h>
 
 
 
 uint64_t
 do_tidy (char	*num)
 {
 	int ix;
 	char *tt;
 	uint64_t tmp;
 	uint64_t  on;
 
 	sscanf (num, "%lu", &on);
 
 	tt = num;
 	while (*tt) {
 		if (tt[1] != '\0' && tt[0] > tt[1]) {
 			sscanf (&tt[1], "%lu", &tmp);
 
 			on -= (tmp+1);
 			sprintf (num, "%lu", on);
 			tt = num;
 		} else {
 			++tt;
 		}
 	}
 
 	
 	return on;
 }
 
 int 
 main ()
 {
 	int	ix, ntests;
 	char	num[128];
 
 	scanf ("%d", &ntests);
 
 	for (ix = 1; ix <= ntests; ++ix) {
 
 		scanf("%s", num);
 
 		printf ("Case #%d: " "%"PRIu64"\n", ix, do_tidy (num));
 	}
 }

