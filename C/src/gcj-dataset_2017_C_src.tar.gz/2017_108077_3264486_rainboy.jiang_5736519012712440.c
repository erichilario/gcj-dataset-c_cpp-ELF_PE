#include <stdio.h>
 #include <string.h>
 
 int main() {
 	int T, t;
 
 	scanf("%d", &T);
 	for (t = 1; t <= T; t++) {
 		static char s[1024];
 		int k, n, i, j, cnt;
 
 		scanf("%s%d", s, &k);
 		n = strlen(s);
 		cnt = 0;
 		for (i = 0; i < n; i++)
 			if (s[i] == '-') {
 				if (i + k > n) {
 					cnt = -1;
 					break;
 				}
 				for (j = i; j < i + k; j++)
 					s[j] = (s[j] == '-' ? '+' : '-');
 				cnt++;
 			}
 		printf("Case #%d: ", t);
 		if (cnt == -1)
 			printf("IMPOSSIBLE");
 		else
 			printf("%d", cnt);
 		printf("\n");
 	}
 	return 0;
 }

