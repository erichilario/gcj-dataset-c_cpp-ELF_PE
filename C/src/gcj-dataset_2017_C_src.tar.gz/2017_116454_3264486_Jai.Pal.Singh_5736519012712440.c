#include<stdio.h>
 
 int string_matcher(char s[],int len);
 
 int main(void){
 	int t,k,i,j,l,len,flips;
 	char s[1000];
 	scanf("%d",&t);
 	for(i=0; i<t;i++){
 		len = 0;
 		scanf("%s",s);
 		scanf("%d",&k);
 		for(j=0;s[j]!='\0';j++)
 			len++;
 		flips = 0;
 		for(j=0;j<len;j++){
 			if((s[j]=='-')&&(j+k <= len)){
 				flips++;
 				for(l=0;l<k;l++){
 					if(s[l+j]=='-')
 						s[l+j] = '+';
 					else
 						s[l+j] = '-';
 					}
 				}
 			}
 		
 		if(!string_matcher(s,len))
 			printf("Case #%d: IMPOSSIBLE\n",i+1);
 		else
 			printf("Case #%d: %d\n",i+1,flips);
 		}
 	
 	return 0;
 	}
 	
 int string_matcher(char s[],int len){
 	int i;
 	for(i=0;i<len;i++)
 		if(s[i]== '-'){
 			return 0;
 		}
 	return 1;
 	}

