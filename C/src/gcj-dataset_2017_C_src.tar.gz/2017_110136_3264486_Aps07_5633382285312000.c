#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>	
 
 char* convert(char *n)
 {
 	int len=strlen(n), i, j;
 	
 	if(len==1)
 		return n;
 	for(i=len-1;i>0;i--)
 	{
 		if(n[i]<n[i-1])
 		{
 			n[i]='x';
 			n[i-1]-=1;
 		}
 	}
 	for(i=0;i<len;i++)
 	{
 		if(n[i]=='x')
 		{
 			for(j=i;j<len;j++)
 				n[j]='9';
 			break;
 		}
 	}
 	
 	if(n[0]=='0')
 		n=n+1;
 	return n;
 }
 int main()
 {
 	int t, i, j, len;
 	scanf("%d",&t);
 	char **n=(char**)malloc(sizeof(char*)*t);
 	int *num=(int*)malloc(sizeof(int)*t);
 	for(i=0;i<t;i++)
 	{
 		n[i]=(char*)malloc(sizeof(char)*19);		
 		scanf("%s",n[i]);
 	}
 	
 	for(i=0;i<t;i++)
 	{
 		printf("Case #%d: %s\n",i+1,convert(n[i]));
 	}
 	return 0;
 }

