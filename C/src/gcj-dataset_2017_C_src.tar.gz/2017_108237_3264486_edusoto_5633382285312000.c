#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 FILE *fin, *fout;
 
 //tidy numbers
 
 int tidy(long long int N){
 	long long int vect[25], i, j, aux=0;
 	i=0;
 	while(N>0){
 		vect[i]=N%10;
 		N=N/10;
 		i++;
 	//	printf("%lld\n",N);
 	}
 	for(j=i-1; j > 0 && aux==0; j--){
 		if(vect[j]>vect[j-1])
 			aux++;
 	}
 	if(aux==0){
 		return -1;
 	}else{
 		return j;
 	}
 }
 
 int main(int argc, char *argv[]){
 	int abcd, i, j, k;
 	long long int N;
 
 	fin=fopen(argv[1], "r");
 	fout=fopen("out.txt", "w");
 	if (fin==NULL || fout == NULL)
 	{
 		printf("ERROR WITH FILE.\n");
 	}
 	else 
 	{
 		fscanf(fin, "%d", &abcd);
 		for (i = 0; i<abcd; i++){
 			fscanf(fin, "%lld", &N);
 			j=tidy(N);
 			if(j==-1){
 				fprintf(fout, "Case #%d: %lld\n", i+1, N);
 			}else{
 				do{
 					for(k=0; k <j+1; k++)
 						N=N/10;
 					for(k=0; k <j+1; k++)
 						N=N*10;
 					N=N-1;
 					j=tidy(N);
 				}
 				while(j!=-1);
 				fprintf(fout, "Case #%d: %lld\n", i+1, N);
 			}			
 		}
 		fclose(fin);
 		fclose(fout);
 	}
 	return 0;
 }

