/*
 #include <stdio.h>
 
 int main(void) {
 	int kg = 0, min = 0, remkg = 0, bag3 = 0, bag5 = 0;
 
 	scanf("%d", &kg);
 	if (kg % 5 == 0) {
 		bag5 = kg / 5;
 	}
 	else if (kg % 5 == 3) {
 		bag5 = kg / 5;
 		bag3 = 1;
 	}
 	else {
 		for (bag5 = kg / 5; bag5 >= 0; bag5--) {
 			remkg = kg - 5 * bag5;
 			if (remkg % 3 == 0) {
 				bag3 = remkg / 3;
 				break;
 			}
 		}
 		if (bag5 == 0) {
 			bag5 = 0, bag3 = -1;
 		}
 	}
 	min = bag5 + bag3;
 	printf("%d\n", min);
 
 	return 0;
 }
 *//*
 #include <stdio.h>
 int main(void) {
 	int date[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
 	int month, day, allday = 0;
 	scanf("%d %d", &month, &day);
 	for (int m = month - 2; m >= 0; m--) { // Է  - 1 ޱ ϼ 
 		allday += date[m];
 	}
 	allday += day; //  Է ϼ 
 
 	switch (allday % 7) {
 	case 0: printf("SUN\n"); break;
 	case 1: printf("MON\n"); break;
 	case 2: printf("TUE\n"); break;
 	case 3: printf("WEN\n"); break;
 	case 4: printf("THU\n"); break;
 	case 5: printf("FRI\n"); break;
 	case 6: printf("SAT\n"); break;
 	}
 
 	return 0;
 }
 
 #include <stdio.h>
 
 int issum(int n, int d) {
 	return (n * (2 + (n - 1) * d)) / 2;
 }
 int main(void) {
 	int num, distance;
 	scanf("%d", &num);
 
 	for (int l = 1;; l++) {
 		if (num - issum(l, 6) <= 0) {
 			distance = l;
 			break;
 		}
 	}
 	printf("%d\n", distance);
 
 	return 0;
 }
 */
 /*int C, N, point[1001][1001] = { 0 };
 double result = 0, per = 0;
 printf();
 scanf("%d", &C);
 for (int i = 0; i < C; i++) {
 scanf("%d", &N);
 for (int j = 0; j < N; j++) {
 
 }
 }
 
 #include <stdio.h>
 
 int main(void) {
 	int bus_card = 10000, distance = 0, years = 0, fee = 0;
 	scanf("%d %d", &years, &distance);
 
 
 	printf("ܾ : %d\n\n", bus_card);
 	printf("° : ");
 	if (years >= 7 && years <= 12) {
 		fee = 450;
 		printf("\n");
 	}
 	else if (years >= 13 && years <= 18) {
 		fee = 720;
 		printf("ûҳ\n");
 	}
 	else if (years >= 65) { // 19ǿ 64ϰ Ƿ 65 ̻  Ǵ
 		fee = 0;
 		printf("\n");
 	}
 	else if (years >= 19) {
 		fee = 1250;
 		printf("\n");
 	}
 	else {
 		fee = 0; // 7 ̸   ??
 		printf("\n");
 	}
 	if (distance > 10) {
 		if (distance < 50) {
 			for (int i = distance - 10; i > 0; i -= 5)
 				fee += 100;
 		}
 		else{
 			for (int i = 10; i < 50; i += 5)
 				fee += 100;
 			for (int j = distance - 50; j > 0; j -= 8)
 				fee += 100;
 		}
 	}
 	printf("̿Ÿ: %dkm\n", distance);
 	printf("ݾ : %d\n", fee);
 	printf("ܾ : %d\n", bus_card - fee);
 	
 	return 0;
 }
 */
 #include <stdio.h>
 #include <math.h>
 
 int Number_of_digit(int input_N, int *digit_of_N);
 void Save_digit(int digit_of_N, int arr[][21], int case_num);
 void Find_Sorted_N(int T, int unsorted_N[][21], int digit, int sorted_N[]);
 
 int main(void)
 {
 	int T, N, digit_of_N = 0, ustN[100][21] = { 0 }, stN[100] = { 0 };
 	FILE *wfp = fopen("attempt1.txt", "w");
 	FILE *rfp = fopen("B-small-attempt1.in", "r");
 	fscanf(rfp, "%d", &T);
 	for (int i = 0; i < T; i++)
 		fscanf(rfp,"%d", &ustN[i][0]);
 
 
 	for (int j = 0; j < T; j++) {
 		Number_of_digit(ustN[j][0], &digit_of_N);
 		Save_digit(digit_of_N, ustN, j);
 		Find_Sorted_N(j, ustN, digit_of_N, stN);
 		fprintf(wfp, "Case #%d: %d\n", j + 1, stN[j]);
 		digit_of_N = 0;
 	}
 
 	fclose(rfp);
 	fclose(wfp);
 	return 0;
 }
 
 int Number_of_digit(int input_N, int *digit_of_N)
 {
 	if (input_N == 0)
 		return 0;
 	(*digit_of_N)++;
 	return Number_of_digit(input_N / 10, digit_of_N);
 }
 
 void Save_digit(int digit_of_N, int arr[][21], int case_num)
 {
 	int s2;
 	for (int s = 1; s <= digit_of_N; s++) {
 		arr[case_num][s] = arr[case_num][0] / pow(10, digit_of_N - s);
 		s2 = arr[case_num][s] / 10;
 		if (s >= 2)
 			arr[case_num][s]-= s2*10;
 	}
 }
 
 void Find_Sorted_N(int T, int unsorted_N[][21], int digit, int sorted_N[]) {
 	for (int k = 1; k < digit; k++) {
 		for (int i = 1; i < digit; i++) {
 			if (unsorted_N[T][i] > unsorted_N[T][i + 1]) {
 				unsorted_N[T][i]--;
 				for (int t = i + 1; t <= digit; t++) {
 					unsorted_N[T][t] = 9;
 				}
 			}
 		}
 	}
 	for (int j = 1; j <= digit; j++) {
 		sorted_N[T] += unsorted_N[T][j] * pow(10, digit - j);
 	}
 
 }

