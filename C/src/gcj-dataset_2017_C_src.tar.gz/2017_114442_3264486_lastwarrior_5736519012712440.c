#include <stdio.h>
 #include <string.h>
 int main(void) {
 	int t;
 	scanf("%d",&t);
 	int i,j, j1;
 	
 	for(i=1; i<=t; i++)
 	{
 		char arr[200];
 		int k;
 		scanf("%s %d",arr,&k);
 		int l = strlen(arr);
 		if(l<k)
 		{
 			int flag = 0;
 			for(j=0 ; j< l; j++)
 			{
 				if(arr[j] == '-')
 				{
 					flag = 1;
 					break;
 				}
 			}
 			if(flag==1)
 			{
 				printf("Case #%d: IMPOSSIBLE\n",i);
 			}
 			else
 			printf("Case #%d: 0\n", i);
 			continue;//
 		}
 		int count = 0;
 		for(j=0; j<l ; j++ )
 		{
 			if(arr[j] == '+')
 			continue;
 			else
 			{
 				j1 = j;
 				if(j1+k-1 < l)
 				{
 					count++;
 					for(j1 = j; j1 < l && j1 < j+k; j1++)
 					{
 						if(arr[j1] == '+')
 						arr[j1] = '-';
 						else if(arr[j1] == '-')
 						arr[j1] = '+';
 					}
 				}
 			}
 		}
 		int flag = 0;
 		for(j=0; j<l ; j++)
 		if(arr[j] == '-')
 		{
 			flag = 1;
 			break;
 		}
 		if(flag==1)
 			{
 				printf("Case #%d: IMPOSSIBLE\n",i);
 			}
 			else
 			printf("Case #%d: %d\n", i, count);
 			//printf("HI %s\n",arr);
 	}
 	// your code goes here
 	return 0;
 }

