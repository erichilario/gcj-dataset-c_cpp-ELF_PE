#include <stdio.h>
 
 
 
 
 
 #define ARG1
 
 
 
 
 
 struct Result
 
 
 
 {
 
 
 
   long long int max;
 
 
 
   long long int min;
 
 
 
 };
 
 
 
 
 
 struct StackItem
 
 
 
 {
 
 
 
   long long int value;
 
 
 
   struct StackItem * next;
 
 
 
 };
 
 
 
 
 
 struct Stack
 
 
 
 {
 
 
 
   struct StackItem * top;
 
 
 
   int amount;
 
 
 
 };
 
 
 
 
 
 int chr(char ch)
 
 
 
 {
 
 
 
   switch(ch)
 
 
 
   {
 
 
 
     case '0':
 
 
 
       return 0;
 
 
 
     case '1':
 
 
 
       return 1;
 
 
 
     case '2':
 
 
 
       return 2;
 
 
 
     case '3':
 
 
 
       return 3;
 
 
 
     case '4':
 
 
 
       return 4;
 
 
 
     case '5':
 
 
 
       return 5;
 
 
 
     case '6':
 
 
 
       return 6;
 
 
 
     case '7':
 
 
 
       return 7;
 
 
 
     case '8':
 
 
 
       return 8;
 
 
 
     case '9':
 
 
 
       return 9;
 
 
 
   }
 
 
 
   return 0;
 
 
 
 }
 
 
 
 
 
 struct Stack * createStack()
 
 
 
 {
 
 
 
   struct Stack * stack;
 
 
 
   stack = (struct Stack *) malloc(sizeof(struct Stack));
 
 
 
   stack->top = NULL;
 
 
 
   stack->amount = 0;
 
 
 
   return stack;
 
 
 
 }
 
 
 
 
 
 int numberOnSite(struct Stack * stack)
 
 
 
 {
 
 
 
   if(stack != NULL)
 
 
 
     return stack->amount;
 
 
 
   return 0;
 
 
 
 }
 
 
 
 
 
 long long int popMaxPlace(struct Stack * stack)
 
 
 
 {
 
 
 
   long long int max;
 
 
 
   struct StackItem * item;
 
 
 
   struct StackItem * tmp;
 
 
 
 
 
   max = -1;
 
 
 
   if(stack != NULL && stack->top != NULL)
 
 
 
   {
 
 
 
     stack->amount-=1;
 
 
 
     max = stack->top->value;
 
 
 
 
 
     item = stack->top;
 
 
 
     while(item != NULL)
 
 
 
     {
 
 
 
       if(max < item->value)
 
 
 
         max = item->value;
 
 
 
       item = item->next;
 
 
 
     }
 
 
 
 
 
     if(stack->top->value == max)
 
 
 
     {
 
 
 
       item = stack->top;
 
 
 
       stack->top = item->next;
 
 
 
       free(item);
 
 
 
     }
 
 
 
     else
 
 
 
     {
 
 
 
       item = stack->top;
 
 
 
       while(item->next->value != max)
 
 
 
         item = item->next;
 
 
 
       tmp = item->next;
 
 
 
       item->next = item->next->next;
 
 
 
       free(tmp);
 
 
 
     }
 
 
 
   }
 
 
 
 #ifdef ARG2
 
 
 
 printf("popMax() %d\n", max);
 
 
 
 #endif
 
 
 
   return max;
 
 
 
 }
 
 
 
 
 
 long long int popMinPlace(struct Stack * stack)
 
 
 
 {
 
 
 
   long long int min;
 
 
 
   struct StackItem * item;
 
 
 
   struct StackItem * tmp;
 
 
 
 
 
   min = -1;
 
 
 
   if(stack != NULL && stack->top != NULL)
 
 
 
   {
 
 
 
     stack->amount-=1;
 
 
 
     min = stack->top->value;
 
 
 
 
 
     item = stack->top;
 
 
 
     while(item != NULL)
 
 
 
     {
 
 
 
       if(min > item->value)
 
 
 
         min = item->value;
 
 
 
       item = item->next;
 
 
 
     }
 
 
 
 
 
     if(stack->top->value == min)
 
 
 
     {
 
 
 
       item = stack->top;
 
 
 
       stack->top = item->next;
 
 
 
       free(item);
 
 
 
     }
 
 
 
     else
 
 
 
     {
 
 
 
       item = stack->top;
 
 
 
       while(item->next->value != min)
 
 
 
         item = item->next;
 
 
 
       tmp = item->next;
 
 
 
       item->next = item->next->next;
 
 
 
       free(tmp);
 
 
 
     }
 
 
 
   }
 
 
 
 #ifdef ARG2
 
 
 
 printf("popMin() %d\n", min);
 
 
 
 #endif
 
 
 
   return min;
 
 
 
 }
 
 
 
 
 
 void pushItem(struct Stack * stack, long long int value)
 
 
 
 {
 
 
 
   struct StackItem * item;
 
 
 
 #ifdef ARG2
 
 
 
 printf("pushItem() %d\n", value);
 
 
 
 #endif
 
 
 
   item = (struct StackItem *) malloc(sizeof(struct StackItem));
 
 
 
   item->value = value;
 
 
 
   item->next = stack->top;
 
 
 
   stack->top = item;
 
 
 
   stack->amount += 1;
 
 
 
 }
 
 
 
 
 
 void releaseStack(struct Stack * stack)
 
 
 
 {
 
 
 
   struct StackItem * item;
 
 
 
   struct StackItem * tmp;
 
 
 
   item = stack->top;
 
 
 
   while(item != NULL)
 
 
 
   {
 
 
 
     tmp = item;
 
 
 
     item = item->next;
 
 
 
     free(tmp);
 
 
 
   }
 
 
 
   free(stack);
 
 
 
 }
 
 
 
 
 
 void solve(long long int, long long int , struct Result *);
 
 
 
 long long int first(char *);
 
 
 
 
 
 long long int second(char * str)
 
 
 
 {
 
 
 
   int i;
 
 
 
   char * ptr;
 
 
 
   i = 0;
 
 
 
   while(*str != ' ')
 
 
 
     str++;
 
 
 
   ptr = str + 1;
 
 
 
   *str = '\0';
 
 
 
   return first(ptr);
 
 
 
 }
 
 
 
 
 
 long long int first(char * str)
 
 
 
 {
 
 
 
   long long int value;
 
 
 
   int i;
 
 
 
   int ln;
 
 
 
   value = 0;
 
 
 
   ln = strlen(str);
 
 
 
   for(i = 0; i < ln; i++)
 
 
 
     value = value * 10 + chr(str[i]);
 
 
 
   return value;
 
 
 
 }
 
 
 
 
 
 char toc(int v)
 
 
 
 {
 
 
 
   switch(v)
 
 
 
   {
 
 
 
     case 0:
 
 
 
       return '0';
 
 
 
     case 1:
 
 
 
       return '1';
 
 
 
     case 2:
 
 
 
       return '2';
 
 
 
     case 3:
 
 
 
       return '3';
 
 
 
     case 4:
 
 
 
       return '4';
 
 
 
     case 5:
 
 
 
       return '5';
 
 
 
     case 6:
 
 
 
       return '6';
 
 
 
     case 7:
 
 
 
       return '7';
 
 
 
     case 8:
 
 
 
       return '8';
 
 
 
     case 9:
 
 
 
       return '9';
 
 
 
   }
 
 
 
   return '0';
 
 
 
 }
 
 
 
 
 
 char * preview(long long int value, char * buf)
 
 
 
 {
 
 
 
   long long int dt;
 
 
 
   int x;
 
 
 
   char ch;
 
 
 
   int pos;
 
 
 
   pos = 0;
 
 
 
   buf[0] = '\0';
 
 
 
   if(value == 0)
 
 
 
   {
 
 
 
     buf[0] = '0';
 
 
 
     buf[1] = '\0';
 
 
 
   }
 
 
 
   else
 
 
 
   {
 
 
 
     while(value > 0)
 
 
 
     {
 
 
 
       dt = value / 10;
 
 
 
       x = value - dt * 10;
 
 
 
       value = dt;
 
 
 
       buf[pos] = toc(x);
 
 
 
       buf[++pos] = '\0';
 
 
 
     }
 
 
 
     for(x = 0; x < pos/2; x++)
 
 
 
     {
 
 
 
       ch = buf[x];
 
 
 
       buf[x] = buf[pos - x - 1];
 
 
 
       buf[pos - x - 1] = ch;
 
 
 
     }
 
 
 
   }
 
 
 
   return buf;
 
 
 
 }
 
 
 
 
 
 int main(int argc, char ** argv)
 
 
 
 {
 
 
 
   FILE * fd;
 
 
 
   struct Result rc;
 
 
 
   char line[1050];
 
 
 
   int out;
 
 
 
   int t;
 
 
 
   long long int fst;
 
 
 
   long long int sec;
 
 
 
   char buf[1];
 
 
 
   int pos;
 
 
 
   int bs;
 
 
 
   char b1[64];
 
 
 
   char b2[64];
 
 
 
 
 
   out = 0;
 
 
 
   t = -1;
 
 
 
   pos = 0;
 
 
 
   if(argc <2)
 
 
 
   {
 
 
 
     printf("Input file name hasn't been specified.\n");
 
 
 
     return 1;
 
 
 
   }
 
 
 
 
 
   fd = fopen(argv[1], "rb");
 
 
 
   while(!feof(fd))
 
 
 
   {
 
 
 
     bs = fread(buf, 1 , 1, fd);
 
 
 
     if(bs > 0)
 
 
 
     {
 
 
 
       if(buf[0] != '\r' && buf[0] != '\n')
 
 
 
       {
 
 
 
         line[pos] = buf[0];
 
 
 
         line[++pos] = '\0';
 
 
 
       }
 
 
 
       else if(pos > 0)
 
 
 
       {
 
 
 
         if(t < 0)
 
 
 
         {
 
 
 
           t = atoi(line);
 
 
 
           pos = 0;
 
 
 
         }
 
 
 
         else
 
 
 
         {
 
 
 
           if(--t >=0)
 
 
 
           {
 
 
 
             sec = second(line);
 
 
 
             fst = first(line);
 
 
 
             solve(fst, sec, &rc);
 
 
 
             printf("Case #%d: %s %s\n", ++out, preview(rc.max, b1), preview(rc.min, b2));
 
 
 
           }
 
 
 
           pos = 0;
 
 
 
         }
 
 
 
       }
 
 
 
     }
 
 
 
   }
 
 
 
 
 
   if(pos > 0)
 
 
 
   {
 
 
 
     sec = second(line);
 
 
 
     fst = first(line);
 
 
 
     solve(fst, sec, &rc);
 
 
 
     printf("Case #%d: %s %s", ++out, preview(rc.max, b1), preview(rc.min, b2));
 
   }
 
 
 
 
 
   fclose(fd);
 
 
 
   return 0;
 
 
 
 }
 
 
 
 
 
 void solve(long long int places, long long int persons, struct Result * rc)
 
 
 
 {
 
   struct Stack * stack;
 
 
 
   long long int maxPlace;
 
 
 
   long long int left;
 
 
 
   long long int right;
 
 
 
 
 
   stack = createStack();
 
 
 
   pushItem(stack, places);
 
 
 
   while(persons > 0)
 
 
 
   {
 
     persons -= 1;
 
 
 
     maxPlace = popMaxPlace(stack);
 
 
 
     if(maxPlace - maxPlace / 2 * 2 == 1)
 
     {
 
       left = (maxPlace - 1) / 2;
 
       right = (maxPlace - 1) / 2;
 
     }
 
     else
 
     {
 
       left = maxPlace / 2 - 1;
 
       right = maxPlace / 2;
 
     }
 
 
 
     if(persons == 0)
 
     {
 
       rc->max = right;
 
       rc->min = left;
 
     }
 
     else
 
     {
 
       pushItem(stack, left);
 
 
 
       pushItem(stack, right);
 
 
 
     }
 
 
 
   }
 
   releaseStack(stack);
 
 
 
 }
