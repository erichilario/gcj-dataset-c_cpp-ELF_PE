#include <stdio.h>
 #include <stdlib.h>
 
 int main(void) {
 	int T;
 	scanf("%d\n", &T);
 	int i; 
 	char *N = (char *) malloc(21 * sizeof(char));
 	char c;
 	int idx;
 	for (i =1; i<=T; i++) {
 		idx = 0;
 		while ((c = getchar()) != '\n' && c != EOF) {
 			N[idx++] = c;
 		}
 		N[idx]='\0';
 		
 		//we have the numbers
 		//find least idx k;
 		int k =-1;
 		int j;
 		for (j =0 ; j< idx-1; j++) {
 			if (N[j] > N[j+1]) {
 				k = j;
 				break;
 			}
 		}
 		if (k == -1) {
 			printf("Case #%d: %s\n", i,N);
 			continue;
 		}
 		//now find the least feasible index by moving k to the left
 		while (k != 0 && N[k]-N[k-1] == 0)
 			k--;
 
 		//now create the new number by reducing the digit indexed by k and replacing all the digits to the right with 9
 		N[k]= N[k]-1;
 		for (j = k+1; j < idx; j++) {
 			N[j] = '9';
 		}
 		if (k==0 && N[k] == '0' ) N++;
 		printf("Case #%d: %s\n", i,N);
 	}
 	return 0;
 }
