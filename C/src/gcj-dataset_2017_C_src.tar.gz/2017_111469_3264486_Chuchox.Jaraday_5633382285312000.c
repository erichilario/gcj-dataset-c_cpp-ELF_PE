#include <stdio.h>
 
 int main(void){
     int cases, casos;
     char digitos[20];
     char c;
     int i, j, k;
 
     scanf("%d\n",&cases);
     for(casos=1;casos<=cases;casos++){
         i = 0;
         while((c=getchar())!='\n'){
             digitos[i] = c - '0';
             //putchar(digitos[i]+'0');
             i++;
         }
         //putchar('\n');
         for(j=(i-1);j;j--){
             if(digitos[j]<digitos[j-1]){
                 digitos[j-1] -= 1;
                 k=j;
                 while(k<i){
                     digitos[k] = 9;
                     k++;
                 }
                 /*for(k=0;k<i;k++){
                     putchar(digitos[k]+'0');
                 }
                 putchar('\n');*/
             }
         }
 
         printf("Case #%d: ", casos);
         j = 0;
         while(digitos[j] == 0){
             j++;
         }
         for(k=j;k<i;k++){
             putchar(digitos[k]+'0');
         }
         putchar('\n');
     }
 
 
     return(0);
 }

