#include <stdio.h>
 void toarray(unsigned long long int a[],unsigned long long int c,unsigned long long int n)
 {
     unsigned long long int d;unsigned long long int i=c-1;
     while(n>0)
     {
         d=n%10;
         a[i]=d;
         i--;
         n=n/10;
     }
 }
 int check_sort(unsigned long long int a[],unsigned long long int n)
 {
     unsigned long long int i,j,t;
     for(i=1;i<n;++i)
     {
         j=i;
         t=a[i];
         while(j>0)
         {
             if(a[j-1]<=t)
                 break;
             else
                 return 0;
         }
     }
     return 1;
 }
 int main()
 {
     int t,x=1;
     scanf("%d",&t);
     while(t--)
     {
         unsigned long long int n;
         scanf("%llu",&n);
         unsigned long long int i;
         while(n>0)
         {
             unsigned long long int c=0,num=n;
             while(num>0)
             {
                 c++;
                 num/=10;
             }
             unsigned long long int a[c];
             toarray(a,c,n);
             if((check_sort(a,c))==0)
                 n=n-1;
             else
             {
                 printf("Case #%d: ",x);
                 for(i=0;i<c;++i)
                     printf("%llu",a[i]);
                 break;
             }
         }
         printf("\n");x++;
     }
     return 0;
 }

