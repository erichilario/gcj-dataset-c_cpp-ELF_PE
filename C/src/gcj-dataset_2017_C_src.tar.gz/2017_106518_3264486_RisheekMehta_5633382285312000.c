#include<stdio.h>
 int main(){
     int T,case_no;
     FILE *fin,*fo;
     fin=fopen("B-large.in","r");
     fo=fopen("B-large.out","w");
     fscanf(fin,"%d",&T);
     for(case_no=0;case_no<T;case_no++){
         char ch_no[20];
         int no[20];
         fscanf(fin,"%s",ch_no);
         int len=0;
         while(ch_no[len]!='\0'){
             no[len]=ch_no[len]-48;
             len++;
         }
         int i,j,k;
         for(i=0;i<(len-1);i++){
             if(no[i]>no[i+1]){
                 no[i]--;
                 for(j=i;j>0;j--){
                     if(no[j]<no[j-1]){
                         no[j-1]--;
                     }
                     else{
                         break;
                     }
                 }
                 for(k=(j+1);k<len;k++)
                     no[k]=9;
                 break;
             }
         }
         fprintf(fo,"Case #%d: ",case_no+1);
         if(no[0]!=0)
             fprintf(fo,"%d",no[0]);
         for(i=1;i<len;i++)
             fprintf(fo,"%d",no[i]);
         fprintf(fo,"\n");
     }
     return 0;
 }

