#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main(int argc, char* argv[]){
     //Variable decleration to hold 
     
     int num, last, after_last, ans, multiple_ten, orgnl_num, i, j = 1, limit; 
     char tmp[500];
     FILE* fp = fopen(argv[1], "r"); 
     
     if(fp == NULL){
         printf("open error\n");
         exit(1);
     }
     
     if (fgets(tmp, 60, fp) != NULL){
         
         sscanf(tmp, "%d", &limit);
 
         for (j = 1; j <= limit; j++){ 
 
         
             ans = 0; multiple_ten = 1; i = 1;
             
             if (fgets(tmp, 70, fp) != NULL){        
             
                 sscanf(tmp, "%d", &orgnl_num);
                 
                 num = orgnl_num;
                 
                 after_last = num % 10;
             
                 while(num != 0){
                     //Finding out the last number
                     last = num % 10;
                
                     if(last <= after_last){
                         ans = ans + last * multiple_ten;
                         multiple_ten = multiple_ten * 10;
                         
                         num = num/10;
                         
                         after_last = last;
                     }
                     
                     else{
                         num = orgnl_num-i;
                         multiple_ten = 1;
                         after_last = num%10;
                         ans = 0;
                         i++;
                     }
                 }
             printf("Case #%d: %d\n", j, ans);
            
         }
        }
     }
 }

