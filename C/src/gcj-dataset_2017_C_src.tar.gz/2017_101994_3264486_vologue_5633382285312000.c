#include<stdio.h>
 int check(long long a){
 	int l,b;
 	int m=0;
 	b=(int)a%10;
 	a=a/10;
 	while(a!=0){
 		l=(int)a%10;
 		a=a/10;
 		if(l>b){
 			m=1;
 			break;
 		}
 		b=l;
 	}
 		return m;
 }
 int main(){
 	int t,j;
 	long long n,s,i,k=0;
 	scanf("%d",&t);
 	for(j=0;j<t;j++){
 		k++;
 		scanf("%lld",&n);
 		s=n;
 		while(s>0){
 			if(check(s)==0){
 				printf("Case #%lld: %lld\n",k,s);
 				s=-1;
 			} 
 			else 
 			s--;
 		}
 	}
 	return 0;
 }

