#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 int main() {
 
     int T;
 
     long long int N,tidy,wrong;
 
     char S[25],tidyS[25];
 
     scanf("%d", &T);
     //printf("%d\n",T);
 
     for (int i=1;i<=T;i++) {
         scanf("%s", S);
         
         N=atol(S);
         //printf("%lld\n", N);
         //
        
         for (tidy=N; tidy>=1; tidy--) {
             sprintf(tidyS,"%lld",tidy);
             //Logic
             if (tidy < 10) break;
             wrong=0;
             for (int i=0;i<strlen(tidyS)-1;i++) {
                 if (tidyS[i] > tidyS[i+1]) {
                     wrong=1;
                     break;
                 }
             } 
             if (wrong==0) break;
             //End logic
         }
 
         printf("Case #%d: %s\n", i, tidyS);
     }
 
 }

