#include <stdio.h>
 int stlen(char* str){
     int len = 0;
     while(str[len]!='\0'){
         len++;
     }
     return len;
 }
 int main()
 {
     int t;
     scanf("%d",&t);
     char st[2000];
     int x = 1;
     while(t--){
         scanf("%s",st);
         int ps,i,j;
         scanf("%d",&ps);
         int len = stlen(st);
         int count = 0;
         for(i=0;i<len-ps+1;i++){
             if(st[i]=='-'){
                 count++;
                 for(j=i;j<i+ps;j++){
                     if(st[j]=='+'){
                         st[j] = '-';
                     }
                     else {
                         st[j] = '+';
                     }
                 }
             }
         }
         int q = 0;
         for(i=0;i<len;i++){
             if(st[i]=='-'){
                 q = 1;
                 break;
             }
         }
         if(q == 1){
             printf("Case #%d: IMPOSSIBLE\n",x);
         }
         else {
             printf("Case #%d: %d\n",x,count);
         }
         x++;
     }
     return 0;
 }
 

