#include<stdio.h>
 #include<Stdlib.h>
 #include<string.h>
 
 char * tidy(char *);
 char * clear (char * );
 
 void main()
 {
     char a[30];
     int t;
     scanf("%d",&t);
     int i;
     for(i=0;i<t;i++){
         scanf("%s",a);
         char * ans=tidy(a);
         printf("Case #%d:",i+1);
         if(a[0]==' ')
             printf("%s\n",ans);
         else
             printf(" %s\n",ans);
     }
 }
 
 char * tidy(char * a)
 {
     int l=strlen(a);
     int i,j;
     int n1,n2,nt;
     for(i=0;i<l-1;i++){
         n1=a[i]-48;
         n2=a[i+1]-48;
         if(n1>n2){
             j=i;
             while( a[j]==a[j-1] ) j--;
             a[j]--;
             j++;
             while(j<l){
                 a[j]='9';
                 j++;
             }
         }
     }
     return clear(a);
 }
 
 char * clear (char * a)
 {
     if(a[0]=='0') a[0]=' ';
     return a;
 }

