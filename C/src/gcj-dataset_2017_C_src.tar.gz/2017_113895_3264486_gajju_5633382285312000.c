#include<stdio.h>
 #include<string.h>
 
 int t,n,i,f,j;
 char a[20];
 
 
 int main()
 {
 scanf("%d",&t);
 
 for(j=0;j<t;++j)
 {
 f=0;
 scanf("%s",a);
 n=strlen(a);
 
 for(i=1;i<n;++i)
 if(a[i]<a[i-1])
 {
 a[i-1]--;
 f=1;
 if(i!=1)i-=2;
 else {f=1;break;}
 }
 else if(f==1) {i++;break;}
 
 if(f==1)
 for(;i<n;++i)a[i]='9';
 
 for(i=0;a[i]=='0';++i);
 printf("Case #%d: %s\n",j+1,a+i);
 }
 
 
 return 0;
 }

