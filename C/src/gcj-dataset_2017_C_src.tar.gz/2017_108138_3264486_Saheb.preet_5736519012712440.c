#include <stdio.h>
 #include <string.h>
 
 int main()
 {
     int t, l, i, ti, k, j, count;
     char s[ 1001 ];
     scanf( "%d", &t );
     for( ti = 0; ti < t; ti ++ )
     {
         scanf( "%s%d", s, &k );
         l = strlen( s );
         count = 0;
         for( i = 0; i < l; i ++ )
             if( s[ i ] == '-' )
                 if( i + k > l )
                     break;
                 else
                 {
                     for( j = i; j < i + k; j ++ )
                         s[ j ] = s[ j ] == '-' ? '+' : '-';
                     count ++;
                 }
         if( i == l )
             printf( "Case #%d: %d\n", ti + 1, count );
         else
             printf( "Case #%d: IMPOSSIBLE\n", ti + 1 );
     }
     return 0;
 }

