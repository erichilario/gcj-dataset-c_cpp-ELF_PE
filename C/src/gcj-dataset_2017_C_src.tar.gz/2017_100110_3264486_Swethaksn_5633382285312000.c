#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int main()
 {
     int t;
     int n,k;
 
     scanf("%d",&t);
 
     int a[t];
     int i,j;
 
     for(k=0;k<t;k++)
     {
         char buffer [256];
          scanf("%d",&n);
 
     for(i=n;i>=0;i--)
     {
 
         itoa(i,buffer,10);
         int l=strlen(buffer);
         j=l-1;
         while(j>0)
         {
             if(buffer[j]<buffer[j-1])
                 break;
             else
                 j--;
         }
         if(j==0)
         {
             a[k]=i;
             break;
         }
 
     }
     }
     for(k=0;k<t;k++)
     {
         printf("Case #%d: %d\n",k+1,a[k]);
     }
 }
 
 

