#include <stdio.h>
 #include <string.h>
 
 long long sagot(long long *dig, long long k){
 	long long yes = 1;
 	long long last = -1;
 	for(long long i = 0; i < k; i++){
 		if(i+1 >= k) continue;
 		if(dig[i] > dig[i+1]){
 			yes = 0;
 			last = dig[i];
 			break;
 		}
 	}
 	if(yes){
 		long long ret = 0;
 		for(long long i = 0; i < k; i++){
 			ret *= 10;
 			ret += dig[i];
 		}
 		return ret;
 	}
 	long long wew = 0;
 	for(long long i = 0; i < k; i++){
 		if(wew) {dig[i]=9; continue;}
 		if(dig[i] == last){
 			wew = 1;
 			dig[i]--;
 		}
 	}
 	// for(long long i = 0; i < k; i++){
 	// 	if(wew){
 	// 		dig[i] = 9;
 	// 		continue;
 	// 	}
 	// 	if(i+1 >= k) continue;
 	// 	if(dig[i] >= dig[i+1]){
 	// 		wew = 1;
 	// 		dig[i]--;
 	// 	}
 	// }
 	long long ret = 0;
 	for(long long i = 0; i < k; i++){
 		ret *= 10;
 		ret += dig[i];
 	}
 	return ret;
 }
 
 int main(){
 	long long T;
 	scanf("%lld", &T);
 
 	long long i;
 	for(i = 1; i <= T; i++){
 		char str[100];
 		long long len = 0;
 		scanf("%s", str);
 		for(int i = 0; i < 100; i++){
 			if(str[i] == '\0') break;
 			len++;
 		}
 		
 		long long dig[100];
 		for(long long i = 0; i < len; i++){
 			dig[i] = (long long)(str[i]-'0');
 		}
 		long long ans = sagot(dig, len);
 		printf("Case #%lld: %lld\n", i, ans);
 	}
 }

