#include <stdio.h>
 #include <string.h>
 
 int main() {
 	char str[1010];
 	int T, K, len;
 
 	scanf("%d", &T);
 
 	for (int i = 1; i <= T; i++) {
 		scanf("%s %d", str, &K);
 		len = strlen(str);
 
 		int ret = 0;
 		int j;
 
 		for (j = 0; j <= len - K; j++) {
 			if (str[j] == '-') {
 				ret++;
 				for (int k = 0; k < K; k++) {
 					if (str[j + k] == '-') str[j + k] = '+';
 					else str[j + k] = '-';
 				}
 			}
 //			printf("%s\n", str);
 		}
 
 		for (; j < len; j++) if  (str[j] == '-') ret = -1;
 
 		if (ret < 0) printf("Case #%d: IMPOSSIBLE\n", i);
 		else printf("Case #%d: %d\n", i, ret);
 	}
 	return 0;
 }

