#include <stdio.h>
 #include <string.h>
 
 int isTidy(char num[],int len);
 
 int main(void){
     FILE *fPtrQ = fopen("/Users/Clown0/Desktop/Hello World/Hello World/Que.txt", "r");
     FILE *fPtrA = fopen("/Users/Clown0/Desktop/Hello World/Hello World/Ans.txt", "w");
     
     int t=0,x=1,len,inum;
     char num[18];
     fscanf(fPtrQ, "%d", &t);
     
     while (t--) {
         fscanf(fPtrQ, "%s", num);
         
         len = strlen(num)-1;
         while (isTidy(num,len) == 0) {
             inum = atoi(num)-1;
             sprintf(num, "%d",inum);
             len = strlen(num)-1;
         }
         
         fprintf(fPtrA, "Case #%d: %s\n",x++,num);
     }
     fclose(fPtrQ);
     fclose(fPtrA);
     return 0;
 }
 
 int isTidy(char num[], int len){
     int i;
     
     for(i=len; i>0 ;i--){
         if(num[i-1] > num[i])
             return 0;
     }
     
     return 1;
 }
