
 #include <stdio.h>
 
 int main() {
 	int T,t;
 	scanf("%d",&T);
 	t = T;
 	while(t--)
 	{
 	    long long int N,K;
 	    scanf("%lld %lld",&N,&K);
 	    char S[100];
 	    int i = 0;
 	    while(K!=1)
 	    {
 	        if(K%2 == 0)
 	        S[i] = 'r';
 	        else S[i] = 'l';
 	        i++;
 	        K = K/2;
 	    }
 	    if(i>=2&& S[0] == 'l' && S[1] == 'r')
 	    {
 	        while(i>2)
 	        {
 	            if(S[i-1] == 'l')
 	            {
 	                if(N%2!=0)
 	                N = N/2;
 
 	                else N = N/2 -1;
 	            }
 
 	            else N = N/2;
 	            i--;
 	        }
 	        long long int PP = N;
 	        while(i>0)
 	        {
 	            if(S[i-1] == 'l')
 	            {
 	                if(N%2!=0)
 	                N = N/2;
 
 	                else N = N/2 -1;
 	                PP = PP/2;
 	            }
 
 	            else {
 	                N = N/2;
 	                PP = PP%2==0?PP/2-1:PP/2;
 	            }
 	            i--;
 	        }
 	        if(PP > N)
 	        N = PP;
 	    }
 	    else{
 
 
 	    while(i>0)
 	    {
 	        if(S[i-1] == 'l')
 	        {
 	            if(N%2!=0)
 	            N = N/2;
 	            else N = N/2 -1;
 	        }
 	        else N = N/2;
 	        i--;
 	    }
 	    }
 	    if(N==0)
 	    N++;
 	    if(N%2==0)
 	    {
 	        printf("Case #%d: %lld %lld\n",T-t,N/2,N/2-1);
 	    }
 	    else printf("Case #%d: %lld %lld\n",T-t,N/2,N/2);
 	}
 	return 0;
 }

