#include <stdio.h>
 #include <string.h>
 
 void next_tidy(char *num, int slen) {
 	int i, isflipped;
 	
 	if(slen > 1) {
 		isflipped = 0;
 		
 		for(i = 1; i < slen; ++i) {
 			if(num[i - 1] > num[i]) {
 				if(num[i - 1] == '9' && isflipped) {
 					num[i] = '9';
 				}
 				else {
 					--num[i - 1];
 					num[i] = '9';
 					
 					isflipped = !isflipped ? !isflipped : isflipped;
 				}
 			}
 		}
 		
 		//isflipped = 0;
 		for(i = slen - 2; i >= 1; --i) {
 			if(num[i - 1] > num[i]) {
 				//if(num[i - 1] == '9' && isflipped) {
 				//	num[i] = '9';
 				//}
 				//else {	
 					--num[i - 1];
 					num[i] = '9';
 				//}
 				
 				//isflipped = !isflipped ? !isflipped : isflipped;
 			}
 		}
 	}
 	
 	i = 0;
 	while(num[i] == '0' && i < slen) {
 		++i;
 	}
 	
 	printf("%s\n", num + i);
 }
 
 int main(void) {
 	int t;
 	int testcases, slen;
 	char anum[20];
 	
 	scanf("%d", &testcases);
 	
 	for(t = 0; t < testcases; ++t) {
 		scanf("%s", anum);
 		slen = strlen(anum);
 		
 		printf("Case #%d: ", t + 1);
 		next_tidy(anum, slen);
 	}
 }
