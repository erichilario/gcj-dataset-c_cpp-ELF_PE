#include <stdio.h>
 void flip(char *S,int start  ,int end )
 {
     while(start<=end)
     {
         if(S[start] == '+') S[start] = '-';
         else S[start] = '+';
         start++;
     }
 }
 int main() {
 	int t,k,T;
 	scanf("%d",&t);
 	T = t;
 	int ind = 0;
 	while(t--)
 	{
 	    char S[1000];
 	    scanf("%s",S);
 	    scanf("%d",&k);
 	    int p1=0,p2=strlen(S)-1;
 	    while(p1<strlen(S)&&p2>=0)
 	    {
 	        if(S[p1] == '-')
 	        break;
 	        if(S[p2] == '-')
 	        break;
 	        p1++;p2--;
 	    }
 	    if(S[p1] == '-' && p1%k == 0 ) ind = 1;
 	    else ind = 0;
 	    if(ind == 0)
 	    {
 	        int i = 0,count = 0;
 	        for(;i<strlen(S);++i)
 	        {
 	            if(S[i] == '-')
 	            {
 	                if(strlen(S) - i >= k)
 	                {
 	                    count++;
 	                    flip(S,i,i+k-1);
 	                }
 
 	                else {printf("Case #%d: IMPOSSIBLE\n",T-t);goto B;}
 	            }
 
 	        }
 	        printf("Case #%d: %d\n",T - t ,count);
 	    }
 	    else {
 	            int i = strlen(S)-1,count = 0;
 	            for(;i>=0;--i)
 	            {
 	                if(S[i] == '-')
 	                {
 	                    if(i+1 >= k)
 	                    {
 	                        count++;
 	                        flip(S,i-k+1,i);
 	                    }
 	                    else {printf("Case #%d: IMPOSSIBLE\n",T-t);goto B;}
 	                }
 
 	            }
 	            printf("Case #%d: %d\n",T - t ,count);
 	    }
 	    B : ;
 
 
 
 
 	}
 	return 0;
 }

