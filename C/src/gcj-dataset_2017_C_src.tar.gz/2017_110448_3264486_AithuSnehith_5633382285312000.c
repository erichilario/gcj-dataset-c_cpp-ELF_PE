#include<stdio.h>
 #include<string.h>
 
 struct node{
 	char a[100];
 };
 
 int main()
 {
 	int test=0;
 	scanf("%d", &test);
 	struct node in[test];
 	for(int k=0;k<=test-1;k++)
 	{
 		scanf("%s", &in[k].a);
 	}
 	for(int k=1;k<=test;k++)
 	{
 		int i;
 		int x=0;
 		
 		x=strlen(in[k-1].a);
 		for(int i=x-1;i>0;i--)
 		{	
 			
 			if(in[k-1].a[i-1]>in[k-1].a[i])
 			{
 				for(int j=i;j<=x-1;j++)    in[k-1].a[j]='9';
 				in[k-1].a[i-1]=in[k-1].a[i-1]-1;
 			}
 		}
 		printf("case #%d: ", k);	
 		for(int i=0;i<x;i++)
 		{
 			
 			if(in[k-1].a[i] != '0')	printf("%c", in[k-1].a[i]);
 		
 		}
 		printf("\n");
 	}
     return 0;
 }

