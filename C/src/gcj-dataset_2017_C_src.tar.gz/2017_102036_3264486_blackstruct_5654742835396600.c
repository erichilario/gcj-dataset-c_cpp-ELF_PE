#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main(int argc,char** argv)
 {
     FILE* in=fopen(argv[1], "r");
     FILE* out=fopen(argv[2], "w");
     char tab[2001];
     int i=0;
     int j=0;
     int n=0;
     int c=0;
     int a=0;
     int max;
     int imax;
     int compt=0;
    int k=0;
    fscanf(in,"%d",&k);
     for(i=1;i<=k;i++){
         fprintf(out,"Case #%d: ",i);
         fscanf(in,"%d",&j);
         fscanf(in,"%d",&n);
         tab[0]=1;
         for(a=1;a<j+2;a++){
             tab[a]=0;
         }
         tab[j+1]=1;
         for(a=0;a<n;a++){
             c=1;
             max=0;
             imax=0;
             while(c<j+1){
             compt=0;
                 while(tab[c]!=1){
                     compt++;
                     c++;
                 }
                 if(compt>max){
                     max=compt;
                     imax=c;
                 }
                 c++;
             }
             tab[imax-max/2-1]=1;
             printf("%d\n",imax-max/2-1);
         }
 
         if(max%2==1){
          fprintf(out,"%d %d\n",max/2,max/2);
 
         }else{
          fprintf(out,"%d %d\n",max/2,max/2-1);
         }
     }
    fclose(in);
    fclose(out);
     return 0;
 }
 

