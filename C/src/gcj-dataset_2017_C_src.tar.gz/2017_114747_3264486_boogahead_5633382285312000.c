#include <stdio.h>
 int check(int a)
 {
 	int i,j,sac,storage,tmp;
 	for (i = a; i > 0; i--)
 	{
 		storage = i;
 		tmp = i;
 		while (tmp > 0)
 		{
 			sac = tmp % 10;
 			tmp /= 10;
 			if (sac < (tmp) % 10)
 			{
 				break;
 			}
 			if (tmp == 0)
 			{
 				return storage;
 			}
 		}
 	}
 }
 int main(void)
 {
 	FILE *ifp,*ofp;
 	int res,times,i,result;
 	int store[100];
 	ifp = fopen("B-small-attempt0.in", "r");
 	ofp = fopen("output.txt", "w");
 	res = fscanf(ifp, "%d", &times);
 	for (i = 0; i < times; i++)
 	{
 		res = fscanf(ifp, "%d", &store[i]);
 		result=check(store[i]);
 		fprintf(ofp, "Case #%d: %d\n", i+1, result);
 	}
 	fclose(ifp);
 	fclose(ofp);
 }
