#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     int T, t;
     long long N;
     int digit[20], len, i, j;
 
     scanf( "%d\n", &T );
     for( t = 1 ; t <= T ; t++ )
     {
         scanf( "%lld\n", &N );
 
         len = 0;
         while( N > 0 )
         {
           digit[len++] = N%10;
           N = N / 10ll;
         }
         
         for( i = 1 ; i < len ; i++ )
         {
           if( digit[i-1] < digit[i] )
           {
             digit[i] -= 1;
             for( j = 0 ; j < i ; j++ )
               digit[j] = 9;
           }
         }
 
         N = 0ll;
         for( i = len-1 ; i >= 0 ; i-- )
           N = N * 10ll + (long long)digit[i];
 
         printf( "Case #%d: %lld\n", t, N );
     }
 
     return 0;
 }

