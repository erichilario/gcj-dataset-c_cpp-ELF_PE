#include <stdio.h>
 #include <string.h>
 
 unsigned int up,down;
 
 void flip(char *s,size_t len,unsigned int width,unsigned int x)
 	{
 	s += x;
 	for(;width;width--,s++)
 		{
 		if(*s=='+')
 			{
 			*s='-';
 			up--;
 			}
 		else
 			{
 			*s='+';
 			up++;
 			}
 		}
 	}
 
 int main(int argc,char *argv[])
 	{
 	unsigned int num_tests,t,s,x;
 	size_t len;
 	int k;
 	char pancakes[1001],*pos,*lastpos;
 
 	scanf("%d\n",&num_tests);
 	for(t=0;t<num_tests;t++)
 		{
 		scanf("%s %d\n",pancakes,&s);
 		len=strlen(pancakes);
 		up=0;
 		for(pos=pancakes;*pos!='\0';pos++)
 			{
 			if(*pos=='+')
 				{
 				up++;
 				}
 			}
 		
 		k=0;
 		lastpos=pancakes;
 		while((pos=strchr(pancakes,'-'))!=NULL)
 			{
 			down=len-up;
 			if(pos<lastpos)
 				{
 				k=-1;
 				break;
 				}
 			
 			k++;
 			x=pos-pancakes;
 			if(x+s>len)
 				{
 				x=len-s;
 				}
 			flip(pancakes,len,s,x);
 			lastpos=pos;
 			}
 		
 		if(k>=0)
 			{
 			printf("Case #%d: %d\n",t+1,k);
 			}
 		else
 			{
 			printf("Case #%d: IMPOSSIBLE\n",t+1);
 			}
 		}
 	}

