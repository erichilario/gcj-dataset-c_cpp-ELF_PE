#include<stdio.h>
 #include<math.h>
 #include<string.h>
 #include<stdlib.h>
 
 void flip(char s[],int k,int j)
 {
     int i;
     for(i=j;i<j+k;i++)
     {
         if(s[i]=='+')
             s[i]='-';
         else
             s[i]='+';
     }
 }
 int main()
 {
     int t,i,j;
     scanf("%d",&t);
     for(i=0;i<t;i++)
     {
         char s[10];
         int k,cflip=0;
         scanf("%s",s);
         scanf("%d",&k);
         for(j=0;j<strlen(s)-k+1;j++)
         {
             if(s[j]=='-')
             {
                 flip(s,k,j);
                 cflip++;
             }
         }
         int count=1;
         for(j=0;j<strlen(s);j++)
         {
             if(s[j]=='-')
                 count=0;
         }
         if(count==0)
             printf("Case #%d: IMPOSSIBLE\n",i+1);
         else
             printf("Case #%d: %d\n",i+1,cflip);
     }
         return 0;
 }

