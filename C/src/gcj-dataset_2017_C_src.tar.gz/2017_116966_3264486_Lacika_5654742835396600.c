#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     int nrT, nrC=1, *st, n, k, i, j;
     FILE* f, *df;
     int *ls, *rs;
     int *maxS, *minS, minAux, contor;
     if((f=fopen("C-small-1-attempt8.in", "r"))==NULL)
     {
         perror("C-small-1-attempt8.in");
         exit(0);
     }
     if((df=fopen("output.in", "w"))==NULL)
     {
         perror("output.in");
         exit(0);
     }
     fscanf(f, "%d", &nrT);
     while(nrT--)
     {
         fscanf(f, "%d", &n);
         fscanf(f, "%d", &k);
         st=(int*)malloc(sizeof(int)*n);
         ls= (int*)malloc(sizeof(int)*n);
         rs= (int*)malloc(sizeof(int)*n);
         maxS= (int*)malloc(sizeof(int)*n);
         minS= (int*)malloc(sizeof(int)*n);
         for(i=0;i<n;i++){
             st[i] = 0;
         }
         while(k--)
         {
             for(i=0; i<n; i++)
             {
                 ls[i]=rs[i]=maxS[i]=minS[i]=0;
             }
 
             for(i=0; i<n; i++)
             {
                 if(st[i]==0)
                 {
                     for(j=i+1; j<n && st[j]==0; j++)
                     {
                         rs[i]++;
                     }
                     for(j=i-1; j>=0 && st[j]==0; j--)
                     {
                         ls[i]++;
                     }
                 }
             }
             for(i=0; i<n; i++)
             {
                 maxS[i]=ls[i]>rs[i]?ls[i]:rs[i];
                 minS[i]=ls[i]<rs[i]?ls[i]:rs[i];
             }
 
             for(i=0; i<n; i++)
                 if(st[i]==0)
                     break;
             minAux = i;
             contor =0;
             for(i=i+1; i<n; i++)
             {
                 if(st[i]!= 1 && minS[minAux]<minS[i])
                 {
                     minAux=i;
                     contor=0;
                 }
                 else if(st[i]!= 1 && minS[minAux]==minS[i])
                 {
                     contor++;
                 }
             }
             if(contor==0)
             {
                 st[minAux]=1;
                 if(k==0) fprintf(df, "Case #%d: %d %d\n", nrC, maxS[minAux], minS[minAux]);
             }
             else
             {
                 contor = 0;
                 for(i=minAux+1; i<n; i++)
                 {
                     if(st[i]!= 1 && minS[minAux] == minS[i] && maxS[minAux]<maxS[i])
                     {
                         minAux=i;
                         contor = 0;
                     }
                     else if(st[i]!= 1 && minS[minAux] == minS[i] && maxS[minAux]==maxS[i])
                     {
                         contor++;
                     }
                 }
                 st[minAux]=1;
                 if(k==0) fprintf(df, "Case #%d: %d %d\n", nrC, maxS[minAux], minS[minAux]);
 
             }
         }
         nrC++;
 
     }
     return 0;
 }

