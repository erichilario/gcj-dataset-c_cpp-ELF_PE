#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 void flip(char *string, int start, int k);
 
 int main() {
     int T;
 
     scanf("%d", &T);
 
     char string[1001];
     int K;
     for (int idx = 0; idx < T; idx++) {
         scanf("%s %d", string, &K);
 
         int finished = 0;
         int count = 0;
         int prev = 0;
 
         int set = 1;
         while (!finished) {
             for (int jdx = 0; jdx < strlen(string); jdx++) {
                 if (string[jdx] == '-') {
                     if ((jdx <= prev) && (jdx != 0)) {
                         printf("Case #%d: IMPOSSIBLE\n", idx + 1);
                         set = 0;
                     }
                     if (jdx + K > strlen(string)) {
                         printf("Case #%d: IMPOSSIBLE\n", idx + 1);  
                         set = 0;
                     }
                     flip(string, jdx, K);
                     count++;
                     prev = jdx;
                     break;
                 }
             }
 
             finished = 1;
             for (int jdx = 0; jdx < strlen(string); jdx++)
                 if (string[jdx] =='-')
                     finished = 0;
             if (set == 0)
                 finished = 1;
         }
         if (set != 0)
             printf("Case #%d: %d\n", idx + 1, count);
     }
 }
 
 void flip(char *string, int start, int k) {
     for (int idx = start; idx < (start + k); idx++) {
         if (string[idx] == '+')
             string[idx] = '-';
         else
             string[idx] = '+';
     }
 }

