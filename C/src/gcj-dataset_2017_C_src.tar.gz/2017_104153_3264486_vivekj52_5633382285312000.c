#include<stdio.h>
 
 int main()
 {
 	int tc;
 	scanf("%d",&tc);
 	for(int i=1;i<=tc;i++)
 	{
 		long long int n;
 		scanf("%lld",&n);
 		while(n)
 		{
 			long long int num=n;
 			while(num)
 			{
 				int x,y;
 				x=num%10;
 				num/=10;
 				y=num%10;
 				if(x<y)
 					break;
 			}
 			if(num==0)
 				break;
 			n--;
 		}
 		printf("Case #%d: %lld\n",i,n);
 	}
 	return 0;
 }
