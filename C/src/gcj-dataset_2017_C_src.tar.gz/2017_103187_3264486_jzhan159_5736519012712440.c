#include <stdio.h>
 #include <stdlib.h>
 #include <unistd.h>
 
 int main(int argc, char ** argv){
   FILE * input = fopen(argv[1], "r");
   FILE * output = fopen(argv[2], "w");
   char * testcase = NULL;
   size_t size = 0;
   int temp = getline(&testcase, &size, input);
   if(temp == -1){
     exit(1);
   }
   int num = atoi(testcase);
   // printf("num: %d\n", num);
 
   temp = 0;
   int k;
 
 
 
   while(getline(&testcase, &size, input) != -1){
       char * face = malloc(4096);
       int k = 0;
       // fprintf(stderr, "testcase: %s\n", testcase);
       sscanf(testcase, "%s %d\n", face, &k);
       // fprintf(stderr, "+-: %s k:%d\n", face, k);
 
       // solve the pwd
       int times = 0;
       char * curr = face;
       while(*curr){
           if(*curr == '-'){
               times ++;
               int i = 0;
               for(i = 0; i < k; i++){
                   if(!*(curr+i)){
                       times = -1;
                       break;
                   }
                   if(*(curr + i) == '-')
                       *(curr + i) = '+';
                   else
                       *(curr + i) = '-';
               }
               if(times == -1){
                   break;
               }
           }
           curr ++;
       }
       // printf("face: %s times: %d\n", face, times);
       temp ++;
       if(times != -1)
         fprintf(output, "Case #%d: %d\n", temp, times);
       else
         fprintf(output, "Case #%d: IMPOSSIBLE\n", temp);
 
       if(temp == num){
           free(face);
           break;
       }
       free(face);
       face = NULL;
   }
   free(testcase);
   fclose(input);
   return 0;
 }

