#include <stdio.h>
 #include <string.h>
 
 int isPair(int number)
 {
 	return number % 2 == 0;
 }
 
 void printArray(int array[1000], int k, int start)
 {
 	int i;
 
 	printf("[");
 	for (i = 0; i < k; i++)
 	{
 		printf("%d", array[(start + i) % k]);
 		if (i != k -1) printf(" ");
 	}
 	printf("]\n");
 }
 
 int main()
 {
 	int i, j, n, k, m, current, changes, s, flips[1000];
 	char string[1000];
 
 	scanf("%d", &n);
 	for (i = 0; i < n; i++)
 	{
 		changes = 0;
 		scanf("%s %d", string, &k);
 
 		for (j = 0; j < k; j++) flips[j] = 0;
 		s = strlen(string);
 
 		for (j = 0, current = 0; j < s; j++)
 		{
 			//printArray(flips, k, j);
 
 			if ((string[j] == '-' && isPair(flips[current])) || (string[j] == '+' && !isPair(flips[current])))
 			{
 				for (m = 0; m < k; m++)
 				{
 					flips[(current+1+m) % k] += 1;
 				}
 				changes++;
 			}
 			flips[current] = 0;
 			current = (current + 1) % k;
 		}
 
 		printf("Case #%d: ", i+1);
 		if (flips[current] == 0) printf("%d\n", changes);
 		else printf("IMPOSSIBLE\n");
 	}
 
 	return 0;
 }
