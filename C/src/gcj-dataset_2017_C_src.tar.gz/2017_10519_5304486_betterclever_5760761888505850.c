#include <stdio.h>
 int main()
 {
     int t;
     scanf("%d", &t);
     int i, j, x, y;
     char a[100][100];
     for (x = 1; x <= t; x++)
     {
         int r, c;
         scanf("%d%d", &r, &c);
         for (i = 0; i < r; i++)
         {
             scanf("%s", a[i]);
   //          printf("%s\n",a[i]);
         }
 /*
 	for (i = 0; i < r; i++)
         {
             //for (j = 0; j < c; j++)
             //{
                 printf("%s", a[i]);
            // }
             printf("\n");
         }
 */
         for (i = 0; i < r; i++)
         {
             for (j = 0; j < c; j++)
             {
                 char z = a[i][j];
                 if (z != '?')
                 {
                     for (y = j + 1; y < c; y++)
                     {
                         if (a[i][y] != '?')
                         {
                             break;
                         }
                         a[i][y] = a[i][y - 1];
                     }
                 }
             }
         }
         for (i = r - 1; i >= 0; i--) {
             for (j = c - 1; j >= 0; j--) {
                 char z = a[i][j];
                 if (z != '?') {
                     for (y = j - 1; y >= 0; y--) {
                         if (a[i][y] != '?') {
                             break;
                         }
                         a[i][y] = a[i][y + 1];
                     }
                 }
             }
         }
         for (i = 0; i < r; i++)
         {
             if (a[i][0] != '?')
             {
                 if (i != 0)
                 {
                     if (a[i - 1][0] == '?')
                     {
                         for (j = 0; j < c; j++)
                         {
                             a[i - 1][j] = a[i][j];
                         }
                     }
                 }
                 if (i != r - 1)
                 {
                     if (a[i + 1][0] == '?')
                     {
                         for (j = 0; j < c; j++)
                         {
                             a[i + 1][j] = a[i][j];
                         }
                     }
                 }
             }
         }
 
         for (i = r-1; i >= 0; i--)
         {
             if (a[i][0] != '?')
             {
                 if (i != 0)
                 {
                     if (a[i - 1][0] == '?')
                     {
                         for (j = 0; j < c; j++)
                         {
                             a[i - 1][j] = a[i][j];
                         }
                     }
                 }
                 if (i != r - 1)
                 {
                     if (a[i + 1][0] == '?')
                     {
                         for (j = 0; j < c; j++)
                         {
                             a[i + 1][j] = a[i][j];
                         }
                     }
                 }
             }
         }
 
         printf("Case #%d:\n",x);
         for (i = 0; i < r; i++)
         {
             for (j = 0; j < c; j++)
             {
                 printf("%c", a[i][j]);
             }
             printf("\n");
         }
     }
     return 0;
 }

