#include <stdio.h>
 #include <stdlib.h>
 
 int calcola_min(int vettore[], int posizione, int massimo){
     //destra
 
     int contatore = posizione + 1;
     int numero_destra = 0;
     int numero_sinistra = 0;
     while (1 == 1){
         if(vettore[contatore] != 0 || contatore == massimo){
             if(contatore == massimo && vettore[contatore] == 0){
                 numero_destra++;
             }
             break;
         }else{
             numero_destra++;
         }
         contatore++;
     }
 
     //sinistra
 
     contatore = posizione - 1;
     while (1 == 1){
         if(vettore[contatore] != 0 || contatore == 0){
             if(contatore == 0 && vettore[contatore] == 0){
                 numero_sinistra++;
             }
             break;
         }else{
             numero_sinistra++;
         }
         contatore--;
     }
     if(numero_destra <= numero_sinistra){
         return numero_destra;
     }else{
         return numero_sinistra;
     }
 }
 
 int calcola_max(int vettore[], int posizione, int massimo){
     //destra
 
     int contatore = posizione + 1;
     int numero_destra = 0;
     int numero_sinistra = 0;
     while (1 == 1){
         if(vettore[contatore] != 0 || contatore == massimo){
             if(contatore == massimo && vettore[contatore] == 0){
                 numero_destra++;
             }
             break;
         }else{
             numero_destra++;
         }
         contatore++;
     }
 
     //sinistra
 
     contatore = posizione - 1;
     while (1 == 1){
         if(vettore[contatore] != 0 || contatore == 0){
             if(contatore == 0 && vettore[contatore] == 0){
                 numero_sinistra++;
             }
             break;
         }else{
             numero_sinistra++;
         }
         contatore--;
     }
     if(numero_destra >= numero_sinistra){
         return numero_destra;
     }else{
         return numero_sinistra;
     }
 }
 
 int main(){
     FILE * input;
     FILE * output;
     int iterazioni;
     int contatore;
     int i;
     int maxConveniente = 0;
     int minConveniente = 0;
 
     input = fopen("input.in", "r");
     output = fopen("output.txt", "w+");
 
     fscanf(input, "%d", &iterazioni);
 
     for(contatore = 0; contatore < iterazioni; contatore++){
         int bagni;
         int persone;
         fscanf(input, "%d", &bagni);
         fscanf(input, "%d", &persone);
 
         //creazione array di riferimento
 
         int RapprBagni[bagni+2];
         RapprBagni[0] = 1;
         RapprBagni[bagni+1] = 1;
         for(i = 1; i <= bagni; i++){
             RapprBagni[i] = 0;
         }
 
         //posizionamento
         if((bagni+2)%2 == 0){
             RapprBagni[((bagni+2)/2)-1] = 1;
             if (persone == 1){
                 maxConveniente = calcola_max(RapprBagni, ((bagni+2)/2)-1, bagni + 1);
                 minConveniente = calcola_min(RapprBagni, ((bagni+2)/2)-1, bagni + 1);
             }
         }else{
             RapprBagni[((bagni+2)/2)] = 1;
             if (persone == 1){
                 maxConveniente = calcola_max(RapprBagni, (bagni+2)/2, bagni + 1);
                 minConveniente = calcola_min(RapprBagni, (bagni+2)/2, bagni + 1);
             }
         }
 
         for(i = 1; i < persone; i++){
             //printf("%d\n", RapprBagni[i]);
             maxConveniente = 0;
             minConveniente = 0;
             int cont;
             /*printf("Persona %d", i);
             printf("\n");*/
             //controllo posizioni migliori
 
             for(cont = 1; cont < bagni+2; cont++){
                 if(RapprBagni[cont] == 0){
                     int maxTemp = calcola_max(RapprBagni, cont, bagni + 1);
                     int minTemp = calcola_min(RapprBagni, cont, bagni + 1);
                     if(minTemp > minConveniente){
                         maxConveniente = maxTemp;
                         minConveniente = minTemp;
                     }else if(minTemp == minConveniente){
                         if(maxTemp > maxConveniente){
                             maxConveniente = maxTemp;
                             minConveniente = minTemp;
                         }
                     }
                 //printf("%d %d %d %d\n", maxTemp, minTemp, minConveniente, maxConveniente);
                 }
             }
 
             //Piazzamento
             for(cont = 1; cont < bagni+2; cont++){
                 if(RapprBagni[cont] == 0){
                     int maxTemp = calcola_max(RapprBagni, cont, bagni + 1);
                     int minTemp = calcola_min(RapprBagni, cont, bagni + 1);
                     if(minTemp == minConveniente && maxTemp == maxConveniente){
                         RapprBagni[cont] = i+1;
                         break;
                     }
                 }
             }
         }
         /*for(i = 0; i < bagni+2; i++){
             printf("%d ", RapprBagni[i]);
         }
         printf("\n");*/
         fprintf(output, "Case #%d: %d %d\n",contatore+1, maxConveniente, minConveniente);
     }
 
 
     return 0;
 }

