#include<stdio.h>
 int main()
 {
 	long long int t,q;
 	scanf("%lld",&t);
 	q=1;
 	while(q!=t+1)
 	{
 		long long int n,x,r,p=0;
 		scanf("%lld",&n);
 		while(n!=0)
 		{	x=n;
 			while(x!=0)
 			{
 				r=x%10;
 				x=x/10;
 				if(r>=x%10)
 				{
 					p=0;
 				}
 				else
 				{
 					p=1;
 					break;
 				}
 			}
 			if(p==0)
 			{
 				printf("Case #%lld: %lld\n",q,n);
 				break;
 			}
 			n--;
 		}
 		q++;
 	}
 }
