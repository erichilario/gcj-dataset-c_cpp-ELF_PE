#include <stdio.h>
 #include <string.h>
 
 int isTidy(char num[],int len);
 
 
 int main(void){
     FILE *fPtrQ = fopen("/Users/Clown0/Desktop/Hello World/Que.txt", "r");
     FILE *fPtrA = fopen("/Users/Clown0/Desktop/Hello World/Ans2.txt", "w");
     
     int t=0,x=1,len,k,i;
     char num[19],temp;
     fscanf(fPtrQ, "%d", &t);
     
     while (t--) {
         fscanf(fPtrQ, "%s", num);
         len = (int)strlen(num)-1;
         
         for (i=0; i<(len+1)/2; i++) {
             temp = num[i];
             num[i] = num[len-i];
             num[len-i] = temp;
         }
         
         while ((k = isTidy(num,len)) != -1) {
             if (num[k] != '0') {
                 --num[k];
                 for (i=k-1; i>=0; --i)
                     num[i] = '9';
                 if(num[len] == '0'){
                     num[len] = '\0';
                     --len;
                 }
             }
             else{
                 num[k] = '9';
                 for(i=k+1; num[i]=='0'; i++)
                     num[k] = '9';
                 if (k == len) {
                     num[k] = '\0';
                     len--;
                 }
                 else
                     num[k]--;
             }
         }
         
         for (i=0; i<(len+1)/2; i++) {
             temp = num[i];
             num[i] = num[len-i];
             num[len-i] = temp;
         }
         fprintf(fPtrA, "Case #%d: %s\n",x++,num);
         
     }
     fclose(fPtrQ);
     fclose(fPtrA);
     return 0;
 }
 
 int isTidy(char num[], int len){
     int i;
     
     for(i=len; i>0 ;--i){
         if(num[i] > num[i-1])
             return i;
     }
     
     return -1;
 }
