#include <stdio.h>
 
 
 
 void check(char *, char *);
 
 int asc(char *, int);
 
 void reduce(char *, int);
 
 char toc(char);
 
 
 
 int main(int argc, char ** argv)
 
 {
 
   char line[1050];
 
   char prep[1050];
 
   int pos;
 
   int out;
 
   FILE * fd;
 
   int bs;
 
   char buf[1];
 
   int t;
 
 
 
   t = -1;
 
   pos = 0;
 
 
 
   if(argc < 2)
 
   {
 
     printf("Please specify input file.\n");
 
     return 1;
 
   }
 
 
 
   out = 1;
 
   fd = fopen(argv[1], "rb");
 
 
 
   while(!feof(fd))
 
   {
 
     bs = fread(buf, 1, 1, fd);
 
 //printf("%c", buf[0]);
 
     if(bs > 0)
 
     {
 
       if(buf[0] != '\r' && buf[0] != '\n')
 
       {
 
         line[pos] = buf[0];
 
         line[++pos] = '\0';
 
       }
 
       else if(pos > 0)
 
       {
 
         if(t == -1)
 
         {
 
           t = atoi(line);
 
           pos = 0;
 
         }
 
         else if(--t >= 0)
 
         {
 
           check(line, prep);
 
           printf("Case #%d: %s\n", out++, line);         
 
           pos = 0;
 
         }
 
       }
 
     }
 
   }
 
 
 
   if(pos > 0)
 
   {
 
     check(line, prep);
 
     printf("Case #%d: %s", out++, line);         
 
   }
 
   fclose(fd);
 
 
 
 /*
 
   strcpy(line, "132");
 
   check(line, prep);
 
   printf("Case #1: %s\n", line);
 
 
 
   strcpy(line, "1000");
 
   check(line, prep);
 
   printf("Case #2: %s\n", line);
 
 
 
   strcpy(line, "7");
 
   check(line, prep);
 
   printf("Case #3: %s\n", line);
 
 
 
   strcpy(line, "111111111111111110");
 
   check(line, prep);
 
   printf("Case #4: %s\n", line);
 
 */
 
 
 
   return 0;
 
 }
 
 
 
 char toc(char ch)
 
 {
 
   switch(ch)
 
   {
 
     case '0': return 0;
 
     case '1': return 1;
 
     case '2': return 2;
 
     case '3': return 3;
 
     case '4': return 4;
 
     case '5': return 5;
 
     case '6': return 6;
 
     case '7': return 7;
 
     case '8': return 8;
 
     case '9': return 9;
 
   }
 
   return 0;
 
 }
 
 
 
 char tocc(char ch)
 
 {
 
   switch(ch)
 
   {
 
     case 0: return '0';
 
     case 1: return '1';
 
     case 2: return '2';
 
     case 3: return '3';
 
     case 4: return '4';
 
     case 5: return '5';
 
     case 6: return '6';
 
     case 7: return '7';
 
     case 8: return '8';
 
     case 9: return '9';
 
   }
 
   return '0';
 
 }
 
 
 
 void solve(char * str, int ln)
 
 {
 
   int result;
 
   int i;
 
   int j;
 
   result = 0;
 
   while(result == 0)
 
   {
 
     result = 1;
 
     for(i = ln - 1; i >= 1; i--)
 
       if(str[i - 1] > str[i])
 
       {
 
         result = 0;
 
         for(j = i; j < ln; j++)
 
           str[j] = 9;
 
         str[i - 1] -= 1;
 
         i = -1;
 
       }
 
   }
 
 }
 
 
 
 void check(char * kf, char * td)
 
 {
 
   int ln;
 
   int i;
 
   ln = strlen(kf);
 
   for(i = 0; i < ln; i++)
 
     td[i] = toc(kf[i]);
 
   solve(td, ln);
 
   for(i = 0; i < ln; i++)
 
     kf[i] = tocc(td[i]);
 
   while(kf[0] == '0')
 
   {
 
     strcpy(td, kf+1);
 
     strcpy(kf, td);
 
   }
 
 }
