#include<bits/stdc++.h>
 using namespace std;
 typedef long long int ll;
 typedef unsigned long long int ull;
 const int MOD = 1000000007;
 #define op(x) (x&(-x))
 #define trace1(x)                cerr << #x << ": " << x << endl;
 #define trace2(x, y)             cerr << #x << ": " << x << " | " << #y << ": " << y << endl;
 #define trace3(x, y, z)          cerr << #x << ": " << x << " | " << #y << ": " << y << " | " << #z << ": " << z << endl;
 #define trace4(a, b, c, d)       cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << endl;
 #define trace5(a, b, c, d, e)    cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << endl;
 #define trace6(a, b, c, d, e, f) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << " | " << #f << ": " << f << endl;
 #define FOR(i,a,b) for(int i=a;i<b;i++)
 #define si(n) scanf("%d",&n)
 #define s2i(x,y) scanf("%d %d",&x,&y);
 #define s3i(x,y,z) scanf("%d %d %d",&x,&y,&z);
 #define s4i(x,y,z,w) scanf("%d %d %d %d",&x,&y,&z,&w);
 #define print(a,n) for(int i=0;i<n;i++) cout<<a[i]<<" "; cout<<endl;
 #define print2d(a,n,m) for(int i=0;i<n;i++) {for(int j=0;j<m;j++) cout<<a[i][j]<<" "; cout<<endl;}
 
 FILE *fin = freopen("A-small-attempt1.in","r",stdin);
 FILE *fout = freopen("out4","w",stdout);
 string x;
 void flip(int i,int j)
 {
 	for(int q=i;q<=j;q++)
 	{
 		if(x[q] == '+') x[q] = '-';
 		else x[q] = '+';
 	}
 }
 
 int main()
 {
 	int t,k;
 	cin >> t;
 	FOR(T,1,t+1)
 	{
 		cin >> x >> k;
 		int flag = 1;
 		int ans = 0, i = 0;
 		while( i < x.length())
 		{
 			if(x[i] == '+') i ++;
 			else
 			{
 				if(i + k - 1 >= x.length())
 				{
 					flag = -1;
 					break;
 				}
 				flip(i,i+k-1);
 				ans ++;	
 				i ++;
 			}
 
 		}
 		cout << "Case #" << T << ": ";
 		if(flag == -1)
 			cout << "IMPOSSIBLE" << endl;
 		else
 			cout << ans << endl;
 	}
 	return 0;
 }
