#include <stdio.h>
 
 int main()
 {
     int t, ti, i, level;
     long long int n, k;
     scanf( "%d", &t );
     for( ti = 0; ti < t; ti ++ )
     {
         scanf( "%lld%lld", &n, &k );
         //determine level of partition.
         for( level = sizeof( long long int ) * 8 - 1; level >= 0; level -- )
             if( ( ( ( long long int ) 1 ) << level ) & k )
                 break;
         //start from top of the tree and go in the node which will contain that k
         for( ; level > 0; level -- )
             if( ( ( ( long long int ) 1 ) << ( level - 1 ) ) & k )
                 n = ( n - 1 ) >> 1;
             else
                 n >>= 1;
         printf( "Case #%d: %lld %lld\n", ti + 1, n >> 1, n > 0 ? ( n - 1 ) >> 1 : 0 ); 
     }
     return 0;
 }

