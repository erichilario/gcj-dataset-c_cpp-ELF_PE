#include<stdio.h>
 #include<string.h>
 
 int main(void)
 {
     int t, k;
     char s[11];
     printf("");
     scanf(" %d", &t);
     for(int i = 1; i <= t; i++){
         int count = 0, f = 1;
         printf("");
         scanf("%s", s);
         printf("");
         scanf(" %d", &k);
         
         for(int j = 0, l = strlen(s); j < l; j++){
             if(s[j] == 45 && j <= l-k){
                 for(int p = 0; p < k; p++){
                     if(s[j+p] == 45) s[j+p] = 43;
                     else s[j+p] = 45;
                 }
                 count++;
             }
             else if(s[j] == 45)   f=0;
         }
         if(f) printf("Case #%d: %d\n", i, count);
         else printf("Case #%d: IMPOSSIBLE\n", i);
     }
 }
