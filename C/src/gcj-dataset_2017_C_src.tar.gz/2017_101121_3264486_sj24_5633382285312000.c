#include<stdio.h>
 #include<math.h>
 int main(){
   FILE *fi, *fo;
   fi = fopen("large.in", "r");
   fo = fopen("data.out", "w");
   int t, valid;
   long long n, lastT, testNum, t1, t2;
   fscanf(fi, "%d", &t);
   for(int i=1; i<=t; i++){
     fscanf(fi, "%lld", &n);
     while(n > 0){
       if(n >= 10000000){
         t1 = n;
         t2 = 0;
         while(t1 > 0){
           t2++;
           t1 /= 10;
         }
         n = n - (n % (long long)pow(10, t2-1));
       }
       testNum = n;
       valid=1;
       t2 = n % 10;
       while(testNum > 0 && valid){
         t1 = testNum % 10;
         testNum /= 10;
         if(!(t1 <= t2)){
           valid = 0;
           break;
         }
         t2 = t1;
       }
       if(valid){
         fprintf(fo, "Case #%d: %lld\n", i, n);
         break;
       }else{
         n--;
       }
     }
   }
   fclose(fi);
   fclose(fo);
   return 0;
 }

