#include <stdio.h>
 #include <string.h>
 
 int main()
 {
     int T, K;
     char S[1010];
     int i, j, len, count, kase;
 
     scanf("%d", &T);
     for(kase = 1; kase <= T; kase++) {
         scanf("%s %d", S, &K);
         count = 0;
         
         len = strlen(S);
         for(i = 0; i <= len - K; i++) {
             if(S[i] == '+') {
                 continue;
             }
             // do flip
             for(j = 0; j < K; j++) {
                 if(S[i+j] == '+') {
                     S[i+j] = '-';
                 } else {
                     S[i+j] = '+';
                 }
             }
             count += 1;
             // test print
             //printf("State: %s\n", S);
         }
         for (i = 0; i < len; i++) {
             if(S[i] == '-') {
                 count = -1;
                 break;
             }
         }
         if (count == -1) {
             printf("Case #%d: IMPOSSIBLE\n", kase);
         }
         else {
             printf("Case #%d: %d\n", kase, count);
         }
     }
 
     return 0;
 
 }
