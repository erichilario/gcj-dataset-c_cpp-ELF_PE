#include <stdio.h>
 
 int main(void){
     int cases, casos;
     int r, c, i, j, k, blancos, rep;
     char cake[26][26];
 
     scanf("%d\n",&cases);
     for(casos=1;casos<=cases;casos++){
         printf("Case #%d:\n",casos);
         scanf("%d %d\n",&r,&c);
         for(i=0;i<r;i++){
             for(j=0;j<c;j++){
                 cake[i][j] = getchar();
             }
             getchar();
         }
         //impresion de prueva
         /*for(i=0;i<r;i++){
             for(j=0;j<c;j++){
                 putchar(cake[i][j]);
             }
             putchar('\n');
         }
         putchar('\n');*/
         rep = 1;
         while(rep){
         for(i=0;i<r;i++){
             //vemos cuantos espacios hay
             blancos = 0;
             for(j=0;j<c;j++){
                 if(cake[i][j]=='?'){
                     blancos++;
                 }
             }
             if(blancos){
                 if(blancos<c){
                     for(j=0;j<c;j++){
                         if(cake[i][j]=='?'){
                             k=j+1;
                             while((cake[i][k]=='?')&&(k<c)){
                                 k++;
                             }
                             if(k == c)
                                 k--;
                             if(cake[i][k]!='?'){
                                 cake[i][j] = cake[i][k];
                             }else{
                                 cake[i][j] = cake[i][j-1];
                             }
                         }
                     }
                 }else if(i){
                     int arriva = 0;
                     for(j=0;j<c;j++){
                         if(cake[i-1][j] == '?')
                             arriva++;
                     }
                     if(arriva != c){
                         for(j=0;j<c;j++){
                             cake[i][j] = cake[i-1][j];
                         }
                     }else if(i != (r-1)){
                         for(j=0;j<c;j++){
                             cake[i][j] = cake[i+1][j];
                         }
                     }
                 }else{
                     int abajo = 0;
                     for(j=0;j<c;j++){
                         if(cake[i+1][j] == '?')
                             abajo++;
                     }
                     if(abajo != c){
                         for(j=0;j<c;j++){
                             cake[i][j] = cake[i+1][j];
                         }
                     }
                 }
             }
         }
         rep = 0;
         for(i=0;i<r;i++){
             for(j=0;j<c;j++){
                 if(cake[i][j]=='?'){
                     rep++;
                 }
             }
         }
         //impresion de prueva
         /*for(i=0;i<r;i++){
             for(j=0;j<c;j++){
                 putchar(cake[i][j]);
             }
             putchar('\n');
         }
         putchar('\n');*/
         }
 
         //impresion fnal
         for(i=0;i<r;i++){
             for(j=0;j<c;j++){
                 putchar(cake[i][j]);
             }
             putchar('\n');
         }
         //putchar('\n');
     }
 
     return(0);
 }

