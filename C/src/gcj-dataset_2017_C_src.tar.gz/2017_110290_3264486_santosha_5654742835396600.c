#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <inttypes.h>
 
 
 void
 do_bath (uint64_t num, uint64_t kk)
 {
 	uint64_t	t, h, l;
 	uint64_t  hh, hl, lh, ll;
 	uint64_t lx, hx, it = 1ul;
 
 	hx = 1ul;
 	t = 1ul;
 	lh = hh = num;
 	hx = 1, lx = 0;
 
 	while (t <= kk) {
 
 		hl = (hh-1ul)/2ul;
 		hh = hh/2ul;
 		ll = (lh-1ul)/2ul;
 		lh = (lh)/2ul;
 
 		it *= 2ul;
 		if (it > kk) {
 			if (t + hx > kk) {
 				h = hh;
 				l = hl;
 			} else {
 				l = ll;
 				h = hl;	
 			}
 		}
 		if (hh == hl) {
 			hx *= 2ul;
 		}
 		if (hh == lh) {
 			hx += lx;
 		}
 		lx = it - hx;
 		lh = ll;
 		t = it;
 	}
 	printf ("%lu %lu\n", h, l);
 	return;
 }
 
 int 
 main ()
 {
 	int	ix, ntests;
 	uint64_t	kk, num;
 
 	scanf ("%d", &ntests);
 
 	for (ix = 1; ix <= ntests; ++ix) {
 
 		scanf("%lu%lu", &num, &kk);
 
 		printf ("Case #%d: ", ix);
 		do_bath (num, kk);
 	}
 
 }

