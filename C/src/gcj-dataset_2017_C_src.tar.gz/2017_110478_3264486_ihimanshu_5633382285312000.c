#include<stdio.h>
 #include<stdlib.h>
 int check(int *a,int l)
 {
     int i=0;
     for(i=0;i<l-1;i++)
         if(a[i]>a[i+1])
         return 1;
     return 0;
 }
 int main()
 {
     int t,c=1;
     FILE *p=fopen("B-small-attempt3.in","r");
     FILE *o=fopen("most.ou","w");
     fscanf(p,"%d",&t);
     while(t--)
     {
         int a[20],l=0,i=0,x=0,pos;
         char str[20];
         fscanf(p,"%s",str);
         for(l=0;str[l]!='\0';l++)
             a[l]=str[l]-'0';
         if(l>1)
         {
             while(a[x]<=a[x+1]&&x<l-1) x++;
             if(x!=l-1)
             {
                 if(a[x]==1)
                 {
                     l--;
                     x=0;
                     while(x<l)
                     {
                         a[x++]=9;
                     }
                     fprintf(o,"Case #%d: ",c++);
                     for(i=0;i<l;i++)
                         fprintf(o,"%d",a[i]);
                     fprintf(o,"\n");
                 }
                 else
                 {
                     pos=x+1;
                     do{
                     a[x++]--;
                     while(x<l)
                         a[x++]=9;
                     x=pos--;
                     }while(check(a,l));
                     fprintf(o,"Case #%d: ",c++);
                     for(i=0;i<l;i++)
                         fprintf(o,"%d",a[i]);
                     fprintf(o,"\n");
                 }
             }
             else
             {
                 fprintf(o,"Case #%d: ",c++);
                 for(i=0;i<l;i++)
                     fprintf(o,"%d",a[i]);
                 fprintf(o,"\n");
             }
 
         }
         else
         {
             fprintf(o,"Case #%d: %d\n",c++,a[0]);
         }
     }
 }

