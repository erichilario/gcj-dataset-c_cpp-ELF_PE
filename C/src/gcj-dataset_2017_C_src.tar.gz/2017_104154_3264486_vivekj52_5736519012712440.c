#include<stdio.h>
 
 int main()
 {
 	int tc;
 	scanf("%d",&tc);
 	for(int i=1;i<=tc;i++)
 	{
 		char s[1005];
 		int k,x,count=0,z,j=0;
 		scanf("%s %d",s,&k);
 
 		for(x=0;s[x]!='\0';x++)
 		
 		for(j;j<=x-k+1;j++)
 			if(s[j]=='-')
 			{
 				s[j]='+';
 				for(int y=1;y<k;y++)
 				{
 					if(s[j+y]=='+')
 						s[j+y]='-';
 					else
 						s[j+y]='+';
 				}
 				count++;
 			}
 		
 		for(z=0;z<x;z++)
 		{
 			if(s[z]=='-')
 				break;
 		}
 		if(z==x)
 			printf("Case #%d: %d\n",i,count);
 		else
 			printf("Case #%d: IMPOSSIBLE\n",i);
 
 	}
 	return 0;
 }
