#include<stdio.h>
 int N,A[1002],LR[2][1001],min[1001],K,max[1001],maxo,maxo2,q,lst;
 void find(int i,int *L,int *R)
 {	int x=i-1,y=i+1;
 	*L=*R=0;
 	while(!A[x--])
 		*L=(*L)+1;
 	while(!A[y++])
 		*R=(*R)+1;
 	LR[0][i]=*L,LR[1][i]=*R;
 }
 void max1()
 {	int i;
 	maxo=-1;
 	for(i=1;i<=N;++i)
 	{	if(A[i])
 			continue;
 		if(min[i]>maxo)
 			maxo=min[i];
 	}
 }
 void max2()
 {
 	int i;
 	maxo2=-1;
 	for(i=1;i<=N;++i)
 	{	if(A[i])
 			continue;
 		if(min[i]!=maxo)
 			continue;
 		if(max[i]>maxo2)
 			maxo2=max[i];
 
 	}
 }
 void assign()
 {	int i;
 	for(i=1;i<=N;++i)
 	{
 		if(A[i])
 			continue;
 		if((min[i]==maxo)&&(max[i]==maxo2))
 		{	A[i]=1;
 			lst=i;
 			break;
 		}
 	}
 }
 int main()
 {
 	int i,s,L,R,ir,ri=0,sol[100][2];
 	scanf("%d",&ir);
 while(ir!=0)
 {
 	scanf("%d",&N);
 	for(i=0;i<=N+1;++i)
 		A[i]=0;
 	A[0]=1;
 	A[N+1]=1;
 	scanf("%d",&K);
 	for(s=0;s<K;++s)
 	{	
 		for(i=1;i<=N;++i)
 		{	if(A[i])
 				continue;
 			find(i,&L,&R);
 			if(LR[1][i]<LR[0][i])
 			{	min[i]=LR[1][i];
 				max[i]=LR[0][i];
 			}
 			else
 			{	min[i]=LR[0][i];
 				max[i]=LR[1][i];
 			}
 		}
 		max1();
 		max2();
 		assign();
 	}
 	find(lst,&L,&R);
 	sol[ri][0]=L>R?L:R,sol[ri][1]=L>R?R:L;
 	ri++;
 	ir--;
 }
 for(ir=0;ir<ri;++ir)
 	printf("\nCase #%d: %d %d",ir+1,sol[ir][0],sol[ir][1]);
 	return 0;
 }

