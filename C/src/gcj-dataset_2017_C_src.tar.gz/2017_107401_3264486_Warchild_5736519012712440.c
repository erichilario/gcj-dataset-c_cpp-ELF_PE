#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int check(char*);
 void main()
 {
 	FILE *fp, *ft;
 	fp = fopen("A-small-attempt2.in","r");
 	ft = fopen("output1","w");
 	char S[100];
 	int i,j,k,no_of_inputs,length,K;
 	
 	fscanf(fp,"%d", &no_of_inputs);
 	
 	//loop for input lines
 	for(i=0;i<no_of_inputs;i++)
 	{
 		int no_of_flips = 0;
 		char output[11];	
 		//take the string first
 		fscanf(fp,"%s", S);
 		fscanf(fp,"%d", &K);
 		length = strlen(S);
 		
 		//loop for each charecter in a string
 		for(j=0;j<strlen(S);j++)
 		{
 			if(S[j] == '+')continue;
 			else{
 				//check for boundary
 				if(K <= strlen(S)-j)
 				{	
 					//loop for flipping
 					for(k=0;k<K;k++)
 					{	
 						if(S[j+k] == '-')
 						S[j+k] = '+';
 						else S[j+k] = '-';
 						
 					}
 					no_of_flips++;
 				}
 			}	
 		}
 		
 		if(check(S))
 		{
 			fprintf(ft,"Case #%d: %d\n",i+1,no_of_flips);
 		}
 		else{
 			fprintf(ft,"Case #%d: IMPOSSIBLE\n",i+1);
 		}
 		
 	}
 }
 
 int check(char* S)
 {
 	int i,flag = 1;
 	for(i=0;i<strlen(S);i++)
 	{
 		if(S[i] == '-')
 			flag = 0;
 	}
 	return flag;
 }

