#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 int main(void)
 {
 	int t;
 	scanf("%d\n",&t);
 	int i;
 	int l;
 	int *A;
 	int j;
 	int y=1;
 	long long N;
 	long long n;
 	while(y<=t)
 	{
 		scanf("%lld",&n);
 		l=floor(log10(n))+1;
 		A=(int *)malloc(l*sizeof(int));
 		A[l-1]=n%10;
 		n/=10;
 		for(i=1;i<l;i++)
 		{
 			A[l-i-1]=n%10;
 			if(A[l-i-1]>A[l-i])
 			{
 				A[l-i-1]-=1;
 				for(j=l-i;j<l;j++)
 				{
 					A[j]=9;
 				}
 			}
 			n/=10;
 		}
 		N=A[0];
 		for(i=1;i<l;i++)
 		{
 			N=(10*N)+A[i];
 		}
 		printf("Case #%d: %lld\n",y,N);
 		y++;
 	}
 	return 0;
 }

