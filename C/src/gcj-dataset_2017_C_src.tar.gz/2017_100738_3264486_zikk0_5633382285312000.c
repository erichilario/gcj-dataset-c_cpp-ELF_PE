#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main() {
     int T;
 
     scanf("%d", &T);
 
     unsigned long int K;
     int array[19];
     for (int tdx = 0; tdx < T; tdx++) {
         scanf("%lu", &K);
 
         int idx = 18;
         unsigned long int div, mod;
 
         mod = K % 10;
         div = K / 10;
 
         array[idx] = mod;
         idx--;
         while (div != 0) {
             mod = div % 10;
             div = div / 10;
             array[idx] = mod;
             idx--;
         }
 
         for (int jdx = 18; jdx > idx + 1; jdx--) {
             if (array[jdx - 1] > array[jdx]) {
                 for (int kdx = jdx; kdx < 19; kdx++)
                     array[kdx] = 9;
                 array[jdx - 1]--;
             }
         }
         
         unsigned long int number = 0, prod = 1;
 
         for (int jdx = 18; jdx > idx; jdx--) {
             number += array[jdx] * prod;
             prod *= 10;
         }
         printf("Case #%d: %lu\n", tdx + 1, number);
     }
     return 0;
 }
 

