#include <stdio.h>
 #include <string.h>
 
 int main(int argc,char *argv[])
 	{
 	unsigned int num_tests;
 	unsigned int t;
 	size_t len;
 	char number[25],*pos;
 	
 	scanf("%d\n",&num_tests);
 	for(t=0;t<num_tests;t++)
 		{
 		fgets(number,25,stdin);
 		len=strspn(number,"0123456789");
 		if(len)
 			{
 			pos=number+len;
 			*pos='\0';
 			pos--;
 			while(pos>number)
 				{
 				while((pos>number)&&(*pos>=*(pos-1)))
 					{
 					pos--;
 					}
 				if((pos>number)&&(*pos<*(pos-1)))
 					{
 					(*(pos-1))--;
 					while(*pos)
 						{
 						*pos='9';
 						pos++;
 						}
 					pos--;
 					}
 				}
 			while(*pos=='0')
 				{
 				pos++;
 				}
 			if(pos>number)
 				{
 				memmove(number,pos,strlen(pos)+1);
 				}
 			printf("Case #%d: %s\n",t+1,number);
 			}
 		else
 			{
 			fprintf(stderr,"%d %s??\n",t,number);
 			}
 		}
 	}

