#include<stdio.h>
 #include<string.h>
 #include <stdlib.h>
 
  int main()
  {
      int k,i,j,test,temp,flag,count;
      int p;
      char *c=(char *)malloc(125600*sizeof(char));
      scanf("%d",&test);
      for(temp=0;temp<test;temp++)
      {
         flag=0;
         count=0;
         scanf("%s",c);
         for(p=0;c[p]!='\0';p++);
         scanf("%d",&k);
 
         for(i=0;i<p-k+1; i++)
         {
             if(c[i]=='-')
             {
                 for(j=i;j<i+k; j++)
                 {
                     if(c[j]=='-')
                         c[j]='+';
                     else
                     c[j]='-';
                 }
                 count++;
             }
         }
         for(;i<p;i++)
         {
             if(c[i]=='-')
             {
                 printf("Case #%d: IMPOSSIBLE\n",temp+1);
                 flag=1;
                 break;
             }
         }
          if(flag==0)
             printf("Case #%d: %d\n",temp+1,count);
     }
     free(c);
     return 0;
  }

