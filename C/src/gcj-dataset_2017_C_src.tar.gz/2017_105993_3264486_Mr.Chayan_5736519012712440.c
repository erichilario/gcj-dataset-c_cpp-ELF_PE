#include<stdio.h>
 #include<string.h>
 
 int main(){
     int n,t,k,i,j,l,count;
     char s[1002];
     scanf("%d",&t);
     for(l=1;l<=t;l++){
         scanf("%s",&s);
         n=strlen(s);
         scanf("%d",&k);
         count=0;
         for(i=0;i<n-k+1;i++){
             if(s[i]=='-'){
                 for(j=i;j<i+k;j++){
                     if(s[j]=='-')
                         s[j]='+';
                     else
                         s[j]='-';
                 }
                 count++;
             }
         }
         //printf("%s\n",s);
         for(i=n-k+1;i<n;i++){
             if(s[i]=='-'){
                 printf("Case #%d: IMPOSSIBLE\n",l);
                 break;
             }
         }
         if(i==n){
             printf("Case #%d: %d\n",l,count);
         }
     }
 }

