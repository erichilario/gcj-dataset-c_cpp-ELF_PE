#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 #include<string.h>
 
 
 char * change(char *a)
 {
     int length,i,j;
     length=strlen(a);
     if(length==1)
         return a;
 
     for(i=length-1;i>0;i--)
     {
         if(a[i]<a[i-1])
         {
             a[i]='k';
             a[i-1]-=1;
         }
     }
 
 	for(i=0;i<length;i++)
     {
         if(a[i]=='k')
         {
             for(j=i;j<length;j++)
                 a[j]='9';
             break;
         }
     }
 
     if(a[0]=='0')
         a=a+1;
     return a;
 }
 
 int main()
 {
     int test,i,j,length;
     scanf("%d",&test);
     char **a=(char **)malloc(sizeof(char *)*test);
     for(i=0;i<test;i++)
     {
         a[i]=(char *)malloc(sizeof(char)*19);
         scanf("%s",a[i]);
     }
     for(i=0;i<test;i++)
 	{
 		printf("Case #%d: %s\n",i+1,change(a[i]));
 	}
 	return 0;
 }

