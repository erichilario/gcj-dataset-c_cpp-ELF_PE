#include <stdio.h>
 char arr[26][26];
 void doit(int cas)
 {
 	int i, j, r, c;
 	scanf("%d %d", &r, &c);
 	for(i=0; i<r; i++)
 			scanf("%s", &arr[i]);
 	for(i=0; i<r; i++)
 		for(j=0; j<c; j++)
 		{
 			if(arr[i][j] != '?')
 			{
 				if(arr[i-1][j] == '?')
 				{
 					arr[i-1][j] = arr[i][j];
 					i=i-1;
 					j=j-1;
 					continue;
 				}
 				if(arr[i+1][j] == '?')
 				{
 					arr[i+1][j] = arr[i][j];
 				}
 			}
 		}
 	for(i=0; i<r; i++)
 		for(j=0; j<c; j++)
 		{
 			if(arr[i][j] != '?')
 			{
 				if(arr[i][j-1] == '?')
 				{
 					arr[i][j-1] = arr[i][j];
 					j=j-2;
 					continue;
 				}
 				if(arr[i][j+1] == '?')
 				{
 					arr[i][j+1] = arr[i][j];
 				}
 			}
 		}
 		printf("Case #%d:\n", cas);
 		for(i=0; i<r; i++)
 		{
 			printf("%s\n", arr[i]);
 		}
 }
 void main()
 {
 	int t, i;
 	scanf("%d", &t);
 	for(i=1; i<=t; i++)
 		doit(i);
 }
