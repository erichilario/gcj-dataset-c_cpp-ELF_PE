#include<stdio.h>
 #include<string.h>
 int main()
 {
     int t,len,i,j,f[1001],ans,k,r1;
     char s[1001];
     scanf("%d",&t);
     for(i=0;i<t;i++)
     {
         scanf("%s",s);
         scanf("%d",&k);
         len=strlen(s);
         for(j=0;j<len;j++)
         {
             if(s[j]=='+')
                 f[j]=1;
             else
                 f[j]=0;
         }
         ans=0;
         for(j=len-1;j>=k-1;j--)
         {
             if(f[j]==0)
             {
                 ans++;
                 for(r1=j;r1>(j-k);r1--)
                 {
                     f[r1]=(f[r1]+1)%2;
                 }
             }
         }
         r1=0;
         for(j=0;j<len;j++)
         {
             if(f[j]==0)
             {
                 r1=1;
                 break;
             }
         }
         if(r1==1)
             printf("Case #%d: IMPOSSIBLE\n",i+1);
         else
             printf("Case #%d: %d\n",i+1,ans);
     }
     return 0;
 }

