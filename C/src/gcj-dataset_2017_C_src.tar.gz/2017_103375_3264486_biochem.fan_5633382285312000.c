#include <stdio.h>
 #include <string.h>
 
 int check(int n) {
 	char buf[20];
 	sprintf(buf, "%d", n);
 	int len = strlen(buf);
 
 	for (int i = 1; i < len; i++) {
 		if (buf[i - 1] > buf[i]) return -1;
 	}
 	return 0;
 }
 
 int main() {
 	int T = 0;
 	char str[20];
 	scanf("%d", &T);
 
 	for (int t = 1; t <= T; t++) {
 		int x;
 		scanf("%d", &x);
 		while (check(x) < 0) x--;
 		printf("Case #%d: %d\n", t, x);
 /*		scanf("%s", str);
 		int len = strlen(str);
 
 		int flag = 0;
 		for (int i = len - 1; i >= 0; i--) {
 			
 		}
 */
 	}
 
 	return 0;
 }

