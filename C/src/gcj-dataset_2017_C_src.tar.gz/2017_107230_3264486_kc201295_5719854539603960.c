#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>	
 
 int up[2][10000]={0}, k=0;
 
 int check(char **matrix, int n, int i, int j, char ch)
 {
 	int flag=1, x, y;
 	switch(ch)
 	{
 		case 'o':
 		{
 			for(x=i-1;x>=0;x--)
 				if((matrix[x][j]=='o'||matrix[x][j]=='x'))
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=i+1;x<n;x++)
 				if((matrix[x][j]=='o'||matrix[x][j]=='x'))
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=j-1;x>=0;x--)
 				if((matrix[i][x]=='o'||matrix[i][x]=='x'))
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=j+1;x<n;x++)
 				if((matrix[i][x]=='o'||matrix[i][x]=='x'))
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=i-1,y=j-1;(x>=0&&y>=0);x--,y--)
 				if(matrix[x][y]=='o'||matrix[x][y]=='+')
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=i+1,y=j+1;(x<n&&y<n);x++,y++)
 				if(matrix[x][y]=='o'||matrix[x][y]=='+')
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=i+1,y=j-1;(x<n&&y>=0);x++,y--)
 				if(matrix[x][y]=='o'||matrix[x][y]=='+')
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=i-1,y=j+1;(x>=0&&y<n);x--,y++)
 				if(matrix[x][y]=='o'||matrix[x][y]=='+')
 				{
 					flag=0;
 					return 0;
 				}
 			break;
 		}
 		case 'x':
 		{
 			for(x=0;x<n;x++)
 				if((matrix[x][j]=='o'||matrix[x][j]=='x')&&(x!=i))
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=0;x<n;x++)
 				if((matrix[i][x]=='o'||matrix[i][x]=='x')&&(x!=j))
 				{
 					flag=0;
 					return 0;
 				}
 			break;
 		}
 		case '+':
 		{
 			for(x=i-1,y=j-1;(x>=0&&y>=0);x--,y--)
 				if(matrix[x][y]=='o'||matrix[x][y]=='+')
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=i+1,y=j+1;(x<n&&y<n);x++,y++)
 				if(matrix[x][y]=='o'||matrix[x][y]=='+')
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=i+1,y=j-1;(x<n&&y>=0);x++,y--)
 				if(matrix[x][y]=='o'||matrix[x][y]=='+')
 				{
 					flag=0;
 					return 0;
 				}
 			for(x=i-1,y=j+1;(x>=0&&y<n);x--,y++)
 				if(matrix[x][y]=='o'||matrix[x][y]=='+')
 				{
 					flag=0;
 					return 0;
 				}
 			break;
 		}
 	}
 	return flag;			
 }
 
 void update(char **matrix, int n, int i, int j)
 {
 	char ch=matrix[i][j];
 	switch(ch)
 	{
 		case '.':
 		{
 			if(check(matrix, n, i, j, 'o'))
 			{
 				matrix[i][j]='o';
 				up[0][k]=i;
 				up[1][k]=j;
 				k++;
 			}
 			else if(check(matrix, n, i, j, '+'))
 			{
 				matrix[i][j]='+';
 				up[0][k]=i;
 				up[1][k]=j;
 				k++;
 			}
 			else if(check(matrix, n, i, j, 'x'))
 			{
 				matrix[i][j]='x';
 				up[0][k]=i;
 				up[1][k]=j;
 				k++;
 			}
 			break;
 		}
 		case '+':
 		case 'x':
 		{
 			if(check(matrix, n, i, j, 'o'))
 			{
 				matrix[i][j]='o';
 				up[0][k]=i;
 				up[1][k]=j;
 				k++;
 			}
 			break;
 		}
 	}
 			
 }
 
 int main()
 {
 	int t, i, j, len, x, y, p, q, sum=0;
 	scanf("%d",&t);
 	char ch;
 	int n, m;
 	for(i=0;i<t;i++)
 	{
 		scanf("%d",&n);
 		char **matrix=(char**)malloc(sizeof(char*)*n);
 		for(j=0;j<n;j++)
 			matrix[j]=(char*)malloc(sizeof(char)*n);
 		
 		scanf("%d",&m);
 		for(x=0;x<n;x++)
 				for(y=0;y<n;y++)
 					matrix[x][y]='.';
 		if(m>0)
 		{
 			for(x=0;x<m;x++)
 			{
 				fflush(stdin);
 				scanf("%c",&ch);
 				scanf("%d",&p);
 				scanf("%d",&q);
 				matrix[p-1][q-1]=ch;
 			}
 		}
 		k=0;
 		for(x=0;x<n;x++)
 		{
 			for(y=0;y<n;y++)
 			{
 				update(matrix,n,x,y);
 			}
 		}
 		//SUM
 		sum=0;
 		for(x=n-1;x>=0;x--)
 		{
 			for(y=n-1;y>=0;y--)
 			{
 				if(matrix[x][y]=='o')
 					sum+=2;
 				else if(matrix[x][y]=='+'||matrix[x][y]=='x')
 					sum+=1;
 			}
 		}
 		printf("Case #%d: %d %d\n",i+1,sum,k);
 		//INDEX PRINT
 //		printf("*****\n");
 //		for(x=0;x<n;x++)
 //		{
 //			for(y=0;y<n;y++)
 //			{
 //				printf("%c  ",matrix[x][y]);
 //			}
 //			printf("\n");
 //		}
 //		printf("*****\n");
 		for(x=0;x<k;x++)
 		{
 			printf("%c %d %d\n",matrix[(up[0][x])][(up[1][x])],up[0][x]+1,up[1][x]+1);
 		}
 		
 	}
 	return 0;
 }

