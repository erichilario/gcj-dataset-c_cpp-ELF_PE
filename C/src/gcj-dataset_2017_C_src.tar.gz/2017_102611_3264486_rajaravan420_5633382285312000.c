
 #include <stdio.h>
 void sett(char *S,int i,int p)
 {
     if(i < 0)
     i = 0;
     while(i<p-1)
     {
         if(S[i] <= S[i+1]) i++;
         else
         {
                 S[i]--;
                 int j = i+1;
                 while(j<p)
                 S[j++] = '9';
                 i--;
                 sett(S,i,p);
         }
     }
 }
 int check(char *S,int p)
 {
     int i=0;
     while(i<p-1)
     {
         if(S[i] > S[i+1]) return 0;
         i++;
     }
     return 1;
 }
 int main() {
     int T;
     scanf("%d",&T);
     int z = T;
     while(z--)
     {
         char S[20];
         scanf("%s",S);
         int p = strlen(S);
         if(check(S,p)==1)
         {
             printf("Case #%d: %s\n",T-z,S);
         }
         else {
                 sett(S,0,p);
 
         int i;
         for(i=0;i<p;++i)
         if(S[i]!='0') break;
         printf("Case #%d: ",T-z);
         for(;i<p;++i)
         printf("%c",S[i]);
         printf("\n");
         }
     }
 	return 0;
 }

