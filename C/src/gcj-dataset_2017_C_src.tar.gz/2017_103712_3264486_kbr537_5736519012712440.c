#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <assert.h>
 
 void
 print_val(char *row, int K)
 {
 	int len = 0;
 	len = strlen(row);
 	int seq = 0;
 	int cnt  = 0;
 	int itr = 0, itr1 = 0, itr2 = 0;
 
 	for (itr = 0; itr < len;)
 	{
 		if (row[itr] == '-') {
 			seq++;
 			if (seq == K) {
 				cnt++;
 				for (itr2 = 0; itr2 < seq ; itr2++)
 				{
 					row[itr-itr2] = '+';
 				} 
 				seq = 0;
 			} else if (itr == len-1) {
 				printf("IMPOSSIBLE\n");
 				return;
 			}
 			itr++;
 		} else if (row[itr] == '+') {
 			if (seq == 0) {
 				itr++;
 				continue;
 			}
 			else {
 				int t_itr = itr;
 				for (itr1 = 0; itr1 < K ; itr1++)
 				{
 					if (t_itr >= len)
 					{
 						printf("IMPOSSIBLE\n");
 						return;
 					}
 					if (row[t_itr] == '-')
 						row[t_itr] = '+';
 					else if (row[t_itr]  == '+')
 						row[t_itr] = '-';
 					t_itr++;
 				}
 				itr = itr - seq;
 				cnt++;
 				seq = 0;
 			}
 		}
 	}
 	printf("%d\n", cnt);
 }
 
 int
 main()
 {
 	FILE* fp;
 	char buffer[255] = {'\0',};
 	int len = 0;
 	int T = 0, itr = 0;
 	int temp_itr = 0;
 
 	fp = fopen("A-small-attempt2.in", "r");
 	
 	fgets(buffer, 255, (FILE*) fp);
 
 	len = strlen(buffer);
 	buffer[len-1] = '\0';
 
 	T = atoi(buffer);
 
 	for (itr = 0; itr < T; itr++)
 	{
 		int K = 0;
 		char row[255] = {'\0',};
 		char *token = NULL;
 
 		fgets(buffer, 255, (FILE*) fp);
 
 		len = strlen(buffer);
 		buffer[len-1] = '\0';
 
 		token = strtok(buffer, " ");
 		strcpy(row, token);
 
 		token = strtok(NULL, " ");
 		K = atoi(token);
 
 		printf("Case #%d: ", (itr+1));
 		print_val(row, K);
 	}
 
 	fclose(fp);
 }

