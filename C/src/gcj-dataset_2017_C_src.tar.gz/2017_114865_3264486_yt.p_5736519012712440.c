#include<stdio.h>
 #include<string.h>
 void change(char a[],int i,int k)
 {
 	int j;
 	for(j=i;j<i+k;j++)
 	{
 			
 		if(a[j]=='-')
 		{
 			a[j]='+';
 			
 		}
 		else
 		{
 			a[j]='-';
 			
 		}
 	}
 }
 int valid(char a[]){
 	int i;
 	for(i=0;a[i]!='\0';i++)
 	{
 		if(a[i]=='-')
 		{
 			return 0;
 		}
 	}
 	return 1;
 }
 int main()
 {
 	FILE *fp=fopen("out.txt","w");
 	char a[1000];
 	int temp,t,k,count=0,len,i;
 
 	scanf("%d",&t);
 	temp=t;
 	while(t--)
 	{
 		count=0;
 		scanf("%s",a);
 		len=strlen(a);
 		scanf("%d",&k);
 		for(i=0;a[i]!='\0';i++)
 		{
 			if(a[i]=='-')
 			{
 				if(i+k>len)
 				{
 					break;
 				}
 					
 					change(a,i,k);
 					count++;
 					
 			}
 		}
 		if(valid(a))
 		{
 			fprintf(fp,"Case #%d: %d\n",temp-t,count);
 		}
 		else
 		{
 			fprintf(fp,"Case #%d: IMPOSSIBLE\n",temp-t);
 		}
 	}
 	return 0;
 }

