#include<stdio.h>
 #include<string.h>
 #include <stdlib.h>
 #include <fcntl.h>
 
 int main()
 {
     int numOfInputData;
     freopen("B-large.in","r",stdin);
     freopen("B.out","w",stdout);
     scanf("%d",&numOfInputData);
     int i ;
     for(i = 0 ; i<numOfInputData; i++)
     {
         //fwrite(str , 1 , sizeof(str) , fp );
         printf("Case #%d: ",i+1);
 
         //count
         char inputData[50];
         scanf("%s",inputData);
         int strLength = strlen(inputData);
         int j ;
         for(j = strLength; j>1; j-- )
         {
             if(inputData[j-1] >= inputData[j-2])
                 continue;
             else
             {
                 inputData[j-1] = '9';
                 if(inputData[j-2] != 0)
                     inputData[j-2] = inputData[j-2] -1;
                 else
                 {
                     inputData[j-2] = '9';
                 }
                 int f ;
                 for( f = j-1 ; f < strLength ; f ++)
                     inputData[f] = '9';
             }
         }
 
         if(inputData[0] == '0')
         {
             int l;
             for(l = 0; l<strLength; l++ )
             {
                 inputData[l-1]=inputData[l];
             }
             inputData[l-1]='\0';
             strLength = strlen(inputData);
         }
         printf("%s\n",inputData );
     }
     return 0;
 }
 

