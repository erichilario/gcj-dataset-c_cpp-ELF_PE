#include <stdio.h>
 #include <string.h>
 
 int notOver(char str[], int len, int flip);
 int iscontinues(char str[], int len, int flip);
 int canRever(char str[], int len, int flip);
 int canCover(char str[], int len, int flip);
 
 int main(void){
     FILE *fPtrQ = fopen("/Users/Clown0/Desktop/Hello World/Que.txt", "r");
     FILE *fPtrA = fopen("/Users/Clown0/Desktop/Hello World/Ans.txt", "w");
     
     int t,i,k,total,total2,flip,flag,flag2,tt=1,c;
     char str[11],str2[11];
     
     fscanf(fPtrQ, "%d",&t);
     
     while (t--) {
         fscanf(fPtrQ, "%s%d",str,&flip);
         int len = (int)strlen(str);
         strcpy(str2, str);
         
         total = flag = 0;
         flag2 = -1;
         
         while (notOver(str, len, flip)) {
             k = iscontinues(str, len, flip);
             if (k != -1 && k != flag2) {
                 for (i=0; i < flip; ++i) {
                     str[k-i] = '+';
                 }
                 ++total;
                 flag2 = -1;
             }
             else if(canRever(str, len, flip) != -1){
                 for (i=0,c=canRever(str, len, flip); i<flip; ++i) {
                     if(str[c+i] == '+')
                         str[c+i] = '-';
                     else
                         str[c+i] = '+';
                 }
                 total++;
                 flag2 = 0;
             }
             else if(canCover(str, len, flip) != -1){
                 for (i=0,c=canCover(str, len, flip); i<flip; ++i) {
                     str[c+i] = '-';
                 }
                 total++;
                 flag2 = c+flip-1;
             }
             else{
                 flag = 1;
                 break;
             }
         }
         
         if (flag == 0){
             total2 = 0;
             flag2 = -1;
             if(canCover(str2, len, flip) != -1){
                 for (i=0,c=canCover(str2, len, flip); i<flip; ++i) {
                     str2[c+i] = '-';
                 }
                 total2++;
                 flag2 = c+flip-1;
             }
             while (notOver(str2, len, flip)) {
                 k = iscontinues(str2, len, flip);
                 if(k != -1 && k != flag2) {
                     for (i=0; i < flip; ++i) {
                         str2[k-i] = '+';
                     }
                     ++total2;
                     flag2 = -1;
                 }
                 else if(canRever(str2, len, flip) != -1){
                     for (i=0,c=canRever(str2, len, flip); i<flip; ++i) {
                         if(str2[c+i] == '+')
                             str2[c+i] = '-';
                         else
                             str2[c+i] = '+';
                     }
                     total2++;
                     flag2 = 0;
                 }
                 else if(canCover(str2, len, flip) != -1){
                     for (i=0,c=canCover(str2, len, flip); i<flip; ++i) {
                         str2[c+i] = '-';
                     }
                     total2++;
                     flag2 = c+flip-1;
                 }
                 else{
                     flag = 1;
                     break;
                 }
             }
             if (total <= total2){
                 fprintf(fPtrA, "Case #%d: %d\n",tt++,total);
                 printf("Case #%d: %d\n%s\n",tt,total,str);
             }
             else{
                 fprintf(fPtrA, "Case #%d: %d\n",tt++,total2);
                 printf("Case #%d: %d\n%s\n",tt,total2,str);
             }
         }
         else
             fprintf(fPtrA, "Case #%d: IMPOSSIBLE\n",tt++);
         
     }
     
     fclose(fPtrQ);
     fclose(fPtrA);
     return 0;
 }
 
 int notOver(char str[], int len, int flip){
     int i;
     for (i=0; i < len; ++i) {
         if(str[i] != '+')
             return 1;
     }
     
     return 0;
 }
 
 int iscontinues(char str[], int len, int flip){
     int i,num;
     for (i=0,num=0; i <= len; ++i) {
         if (num == flip)
             return i-1;
         else if(str[i] == '-')
             ++num;
         else
             num=0;
     }
     return -1;
 }
 
 int canRever(char str[], int len, int flip){
     int i,j,num,flag;
     for (i=0; i+flip<len; ++i) {
         for(j=i,num=0,flag=0; j<flip+i; ++j){
             if (str[j] == str[j+1])
                 ++num;
             else if(flag == 0){
                 flag=1;
                 ++num;
             }
             else
                 break;
         }
         if (num == flip-1 && str[j] != str[j+1] && str[j+1] == '-')
             return i;
     }
     return -1;
 }
 
 int canCover(char str[], int len, int flip){
     int i,j,num;
     for (i=0; i+flip<len; ++i) {
         for(j=i,num=0; j<flip+i; ++j){
             if (str[j] == str[j+1])
                 ++num;
             else
                 break;
         }
         if (num == flip-1 && str[j] != str[j+1] && str[j+1] == '-')
             return i;
     }
     return -1;
 }
