#include<stdio.h>
 #include "queue.h"
 
 
 
 
 
 void add_digits(int d,queue *q)
 {
   add(q,d);
 }
 
 
 
 void check_tidy(long n,queue *q,queue *tidy)
 {
   int num=n;
 
   while(n!=0)
   {
    add_digits(n%10,q);
    n=n/10;
   }
   
  if(sorted(q->top))
   add(tidy,num);
  
 }
 
 
 main()
 {
 queue q,tidy;
 FILE *fp;
 
 long j,i,t,n;
 
 
  fp=fopen("B-small-attempt1.in","r");
  fscanf(fp,"%ld",&t);
  tidy.top=NULL;
  q.top=NULL;
 
  for(i=1;i<=t;i++)
 {
  fscanf(fp,"%ld",&n);
 
  printf("Case #%d: ",i);
  for(j=1;j<=n;j++)
  {
   check_tidy(j,&q,&tidy);
   free(q.top);
   q.top=NULL;
  }
  printf("%ld\n",tidy.top->data);
 }
 
 return 0;
 }

