//
 // qual_c.c
 //
 
 #include <stdio.h>
 
 
 int main()
 {
 	int t;
 	long long n, k;
 	int i;
 	struct {
 		long long large_large;
 		long long large_small;
 		long long small_large;
 		long long small_small;
 	} empty;
 	long long large_large_number;
 	long long j;
 	long long diff;
 	long long min, max;
 
 	fscanf(stdin,"%d\n",&t);
 	for(i = 0; i < t; i++) {
 		// input data
 		fscanf(stdin,"%lld %lld\n",&n,&k);
 //		fprintf(stderr,"%lld,%lld\n",n,k);
 		// init
 		large_large_number = n;
 		empty.large_large = 1;
 		empty.large_small = 0;
 		empty.small_large = 0;
 		empty.small_small = 0;
 		// calc
 		j = 0;
 		while(1) {
 			if(empty.large_large) {
 				// odd
 				diff = empty.large_large;
 				empty.large_large = 0;
 				if(large_large_number & 1) {
 					// odd
 					max = min = large_large_number / 2;
 					empty.small_large += (diff * 2);
 				} else {
 					// even
 					max = large_large_number / 2;
 					min = max - 1;
 					empty.small_large += diff;
 					empty.small_small += diff;
 				}
 				if(j + diff >= k) {
 					break;
 				}
 				j += diff;
 			} else if(empty.large_small) {
 				// even
 				diff = empty.large_small;
 				empty.large_small = 0;
 				if(large_large_number & 1) {
 					// odd (large_small is even)
 					max = large_large_number / 2;
 					min = max - 1;
 					empty.small_large += diff;
 					empty.small_small += diff;
 				} else {
 					// even (large_small is odd)
 					max = min = large_large_number / 2;
 					empty.small_small += (diff * 2);
 				}
 				if(j + diff >= k) {
 					break;
 				}
 				j += diff;
 			} else {
 				empty.large_large = empty.small_large;
 				empty.large_small = empty.small_small;
 				empty.small_large = 0;
 				empty.small_small = 0;
 				large_large_number /= 2;
 			}
 //			fprintf(
 //				stderr,
 //				"%lld(%lld,%lld,%lld,%lld)\n",
 //				large_large_number,
 //				empty.large_large,empty.large_small,empty.small_large,empty.small_small
 //			);
 		}
 		// output result
 		printf("Case #%d: ",i+1);
 		printf("%lld %lld",max,min);
 		printf("\n");
 	}
 
 	return 0;
 }
 
 // End of qual_c.c

