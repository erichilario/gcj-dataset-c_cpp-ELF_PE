#include<stdio.h>
 #include<string.h>
 
 int T,t,n,i,f,k,j,x,s,q;
 int a[1000005];
 
 void prep()
 {
 a[0]=1;
 for(i=1;i<n+1;++i)a[i]=0;
 a[i]=1;
 //init over
 while(x--)
 {
 j=k=s=0;
 for(i=0;i<=n+1;++i)
 	if(a[i]==0)j++;
 	else 
 	{
 		if(j>k)
 		{
 			k=j;
 			s=i-j-1;
 		}
 		j=0;
 	}
 	
 a[s+(k-k/2)]=1;
 //for(i=0;i<=n+1;++i)printf("%d\t",a[i]);printf("\n");
 }
 
 return ;
 }
 
 
 int main()
 {
 scanf("%d",&t);
 
 for(T=0;T<t;++T)
 {
 scanf("%d%d",&n,&x);x--;
 prep();
 j=k=f=q=0;s=n+3;
 for(i=0;i<=n+1;++i)
 	if(a[i]==0)j++;
 	else 
 	{
 		if(j>k)
 		{
 			k=j;
 			//f=i-j;
 		}
 		j=0;
 		
 	}
 if(k>=1)
 k--;
 
 printf("Case #%d: %d %d\n",T+1,k-k/2,k/2);
 }
 
 
 return 0;
 }
 

