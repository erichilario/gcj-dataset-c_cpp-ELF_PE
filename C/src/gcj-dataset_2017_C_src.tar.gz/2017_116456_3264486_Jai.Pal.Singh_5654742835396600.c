#include<stdio.h>
 #include<stdlib.h>
 
 int main(void){
 	int t,i,n,k,*a,j;
 	scanf("%d",&t);
 	//printf("t=%d\n",t);
 	for(i=1;i<=t;i++){
 		scanf("%d %d",&n, &k);
 		a = (int *)malloc((2*n + 1)*sizeof(int));
 		a[0] = n;
 		if(n==k){
 			printf("Case #%d: %d %d\n",i,0,0);
 			continue;
 			}
 		for(j=0; j<=k; j++){
 			a[2*j +1] = a[j]/2;
 			a[2*j +2] = a[j] - a[j]/2 -1;
 			//printf("a[%d]= %d,a[%d] = %d\n",2*j+1,a[2*j+1],2*j+2,a[2*j+2]);
 			}
 		if(k==1)
 			k=0;
 		printf("Case #%d: %d %d\n",i,a[2*k+1],a[2*k+2]);
 		free(a);
 		}
 	return 0;
 	}

