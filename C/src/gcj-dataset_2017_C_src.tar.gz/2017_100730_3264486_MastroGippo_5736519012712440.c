#include <stdio.h>
 #include <stdlib.h>
 
 char * outp;
 int main(void)
 {
     FILE * fp;
     FILE * fo;
     int cc = 1;
 //    char * line = NULL;
     size_t len = 0;
     ssize_t read;
 
     fp = fopen("c:\\py\\in.txt", "r");
     fo = fopen("c:\\py\\out.txt", "w");
     if (fp == NULL)
     {
         printf("ERR");
         exit(EXIT_FAILURE);
     }
    if (fo == NULL)
     {
         printf("ERR");
         exit(EXIT_FAILURE);
     }
 
     char line[256];
     int pk = 0;
     fgets(line, sizeof(line), fp);
 
     while (fgets(line, sizeof(line), fp)) {
        printf("Retrieved line: ", read);
         printf("%s", line);
         int ind = 0;
         while(line[ind] != ' ')
             ind++;
         line[ind] = 0;
         pk = atoi(line+ind+1);
         int res = PAN(line, pk);
         if(res == -1)
         {
             fprintf(fo,"Case #%d: IMPOSSIBLE\n", cc++);
             printf("IMP\n");
         }
         else
         {
             printf("%d\n",res);
             fprintf(fo,"Case #%d: %d\n", cc++ ,res);
         }
         /*len = strlen(line);
         if(line[len-1] == '\n') len--;
         //lup(line, len);
 		New(line, len);
 		printf(" - %s\n", outp);*/
     }
 
     fclose(fp);
     fclose(fo);
     if (line)
         free(line);
 
     getchar();
     exit(EXIT_SUCCESS);
 }
 
 int PAN(char* ps, int s)
 {
     int i,j,f;
     f=0;
     int l = strlen(ps);
     for(i = 0; i <= l-s; i++)
     {
         if(ps[i]=='-')
         {
             f++;
             for(j = i; j < i+s; j++)
             {
                 if(ps[j] == '-')
                     ps[j] = '+';
                 else
                     ps[j] = '-';
             }
         }
     }
     for(i = 0; i < l; i++)
         if(ps[i] == '-')
             return -1;
     return f;
 }
 /*
 void bath(int n, int p)
 {
     char * b;
     b = (char*) malloc(n+2);
 
     b[0]=1;
     b[n+1]=1;
 
 
 
     free(b);
 
 }
 */
 void New(char* ss, int l)
 {
     int i;
 	int nope = 0;
 //	for(i = 0; i < l; i++)
     while(!check(ss,l))
     {
 
         nope = 0;
         i=0;
         while(i<l)
         {
             if(nope)
                 ss[i] = '9';
             else if(ss[i] > ss[i+1])
             {
                 nope = 1;
                 ss[i]--;
             }
             i++;
         }
     }
 	if(ss[0] == '0') outp = ss+1;
         else outp=ss;
 	return;
 /*
     int h = 0;
     int hpos = 0;
     int i;
     for(i = 0; i <= l; i++)
     {
         if(ss[i] > h)
         {
             h = ss[i];
             hpos = i;
         }
     }
     if(hpos != 0)
         ;*/
 }
 
 void lup(char* ss, int l)
 {
 	int tmp;
     int i;
 	while(!check(ss,l))
 	{
 	    //decrement
         for(i = l-1; i >= 0; i--)
         {
             if(ss[i] == '0')
             {
                 ss[i] = '9';
             }
             else
             {
                 ss[i]--;
 
                 break;
             }
         }
 
         if(ss[0] == '0')
         {
             ss++;
             l--;
         }
 /*
 		tmp = atoi(ss);
 		tmp--;
 		sprintf(ss, "%d", tmp);
 		l = strlen(ss);*/
 	}
 	outp = ss;
 }
 int check(char* ss, int l)
 {
 	int i;
 	for(i = 1; i < l; i++)
 	{
 		if(ss[i] < ss[i-1])
 			return 0;
 	}
 	return 1;
 }

