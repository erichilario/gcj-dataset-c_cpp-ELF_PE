#include <stdio.h>
 #include <string.h>
 int main(void) {
 char s[100000];
 int k,n,i,j,c=0,p=0,t,m[100000],mp;
 scanf("%d",&t);
 for(mp=0;mp<t;mp++)
 { 
 c=0;
 p=0;
 scanf("%s %d",s,&k);
 n=strlen(s);
 for(i=0;i<n;i++)
 {
 if(s[i]=='-'&& i+k<=n)
 {
 for(j=i;j<i+k;j++)
 {
 if(s[j]=='-')
 s[j]='+';
 else
 s[j]='-';
 }
 c++;
 }
 }
 s[n]='\0';
 //printf("%s\n",s);
 for(i=0;i<n;i++)
 {
 if(s[i]=='-')
 {
 p=1;
 break;
 }
 }
 if(p==0)
 m[mp]=c;
 else
 m[mp]=-1;
 }
 for(i=0;i<t;i++)
 {
 if(m[i]!=-1)
 printf("Case #%d: %d\n",i+1,m[i]);
 else
 printf("Case #%d: IMPOSSIBLE\n",i+1);
 }
 return 0;
 }
