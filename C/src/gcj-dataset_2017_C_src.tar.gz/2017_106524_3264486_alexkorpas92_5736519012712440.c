#include <stdio.h>
 #include <stdlib.h>
 
 char flip(char c) {
   if (c=='-')
     c = '+';
   else
     c = '-';
   
   return c;
 }
     
 int main () 
 {
   int i, j, k,  T;
   
   if (scanf("%d\n", &T)) {};
   for (i = 0; i < T; i++) {
     int N, M = 0;
     char input[2000], S[1500];
     
     if (fgets(input, sizeof(input), stdin)) {};
     sscanf(input, "%s %d", S, &N);
 
     j = 0;
     while (S[j+N-1] != '\0') {
       if (S[j] != '+') {
 	for (k = j; k < j + N; k++)
 	  S[k] = flip(S[k]);
 	M++;
       }
       j++;
     } 
     
     j = 0;  
     while (S[j] != '\0') {
       if (S[j++] == '-') {
 	M = -1;
 	break;
       }
     }
     
     printf("Case #%d: ", i+1);
     if (M < 0)
       printf("IMPOSSIBLE\n");
     else
       printf("%d\n", M);
   }
   return 0;
 }

