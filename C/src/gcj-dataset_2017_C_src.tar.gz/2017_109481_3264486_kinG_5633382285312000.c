#include <stdio.h>
 #include <stdlib.h>
 void test(int t,FILE* );
 int main()
 {FILE *file = fopen("E:\\downloadsssss\\B-small-attempt1.in", "r");
     int t,i;
     fscanf(file,"%d",&t);
     for(i = 1; i<= t; i++)
         test(i,file);
     return 0;
 }
 
 
 void test(int t,FILE* file)
 {
 
     FILE *fpIn;
  fpIn = fopen("E:\\out_tidy.txt", "a");
 
 
     char a[1009]; int big = 0, i = 0, index;
     fflush(stdin);
     fscanf(file,"%s",a);
     //printf("%s",a);
     printf("Case #%d: ",t);
     fprintf(fpIn,"Case #%d: ",t);
     while(a[i] > big && a[i] != '\0')
     {
         index = i;
         big = a[i] ;
         //printf("%d = b \n",big);
         i++;
     }
     i--;
     while(a[i]>= big){
     if(a[i+1] == '\0')
     {
         printf("%s",a);
         fprintf(fpIn,"%s",a);
         printf("\n");
         fprintf(fpIn,"\n");
         return;
     }
     i++;
     } i = 0;
     if(a[index+1] != '\0')
     {
         if(big == 1)
     {
         while(a[i+1] != '\0'){
         printf("9");
         fprintf(fpIn,"9");
         i++;
     }
     printf("\n");
     fprintf(fpIn,"\n");
     }
     else {
             i= 0;
         while(i<index)
         {
             printf("%c",a[i]);
             fprintf(fpIn,"%c",a[i]);
             i++;
         }
         if(a[index] -1 != '0')
         {printf("%c",a[index]-1);
         fprintf(fpIn,"%c",a[index]-1);}
         i++;
         while(a[i] != '\0')
         {
             printf("9");
             fprintf(fpIn,"9");
             i++;
         }
         printf("\n");
         fprintf(fpIn,"\n");
     }
     }
 }

