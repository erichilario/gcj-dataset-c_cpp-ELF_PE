#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
  // functional declarations
 
 char** get_nums(int* t);
 char** find_tidy(char**, int);
  int tidy(char* num, int len);
 void print(char**, int);
 
  int main(void)
 {
  // local declarations
  int t;
  char** aryOfNums;
 
  // statements
  aryOfNums=get_nums(&t);
  find_tidy(aryOfNums, t);
  print(aryOfNums,t);
 
  return 0;
 }
 
 char** get_nums(int* t)
 {
  // local declarations
  char** aryOfnums;
  FILE* spIn;
  int size;
 
  // statements
  spIn=fopen("B-small-attempt0.in", "r");
 
  if(!spIn)
    printf(" Error: unable to open input file"), exit(100);
 
  fscanf(spIn, "%d", t);
  size=*t;
  aryOfnums=(char**)calloc(size, sizeof(char*));
  
  for(int i=0; i<size;i++)
    { 
      aryOfnums[i]=(char*)calloc(19,sizeof(char));
      fscanf(spIn, " %s", aryOfnums[i]);
    }
  return aryOfnums;
 }
 
 char** find_tidy(char** nums, int t)
 {
  // local declarations
  int index;
  int i=0;
  // statements
  for( i=0; i<t;i++)
    while( (index=tidy(nums[i], (int)(strlen(nums[i])-1))) >= 0	 )
       {
          if(0== nums[i][index])
 	   nums[i][index]='0';
          else
            --(nums[i][index]);
 
          for(int j=index+1; j<strlen(nums[i]); j++)
              nums[i][j]='9';
       }
  return nums;
 }
 
 int tidy(char* num, int len)
 {
 // local declarations
  int j;
 int i=len;
 
 // statements
   if(len==0)
     return -1;
  j=len-1;
  
  for( i=len; i>0; i--, j--)
     if(num[j]>num[i])
         return j;
   
   
  if(j<0) 
   return -1;
 } 
 
    
 
 void print(char** nums, int n)
 {
 // local declarations
  char* tidy[n];
  int redundant;
  int len;
  int i,k;
  FILE* spOut;
  // statements
  spOut=fopen("B-small-attempt3.out", "w");
  if(!spOut)
    printf(" unable to open output file\n"), exit(104);
 
  for(i=0; i<n; i++)
     {
       k=0;
       tidy[i]=(char*)calloc((len=strlen(nums[i]))+1, sizeof(char));
      
      if('0'== *nums[i])
          redundant=k=1;
  
      while(redundant)
          if('0'== *(k+nums[i]))
            k++;    
          else
            redundant=0;
      strcpy(tidy[i], nums[i]+k);
   }
 
  for(i=0; i<n;i++)
    fprintf(spOut,"Case #%d: %s\n", i+1, tidy[i]);
  fclose(spOut);
 
 	    
   return;
 }  

