#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>	
 
 int main()
 {
 	int t, i, flag;
 	scanf("%d",&t);
 	long long *n=(long long*)malloc(sizeof(long long)*t);
 	long long temp, y, x;
 	for(i=0;i<t;i++)
 	{
 		scanf("%lld",&n[i]);
 	}
 	
 	for(i=0;i<t;i++)
 	{
 		if(n[i]<10)
 		{
 			printf("Case #%d: %lld\n",i+1,n[i]);
 			continue;
 		}
 		else if(n[i]==10)
 		{
 			printf("Case #%d: 9\n",i+1);
 			continue;
 		}
 		while(n[i]>=10)
 		{
 			temp=n[i];
 			flag=0;
 			y=temp%10;
 			temp=temp/10;
 			x=temp%10;
 			while(temp>0)
 			{
 				if(x>y)
 				{
 					flag=1;
 					break;
 				}
 				y=x;
 				temp=temp/10;
 				x=temp%10;
 			}
 			if(flag==1)
 			{
 				n[i]--;
 			}
 			else
 			{
 				printf("Case #%d: %lld\n",i+1,n[i]);
 				break;
 			}
 		}
 	}
 	
 	return 0;
 }

