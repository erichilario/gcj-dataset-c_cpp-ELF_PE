#include <stdio.h>
 #include <math.h>
 
 long long int num(int x[],int p){
     long long int power,m;
     long long int y=0;
     for(m=0;m<p+1;m++){
         power = pow(10,p-m);
         y = y + (x[m]*power);
     }
     return y;
 }
 
 long long int comp(int x[], int p, int i){
     int j;
     if(i==p || i<0){
         return num(x,p);
     }
     else if(x[i]<=x[i+1]){
          return comp(x,p,i+1);
     }
     else{
         x[i]--;
         for(j=i+1;j<p+1;j++){
             x[j]=9;
         }
         return comp(x,p,i-1);
     }
     
 }
 
 long long int max(long long int n ){
     /*if(n%10==0){
         return n-1;
     }*/
     int p;
     long long int m;
     p=0;
     m=n;
     while(m/10!=0){
         p++;
         m=m/10;
     }
     if(p==0){
     	return n;
     }
     long long int power;
     power = pow(10,p);
     if((n%power)==0){
     	return n-1;
     }
     int x[p+1];
     for(m=0;m<p+1;m++){
         power = pow(10,p-m);
         x[m]=(n/power)%10;
     }
     return comp(x,p,0);
     
 }
 
 int main(void) {
 	int t;
 	long long int n,m;
 	scanf("%d\n",&t);
 	int i;
 	for(i=1;i<=t;i++){
 	    scanf("%lld\n",&n);
 	    m = max(n);
 	    printf("Case #%d: %lld\n",i,m);
 	}
 	return 0;
 }
 

