#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main(){
     freopen("B-large.in", "r", stdin);
     freopen("B-large.out", "w", stdout);
 
     int T, i,j,q,k, len;
     char N[21];
 
     scanf("%i", &T);
     for(i=0; i<T; i++){
         scanf("%s", N);
         char S[21];
         for(j=0; j<21; j++){
             S[j] = 0;
         }
         len = strlen(N);
         for(j=0; j<len; j++){
             if(j+1 < len && N[j+1] < N[j]){
                 S[j] = (int) N[j] - 1;
                 for(q=j+1; q<len; q++){
                     S[q] = '9';
                 }
                 goto done;
             }
             S[j] = N[j];
         }
         done: for(k=j; k>=0; k--){
             if(k+1 < len && S[k+1] < S[k]){
                 S[k] = (int) N[k] - 1;
                 for(q=k+1; q<len; q++){
                     S[q] = '9';
                 }
             }
         }
         printf("Case #%i: %lli\n", i+1 , atoll(S));
     }
 
     return 0;
 }

