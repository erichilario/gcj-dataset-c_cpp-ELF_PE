#include <stdio.h>
 #include <stdlib.h>
 
 int main(void) {
 
 	int T;
 	scanf("%d\n", &T);
 	int i;
 	char *S = (char *) malloc(1001 * sizeof(char));
 	char c;
 	int k;
 	int result;
 	for (i = 1; i<=T; i++)	{
 		result = 0;
 		int idx = 0;
 		while ((c=getchar())!= ' ') {
 			S[idx++] = c;
 		}
 		S[idx] = '\0';
 		scanf("%d\n",&k);
 		// now solve the problemc
 		int j = 0;
 		int l;
 		for (j = 0; j <= idx - k; j++) {
 			if (S[j] == '-') {
 				//we need to flip
 				result++;
 				for (l = j; l < j + k; l++) {
 					S[l] = (S[l] == '-' ? '+' : '-'); //flip
 				}
 			}
 		}
 		int flag = 0;
 		for (j =0 ; j<idx; j++) {
 			if (S[j] == '-') {
 				printf("Case #%d: IMPOSSIBLE\n",i);
 				flag = 1;
 				break;
 			}
 		}
 		if (!flag) 
 			printf("Case #%d: %d\n", i,result);
 	}
 
 	return 0;
 }
