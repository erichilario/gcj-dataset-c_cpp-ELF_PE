#include <stdio.h>
 #include <string.h>
 
 int toSpacelen(int men, char stall[]);
 
 int main(void){
     FILE *fPtrQ = fopen("/Users/Clown0/Desktop/Hello World/Que.txt", "r");
     FILE *fPtrA = fopen("/Users/Clown0/Desktop/Hello World/Ans.txt", "w");
 
     int i,l,n,k,t,templen,maxlen,nodemen,tt=1,min;
     
     fscanf(fPtrQ, "%d",&t);
     
     while (t--) {
         char stall[1002] = {0};
         fscanf(fPtrQ, "%d%d",&n,&k);
         stall[0] = 1;
         stall[n+1] = -1;
         
         for (i=1; i <= k; ++i) {
             for (l=0,maxlen=0,nodemen=0; l < n; ++l) {
                 if (stall[l] == 1) {
                     templen = toSpacelen(l,stall);
                     if (templen > maxlen){
                         maxlen = templen;
                         nodemen = l;
                     }
                 }
             }
             min = maxlen/2;
             stall[nodemen+min] = 1;
         }
         
         for(i=0; i < 10;++i)
             printf("%d",stall[i]);
         
         fprintf(fPtrA,"Case #%d: %d %d\n",tt++,maxlen-min-1,min-1);
     }
     
     fclose(fPtrQ);
     fclose(fPtrA);
     return 0;
 }
 
 int toSpacelen(int men, char stall[]){
     int i;
     for (i=1; stall[men+i] != -1 && stall[men+i] != 1; ++i) {
         continue;
     }
     return i;
 }
