#include <stdio.h>
 #include <stdlib.h>
 
 int handleCase() {
 	int buffer_size = 1024;
 	int flippersize = 1;
 	char* buffer = calloc(buffer_size, sizeof(char));
 	fscanf(stdin, "%s %i\n", buffer, &flippersize);
 	int i=0, j=0;
 	int flips = 0;
 	do {
 		switch (buffer[i]) {
 			case '+': // Do nothing
 				break;
 			case '-' :
 				flips++;
 				for (j=i; j<i+flippersize; ++j) {
 					switch (buffer[j]) {
 						case '+' :
 							buffer[j] = '-';
 							break;
 						case '-' :
 							buffer[j] = '+';
 							break;
 						default:
 							fprintf(stdout, "IMPOSSIBLE");
 							return 0;
 					}
 				}
 				break;
 			default: //exit
 				i = -1;
 		}
 	} while (++i);
 	fprintf(stdout, "%i", flips);
 
 	free(buffer);
 	return 0;
 }
 
 void main () {
 	int ncases,i;
 	fscanf(stdin, "%i ", &ncases);
 
 	for(i=0; i<ncases; i++) {
 		fprintf(stdout, "Case #%i: ", i+1);
 		handleCase();
 		fprintf(stdout, "\n");
 	}
 }

