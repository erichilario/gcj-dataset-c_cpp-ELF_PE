#include<stdio.h>
 #include<string.h>
 int check(char * str)
 {
 	for(int i=0	;str[i] != '\0';i++)
 	{
 		if(str[i] == '-')
 			return i;
 	}
 	return -1;
 }
 int main()
 {
 	int t;
 	scanf("%d",&t);
 	for(int i=0;i<t;i++)
 	{
 		char s[11]; 
 		int k, c=0, cb, step=0;
 		scanf("%s %d",s,&k);
 		cb = check(s);int counter=0;
 		while(cb != -1)
 		{
 			step++;
 			for(int j=cb ;j<(cb+k) ;j++)	
 			{
 				if(s[j] == '-')
 				{
 					s[j] = '+';
 					continue;
 				}
 				if(s[j] == '+')
 					s[j] = '-';
 			}								
 			if(cb >= (strlen(s) - k + 1))
 			{
 				counter = -1;
 				break;
 			}			
 			cb = check(s);	
 		}
 		if (counter== -1)
 			printf("Case #%d: %s\n",i+1,"IMPOSSIBLE");
 		else
 			printf("Case #%d: %d\n",i+1,step);
 	}	
 	return 0;
 }
