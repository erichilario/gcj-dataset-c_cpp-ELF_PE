#include <stdio.h>
 
 long long find(long long n, long long k, int b) {
 	long long x;
 	int type;
 
 	if (k == 1)
 		return n;
 	if ((k & 1LL << (b - 1)) > 0)
 		type = 1;
 	else
 		type = 0;
 	x = find(n, ((k - (1LL << b)) | (1LL << (b - 1))), b - 1);
 	return type == 0 ? x / 2 : (x - 1) / 2;
 }
 
 int count(long long x) {
 	return x == 0 ? 0 : count(x / 2) + 1;
 }
 
 int main() {
 	int t, T;
 
 	scanf("%d", &T);
 	for (t = 1; t <= T; t++) {
 		long long n, k, x;
 		int b;
 
 		scanf("%lld%lld", &n, &k);
 		b = count(k) - 1;
 		x = find(n, k, b);
 		printf("Case #%d: %lld %lld\n", t, x / 2, (x - 1) / 2);
 	}
 	return 0;
 }

