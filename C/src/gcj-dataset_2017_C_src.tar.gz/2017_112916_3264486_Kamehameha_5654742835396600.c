#include<stdio.h>
 #include<math.h>
 
 int main() {
 	int old[1000]={0},
 		newf[1000]={0};
 	int t,n,k,temp,x,y,i,j,index;
 	scanf("%d",&t);
 	for(i=1;i<=t;i++) {
 		scanf("%d%d",&n,&k);
 		old[0]=n;
 		for(j=1;j<k;j++) {
 			temp=index=0;
 			for(y=0;y<=j;y++)
 				if(old[y]>temp) {
 					temp=old[y];
 					index=y;
 				}
 			for(x=y=0;x<=j;x++,y++) {
 				if(x==index) {
 					newf[x]=old[x]/2;
 					newf[x+1]=(old[x]-1)/2;
 					x++;
 				}
 				else
 					newf[x]=old[y];
 			}
 			for(x=0;x<=j;x++) //{
 				old[x]=newf[x];
 				//printf("%d, ",old[x]);
 			//}
 			//printf("\n");
 		}
 		temp=0;
 		for(x=0;x<k;x++) {
 			if(temp<old[x])
 				temp=old[x];
 			old[x]=newf[x]=0;
 		}
 		printf("Case #%d: %d %d\n",i,temp/2,(temp-1)/2);
 	}
 }

