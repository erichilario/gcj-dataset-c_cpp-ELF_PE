#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 
 int controllo(int numero){
     //return 0 se non ordinato
     //return 1 se ordinato
     int conta_cifre = 1;
     int moltiplicazione = 1;
     int i;
     int numero_scomposto[4];
     //Prendi cifre
     for(i = 0; i < numero; i++){
         moltiplicazione *= 10;
         if (numero < moltiplicazione){
             break;
         }else{
                 conta_cifre += 1;
         }
     }
     //cifre singole in numero_scomposto
     for(i = 1; i <= conta_cifre; i++){
         numero_scomposto[i-1] = numero / pow(10, conta_cifre - i);
         numero -= (numero_scomposto[i-1] * pow(10, conta_cifre - i));
     }
 
     //Iniziamo con i controlli
     int considerazione = numero_scomposto[0];
     int numeri_uguali = 1;
     for(i = 1; i < conta_cifre; i++){
         int numero_provvisorio = numero_scomposto[i];
         if (numero_provvisorio == considerazione){
             numeri_uguali++;
         }else{break;}
     }
     if (numeri_uguali == conta_cifre){
         return 1;
     }
     //2 controllo
     considerazione = numero_scomposto[0];
     for(i = 1; i < conta_cifre; i++){
         int numero_provvisorio = numero_scomposto[i];
         if (numero_provvisorio >= considerazione){
             considerazione = numero_provvisorio;
         }
         else{
             return 0;
         }
     }
     return 1;
 
 }
 
 int main(){
     FILE * input;
     FILE * output;
     int numero_iterazioni;
     int contatore;
     int numero;
     int numero_scomposto[4];
     int i;
     input = fopen("input.in", "r");
     output = fopen("output.txt", "w+");
     fscanf(input, "%d", &numero_iterazioni);
 
     for(contatore = 0; contatore < numero_iterazioni; contatore++){
         fscanf(input, "%d", &numero);
         if((numero < 10) && (numero >= 1)){
             fprintf(output, "Case #%d: %d\n", contatore+1, numero);
         }else{
             while(1 == 1){
                 if(controllo(numero) == 1){
                     break;
                 }
                 numero -= 1;
             }
             fprintf(output, "Case #%d: %d\n", contatore+1, numero);
         }
 
     }
 
     return 0;
 }

