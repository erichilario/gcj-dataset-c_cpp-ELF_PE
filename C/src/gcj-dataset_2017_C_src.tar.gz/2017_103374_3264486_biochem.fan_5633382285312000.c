#include <stdio.h>
 #include <string.h>
 
 int main() {
 	int T = 0;
 	char str[20];
 	scanf("%d", &T);
 
 	for (int t = 1; t <= T; t++) {
 		scanf("%s", str);
 		int len = strlen(str);
 
 		while (1) {
 			int i, j, ok = 1;
 			for (i = 1; i < len; i++) {
 				if (str[i] < str[i - 1]) {ok = 0; break;}
 			}
 			if (ok == 1) {
 				break;	
 			}
 			for (j = i; j < len; j++) str[j] = '9';
 			for (j = i - 1; j >= 0; j--) {
 				if (str[j] > '0') {
 					str[j]--;
 					break;
 				} else {
 					if (j > 0) str[j] = '9';
 					else str[j] = '0';
 				}
 			}
 //			printf("%s\n", str);
 		}
 		if (str[0] == '0') printf("Case #%d: %s\n", t, str + 1);
 		else printf("Case #%d: %s\n", t, str);
 	}
 
 	return 0;
 }

