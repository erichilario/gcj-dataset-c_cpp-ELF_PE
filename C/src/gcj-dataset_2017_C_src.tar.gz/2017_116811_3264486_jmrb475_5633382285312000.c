#include <bits/stdc++.h>
 using namespace std;
 
 int main()
 {
 	ios::sync_with_stdio(false);
 	ifstream inf;
 	ofstream outf;
 	inf.open("input");
 	outf.open("fout.txt", ios::out);
 	int t;
 	//inf>>t;
 	cin>>t;
 	int p = 1;	
 	while(t--)
 	{
 		char str[1024];
 		//inf>>str;
 		cin>>str;
 		int s = strlen(str);
 		//cout<<s<<" s \n";
 		for(int i=1; i<s; i++)
 		{
 			if( str[i] < str[i-1] )
 			{
 				for(int j=i-1; j>=0; j--)
 				{
 					if( str[j] == '0')
 					{
 						str[j] = '9';
 					}
 					else
 					{
 						str[j]--;
 						if( j > 0)
 						{
 							if( str[j] < str[j-1])
 								str[j] = '9';
 							else
 								break;
 						}
 					}
 				}
 				for(int j=i; j<s; j++)
 				{
 					str[j] = '9';
 				}
 				break;
 			}
 		}
 		outf<<"Case #"<<p++<<": "<<atoll(str)<<"\n";
 		//cout<<"Case #"<<p++<<": "<<str<<"\n";
 	}
 	inf.close();
 	outf.close();
 	
 }

