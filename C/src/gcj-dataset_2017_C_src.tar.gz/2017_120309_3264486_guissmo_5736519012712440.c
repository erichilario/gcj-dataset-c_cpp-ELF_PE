#include <stdio.h>
 #include <string.h>
 
 long sagot(char *str, long k){
 	long ret = 0;
 	long len = 0;
 	for(long i = 0; ; i++){
 		if(str[i] == '\0') break;
 		len++;
 	}
 	for(long i = 0; i < len-k+1; i++){
 		if(i+k > len) break;
 		if(str[i] == '-'){
 			ret++;
 			for(int j = i; j < i+k; j++){
 				if(str[j] == '+') str[j] = '-';
 				else str[j] = '+';
 			}
 		}
 	}
 	for(int i = 0; i < len; i++){
 		if(str[i] != '+') return -1;
 	}
 	return ret;
 }
 
 int main(){
 	long T;
 	scanf("%ld", &T);
 
 	long i;
 	for(i = 1; i <= T; i++){
 		char str[2000];
 		long k;
 		scanf("%s %ld", str, &k);
 		long ans = sagot(str, k);
 		if(ans < 0){
 			printf("Case #%ld: IMPOSSIBLE\n", i);
 		}else{
 			printf("Case #%ld: %ld\n", i, ans);
 		}
 	}
 }

