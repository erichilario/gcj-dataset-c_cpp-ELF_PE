#include <stdio.h>
 
 int r[4],s;
 void rIni();
 
 int main(void) {
 	int k,T;
 	freopen("B.in","r",stdin);
 	freopen("outasput.out","w",stdout);
 	scanf("%d",&T);
 	for(k=1;k<=T;k++)
 	{
 	    int i,n,f,j,inc,max,x;
 	    scanf("%d",&n);
 	    for(i=n;i>0;i--)
 	    {   inc=f=max=x=s=j=0;
 		rIni();
 		x=i;
 		while(x!=0)
 		{   r[inc++]=x%10;
 		    x=x/10;
 		    s++;
 		}
 		if(s==4)
 		{
 
 		}
 		else if(s==3)
 		{
 		  if(r[0]>=r[1])
 			if(r[1]>=r[2])
 				{printf("Case #%d: %d",k,i);break;}
 		}
 		else if(s==2)
 		{
 		  if(r[0]>=r[1])
 			{printf("Case #%d: %d",k,i);break;}
 		}
 		else
 			{printf("Case #%d: %d",k,i);break;}
 	    }
 	    printf("\n");
 	}
 	return 0;
 }
 
 void rIni()
 {       int i;
 	for(i=0;i<4;i++)
 	r[i]=0;
 }
 

