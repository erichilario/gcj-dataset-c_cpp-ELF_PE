#include<stdio.h>
 #include<string.h>
 
 int main() {
 
     int T, K, N, i,j,l;
 
     char S[1002];
     int len, end;
 
     scanf("%d", &T);
     //printf("%d\n",T);
 
     for (int i=1;i<=T;i++) {
         N=-2;
         scanf("%s %d", S, &K);
         //printf("%s %d\n", S, K);
 
         len = strlen(S);
         if (strstr(S, "-")==NULL) N=0;
         else {
             //- is present.
             if (len == K) {
                 if ((strstr(S, "+")!=NULL)
                         && (strstr(S, "-")!=NULL)) {
                     N=-1;
                 } else if (strstr(S,"+")==NULL) N=1;
             } else {
                 //Contains both, len > K   
                 N=0;
                 //for (char *ptr=strstr(S,"-");ptr!=NULL;ptr=strstr(ptr,"-")) {
                 for (char *ptr=strstr(S,"-");ptr!=NULL;ptr=strstr(S,"-")) {
                     //Start flipping
                     char *start=ptr;
                     int end = 0;
                     for (l=1;l<=K; l++) {
                         if (*ptr==0) {
                             end = 1;
                             break;
                         }
                         if (*ptr=='-') *ptr='+'; else *ptr='-';
                         //printf("l=%d K=%d %s\n",l,K, ptr);
                         ptr++;
                     }
                     if (end == 1) {
                         ptr=start;
                         for (j=1; j<=(K-l+1);j++) {
                             ptr--;
                             if (*ptr=='-') *ptr='+'; else *ptr='-';
                            // printf("j=%d K-l=%d %s\n",j,K-l, S);
                         }
                     }
                     //End of flip
                     N++;
                     //printf("End of flip %d %s\n",N, S);
                     if (N>len) {
                         N=-1;
                         break;
                     }
                 }
                 if (strstr(S,"-")!=NULL) N=-1;
             }
         }
 
         if (N==-1)
             printf("Case #%d: IMPOSSIBLE\n", i);
         else 
             printf("Case #%d: %d\n", i, N);
     }
 
 }

