#include <stdio.h>
 int main() 
 {
     int t,p,k,n,b,a;
     scanf("%d",&t);
     for(p=1;p<=t;p++)
         {
             scanf("%d%d",&n,&k);
             int size=0;
             size=2*n+2;
             int arr[size];
             arr[1]=n;
             int i=0;
             for(i=1;i<=k;i++)
             {
                 a=arr[i]/2;
                 b=a;
                 if(arr[i]%2==0)
                 b=b-1;
                 if(b<0)
                 b=0;
                 arr[2*i]=a;
                 arr[2*i+1]=b;
                 
             }
             i=i-1;
             printf("Case #%d: %d %d\n",p,+arr[2*i],arr[2*i+1]);
         }
 	return 0;
 }
