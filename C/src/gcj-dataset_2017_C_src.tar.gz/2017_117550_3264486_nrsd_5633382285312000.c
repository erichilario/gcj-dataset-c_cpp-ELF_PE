#include <stdio.h>
 int count(unsigned int i) {
  int ret=1;
  while (i/=10) ret++;
  return ret;
 }
  
 int main()
 {
   int i,j,k,arr[100], n, c, d, swap,a,b,z,flag=0;
   int num,dig,num2,mani=1;
   scanf("%d",&n);
   for (i=n;i>0;i--)
   {
   	scanf("%d",&num);
   	
   	    for(j=num;j>0;j--){
   	        num=j;
         	dig=count(j);
          	num2=dig;
          	dig--;
   			//	printf("%d",num2);
   			
   			arr[dig]=num%10;
   		//	printf("%d\t",j);
   			if(arr[dig]==0)
   			continue;
   			num=num/10;
   			for(k=dig-1;k>=0;k--)
   			{
   			    arr[k]=num%10;
   			   // printf("%d ",arr[k]);
   			    if(arr[k]==0 || arr[k]>arr[k+1])
   			    break;
   			    num=num/10;
   			   // printf("%d\t",arr[k]);
   			    
   			}
   			if(k==-1){
   			    printf("Case #%d: %d\n",mani,j);
   			    mani++;
   			break;
   			}
 
   	  }
   }
     return 0;
 }
