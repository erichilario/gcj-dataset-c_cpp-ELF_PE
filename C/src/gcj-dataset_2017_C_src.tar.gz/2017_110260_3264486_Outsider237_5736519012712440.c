#include <stdio.h>
 #include <string.h>
 char s[1000];
 int fsize;
 void flip(int p)
 {
   int si;
   for(si=0; si<fsize; si++)
   {
     if (s[p+si]=='+')
       s[p+si] = '-';
     else
       s[p+si] = '+';
   }
 }
 
 int cal()
 {
   int i, size, count=0;
   scanf("%s", &s);
   scanf("%d", &fsize);
   size = strlen(s);
   for(i=0; i<=size-fsize; i++)
     if(s[i]=='-')
     {
       flip(i);
       count++;
     }
   for(; i<size; i++)
     if(s[i]=='-')
       return -1;
   return count;
 }
 
 void main()
 {
   int T, i, res;
   scanf("%d", &T);
   for(i=1; i<=T; i++)
   {
     if((res=cal())==-1)
       printf("Case #%d: IMPOSSIBLE\n", i);
     else
       printf("Case #%d: %d\n", i, res);
   }
 }

