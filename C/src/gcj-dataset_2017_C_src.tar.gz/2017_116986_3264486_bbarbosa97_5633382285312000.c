//
 //  main.c
 //  Tidy Numbers
 //
 //  Created by Bernardo Barbosa on 08/04/17.
 //  Copyright © 2017 Bernardo Barbosa. All rights reserved.
 //
 
 #include <stdio.h>
 
 int main(int argc, const char * argv[]) {
     int times,number,digit,number2,algarisms=0,a=0,ok=0,nn,i,n;
     
     scanf("%d",&times);
     for(i=0;i<times;i++){
         scanf("%d",&number);
         number2 = number;
         
         for(n=number;n>0;n--){
             a=1;
             nn = n;
             ok=0;
             while(nn >0){
                 digit = nn%(10);
                 nn /= 10;
                 if(digit < nn%(10)){
                     ok=1;
                 }
                 a++;
             }
             if(!ok){
                 printf("Case #%d: %d\n",i+1,n);
                 break;
             }
         }
         algarisms=0;
     }
     return 0;
 }

