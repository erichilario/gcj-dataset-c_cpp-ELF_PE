#include <stdio.h>
 #include <string.h>
 #define ll long long
 
 int main(){
 	ll T;
 	scanf("%lld", &T);
 	ll keis;
 	for(keis = 1; keis <= T; keis++){
 		ll R;
 		ll C;
 		scanf("%lld %lld\n", &R, &C);
 		char arr[R][C];
 		ll wherei[26];
 		ll wherej[26];
 		for(ll i = 0; i < R; i++){
 			for(ll j = 0; j < C; j++){
 				scanf("%c", &arr[i][j]);
 			}
 			if(i != R-1) scanf("\n");
 		}
 		char sagot[R][C];
 		for(ll j = 0; j < C; j++){
 			char x = '?';
 			for(ll i = 0; i < R; i++){
 				sagot[i][j] = '.';
 				char c = arr[i][j];
 				if(c != x && c != '?') x = c;
 				sagot[i][j] = x;
 			}
 		}
 		for(ll j = 0; j < C; j++){
 			char x = '?';
 			for(ll i = R-1; i >= 0; i--){
 				char c = sagot[i][j];
 				if(c == '?') sagot[i][j] = x;
 				else x = c;
 			}
 		}
 		for(ll i = 0; i < R; i++){
 			char x = '?';
 			for(ll j = C-1; j >= 0; j--){
 				char c = sagot[i][j];
 				if(c == '?') sagot[i][j] = x;
 				else x = c;
 			}
 		}
 		for(ll i = 0; i < R; i++){
 			char x = '?';
 			for(ll j = 0; j < C; j++){
 				char c = sagot[i][j];
 				if(c == '?') sagot[i][j] = x;
 				else x = c;
 			}
 		}
 		printf("Case #%lld:\n", keis);
 		for(ll i = 0; i < R; i++){
 			for(ll j = 0; j < C; j++){
 				printf("%c", sagot[i][j]);
 			}
 			printf("\n");
 		}
 
 	}
 }

