#include <stdio.h>
 #include <string.h>
 int check(char* a)
 {
 	int i;
 	int flag = 0;
 	for (i = 0; i < strlen(a); i++)
 	{
 		if (*(a + i) == '-')
 		{
 			flag = 1;
 			break;
 		}
 	}
 	if (flag)
 	{
 		return 0;
 	}
 	else { return 1; }
 }
 int main(void)
 {
 	FILE *ifp, *ofp;
 	ifp = fopen("A-small-attempt1.in", "r");
 	ofp = fopen("output.txt", "w");
 	char S[100][1000];
 	int index, j, i, k, res, times;
 	int size[100];
 	int flag = 0;
 	int count = 0;
 	res = fscanf(ifp,"%d", &times);
 	for (i = 0; i < times; i++)
 	{
 		res = fscanf(ifp,"%s %d", S[i],&size[i]);// 
 	}
 	for (i = 0; i < times; i++)
 	{
 		if (check(S[i]))
 		{
 			fprintf(ofp, "Case #%d: 0\n", i + 1);
 		}
 		else 
 		{
 			for (j = 0; j < strlen(S[i]); j++)
 			{
 				if (S[i][j] == '-');
 				{
 					if (j + size[i] > strlen(S[i]))
 					{
 						if (!check(S[i])) 
 						{
 							fprintf(ofp, "Case #%d: IMPOSSIBLE\n", i + 1);
 							break;
 						}
 					}
 					else if (S[i][j]=='-')
 					{
 						for (k = j; k < j + size[i]; k++)
 						{
 							if (S[i][k] == '+') { S[i][k] = '-'; }
 							else { S[i][k] = '+'; }
 						}
 						count++;
 					}
 				}
 				if (check(S[i]))
 				{
 					fprintf(ofp, "Case #%d: %d\n", i + 1, count);
 					break;
 				}
 			}
 		}
 		count = 0;
 	}
 }
