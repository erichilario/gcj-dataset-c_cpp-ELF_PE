#include <stdio.h>
 #include <string.h>
 #define ll long long
 
 ll minLR(ll N){
 	switch(N%2){
 		case 0: return N/2 - 1;
 		case 1: return N/2;
 	}
 }
 
 ll maxLR(ll N){
 	switch(N%2){
 		case 0: return N/2;
 		case 1: return N/2;
 	}
 }
 
 ll sagot(ll N, ll K){
 	
 	ll n = N;
 
 	ll od[64];
 	ll ev[64];
 
 	for(int i = 0; i < 64; i++){ od[i] = 0; ev[i] = 0; }
 
 	switch(n%2){
 		case 0: {ev[0] = 1; od[0] = 0;} break;
 		case 1: {od[0] = 1; ev[0] = 0;} break;
 	}
 
 	ll i = 0;
 	// printf("%lld %lld %lld %lld\n", n, i, od[i], ev[i]);
 	while(n != 0){
 		ev[i+1] += ev[i];
 		od[i+1] += ev[i];
 		switch(n%4){
 			case 0: { od[i+1] += 2*od[i]; } break;
 			case 1: { ev[i+1] += 2*od[i]; } break;
 			case 2: { ev[i+1] += 2*od[i]; } break;
 			case 3: { od[i+1] += 2*od[i]; } break;
 		}
 		n = n >> 1;
 		i++;
 		// printf("%lld %lld %lld %lld\n", n, i, od[i], ev[i]);
 	}
 
 	ll d = -1;
 	ll k = K;
 	while(k != 0){
 		k = k >> 1;
 		d++;
 	}
 	// printf("%lld\n", d);
 
 	n = N >> d;
 	// printf("n = %lld\n", n);
 
 	ll s = 0;
 	k = K;
 	k -= (1 << d);
 	// printf("k = %lld\n", k);
 
 	switch(n%2){
 		case 0: { if(k-ev[d] >= 0) return n-1; else return n; } break;
 		case 1: { if(k-od[d] >= 0) return n-1; else return n; } break;
 	}
 
 }
 
 int main(){
 	ll T;
 	scanf("%lld", &T);
 
 	ll i;
 	for(i = 1; i <= T; i++){
 		ll N;
 		ll K;
 		scanf("%lld %lld", &N, &K);
 		ll ans = sagot(N, K);
 		printf("Case #%lld: %lld %lld\n", i, maxLR(ans), minLR(ans));
 	}
 }

