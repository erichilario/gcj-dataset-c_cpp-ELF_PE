#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 int main(){
 	int t,k, len,i,j,l,n, flag;
 	FILE *fin, *fout;
 	char str[21];
 	fin = fopen("B-small-attempt0.in", "r");
 	fout = fopen("outputB.txt", "w+");
 	
 	fscanf(fin, "%d",&t);
 	n=1;
 	while(t--){
 		fscanf(fin, "%s", str);
 		len = strlen(str);
 		
 		while(1){
 			flag=0;
 			for(i=0;i<len-1;i++){
 				if(str[i]>str[i+1]){
 					flag=1;
 					str[i] = str[i]-1;
 					for(j=i+1;j<len;j++){
 						str[j] = '9';
 					}
 					break;
 				}
 			}
 			if(!flag)
 				break;
 		}
 		
 		if(str[0] == '0' && len >= 2){
 			fprintf(fout, "Case #%d: %s\n",n++, str+1);
 		}else
 			fprintf(fout, "Case #%d: %s\n",n++, str);
 	}
 	return 0;
 }

