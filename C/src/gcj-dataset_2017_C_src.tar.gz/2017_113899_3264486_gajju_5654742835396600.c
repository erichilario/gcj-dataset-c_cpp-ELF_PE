#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 int T,x,t,n,k;
 
 int output(int n,int k)
 {
 if((n==0)||(n/2 <k)||(n==1))return 0;
 if(k==1)return n-1;
 n--;k--;
 return output(n-n/2,k-k/2);
 }
 
 int main()
 {
 
 scanf("%d",&t);
 
 for(T=0;T<t;++T)
 {
 
 scanf("%d%d",&n,&x);
 k=0;
 k=output(n,x);
 printf("Case #%d: %d %d\n",T+1,k-k/2,k/2);
 }
 
 
 return 0;
 }
 

