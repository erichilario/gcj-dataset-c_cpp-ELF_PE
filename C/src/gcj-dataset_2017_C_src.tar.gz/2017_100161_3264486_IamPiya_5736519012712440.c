#include<stdio.h>
 #include<string.h>
 void main()
 {
     int t,i,m;
     scanf("%d",&t);
     for(m=0;m<t;m++)
     {
         char s[1001];
         int k,l,j,c=0;
         fflush(stdin);
         scanf("%s",s);
         l=strlen(s);
         scanf("%d",&k);
         i=0;
         while(i<=l-k)
         {
             if(s[i]=='-')
             {
                 j=i;
                 s[j++]='+';
                 while(j<i+k)
                 {
                     if(s[j]=='-')
                         s[j]='+';
                     else
                         s[j]='-';
                     j++;
 
                 }
                 c++;
             }
             i++;
         }
         j=i;
         while(s[j])
         {
             if(s[j]=='-')
                 break;
             j++;
         }
         if(j==l)
             printf("Case #%d: %d\n",m+1,c);
         else
             printf("Case #%d: IMPOSSIBLE\n",m+1);
     }
 }

