#include <stdio.h>
 #include <stdlib.h>
 #define DEBUG 1
 #undef DEBUG
 
 typedef struct {
 	int max;
 	int min;
 } R;
 
 typedef struct stall {
 	int n;
 	struct stall* left;
 	struct stall* right;
 	int occupied;
 } Stall;
 
 int get_rs(Stall* stall) {
 	return stall->right->n - stall->n;
 }
 int get_ls(Stall* stall) {
 	return stall->n - stall->left->n;
 }
 
 int min(int a, int b) {
 	if (a < b) {
 		return a;
 	}
 	return b;
 }
 int max(int a, int b) {
 	if (a > b) {
 		return a;
 	}
 	return b;
 }
 
 /* where N is number of stalls including guards */
 R* stalls(int N, int K) {
 	int i;
 	int N_Stalls = N + 2;
 	R* r = malloc(sizeof(R));
 	Stall** stalls = malloc(N_Stalls * sizeof(Stall*));
 
 	int j;
 	int ls, rs, s = 0;
 	int current_ls, current_rs;
 
 	/* init and mark left/right stalls as occupied */
 	for (i = 0; i < N_Stalls; i++) {
 		/* malloc stall... */
 		stalls[i] = malloc(sizeof(Stall));
 	}
 	for (i = 0; i < N_Stalls; i++) {
 		stalls[i]->n = i;
 		stalls[i]->occupied = 0;
 		if (i != 0) {
 			stalls[i]->left = stalls[0];
 		} else {
 			stalls[i]->occupied = 1;
 			stalls[i]->left = NULL;
 		}
 		if (i != N_Stalls - 1) {
 			stalls[i]->right = stalls[N_Stalls - 1];
 		} else {
 			stalls[i]->occupied = 1;
 			stalls[i]->right = NULL;
 		}
 	}
 
 	/* debug */
 	#ifdef DEBUG
 	printf("Initial\n");
 	for (j = 0; j < N_Stalls; j++) {
 		if (stalls[j]->occupied) {
 			printf("%s", "o");
 		}
 		else {
 			printf("%s", ".");
 		}
 	}
 	printf("\n");
 	#endif
 
 	/* fit k visitors */
 	for (i = 0; i < K; i++) {
 		/* reset */
 		ls = 0;
 		rs = 0;
 
 		/* get ls/rs */
 		for (j = 0; j < N_Stalls; j++) {
 			if (!stalls[j]->occupied) {
 				/* init ls/rs */
 				if (ls == 0 && rs == 0) {
 					ls = get_ls(stalls[j]);
 					rs = get_rs(stalls[j]);
 					s = j;
 					continue;
 				}
 
 				current_ls = get_ls(stalls[j]);
 				current_rs = get_rs(stalls[j]);
 
 				if (min(current_ls, current_rs) > min(ls, rs)) {
 					ls = current_ls;
 					rs = current_rs;
 					s = j;
 					continue;
 				}
 				if (min(current_ls, current_rs) == min(ls, rs)) {
 					if (max(current_ls, current_rs) > max(ls, rs)) {
 						/* choose the one among those where
 						max(ls, rs) is maximal */
 						ls = current_ls;
 						rs = current_rs;
 						s = j;
 						continue;
 					}
 					if (max(current_ls, current_rs) == max(ls, rs)) {
 						/* double tie, choose leftmost stall */
 						continue;
 					}
 				}
 			}
 			#ifdef DEBUG
 			printf("ls - %d, rs - %d, s - %d\n", ls, rs, s);
 			#endif
 		}
 
 		/* occupy cell */
 		stalls[s]->occupied = 1;
 
 		/* update */
 		for (j = s - 1; j > 0; j--) {
 			if (stalls[j]->right->n > s) {
 				stalls[j]->right = stalls[s];
 			} else {
 				break;
 			}
 		}
 		for (j = s + 1; j < N_Stalls; j++) {
 			if (stalls[j]->left->n < s) {
 				stalls[j]->left = stalls[s];
 			} else {
 				break;
 			}
 		}
 
 		/* debug */
 		#ifdef DEBUG
 		printf("%d\n", i + 1);
 		for (j = 0; j < N_Stalls; j++) {
 			if (stalls[j]->occupied) {
 				printf("%s", "o");
 			}
 			else {
 				printf("%s", ".");
 			}
 		}
 		printf("\n");
 
 		printf("%d - NULL %d\n", j, stalls[0]->right->n);
 		for (j = 0; j < N_Stalls; j++) {
 			if (j == 0 || j == N_Stalls - 1) {
 				continue;
 			}
 			printf("%d - %d %d\n", j, stalls[j]->left->n, stalls[j]->right->n);
 		}
 		printf("%d - %d NULL\n", j - 1, stalls[N_Stalls - 1]->left->n);
 		#endif
 	}
 
 	r->max = max(ls, rs);
 	r->min = min(ls, rs);
 	return r;
 }
 
 /* n - number of stalls */
 /* K - people */
 int main(int argc, char* argv[]) {
 	int i, input_count;
 	int N, K;
 	R* r;
 
 	/* first line - number of inputs */
 	scanf("%d", &input_count);
 
 	for (i = 0; i < input_count; i++) {
 		scanf("%d %d", &N, &K);
 		r = stalls(N, K);
 		printf("Case #%d: %d %d\n", i + 1, r->max - 1, r->min - 1);
 	}
 
 	return 0;
 }

