#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char* itoa(long long int i, char b[]){
     char const digit[] = "0123456789";
     char* p = b;
 
     long long int shifter = i;
     do{ //Move to where representation ends
         ++p;
         shifter = shifter/10;
     }while(shifter);
     *p = '\0';
     do{ //Move back, inserting digits as u go
         *--p = digit[i%10];
         i = i/10;
     }while(i);
     return b;
 }
 
 int main(void)
 {
 	int t,count,flag,tidy,i,len;
 	char s[20];
 	long long int n;
 	scanf("%d",&t);
 	count=1;
 	while(count<=t)
 	{
 		scanf("%lld",&n);
 		flag=0;
 		tidy=0;
 		while(!tidy)
 		{
 			itoa(n,s);
 			len = strlen(s);
 			//printf("%s\n",s);
 			flag=0;
 			for(i=0;i<len-1;i++)
 			{
 				if(s[i]>s[i+1])
 				{
 					flag=1;
 					break;
 				}	
 			}
 			if(!flag)
 			{
 				tidy=1;
 				break;
 			}
 			n--;
 		}
 		printf("Case #%d: %lld\n",count,n);
 		count++;
 	}
 	return 0;
 }

