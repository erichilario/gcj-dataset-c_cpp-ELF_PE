#include"stdio.h"
 #include <stdlib.h>
 #include <string.h>
 
 int main () {
 int i,j,t, fl;
 long long int num;
 char numstr[100];
 
 	scanf("%d",&t);
 
 	for(j = 1; j<= t ; j++) {
 		scanf("%s",numstr);
 //		ltoa(num,numstr,10);
 //printf("%s\n",numstr);
 fl=1;
 while(fl==1) {
 	fl=0;		
 		for(i=1;i<strlen(numstr);i++){
 
 		if(strlen(numstr) == 1) break;			
 			if(numstr[i-1]>numstr[i] && fl == 0) {
 				numstr[i-1]=numstr[i-1]-1;
 				numstr[i]='9';
 				fl = 1;
 			} else if (fl == 1){
 				numstr[i] = '9';
 			}
 		}
 }
 		printf("Case #%d: %lld\n",j,atoll(numstr));	
 	}
 
 	return 0;
 }

