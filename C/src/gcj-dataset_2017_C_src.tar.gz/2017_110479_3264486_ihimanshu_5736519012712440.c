#include<stdio.h>
 void flip(char *a)
 {
     if(*a=='-')
         *a='+';
     else if(*a=='+')
         *a='-';
 }
 void flipall(char *str,int s,int k)
 {
     int i=0;
     while(i<k)
     {
         flip(&str[s+i]);
         i++;
     }
 }
 int check(char *str)
 {
     int i=0;
     for(;str[i]!='\0';i++)
         if(str[i]=='-')
         return 0;
     return 1;
 }
 int main()
 {
     int t,c=1;
     FILE *p=fopen("in1.in","r");
     FILE *o=fopen("ou1.ou","w");
     fscanf(p,"%d",&t);
     while(t--)
     {
         char str[1010];
         int k;
         fscanf(p,"%s",str);
         fscanf(p,"%d",&k);
         int i=0,j;
         int l=strlen(str) - k;
         int count=0;
         while(i<=l)
         {
             if(str[i]=='-')
                 {
                     flipall(str,i,k);
                     count++;
                 }
             while(str[++i]!='-'&&i<=l);
         }
         if(check(str))
             fprintf(o,"Case #%d: %d\n",c++,count);
         else
             fprintf(o,"Case #%d: IMPOSSIBLE\n",c++);
     }
 }

