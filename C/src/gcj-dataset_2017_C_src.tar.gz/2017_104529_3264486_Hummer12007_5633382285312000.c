#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main() {
 	int i, j, k, pref, N;
 	char c[32];
 	scanf("%d\n", &N);
 	for (i = 1; i <= N; ++i) {
 		fgets(c, 31, stdin);
 		c[strcspn(c, "\n")] = 0;
 		while (1) {
 			pref = strspn(c, "0");
 			memmove(c, c + pref, strlen(c) - pref);
 			c[strlen(c) - pref] = 0;
 			for (j = 0; j < strlen(c) - 1; ++j) {
 				if (c[j] > c[j + 1]) {
 					memset(c + j + 1, '9', strlen(c) - j - 1);
 					k = j;
 					while (k >= 0 && c[k] == '0')
 						c[k--] = '9';
 					c[k]--;
 					break;
 				}
 			}
 			if (j == strlen(c) - 1)
 				break;
 		}
 		pref = strspn(c, "0");
 		memmove(c, c + pref, strlen(c) - pref);
 		c[strlen(c) - pref] = 0;
 		printf("Case #%d: %s\n", i, c);
 	}
 	return 0;
 }

