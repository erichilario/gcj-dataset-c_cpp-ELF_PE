#include <stdio.h>
 #include <stdlib.h>
 
 int stlen(char* str){
     int len = 0;
     while(str[len]!='\0'){
         len++;
     }
     return len;
 }
 
 int main()
 {
     int t;
     scanf("%d",&t);
     int x = 1;
     char* num = (char*) malloc(sizeof(char)*1000);
     while(t--){
         scanf("%s",num);
         int i,j;
         int len = stlen(num);
         if(len!=1){
             for(i=len-1;i>0;i--){
                 if(num[i]<num[i-1]){
                     num[i-1]-=1;
                     for(j=i;j<len;j++){
                         num[j]='9';
                     }
                 }
             }
             if(num[0]=='0'){
                 num++;
             }
             printf("Case #%d: %s\n",x,num);
         }
         else {
             printf("Case #%d: %s\n",x,num);
         }
         x++;
     }
 }

