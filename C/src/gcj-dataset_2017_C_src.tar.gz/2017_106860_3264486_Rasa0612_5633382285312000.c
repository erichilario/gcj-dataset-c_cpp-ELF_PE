#include <stdio.h>
 
 
 
 int main(void) {
 int testcases,test1=1;
 scanf("%d",&testcases);
 
 while(test1<=testcases)
 {
 int t,n;int c1=0;
 int a[30],c=0,i,l=0,countof=0;
 scanf("%d",&t);
 n=t;
 while(n)
 {   
     n/=10;
     c++;
 }
 int p=c-1;
 
 int k=c-1;
 n=t;
 while(k>=0 )
 {
 a[k]=n%10;
 n/=10;
 k--;
 }
 k=c-1;
 c1=0;
 while(c1==0){
 l=0;
 
 for(i=0;a[i]<=a[i+1] && i<c-1;i++)
    {l++;
   
    }
 countof=0;
 
 if(a[0]==0)
 countof=1;
 if(l+1==c) 	
    {
     printf("case #%d: ",test1);
     for(i=countof;i<c;i++)
     printf("%d",a[i]);
     printf("\n");
     c1=1;
     break;
     
    }	
 else
    {
    a[i++]--;
    for(;i<c;i++)
     a[i]=9;
    }
 
 }
 test1++;
 }return 0;
 }
 

