#include <conio.h>
 #include <stdio.h>
 
 int snapper[31]; // on/off state
 int E = 1; // which is the final with electric 
 
 void p(FILE *output, long T, long N, long K) {
   long k, i, on;
 //  printf("%d, %d, %d, %d\n", snapper[1], snapper[2], snapper[3], snapper[4]);
   for(k = 0; k < K; k++) {
     for(i = 1; i <= E && i <= N; i++) {
       if(snapper[i] == 0)
         snapper[i] = 1;
       else
         snapper[i] = 0;
     }
         
     //update final with electric
     for(i = 1; i <= N; i++) {
       if(snapper[i] == 0 || i == N) {
         E = i;
         break;
       }  
     }
     
 //    printf("[%03d] %d, %d, %d, %d    %d\n", k, snapper[1], snapper[2], snapper[3], snapper[4], E);
   } 
   
   if(E == N && snapper[N] == 1)
     on = 1;
   else
     on = 0;
   
   fprintf(output, "Case #%d: %s\n", T, (on)?"ON":"OFF");
   printf("Case #%d: %s\n", T, (on)?"ON":"OFF");
 }
 
 int main()
 {
   FILE *input = fopen("input.txt", "r"); 
   FILE *output = fopen("output.txt", "w");
   long T=0, CaseNum, N, K;
   int i;
   
   fscanf(input, "%d\n", &CaseNum);
   printf("%d\n", CaseNum);
   for( T=1; T<=CaseNum; T++) {
     for(i=1; i<31; i++)
       snapper[i] = 0;
     E = 1;
       
     fscanf(input, "%d %d\n", &N, &K);    
     printf("%d %d\n", N, K);
     p(output, T, N, K);
   }  
 
   fclose(input);
   fclose(output);
   return 0;
 }

