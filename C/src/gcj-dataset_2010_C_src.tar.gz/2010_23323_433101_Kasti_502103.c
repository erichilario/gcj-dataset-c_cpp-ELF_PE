#include <stdio.h>
 #include <stdlib.h>
 #include <windows.h>
 
 
 BYTE Snap[30];
 DWORD N;
 DWORD K;
 
 
 BOOL TestCase()
 {
   DWORD i;
   memset(Snap, 0, N);
   while (K--)
   {
     int haspower = 1;
     for (i=0; i<N; i++)
     {
       if (haspower)
       {
         haspower = (Snap[i] != 0);
         Snap[i] = !(Snap[i]);
         if (!haspower)
         {
           break;
         }
       }
     }
   }
   for (i=0; i<N; i++)
   {
     if (Snap[i] == 0)
     {
       break;
     }
   }
   return (i == N);
 }
 
 
 void main()
 {
   FILE * f;
   f = fopen("d:\\a.txt", "r");
   if (f != NULL)
   {
     DWORD T, n;
     fscanf(f, "%d\n", &T);
     for (n=1; n<=T; n++)
     {
       fscanf(f, "%d %d\n", &N, &K);
       printf("Case #%d: %s\n", n, TestCase()? "ON" : "OFF");
     }
     fclose(f);
   }
 }
 
 

