#include "common.h"
 #include "common.c"
 
 int main(void)
 {
   int64_t C, N, K, B, T;
   int i, j, tmp, flag1, test, sum, k, old_jump;
   int x[100], jumps[100];
   double t1, t2, rest;
   double v[100];
     
   scanf(" %lld", &C);
   for(test = 0; test < C; test++)
     {
       scanf(" %lld %lld %lld %lld", &N, &K, &B, &T);
       for(i = 0; i < N; i++)
         {
           scanf(" %d", &x[i]);
         }
       for(i = 0; i < N; i++)
         {
           scanf(" %d", &tmp);
           v[i] = tmp;
         }
       for(i = N - 1; i >= 0; i--)
         {
           jumps[i] = 0;
           flag1 = FALSE;
           t2 = T + 1;
           for(j = i; j < N; j++)
             {
               if(v[i] > v[j])
                 {
                   flag1 = TRUE;
                   t1 = (x[j] - x[i]) / (v[i] - v[j]);
                   rest = B - (x[j] + v[j] * t1);
                   if(rest > EPS6)
                     {
                       t2 = t1 + rest / v[j];
                       if(t2 <= T)
                         {
                           break;
                         }
                       if(jumps[j] != 100)
                         {
                           jumps[i] += jumps[j];
                         }
                       jumps[i]++;
                     }
                   else
                     {
                       t2 = (B - x[i]) / v[i];
                       break;
                     }
                 }
             }
           if(flag1 == FALSE)
             {
               t2 = (B - x[i]) / v[i];
             }
           if(t2 > T)
             {
               jumps[i] = 100;
             }
           //out("(%d,%d) ", i, jumps[i]);
         }
       //outn("");
       sum = 0;
       k = 0;
       for(i = N - 1; i >= 0; i--)
         {
           if(jumps[i] < 100)
             {
               sum += jumps[i];
               k++;
               if(k >= K)
                 {
                   break;
                 }
             }
         }
       if(k >= K)
         {
           outn("Case #%d: %d", test + 1, sum);
         }
       else
         {
           outn("Case #%d: IMPOSSIBLE", test + 1);
         }
     }
   return 0;
 }

