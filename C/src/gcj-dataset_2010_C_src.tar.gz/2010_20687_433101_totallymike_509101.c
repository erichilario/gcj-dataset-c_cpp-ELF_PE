#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct group{
   int g; // Number of people per group.
   struct group *next, *prev;
 } group;
 
 int main() {
   int i, j; // Counters.
   int t; // Test cases.
   int riders; // Amount of riders on current trip.
   int groups_on_coaster;
   group *first, *temp, *temp2;
   
   scanf("%d", &t);
 
   int R[t], k[t], N[t];
   int *g[t];
   int answers[t];
 
   for (i = 0; i < t; i++) {
     scanf("%d %d %d", &R[i], &k[i], &N[i]);
     g[i] = (int *) malloc(sizeof(int) * N[i]);
     
     for (j = 0; j < N[i]; j++) {
       scanf("%d", &g[i][j]);
     }
   }
 
   for (i = 0; i < t; i++) {
     first = (group *) malloc(sizeof(group));
     first->g = g[i][0];
     temp = first;
     for (j = 1; j < N[i]; j++) {
       temp->next = (group *) malloc(sizeof(group));
       temp2 = temp->next;
       temp2->g = g[i][j];
       temp2->prev = temp;
       temp = temp2;
     }
     temp->next = first;
     first->prev = temp;
     riders = 0;
     groups_on_coaster = 0;
     answers[i] = 0;
     for (j = 0; j < R[i]; j++) {
       while (riders < k[i]) {
 	if (groups_on_coaster >= N[i]) {
 	  break;
 	}
 	if (first->g + riders <= k[i]) {
 	  riders += first->g;
 	  answers[i] += first->g;
 	  first = first->next;
 	  groups_on_coaster++;
 	} else {
 	  break;
 	}
       }
       groups_on_coaster = 0;
       riders = 0;
     }
 
     first->prev->next = NULL;
     while (first->next != NULL) {
       temp = first;
       first = first->next;
       free(temp);
     }
     free(first);
   }
 
   for (i = 0; i < t; i++) {
     printf("Case #%d: %d\n", i + 1, answers[i]);
   }
   return 0;
 }

