#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define BIT_IS_ZERO(word, pos)  ((word & (1<<(31 - pos))) == 0)
 #define BIT_IS_ONE(word, pos)   (!BIT_IS_ZERO(word, pos))
 #define SWITCH_BIT(word,pos)    (word ^= (1<<(31 - pos)))
 #define SNAP_FINGERS(snapper, N)        \
     if(1){                              \
         int i;                          \
         for (i = 0; i < N ; i++) {      \
             SWITCH_BIT(snapper, i);     \
             if (BIT_IS_ONE(snapper, i)) \
                 break;                  \
         }                               \
     }
 
 int main(int argc, char **argv)
 {
     FILE *fp = fopen(argv[1], "r");
     long int T, N, light;
     unsigned long int snapper; // 32 bit, each bit a snapper
     unsigned long long int t, k, K;
 
     fscanf(fp, "%ld", &T);
     for (t = 0; t < T; t++) {
         fscanf(fp, "%ld %Ld", &N, &K);
         for (snapper = 0, k = 0; k < K; k++) {
             SNAP_FINGERS(snapper, N);
         }
         for (light = 1, k = 0; k < N; k++) {
             if (BIT_IS_ZERO(snapper, k)) {
                 light = 0;
                 break;
             }
         }
         printf("Case #%Lu: %s\n", t+1, (light == 1) ? "ON" : "OFF");
     }
 }
 

