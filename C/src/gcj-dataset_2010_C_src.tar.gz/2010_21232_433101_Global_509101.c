#include <stdio.h>
 #include <stdlib.h>
 
 #define rep(i,N) for (i = 0; i < N; i++)
 
 void main(){
 	int R,K,N,i,T,t;
 	int A[3000], B[1000], C[1000];
 
 	scanf("%d", &T);
 	rep(t,T) {
 		scanf("%d %d %d", &R, &K, &N);
 		rep(i, N) { scanf("%d", &A[i]); A[N+i] = A[i]; }
 		rep(i, N) {		
 			int c = 0, d = 0, j = i;
 			while (c + A[j] <= K && d < N) { c+=A[j]; d++; j++; }
 			B[i] = j % N;
 			C[i] = c;
 		}
 		
 		long long int S = 0, j = 0;
 		rep(i, R) {
 			S += C[j];
 			j = B[j];
 		}
 		printf("Case #%d: %lld\n", t+1, S);
 	}
 }
 

