
 
 unsigned long long facts[501];
 
 unsigned tables[501][501];
 
 unsigned long long val[501];
 
 unsigned long long foo(int a, int b){
   if (b>a) return foo(a,a);
   if (tables[a][b] != 0) return tables[a][b];
   unsigned long long sum = 0;
   int i;
   for (i=1;i<=b;i++){
     unsigned int currval = facts[a] / facts[a-i] / facts[i];
     sum += currval;
   }
   tables[a][b] = sum;
   return sum;
 }
 
 int bar(int a){
   if (a<=1) return 0;
   if (a==2) return 1;
   if (a==3) return 2;
   if (a==4) return 3;
   unsigned sum = a-1;
   unsigned b = a-3;
   int i;
   for (i=1;i<b;i++){
     unsigned cur = (unsigned)foo(i, b-i);
     sum += cur;
   }
   return sum;
 }
 
 int main(){
   int k;
   facts[0] = 1;
   for (k=1;k<=500;k++){
     facts[k] = facts[k-1]*k;
   }
 
   int times, i, t;
   scanf("%d", &times);
   for (i=0;i<times;i++){
     scanf("%d", &t);
     if (val[t] == 0)     {
       val[t] = bar(t)%100003;
     }
   printf("Case #%i: %i\n", i+1, val[t]);
   }
 }

