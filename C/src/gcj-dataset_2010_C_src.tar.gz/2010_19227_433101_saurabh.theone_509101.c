#include<stdio.h>
 
 main()
 {
     int t, i, r, k, n, j;
     scanf("%d", &t);
     for (i = 0; i < t; i++)
     {
         scanf("%d%d%d", &r, &k, &n);
         int queue[n], ctr = 0, amt = 0, total = 0, ctr1 = 0;
         for (j = 0; j < n; j++)
         {
             scanf("%d", &queue[j]);
             //printf("queue[%d]:%d\n",j,queue[j]);
         }
         for (j = 0; j < r; j++)
         {
             //for each round do --->
             amt = 0;
             ctr1 = 0;
             while (1)
             {
                 if (amt + queue[ctr] <= k)
                 {
                     amt += queue[ctr];
                     ctr1++;
                     if (ctr1 == n)
                     {
                         break;
                     }
                     ctr = (ctr + 1) % n;
                 } else
                 {
                     break;
                 }
             }
             //printf("amt: %d\n", amt);
             //printf("total: %d\n", total);
             total += amt;
         }
         printf("Case #%d: %d\n", i + 1, total);
     }
 }
