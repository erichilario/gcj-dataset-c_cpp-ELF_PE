#include<stdio.h>
 
 int main(){
     
   int t,r,k,n,g[10];
   int i,j,l,sum,temp;
   int x,y;   
   
   
   scanf("%d",&t);
   for(i=1;i<=t;i++){
      scanf("%d",&r);
      scanf("%d",&k);                 
      scanf("%d",&n);                 
      
      for(j=0;j<n;j++){
         scanf("%d",&g[j]);                 
      }
  
      sum=0;
  
      x=0;
      for(l=0;l<r;l++){
        temp=0;
         for(j=0;j<n;j++){
            y=x+j;
            if(y>=n){
               y=y-n;
            }
            if((temp+g[y])<=k){
                 temp=temp+g[y];
            }   
            else{
                 break;
            }        
         
         }
         sum=sum+temp;
         x=y;                    
      }
      printf("Case #%d: %d\n",i,sum);
  
   }
     
 }

