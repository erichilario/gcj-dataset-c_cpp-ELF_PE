#include <stdio.h>
 
 int main()
 {
     int T, Ti, N, K;
     scanf("%d", &T);
 
     for (Ti = 1; Ti <= T; Ti++)
     {
         scanf("%d %d", &N, &K);
 
         int ON=1;
         for (int i=0;i<N;i++)
         {
             if (!(K & (1<<i)))
                 ON=0;
         }
         printf("Case #%d: %s\n", Ti, (ON?"ON":"OFF"));
     }
 }

