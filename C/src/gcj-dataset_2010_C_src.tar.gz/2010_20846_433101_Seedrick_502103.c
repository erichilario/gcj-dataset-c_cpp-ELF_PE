#include<stdio.h>
 #include<math.h>
 //#include<conio.h>
 int main() {
   
     //FILE* fr = fopen("A-large.in", "r");
     //FILE* fw = fopen("A-large.out", "w");
     
     int noc, nocc;
     scanf("%d", &noc);
     nocc = noc;
     int n,k;
     
     while(nocc--){
         scanf("%d", &n);
         scanf("%d", &k);
         
         if(!(k % 2)) {
             printf("Case #%d: OFF\n", (noc-nocc));
             continue;
         }
         
         long i = pow(2.0,(float)n);
         if(!((k+1)%i))
             printf("Case #%d: ON\n", (noc-nocc));
         else
             printf("Case #%d: OFF\n", (noc-nocc));
     
     }
     //fclose(fr);
     //fclose(fw);
     //getch();
     return 0;
 }

