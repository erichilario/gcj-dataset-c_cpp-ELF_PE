#include <stdio.h>
 #include <stdlib.h>
 #include <linux/fs.h>
 #include <math.h>
 
 int T, R, k, N;
 int g[10000000];
 int gm[10000000];
 int amount;
 
 void main(void)
 {
 	FILE *fpi, *fpo;
 	int i,j;
 	int p, tmp;
 
 	fpi=fopen("C-small-attempt0.in", "r");
 	fpo=fopen("C-small-attempt0.out","w");
 
 	fscanf(fpi, "%d", &T);
 	for(i=0;i<T;i++)
 	{
 		amount = 0;
 		p=0;
 		fscanf(fpi, "%d %d %d", &R, &k,&N);
 
 		for(j=0;j<N;j++)
 			fscanf(fpi, "%d", &g[j]);	
 		for(j=0;j<R;j++)
 		{
 			tmp=0;
 			while(tmp+g[p] <= k && gm[p] != 1)
 			{
 				tmp+=g[p];
 				gm[p]=1;
 				p=(p+1)%N;
 			}
 			memset(gm, 0, sizeof(int)*N);
 			amount += tmp;
 		}
 
 		fprintf(fpo, "Case #%d: %d\n", i+1, amount);
 	}
 	fclose(fpi);
 	fclose(fpo);
 }
 

