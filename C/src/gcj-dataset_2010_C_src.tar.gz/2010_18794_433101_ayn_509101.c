//#define DEBUG_PRINTS
 
 #ifdef DEBUG_PRINTS
 #define PRINT(X) printf X
 #else
 #define PRINT(X)
 #endif
 
 #include <stdio.h>
 
 FILE *fpIn, *fpOut;
 void exec( int testcase );
 
 int main( void )
 {	
 	int i,cases;
 
 	fpIn = fopen ( "C-small-attempt0.in", "r" );
 	fpOut = fopen ( "output.out", "w" );
 
 	if ( fpIn == NULL || fpOut == NULL ) 
 	{	
 		PRINT (("Error: Input file not found\n"));
 		return 0;
 	}
 
 	fscanf (fpIn, " %d", &cases);
 
 	PRINT (("Total test cases:%d\n",cases));
 
 	for (i=1;i<=cases;i++)
 	{
 		exec(i);
 	}
 
 	fclose (fpIn);
 	fclose (fpOut);
 
 	return 0;
 }
 
 int g[1000];
 
 void exec( int testcase )
 {
 	int R, k, N,i,group,people_per_round,Euros,first_group;
 
 	fscanf (fpIn, " %d %d %d", &R, &k, &N);
 
 	for ( i=0; i<N; i++ )
 	{
 		fscanf (fpIn, " %d", &g[i]);
 	}
 
 	group = 0;
 	Euros = 0;
 	for (i=1; i<=R; i++)
 	{
 		people_per_round = 0;
 		first_group = group;
 		do
 		{
 			people_per_round += g[group];
 			group++;
 			if ( group == N ) group = 0;
 		} while ( (group != first_group) && ((people_per_round + g[group]) <= k) );
 
 		Euros = Euros + people_per_round;
 	}
 
 	fprintf ( fpOut, "Case #%d: %d\n", testcase, Euros );
 
 	PRINT (( "Case #%d: %d\n", testcase, Euros ));
 }

