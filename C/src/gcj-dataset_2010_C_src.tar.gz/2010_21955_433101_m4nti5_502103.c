#include <stdio.h>
 #include <string.h>
 int power[31], onoff[31],k,n;
 
 int bulbOn(){
 	int i,j,m;
 	memset(power,0,sizeof power);
 	memset(onoff,0,sizeof onoff);
 	power[0] = 1;
 	onoff[0] = 1;
 	for(i = 0; i < k; ++i){
 		for(j = 1; j <=n; ++j){
 			if(power[j-1]){
 				onoff[j] = !onoff[j];
 			}else
 				break;
 		}
 		for(j = 1; j <=n; ++j){
 			if(!onoff[j] || !power[j-1]){
 				for(m = j; m <=n; ++m){
 					power[m] = 0;
 				}
 				break;
 			}else if(power[j-1] && onoff[j])
 				power[j] = 1;
 		}
 	}
 
 	if(power[n] == 1 && onoff[n] == 1){
 		return 1;
 	}
 	return 0;
 }
 
 int main(){
 	int t,c = 1;
 	scanf("%d\n",&t);
 	while(t--){
 		scanf("%d %d\n",&n,&k);
 		if(bulbOn()){
 			printf("Case #%d: ON\n",c);
 		}else
 			printf("Case #%d: OFF\n",c);
 		c++;
 	}
 }
 

