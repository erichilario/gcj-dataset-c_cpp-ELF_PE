#include <stdio.h>
 #include <assert.h>
 
 #define BUFLEN 50
 #define MAXLEN 50
 #define Neither 100
 #define Both 101
 
 
 enum {
   NONE = 0,
   RED,
   BLUE,
 };
 
 void
 print_matrix(int mat[BUFLEN][BUFLEN], int n)
 {
   int i,j;
   printf("\n");
   for(i = 0;i < n; i++) {
     for(j = 0; j < n; j++) {
       switch (mat[i][j]) {
         case RED :
           printf("R");
           break;
         case BLUE :
           printf("B");
           break;
         case NONE :
           printf(".");
           break;
       }
     }
     printf("\n");
   }
 }
 
 void
 count_row(int p, int mat[BUFLEN][BUFLEN], int n, int * max) {
   int i, j, c = 0;
   for (i = 0; i < n; i++) {
     for (j = 0; j < n; j++) {
       if(mat[i][j] == p) {
         c++;
       } else {
         if (c > *max) {
           *max = c;
         }
         c = 0;
       }
     }
     if (c > *max) {
       *max = c;
     }
     c = 0;
   }
 }
 
 void
 count_column(int p, int mat[BUFLEN][BUFLEN], int n, int * max) {
   int i, j, c = 0;
   for (j = 0;  j < n; j++) {
     for (i = 0; i < n; i++) {
       if(mat[i][j] == p) {
         c++;
       } else {
         if (c > *max) {
           *max = c;
         }
         c = 0;
       }
     }
     if (c > *max) {
       *max = c;
     }
     c = 0;
   }
 }
 
 void
 count_slash(int p, int mat[BUFLEN][BUFLEN], int n, int * max) {
   int i, j, u, v, c = 0;
 
   j = 0;
   for (i = 0;i < n; i++) {
     u = i;
     v = j;
     c = 0;
     while (u < n && v < n) {
       if(mat[u][v] == p) {
         c++;
       } else {
         if (c > *max) {
           *max = c;
         }
         c = 0;
       }
       u++;
       v++;
     }
     if (c > *max) {
       *max = c;
     }
     c = 0;
   }
   i = 0;
   for (j = 0;j < n; j++) {
     u = i;
     v = j;
     c = 0;
     while (u < n && v < n) {
       if(mat[u][v] == p) {
         c++;
       } else {
         if (c > *max) {
           *max = c;
         }
         c = 0;
       }
       u++;
       v++;
     }
     if (c > *max) {
       *max = c;
     }
     c = 0;
   }
 }
 
 
 void
 count_bslash(int p, int mat[BUFLEN][BUFLEN], int n, int * max) {
   int i, j, u, v, c = 0;
 
   j = 0;
   for (i = 0;i < n; i++) {
     u = i;
     v = j;
     c = 0;
     while (u < n && v < n && u >= 0 && v >= 0) {
       if(mat[u][v] == p) {
         c++;
       } else {
         if (c > *max) {
           *max = c;
         }
         c = 0;
       }
       u++;
       v--;
     }
     if (c > *max) {
       *max = c;
     }
     c = 0;
   }
   i = n - 1;
   for (j = 0;j < n; j++) {
     u = i;
     v = j;
     c = 0;
     while (u < n && v < n && u >= 0 && v >= 0) {
       if(mat[u][v] == p) {
         c++;
       } else {
         if (c > *max) {
           *max = c;
         }
         c = 0;
       }
       u++;
       v--;
     }
     if (c > *max) {
       *max = c;
     }
     c = 0;
   }
 }
 
 int f(unsigned int n , unsigned int k) {
   int i,j, p = 0, q = 0;
   int mat[BUFLEN][BUFLEN];
   char buffer[BUFLEN];
   int tmp_row[BUFLEN];
   int max_r = 0 , max_b = 0;
 
   q = n - 1;
   for (i = 0; i < n; i++) {
     scanf("%s", buffer);
     // 一時配列に入れる
     for (j = 0; j < n; j++) {
       switch (buffer[j]) {
         case 'R' :
           tmp_row[j] = RED;
           break;
         case 'B' :
           tmp_row[j] = BLUE;
           break;
         case '.' :
           tmp_row[j] = NONE;
           break;
       }
     }
     p = n - 1;
     // 後ろから NONE でないものまで数える
     for (j = n - 1; j >= 0 ; j--) {
       if (tmp_row[j] != NONE) {
         break;
       }
     }
     while(j >= 0 && p >= 0) {
       if(tmp_row[j] == NONE) {
         j--;
         continue;
       }
 
       mat[p][q] = tmp_row[j];
       j--;
       p--;
     }
     for (; p >= 0;p--) {
       mat[p][q] = NONE;
     }
     q--;
   }
 
   /* printf("\n"); */
   /* print_matrix(mat, n); */
   /* printf("\n"); */
 
   count_row(RED, mat, n, &max_r);
   count_column(RED, mat, n, &max_r);
   count_slash(RED, mat, n, &max_r);
   count_bslash(RED, mat, n, &max_r);
 
   count_row(BLUE, mat, n, &max_b);
   count_column(BLUE, mat, n, &max_b);
   count_slash(BLUE, mat, n, &max_b);
   count_bslash(BLUE, mat, n, &max_b);
 
   //printf("max RED is %d\n", max_r);
   //printf("max BLUE is %d\n", max_b);
 
   if(max_r >= k && max_b >= k)
     return Both;
   if(max_r >= k)
     return RED;
   if(max_b >= k)
     return BLUE;
   return Neither;
 }
 
 int main () {
   int i, j, l, n, k;
   scanf("%d", &l); // count test cases
   for (i = 0; i < l; i++) {
     int res;
     scanf("%d %d", &n, &k);
     printf("Case #%i: ", i + 1);
     res = f(n,k);
     switch (res) {
       case BLUE:
         printf("Blue\n");
         break;
       case RED:
         printf("Red\n");
         break;
       case Neither:
         printf("Neither\n");
         break;
       case Both:
       default:
         printf("Both\n");
         break;
     }
   }
   return 0;
 }

