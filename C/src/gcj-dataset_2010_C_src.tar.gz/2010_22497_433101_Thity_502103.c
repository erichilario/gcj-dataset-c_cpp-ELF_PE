#include <stdio.h>
 #define INFILE "A-small.in"
 #define OUTFILE "A-small.out"
 
 int main(void)
 {
 	int i, j, t;
 	freopen(INFILE,  "r", stdin);   
 	freopen(OUTFILE, "w", stdout);
 	scanf("%d", &t);
 	for (i=1; i<=t; i++)
 	{
 		unsigned long n, k;
 		scanf("%lu%lu", &n, &k);
 		for (j=0; j<n; j++)
 			if ((1<<j)&(k+1))
 				break;
 		printf("Case #%d: ", i);
 		if (j==n)
 			puts("ON");
 		else
 			puts("OFF");
 	}
 	return 0;
 }
