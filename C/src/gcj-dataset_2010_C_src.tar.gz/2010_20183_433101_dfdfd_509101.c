#include<stdio.h>
 #include<conio.h>
 int itimes,i,j,rolls,ar[9999999],y;
 long int r,k,n;
 int calc( long int,long int,long int);
 int main()
 {
     //printf("No of test cases: ");
     scanf("%d",&itimes);
     for(i=1;i<=itimes;i++)
     {
 			  //printf("r k n: ");
 			  scanf("%d %d %d",&r,&k,&n);
 			  ar[9999999]=0;
 			  //printf("enter elements: ");
 			  for(j=0;j<n;j++)
 			  {
 					  scanf("%d",&ar[j]);
 			  }
 			  rolls=calc(r,k,n);
 			  printf("Case #%d: %d\n",i,rolls);
     }
     //getch();
 return 0;
 }
 
 
 int calc( long int r, long int k, long int n)
 {
     int x=0,y=0,euro=0,add=0,add1=0,z=0;
     y=0;
     for(x=0;x<r;x++)
     {
 		    add=0;
 		    add1=ar[y];  //  ++y
 		    z=0;
 		    while(add1<=k)
 		    {
 				  if(++z>n)
 				  break;
 				  add=add1;
 				  y++;
 				  if(y>=n)
 				  y=0;
 				  add1=add1+ar[y];
 		    }
 		    //y--;
 
 		    euro=euro+add;
 
     }
     return euro;
 }
 
 

