#include <stdio.h>
 #define MAXN 3
 int main() {
 int N;
 unsigned long long int t[MAXN];
 int testCase;
 scanf("%d",&testCase);
 unsigned long long i,j,diff;
 for ( i = 1; i <= testCase; i++) {
 scanf("%d",&N);
 printf("Case #%llu: ",i);
 for(j = 0; j < N; j++ ) {
 	scanf("%llu",&t[j]);
 }
 unsigned long long k;
 for ( j = 1; j < N; j++ ) {
  unsigned long long temp = t[j];
  for ( k = j; k > 0; k-- ) {
 	if ( t[k-1] >= t[j] ) {
 		t[k] = t[k-1];
 	}
 	else {
 		break;
 	}
 }
 t[k] = temp;
 }
 diff = -1;
 for ( j = 1; j < N; j++) {
 	if ( diff == -1 ) {
 		diff = t[j] - t[j -1];
 	}
 	else if( diff == 0 || ( diff > t[j] - t[j-1] && (t[j] - t[j-1] ) != 0)) {
 		diff = t[j] - t[j-1];
 	} 
 }
  
 for ( j = diff; j > 0; j--) {
 	int same = 1;
 	int mod = t[0]%j;
 	for ( k = 1; k < N;k++) {
 		if ( t[k] % j != mod ) {
 			same = 0;
 		}
 	}
 	if ( same ) {
 		printf("%llu\n",(j - mod)%j);
 		break;
 	}
 }
 }
 return 0;
 }

