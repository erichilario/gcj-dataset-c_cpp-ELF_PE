#include <stdio.h>
 
 #define MAX_G_QTY 1000
 #define NOINFO (int64)(-1)
 
 typedef long long int64;
 
 int main() {
     int64 t, r, k, n, profit;
     int64 g[MAX_G_QTY];
     int64 jump[MAX_G_QTY];
     int64 cost[MAX_G_QTY];
     int64 i,j,p;
 
     scanf("%lld", &t);
     for(i=1; i<=t; i++) {
 	scanf("%lld %lld %lld", &r, &k, &n);
 	for(j=0; j<n; j++) {
 	    scanf("%lld", &(g[j]));
 	    jump[j] = NOINFO;
 	}
 	for(profit=p=0; r>0; r--) {
 	    if(jump[p] == NOINFO) {
 		    int64 s,jj,nn;
 		    for(s=0,j=jj=p,nn=p+n; jj<nn && s+g[j]<=k; jj++,j=(j+1)%n) {
 			s += g[j];
 		    }
 		    cost[p] = s;
 		    jump[p] = j;
 	    }
 	    //printf("%lld -> %lld = %lld\n", p, jump[p], cost[p]);
 	    profit += cost[p];
 	    p = jump[p];
 	}
 	printf("Case #%lld: %lld\n", i, profit);
     }
     return 0;
 }

