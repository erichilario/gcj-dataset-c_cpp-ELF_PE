#include <stdio.h>
 #include <stdlib.h>
 
 int main(){
     FILE *input = fopen("C-small.in", "r");
     FILE *output = fopen("C-small.out", "w");
 
     int cases;
     fscanf(input, "%d\n",&cases);
     
     int i, j;
     for(i=0;i<cases;i++){
         int R, k, N, money = 0;
         fscanf(input, "%d %d %d\n", &R, &k, &N);
         
         int g[N];
         
         for(j=0;j<N;j++){
             g[j] = 0;
             fscanf(input, "%d", &g[j]);
         }
         fscanf(input, "\n");
         
         int doneRides;
         int pos = 0;
         for(doneRides=0;doneRides<R;doneRides++){
             int groupsOnBoard = 0;
             for(j=0;;pos++){
                 if(pos >= N){
                     pos = 0;
                 }
                 if((j + g[pos]) > k || groupsOnBoard >= N){
                     break;
                 }
                 j += g[pos];
                 groupsOnBoard ++;
             }
             money += j;
         }
         fprintf(output, "Case #%d: %d\n",i+1,money);
     }
     fclose(input);
     fclose(output);
 }
 
 
 

