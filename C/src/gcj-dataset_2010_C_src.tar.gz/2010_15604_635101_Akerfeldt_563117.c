#define _CRT_SECURE_NO_WARNINGS 1
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 typedef struct _dir
 {
 	char name[256];
 	struct _dir *parent;
 	int numChildren;
 	struct _dir *children;
 } Dir;
 
 int dcompare (const void * ina, const void * inb)
 {
 	Dir *tempa, *tempb;
 	
 	tempa = (Dir*)ina;
 	tempb = (Dir*)inb;
 
 	return strcmp(tempa->name,tempb->name);
 }
 
 int main(int argc, char *argv[])
 {
 	char buf[1024], tempbuf[1024], *pch, *tch, *ttch;
 	int i, j, T, N, M, mkdirs;
 	Dir root, *curDir, *temp, key;
 
 	root.name[0] = '\0';
 	root.parent = NULL;
 
 	gets(buf);
 	sscanf(buf, "%d", &T);
 	for(i=0; i<T; i++)
 	{
 		root.numChildren = 0;
 		root.children = NULL;
 
 		gets(buf);
 		sscanf(buf, "%d %d", &N, &M);
 		for(j=0; j<N; j++)
 		{
 			curDir = &root;
 			gets(buf);
 			pch = strtok (buf,"/");
 			while (pch != NULL)
 			{
 				memcpy(tempbuf, buf, 1024);
 				tch = &tempbuf[pch-buf];
 				ttch = strchr(tch,'/');
 				if(ttch != NULL) *ttch = '\0';
 
 				
 				memcpy(key.name, tch, 256);
 				key.parent = curDir;
 				key.numChildren = 0;
 				key.children = NULL;
 				temp = (Dir*)bsearch(tch, curDir->children, curDir->numChildren, sizeof(Dir), dcompare);
 				
 				if(temp != NULL)
 				{
 					curDir = temp;
 				}
 				else
 				{
 					curDir->numChildren++;
 					curDir->children = realloc(curDir->children, sizeof(Dir)*curDir->numChildren);
 					curDir->children[curDir->numChildren-1] = key;
 					qsort (curDir->children, curDir->numChildren, sizeof(Dir), dcompare);
 					temp = (Dir*)bsearch(tch, curDir->children, curDir->numChildren, sizeof(Dir), dcompare);
 					curDir = temp;
 				}
 
 				pch = strtok (NULL, "/");
 			}
 		}
 
 		mkdirs=0;
 		for(j=0; j<M; j++)
 		{
 			curDir = &root;
 			gets(buf);
 			pch = strtok (buf,"/");
 			while (pch != NULL)
 			{
 				memcpy(tempbuf, buf, 1024);
 				tch = &tempbuf[pch-buf];
 				ttch = strchr(tch,'/');
 				if(ttch != NULL) *ttch = '\0';
 
 				
 				memcpy(key.name, tch, 256);
 				key.parent = curDir;
 				key.numChildren = 0;
 				key.children = NULL;
 				temp = (Dir*)bsearch(tch, curDir->children, curDir->numChildren, sizeof(Dir), dcompare);
 				
 				if(temp != NULL)
 				{
 					curDir = temp;
 				}
 				else
 				{
 					mkdirs++;
 					curDir->numChildren++;
 					curDir->children = realloc(curDir->children, sizeof(Dir)*curDir->numChildren);
 					curDir->children[curDir->numChildren-1] = key;
 					qsort (curDir->children, curDir->numChildren, sizeof(Dir), dcompare);
 					temp = (Dir*)bsearch(tch, curDir->children, curDir->numChildren, sizeof(Dir), dcompare);
 					curDir = temp;
 				}
 
 				pch = strtok (NULL, "/");
 			}
 		}
 
 		printf("Case #%d: %d\n",i+1,mkdirs);
 	}
 
 	return 0;
 }
