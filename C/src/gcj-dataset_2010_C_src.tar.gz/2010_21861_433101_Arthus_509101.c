#include<stdio.h>
 #include<stdlib.h>
 struct e{
 	int val;
 	struct e *next;
 };
 typedef struct e *Ele;
 struct data{
 	Ele e;
 	int size;
 };
 typedef struct data *D;
 D create(int n)
 {
 	int c,r,k,i,j;
 	D a;
 	Ele temp,tmp;
 	a = (D)malloc(sizeof(struct data));
 	a->size = n;
 	a->e = NULL;
 	for(j=0;j<n;j++)
 	{
 		scanf("%d",&i);
 		temp = (Ele)malloc(sizeof(struct e));
 		temp->val = i;
 		temp->next = NULL;
 		if(a->e == NULL)
 		{
 			a->e = temp;
 			tmp = temp;
 		}	
 		else
 		{
 			tmp->next = temp;
 			tmp = tmp->next;
 		}
 	}
 	tmp->next = a->e;
 	return a;
 }
 int main()
 {
 	D a;
 	int n,t,r,k,in,count,kt,chek;;
 	Ele temp;
 	scanf("%d",&t);
 	for(in =1;in<=t;in++)
 	{
 		printf("Case #%d: ",in);
 		scanf("%d %d %d",&r,&k,&n);
 		a = create(n);
 		count = 0;
 		temp = a->e;
 		kt = k;
 		chek = 0;
 		while(r>0)
 		{
 
 			if(temp->val > kt || chek>=a->size)
 			{
 				r--;
 				kt = k;
 				chek = 0;
 			}
 			else 
 			{
 				chek++;
 				kt = kt-temp->val;
 				count = count+temp->val;			
 				temp = temp->next;
 			}
 		}	
 		printf("%d\n",count);
 	}return 0;
 }			
 	

