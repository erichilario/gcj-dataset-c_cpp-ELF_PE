#include <stdio.h>
 
 int main(){
 /*
 From the statement we can deduce that the number of times that you have to snapp is equal to:
 		2x+1
 therefore we calculate the sequence for X, where X is equal to 1<=X<=30
 */
 int val[30];
 int T,a;
 int G,H,x;
 int y=0,s;
 for(s=0;s<30;s++){
 y=((2*y)+1);
 val[s]=y;
 }
 
 scanf("%i",&T);
 for(a=0;a<T;a++){
 	scanf("%i %i",&G,&H);
 	if(H<val[G-1]){
 		printf("Case #%i: OFF\n",a+1);
 	} else{
 		if(H%val[G-1]==((int)((H-(H%val[G-1]))/val[G-1]))-1) {
 			printf("Case #%i: ON\n",a+1);
 		} else {
 			printf("Case #%i: OFF\n",a+1);
 		}
 	}
 }
 return 0;
 }

