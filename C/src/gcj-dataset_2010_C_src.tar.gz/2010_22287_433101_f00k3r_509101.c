#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
 	freopen("a.in","r",stdin);
 	FILE* fout = fopen("a.out","w");
 	unsigned int R,k,N;
 	int T,i,j;
 	scanf("%d\n",&T);
 	int g[1000];
 	int pplleft = 0,rounds_left=1,start=0,end;
 	int money = 0,in=0;
 	for(i=0;i<T;i++){
 		scanf("%d %d %d\n",&R,&k,&N);
 		//printf("%d %d %d\n",R,k,N);
 		for(j=0;j<N;j++){
 			scanf("%d",&g[j]);
 			//printf("%d",g[j]);
 		}
 		//printf("\n");
 		g[j] = -1;
 		start = 0;
 		end = N-1;
 		while(rounds_left <= R ){
 			while(k-pplleft >= g[start]){
 				//printf("%d ",g[start]);
 				pplleft += g[start];
 				if(start == end){
 					start = 0;
 					break;
 				}
 				//in++;	
 				start++;
 				if(start >= N)
 					start = 0;	
 			}
 			//printf("\n");
 			money += pplleft;
 			end = start-1 >= 0?start-1:N-1;
 			//printf("Start = %d and End = %d\n",start,end);
 			pplleft = 0;
 			rounds_left++;
 		}
 		rounds_left = 1;
 		pplleft = 0;
 		fprintf(fout,"Case #%d: %d\n",i+1,money);
 		money = 0;
 		in=0;
 	}
 	return 0;
 }

