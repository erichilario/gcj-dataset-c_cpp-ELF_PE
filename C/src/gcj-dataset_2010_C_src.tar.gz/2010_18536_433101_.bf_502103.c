#include <stdio.h>
 #include <stdlib.h>
 
 #define true 1
 #define false 0
 
 #define MAX_N 30
 
 typedef unsigned char bool;
 
 int f[MAX_N+2];
 
 int main()
 {
    int T, cont = 0;
    int i;
 
    f[0] = 1;
    for(i = 1; i <= MAX_N; i++)
       f[i] = 2*(f[i-1]-1)+2;
       
    scanf("%d", &T);
    while(T--)
    {
       int n, k;
       
       scanf("%d %d", &n, &k);
       
       if((k+1) % f[n] == 0)
          printf("Case #%d: ON\n", ++cont);
       else
          printf("Case #%d: OFF\n", ++cont);
    }
    
 return 0;
 }

