#include <stdio.h>
 #define MAXN 10
 int main() {
 int testCase;
 unsigned long long N, K;
 int a[MAXN],i;
 a[0] = 1;
 for ( i = 1; i < MAXN; i++ ) {
 	int ans = a[i - 1];
 	a[i] = ans | (ans << 1 );
 }
 scanf("%d",&testCase);
 for( i = 1; i <= testCase; i++ ) {
 	scanf("%llu %llu",&N,&K);
 	printf("Case #%d: ",i);
 	if ( K ) 
 	printf("%s\n",((K % (a[N - 1] + 1)) == a[N-1] ) ? "ON":"OFF");
 	else 
 	printf("OFF\n");
 }  
 
 return 0;
 }
 
 	
 	

