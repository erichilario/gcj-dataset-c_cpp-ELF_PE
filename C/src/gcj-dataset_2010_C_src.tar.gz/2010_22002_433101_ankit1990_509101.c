#include<stdio.h>
 int main()
 {
  int i ;
  int j ;
 
  int n ;
  int k ;
  int l  [ 1000 ] ;
  int l1 [ 1000 ] ;
  int l2 [ 1000 ] ;
  long long int Money = 0 ;
  int r ;
  int t ;
  int beg = 0 ;
  int total ;
  scanf("%d",&t);
  int p = 0  ;
  while( t > 0 ) 
  {
   t-- ;
   Money = 0 ;
   beg = 0 ; 
   scanf("%d %d %d", &r , &k , &n ) ;
   for( i = 0 ; i < n ; i++ ) 
   {
    scanf("%d",&l[i] ) ;
   }
 
   for( i = 0 ; i < n ; i++ )
   {
    total = 0 ;
    for( j = 0 ; j < n ; j++ ) 
    {
     if( l[(i+j)%n] + total <= k ) 
     {
      total = l[ (i+j)%n ] + total ;
     }
     else
     {
      break ; 
     }
    } 
    l1[i] = total ;
    l2[i] = (i+j)%n ;
   }
   beg = 0 ;
   for( i = 0 ; i < r ; i++ ) 
   {
    Money = Money + l1[ beg ] ;  
    beg = l2[ beg ] ;
   }
   p++ ;
   printf("Case #%d: %lld\n", p ,  Money ) ; 
  }
 } 

