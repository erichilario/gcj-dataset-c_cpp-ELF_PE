#include<math.h>
 #include<stdio.h>
 
 main ()
 {
      FILE *fpi,*fpo;
      int T, casen=0;
      long int R,k,N,g[1000],euro=0,rn=1,nn=0,kn=0,i=0,c=1;
     // clrscr();
      fpi=fopen("C:\A-large.IN","r");
      fpo=fopen("C:\A-large.out","w");
      fscanf(fpi,"%d",&T);
      while(++casen <=T)
      {
                    fscanf(fpi,"%ld %ld %ld",&R,&k,&N);
                    printf("%ld %ld %ld\n",R,k,N);
                    
                    while(nn<N)
                    {
                    fscanf(fpi,"%ld",&g[nn]);
                    printf("N=%d\tnn=%d\tg[nn]=%ld\n",N,nn,g[nn]);
                    nn++;
                    }
                    
                    while(rn++<=R)
                    {
                         while(((kn+g[i])<=k) && (c++ <=N) )
                         {
                         kn=kn+g[i++];
                         if(i==N) i=0;            
                         }       
                    euro=euro+kn;
                    kn=0;  
                    c=1;                             
                    }
                    
      printf("Case #%d: %ld\n",casen,euro);
      fprintf(fpo,"Case #%d: %ld\n",casen,euro);
      euro=0;
      rn=1;
      nn=0;
      i=0;
      c=1;
      }
    getch();  
 }

