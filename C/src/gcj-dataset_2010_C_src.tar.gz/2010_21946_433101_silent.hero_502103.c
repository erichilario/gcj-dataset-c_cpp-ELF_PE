#include<stdio.h>
 #include<conio.h>
 main()
 {FILE *fp,*fout;
 long n,k,i,j,a,sum=1,b;
 int flag=1;
 fp=fopen("D:\\TC\\dash.in","r");
 fout=fopen("D:\\TC\\dash.out","w");
 fscanf(fp,"%ld",&i);
 for(j=0;j<i;j++)
 {fscanf(fp,"%ld",&n);
  fscanf(fp,"%ld",&k);
  sum=1;
  flag=1;
  for(a=0;a<n;a++)
   {sum=sum*2;
   }
  b=k/sum+1;
  for(a=1;a<=b;a++)
   {if(k==sum*a-1){flag=0;fprintf(fout,"Case #%d: ON\n",j+1);}
   }
  if(flag==1)fprintf(fout,"Case #%d: OFF\n",j+1);
 }
 
 }
