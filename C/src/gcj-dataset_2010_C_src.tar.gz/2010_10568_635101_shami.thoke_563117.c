#include <iostream>
 #include <vector>
 #include <set>
 #include <map>
 #include <string>
 using namespace std;
 
 char a[1024];
 multimap<string,string> mp;
 
 void createMap(string s)
 {
   size_t end = s.size() -1;
   size_t pos = s.rfind("/"); 
   string n, p;
   while(pos != string::npos) {
     n = ""; p = "";
     n = s.substr(pos+1, end - pos);
     p = s.substr(0, pos);
     if(pos == 0) 
       break;
     mp.insert(pair<string, string>(n,p));
     end = pos - 1;
     pos = s.rfind("/", end);
   }
   mp.insert(pair<string, string>(n, "/"));
 }
 
 long long getNum(string s)
 {
   long long cnt = 0;
   size_t end = s.size() -1;
   size_t pos = s.rfind("/");
   string n, p;
   while(pos != string::npos) {
     n = ""; p = "";
     n = s.substr(pos+1, end - pos);
     p = s.substr(0, pos);
     if(pos == 0) 
       break;
     multimap<string, string>::iterator ii = mp.find(n); 
     if(ii == mp.end()) {
       ++cnt;
       mp.insert(pair<string, string>(n,p));
       end = pos - 1;
       pos = s.rfind("/", end);
       continue;
     }
     multimap<string, string>::iterator il, ih;
     il = mp.lower_bound(n);
     ih = mp.upper_bound(n);
     bool found = false;
     for(; il != ih; ++il) {
       if(il->second == p) {
         // found the parent 
         found = true;
         break;
       }
     }
     if(found) 
       return cnt;
     ++cnt;
     mp.insert(pair<string, string>(n,p));
     end = pos - 1;
     pos = s.rfind("/", end);
   } 
   
   multimap<string, string>::iterator ii = mp.find(n); 
   if(ii == mp.end()) {
     ++cnt;
     mp.insert(pair<string, string>(n, "/"));
   }
   else { 
     multimap<string, string>::iterator il, ih;
     il = mp.lower_bound(n);
     ih = mp.upper_bound(n);
     bool found = false;
     for(; il != ih; ++il) {
       if(il->second == "/") {
         // found the parent 
         found = true;
         break;
       }
     }
     if(!found) {
       ++cnt;
       mp.insert(pair<string, string>(n, "/"));
     }
   }
   return cnt;
 }
 
 int main(int argc, char* argv[])
 {
   if(argc != 2) {
     cout << "Usage: ./a.out <input_file>" << endl;
     exit(0);
   }
   FILE* fp = fopen (argv[1], "r");
   if(fp == NULL) {
     cout << "Can't open file " << argv[1] << " for read operation" << endl;
     exit(0);
   }
   int T;
   fscanf (fp, "%d", &T);
   for(int tc = 1; tc <= T; ++tc) {
     mp.clear();
     int N, M;
     fscanf (fp, "%d", &N);
     fscanf (fp, "%d", &M);
     bzero(a, 1024);
     for(int i = 0; i < N; ++i) {
       fscanf (fp, "%s", a);
       string s(a);
       createMap(s);
     }
     bzero(a, 1024);
     long long count = 0;
     for(int j = 0; j < M; ++j) {
       fscanf (fp, "%s", a);
       string s(a);
       count += getNum(s);
     }
     cout << "Case #" << tc << ": " << count << endl;
   }
 }

