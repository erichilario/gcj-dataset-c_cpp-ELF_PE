#include <stdio.h>
 
 unsigned int fibonacci(unsigned int n){
 	unsigned int a = 1, b = 1,i,sum;
 	if(n<3) return 1;
 	for(i = 3; i <=n; i++){
 		sum = a + b;
 		a = b%100003;
 		b = sum%100003;
 	}
 	return sum;
 }
 
 int main(int argc, char *argv[]) {
 	int t, i, n;
 	scanf("%d", &t);
 	for (i = 1; i <= t; i++) {
 		scanf("%d", &n);
 		printf("Case #%d: %u\n", i, fibonacci(n));
 	}	
 	return 0;
 }

