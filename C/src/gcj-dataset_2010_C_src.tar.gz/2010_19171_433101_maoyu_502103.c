#include<stdio.h>
 #include<string.h>
 int ans[31]={0,1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535,131071,262143,524287,1048575,2097151,4194303,8388607,16777215,33554431,67108863,134217727,268435455,536870911,1073741823};
 
 int main()
 {
     freopen("001.in","r",stdin);
     freopen("001.out","w",stdout);
 
     int t,n,k;
     int i,j;
     scanf("%d",&t);
     for (i=1;i<=t;i++)
     {
         scanf("%d%d",&n,&k);
         k=k-ans[n];
         if (k==0) printf("Case #%d: ON\n",i);
         else 
         {
             if (k%(ans[n]+1)==0) printf("Case #%d: ON\n",i);
             else printf("Case #%d: OFF\n",i);
         }
     }
     return 0;
 }

