#include <string.h>
 #include "bn.h"
 
 
 int bn_mov_str_hex(BIGNUM *a, const char *str)
 {
 	int p, i, len, k, j;
 	BN_UCHAR c;
 	char t[BN_UCHAR_L / 4 + 1];
 	BN_ZERO(a);
 	len = strlen(str);
 	k = BN_UCHAR_L / 4;
 	
 	a->len = 0;
 	for(i = len - 1; i >= 0; i-=k)
 	{
 		for(j = 0; j < k; j++)
 		{
 			t[j] = i - k + j + 1 >=0 ? str[i - k + j + 1] : '0';
 		}
 		t[k] = 0;
 		//c = atoi(t);
 		sscanf(t, "%X", &c);
 		a->v[a->len++] = c;
 	}
 	
 	return 0;
 }
 
 int bn_mov_str_dec(BIGNUM *a, const char *str)
 {
 	int i, k;
 	int len = strlen(str);
 	BIGNUM p, sum, t;
 	BN_ONE((&p));
 	BN_ZERO(a);
 	for(i = len - 1; i >= 0; i--)
 	{
 		k = str[i] - '0';
 		bn_umul2(&t, &p, k);
 		bn_uadd(&sum, a, &t);
 		bn_mov_bn(a, &sum);
 
 		bn_umul2(&t, &p, 10);
 		bn_mov_bn(&p, &t);
 	}
 	return 0;
 }
 
 int bn_mov_uint(BIGNUM *a, const BN_UINT b)
 {
 	int n = BN_UINT_L / BN_UCHAR_L;
 
 	BN_ZERO(a);
 	
 	a->len = 0;	
 
 	while(n--)
 	{
 		a->v[n] = (b>>(BN_UCHAR_L * n)) & BN_UCHAR_M;
 	}
 
 	while(a->v[a->len]) a->len++;
 	if(a->len == 0) a->len = 1;
 
 	return 0;
 }
 
 
 //a = b;
 int bn_mov_bn(BIGNUM *a, const BIGNUM *b)
 {
 	BN_COPY(a, b);
 	BN_FIX(a);
 	return 0;
 }
 
 //a = sub(b);
 int bn_mov_sub(BIGNUM *a, const BIGNUM *b, const BN_UINT start, const BN_UINT end)
 {
 	int i;
 	for(i = start; i <= end && i >= 0; i++)
 	{
 		a->v[i - start] = b->v[i];
 	}
 	a->len = i - start + 1;
 	return 0;
 }
 
 //sign(a - b)
 int bn_ucmp(const BIGNUM *a, const BIGNUM *b)
 {
 	int i;
 	if(a->len > b->len) return 1;
 	if(a->len < b->len) return -1;
 
 	for(i = a->len - 1; i >=0; i--)
 	{
 		if(a->v[i] > b->v[i]) return 1;
 		if(a->v[i] < b->v[i]) return -1;
 	}
 	
 	return 0;
 }
 
 //show as hex format
 char* bn_str_hex(const BIGNUM *a)
 {
 	static char str[MAX_HEX_LEN];
 	char t[4];
 	int i;
 
 	strcpy(str, "");
 	for(i = a->len - 1; i >= 0; i--)
 	{
 		sprintf(t, "%02X", a->v[i]);
 		strcat(str, t);
 	}
 	
 	return str;
 }
 
 //show as dec format
 char* bn_str_dec(const BIGNUM *a)
 {
 	static char str[MAX_DEC_LEN];
 	char t;
 	int i, j;
 	BN_UCHAR k;
 	BIGNUM b, q, r1, r2;
 
 	if(bn_iszero(a))
 	{
 		str[0] = '0';
 		str[1] = 0;
 		return str;
 	}
 
 	strcpy(str, "");
 
 	i = 0;
 	bn_mov_bn(&b, a);
 	while(!bn_iszero(&b) && MAX_DEC_LEN > i)
 	{
 		bn_udiv2(&q, &k, &b, 10);
 		str[i++] = k + '0';
 		
 
 		bn_umul2(&r1, &q, 10);
 		bn_uadd2(&r2, &r1, k);
 		if(bn_ucmp(&b, &r2) != 0)
 		{
 			printf("rc=%X b=%s\n", k, bn_str_hex(&b));
 			printf("rr=%s\n", k, bn_str_hex(&r2));							
 		}
 
 		bn_mov_bn(&b, &q);
 	}
 	
 	for(j = 0; j <= i / 2; j++)
 	{
 		t = str[j];
 		str[j] = str[i - j - 1];
 		str[i - j - 1] = t;
 	}
 	str[i] = 0;
 
 	return str;
 }
 
 //is a zero?
 int bn_iszero(const BIGNUM *a)
 {
 	int i;
 	if(a->len <= 0 || a->len > MAX_D_LEN) return 1;
 	for(i = a->len - 1; i >= 0; i--)
 	{
 		if(a->v[i]) return 0;
 	}
 	return 1;
 }
 
 //c = a + b;
 int bn_uadd(BIGNUM *c, const BIGNUM *a, const BIGNUM *b)
 {
 	BN_UINT s;
 	int c_len = a->len > b->len ? a->len : b->len;
 	int carry = 0;
 	int i;
 	
 	c->len = 0;
 	for(i = 0; i < c_len; i++)
 	{
 		s = carry;
 		if(i < b->len) s +=  b->v[i];
 		if(i < a->len) s +=  a->v[i];
 		
 		c->v[c->len++] = s & BN_UCHAR_M;		
 		carry = s >> BN_UCHAR_L;
 	}
 	
 	if(carry && c->len < MAX_D_LEN)
 	{		
 		c->v[c->len++] = carry;
 	}		
 
 	return 0;
 }
 
 int bn_uadd2(BIGNUM *c, const BIGNUM *a, const BN_UCHAR b)
 {
 	int i;
 	BN_UINT s;
 	BN_UCHAR carry;
 
 	if(bn_iszero(a))
 	{
 		bn_mov_uint(c, b);
 		return 0;
 	}
 
 	bn_mov_bn(c, a);
 
 	s = c->v[0] + b;
 	carry = (s>>BN_UCHAR_L) & BN_UCHAR_M;
 	c->v[0] = (s & BN_UCHAR_M);
 	for(i = 1; i < c->len; i++)
 	{
 		s = c->v[i] + carry;
 		carry = (s>>BN_UCHAR_L) & BN_UCHAR_M;
 		c->v[i] = (s & BN_UCHAR_M);
 	}
 
 	if(carry)
 	{
 		c->v[c->len++] = carry;
 	}
 
 	return 0;
 }
 
 //c = a - b; a must larger than b.
 int bn_usub(BIGNUM *c, const BIGNUM *a, const BIGNUM *b)
 {
 	int i;
 	BN_UINT s;
 	int carry = 0;
 	
 	c->len = 0;
 	for(i = 0; i < a->len; i++)
 	{
 		s = a->v[i];
 		if(carry) s--;		
 		carry = 0;
 
 		if(s < b->v[i]) s += (BN_UCHAR_M+1);
 		carry = s >> BN_UCHAR_L;
 
 		if(i < b->len) s = s - b->v[i];
 		c->v[c->len++] = s;
 	}
 
 	BN_FIX(c);
 
 	return 0;
 }
 
 //c = a * b;
 int bn_umul(BIGNUM *c, const BIGNUM *a, const BIGNUM *b)
 {
 	int i, j;
 	int m, n;
 	BN_UCHAR carry;	
 	BN_UINT s;
 
 	m = a->len;
 	n = b->len;
 		
 	c->len = m + n;
 	for(i = 0; i < m; i++)
 	{
 		c->v[i] = 0;
 	}
 	
 	for(j = 0; j < n; j++)
 	{
 		if(b->v[j] == 0)
 		{
 			c->v[j+m] = 0;
 		} else {
 			carry = 0;
 			for(i = 0; i < m; i++)
 			{
 				s = a->v[i] * b->v[j] + carry + c->v[i+j];
 				c->v[i+j] = s & BN_UCHAR_M;
 				carry = (s >> BN_UCHAR_L) & BN_UCHAR_M;
 			}
 			c->v[j+m] = carry;
 		}
 	}
 	
 	BN_FIX(c);
 
 	return 0;
 }
 
 //c = a * b;
 int bn_umul2(BIGNUM *c, const BIGNUM *a, const BN_UCHAR b)
 {
 	int i, carry;
 	BN_UINT s;
 	carry = 0;
 	for(i = 0; i < a->len; i++)
 	{
 		s = b * a->v[i] + carry;
 		carry = (s>>BN_UCHAR_L) & BN_UCHAR_M;
 		c->v[i] = s & BN_UCHAR_M;
 	}
 	c->len = a->len;
 	if(carry)
 	{
 		c->v[i] = carry;
 		c->len++;
 	}
 	return 0;
 }
 //a = b * q + r
 int bn_udiv2(BIGNUM *q, BN_UCHAR *r, const BIGNUM *a, const BN_UCHAR b)
 {
 	int i, p;
 	int carry;
 	BN_UINT s;
 
 	if(bn_iszero(a))//a==0
 	{
 		*r = 0;
 		BN_ZERO(q);
 		return 0;
 	}
 
 	if(a->len == 1 && a->v[0] == b)//a==b
 	{
 		*r = 0;
 		BN_ONE(q);
 		return 0;
 	}
 
 	if(a->len == 1 && a->v[0] < b)
 	{
 		*r = a->v[0];
 		BN_ZERO(q);
 		return 0;
 	}
 
 	carry = 0;
 	q->len = a->len;
 
 	for(i = a->len - 1; i >= 0; i--)
 	{
 		s = (carry << BN_UCHAR_L) | a->v[i];
 		q->v[i] = s / b;
 		carry = s % b;
 	}
 	*r = carry;
 	BN_FIX(q);
 	return 0;
 }
 //do a=q*b+r
 //set d makes a*d=q*(b*d) + (r*d); maybe d=(L/2)
 //set r=(a*d);
 //set i = m+n, j=m
 int bn_udiv(BIGNUM *q, BIGNUM *r, const BIGNUM *a, const BIGNUM *b)
 {
 	int i, j, d, h, k, m, n;
 	BIGNUM aa, bb, rr, br, bq;
 	BN_UINT s, bi, re, qq;
 	BN_UCHAR t;
 	int left, right, mid;
 
 	k = bn_ucmp(a, b);
 	//b == 0;
 	if(bn_iszero(b)) 
 	{
 		BN_ZERO(r);
 		BN_ZERO(q);
 		return 1;
 	}
 
 	if(k == 0)//a==b,q=1,r=0
 	{
 		BN_ZERO(r);
 		BN_ONE(q);
 		return 0;
 	} else if(k < 0)//a<b,q=0,r=b
 	{
 		bn_mov_bn(r, a);
 		BN_ZERO(q);
 		return 0;
 	}
 
 	if(b->len == 1)
 	{
 		bn_udiv2(q, &t, a, b->v[0]);
 		r->len = 1;
 		r->v[0] = t;
 		return 0;
 	}
 	
 	h = a->len - 1;
 	k = b->len - 1;
 	for(j = 0; j <= h - k; j++)
 	{
 		q->v[j] = 0;
 	}
 	q->len = h - k + 1;
 
 
 	n = b->len;
 	m = a->len - b->len;
 	bi = BN_UCHAR_M + 1;
 	if(BN_UCHAR_M & (b->v[n - 1]>>(BN_UCHAR_L/2)))
 	{
 		d = 0;
 	} else {
 		d = BN_UCHAR_L/2;
 	}
 	bn_mov_bn(&aa, a);
 	bn_mov_bn(&bb, b);
 	bn_shift_l(&aa, d);
 	bn_shift_l(&bb, d);
 	if(aa.len == a->len) aa.v[m+n]=0;
 	bb.v[n] = 0;
 	for(j = m; j >=0; j--)
 	{
 		s = (aa.v[j+n]<<BN_UCHAR_L)|aa.v[j+n-1];
 		
 		qq = s / bb.v[n-1];
 		re = s % bb.v[n-1];
 		qq = qq < BN_UCHAR_M ? qq : BN_UCHAR_M;
 
 		while(qq * bb.v[n-2] > ((re<<BN_UCHAR_L)|aa.v[j+n-2]))
 		{
 			qq--;			
 			if(re>=bi)
 			{
 				break;
 			}
 			re+=bb.v[n-1];
 		}
 
 		bn_mov_sub(&br, &aa, j, j+n);		
 		bn_umul2(&rr, &bb, qq);		
 		
 		if(bn_ucmp(&br, &rr) < 0)
 		{			
 			qq--;
 			bn_umul2(&rr, &bb, qq);			
 		}
 		bn_usub(&bq, &br, &rr);
 		
 		for(i = bq.len; i <= n; i++)
 		{
 			bq.v[i] = 0;
 		}
 		for(i = 0; i <= n; i++)
 		{
 			aa.v[i + j] = bq.v[i];
 		}
 		q->v[j] = qq;
 			
 	}
 	q->len = m+1;
 	BN_FIX(q);
 	
 	//bn_mov_sub(&rr, &aa, 0, n-1);
 	bn_mov_bn(&rr, &aa);
 	bn_shift_r(&rr, d);
 	bn_mov_bn(r, &rr);
 	BN_FIX(r);
 /*
 	bn_mov_sub(&rr, &aa, aa.len - bb.len, aa.len+1);
 	
 	printf("Loop:%d %d %d\n", aa.len, bb.len, d);
 	printf("aa:%s\n", bn_str_dec(&aa));
 	
 	for(i = aa.len - bb.len; i >= 0; i--)
 	{	
 		printf("rr:%s ", BN_FORMAT(&rr));
 		printf("bb:%s\n", BN_FORMAT(&bb));
 		k = bn_ucmp(&rr, &bb); 
 		if(k < 0)
 		{
 			qq = 0;
 		} else if(k == 0) {
 			qq = 1;
 		} else {
 			s = (rr.v[rr.len-1]<<BN_UCHAR_L)|rr.v[rr.len-2];
 			t = s / bb.v[bb.len - 1];
 			qq = BN_UCHAR_M - 1 < t ? BN_UCHAR_M - 1 : t;
 			while(qq * bb.v[bb.len - 2] >= (((s - qq * bb.v[bb.len - 1]) << BN_UCHAR_L) | rr.v[rr.len - 2]))
 			{
 				qq--;
 			}
 		}
 		bn_umul2(&bq, &bb, qq);
 		if(bn_ucmp(&rr, &bq) < 0)
 		{
 			qq--;
 			bn_umul2(&bq, &bb, qq);
 		}
 		q->v[i] = qq;
 		bn_usub(&br, &rr, &bq);
 		bn_mov_bn(&rr, &br);		
 		if(i - 1 >= 0){
 			bn_shift_l(&rr, BN_UCHAR_L);
 			rr.v[0] = aa.v[i-1];			
 		}
 		printf("bq:%s %d\n", BN_FORMAT(&bq), qq);
 	}
 	printf("rr:%s\n", BN_FORMAT(&rr));
 	q->len = a->len - b->len + 1;
 	BN_FIX(q);
 	
 	bn_shift_r(&rr, d);
 	bn_mov_bn(r, &rr);
 	BN_FIX(r);
 	*/
 	
 	return 0;
 }
 
 
 BN_UCHAR bn_get_bit(BIGNUM *c, const BN_UINT p)
 {
 	BN_UCHAR r;
 	int words,bytes;
 	words = p / BN_UCHAR_L;
 	bytes = p % BN_UCHAR_L;
 	if(p < MAX_D_LEN)
 	{
 		r = ((c->v[words])>>bytes) & 0x01;
 	} else {
 		r = -1;
 	}
 
 	return r;
 }
 
 //c<<l
 int bn_shift_l(BIGNUM *c, const BN_UINT l)
 {
 	int i;
 	int words, bits;
 	BN_UCHAR hig,low;
 	BN_UINT s;
 	words = l / BN_UCHAR_L;
 	bits = l % BN_UCHAR_L;
 
 	if(words >= MAX_D_LEN)
 	{
 		BN_ZERO(c);
 		return 0;
 	}
 
 	for(i = 0; i <= words && i + c->len < MAX_D_LEN; i++)
 	{
 		c->v[i + c->len] = 0;
 	}
 
 	for(i = c->len - 1; i >= 0; i--)
 	{
 		s = c->v[i];
 		s <<= bits;
 		hig = (s >> BN_UCHAR_L) & BN_UCHAR_M;
 		low = (s) & BN_UCHAR_M;
 		
 		if(words) c->v[i] = 0;
 		else c->v[i] <<= bits;
 
 		if(i + words + 1 < MAX_D_LEN)//set hig to i + words + 1
 		{
 			c->v[i + words + 1] |= hig;
 		}
 
 		c->v[i + words] |= low;
 
 	}
 	
 	for(i = 0; i < words; i++)
 	{
 		c->v[i] = 0;
 	}
 
 	c->v[words] &= ~(BN_UCHAR_M>>(BN_UCHAR_L-bits));
 
 	
 	c->len += words;
 	if(bits) c->len++;
 	if(c->len > MAX_D_LEN) c->len = MAX_D_LEN;
 	BN_FIX(c);
 
 	return 0;
 }
 
 //c>>r
 int bn_shift_r(BIGNUM *c, const BN_UINT r)
 {
 	int i;
 	int words, bits;
 	BN_UCHAR hig,low;
 	BN_UINT s;
 	words = r / BN_UCHAR_L;
 	bits = r % BN_UCHAR_L;
 
 	if(words >= MAX_D_LEN || c->len <= words)
 	{
 		BN_ZERO(c);
 		return 0;
 	}
 	
 	for(i = 0; i < words; i++)
 	{
 		c->v[i] = 0;
 	}
 
 	c->v[words] &= ~(BN_UCHAR_M>>(BN_UCHAR_L-bits));
 	
 	
 	for(i = words; i < c->len; i++)
 	{
 		s = c->v[i] << BN_UCHAR_L;
 		s >>= bits;
 		hig = (s >> BN_UCHAR_L) & BN_UCHAR_M;
 		low = (s & BN_UCHAR_M);
 		
 		if(words) c->v[i] = 0;
 		else c->v[i] >>= bits;
 
 		if(i - words - 1 >= 0)//set low to i - words - 1
 		{
 			c->v[i - words - 1] |= low;
 		}
 
 		c->v[i - words] |= hig;
 	}
 
 	for(i = 0; i < words; i++)
 	{
 		c->v[c->len - 1 - i] = 0;
 	}
 
 	c->v[c->len - words - 1] &= BN_UCHAR_M>>bits;
 	
 	c->len -= words;
 
 	BN_FIX(c);
 
 	return 0;
 }
