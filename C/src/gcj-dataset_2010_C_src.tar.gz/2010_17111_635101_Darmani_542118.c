#include<stdio.h>
 #include<stdlib.h>
 
 int x[50];
 int v[50];
 
 int dp[51][51];
 int minsw[50];
 
 int timeto(int x, int v, int b)
 {
   return (b-x+v-1)/v;
 }
 
 int main()
 {
   int C;
   scanf("%d",&C);
 
   for(int times =1; times <= C; times++)
     {
       int N,K,B,T;
       scanf("%d %d %d %d",&N,&K,&B,&T);
 
       for(int i = 0; i < N; i++)
 	scanf("%d",&x[i]);
       for(int i = 0; i < N; i++)
 	scanf("%d",&v[i]);
       
       for(int i = 0; i < 51; i++)
 	{
 	  for(int j =0; j < 51; j++)
 	    dp[i][j] = -1;
 
 	}
       
       dp[N-1][1] = timeto(x[N-1],v[N-1],B) <= T? 0 : -1;
       if(dp[N-1][1]>=0)
 	minsw[N-1] = 0;
       else
 	minsw[N-1] = -1;
 
       dp[N-1][0] = 0;
 
 
       for(int i = N-2; i >= 0; i--)
 	{
 	  minsw[i] = 500000;
 	  int sw = 0;
 	  for(int k = i+1; k < N; k++)
 	    {
 	      if(v[k] >= v[i])
 		continue;
 
 	      int cross = timeto(x[i],v[i]-v[k],x[k]);
 
 	      if(x[i]+v[i]*cross>=B)
 		continue;
 	     
 	      if(timeto(x[i],v[i],B) > T)
 		continue;
 
 	      if(cross+timeto(x[i]+v[i]*cross,v[k],B)<=T)
 		{
 		  if(minsw[k]>= 0 && sw+minsw[k]<minsw[i])
 		    minsw[i] = sw+minsw[k];
 		}
 	      sw++;
 	    }
 	  
 	  if(timeto(x[i],v[i],B) <= T && sw<minsw[i])
 		minsw[i] = sw;
 
 	  if(sw==0)
 	    {
 	      if(timeto(x[i],v[i],B) <= T)
 		minsw[i] = 0;
 	    }
 
 
 	  if(minsw[i] == 500000)
 	    minsw[i] = -1;
 
 
 	  for(int j = 0; N-i>=j; j++)
 	    {
 	      if(j==0)
 		{
 		  dp[i][j] = 0;
 		  continue;
 		}
 
 	      if(dp[i+1][j-1]==-1 &&dp[i+1][j] ==-1)
 		continue;
 	      else if(dp[i+1][j] ==-1 && dp[i+1][j-1] != -1)
 		{
 		  if(minsw[i] >= 0)
 		    dp[i][j] = dp[i+1][j-1]+minsw[i];
 		}
 	      else
 		{
 		  if(minsw[i]>=0)
 		    {
 		      int a = dp[i+1][j];
 		      int b = dp[i+1][j-1]+minsw[i];
 		      dp[i][j] = a < b ? a : b;
 		    }
 		  else
 		    dp[i][j] = dp[i+1][j];
 		}
 	    }
 	}
 
       for(int i = 0; i < 49; i++)
 	{
 	  if(dp[0][i+1]<dp[0][i] && dp[0][i+1]>=0)
 	    {
 	      printf("%d %d %d\n",i,dp[0][i],dp[0][i+1]);
 	      return 1/0;
 	    }
 	}
 
       if(dp[0][K] >= 0)
 	{
 	  printf("Case #%d: %d\n",times, dp[0][K]);
 	}
       else
 	{
 	  printf("Case #%d: IMPOSSIBLE\n",times);
 	}
 	  
     }
 
   return 0;
 }

