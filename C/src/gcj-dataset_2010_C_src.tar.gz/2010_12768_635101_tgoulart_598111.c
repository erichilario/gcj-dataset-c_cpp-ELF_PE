#include <stdio.h>
 #include <string.h>
 
 #define MOD 100003
 
 int main() {
 	int t, caso = 1;
 	int n, i, fib[505];
 	
 	fib[0] = 0;
 	fib[1] = 1;
 	for (i=2; i <= 500; i++) {
 		fib[i] = (fib[i-1] + fib[i-2]) % MOD;
 	}
 	
 	scanf("%d",&t);
 	while (t--) {
 		scanf("%d",&n);
 		
 		printf("Case #%d: %d\n",caso++,fib[n]);
 	}
 	
 	return 0;
 }

