/* KRIOZERO */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <unistd.h>
 
 #define OFF 0
 #define ONN 2
 #define ONP 3
 
 long long int exponente2(int x){
 	int i;
 	long long int valor=2;
 	for(i=1;i!=x;i++){
 		valor *= 2;
 	}
 	return valor;
 }
 
 int main(int argc, char **argv){
 	int i,j,g;
 	int cases,rcases;
 	int rondas,psj,ngrp,psjgrp;
 	FILE *fd,*outfd;
 	char lin[40];
 	char outlin[40];
 	char lin2[8000];
 	int grupo[1002];
 	char *num;
 	int nper,euros,llena;
 	
 	for(i=0;i!=1002;i++){
 		grupo[i]=0;
 	}
 
 	printf("+Fichero OUT: %s\n",argv[2]);
 	outfd = fopen(argv[2],"w");
 
 	printf("+Fichero IN: %s\n\n",argv[1]);
 	fd = fopen(argv[1],"r");
 
 	fgets(lin,39,fd);
 	sscanf(lin,"%d",&cases);//fprintf(stderr,"%d\n",cases);
 
 	rcases = cases;
 	for(;cases!=0;--cases){
 		fgets(lin,70,fd);
 		sscanf(lin,"%d %d %d",&rondas,&psj,&ngrp);
 		//fprintf(stderr,"R:%d psj:%d ngrp:%d\ng:",rondas,psj,ngrp);
 		fgets(lin2,8000,fd);
 		for(i=0;i!=ngrp;i++){
 			if(i==0){
 				grupo[i] = atoi(strtok(lin2," "));
 				//fprintf(stderr,"%d ",grupo[i]);
 			}else{
 				if((num = strtok(NULL," "))!=NULL){
 					grupo[i] = atoi(num);
 					//fprintf(stderr,"%d ",grupo[i]);
 				}
 			}
 		}
 		//fprintf(stderr,"\n---------\n");
 		//for(i=0;i!=ngrp;i++)fprintf(stderr,"%d ",grupo[i%ngrp]);	
 		//fprintf(stderr,"\n---------\n");
 		
 		i=euros=0;
 		for(j=rondas;j!=0;j--){
 			llena=nper=g=0;
 			while(llena==0){
 				if((nper + grupo[i%ngrp])<=psj && g<ngrp){
 					nper += grupo[i%ngrp];
 					//fprintf(stderr,"%d ",grupo[i%ngrp]);
 					++i;
 				} else {
 					llena = 1;
 					euros += nper;
 					//fprintf(stderr,"\n");
 				}
 				++g;
 			}
 		}
 		fprintf(stderr,"Case #%d: %d\n",rcases-cases+1,euros);
 		fprintf(outfd,"Case #%d: %d\n",rcases-cases+1,euros);
 	}
 	
 	fclose(fd);
 	fclose(outfd);
 	return 0;
 }

