#include <stdio.h>
 
 int C[101][101];
 int A[101];
 int N, I, D, M;
 
 int cost(int k, int l)
 {
   if ( k >= N - 1 || l >= N )
     return 0;
   if ( C[k][l] >= 0 )
     return C[k][l];
   int d = abs(A[l] - A[k]);
   if ( d <= M )
     return cost(l, l + 1);
   /* delete A[l] */
   int c1 = D + cost(k, l + 1);
   int ck = cost(l, l + 1);
   /* delete A[k] */
   int c4 = D + ck;
   /* insert bw A[k] and A[l] */
   int p, c2 = c1;
   if ( M > 0 )
   {
     if ( d % M == 0 )
       p = d/M - 1;
     else
       p = d/M;
     c2 = p*I + ck;
   }
   /* change value */
   int c3 = d - M;
   if ( c3 > D + I )
     c3 = D + I;
   c3 += ck;
   int c = c1;
   if ( c > c2 )
     c = c2;
   if ( c > c3 )
     c = c3;
   if ( c > c4 )
     c = c4;
   /* now mixed changing value/insert */
   if ( M > 0 )
   for ( p=1; p<d/M + 1; ++p )
   {
     int cp = p*I;
     if ( A[l] > A[k] )
       cp += abs(A[l] - (p + 1)*M);
     else
       cp += abs(A[k] - (p + 1)*M);
     cp += ck;
     if ( cp < c )
       c = cp;
   }
   C[k][l] = c;
   return c;
 }
 
 int f_cost()
 {
   int k;
   for ( k=0; k<N; ++k )
   {
     int l;
     for ( l=0; l<N; ++l )
       C[k][l] = -1;
   }
   return cost(0, 1);
 }
 
 void read()
 {
   scanf("%d %d %d %d", &D, &I, &M, &N);
   int k;
   for ( k=0; k<N; ++k )
     scanf("%d", A + k);
 }
 
 int main()
 {
   int T, t;
   scanf("%d", &T);
   for ( t=1; t<=T; ++t )
   {
     read();
     printf("Case #%d: %d\n", t, f_cost());
   }
   return 0;
 }

