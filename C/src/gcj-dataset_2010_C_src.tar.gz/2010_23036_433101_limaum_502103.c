#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct snapper_t snapper;
 
 typedef struct snapper_t
 {
 
 	int swtch;
 	int energy;
 	int light;
 	int haslight;
 
 }snap;
 
 int process(int n, int k){
 
 	snapper sp[n];
 	int i;
         for(i = 0;i < n;i++){
 
 		if(i == 0){
 			sp[i].energy = 1;
 		} else {
 			sp[i].energy = 0;			
 		}
 		sp[i].swtch = 0;
 		sp[i].light = 0;
 		if(i == (n-1)){
 			sp[i].haslight = 1;
 		} else {
 			sp[i].haslight = 0;
 		}
 	}
 	
 	i = 0;
 	while(i < k)
 	{
 		int j;
 		for(j = 0;j < n;j++){
 			if(sp[j].energy == 1){
 				sp[j].swtch = (sp[j].swtch == 1) ? 0: 1; 	
 			}
 			if(j != 0){
 				sp[j].energy = (sp[j-1].energy == 1 && sp[j-1].swtch == 1) ? 1 : 0;
 			}
 			sp[j].light = (sp[j].haslight == 1 && sp[j].swtch == 1 && sp[j].energy == 1) ? 1 : 0;
 			
 			
 		}
 		i++;
 	}
 		
 	return sp[n-1].light;
 }
 
 int main()
 {
 	FILE *in;
 	FILE *out;
 
 	in = fopen("A-small-attempt0.in","r");
 	out = fopen("A-small-attempt0.out", "w");
 	int t,n,k = 0;
 	fscanf(in, "%d", &t);
 	//printf("%d\n", t);
 	int cas = 1;
 	while(t > 0){
 		fscanf(in, "%d %d", &n,&k);
 		//printf("%d %d\n", n,k);
 		int r = process(n,k);
 		if(r){
 		     fprintf(out, "Case #%d: ON\n", cas);		
 		} else {
 		     fprintf(out, "Case #%d: OFF\n", cas);					
 		}
 		t--;
 		cas++;
 	}
 
 	fclose(in);
 	fclose(out);
 
 	return 0;
 }

