#include<stdio.h>
 int main()
 {
    long int n, k, cases;
    int fact=1, i, j;
    FILE *p = fopen( "A-small-attempt0.in", "r");
    char state[2][4] ={"OFF\0", "ON\0"};
    fscanf(p, "%d", &cases);
    for(j=1; j<=cases;++j){
     fscanf(p, "%d", &n);
     fscanf(p, "%d", &k);
     for(i=0;i<n;++i){ 
      if(!(fact=k%2))break;
      k/=2;
      }
     printf( "Case #%d: %s \n",j,state[fact]);
    } 
     return 0;
 }
 
       

