#include <cstdio>
 #include <iostream>
 
 using namespace std;
 
 int main()
 {
     long queue [1010];
     long sale  [1010];
     int  index [1010];
 
     int N;
     long R, k;
     long T;
 
     scanf("%ld", &T);
 
     for (long count = 1; count <= T; count ++) {
         scanf("%ld%ld%d", &R, &k, &N);
         for (int i = 0; i < N; i ++)
         {
             scanf("%ld", &queue[i]);
             sale[i] = 0;
             index[i] = -1;
         }
         
          long left = R;
          long ans = 0;
          int head = 0;
          int prev = -1;
 
          while (left > 0) {
              index[head] = R - left;
              long rs = 0;
              int next = head;
              while (rs + queue[next] <= k) {
                 rs += queue[next];
                 next = (next + 1) % N;
                 if (next == head)
                     break;
              }
              ans += rs;
              sale[index[head]] = rs;
              left --;
              if (index[next] != -1) {
                  int cl = index[head] - index[next] + 1;
                  long cs = sale[index[head]];
 
                  for (int i = index[next]; i < index[head]; i ++)
                      cs += sale[i];
 
                  //printf("Found cycle at s=%d, e=%d, cl=%d, cs=%ld left=%ld\n", index[head], index[next], cl, cs, left);
                  int cc = left/cl;
                  ans += (cs * cc);
 
                  left = left % cl;
                  int i = index[next];
                  while (left > 0) {
                      rs = 0;
                      ans += sale[i];
                      i ++;
                      left --;
                  }
                  break;
              }
              head = next;
          }
          printf("Case #%ld: %ld\n", count,ans);
     }
 
     return 0;
 }

