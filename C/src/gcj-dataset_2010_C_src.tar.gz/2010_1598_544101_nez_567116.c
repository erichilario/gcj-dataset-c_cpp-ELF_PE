#include <stdio.h>
 
 #define REP(a, b, c) for (a=b; a<c; a++)
 
 #define dot '.'
 #define R 'R'
 #define B 'B'
 
 char brd[50][50];
 
 int main()
 {
 	int i = 0, j =0, i_temp =0, j_temp = 0;
 	int N = 0, K = 0;
 	int tc = 0, temp_tc = 0;
 	int k_r = 0, k_b = 0;
 	int rwin = 0, bwin = 0;
 
 	FILE *f_in = NULL;
 	FILE *f_out = NULL;
 
 	f_in = fopen("inputA.txt", "r");
 	f_out = fopen("outputA.txt", "w");
 
 	fscanf(f_in, "%d", &tc);
 
 	REP(temp_tc , 1, tc+1)
 	{
 		 k_r = k_b = 0;
 		 rwin = bwin = 0;
 
 		fscanf(f_in, "%d %d", &N, &K);
 
 		REP (i, 0, N)
 		{
 			REP(j, 0, N)
 			{
 				brd[N-1-j][N-1-i] = fgetc(f_in);
 				if (brd[N-1-j][N-1-i] == '\n') 
 					brd[N-1-j][N-1-i] = fgetc(f_in);
 
 			}
 		}
 
 		REP(j, 0, N)
 		{
 			for (i_temp = N-1; i_temp >= 0; i_temp--)
 			{
 				for (i = 1; i<=i_temp ; i++)
 				{
 					//while (brd[i])
 					if (brd[i-1][j] == dot)
 					{
 						brd[i-1][j] = brd[i][j];
 						brd[i][j] = dot;
 					}
 				}
 			}
 		}
 
 		//check row
 		REP (j, 0, N)
 		{
 			k_b = k_r = 0;
 			REP (i, 0, N)
 			{
 				if ((rwin == 1) && (bwin == 1))
 				{
 					break;
 				}
 
 				if (brd[i][j] == dot)
 				{
 					k_b = k_r = 0;
 				}
 				else if (brd[i][j] == R)
 				{
 					k_b = 0;
 					if (!rwin)
 					{
 						k_r++;
 						if (k_r == K) rwin = 1;
 					}
 				}
 				else if (brd[i][j] == B)
 				{
 					k_r = 0;
 
 					if (!bwin)
 					{
 						k_b++;
 						if (k_b == K) bwin = 1;
 					}
 				}
 				else if ((rwin == 1) && (bwin == 1))
 				{
 					break;
 				}
 			}
 
 
 		}
 
 		//check column
 		REP (i, 0, N)
 		{
 			k_b = k_r = 0;
 			REP (j, 0, N)
 			{
 				if ((rwin == 1) && (bwin == 1))
 				{
 					break;
 				}
 
 				if (brd[i][j] == dot)
 				{
 					k_b = k_r = 0;
 				}
 				else if (brd[i][j] == R)
 				{
 					k_b = 0;
 					if (!rwin)
 					{
 						k_r++;
 						if (k_r == K) rwin = 1;
 					}
 
 				}
 				else if (brd[i][j] == B)
 				{
 					k_r = 0;
 
 					if (!bwin)
 					{
 						k_b++;
 						if (k_b == K) bwin = 1;
 					}
 				}
 				else if ((rwin == 1) && (bwin == 1))
 				{
 					break;
 				}
 			}
 		}
 
 		//check diagnol
 		REP (i, 0, N)
 		{
 			i_temp = i;
 			j = 0;
 
 			k_b = k_r = 0;
 			while ((i_temp < N) && (j < N))
 			{
 				if ((rwin == 1) && (bwin == 1))
 				{
 					break;
 				}
 
 				if (brd[i_temp][j] == dot)
 				{
 					k_b = k_r = 0;
 				}
 				else if (brd[i_temp][j] == R)
 				{
 					k_b = 0;
 					if (!rwin)
 					{
 						k_r++;
 						if (k_r == K) rwin = 1;
 					}
 				}
 				else if (brd[i_temp][j] == B)
 				{
 					k_r = 0;
 
 					if (!bwin)
 					{
 						k_b++;
 						if (k_b == K) bwin = 1;
 					}
 				}
 
 				i_temp++;
 				j++;
 			}
 
 			i_temp = i;
 			j  = 0;
 			k_b = k_r = 0;
 
 			while (i_temp < N && j >= 0)
 			{
 				if ((rwin == 1) && (bwin == 1))
 				{
 					break;
 				}
 
 				if (brd[i_temp][j] == dot)
 				{
 					k_b = k_r = 0;
 				}
 				else if (brd[i_temp][j] == R)
 				{
 					k_b = 0;
 					if (!rwin)
 					{
 						k_r++;
 						if (k_r == K) rwin = 1;
 					}
 				}
 				else if (brd[i_temp][j] == B)
 				{
 					k_r = 0;
 
 					if (!bwin)
 					{
 						k_b++;
 						if (k_b == K) bwin = 1;
 					}
 				}
 
 				i_temp++;
 				j--;
 			}
 		}
 
 
 		REP (j, 0, N)
 				{
 					j_temp = j;
 					i = 0;
 
 					k_b = k_r = 0;
 					while ((j_temp < N) && (i < N))
 					{
 						if ((rwin == 1) && (bwin == 1))
 						{
 							break;
 						}
 
 						if (brd[i][j_temp] == dot)
 						{
 							k_b = k_r = 0;
 						}
 						else if (brd[i][j_temp] == R)
 						{
 							k_b = 0;
 							if (!rwin)
 							{
 								k_r++;
 								if (k_r == K) rwin = 1;
 							}
 						}
 						else if (brd[i][j_temp] == B)
 						{
 							k_r = 0;
 
 							if (!bwin)
 							{
 								k_b++;
 								if (k_b == K) bwin = 1;
 							}
 						}
 
 						i++;
 						j_temp++;
 					}
 
 					i = 0;
 					j_temp  = j;
 					k_b = k_r = 0;
 
 					while (i < N && j_temp >= 0)
 					{
 						if ((rwin == 1) && (bwin == 1))
 						{
 							break;
 						}
 
 						if (brd[i][j_temp] == dot)
 						{
 							k_b = k_r = 0;
 						}
 						else if (brd[i][j_temp] == R)
 						{
 							k_b = 0;
 							if (!rwin)
 							{
 								k_r++;
 								if (k_r == K) rwin = 1;
 							}
 						}
 						else if (brd[i][j_temp] == B)
 						{
 							k_r = 0;
 
 							if (!bwin)
 							{
 								k_b++;
 								if (k_b == K) bwin = 1;
 							}
 						}
 
 						i++;
 						j_temp--;
 					}
 				}
 
 		if ((rwin == 1) && (bwin == 0))
 		{
 			fprintf (f_out, "Case #%d: Red\n", temp_tc);
 		}
 		else if ((rwin == 0) && (bwin == 1))
 		{
 			fprintf (f_out, "Case #%d: Blue\n", temp_tc);
 		}
 		else if ((rwin == 1) && (bwin == 1))
 		{
 			fprintf (f_out, "Case #%d: Both\n", temp_tc);
 		}
 		else
 		{
 			fprintf (f_out, "Case #%d: Neither\n", temp_tc);
 		}
 	}
 
 }

