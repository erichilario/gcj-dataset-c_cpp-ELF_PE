#include<stdio.h>
 #include<gmp.h>
 
 #define max(x,y) (x<y)?y:x
 
 void find_cases_t(mpz_t result,int n,int position){
   int temp;
   mpz_t num,den1,den2,temp1,temp2;
   mpz_init(num);
   mpz_fac_ui(num,n-position-1);
   if(position==1){
     mpz_add_ui(result,result,1);
     mpz_mod_ui(result,result,100003);
   }
   else{
     for(temp=max(2*position-n,1);temp<position;temp++){
       if(position!=temp+1){
 	mpz_init(temp1);
 	mpz_init_set_ui(temp2,0);
 	mpz_init(den1);
 	mpz_init(den2);
 	mpz_fac_ui(den1,position-temp-1);
 	mpz_fac_ui(den2,n+temp-(2*position));
 	mpz_mul(den1,den1,den2);
 	mpz_divexact(temp1,num,den1);
 	
 	find_cases_t(temp2,position,temp);
 	mpz_mul(temp1,temp1,temp2);
 	mpz_add(result,result,temp1);
         mpz_mod_ui(result,result,100003);
 	mpz_clear(den1);
 	mpz_clear(den2); 
 	mpz_clear(temp1);
 	mpz_clear(temp2);
       }
       else{
 	find_cases_t(result,position,temp);
         mpz_mod_ui(result,result,100003);
       }
     }
   }
   mpz_clear(num);
 }
 
 void find_cases(mpz_t result,int n){
   mpz_clear(result);
   mpz_init_set_ui(result,0);
   int temp;
   for(temp=1;temp<n;temp++)
     find_cases_t(result,n,temp);
 }
 
 int main(void){
   int num_cases,curr_cases,n;
   mpz_t result;
   scanf("%d",&num_cases);
   for(curr_cases=1;curr_cases<=num_cases;curr_cases++){
     scanf("%d",&n);
     mpz_init(result);
     find_cases(result,n);
     mpz_mod_ui(result,result,100003);
     gmp_printf("Case #%d: %Zd\n",curr_cases,result);
     mpz_clear(result);
   }
   return 0;
 }

