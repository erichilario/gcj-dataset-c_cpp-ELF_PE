#include<stdio.h>
 #include<string.h>
 #define abs(x) ((x)>0?(x):(-(x)))
 #define max(a,b) ((a)>(b)?(a):(b))
 #define min(a,b) ((a)>(b)?(b):(a))
 int f[151][300],F[151][300];
 int h[300][300];
 int g[151];
 int main(){
 	int T;
 	scanf("%d",&T);
 	int l;
 	for(l=1;l<=T;l++){
 		printf("Case #%d: ",l);
 		int D,I,m,n;
 		int i;
 		scanf("%d%d%d%d",&D,&I,&m,&n);
 		memset(f,0,sizeof f);
 		memset(g,0,sizeof g);
 		for(i=0;i<n;i++)
 			scanf("%d",g+i);
 		int j,k;
 		memset(F,127,sizeof F);
 		for(j=0;j<256;j++)
 			f[0][j]=abs(j-g[0]);
 		if(m>0){
 			for(j=0;j<256;j++)
 			for(k=0;k<256;k++)
 				if(f[0][j]+(abs(j-k)/m+(abs(j-k)%m!=0))*I<F[0][k])
 				F[0][k]=f[0][j]+(abs(j-k)/m+(abs(j-k)%m!=0))*I;
 		}
 		if(m==0)
 			for(k=0;k<256;k++)F[0][k]=f[0][k];
 		for(i=1;i<n;i++){
 			for(j=0;j<256;j++){
 				f[i][j]=F[i-1][j]+D;
 				for(k=max(0,j-m);k<=min(255,j+m);k++)
 				if(F[i-1][k]+abs(j-g[i])<f[i][j])
 					f[i][j]=F[i-1][k]+abs(j-g[i]);
 				if(m>0){
 					for(k=0;k<256;k++)
 					if(f[i][j]+(abs(j-k)/m+(abs(j-k)%m!=0))*I<F[i][k])
 						F[i][k]=f[i][j]+(abs(j-k)/m+(abs(j-k)%m!=0))*I;
 				}
 			}
 			if(m==0)
 			for(k=0;k<256;k++)
 				F[i][k]=f[i][k];
 		}
 		int ans=2147483647;
 		for(j=0;j<256;j++)if(F[n-1][j]<ans)ans=F[n-1][j];
 		printf("%d\n",ans);
 	}
 	return 0;
 }

