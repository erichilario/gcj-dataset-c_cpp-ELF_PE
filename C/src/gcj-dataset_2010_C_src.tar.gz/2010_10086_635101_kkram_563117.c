#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 #define MAX_LENGTH 200
 
 char *read_input_line(char *str) 
 {
     char *tmp;
 
     str = fgets(str, MAX_LENGTH, stdin);
 
     tmp = strchr(str, '\n');
     if(tmp == NULL) {
         printf("Error: newline char not found!\n");
         exit(-1);
     }
     *tmp = '\0';
 
     if(str == NULL) {
         printf("Error: reading input line\n");
         exit(-1);
     }
     return str;
 }
 
 int read_input_int(char *str) 
 {
     int val;
 
     str = read_input_line(str);
     sscanf(str, "%d", &val); 
     return val;
 }
 
 int output(int nr_case, int print)
 {
     printf("Case #%d: %d\n", nr_case, print);
 }
 
 int main(void)
 {
     int cases, i, j, k, l;
     int N, M, n;
     char str[MAX_LENGTH + 1];
     char *res;
     int count;
     char val;
     int flag;
     int outval;
     char path[200][MAX_LENGTH + 1];
     char *ret;
     int cur;
     int exists;
     int len;
 
     cases = read_input_int(str);
 
     for(i = 1; i <= cases; i++) {
         outval = 0;
 
         res = read_input_line(str);
         sscanf(res, "%d %d", &N, &M);
 
         for(j = 0; j < N; j++) {
             res = read_input_line(str);
             memcpy(path[j], res, strlen(res));
             path[j][strlen(res)] = '\0';
         }
 
         n = N;
         for(j = 0; j < M; j++) {
             res = read_input_line(str);
            
             exists = 0;
             count = 0;
             for(k = 0; k < strlen(res); k++)
                 if(res[k] == '/')
                     count++;
       //     printf("dirs %d\n", count); 
             ret = res;
             while(1) {
                 ret = strchr(ret + 1, '/');
 
                 if(!ret)
                     len = strlen(res);
                 else
                     len = ret - res;
 
                 cur = 1;
                 for(k = 0; k < n; k++) {
                     if(strlen(path[k]) < len)
                         continue; 
                     if(path[k][len] != '/' && path[k][len] != '\0') {
      //                   printf("cont path %s len %d\n", path[k], len);
                         continue; 
                     }
                     cur = memcmp(path[k], res, len);
                     if(!cur)
                         break;
                 }
                 
                 if(cur) 
                     break;
                 exists++;
                 if(!ret)
                     break;
             }
           
             memcpy(path[n], res, strlen(res));
             path[n][strlen(res)] = '\0';
             n++;
 
             outval += count - exists;
             //printf("res %s %d\n", res, outval);
         }
 
         output(i, outval); 
     }
 
     return 1;
 }

