#include <stdio.h>
 #include <string.h>
 int check[101];
 int n, k, b, t;
 int main()
 {
     int tc, cn;
     int i, j, l;
     int min1, res, cnt;
     int vi, xi;
     int xx, yy;
     int x[101], v[101], perm[101];
     int num[101];
     scanf("%d", &tc);
     for (cn = 1; cn <= tc; cn++) {
         scanf("%d%d%d%d", &n, &k, &b, &t);
         for (i = 0; i < n; i++) {
             scanf("%d", &x[i]);
         }
         for (i = 0; i < n; i++) {
             scanf("%d", &v[i]);
         }
         memset(check, 0, sizeof(check));
         for (i = 0; i < n; i++) {
             if ((long long)x[i] + (long long)t * (long long)v[i] >= (long long)b) {
                 check[i] = 1;
             }
         }
         l = 0;
         for (i = 0; i < n; i++) {
             if (check[i])
                 l++;
         }
         if (k == 0) {
             printf("Case #%d: 0\n", cn);
             continue;
         }
         if (l < k) {
             printf("Case #%d: IMPOSSIBLE\n", cn);
             continue;
         }
 
         if (k == 1) {
             for (i = n-1, j = 0; i >= 0; i--, j++) {
                 if (check[i])
                     break;
                 j++;
             }
             printf("Case #%d: %d\n", cn, j);
         }
         else if (k == 2) {
             for (i = n-1, j = 0; i >= 0; i--, j++) {
                 if (check[i])
                     break;
             }
             xx = 0;
             for (i = i-1; i >= 0; i--, xx++) {
                 if (check[i])
                     break;
             }
             printf("Case #%d: %d\n", cn, j*2+xx);
         }
         else if (k == 3) {
             for (i = n-1, j = 0; i >= 0; i--, j++) {
                 if (check[i])
                     break;
             }
             xx = 0;
             for (i = i-1; i >= 0; i--, xx++) {
                 if (check[i])
                     break;
             }
             yy = 0;
             for (i = i-1; i >= 0; i--, yy++) {
                 if (check[i])
                     break;
             }
             printf("Case #%d: %d\n", cn, j*3+xx*2+yy);
         }
         else {
             printf("????\n");
         }
     }
     return 0;
 }

