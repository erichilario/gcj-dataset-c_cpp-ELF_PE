#include <stdio.h>
 
 int main() {
     
     unsigned int n, t, k;
     
     int kase;
     
     unsigned int twopow[31];
     
     int i;
     
     twopow[0]=1; twopow[1]=2;
     for (i=2; i<31; i++) {
         twopow[i] = 2*twopow[i-1];
     }
     
     scanf( "%d", &t );
     
     for (kase=0;kase<t;kase++) {
         
         scanf( "%d %d", &n, &k );
         
         printf("Case #%d: %s\n", kase+1, ((k%twopow[n])==twopow[n]-1)?"ON":"OFF");
         
     }
     
     return 0;
 }
