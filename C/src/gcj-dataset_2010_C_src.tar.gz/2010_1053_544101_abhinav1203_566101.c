#include<stdio.h>
 #include<math.h>
 int main()
 {
   int t,d,i,m,n,j,cost,test,a[105];
   scanf("%d",&t);
   test=1;
   while(t--)
     {
       scanf("%d %d %d %d",&d,&i,&m,&n);
       for(j=0;j<n;j++)
 	scanf("%d",&a[j]);
       cost=0;
       for(j=1;j<n;j++)
 	{
 	  if(fabs(a[j]-a[j-1])<m)
 	    continue;
 	  if(fabs(a[j]-a[j-1])-m>fabs(a[j]-a[j-1])/m*i && fabs(a[j]-a[j-1])/m*i<d)
 	    cost+=fabs(a[j]-a[j-1])/m*i;
 	  else if(fabs(a[j]-a[j-1])-m<d)
 	    cost+=fabs(a[j]-a[j-1])-m;
 	  else
 	    {
 	      cost+=d;
 	      if(fabs(a[j+1]-a[j-1])<fabs(a[j+1]-a[j]))
 		a[j]=a[j-1];
 	    }
 	}
       printf("Case #%d: %d\n",test++,cost);
     }
   return 0;
 }

