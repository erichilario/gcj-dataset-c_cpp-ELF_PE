/*http://www.codechef.com/MAY10/problems/TR1/*/
 
 #include <stdio.h>
 #define MAXNOOFPLUGS 10
 int sockets[MAXNOOFPLUGS+1],indexes[MAXNOOFPLUGS+1][MAXNOOFPLUGS+1],mod[MAXNOOFPLUGS+1];
 int isZero(int noofsockets)
 {
 int i;
 for(i=1;i<noofsockets+1;i++)
 {
 if(sockets[i]==1)
 return 0;
 }
 return 1;
 }
 void AddToIndex(noofsockets,l)
 {
 int i;
 for(i=1;i<MAXNOOFPLUGS+1;i++)
 {
 if(indexes[noofsockets][i]==0)
 {	indexes[noofsockets][i]=l+1;
 	return;
 }
 }
 
 }
 int isPresent(noofsockets,l)
 {
 int i;
 if(l==0)
 return 0;
 for(i=1;i<MAXNOOFPLUGS+1;i++)
 {
 if(indexes[noofsockets][i]==l)
 {	
 	return 1;
 }
 }
 return 0;
 }
  
 int flip(int noofsockets)
 {
 /*it should set mod and indexes
 */
 int i,l;
 if(noofsockets==1)
 {
 mod[1]=2;
 indexes[1][1]=1;
 }
 sockets[1]=1;
 l=1;
 while(1)
 {
 
 for(i=noofsockets;i>1;i--)
 {
 	if(sockets[i-1]==1)
 	{
 		if(sockets[i]==1)
 			sockets[i]=0;
 		else
 			sockets[i]=1;
 	}
 
 }
 		if(sockets[1]==1)
 			sockets[1]=0;
 		else
 			sockets[1]=1;
 
 	if(sockets[noofsockets]==1)
 	{
 		AddToIndex(noofsockets,l);
 	}
 	if(isZero(noofsockets))
 	{
 		mod[noofsockets]=l+1;
 		return;
 	}
 
 l++;
 //sockets[
 }
 }
 int main()
 {
 
 int noIter,i,j,finalresult,noofflips,noofsockets;
 for(i=1;i<MAXNOOFPLUGS+1;i++)
 {
 	sockets[i]=0;
 	mod[i]=0;
 	for(j=1;j<MAXNOOFPLUGS+1;j++)
 	{
 		indexes[i][j]=0;
 	}
 }
 
 for(i=1;i<MAXNOOFPLUGS+1;i++)
 {
 	for(j=1;j<MAXNOOFPLUGS+1;j++)
 	{
 		sockets[i]=0;
 	}
 	flip(i);
 }
 
 /*for(i=1;i<MAXNOOFPLUGS+1;i++)
 {
 	printf("no of sockets %d mod %d\nIndexes at which bulb glows\n",i,mod[i]);
 	for(j=1;j<MAXNOOFPLUGS+1;j++)
 	{
 		printf("%d ",indexes[i][j]);
 	}
 	printf("\n");
 }*/
 
 scanf("%d",&noIter); 
 
 
 	for(i=0;i<noIter;i++)
 	{
 		
 		scanf("%d %d",&noofsockets,&noofflips);
 		
 		//printf("%d %d",noofsockets,noofflips);
 		if(noofsockets==1)
 		{
 			if(noofflips%2==1)
 				finalresult=1;
 		}
 		if(isPresent(noofsockets,noofflips%mod[noofsockets]))
 				finalresult=1;
 			else
 				finalresult=0;
 		if(noofflips==0)
 			finalresult=0;
 
 		if(finalresult==0)
 		printf("Case #%d:OFF\n",(i+1));
 		else
 		printf("Case #%d:ON\n",(i+1));
 		
 	}		
 }
 

