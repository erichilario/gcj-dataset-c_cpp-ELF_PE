#include <assert.h>
 #include <stdio.h>
 #include <stdlib.h>
 #define __USE_BSD
 #include <string.h>
 
 typedef char Path[101];
 typedef struct Root {
 	char *name;
 	int n;
 	struct Root *p;
 } Root;
 
 static int paths = 0;
 
 // add path if not exists, return it
 Root *
 addpath(Root *r, char *s, int verbose)
 {
 	for (int i = 0; i < r->n; i++)
 		if (strcmp(r->p[i].name, s) == 0) {
 			fprintf(stderr, "have dir %s\n", s);
 			return r->p + i;
 		}
 
 	// not exists
 	if (verbose)
 		paths++;
 	fprintf(stderr, "need dir %s (verb=%d)\n", s, verbose);
 
 	r->n++;
 	r->p = realloc(r->p, r->n * sizeof(Root));
 	assert(r->p);
 	r->p[r->n - 1].name = strdup(s);
 	r->p[r->n - 1].n = 0;
 	r->p[r->n - 1].p = NULL;
 	return r->p + r->n - 1;
 }
 
 
 int
 main() {
 	int T;	// test cases
 	scanf(" %d", &T);
 	for (int t = 1; t <= T; t++) {
 		int N, M;	// existing paths, desired paths
 		scanf(" %d %d", &N, &M);
 		paths = 0;
 		
 		Root r = { NULL, 0, NULL };
 		for (int i = 0; i < M + N; i++) {
 			Path path;
 			scanf(" %s", path);
 
 			Root *x = &r;
 			fprintf(stderr, "path=\"%s\" paths=%d, i=%d, M=%d\n", path, paths, i, M);
 			// add path to Root tree, count it if i >= N
 			char *s = path, *sc;
 			assert(*s == '/');
 			while ((sc = strchr(++s, '/'))) {
 				*sc = 0;
 				x = addpath(x, s, i >= N);
 				s = sc;
 			}
 			addpath(x, s, i >= N);
 		}
 
 		printf("Case #%d: %d\n", t, paths);
 	}
 }

