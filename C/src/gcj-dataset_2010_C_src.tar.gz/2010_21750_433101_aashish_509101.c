#include<stdio.h>
 #include<stdlib.h>
 #include<unistd.h>
 
 
 struct node
 {
     int info;
     struct node *link;
 };
 
 typedef struct node * nodeptr;
 
 
 
 /*nodeptr del_node(nodeptr head,int steps)
 {
     int i;
     nodeptr val=head;
     for(i=0;i<steps-2;i++)
     {
         val=val->link;
     }
     val->link = (val->link)->link;
     head=val->link;
     return head;
 }*/
 
 
 nodeptr insert(nodeptr head, int n)
 {
     nodeptr temp,val;
     temp = (nodeptr)malloc(sizeof(struct node));
     temp->info = n;
     if(head == NULL)
     {
         head = temp;
         head->link = head;
         return head;
     }
     else {
         val = head;
         while(val->link != head)
             val = val->link;
         val->link = temp;
         temp->link = head;
         return head;
     }
 }
 
 
 /*void display(nodeptr head)
 {
     nodeptr val;
     val=head;
     printf("%d\t",val->info);
     while(val->link!=head)
     {
         val=val->link;
         printf("%d\t",val->info);
     }
     printf("\n");
 }*/
 
 
 
 int main()
 {
 	int t, r, n, i, k, val, iter, no_of_iter, all_included;
 	long long int amount, sum;
 	scanf("%d",&t);
 	for (iter = 0; iter<t; iter++) {
 		scanf("%d%d%d",&r,&k,&n);
 		nodeptr head;
 		sum = 0;
     		head=(nodeptr)malloc(sizeof(struct node));
     		head=NULL;
 		for(i=1;i<=n;i++) {
 			scanf("%d",&val);
 			sum += val;
 			head = insert(head,val);
 		}
 		amount = 0;
 		//printf ("%Ld",sum)
 		if ( sum <= k ) {
 			amount = r*sum;
 		}
 		else {	
 		    for (i = 0; i< r; i++) {
 			sum = 0;
 			while (1) {
 				sum += head->info;
 				if (sum <= k ) {
 					head = head->link;
 				}
 				else {
 					sum -= head->info;
 					break;
 				}
 				//printf("%d\t",no_of_iter);
 			}
 			amount += sum;
 		    }
 		}
 		printf("Case #%d: %Ld\n",iter+1 , amount);
 	}
 	
 	return 0;
 }

