#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int main() {
 
 	FILE* op;
 	int T, i;
 	long int K, R, N, *gSize, j, Euros, h, temp, tempH;
 
 	op = fopen("output.txt", "w");
 	scanf("%d", &T);
 
 	for ( i = 1; i <= T; i++ ) {
 		Euros = 0;
 		scanf("%ld%ld%ld", &R, &K, &N);
 		gSize = (long int*)calloc(N, sizeof(long int));
 		for( j = 0; j < N; j++ )
 			scanf("%ld", &gSize[j]);
 
 		h = 0;
 		for ( j = 0; j < R; j++ ) {
 			temp = 0;
 			tempH = 0;
 			while ( (temp + gSize[h]) <= K && tempH < N ) {
 				temp += gSize[h];
 				h = ( h + 1 ) % N;
 				tempH++;
 			}
 			Euros += temp;
 		
 		}
 		
 		fprintf(op, "Case #%d: %ld\n", i, Euros);
 	}
 	fclose(op);
 	
 	return 0;
 }
 
 

