#include <stdio.h>
 #include <stdlib.h>
 
 #define true 1
 #define false 0
 
 typedef unsigned char bool;
 
 #define MAX_GROUPS 1100
 
 typedef struct
 {
    long long int size, turn, accum;
 } info;
 
 info gr[MAX_GROUPS];
 
 int main()
 {
    int T, cont = 0;
 
    scanf("%d", &T);
    while(T--)
    {
       long long int runs, max, nGroups;
       long long int lenCycle;
       long long int euros, eurosCycle, tGroups = 0;
       long long int i, k;
       
       scanf("%lld %lld %lld", &runs, &max, &nGroups);
       
       for(i = 0; i < nGroups; i++)
       {
          gr[i].turn = gr[i].accum = -1;
          scanf("%lld", &gr[i].size);
          tGroups += gr[i].size;
       }
       
       if(tGroups > max)
       {
          i = 0;
          euros = 0;
          lenCycle = -1, eurosCycle = -1;
 
          for(k = 0; k < runs; k++)
          {
             long long int cur = 0;            
          
             if(gr[i].turn == -1)
             {
                gr[i].turn = k;
                gr[i].accum = euros;
             }
             else
             {
                if(lenCycle == -1)
                {
                   lenCycle = k-gr[i].turn;
                   eurosCycle = euros-gr[i].accum;
                }
                
                if((runs-k)%lenCycle == 0)
                {
                   euros += ((runs-k)/lenCycle)*eurosCycle;
                   break ;
                }
             }
             
             for( ; ; i++)
             {
                if(i == nGroups)
                   i = 0;
                
                if(cur + gr[i].size <= max)
                   cur += gr[i].size;
                else
                   break ;
             }
             
             euros += cur;
          }
       }
       else
       {
          euros = tGroups*runs;
       }
       
       printf("Case #%d: %lld\n", ++cont, euros);
    }
         
 return 0;
 }

