#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 #define MAX_N 30
 #define MAX_K 100000000
 
 //int state[MAX_K][MAX_N];
 //int power[MAX_K][MAX_N];
 
 int* state;
 int* power;
 
 int main()
 {
 	int n, k, i, j, num, cut;
 
 	state = malloc(MAX_K*sizeof(int));
 	power = malloc(MAX_K*sizeof(int));
 
 	memset(state, 0, MAX_K*sizeof(int));
 	memset(power, 0, MAX_K*sizeof(int));
 	
 	//memset(state, 0, MAX_K*MAX_N*sizeof(int));
 	//memset(power, 0, MAX_K*MAX_N*sizeof(int));
 
 	power[0] = 1;
 
 	for(i =	1 ; i < MAX_K; i++)
 	{
 		state[i] = power[i-1] ^ state[i-1];
 		power[i] = 0x1;
 		j = 0;
 		while(j <= 32 && (state[i] >> j) & 0x1 == 0x1)
 		{
 			power[i] = (power[i] << 1) | 0x1;
 			j++;
 		}
 	}
 
 	int ii, jj;
 	scanf("%d", &num);
 	for(i = 0; i < num; i++)
 	{
 		scanf("%d %d", &n, &k);
 		//printf("s: %x p:%x\n", state[k], power[k]);
 		if(((power[k] >> (n-1)) & 0x1) == 1 && ((state[k] >> (n-1)) & 0x1) == 1)
 			printf("Case #%d: ON\n", i+1);
 		else
 			printf("Case #%d: OFF\n", i+1);
 	}
 }

