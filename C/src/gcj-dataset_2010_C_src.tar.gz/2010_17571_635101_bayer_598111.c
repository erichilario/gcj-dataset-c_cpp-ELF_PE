#include <stdio.h>
 #include <stddef.h>
 #include <stdlib.h>
 
 long int res[500];
 
 long int fib(int a1) {
 	if (a1 == 2)
 		return 1;
 	if (a1 == 3)
 		return 2;
 	if (res[a1-2] == -1)
 		res[a1-2] = fib(a1-2);
 	if (res[a1-1] == -1)
 		res[a1-1] = fib(a1-1);
 	return res[a1-2]+res[a1-1];
 }
 
 int main(int argc, char**argv) {
 	FILE *fp_in, *fp_out;
 	int count_tc;
 	int i, j;
 	int n;
 	if (argc < 3) {
 		printf("Usage: %s <input_file> <output_file>\n", argv[0]);
 		exit(0);
 	}
 
 	fp_in = fopen(argv[1], "r");
 	if (fp_in == NULL) {
 		perror(argv[1]);
 		exit(1);
 	}
 	fp_out = fopen(argv[2], "w");
 	if (fp_out == NULL) {
 		perror(argv[2]);
 		exit(1);
 	}
 
 	fscanf(fp_in, "%d ", &count_tc);
 	for (i = 0; i < count_tc; i++) {
 		for (j = 0; j < 500; j++)
 			res[j] = -1;
 		res[2] = 1;
 		res[3] = 2;
 		fscanf(fp_in, "%d ", &n);
 
 		if (res[n] == -1)
 			res[n] = fib(n-1)+fib(n-2);
 
 		fprintf(fp_out, "Case #%d: %ld\n", i+1, (res[n])%100003);
 	}
 
 
 	fclose(fp_in);
 	fclose(fp_out);
 	return 0;
 }

