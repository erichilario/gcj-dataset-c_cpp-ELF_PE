#include<stdio.h>
 int main()
 {
 	long long t,i,n,k,r,pow;
 
 	scanf("%lld",&t);
 	
 	for(i=1;i<=t;i++)
 	{
 		scanf("%lld %lld",&n,&k);
 		pow=1;	
 		pow<<=n;
 		r=k%pow;
 		if(r+1==pow)
 			printf("Case #%lld: ON\n",i);
 		else
 			printf("Case #%lld: OFF\n",i);
 	}
 	return 0;
 }

