#include <stdio.h>
 #include <stdlib.h>
 
 
 typedef struct queue {
    int g;
    struct queue * next;
 } QUEUE;
 
 QUEUE * q = NULL;
 QUEUE * tail = NULL;
 
 
 int compute (int, int);
 void add(int);
 void requeue(QUEUE *);
 void display(QUEUE *);
 
 
 int main(void) {
    FILE * fp = fopen("C-small-attempt0.in", "r");
    FILE * out = fopen("output.out", "w");
    int t, R, k, N, c=0;
    int qi;  // queue item
    
    fscanf(fp, "%d", &t);
    
    while(c<t) {
       fscanf(fp, "%d", &R);
       fscanf(fp, "%d", &k);
       fscanf(fp, "%d", &N);
       
       int i=0;
    
    
       for(; i<N; i++) {
          fscanf(fp, "%d", &qi);
          add(qi);
       }
       
       
       fprintf(out, "Case #%d: %d\n", c+1, compute(R,k));
       
       q=NULL;
       c++;
    }
    
    printf("\nEND");
    getch();
    
    fclose(fp);
    return 0;
 }
 
 
 void add(int qi) {
    if(!q) {
       q = (QUEUE *) malloc(sizeof(QUEUE *));
       q->g = qi;
       q->next = NULL;
       tail = q;
       return;
    } 
    
    tail->next = (QUEUE *) malloc(sizeof(QUEUE *));
    tail = tail->next;
    tail->g = qi;
    tail->next = NULL;
 }
 
 int compute (int R, int k)
 {
    int cr = 0, price=0, total_price=0;
    QUEUE * tmp = q;
    
    while(cr < R) { 
       while((price+tmp->g) <= k) {
          price += tmp->g;
          tmp = tmp->next;
          if(tmp==NULL) break;
       }
       total_price += price;
       price = 0;
       
       if(tmp!=NULL) requeue(tmp);
       
       tmp = q;
       cr++; 
    }
    return total_price;
 }
 
 
 void display(QUEUE * t)
 {
    while(t!=NULL) {
       printf(" - %d ", t->g);
       t = t->next;
    }
    putchar('\n');
 }
 
 void requeue(QUEUE * tmp)
 {
    QUEUE * h = NULL;  // head
    
    while(q != tmp) {
       h = q;
       q = q->next;           
       h->next = NULL;
       tail->next = h;
       tail = h;
    }
   
 }

