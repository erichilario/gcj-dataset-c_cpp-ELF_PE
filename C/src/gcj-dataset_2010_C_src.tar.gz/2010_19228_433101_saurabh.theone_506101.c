#include<stdio.h>
 int gcd(int, int);
 void isort(int*, int);
 
 main()
 {
     int c, i, n, j;
     scanf("%d", &c);
     for (i = 0; i < c; i++)
     {
         scanf("%d", &n);
         int a[n], diff[n - 1];
         for (j = 0; j < n; j++)
         {
             scanf("%d", &a[j]);
         }
         //printf("here\n");
         isort(a, n);
         for (j = 0; j < n; j++)
         {
             //printf("%d ", a[j]);
         }
         //printf("\n");
         for (j = 0; j < n - 1; j++)
         {
             diff[j] = a[j + 1] - a[j];
             //printf("diff[%d]: %d\n", j, diff[j]);
         }
         //printf("here\n");
         int g = diff[0];
         for (j = 1; j < n - 1; j++)
         {
             g = gcd(diff[j], g);
             //printf("gcd #%d: %d\n", j, g);
         }
         //printf("gcd: %d\n", g);
         int enter = 0;
         for (j = 0; j < n; j++)
         {
             if (a[j] % g != 0)
             {
                 enter = 1;
             }
         }
         if (enter == 0)
         {
             printf("Case #%d: 0\n", i + 1);
         } else
         {
             int rem = a[0] % g;
             printf("Case #%d: %d\n", i + 1, g - rem);
         }
     }
 }
 
 void isort(int a[], int len)
 {
     int i, j, min, pos = 0;
     //printf("len:%d\n",len);
     for (i = 0; i < len; i++)
     {
         min = a[i];
         pos = i;
         //printf("min:%d\n",min);
         for (j = i + 1; j < len; j++)
         {
             if (min > a[j])
             {
                 min = a[j];
                 pos = j;
                 //printf("min: %d pos:%d\n", min, pos);
             }
         }
         a[pos] = a[i];
         a[i] = min;
         //printf("a[%d]: %d a[%d]: %d\n",pos,a[pos],i,a[i]);
     }
 }
 
 int gcd(int n1, int n2)
 {
     while (n1 != 0 && n2 != 0)
     {
         if (n1 > n2)
         {
             n1 = n1 - n2;
         } else
         {
             n2 = n2 - n1;
         }
     }
     if (n1 != 0)
         return n1;
     else
         return n2;
 }
