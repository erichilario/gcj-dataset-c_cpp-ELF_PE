#include <stdio.h>
 #include <stdlib.h>
 
 #define rep(i,N) for (i = 0; i < N; i++)
 
 void main(){
 	int T, N, K, i, t, f;
 	scanf("%d", &T);
 	rep(t, T) {
 		scanf("%d %d", &N, &K);
 
 		f = 0;
 		rep(i, N) {
 			f += (K % 2 == 0);
 			K /= 2;
 		}
 		printf("Case #%d: %s\n", t+1, f ? "OFF" : "ON"); 
 	}
 }
 

