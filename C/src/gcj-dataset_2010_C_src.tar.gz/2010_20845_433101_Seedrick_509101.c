#include<stdio.h>
 //#include<conio.h>
 
 int main() {
     
     //FILE* fr = fopen("C-small.in", "r");
     //FILE* fw = fopen("C-small.out", "w");
     
     int noc, nocc;
     scanf("%d", &noc);
     
     nocc = noc;
     int R, RR; // no of times roller coaster runs in a day
     int k; // capacity of the roller coaster
     int N, NN; // no of groups of people
     int array[1000];
 
     while (nocc--) {
         scanf("%d", &R);
         scanf("%d", &k);
         scanf("%d", &N);
         NN = N;
         while (N--)
             scanf("%d", &array[NN - N - 1]);
         N = NN;
 
         int money = 0;
         int money_r;
         int i = 0;
         int ii;
 
         while (R--) {
 
             money_r = 0;
             int count = 0;
             while ((money_r <= k) && (count <= N)) {
                 count++;
                 money_r += array[i++];
                 if (i == N)
                     i = 0;
             }
             
             if (i == 0)
                 i = N - 1;
             else
                 i = i - 1;
             money += (money_r - array[i]);
             
             //printf("%3d : %3d\n", money, money_r);
         }
 
         printf("Case #%d: %d\n", noc - nocc, money);
         money = 0;
     }
     
     //fclose(fr);
     //fclose(fw);
     
     //getch();
     return 0;
 }

