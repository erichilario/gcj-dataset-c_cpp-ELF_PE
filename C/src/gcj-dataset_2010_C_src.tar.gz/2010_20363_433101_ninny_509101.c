#include<stdio.h>
 
 int main()
 {
 int tc,t,i,roller_rides,max,groups;
 
 FILE *f= fopen("D:/C-small-attempt3.in","r");
 
 fscanf(f,"%d",&tc);
 
 for(t=0;t<tc;t++)
 {
 int euros=0;
 fscanf(f,"%d",&roller_rides);
 fscanf(f,"%d",&max);
 fscanf(f,"%d",&groups);
 
 
 int g[groups];
 
 for(i=0;i<groups;i++)
 fscanf(f,"%d",&g[i]);
 
 
 for(i=0;i<roller_rides;i++)
 {
 int e=0,j=0,k,n;
 	while(e<=max)
 		{
 		e=e+g[j];	
 		j++;
 		}
 
 e=e-g[--j];
 euros=euros+e;
 
 
 	for(n=0;n<j;n++)
 	{
 	int temp=g[0];
 		for(k=1;k<groups;k++)
 		{ 
 		g[k-1]=g[k];
 		}
 	g[groups-1]=temp;
 	}
 
 
 }
 
 printf("Case #%d: %d \n",t+1,euros);
 
 }
 
 }

