#include<stdio.h>
 
 int main()
 {
 int repeat,t,n,k,val=1,pow;
 scanf("%d",&repeat);
 for(t=0; t<repeat;t++)
 	{
 	scanf("%d %d",&n,&k);
 	pow=val << n;
 	//printf("POW %d\n",pow);
 	if( (k+1) % pow ==0 )
 		printf("Case #%d: ON\n",t+1);
 	else
 		printf("Case #%d: OFF\n",t+1);
 	}
 return 0;
 }

