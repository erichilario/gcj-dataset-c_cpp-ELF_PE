#include<math.h>
 #include<stdio.h>
 
 main ()
 {
      FILE *fpi,*fpo;
      int N,T, casen=0;
      long int K;
     // clrscr();
      fpi=fopen("C:\A-large.IN","r");
      fpo=fopen("C:\A-large.out","w");
      fscanf(fpi,"%d",&T);
      while(++casen <=T)
      {
                    fscanf(fpi,"%d %ld",&N,&K);
                    if (((K+1)%(int)pow(2,N))==0)
                       {
                        printf("N=%d\tK=%ld\tCase #%d: ON\n",N,K,casen);
                        fprintf(fpo,"Case #%d: ON\n",casen);
                       }
                    else
                    {
                    printf("N=%d\tK=%ld\tCase #%d: OFF\n",N,K,casen);
                        fprintf(fpo,"Case #%d: OFF\n",casen);
                    }
      }
    getch();  
 }

