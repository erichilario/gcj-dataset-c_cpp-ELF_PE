#include<stdio.h>
 #include<string.h>
 
 int main()
 {
     char filename[32];
 	char infile[32], outfile[32];
 	char a[20];
 	FILE *fp, *ofp;
 	int tc, no, t;
 	long pow_2, snaps;
 		
 	scanf("%s", filename);
 	
 	strcpy(infile, filename); 
 	strcpy(outfile, filename);
 	strcat(infile, ".in"); 
 	strcat(outfile, ".out");
 	
 	fp=fopen(infile, "r"), 
 	ofp=fopen(outfile, "w");
 
 	fscanf(fp, "%d\n", &tc);
 	
 	for(t=1;t<=tc;t++)//line no
 	{
 		fgets(a, 20, fp);
 		sscanf(a,"%d %ld",&no,&snaps);
         if(no>26)        
     		fprintf(ofp, "Case #%d: OFF\n", t);
     	else
     	{
     	    pow_2=(1<<no)-1;
     	    snaps &= pow_2;
     	    if((pow_2-snaps)==0)
     	        fprintf(ofp, "Case #%d: ON\n", t);
     	    else
     	        fprintf(ofp, "Case #%d: OFF\n", t);
     	}
 	}
 	return 0;
 }
 

