#include<stdio.h>
 int main(void)
 {
     int i , j , n , t;
     long int k;
     FILE *input , *output;
     if((input = fopen("A-large.in" , "r+"))==NULL)
     {
         printf("Error!");
         exit(1);
     }
     if((output = fopen("output.txt" , "w+"))==NULL)
     {
         printf("Error!");
         exit(2);
     }
     fscanf(input , "%d\n" , &t);
     for(i = j = 1 ; i <= t ; i++ , j = 1)
     {
         fscanf(input , "%d %ld\n" , &n , &k);
         j = j << n;
         if(!((k + 1) % j))
         fprintf(output , "Case #%d: ON\n" , i);
         else
         fprintf(output , "Case #%d: OFF\n" , i);
     }
     fclose(input) , fclose(output);
     return 0;
 }

