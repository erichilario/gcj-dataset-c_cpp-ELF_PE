#include <conio.h>
 #include <stdio.h>
 
 void p(FILE *output, long T, long R, long k, long N, long *g) {
   int pointer = 1;
   int round;
   int i, j;
   unsigned long long sum = 0;
 
   //Create From table
   unsigned long long From[1001]; 
   int       Jump[1001] = {0};
   for(i = 1; i <= N; i++) {
     From[i] = 0;
     Jump[i] = 0;
     
     j = i;
     while(1) {
       if(From[i]+g[j] > k)
         break;
         
       From[i]+=g[j];
       Jump[i]++;
       if(j == N) 
         j = 1;
       else 
         j++;
       if(Jump[i] >= N) break;
     }
 //    printf("From[%d] = %d\n", i, From[i]);
 //    printf("Jump[%d] = %d\n", i, Jump[i]);
   }
 
 //  printf("sum = ");
   for(round = 0; round < R; round++) {
     sum += From[pointer];
     pointer = (pointer-1 + Jump[pointer]) % N +1;
 //  printf("%d + ", From[pointer]);
   }
 //  printf("= %d \n", sum);
 
   fprintf(output, "Case #%Lu: %Lu\n", T, sum);
   printf("Case #%Lu: %Lu\n", T, sum);  
 }
 
 int main()
 {
   FILE *input = fopen("input.txt", "r"); 
   FILE *output = fopen("output.txt", "w");
   long T=0, CaseNum, R, k, N, g[1001];
   int i;
   
   fscanf(input, "%d\n", &CaseNum);
   printf("%d\n", CaseNum);
   for( T=1; T<=CaseNum; T++) {      
     fscanf(input, "%d %d %d\n", &R, &k, &N);        
 //    printf("%d %d %d\n", R, k, N);
     for(i = 1; i <= N; i++) {
       fscanf(input, "%d\n", &g[i]);
 //      printf("%d ", g[i]);
     }
 //    printf("\n");
     p(output, T, R, k, N, g);
   }  
 
   fclose(input);
   fclose(output);
   return 0;
 }

