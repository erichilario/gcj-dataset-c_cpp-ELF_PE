#include<stdio.h>
 main()
 {
     int t;
     scanf("%d",&t);
     int n,k,i;
     for(i=0;i<t;i++)
     {
         scanf("%d%d",&n,&k);
         int mult=1,j=0;
         for(j=0;j<n;j++)
         {
             mult*=2;
         }
         //printf("mult: %d\n",mult);
         if((k+1)%mult==0)
         {
             printf("Case #%d: ON\n",i+1);
         }
         else
         {
             printf("Case #%d: OFF\n",i+1);
         }
     }
 }
