#include <stdio.h>
 #include <string.h>
 #define MAX 101
 
 char P[ MAX*MAX][ MAX*MAX ];
 char NEW[ MAX*5 ][ MAX*5 ];
 
 int n, m;
 
 int esta( char *s ){
   int i, j, k;
 
 
   for( i = 0; i<n; i++ ){
        for( k = 0; s[ k ] != 0 && P[ i ][ k ] != 0 && P[ i ][ k ] == s[ k ]; k++ );
        if( s[ k ] == 0 && P[ i ][ k ] == 0 ) return 1;
 
   }
     
   return 0;
 }
 
 int main(){
   int test, t, r, k, l, i, j;
   char a[ MAX ];
 
  scanf("%d", &t );
   
   for( test = 1; test <= t; test++ ){
 
     printf("Case #%d: ", test );
 
     scanf("%d %d", &n, &m );
 
     for( i = 0; i<n; i++ ) scanf("%s", P[ i ] );
     
     for( i = 0; i<m; i++ ) scanf("%s", NEW[ i ] );
 
     qsort( NEW, m, sizeof( NEW[ 0 ] ), strcmp );
 
 
     for( i = r = 0; i<m; i++ ){
       j = 0;
       while( NEW[ i ][ j ] != 0 ){
 
         for( ; NEW[ i ][ j ] != 0 && NEW[ i ][ j ] == '/'; j++ );
         for( ; NEW[ i ][ j ] != 0 && NEW[ i ][ j ] != '/'; j++ );
         for( k = 0; k<j; k++ ) a[ k ] = NEW[ i ][ k ];
  
         a[ k ] = 0;
 
         if( !esta( a ) ){
            r++;
            for( k = 0; k<j; k++ ) P[ n ][ k ] = NEW[ i ][ k ];
 	   P[ n ][ k ] = 0;
           n++;
         }
        
       }
 
     } 
 
    printf("%d\n", r );
   }
 
  return 0;
 }

