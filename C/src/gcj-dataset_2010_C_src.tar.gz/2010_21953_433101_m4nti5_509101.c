#include <stdio.h>
 #include <string.h>
 int k,r,n;
 int g[1000];
 long long journeys[1000];
 
 long long moneyFromRoller(){
 	int i,j = 0,groups = 0;
 	long long acc = 0,money;
 	for(i = 0; i < n; ++i){
 		while(acc + g[j] <= k && groups < n){
 			acc += g[j];
 			if(j+1 == n){
 				j = 0;
 			}else
 				j++;
 			++groups;
 		}
 		journeys[i] = acc;
 		acc = 0;
 		groups = 0;
 	}
 	i = 0;
 	money = 0;
 	while(r--){
 		money += journeys[i];
 		if(i+1 == n)
 			i = 0;
 		else
 			++i;
 	}
 	return money;
 }
 
 int main(){
 	int t,cases = 1,i;
 	scanf("%d\n",&t);
 	while(t--){
 		memset(g,0,sizeof g);
 		memset(journeys,0,sizeof journeys);
 		scanf("%d%d%d\n",&r,&k,&n);
 		for(i = 0; i < n; ++i){
 			scanf("%d",&g[i]);
 		}
 		scanf("\n");
 		printf("Case #%d: %lld\n",cases,moneyFromRoller());
 		cases++;
 	}
 }
 

