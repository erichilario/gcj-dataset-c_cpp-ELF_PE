#include<stdio.h>
 #define SIZE 1000
 
 int main()
 {
 int T,R,k,N,G[SIZE],i,j,l,sum,tempsum;
 scanf("%d",&T);
 for(i=1;i<=T;i++)
 	{
 	scanf("%d%d%d",&R,&k,&N);sum=0;
 	for(j=0;j<N;j++) {scanf("%d",&G[j]);sum+=G[j];}
 	if(sum<=k){sum=R*sum; printf("Case #%d: %d\n",i,sum);continue;}
 	//if(N==1&&G[0]>k){continue;}
 	l=0;sum=0;
 	for(j=1;j<=R;j++)
 		{tempsum=0;
 		while(tempsum+G[l]<=k)
 			{/*printf("%d | ",G[l]);*/tempsum=tempsum+G[l];l=(l+1)%N; }
 			/*printf("l\n%d j \n",j);*/
 		sum+=tempsum;	
 		}
 	printf("Case #%d: %d\n",i,sum);
 	}
 return 0;
 }

