#include <stdio.h>
 #include <math.h>
 
 
 main()
 {
     FILE *saida, *entrada;
 
     saida = fopen("texto2.txt", "w");
     entrada = fopen ("A-large.in", "r");
 
     long int T, N, K, i, aux, aux2;
 
     fscanf(entrada, "%ld", &T);
 
     for (i=0; i<T; i++)
     {
        // fflush(stdin);
         fscanf(entrada,"%ld", &N);
         fscanf(entrada, "%ld", &K);
 
         aux2 = pow (2, N);
         aux = K % aux2;
 
 
 
         if (aux == aux2-1 && K!=0)
         fprintf(saida, "Case #%ld: ON\n", i+1);
         else
         fprintf(saida, "Case #%ld: OFF\n", i+1);
 
 
     }
 
 
         fclose(entrada);
         fclose(saida);
 
     return 0;
 }

