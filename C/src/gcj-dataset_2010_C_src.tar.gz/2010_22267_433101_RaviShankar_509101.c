#include <stdio.h>
 #include <stdlib.h>
 
 struct node{unsigned long info;
 struct node *next,*prev;
 };
 typedef struct node NODE;
 struct node *start,*temp,*last;
 unsigned long calculate_revenue(unsigned long trips,unsigned long seats);
 
 void insertatend()
 {temp=(NODE *)malloc(sizeof(NODE));
 scanf("%lu",&temp->info);
 if(start==NULL)
 {temp->next=temp;
 temp->prev=temp;
 start=temp;
 }
 else
 {last=start;
 while(last->next!=start)
 last=last->next;
 temp->next=start;
 start->prev=temp;
 last->next=temp;
 temp->prev=last;
 last=temp;
 }
 }
 void deleteatbegin()
 {if(start==NULL)
 return;
 else
 {NODE *p;
 if(start->next==start)
 {temp=start;
 start=NULL;
 free(temp);}
 else
 {temp=start;
 p=start->prev;
 start=start->next;
 start->prev=p;
 p->next=start;
 free(temp);
 }
 }
 
 }
 
 unsigned long calculate_revenue(unsigned long trips,unsigned long seats)
 {
 unsigned long round_num = 1,size=0,revenue = 0;
 for( round_num=1;round_num<=trips;round_num++)
 {
 temp=start;
 size=0;
 while(size<=seats)
 {
 size = size+temp->info;
 temp = temp->next;
 }
 if(size >seats)
 {
 temp = temp->prev;
 size = size-temp->info;
 }
 
 start = temp;
 revenue = revenue+size;
 }
 return revenue;
 }
 unsigned long calc_rev_less_ppl(unsigned long seats,unsigned long iter,unsigned long trips)
 {
 unsigned long num_ppl = 0;
 temp=start;
 if(start!=NULL)
 {
 while(temp->next!=start)
 {
 num_ppl = num_ppl +temp->info;
 temp=temp->next;
 }
 num_ppl = num_ppl +temp->info;
 //printf("\nnum_ppl = %lu,seats= %lu\n",num_ppl,seats);
 if(num_ppl > seats)
 return 1;
 else
 printf("Case #%lu: %lu\n",iter,num_ppl*trips);
 }
 return 0;
 }
 int main()
 {
 unsigned long T_testcases = 0, N_noOfGroups = 0;;
 unsigned long R_noOfRounds = 0, seats = 0 ;
 unsigned long iter=1,j =0;
 scanf("%lu",&T_testcases);
 
 
 for(iter=1; iter<=T_testcases; iter++  )
 {
 scanf("%lu%lu%lu",&R_noOfRounds, &seats, &N_noOfGroups);
 for(j=0; j < N_noOfGroups; j++)
 insertatend();
 if(calc_rev_less_ppl(seats,iter,R_noOfRounds))
 printf("Case #%lu: %lu\n",iter,calculate_revenue(R_noOfRounds,seats)); 
 for(j=0; j < N_noOfGroups; j++)
 deleteatbegin();
 }
 
 return 0;
 }

