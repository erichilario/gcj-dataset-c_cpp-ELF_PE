#include<stdio.h>
 #include<math.h>
 #define MAX 1000
 
 int main()
 {
   int t,r,k,n,j;
   int c,tot,i,p,e;
   int m;
  // unsigned int n,k,an;
 int g[MAX];
 int st[MAX];
 
   scanf("%d",&t);
 
   for(j=0;j<t;j++)
   {
       scanf("%d %d %d",&r,&k,&n);
         c=0;tot=0;
         p=0;e=0;
         m=1;
       for(i=0;i<n;i++)
         {scanf("%d",&g[i]);
         st[i]=0;
         }
        // printf("R%d  K %d N %d\n",r,k,n);
       for(i=0;i<r;i++)
       {
 
           while(tot+g[p%n]<=k && st[p%n]!=m)
           {
             tot+=g[p%n];
             st[p%n]=m;
             p++;
           }
 
           m++;
           e+=tot;
           tot=0;
 
 
 
       }
       printf("Case #%d: %d\n",j+1,e);
 
 
 
   }
 
     return 0;
 }

