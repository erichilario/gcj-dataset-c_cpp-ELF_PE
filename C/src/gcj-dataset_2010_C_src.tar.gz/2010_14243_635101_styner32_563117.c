#include<stdio.h>
 
 int get_list(char *str, char dir[][100]);
 
 
 typedef struct dir dir_t;
 struct dir
 {
 	char name[100];
 	dir_t *children[100];
 	int children_cnt;
 	int level;
 };
 void print_dir(dir_t *d);
 dir_t dir[1000];
 
 int main(void)
 {
 	int i, j,k,l,cn,result,is_same;
 	int n,m,cnt;
 	int level_cnt[100];
 	char str[101];
 	char temp[100][100];
 	dir_t *temp_dir;
 	int dir_cnt = 0;
 
 	scanf("%d", &cn);
 
 	for(k = 0; k < cn; ++k) 
 	{	
 		scanf("%d%d", &n, &m);
 		memset(temp, 0x00, sizeof(temp));
 		memset(dir, 0x00, sizeof(dir));
 		dir_cnt = 1;
 		result = 0;
 		is_same = 0;
 
 		for(i = 0; i < n; ++i) {
 			scanf("%s", str);
 			cnt = get_list(str+1, temp);
 			temp_dir = &dir[0];
 			
 			for(l = 0; l < cnt; ++l) {
 				for(j = 0; j < temp_dir->children_cnt; ++j) {
 					if( strcmp(temp_dir->children[j]->name, temp[l]) == 0) {
 						temp_dir = temp_dir->children[j];
 						is_same = 1;
 						break;
 					}
 				}
 
 				if(!is_same) {
 					temp_dir->children[temp_dir->children_cnt] = &dir[dir_cnt];
 					temp_dir->children_cnt++;
 					
 					dir[dir_cnt].level = temp_dir->level+1;
 					strcpy(dir[dir_cnt].name, temp[l]);
 
 					temp_dir = &dir[dir_cnt];
 					dir_cnt++;
 				}
 				is_same = 0;
 			}
 		}
 		
 		for(i = 0; i < m; ++i) {
 			scanf("%s", str);
 			cnt = get_list(str+1, temp);
 			temp_dir = &dir[0];
 
 			for(l = 0; l < cnt; ++l) {
 				for(j = 0; j < temp_dir->children_cnt; ++j) {
 					if( strcmp(temp_dir->children[j]->name, temp[l]) == 0) {
 						temp_dir = temp_dir->children[j];
 						is_same = 1;
 						break;
 					}
 				}
 				
 				if(!is_same) {
 					temp_dir->children[temp_dir->children_cnt] = &dir[dir_cnt];
 					temp_dir->children_cnt++;
 					
 					dir[dir_cnt].level = temp_dir->level+1;
 					strcpy(dir[dir_cnt].name, temp[l]);
 
 					temp_dir = &dir[dir_cnt];
 					dir_cnt++;
 					result++;
 				}
 				is_same = 0;
 			}
 		}
 		
 		// print_dir(&dir[0]);
 		printf("Case #%d: %d\n", k+1, result);
 	}
 }
 
 int get_list(char *str, char dir[][100]) {
 	char *temp;
 	int i = 0;
 
 	temp = strtok(str, "/");
 	while(temp != NULL) {
 		strcpy(dir[i], temp);
 		i++;
 		temp = strtok(NULL, "/"); 
 	}
 
 	return i;
 }
 
 void print_dir(dir_t *d) {
 	int i;
 	
 	printf("[%d][%s]->", d->level, d->name);
 	for(i = 0; i < d->children_cnt; ++i) {
 		print_dir(d->children[i]);
 	}
 }

