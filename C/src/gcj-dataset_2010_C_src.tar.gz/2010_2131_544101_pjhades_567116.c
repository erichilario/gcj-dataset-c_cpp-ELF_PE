#include <stdio.h>
 #include <string.h>
 #define N 10
 
 int n, k;
 char red, blue;
 char board[N][N];
 char flag[N][N];
 
 void print() {
 	int i, j;
 	printf("\n");
 	for (i = 0; i < n; i++) {
 		for (j = 0; j < n; j++)
 			printf("%c", board[i][j]);
 		printf("\n");
 	}
 	printf("\n");
 }
 
 void detect(int x, int y, int dir) {
 	int i, j, count = 1;
 	//printf("check %d,%d,  dir=%d\t", x, y, 1 << dir);
 	flag[x][y] |= (1 << dir);
 	if (dir == 0) {
 		i = x + 1;
 		j = y - 1;
 		while (i < n && j >= 0 && !(flag[i][j] >> dir) && board[i][j] == board[x][y]) {
 			++count;
 			++i;
 			--j;
 		}
 		i = x - 1;
 		j = y + 1;
 		while (i >= 0 && j < n && !(flag[i][j] >> dir) && board[i][j] == board[x][y]) {
 			++count;
 			--i;
 			++j;
 		}
 	} else if (dir == 3) {
 		i = x + 1;
 		j = y + 1;
 		while (i < n && j< n && !(flag[i][j] >> dir) && board[i][j] == board[x][y]) {
 			++count;
 			++i;
 			++j;
 		}
 		i = x - 1;
 		j = y - 1;
 		while (i >= 0 && j >= 0 && !(flag[i][j] >> dir) && board[i][j] == board[x][y]) {
 			++count;
 			--i;
 			--j;
 		}
 	} else if (dir == 1) {
 		i = x - 1;
 		j = y;
 		while (i >= 0 && !(flag[i][j] >> dir) && board[i][j] == board[x][y]) {
 			++count;
 			--i;
 		}
 		i = x + 1;
 		j = y;
 		while (i < n && !(flag[i][j] >> dir) && board[i][j] == board[x][y]) {
 			++count;
 			++i;
 		}
 	} else if (dir == 2) {
 		i = x;
 		j = y - 1;
 		while (j >= 0 && !(flag[i][j] >> dir) && board[i][j] == board[x][y]) {
 			++count;
 			--j;
 		}
 		i = x;
 		j = y + 1;
 		while (j < n && !(flag[i][j] >> dir) && board[i][j] == board[x][y]) {
 			++count;
 			++j;
 		}
 	}
 	//printf("count=%d\n", count);
 	if (count == k) {
 		if (board[x][y] == 'R')
 			red = 1;
 		else
 			blue = 1;
 	}
 }
 
 void check() {
 	int i, j, k;
 	memset(flag, 0, sizeof(flag));
 	for (i = 0; i < n; i++) {
 		for (j = 0; j < n; j++) {
 			if (board[i][j] != '.') {
 				for (k = 0; k <= 3; k++)
 					if (!((flag[i][j] >> k) & 1))
 						detect(i, j, k);
 			}
 		}
 	}
 }
 
 void solve() {
 	int i, j, k;
 	red = blue = 0;
 	// rotate
 	for (i = 0; i < n; i++) {
 		for (j = n - 1; j >= 0; j--) {
 			k = j;
 			while (k < n - 1 && board[i][k] != '.' && board[i][k + 1] == '.') {
 				board[i][k + 1] = board[i][k];
 				board[i][k] = '.';
 				++k;
 			}
 		}
 	}
 	//print();
 	check();
 	if (blue && red)
 		printf("Both\n");
 	else if (!blue && !red)
 		printf("Neither\n");
 	else if (blue)
 		printf("Blue\n");
 	else
 		printf("Red\n");
 }
 
 int main() {
 	int test, i, j, t;
 	char line[N];
 	freopen("a.in", "r", stdin);
 	freopen("a.out", "w", stdout);
 	scanf("%d", &test);
 	for (t = 1; t <= test; t++) {
 		scanf("%d%d", &n, &k);
 		for (i = 0; i < n; i++) {
 			scanf("%s", line);
 			for (j = 0; j < n; j++)
 				board[i][j] = line[j];
 		}
 		printf("Case #%d: ", t);
 		solve();
 	}
 	return 0;
 }

