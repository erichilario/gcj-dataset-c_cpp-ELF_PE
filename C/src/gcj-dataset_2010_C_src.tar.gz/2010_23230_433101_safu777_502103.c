#include<stdio.h>
 #include<math.h>
 void main()
 {
 	int t,n,i;
 	long k;
 	FILE *fptr1,*fptr2;
 	fptr1=fopen("input.txt","r");
 	fptr2=fopen("output.txt","w");
 	fscanf(fptr1,"%d",&t);
 	for(i=0;i<t;i++)
 	{
 		fscanf(fptr1,"%d%ld",&n,&k);
 		if(((k+1)%(long)pow(2,n))==0)
 			fprintf(fptr2,"Case #%d: ON\n",i+1);
 		else
 			fprintf(fptr2,"Case #%d: OFF\n",i+1);
 	}
 }
 
 
 
 

