int main()
 {
 	long long t,R,k,N,i,j,groups[1005],earnings,count;
 	int front,base;
 
 	scanf("%lld",&t);
 	for(j=1;j<=t;j++)
 	{
 		scanf("%lld %lld %lld",&R,&k,&N);
 		for(i=1;i<=N;i++)
 			scanf("%lld",&groups[i]);
 		earnings=0;
 		front=1;
 		
 		while(R--)
 		{
 			base=front;
 			count=groups[front];
 			front++;
 			front%=(N+1);
 			if(front==0)
 				front=1;
 			while(front!=base)
 			{
 				//printf("front=%d count=%lld\n",front,count);
 				count+=groups[front];
 				if(count==k)
 				{
 					front++;
 					front%=(N+1);
 					if(front==0)
 						front=1;
 					break;
 				}
 				else if(count>k)
 				{
 					count-=groups[front];
 					break;
 				}
 				front++;
 				front%=(N+1);
 				if(front==0)
 					front=1;
 				
 			}
 			//printf("final front=%d count=%lld\n",front,count);
 			earnings+=count;				
 		}
 
 		printf("Case #%lld: %lld\n",j,earnings);
 	}
 	return 0;
 }

