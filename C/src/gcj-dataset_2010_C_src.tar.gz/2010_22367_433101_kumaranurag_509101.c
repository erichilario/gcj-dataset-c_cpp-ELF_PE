#include<stdio.h>
 #include<math.h>
 
 
 int main()
 {
   long long int T,R,N,K;
   long long int i,j,k,c=0;
   long long int NN[1010],total,tmp[1010],sum;  
   FILE *p=fopen("a.txt","w");
 
   scanf("%lld",&T);
   
   while(T--){
     total=0;
     scanf("%lld%lld%lld",&R,&K,&N);
     for(i=1;i<=N;i++)
       scanf("%lld",&NN[i]);
     while(R--){
       sum=0;
      for(i=1;i<=N;i++){
          if(sum+NN[i]<=K)
             sum=sum+NN[i];
          else
             break;
        }
      
      total=total+sum;
      if(i<=N){
        k=0;  
        for(j=i;j<=N;j++)
         tmp[++k]=NN[j];
        for(j=1;j<i;j++)
         tmp[++k]=NN[j];
        for(j=1;j<=N;j++)
         NN[j]=tmp[j];
        }
      }
     fprintf(p,"Case #%lld: %lld\n",++c,total);
     
    }
    fclose(p);
 return 0;
 }

