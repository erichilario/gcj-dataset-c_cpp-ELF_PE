#include <stdio.h>
 #include <math.h>
 
 int main(int argc, char **argv) {
 	char c;
 	int T, N, K;
 
 	T = 0;
 	while((c = getchar()) != '\n')
 		T = T*10 + c - '0';
 
 	int i;
 	for(i = 0; i < T; ++i) {
 	
 		N = 0;
 		while((c = getchar()) != ' ') 
 			N = N*10 + c - '0';	
 		
 		K = 0;
 		while((c = getchar()) != '\n' && c != EOF)
 			K = K*10 + c - '0';
 		
 		int num = pow (2,N);
 
 		printf("Case #%d: ", i+1);
 	
 		if(K%num == num-1)
 			printf("ON\n");
 		else
 			printf("OFF\n");
 	}
 }

