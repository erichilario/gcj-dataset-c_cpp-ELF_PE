#include<stdio.h>
 #include<math.h>
 
 #define SNAP_ON "ON"
 #define SNAP_OFF "OFF"
 
 int main(int argc, char *argv[])
 {
 	unsigned long int K,temp;
 	unsigned int N,T,i;
 	FILE *fp_in, *fp_out;
 	
 	if(1 == argc)
 	{
 		printf("Enter input and output filenames!!");
 		return 0;
 	}
 	
 	fp_in = fopen(argv[1],"r");
 	fp_out = fopen(argv[2],"w");
 
 	fscanf(fp_in,"%d",&T);
 	for(i=0; i<T; i++)
 	{
 // Scanning input
 		fscanf(fp_in,"%d%d",&N,&K);
 // Processing input
 		temp = (unsigned long int)pow(2,N);
 		if(K == temp - 1)
 		{
 			fprintf(fp_out,"Case #%d: %s\n",i+1,SNAP_ON);
 		}
 		else if (0 == ((K- temp + 1) % temp))
 		{
 			fprintf(fp_out,"Case #%d: %s\n",i+1,SNAP_ON);
 		}
 		else
 		{
 			fprintf(fp_out,"Case #%d: %s\n",i+1,SNAP_OFF);
 
 		}
 	}
 
 	return 0;	
 }

