/*
     Google Code Jam 2010
     File Fix-it
     rodrigo.rfc@uol.com.br
     ansi C - C89
     usage: program.exe < input_file > output_file
 */
 
 # include <stdio.h>
 
 typedef char t_a_name [ 100 ] ;
 typedef char t_a_path [ 100 ] ;
 
 struct t_node
 {
     struct t_node * a_sibling ;
     struct t_node * a_children ;
     t_a_name a_name ;
 } ;
 typedef struct t_node t_node ;
 
 int main ( void )
 {
     t_node root = { NULL , NULL , { '/' , '\0' } } ;
     t_node * a_dir = & root , * a_new , * a_last ;
     int t = 0 , tt = 0 , n = 0 , m = 0 , count = 0 ;
     t_a_name a_name = { '\0' } ;
     char c = '\0' ;
     
     scanf ( "%d%*c" , & t ) ;
     tt = t ;
     while ( t -- )
     {
         count = 0 ;
         root . a_sibling = NULL ;
         root . a_children = NULL ;
         memset ( root . a_name , '\0' , sizeof ( char ) ) ;
         scanf ( "%d %d%*c" , & n , & m ) ;
         while ( n -- )
         {
             a_dir = & root ;
             getchar ( ) ;
             do
             {
                 memset ( a_name , '\0' , sizeof ( char ) ) ;
                 scanf ( "%[^/\n]%c" , a_name , & c ) ;
                 if ( a_dir -> a_children == NULL )
                 {
                     a_new = (t_node *) calloc ( 1 , sizeof ( t_node ) ) ;
                     strcpy ( a_new -> a_name , a_name ) ;
                     a_dir -> a_children = a_new ;
                     a_dir = a_dir -> a_children ;
                 } else {
                     a_dir = a_dir -> a_children ;
                     while ( a_dir != NULL )
                     {
                         if ( strcmp ( a_dir -> a_name , a_name ) == 0 )
                         {
                             goto flag1 ;
                         }
                         a_last = a_dir ;
                         a_dir = a_dir -> a_sibling ;
                     }
                     a_dir = a_last ;
                     a_new = (t_node *) calloc ( 1 , sizeof ( t_node ) ) ;
                     strcpy ( a_new -> a_name , a_name ) ;
                     a_dir -> a_sibling = a_new ;
                     a_dir = a_dir -> a_sibling ;
                     flag1 :
                 }
             }
             while ( c != '\n' ) ;
         }
         while ( m -- )
         {
             a_dir = & root ;
             getchar ( ) ;
             do
             {
                 memset ( a_name , '\0' , sizeof ( char ) ) ;
                 scanf ( "%[^/\n]%c" , a_name , & c ) ;
                 if ( a_dir -> a_children == NULL )
                 {
                     a_new = (t_node *) calloc ( 1 , sizeof ( t_node ) ) ; count ++ ;
                     strcpy ( a_new -> a_name , a_name ) ;
                     a_dir -> a_children = a_new ;
                     a_dir = a_dir -> a_children ;
                 } else {
                     a_dir = a_dir -> a_children ;
                     while ( a_dir != NULL )
                     {
                         if ( strcmp ( a_dir -> a_name , a_name ) == 0 )
                         {
                             goto flag2 ;
                         }
                         a_last = a_dir ;
                         a_dir = a_dir -> a_sibling ;
                     }
                     a_dir = a_last ;
                     a_new = (t_node *) calloc ( 1 , sizeof ( t_node ) ) ; count ++ ;
                     strcpy ( a_new -> a_name , a_name ) ;
                     a_dir -> a_sibling = a_new ;
                     a_dir = a_dir -> a_sibling ;
                     flag2 :
                 }
             }
             while ( c != '\n' ) ;
         }
         printf ( "Case #%d: %d\n" , tt - t , count ) ;
     }
     return 0 ;
 }

