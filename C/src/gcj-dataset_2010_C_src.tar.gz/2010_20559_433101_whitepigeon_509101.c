#include<stdio.h>
 int main()
 {
 	int size[1001];
 	int max[1001];
 	int index[1001];
 	int R;
 	int k;
 	int N;
 	int test;
 	int start,end;
 	long long int count;
 	long long int total;
 	int f=0;
 	int i;
 	scanf("%d",&test);
 	while(test--)
 	{
 		scanf("%d%d%d",&R,&k,&N);
 		for(i=0;i<N;i++)
 		{
 			scanf("%d",&size[i]);
 		}
 		start=0;
 		count=0;
 		total=0;
 		int j=0;
 		for(i=0;i<N;i++)
 		{
 			j=i;
 			int l=j;
 			while(count + size[j] <= k)
 			{
 				count+=size[j];
 				j++;
 				j=j%N;
 				if(l==j)
 				{
 					break;
 				}
 			}
 			max[i]=count;
 			index[i]=j;
 		//	printf("%d %d\n",max[i],index[i]);
 			count=0;
 		}
 		int store=0;
 		for(i=0;i<R;i++)
 		{
 			total+=max[store];
 			store=index[store];
 		}
 		printf("Case #%d: %lld\n",f+1,total);
 		f++;
 		total=0;
 	}
 	return 0;
 }

