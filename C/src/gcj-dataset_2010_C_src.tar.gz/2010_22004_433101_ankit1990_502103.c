#include<stdio.h>
 int main()
 {
  int t ;
  int n ;
  int k ;
  int l = 0 ;
  scanf("%d",&t) ;
  while( t > 0 ) 
  {
   l++ ;
   t-- ;
   scanf("%d %d",&n,&k) ;
   if( k % ( 1 << n ) == ( ( 1 << n ) - 1 ) )
   {
    printf("Case #%d: ON\n",l) ;
   }
   else
   { 
    printf("Case #%d: OFF\n",l) ;
   }
  }
 }

