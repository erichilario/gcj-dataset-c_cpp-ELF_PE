#include <stdio.h>
 
 int main(void)
 {
    long long v[30];
    int n, k, t, i;
 
    v[0] = 1;
    for ( i = 1 ; i < 30 ; i++ )
    {
       v[i] = v[i-1]*2 + 1;
    }
    scanf("%d", &t);
    for (i = 0 ; i < t ; i++ )
    {
       scanf("%d %d",&n, &k);
       if ( k < v[n-1] )
          printf("Case #%d: OFF\n", i+1);
       else if (i == v[n-1] )
          printf("Case #%d: ON\n", i+1);
       else
          printf("Case #%d: %s\n", i+1, ( ( (k - v[n-1]) % (v[n-1]+1) ) == 0)?"ON":"OFF");
    }
 
    return 0; 
 }
