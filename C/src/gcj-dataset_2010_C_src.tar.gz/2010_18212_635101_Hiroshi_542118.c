#include <stdio.h>
 
 static int get_C(void)
 {
 	char buf[80];
 
 	fgets(buf, 80, stdin);
 
 	return atoi(buf);
 }
 
 static int N, K, B, T;
 static int pos[50];
 static int ini[50], spd[50];
 static int una[50], cup[50];
 static int rem[50], hit[50];
 static int tick;
 
 static void swap(int n)
 {
 	int i, bk;
 
 	for (i = n + 1; i < N; i++) {
 		if (pos[n] != pos[i])
 			break;
 	}
 	--i;
 
 	//fprintf(stderr, "swap %d,%d\n", n, i);
 
 #define ss(f) do { \
 	bk = f[i]; f[i] = f[n]; f[n] = bk; \
 } while (0)
 	ss(ini); ss(spd);
 	ss(una); ss(cup);
 	ss(rem); ss(hit);
 }
 
 #define SZ	(4096000)
 static char	line[SZ];
 
 static void init(void)
 {
 	char *p, *next;
 	int i;
 
 	fgets(line, SZ, stdin);
 	p = line;
 	for (i = 0; i < N; i++) {
 		ini[i] = strtoul(p, &next, 10);
 		p = next;
 	}
 	fgets(line, SZ, stdin);
 	p = line;
 	for (i = 0; i < N; i++) {
 		spd[i] = strtoul(p, &next, 10);
 		p = next;
 	}
 }
 
 static int check_catchup(void)
 {
 	int i, cnt;
 	int sec;
 
 	cnt = 0;
 	for (i = 0; i < N; i++) {
 
 		sec = (B - ini[i]) / spd[i];
 		una[i] = 0;
 		if (sec > T) {
 			una[i] = 1;
 			++cnt;
 		}
 		rem[i] = T - sec;
 	}
 
 	if (N - cnt < K)
 		return 1;
 
 	cnt = 0;
 	for (i = 1; i < N; i++) {
 		cup[i - 1] = -1;
 		if (spd[i - 1] <= spd[i]) {
 			++cnt;
 			continue;
 		}
 		sec = (ini[i] - ini[i - 1]) / (spd[i - 1] - spd[i]);
 		cup[i - 1] = sec;
 		/* never catches up in Tsec */
 		if (sec > T)
 			++cnt;
 	}
 	if (cnt == N)
 		return 2;
 
 	for (i = 0; i < N; i++)
 		pos[i] = ini[i];
 
 	return 0;
 }
 
 static int step(int *y)
 {
 	int i, k, swp;
 
 //fprintf(stderr, "tick=%d\n", tick);
 	k = 0;
 	for (i = 0; i < N; i++) {
 		pos[i] += spd[i];
 //fprintf(stderr, "pos[%d]:%d:una=%d\n", i, pos[i], una[i]);
 		if (pos[i] >= B)
 			++k;
 	}
 	if (k >= K)
 		return 1;
 	for (i = 1; i < N; i++) {
 		hit[i - 1] = 0;
 		if (pos[i - 1] >= pos[i]) {
 			pos[i - 1] = pos[i];
 			hit[i - 1] = 1;
 		}
 	}
 
 	k = 0;
 	swp = 0;
 	for (i = N - 1; i > 0 && k < K; i--) {
 		if (hit[i - 1] && una[i - 1] == 0) {
 			++k;
 			++swp;
 			swap(i - 1);
 			continue;
 		}
 	}
 
 	*y += swp;
 
 	return k >= K;
 }
 
 static void solve(int x)
 {
 	char buf[1024];
 	int i, y;
 
 	fgets(buf, 1024, stdin);
 	sscanf(buf, "%d %d %d %d", &N, &K, &B, &T);
 
 	init();
 	y = check_catchup();
 	switch(check_catchup()) {
 	case 1:
 		y = -1;
 		goto out;
 	case 2:
 		y = 0;
 		goto out;
 	}
 
 	y = 0;
 	tick = 0;
 	for (tick = 1; tick <= T; tick++) {
 		if (step(&y))
 			break;
 	}
 out:
 	printf("Case #%d: ", x);
 	if (y >= 0)
 		printf("%d\n", y);
 	else
 		printf("IMPOSSIBLE\n");
 }
 
 int main(int argc, char **argv)
 {
 	int i, C;
 
 	C = get_C();
 	for (i = 1; i <= C; i++)
 		solve(i);
 
 	return 0;
 }

