#include <stdio.h>
 #define MAX 10
 
 
 int main(int argc, char *argv[])
 {
     FILE *fp, *output;
     int power[MAX];
     int state[MAX];
     int total;
     int clicks;
     int cycles, loop;
     char str[100];
     char *value, *abcd;
     int R, k, N, i, j, l, money, current;
     int g[MAX], queue[MAX], queue_cur[MAX];
 
     fp = fopen("in", "r");
     if(fp == NULL)
     {
         printf("Failed to open A.in file\n");
 	return -1;
     }
 
     output = fopen("out", "w");
     if(output == NULL)
     {
         printf("Failed to open A.out file\n");
 	return -1;
     }
 
     cycles = atoi(fgets(str, 100, fp));
     printf("Cycles = %d\n", cycles);
 
 
     for(loop = 0; loop < cycles; loop++)
     {
 
         fgets(str, 100, fp);
         value = (char*)strtok_r(str, " ", &abcd);
         R = atoi(value);
         value = (char*)strtok_r(NULL, " ", &abcd);
         k = atoi(value);
 	value = (char*)strtok_r(NULL, " ", &abcd);
         N = atoi(value);
 	fgets(str, 100, fp);
         value = (char*)strtok_r(str, " ", &abcd);
         g[0] = atoi(value);
 
 	printf("R-%d, k-%d, N-%d\n", R, k, N);
         printf("G - %d",g[0]); 
 	for(i=1; i< N; i++)
 	{
             value = (char*)strtok_r(NULL, " ", &abcd);
             g[i] = atoi(value);
 	    printf(", %d",g[i]);
 	}
 
 	printf("\n");
 
 	for(i=0; i<N; i++)
 	    queue[i] = g[i];
 
 	money = 0;
 	for(i=0; i<R; i++)
  	{
             current = 0;
 	    for(j=0; j<N; j++)
 	    {
 		if((current + queue[j]) <= k)
                     current += queue[j];
 		else
 		    break;
 	    }
 
 	   money += current;            
            for(l=0; l<N; l++)
 		queue_cur[l] = queue[l]; 
 
 
            for(l=0; l<N; l++, j++)
 		queue[l] = queue_cur[j%N]; 
 
 	   printf("Money = %d, Queue after %d ride -", current, i); 
            printf("%d",queue[0]);
 
 	   for(l=1; l<N; l++)
               printf(", %d",queue[l]);
 	    printf("\n");
 	}
 	printf("Total money - %d\n", money);
         fprintf(output, "Case #%d: %d\n", loop+1, money);
 
     }
 
     fclose(fp);
     fclose(output);
 }

