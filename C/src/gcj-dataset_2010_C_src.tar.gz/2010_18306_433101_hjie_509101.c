#include <stdio.h>
 #include <stdlib.h>
 
 typedef unsigned long long u_int64;
 
 typedef struct group {
     unsigned int index;
     unsigned int steps;
     u_int64 value;
     short is_loop;
     u_int64 loop_value;
 }group_t;
 
 int in_array[1001];
 group_t all_groups[1001];
 
 void init(int *array, int n, int max)
 {
     int i, j;
     int sum, sub;
     int step;
     if (n == 1) {
         all_groups[1].index = 1;
         all_groups[1].steps = 1;
         all_groups[1].value = array[1];
         all_groups[1].is_loop = 1;
         all_groups[1].loop_value = array[1];
         return ;
     }
 
     for (i = 1; i <= n; ++i) {
         sum = 0;
         step = 0;
         j = i;
         all_groups[i].index = i;
         while (sum <= max && step < n) {
             j = j % n;
             if (j == 0) j = n;
             if (sum + array[j] > max)
                 break;
             sum += array[j];
             sub = array[j];
             step++;
             j++;
         }
         all_groups[i].steps = step;
         all_groups[i].value = sum;
         all_groups[i].is_loop = 0;
         all_groups[i].loop_value = 0l;
     }
     // fast up
     int index;
     u_int64 loop_sum;
     for (i = 1; i <= n; ++i) {
         step = 1;
         index = i;
         loop_sum = all_groups[i].value;
         while (step != n + 1) {
             index += all_groups[index].steps;
             index = index % n;
             if (index == 0) index = n;
             if (index == i) {
                 // loop
                 all_groups[i].is_loop = 1;
                 break;
             }
             loop_sum += all_groups[index].value;
             step++;
         }
         if (all_groups[i].is_loop) {
             all_groups[i].is_loop = step;
             all_groups[i].loop_value = loop_sum;
         }
     }
 }
 
 u_int64 total_earn(int rounds, int n)
 {
     u_int64 result = 0L;
     int r, i;
     i = 1;
     for (r = rounds; r > 0; ) {
         if (all_groups[i].is_loop) {
             if (r >= all_groups[i].is_loop) {
                 result += (r / all_groups[i].is_loop) * all_groups[i].loop_value;
                 r = r % all_groups[i].is_loop;
             }
             if (r == 0) break;
         }
         result += all_groups[i].value;
         i += all_groups[i].steps;
         i = i % n;
         if (i == 0) i = n;
         --r;
     }
     return result;
 }
 
 int main(int argc, char* argv[])
 {
     int t;
     int r, k, n;
     int i, j;
     scanf("%d", &t);
     for (i = 1; i <= t; ++i) {
         scanf("%d %d %d", &r, &k, &n);
         for (j = 1; j <= n; ++j)
             scanf("%d", &in_array[j]);
         init(in_array, n, k);
         printf("Case #%d: %llu\n", i, total_earn(r, n));
     }
     return 0;
 }

