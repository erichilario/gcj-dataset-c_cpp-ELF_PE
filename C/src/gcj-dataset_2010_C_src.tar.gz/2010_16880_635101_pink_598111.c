#include <stdio.h>
 
 void main(void) 
 {
 	FILE *in = fopen("./input.txt", "r");
 	FILE *out = fopen("./output.txt", "w");
 	int loopcount;
 	int count = 0;
         int n;
         int i, j, l;
         unsigned long long ans = 0;
 	fscanf(in, "%d", &count);
 	for (loopcount = 1;loopcount<=count;loopcount++) {
 	    fscanf(in, "%d", &n);
             i = 0;
             j = 1;
             for (l = 1; l < n ; l++) {
                  ans = i + j;
                  i = j;
                  j = ans;
             }
             
             fprintf(out, "Case #%d: %llu\n", loopcount, ans); 
 	}
 	fclose(in);
 	fclose(out);
 
 }

