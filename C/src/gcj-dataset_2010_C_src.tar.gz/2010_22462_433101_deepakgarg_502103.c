#include<stdio.h>
 
 int main(){
  
    int t,n,k;
    int m,l,i,x;
    
    scanf("%d",&t);
    
    for(i=1;i<=t;i++){
       scanf("%d",&n);                 
       scanf("%d",&k);
       
       printf("Case #%d: ",i);
       m=pow(2,n);
       l=m-1;
       if(k<l){
        printf("OFF\n");
       }
       else if(k==l){
         printf("ON\n");     
       }             
       else{
          x=k%m;
          if(x==l){
               printf("ON\n",l);     
          }    
          else{
               printf("OFF\n");                   
          }
       }    
    }
     
    return 0;
 }

