#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <errno.h>
 
 #define IN_FILE	"C-small.in"
 #define OU_FILE	"C-small.ou"
 #define FREE(x) if(x) {free(x); x=NULL;}
 #define BUFSZ	9*1000+1
 
 int main(){
 
         FILE *pinf, *pouf;
         char buf[BUFSZ];
 	char *p, *q;
 	int i, j, t;
 	int T;	//cases 1<=T<=50
 	unsigned long R;	//rides 1<=R<=10E8
 	unsigned long k;	//capacity 1<=k<=10E9
 	int N;	//number of groups 1<=N<=1000
 	unsigned long euros;	//total of euros
 	unsigned long *pgroups;
 	unsigned long g;	//group
 	unsigned long people;	//people in this ride
 
         pinf = fopen(IN_FILE, "r");
         pouf = fopen(OU_FILE, "w");
         if(pinf && pouf){
 
                 fgets(buf, BUFSZ, pinf);
                 sscanf(buf, "%d", &T);
 
                 for(t = 1; t <= T; t++){
 	                fgets(buf, BUFSZ, pinf);
         	        sscanf(buf, "%lu %lu %d", &R, &k, &N);
 
 			//printf("Case %d/%d\nR rides: %lu\nk capacity: %lu\nN groups: %d\n\n", t, T, R, k, N);
 			pgroups = (unsigned long*)calloc(N, sizeof(unsigned long));
 			if(pgroups){
 				//set group array
 		                fgets(buf, BUFSZ, pinf);
 				p = strdup(buf);
 				for(i = 0; i < N; i++){
 					if(i == 0)	q = strtok(p, " ");
 					else 	q = strtok(NULL, " ");
 					if(q){
 						sscanf(q, "%lu", &pgroups[i]);
 						//printf("%lu ", pgroups[i]);			
 					} else break;
 				}
 				//printf("\n");
 				FREE(p);
 				
 /////////////////////////////////////////////// the real thing...
 				euros = 0;
 				i = 0;
 				for(; R > 0; R--){
 					people = 0;
 					j = 0;
 					while((people + pgroups[i] <= k) && (j < N)){
 						people += pgroups[i];
 						if(i == (N-1))	i = 0;
 						else i++;
 						j++;
 					}
 					euros += people;
 				}	// for rides
 ///////////////////////////////////////////////
 				FREE(pgroups);
 			}	// if groups
 			sprintf(buf, "Case #%d: %lu\n", t, euros);
 			fputs(buf, pouf);
 
 		}	//for T cases
 		fclose(pinf);
 		fclose(pouf);
         } else printf("Error leyendo archivo: %s\n", strerror(errno));
 
         return 1;
 }
 

