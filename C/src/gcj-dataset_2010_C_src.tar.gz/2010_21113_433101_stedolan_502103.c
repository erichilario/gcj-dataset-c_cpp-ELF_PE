#include <stdio.h>
 #define g(x) scanf("%d",&x)
 int n,k,t,l;int main(){g(t);while(t+1-++l)g(n),g(k),printf("Case #%d: %s\n",l,~k&(1<<n)-1?"OFF":"ON");}

