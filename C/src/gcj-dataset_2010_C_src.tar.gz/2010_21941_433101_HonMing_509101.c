#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 int pass[1000];
 int optimal[1000][2];
 
 int main()
 {
     int num, r, k, n, i, j;
     long long passtotal;
 
     scanf("%d", &num);
 
     for(i = 1; i <= num ; i++)
     {
         scanf("%d %d %d", &r, &k, &n);
         passtotal = 0;
         memset(optimal, 0, 1000 * 2 *sizeof(int));
         for(j = 0 ; j < n ; j++)
         {
             scanf("%d", &(pass[j]));
             passtotal += pass[j];
         }
 
         if(passtotal <= (long long)k)
             printf("Case #%d: %lld\n", i, passtotal*((long long)r));
         else
         {
             int index = 0;
             int tmp;
             passtotal = 0;
             for(j = 0; j < r; j++)
             {
                 if(optimal[index][0] == 0)
                 { // DP: no optimal found, find it now
                     int tindex = index;
                     tmp = 0;
                     while(tmp < k)
                     {
                         if(tmp + pass[index] > k)
                             break;
                         else
                         {
                             tmp += pass[index];
                             index = (index + 1) % n;
                         }
                     }
                     passtotal += tmp;
                     optimal[tindex][0] = index;
                     optimal[tindex][1] = tmp;
                 }
                 else
                 {
                     passtotal += optimal[index][1];
                     index = optimal[index][0];
                 }
                 //printf("passtotal:%lld, round:%d\n", passtotal, j);
             }
             printf("Case #%d: %lld\n", i, passtotal);
         }
     }
 }

