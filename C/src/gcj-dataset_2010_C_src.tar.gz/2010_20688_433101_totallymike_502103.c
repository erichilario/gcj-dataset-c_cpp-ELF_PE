#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct snapper{
   int on; // 1 or 0.  State.
   int powered; // 1 or 0.  Powered status.
   struct snapper *prev, *next;
 } snapper;
 
 char *bulb_on (snapper *bulb) {
   if (bulb->on)
     return "ON";
   else
     return "OFF";
 }
 
 void snap(snapper *socket, snapper *bulb) {
   snapper *temp = socket->next;
   snapper *temp2;
   
   if (temp->on == 0) {
     temp->on = 1;
     while (temp->next != NULL) {
       if (temp->on == 1) {
 	if (temp->powered == 1) {
 	  temp->next->powered = 1;
 	}
       }
       temp = temp->next;
       
     }
   } else if (temp->on == 1) {
     while (temp->next != NULL && temp->next->powered == 1) {
       temp = temp->next;
     }
     while (temp != socket) {
       if (temp->on == 0) {
 	temp->on = 1;
       } else if (temp->on == 1) {
 	if (temp->next != NULL)
 	  temp->next->powered = 0;
 	temp->on = 0;
       }
       temp = temp->prev;
     }
   }
   socket->next->powered = 1;
   if (bulb->powered == 1) {
     bulb->on = 1;
   } else if( bulb->powered == 0) {
     bulb->on = 0;
   }
 }
 
 
 int main() {
   int i, j; // Counters.
   int t; // Test cases.
   snapper *socket = (snapper *) malloc(sizeof(snapper));
   snapper *bulb = (snapper *) malloc(sizeof(snapper));
   snapper *temp, *temp2;
 
   socket->on = 1;
   socket->powered = 1;
   socket->prev = NULL;
 
   bulb->next = NULL;
 
   // Receive number of test cases.  First line.
   scanf("%d", &t);
   
   // Create array big enough to hold the test cases.
   int n[t], k[t]; //n=snappers, t=snaps.
   
   // Create list of answers for easy printing.
   char *answers[t];
 
   // Populate test case array.
   for (i = 0; i < t; i++) {
     scanf("%d %d", &n[i], &k[i]);
   }
   
   // Begin processing array.
   for (i = 0; i < t; i++) {
     bulb->powered = 0;
     bulb->on = 0;
     temp = socket;
     temp->next = (snapper *) malloc(sizeof(snapper));
     temp = temp->next;
     temp->prev = socket;
     temp->powered = 1;
     for(j = 1; j < n[i]; j++) {
       temp->next = (snapper *) malloc(sizeof(snapper));
       temp2 = temp->next;
       temp2->prev = temp;
       temp = temp->next;
     }
 
     // Link final snapper to bulb.
     temp->next = bulb;
     bulb->prev = temp;
     for (j = 0; j < k[i]; j++) {
       snap(socket, bulb);
     }
     answers[i] = bulb_on(bulb);
   }
   for (i = 0; i < t; i++) {
     printf("Case #%d: %s\n", i + 1, answers[i]);
   }
   
   return 0;
 }
 

