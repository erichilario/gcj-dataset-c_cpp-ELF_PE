#include <stdio.h>
 
 int main() {
 
     int t, r, k, n;
     
     int g[1001];
     int i;
     int kase;
     int pos;
     
     int j,spaceleft;
     
     int newpos[1001];
     int profit[1001];
     
     int totalprofit=0;
     
     scanf( "%d", &t );
     
     for (kase=1; kase<=t; kase++) {
         scanf( "%d %d %d", &r, &k, &n );
         for (i=0; i<n; i++) {
             scanf("%d", &g[i]);
         }
         
         /* pre-process the groups */
         for (i=0;i<n;i++) {
             profit[i]=0;
             spaceleft = k;
             j=i;
             while (spaceleft >= g[j]) {
                 profit[i] += g[j];
                 spaceleft -= g[j];
                 j=(j+1)%n;
                 if (j==i) {
                     break;
                 }
             }
             newpos[i]=j;
             
             //printf("%d: %d %d\n",i,profit[i],j);
         }
         
         
         
         /* Now run through each rollercoaster run */
         totalprofit = 0;
         j=0;
         for (i=0; i<r; i++) {
             totalprofit += profit[j];
             j = newpos[j];
         }
         
         printf("Case #%d: %d\n", kase, totalprofit);
     }
 }
