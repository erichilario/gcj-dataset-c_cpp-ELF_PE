#include <stdio.h>
 #include <stdlib.h>
 
 #define true 1
 #define false 0
 
 typedef unsigned char bool;
 
 int groups[11];
 
 int main()
 {
    int T, cont = 0;
    scanf("%d", &T);
    
    while(T--)
    {
       int runs, max, n, euros, totalGroup;
       int i;
       
       scanf("%d %d %d", &runs, &max, &n);
       
       totalGroup = 0;
       for(i = 0; i < n; i++)
       {
          scanf("%d", &groups[i]);
          totalGroup += groups[i];
       }
       
       if(totalGroup > max)
       {
          euros = 0;
          i = 0;
          while(runs--)
          {
             int cur = 0;
             for( ; ; i++)
             {
                if(i == n)
                   i = 0;
                
                if(cur + groups[i] <= max)
                   cur += groups[i];
                else
                   break ;
             }
             
             euros += cur;
          }
       }
       else
       {
          euros = runs*totalGroup;
       }
       
       printf("Case #%d: %d\n", ++cont, euros);
    }
    
 return 0;
 }

