#include <stdio.h>
 #include <stdlib.h>
 
 int C,N,K,B,T;
 
 void run(int C,int N,int K, int B, int T);
 typedef struct
 {
 	int ID;
 	int Position;
 	int Speed;
 }chick;
 
 void main()
 {
 	int i;
 	scanf("%d",&C);
 	for(i = 0 ; i < C ; i++)
 	{
 		scanf("%d %d %d %d",&N,&K,&B,&T);
 		run(i+1,N,K,B,T);
 	}
 }
 
 void run(int C,int N,int K, int B, int T)
 {
 	chick* chicks;
 	char buffer[33];
 
 	int i,j,OK;
 	int swaps = 0;
 	int count = 0;
 	
 	chicks = (chick*)calloc(N,sizeof(chick));
 	
 	
 	for(i  = 0 ; i < N; i++)
 	{
 		chicks[i].ID = i;
 		scanf("%d",&(chicks[i].Position));
 	}
 
 	for(i  = 0 ; i < N; i++)
 	{
 		
 		scanf("%d",&(chicks[i].Speed));
 		if(B - chicks[i].Position <= chicks[i].Speed * T)
 		{
 			count++;
 		}
 	}
 
 	if(count < K)
 	{
 		printf("Case #%d: IMPOSIBLE\n",C);
 		return;
 	}
 
     count  = 0;
 
 	for(i = 0 ; i < N ; i++)
 	{
 		chick c = chicks[i];
 		int toGO = B - c.Position;
 		double vRelative = (double)c.Speed;
 		if(toGO <= vRelative * T)
 		{
 			for(j = 0 ; j < N ; j++)
 			{
 				chick oc = chicks[j];
 				if(oc.ID == c.ID)
 					continue;
 
 				if(oc.Position > c.Position && oc.Speed < vRelative)
 				{
 					if((toGO / vRelative) <= (B - oc.Position) / oc.Speed)
 					{
 						swaps += 1;
 						vRelative = (((c.Speed) * toGO) - oc.Speed) / (double)toGO;
 					}
 				}
 			}
 		}
 	}
 
 	if(count < K)
 	{
 		printf("Case #%d: IMPOSIBLE\n",C);
 		return;
 	}
 	
 	free(chicks);
 
 	printf("Case #%d: %d\n",C,swaps);
 
 	return;
 }
