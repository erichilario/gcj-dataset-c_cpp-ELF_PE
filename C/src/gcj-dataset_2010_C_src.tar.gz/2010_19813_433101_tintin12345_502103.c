#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 
 int main()
 {
 	int no,i,n;
 	long s,k;
 	scanf("%d",&no);
 	for(i=0;i<no;i++)
 	{
 		scanf("%d",&n);
 		scanf("%ld",&k);
 		printf("Case #%d: ",i+1);
 		s=(long)pow(2,n);
 		if(k%s==(s-1))
 			printf("ON\n");
 		else
 			printf("OFF\n");
 
 	}
 return 0;
 }

