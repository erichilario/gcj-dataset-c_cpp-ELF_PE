#include <stdio.h>
 long long _power(long long n){
     long long ll = 1;
     long long i;
     for(i = 0 ; i < n ; i++)
 	ll *=2;
     return ll;
 }
 
 int isOn(long long n, long long k){
     long long cycle;
     long long on;
     cycle = _power(n);
     on = cycle -1;
     if((k%cycle) == on)
 	return 1;
     return 0;
 }
 
 int main(void){
     int t;
     long long n, k;
     int i, j;
 
     scanf("%d", &t);
 
     for(i = 0 ; i < t;  i++){
 	printf("Case #%d:" , i+1);
 	scanf("%lld %lld", &n, &k);
 	if(isOn(n, k))
 	    printf(" ON\n");
 	else
 	    printf(" OFF\n");
     
     }
 
 
     return 0;
 }

