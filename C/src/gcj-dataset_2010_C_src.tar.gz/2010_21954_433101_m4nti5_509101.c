#include <stdio.h>
 #include <string.h>
 
 int r,k,n,g[1000];
 
 long long countMoney(){
 	int i = 0,j;
 	long long money = 0, acc;
 	while(r--){
 		j = 0;
 		acc = 0;
 		while(acc+g[i] <= k && j < n){
 			acc += g[i];
 			if(i+1 == n)
 				i = 0;
 			else
 				++i;
 				++j;
 		}
 		money += acc;
 	}
 	return money;
 }
 
 int main(){
 	int t,cases = 1,i;
 	scanf("%d\n",&t);
 	while(t--){
 		memset(g,0,sizeof g);
 		scanf("%d%d%d\n",&r,&k,&n);
 		for(i = 0; i < n; ++i){
 			scanf("%d",&g[i]);
 		}
 		scanf("\n");
 		printf("Case #%d: %lld\n",cases,countMoney());
 		cases++;
 	}
 
 }
 

