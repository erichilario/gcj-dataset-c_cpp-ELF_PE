#include <stdio.h>
 #include <stdlib.h>
 #include<string.h>
 
 struct node{
 int size;
 int grpNum;
 int sittingChance;
 int loopNumberForFirstChance;
 int peopleYet;
 struct node *next;
 };
 struct node* listStart;
 	struct node* listEnd;
 	int R,K,totalPeople;
 void addGroup(int data, struct node** listStart, struct node** listEnd){
 //printf("Inside add Node\n");
 	struct node* temp;
 	struct node* newNode = malloc(sizeof(struct node));
 	newNode->size = data;
 	newNode->next = NULL;
 	newNode->grpNum = size(*listStart);
 	newNode->sittingChance = 0;
 	newNode->peopleYet = 0;
 	newNode->loopNumberForFirstChance = 0;
 	if(*listStart==NULL && *listEnd==NULL){
 		*listStart = newNode;
 		*listEnd = newNode;
 		//printf("Node added first time\n");
 	}
 	else{
 		temp = *listEnd;
 		while(temp->next!=NULL){
 			temp = temp->next;
 		}
 		temp->next = newNode;
 		//printf("Node added \n");
 		*listEnd = newNode;
 	}
 	
 	//printf("List start: %d, list end: %d\n",(*listStart)->size,(*listEnd)->size );
 }
 
 
 
 void listRotate(struct node** listStart, struct node** listEnd){
 	
 	if(size(*listStart)<2)
 	{
 		//printf("No rotation possible. either 1 or 0 node\n");
 		return;
 	}
 
 	
 	struct node* startNode = *listStart;
 	struct node* endNode = *listEnd;
 	
 	
 	*listStart = startNode->next;
 	startNode->next = NULL;
 	endNode->next = startNode;
 	*listEnd = startNode;
 	/**/
 	//printf("List start: %d, list end: %d\n",(*listStart)->size,(*listEnd)->size );
 	
 }
 
 void printList(struct node* listStart, struct node* listEnd){
 	if(listStart==NULL){
 		printf("Empty list.\n");
 	}
 	else{
 		while(listStart!=NULL){
 			printf("%d,%d ", listStart->size,listStart->grpNum);
 			listStart = listStart->next;
 		}
 		printf("\n");
 	}
 }
 
 int size(struct node* list){
 	int size = 0;
 	if(list==NULL){
 		return 0;
 	}
 	while(list!=NULL){
 		size++;
 		list = list->next;
 	}
 	return size;
 	
 }
 
 int calculateTotals(struct node* listPointer,int currentLoopNumber,int R, int K){
 	int numberOfGroups,kTemp,j;
 	//printf("Group came again. Value=%d, group=%d, loop number firstTime=%d, current loop=%d, total yet=%d, totalforfirsttime=%d\n",listPointer->size, listPointer->grpNum, listPointer->loopNumberForFirstChance,currentLoopNumber, totalPeople,listPointer->peopleYet );
 	int tillFirstAttempPeople = listPointer->peopleYet;
 	int peopleInEveryCycle = totalPeople - tillFirstAttempPeople;
 	
 	int loopsInEveryCycle = currentLoopNumber - listPointer->loopNumberForFirstChance;
 	
 
 	int loopNumber = currentLoopNumber;
 	int loopsRemaining = R - currentLoopNumber;
 	//printf("tillFirstAttempPeople=%d, peopleInEveryCycle=%d, loopsInEveryCycle=%d, totalPeople=%d, loopNumber=%d, loopsRemaining=%d\n",tillFirstAttempPeople,peopleInEveryCycle,loopsInEveryCycle,totalPeople,loopNumber,loopsRemaining );
 	while(loopsRemaining>=loopsInEveryCycle){
 		totalPeople+=peopleInEveryCycle;
 		loopsRemaining = loopsRemaining - loopsInEveryCycle;
 	}
 	
 	//printf("Before while loop total = %d\n",totalPeople);
 	while(loopsRemaining>0){
 		oneLoopCoster();
 		loopsRemaining--;
 	}
 	
 	
 	
 }
 
 
 oneLoopCoster(){
 	//printf("One coster\n");
 	int numberOfGroups = 0,j,	 kTemp = K;
 		struct node* listPointer = listStart;
 		while(listPointer!=NULL){ //Now coster is empty. Start filling it
 		//printf("kTemp = %d, size=%d\n",kTemp,listPointer->size);
 				if(listPointer->size <= kTemp){
 					kTemp -= listPointer->size;
 					totalPeople+=listPointer->size;
 					numberOfGroups++;
 					listPointer = listPointer->next;
 				}
 				else{
 					break;
 				}
 		}//printf("End of while Loop. Total: %d\n",total);
 		for(j=0; j<numberOfGroups; j++){
 			listRotate(&listStart, &listEnd);
 		}
 }
 
 void freeAllLists(){
 	struct node* temp;
 	while(listStart->next!=NULL)
 	{
 		//printf("In free while\n");
 		temp = listStart;
 		listStart = listStart->next;
 		//printf("freeing %d\n",temp->size);
 		free(temp);
 	}
 	if(listStart!=NULL)
 	free(listStart);
 	
 }
 
 void takeInputs(FILE *in){
 	char buffer[999999];
 	char* buf=buffer;
 	char* xyz;
 	int i=0;
 	char *delm =" ";
 	int numberOfGroupsInCurrentCase;
 	fgets(buffer, 999999, in);
 	//printf("%s",buffer);
 	
 	//fflush(stdout);
 	xyz=strtok(buf,delm);
 
 	R = atoi(xyz);
 	//printf("%d\n",R);
 	buf=NULL;
 	xyz=strtok(buf,delm);
 	K = atoi(xyz);
 	numberOfGroupsInCurrentCase = atoi(buffer);
 	
 	fgets(buffer, 999999, in);
 	buf = buffer;
 	
 	while((xyz=strtok(buf,delm))!=NULL)
 	{
 		//inputNumbers[i++] = atoi(xyz);
 		addGroup(atoi(xyz), &listStart, &listEnd);
 //		printf("%d\n",atoi(xyz)); 
 		buf=NULL;
 		
 	}	
 	//printf("%d %d %d\n",R,K,atoi(buffer));
 
 }
 
 
 int main(){
 	
 	int j, numberOfGroups, N , i, p, kTemp, loopBreaked;
 	char numberOfCases[10000];
 	FILE *in = fopen("C-small-attempt0.in","r");
     FILE *out = fopen("out.txt", "wt");
     fgets(numberOfCases, 999999, in);
     
     for(p=0; p<atoi(numberOfCases); p++){
     
     i=0;
 	totalPeople = 0;
 	kTemp = K;
 	loopBreaked = 0;
 	listStart = NULL;
 	listEnd = NULL;
 	numberOfGroups = 0;
 	N = 11;
 	takeInputs(in);
   	struct node* listPointer = listStart;
 	//printf("Before start loop\n");
 	for(i=0; i<R; i++){ //For every round of coster
 	
 		 numberOfGroups = 0;
 		 kTemp = K;
 		 listPointer = listStart;
 		 //printf("Starting of for loop with Value = %d, group number = %d\n",listPointer->size, listPointer->grpNum);
 		 
 		 if(listPointer->sittingChance > 0){
 				//printf("Group came again. Value=%d, group=%d, loop number firstTime=%d, current loop=%d\n",listPointer->size, listPointer->grpNum, listPointer->loopNumberForFirstChance,i);
 				calculateTotals(listPointer, i, R, K);
 				break;
 		 }
 			
 		else{
 			listPointer->sittingChance = listPointer->sittingChance + 1;
 			listPointer->loopNumberForFirstChance = i;
 			listPointer->peopleYet = totalPeople;
 			oneLoopCoster();
 		}
 		
 	} //End of for loop
 	printf("Case #%d: %d\n", p+1, totalPeople);
 	fprintf(out, "Case #%d: %d\n", p+1, totalPeople);
 	freeAllLists();
 	
 	//Case #1: 21
 	}
 	fclose(in);
 	fclose(out);
 	
 	return 0;
 }
 
 
 
 
 
 
 

