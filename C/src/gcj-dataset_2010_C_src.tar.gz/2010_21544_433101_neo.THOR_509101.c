#include <stdlib.h>
 #include <stdio.h>
 
 typedef unsigned long long bigint;
 
 int 
 main (int argc, char *argv[])
 {
 	bigint r,k,n,t,g[1000],i,j,count,a,b,th,init;
 	scanf("%llu",&t);
 	for(i=0;i<t;i++)
 	{
 		count=0;
 		scanf("%llu %llu %llu",&r,&k,&n);
 		for(j=0;j<n;j++)
 			scanf("%llu",&g[j]);
 		a=0;
 		for(j=0;j<r;j++)
 		{
 			th=0;
 			init=0;
 			while(1)
 			{
 				if((th+g[a])<=k)
 					th+=g[a];
 				else break;
 //				printf("%llu	%llu\n",g[a],th);
 				a++;
 				init++;
 				if(a==n)a=0;
 				if(init==n)break;
 
 			}
 			count +=th;
 //			printf("\n\n");
 		}
 		printf("Case #%llu: %llu\n",i+1,count);
 	}
 	
 	
 	return 0;
 }

