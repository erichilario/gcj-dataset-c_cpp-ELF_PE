#include<stdio.h>
 #include<malloc.h>
 #include<string.h>
 struct str
 {
 	char str1[100];
 	int link[100];
 	struct str *n[100];
 };
 int count=0,check=0;
 int *add[10000];
 int glo=0;
 void process(struct str *root,char *sg)
 {
 	int i,j;
 	char p[100];
 	if(sg[0]=='\0')
 	{
 		check=1;
 		return;
 	}
 	struct str *temproot;
 	temproot=root;
 	for(j=0;;j++)
 	{
 		if(sg[j]=='\0' || sg[j]=='/')
 			break;
 		p[j]=sg[j];
 	}
 	sg=sg+j;
 	p[j]='\0';
 	for(i=0;i<100;i++)
 	{
 		if(check==1)
 			return;
 		if(temproot->link[i]==1)
 		{
 			struct str *next;
 			next=temproot->n[i];
 			if(strcmp(next->str1,p)==0)
 			{
 				process(next,sg+1);
 				break;
 			}
 		}
 		else if(temproot->link[i]==0)
 		{
 			struct str *newnode=malloc(sizeof(struct str));
 			strcpy(newnode->str1,p);
 			for(j=0;j<100;j++)
 				newnode->link[j]=0;
 			temproot->n[i]=newnode;
 			temproot->link[i]=1;
 			process(newnode,sg+1);
 			add[glo++]=newnode;
 			break;
 		}
 	}
 	return;
 }	
 void process1(struct str *root,char *sg)
 {
 
 	int i,j;
 	char p[100];
 	if(sg[0]=='\0')
 	{
 		check=1;
 		return;
 	}
 	struct str *temproot;
 	temproot=root;
 	for(j=0;;j++)
 	{
 		if(sg[j]=='\0' || sg[j]=='/')
 			break;
 		p[j]=sg[j];
 	}
 	sg=sg+j;
 	p[j]='\0';
 	for(i=0;i<100;i++)
 	{
 		if(check==1)
 			return;
 		if(temproot->link[i]==1)
 		{
 			struct str *next;
 			next=temproot->n[i];
 			if(strcmp(next->str1,p)==0)
 			{
 				process1(next,sg+1);
 				break;
 			}
 		}
 		else if(temproot->link[i]==0)
 		{
 			struct str *newnode=malloc(sizeof(struct str));
 			strcpy(newnode->str1,p);
 			for(j=0;j<100;j++)
 				newnode->link[j]=0;
 			temproot->n[i]=newnode;
 			temproot->link[i]=1;
 			count++;
 			
 			add[glo++]=newnode;
 			process1(newnode,sg+1);
 			break;
 		}
 	}
 	return;
 }
 void free1(struct str *head)
 {
 	while(glo>0)
 	{
 		head=add[glo-1];
 		free(head);	
 		glo--;
 	}
 }
 int main()
 {
 	int nooftestcases;
 	scanf("%d",&nooftestcases);
 	int i,j,k=1,n,m;
 	char s[100];
 	while(nooftestcases>0)
 	{
 		count=glo=0;
 		struct str *p=malloc(sizeof(struct str));
 		p->str1[0]='#';
 		p->str1[2]='\0';
 		for(i=0;i<100;i++)
 			p->link[i]=0;
 		scanf("%d%d",&m,&n);
 		
 		for(i=0;i<m;i++)
 		{
 			check=0;
 			scanf("%s",s);
 			int l=strlen(s);
 			s[l+1]='\0';
 			process(p,s+1);
 		}
 		count=0;
 		for(j=0;j<n;j++)
 		{
 			check=0;
 			scanf("%s",s);
 			int l=strlen(s);
 			s[l+1]='\0';
 			process1(p,s+1);
 		}
 		free1(p);
 		free(p);
 		printf("Case #%d: %d\n",k,count);
 		k++;
 		nooftestcases--;
 	}
 	return 0;
 }

