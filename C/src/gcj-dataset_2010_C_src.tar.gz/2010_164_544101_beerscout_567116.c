#include <stdio.h>
 
 char B[101][101];
 int N, K;
 
 void Brotate()
 {
   int r;
   for ( r=0; r<N; ++r )
   {
     int c = N - 1;
     while ( c >= 0 && B[r][c] != '.' )
       --c;
     int free = c;
     while ( c >= 0 )
     {
       if ( B[r][c] != '.' )
       {
         B[r][free--] = B[r][c];
         B[r][c] = '.';
       }
       --c;
     }
   }
 }
 
 int check_x(int r, int c, char p, int dr, int dc)
 {
   int cnt = 0;
   while ( r < N && c < N && r >= 0 && c >= 0 && cnt < K && B[r][c] == p )
   {
     r += dr; c += dc; cnt++;
   }
   return cnt >= K;
 }
 
 int check(char p)
 {
   int r;
   for ( r=0; r<N; ++r )
   {
     int c;
     for ( c=0; c<N; ++c )
     {
       if ( check_x(r, c, p, 0, 1) || check_x(r, c, p, 1, 0)
           || check_x(r, c, p, 1, 1) || check_x(r, c, p, 1, -1) )
         return 1;
     }
   }
   return 0;
 }
 
 
 int main()
 {
   int T, t;
   scanf("%d", &T);
   for ( t=1; t<=T; ++t )
   {
     int n;
     scanf("%d", &N);
     scanf("%d", &K);
     for ( n=0; n<N; ++n )
       scanf("%s", B[n]);
     Brotate();
     /*for ( n=0; n<N; ++n )
     {
       int c;
       for ( c=0; c<N; ++c )
       {
         putchar(B[n][c]);
       }
       putchar('\n');
     }*/
     int red = check('R');
     int blue = check('B');
     printf("Case #%d: ", t);
     if ( red && blue )
       printf("Both\n");
     else if ( red )
       printf("Red\n");
     else if ( blue )
       printf("Blue\n");
     else printf("Neither\n");
   }
   return 0;
 }

