#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, char** argv) {
 	int t, k, r, n, grpnum, *g, i, j, numRiders, euros, pos;
 	FILE *input, *output;
 	
 	if((input = fopen(argv[1], "r")) == NULL || (output = fopen("CoasterAllocOut.txt", "w")) == NULL) {
 		printf("File could not be opened\n");
 	}
 	else {
 		fscanf(input, "%d", &t);
 		
 		for(i = 1; i <= t; i++) {
 			euros = 0;
 			pos = 0;
 			fscanf(input, "%d %d %d", &r, &k, &n);
 			g = (int*) malloc(sizeof(int) * n);
 			for(j = 0;j < n;j++) {
 				fscanf(input, "%d", g+j);
 			}
 			for(j = 0; j < r; j++) {
 				numRiders = 0;
 				grpnum = 0;
 				while((numRiders + g[pos]) <= k && grpnum < n) {
 					numRiders += g[pos];
 					printf("%d ", g[pos]);
 					pos++;
 					grpnum++;
 					if(pos == n) pos = 0;
 				}
 				printf("\n");
 				euros += numRiders;
 			}
 			free(g);
 			fprintf(output, "Case #%d: %d\n", i, euros);
 		}
 		fclose(input);
 		fclose(output);
 	}
 return 0;
 }
