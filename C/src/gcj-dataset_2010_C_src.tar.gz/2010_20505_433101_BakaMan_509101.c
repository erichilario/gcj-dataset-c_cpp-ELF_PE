#include<stdio.h>
 
 int main()
 {
 	long int T;
 	long int R,k,N;
 	long int arr[1020];
 	int i,j;
 	int ct,off,money,start;
 	scanf("%ld",&T);
 	for(i=0;i<T;i++)
 	{
 		scanf("%ld %ld %ld",&R,&k,&N);
 		for(j=0;j<N;j++)
 		scanf("%ld",&arr[j]);
 		off=0;
 		ct=k;
 		money=0;
 		start=off;
 		while(1)
 		{
 			if((ct-arr[off]<0))
 			{
 			ct=k;
 			start=off;
 			R--;
 			}
 			if(R==0) break;
 			ct=ct-arr[off];
 			money=money+arr[off];
 			off++;
 			if(off==N) off=0;
 			if(start==off){ ct=k; R--; }
 			
 		}
 		printf("\nCase #%d: %d",i+1,money);
 				
 		
 	}
 	return 0;
 
 }

