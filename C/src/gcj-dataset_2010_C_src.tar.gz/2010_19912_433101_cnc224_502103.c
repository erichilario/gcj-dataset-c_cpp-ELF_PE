#include <stdio.h>
 
 int r[31];
 
 void init() {
   r[0] = 1;
   int i;
   for (i = 1;i < 31; ++i) {
     r[i] = r[i -1] * 2;
   }
 }
 
 int main() {
   init();
   int t, n, k, i;
   scanf("%d", &t);
   for (i = 0;i < t; ++i) {
     scanf("%d %d",&n, &k);
     printf("Case #%d: ", i + 1);
     if ((k + 1) % r[n] == 0) {
       printf("ON\n");
     } else {
       printf("OFF\n");
     }
   }
   return 0;
 }

