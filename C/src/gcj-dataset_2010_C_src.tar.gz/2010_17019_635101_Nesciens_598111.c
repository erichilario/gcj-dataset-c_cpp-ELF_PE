#include <stdio.h>
 #include <stdlib.h>
 
 #define MAX(a,b) (((a)>(b))?(a):(b))
 
 #define MAXN 501
 #define MOD 100003
 
 unsigned achoosebtab[MAXN][MAXN];
 
 /* a!/b!/(a-b)! */
 void achooseb () {
 	unsigned int i, j;
 	
 	for (i = 0; i < MAXN; i++) {
 		achoosebtab[i][0] = 1;
 	}
 	
 	for (i = 1; i < MAXN; i++) {
 		for (j = 1; j <= i; j++) {
 			achoosebtab[i][j] = (achoosebtab[i-1][j-1] + achoosebtab[i-1][j]) % MOD;
 		}
 	}	
 }
 
 unsigned int tab[MAXN][MAXN];
 unsigned int total[MAXN];
 
 void calc () {
 	unsigned int i, j, k;
 	unsigned int sum, tot;
 	
 	for (i = 2; i < MAXN; i++) {
 		tab[i][1] = 1;
 	}
 	
 	for (i = 3; i < MAXN; i++) {
 		for (j = 2; j < i; j++) {
 			sum = 0;
 			for (k = 1; k < j; k++) {
 				sum += tab[j][k] * achoosebtab[i-j-1][j-k-1];
 				sum %= MOD;
 			}
 			tab[i][j] = sum;
 		}
 	}
 
 	for (i = 0; i < MAXN; i++) {
 		tot = 0;
 		for (j = 1; j < i; j++) {
 			tot += tab[i][j];
 			tot %= MOD;
 		}
 		total[i] = tot;
 	}
 }
 
 int main () {
 	unsigned i, t;
 	
 	achooseb ();
 	calc ();
 	
 	scanf ("%u ", &t);
 	for (i = 1; i <= t; i++) {
 		printf ("Case #%u: %u\n", i, total[i]);
 	}
 	
 	return 0;
 }

