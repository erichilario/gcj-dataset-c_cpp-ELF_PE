/*http://www.codechef.com/MAY10/problems/TR1/*/
 
 #include <stdio.h>
 #define Max 10001
 int main()
 
 {
 
 int noIter,i,j,k,maxsum,noofgroups,noofrounds,tempsum=0,groups[Max],nextgroup[Max],presentlink=0,maxpossum[Max],finalresult,l;
 
 scanf("%d",&noIter); 
 
 
 	for(i=0;i<noIter;i++)
 	{
 		presentlink=0;
 		scanf("%d %d %d",&noofrounds,&maxsum,&noofgroups);
 //		printf("%d %d %d\n",noofrounds,maxsum,noofgroups);
 		tempsum=0;
 		for(k=0;k<noofgroups;k++)
 		{
 			nextgroup[k]=0;
 			scanf("%d",&groups[k]);
 		//	printf("%d tempsum %d\n",groups[k],tempsum);
 			/*tempsum=tempsum+groups[k];
 			if(tempsum>maxsum)
 			{
 				nextgroup[presentlink++]=k;
 				maxpossum[presentlink-1]=tempsum-groups[k];
 				tempsum=groups[k];
 			}
 			else if(tempsum==maxsum)
 			{
 				nextgroup[presentlink++]=k+1;
 				tempsum=0;
 				maxpossum[presentlink-1]=maxsum;
 			}*/
 		}
 		/*for(k=0;k<noofgroups;k++)
 		{
 			printf("%d  %d\n",groups[k],nextgroup[k]);
 		}*/
 	
 		while(presentlink!=(noofgroups))
 		{
 			tempsum=0;
 			for(k=0;k<noofgroups;k++)
 			{
 				tempsum+=groups[(presentlink+k)%noofgroups];
 		//		printf("presentlink %d k=%d tempsum=%d\n",presentlink,k,tempsum);
 				if(tempsum>maxsum)
 				{
 					nextgroup[presentlink]=(presentlink+k)%noofgroups;
 					presentlink++;
 					maxpossum[presentlink-1]=tempsum-groups[(presentlink+k-1)%noofgroups];
 					break;
 				}
 				else if(tempsum==maxsum)
 				{
 					nextgroup[presentlink]=(presentlink+k+1)%noofgroups;
 					presentlink++;
 					maxpossum[presentlink-1]=maxsum;
 					break;
 				}
 				else if(k==(noofgroups-1))
 				{
 
 					nextgroup[presentlink]=presentlink;
 					maxpossum[presentlink]=tempsum;
 					presentlink++;
 
 				}
 		
 			}
 		
 		}
 	/*	for(k=0;k<noofgroups;k++)
 		{
 			
 			printf("%d %d %d\n",groups[k],nextgroup[k],maxpossum[k]);
 		}*/
 		finalresult=0;
 l=0;
 		for(k=0;k<noofrounds;k++)
 		{
 			//printf("l %d %d %d\n",l,nextgroup[k],maxpossum[l]);
 			finalresult+=maxpossum[l];
 			l=nextgroup[l];
 		}
 		printf("Case #%d: %d\n",(i+1),finalresult);
 		
 	}		
 }
 

