#include <stdio.h>
 
 int solve(int N, int K)
 {
   int i, v;
   v = K + 1;
   for (i = 0; i < N; ++i){
     if (v % 2 != 0) return 0;
     v /= 2;
   }
   return 1;
 }
 
 int main(void)
 {
   int T, i, N, K;
   scanf("%d", &T);
   for (i = 0; i < T; ++i) {
     scanf("%d %d", &N, &K);
     printf("Case #%d: %s\n", i+1, solve(N, K) ? "ON" : "OFF");
   }
 }

