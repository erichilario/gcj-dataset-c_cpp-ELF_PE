/******************************************************** 
  * @file A.c
  * @brief 
  * @author Red Li
  * @version 0.0.1
  * @date 2010-5-22
  *
  *********************************************************/
 
 
 #if 1
 
 #include <stdio.h>
 #include <stdlib.h>
 
 
 #define REP(i, begin, end, step) for((i) = (begin); (i) < (end); (i) += (step))
 #define REP1(i, begin, end) REP(i, begin, end, 1)
 #define rep(i, end) REP(i, 0, end, 1)
 
 
 
 int data[50][50];
 int flag[50][50];
 
 static int read_data(FILE *fp, int n)
 {
 	int i, j, d;
 	char c;
 
 	fscanf(fp, "%c", &c);
 	rep(i, n)
 	{
 		rep(j, n)
 		{
 			d = 0;
 			fscanf(fp, "%c", &c);
 			if(c == 'B')
 			{
 				data[j][i] = 1;
 			}
 			else if(c == 'R')
 			{
 				data[j][i] = 2;
 			}
 			else
 			{
 				data[j][i] = 0;
 			}
 		}
 
 		fscanf(fp, "%c", &c);
 	}
 
 
 	for(j = n - 1; j >= 0; j --)
 	{
 		d = n - 1;
 		for(i = n - 1; i >= 0; i --)
 		{
 			if(data[i][j])
 			{
 				data[d][j] = data[i][j];
 				d--;
 			}
 
 		}
 		while(d >= 0)
 		{
 			data[d][j] = 0;
 			d--;
 		}
 	}
 /*
 	rep(i, n)
 	{
 		rep(j, n)
 		{
 			printf("%d ", data[i][j]);
 
 		}
 		printf("\n");
 	}
 */
 	return 0;
 }
 
 
 static int search1(int i, int j)
 {
 	int n = 0;
 	int color = data[i][j];
 	while(j >= 0 && color == data[i][j])
 	{
 		flag[i][j] |= 0x1;
 		n++;
 		j --;
 	}
 
 	return n;
 }
 
 static int search2(int i, int j)
 {
 	int n = 0;
 	int color = data[i][j];
 
 	while(i >= 0 && color == data[i][j])
 	{
 		flag[i][j] |= 0x2;
 		n++;
 		i --;
 	}
 
 	return n;
 }
 
 
 static int search3(int i, int j)
 {
 	int n = 0;
 	int color = data[i][j];
 	while(j >= 0 && i >= 0 && color == data[i][j])
 	{
 		flag[i][j] |= 0x4;
 		n++;
 		j --;
 		i --;
 	}
 
 	return n;
 }
 
 static int search4(int i, int j, int nn)
 {
 	int n = 0;
 	int color = data[i][j];
 	while(j < nn && i >= 0 && color == data[i][j])
 	{
 		flag[i][j] |= 0x4;
 		n++;
 		j ++;
 		i --;
 	}
 
 	return n;
 }
 
 
 int main(int argc, char *argv[])
 {
 	char file[] = "A-large.in";
 	//char file[] = "A_sample.txt";
 	int n, i, cases, k, ii, jj, count, ret[3];
 	FILE *fp, *fout;
 	char str[4][16] = {"Neither", "Blue", "Red", "Both"};
 
 	fp = fopen(file, "r");
 	fout = fopen("output.txt", "w");
 
 
 	fscanf(fp, "%d", &cases);
 	//printf("%d\n", cases);
 
 	rep(i, cases)
 	{
 		fscanf(fp, "%d %d", &n, &k);
 		//printf("%d K:%d\n", n, k);
 		read_data(fp, n);
 
 		memset(flag, 0, sizeof(int) * 50 * 50);
 		memset(ret, 0, sizeof(int) * 3);
 
 		for(ii = n - 1; ii >= 0; ii--)
 		{
 			for(jj = n - 1; jj >= 0; jj--)
 			{
 				if(data[ii][jj])
 				{
 
 					if(!(flag[ii][jj] & 0x1))
 					{
 						count = search1(ii, jj);
 						ret[data[ii][jj]] |= (count >= k);
 
 					}
 					if(!(flag[ii][jj] & 0x2))
 					{
 						count = search2(ii, jj);
 						ret[data[ii][jj]] |= (count >= k);
 					}
 					if(!(flag[ii][jj] & 0x4))
 					{
 						count = search3(ii, jj);
 						ret[data[ii][jj]] |= (count >= k);
 					}
 					if(!(flag[ii][jj] & 0x8))
 					{
 						count = search4(ii, jj, n);
 						ret[data[ii][jj]] |= (count >= k);
 					}
 
 				}
 
 			}
 		}
 
 		//printf("Red:%d Blue:%d\n", ret[1], ret[2]);
 		int rr = ret[1] + (ret[2] << 1);
 		printf("Case #%d: %s\n", i + 1, str[rr]);
 		fprintf(fout, "Case #%d: %s\n", i + 1, str[rr]);
 		//break;
 
 	}
 
 
 
 
 	return 0;
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 #endif

