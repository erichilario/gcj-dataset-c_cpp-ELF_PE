#include<stdio.h>
 
 int main()
 {
 	int arr[11];
 	int t,n,k;
 	int i,j;
 	arr[1]=1;
 	for(i=2;i<11;i++)
 	{
 		arr[i]=2*arr[i-1]+1;
 	}
 	scanf("%d",&t);
 	for(j=0;j<t;j++)
 	{	
 		scanf("%d %d",&n,&k);
 		if(arr[n]==k) printf("\nCase #%d: ON",j+1);
 		else
 		{
 			if(k > arr[n])
 			{
 				if(((k+1)%(1<<n))==0)printf("\nCase #%d: ON",j+1);
 				else printf("\nCase #%d: OFF",j+1);
 			}
 			else
 		 	printf("\nCase #%d: OFF",j+1);	
 		}
 	}
 	return 0;
 
 }

