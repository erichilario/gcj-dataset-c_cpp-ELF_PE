#include <iostream>
 using namespace std;
 
 int main() {
   unsigned long long C, N, K, B, T, s;
   unsigned long long x[50], v[50];
   int arriveY[50];
   cin >> C;
   for(int ic=0; ic<C; ic++) {
     s=0;
     cin >> N >> K  >> B >> T;
     for(int in=0; in<N; in++) {
       cin>>x[in];
     }
     for(int in=0; in<N; in++) {
       cin>>v[in];
     }
     int kindex=0;
     for(int in=0; in<N; in++) {
       float usedtime=(float)(B-x[in])/(float)v[in];
       if(usedtime<=T) kindex++;
     }
     if(kindex<K) {
       cout << "Case #" << ic+1 << ": IMPOSSIBLE" << endl;
       continue;
     }
     for(int in=0; in<N; in++){
       arriveY[in]=0;
     }
     for(int in=0; in<N; in++) {
       float usedtime=(float)(B-x[in])/(float)v[in];
       if(usedtime<=T) arriveY[in]=1;
       //      cout << in << " " << arriveY[in] << endl;
     }
 
     for(int in=0; in<N; in++) {
       float usedtime=(float)(B-x[in])/(float)v[in];
       if(usedtime<=T) {
 	for(int it=in; it<N; it++) {
 	  if(arriveY[it]==0) s++;
 	}
       }
     }
 
     cout << "Case #" << ic+1 << ": " << s << endl;
   }
   return 0;
 }

