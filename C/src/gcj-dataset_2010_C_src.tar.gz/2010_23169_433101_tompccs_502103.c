#include <stdio.h>
 
 #define S_P 0
 #define S_O 1
 #define S_PO 2
 #define S_X 3
 
 int main(){
     FILE *input = fopen("A-small.in", "r");
     FILE *output = fopen("A-small.out", "w");
 
     int cases;
     fscanf(input, "%d\n",&cases);
 
     int i;
     for(i=0;i<cases;i++){
         long N, K;
         fscanf(input, "%ld %ld\n", &N, &K);
 
         long counter = K - ((N-1)*2 + 1);
 
         if(N == 0){
             counter = 0;
         }
 
         int mod = 4;
         
         // special case
         if(N == 1){
             mod = 2;
         }
         
         if(!(counter < 0) && !(K == 0) && (counter == 0 || (counter % mod) == 0)){
             fprintf(output, "Case #%d: ON\n", i+1);
         }else{
             fprintf(output, "Case #%d: OFF\n", i+1);
         }
         
     }
     
 }

