#include <stdio.h>
 #include <stdlib.h>
 
 int main(){
 	FILE *fin, *fout;
 	unsigned int t,n,k,i,j;
 	fin = fopen("A-large.in", "r");
 	fout = fopen("A-large.out", "w");
 	fscanf(fin, "%u", &t);
 	for(i=1; i<=t; i++){
 		fscanf(fin, "%u%u", &n, &k);
 		j = (1 << n) - 1;
 		k &= j;
 		fprintf(fout, "Case #%u: %s\n", i, ((k==j)?"ON":"OFF"));
 	}
 	fclose(fin);
 	fclose(fout);
 	return 0;
 }
 

