#include <stdio.h>
 #include <stdlib.h>
 #include <linux/fs.h>
 #include <math.h>
 
 int T,N,K;
 
 void main(void)
 {
 	FILE *fpi, *fpo;
 	int i;
 
 	fpi=fopen("A-small-attempt0.in", "r");
 	fpo=fopen("A-small-attempt0.out","w");
 
 	fscanf(fpi, "%d", &T);
 	for(i=0;i<T;i++)
 	{
 		fscanf(fpi, "%d %d", &N,&K);
 		
 		if((K+1)%(int)pow(2,N)==0)
 			fprintf(fpo, "Case #%d: ON\n", i+1);
 		else
 			fprintf(fpo, "Case #%d: OFF\n", i+1);
 	}
 	fclose(fpi);
 	fclose(fpo);
 }
 

