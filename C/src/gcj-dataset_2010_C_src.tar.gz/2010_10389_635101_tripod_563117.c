#include<stdio.h>
 #include<malloc.h>
 #include<string.h>
 typedef struct llist
 {
   char name[1000];
   struct llist *left;
   struct llist *child;
   
 }list;
 
 struct llist* createinsert(struct llist * start ,char *dir,int *cr)
 {
  struct llist * temp,*temp1;
 //  if(strcmp(start->name,dir)==0)
  // {
   //   *cr=0;
  //    return start;
  // }
   
   if(start->child == NULL)
   {
     temp=(list*)malloc(sizeof(list));
     strncpy(temp->name,dir,strlen(dir));
     temp->left=NULL;
     temp->child=NULL;
     start->child=temp;
     *cr=1;
     return temp; 
   }
   else
   {
     temp1=start->child;
      while(temp1->left!=NULL)
  
     {
         if(strcmp(temp1->name,dir)==0)
   	{
      		*cr=0;
      	     return temp1;
   	}
 
 	    temp1=temp1->left;
  
      }
    if(strcmp(temp1->name,dir)==0)
   	{
      		*cr=0;
      	     return temp1;
   	}
 
     temp=(list*)malloc(sizeof(list));
     strncpy(temp->name,dir,strlen(dir));
     temp->left=NULL;
     temp->child=NULL;
     temp1->left=temp;
     *cr=1;
     return temp; 
 
   }
  
 }
 int main()
 {
   int N,M,T,i,j;
   int len,k,tk,m,ind,s,cr,count=0;
   char name[1000];
   char tokens[100][1000];
   char token1[100][1000];
 
   list *head,*curr,*prev;
      scanf("%d",&T);
   for(i=0;i<T;i++)
   {
    head=(list*)malloc(sizeof(list)); 
    head->left=NULL;
    head->child=NULL;
    strncpy(head->name,"/",1);
 
     scanf("%d %d",&N,&M);
     count=0;
     tk=0;
     ind=0;
     s=0;
     for(j=0;j<N;j++)
     { 
        ind=0;
         s=0;
         scanf("%s",name);
         len=strlen(name);
         for(k=1;k<len;k++)
         {
           if(name[k]!='/') 
           {
            tokens[tk][ind]=name[k];
            ind++;
           }  
           else
 	   {
          	tokens[tk][ind]='\0';
                 //ind=0;
 		tk++;
                 if(s==0)
                 {
                   prev=createinsert(head,tokens[tk-1],&cr); 
                   s=1; 
                     
                 }   
 		else 
                 {
                    prev=createinsert(prev,tokens[tk-1],&cr);  
  
                 }
                  ind=0;
 
            }	
           //ind++; 
         }
         tokens[tk][ind]='\0';
 	if(s==0)
           {
                   prev=createinsert(head,tokens[tk],&cr);  
                   s=1;
                     
            }   
            else 
            {
                    prev=createinsert(prev,tokens[tk],&cr);  
  
            }
 
         tk++;
         s=0;  
     }
    //for(m=0;m<=tk;m++)
     //     printf("%s \n",tokens[m]);      
    tk=0;
    for(j=0;j<M;j++)
     { 
        int ind=0;
         scanf("%s",name);
         len=strlen(name);
         s=0;
         for(k=1;k<len;k++)
         {
           if(name[k]!='/') 
           {
            token1[tk][ind]=name[k];
            ind++;
           }  
           else
 	   {
          	token1[tk][ind]='\0';
                 //ind=0;
 		tk++;
 		if(s==0)
                 {
                   prev=createinsert(head,token1[tk-1],&cr);  
 		  if(cr)
                     count++;	 
                     s=1;
 
                     
                 }   
 		else 
                 {
                    prev=createinsert(prev,token1[tk-1],&cr);  
 		   if(cr) 
                     count++;	 
 
  
                  }
               ind=0;
            }	
          //ind++; 
         }
         token1[tk][ind]='\0';
         if(s==0)
                 {
                   prev=createinsert(head,token1[tk],&cr); 
 		 if(cr)  count++;	 
                     s=1;
                     
                 }   
 		else 
                 {
                    prev=createinsert(prev,token1[tk],&cr);  
                    if(cr) count++; 
  
                 }
 
         tk++; 
         
           }
     //printf("m token count%d",tk);
     //for(m=0;m<=tk;m++)
          //printf("%s \n",token1[m]);      
   printf("Case #%d: %d\n",i+1,count); 
   memset(tokens,0,100*100);
   memset(token1,0,100*100);
 
 
   }
   memset(tokens,0,100*100);
   memset(token1,0,100*100);
 
   return 0;
 }

