#include<stdio.h>
 main()
 {
     int t,r,k,n,i,c,j,x,g[100],tot;
     freopen("C-small-attempt0.in","r",stdin);
 	freopen("outc.txt","w",stdout);
     scanf("%d",&t);
     for(j=0;j<t;j++)
     {
         tot=0;
         scanf("%d%d%d",&r,&k,&n);
         for(i=0;i<n;i++)
         {
             scanf("%d",&g[i]);
             tot+=g[i];
         }
         i=c=0;
         if(tot<=k)
         c=tot*r;
         else
         {
         while(r--)
         {
             x=k;
             while(1)
             {
                 if(x-g[i]>=0)
                 {
                     x-=g[i];
                     c+=g[i];
                     if(i==n-1)
                     i=0;
                     else
                     i++;
                 }
                 else
                 break;
             }
         }
         }
         printf("Case #%d: %d\n",j+1,c);
     }
         return 0;
 }

