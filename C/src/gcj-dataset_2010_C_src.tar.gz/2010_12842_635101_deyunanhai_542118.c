#include <stdlib.h>
 #include <stdio.h>
 #include <math.h>
 
 #define SMALL_IN
 #define D_DEBUG
 
 int main() {
 	
 	int testcase,caseId, i, j, y,N,T,K,tmp,ret,ed;
 	long long B;
 	int x[50], x1[50], t[50], r[50];
 	
 	
 #ifdef SMALL_IN
 	freopen("B-small.in","r",stdin);freopen("B-small.out","w",stdout);
 #else
 	freopen("B-large.in","r",stdin);freopen("B-large.out","w",stdout);
 #endif
 	
 	scanf("%d",&testcase);
 	for (caseId=1;caseId<=testcase;caseId++) {
 		printf("Case #%d: ",caseId);
 		scanf("%d%d%lld%d", &N,&K,&B,&T);
 		
 		for(i=0;i<N;i++) scanf("%d", &(x[i]));
 		for(i=0;i<N;i++) scanf("%d", &(t[i]));
 		
 		if( K == 0 ) {
 			printf("IMPOSSIBLE"); goto END_F;
 		}
 		
 		j=0;
 		for(i=N-1;i>=0;i--) {
 			tmp = (B-x[i])/t[i];
 			if(tmp <= T) {
 				r[j++] = i;
 				if(j == K) break;
 			}
 		}
 		
 		if(j >= K) {
 			
 			ret = 0;ed=0;
 			for(i=0;i<K;i++) {
 				x1[i] = x[r[K-i-1]];
 				ret += N-r[i]-i-1;
 				//fprintf(stderr, "%d %d\n", r[i], N-r[i]-i-1);
 				t[i] = t[r[K-i-1]];
 			}
 			
 			for(i=1;i<=T;i++) {
 				for(j=K-1;j>=0;j--) {
 					//fprintf(stderr, "x[%d]=%d\n", j, x1[j]);
 					x1[j] += t[j];
 					for(y=0;y<K;y++) {
 						if( j!= y && x1[y] < B) {
 							if(x1[y] <= x1[j] && x1[y] > x1[j]-t[j]) {
 								/*tmp = x1[y];
 								x1[y] = x1[j];
 								x1[j] = tmp;*/
 								ret ++;
 								
 				//fprintf(stderr, "xj %d,xy %d, y %d, j %d\n", x1[j], x1[y], t[j], i);
 							}
 						}
 					}
 					
 					if(x1[j] >= B) {
 						ed++; if(ed >= K) goto END_S;
 					}
 				}
 			}
 			//fprintf(stderr, "\n");
 			
 END_S:
 			printf("%d", ret);
 			
 		} else {
 			printf("IMPOSSIBLE");
 		}
 		
 END_F:
 		printf("\n");
 		fflush(stdout);
 	}
 }

