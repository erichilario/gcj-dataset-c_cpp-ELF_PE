/*
  ============================================================================
  Name        : Snapper2.c
  Author      : silverbullet
  Version     :
  Copyright   : Your copyright notice
  Description : Hello World in C, Ansi-style
  ============================================================================
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 int t;
 int n[10000],k[10000];
 void getInputs(void);
 void printInputs(void);
 void logic(void);
 int power2(int,int);
 
 int main() {
 	getInputs();
 	logic();
 	return 0;
 }
 
 void getInputs(){
 	FILE *fp=fopen("c:/rajatj/codejam10/A-large.in","r");
 	int i;
 	fscanf(fp,"%d",&t);
 	for(i=0;i<t;i++)
 		fscanf(fp,"%d%d",&n[i],&k[i]);
 	fclose(fp);
 }
 
 void logic(){
 	FILE *fout= fopen("c:/rajatj/codejam10/outputs.txt","w");
 	int i;
 	int temp1,temp2;
 	for(i=0;i<t;i++){
 		temp1=power2(2,n[i]);
 		temp2=(k[i]+1)%temp1;
 		if(temp2==0)
 			fprintf(fout, "Case #%d: ON\n",i+1);
 		else
 			fprintf(fout, "Case #%d: OFF\n",i+1);
 	}
 
 	fclose(fout);
 }
 
 int power2(int m,int n){
 	int res=1;
 	while(n-->0)
 		res*=2;
 	return res;
 }
 
 

