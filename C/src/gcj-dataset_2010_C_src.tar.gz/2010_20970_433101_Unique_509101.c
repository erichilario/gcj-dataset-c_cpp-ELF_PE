#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
 	int n,t,r,in,chek;
 	int *grp;
 	int k,kt,count,temp,i;
 	scanf("%d",&t);
 	for(in =1;in<=t;in++)
 	{
 		scanf("%d %ld %d",&r,&k,&n);
 		grp=(int*)malloc(sizeof(int)*n);
 		for(i=0;i<n;i++)
 			scanf("%d",&grp[i]);
 		
 		count = 0;
 		temp = 0;
 		kt = k;
 		chek = 0;
 		while(r>0)
 		{
 
 			if(grp[temp] > kt || chek>=n)
 			{
 				r--;
 				kt = k;
 				chek = 0;
 			}
 			else 
 			{
 				chek++;
 				kt = kt-grp[temp];
 				count = count+grp[temp];			
 				temp = (temp+1)%n;
 			}
 		}
 		printf("Case #%d: %d\n",in,count);
 		free(grp);
 	}
 return 0;
 }
 	

