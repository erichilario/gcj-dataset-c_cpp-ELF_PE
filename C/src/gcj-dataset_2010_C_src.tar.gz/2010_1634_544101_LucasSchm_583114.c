/*
  *  C.c
  *  
  *
  *  Created by Lucas on 5/21/10.
  *
  */
 
 #include <stdio.h>
 
 int main (void) {
 	int a1, a2;
 	int b1, b2;
 	int t, i, j, k, res, menor, maior, temp, m, v;
 	
 	scanf("%d", &t);
 	for (k=1; k <= t; k++) {
 		scanf("%d %d %d %d", &a1, &a2, &b1, &b2);
 		res = 0;
 		
 		for (i=a1; i <= a2; i++)
 			for (j=b1; j <= b2; j++) {
 				menor = i > j ? j : i;
 				maior = i > j ? i : j;
 				
 				v = 0;
 				while (maior > 0 && menor > 0 && (maior - menor >= menor)) {
 					
 					if (v % 2 == 0) {
 						m = maior/menor;
 						maior = maior - menor*m;
 					}
 					else {
 						maior -= menor;
 					}
 					if (maior < menor) {
 						temp = maior;
 						maior = menor;
 						menor = temp;
 					}
 					v++;
 				}
 				if (v % 2 == 0) {
 					res++;
 				}
 			}
 		
 		printf("Case #%d: %d\n", k, res);
 	}
 	
 	return 0;
 }
