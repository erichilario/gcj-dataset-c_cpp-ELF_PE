#include <stdio.h>
 #define MAX 50
 
 typedef struct{
   long long int x, v;
 }P;
 
 P A[ MAX ], B;
 	
 int main(){
   int test, t, n, k, T, s, r, j, c, i;
   long long int b;
 
   scanf("%d", &t );
 
   for( test = 1; test <= t; test++ ){
    
     scanf("%d %d %lld %d", &n, &k, &b, &T );
 
     for( i = 0; i<n; i++ ) scanf("%lld", &A[ i ].x );
 
     for( i = 0; i<n; i++ ) scanf("%lld", &A[ i ].v );
 
     for( s = 1, r = 0; s <= T; s++ ){
 
     for( i = n-1, c = 0; i >= 0; i-- ) 
         if( A[ i ].x >= b ) c++;
 	else break;
 
       if( c >= k ) break;
 
 
     for( i = 0; i<n; i++ ){
         if( A[ i ].x >= b ) continue;
         A[ i ].x += A[ i ].v;
       }
 
       for( i = 0; i<n;i ++ )
        for( j = 0; j<n-1; j++ )
          if( A[ j ].x > A[ j+1 ].x ){
             B = A[ j+1 ];
 	    A[ j+1 ] = A[ j ];
 	    A[ j ] = B;
 	    r++;
          }
     }
  
       for( i = n-1, c = 0; i >= 0; i-- ) 
         if( A[ i ].x >= b ) c++;
 	else break;
 
     printf("Case #%d: ", test );
     if( c >= k ) printf("%d\n", r );
     else printf("IMPOSSIBLE\n"); 
   }
 
  return 0;
 }

