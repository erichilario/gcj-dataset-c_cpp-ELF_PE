#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 #define MAX_LENGTH 100
 
 char *read_input_line(char *str) 
 {
     char *tmp;
 
     str = fgets(str, MAX_LENGTH, stdin);
 
     tmp = strchr(str, '\n');
     if(tmp == NULL) {
         printf("Error: newline char not found!\n");
         exit(-1);
     }
     *tmp = '\0';
 
     if(str == NULL) {
         printf("Error: reading input line\n");
         exit(-1);
     }
     return str;
 }
 
 int read_input_int(char *str) 
 {
     int val;
 
     str = read_input_line(str);
     sscanf(str, "%d", &val); 
     return val;
 }
 
 int output(int nr_case, int rwin, int bwin)
 {
     if(rwin && bwin)
         printf("Case #%d: Both\n", nr_case);
     else if(rwin)
         printf("Case #%d: Red\n", nr_case);
     else if(bwin)
         printf("Case #%d: Blue\n", nr_case);
     else
         printf("Case #%d: Neither\n", nr_case);
 }
 
 int main(void)
 {
     int cases, i, j, k, l, m, n, p;
     char str[MAX_LENGTH + 1];
     char *res;
     int count;
     char val;
     int flag;
     int outval;
     int N, K;
     char board[51][51];
     char rot1[51][51];   
     char rot[51][51];   
     int count_r, count_b;
     int rwin, bwin;
 
     cases = read_input_int(str);
 
     for(i = 1; i <= cases; i++) {
         res = read_input_line(str);
         sscanf(res, "%d %d", &N, &K);
 
         memset(board, 0, sizeof(board));
         memset(rot, '.', sizeof(rot));
         memset(rot1, '.', sizeof(rot));
 
         for(j = 0; j < N; j++) {
             res = read_input_line(str);
             memcpy(board[j], res, N);
         }
 
         for(j = 0; j < N; j++) {
             l = N - 1; 
             for(k = N - 1; k >= 0; k--) {
                 if(board[j][k] != '.') {
                     rot1[l][j] = board[j][k];
                     l--;
                 }
             } 
         }
       
         for(j = 0; j < N; j++) {
             for(k = 0; k < N; k++) {
                     rot[k][N - 1 - j] = rot1[j][k];
             }
         }
 
         /*
         for(j = 0; j < N; j++) {
             for(k = 0; k < N; k++)
                 printf("%c", rot[j][k]);
             printf("\n");
         }
        */
 
         rwin = 0;
         bwin = 0;
         for(j = N - 1; j >= 0; j--) {
             count_r = 0;
             count_b = 0;
             for(k = 0; k < N; k++) {
                if(rot[j][k] == 'R') {
                     count_r++;
                     count_b = 0;
                 }
                
                if(rot[j][k] == 'B') {
                     count_b++;
                     count_r = 0;
                 }
 
                if(rot[j][k] == '.') {
                     count_b = 0;
                     count_r = 0;
                }
 
                if(count_r >= K)
                    rwin = 1;
 
                if(count_b >= K)
                    bwin = 1;
 
                if(rwin && bwin)
                    break;
             }
 
             if(rwin && bwin)
                 break;
         }
        
         if(rwin && bwin)
             goto done;
         
         for(k = 0; k < N; k++) {
             count_r = 0;
             count_b = 0;
             for(j = N - 1; j >= 0; j--) {
                if(rot[j][k] == 'R') {
                     count_r++;
                     count_b = 0;
                 }
                
                if(rot[j][k] == 'B') {
                     count_b++;
                     count_r = 0;
                 }
 
                if(rot[j][k] == '.') {
                     count_b = 0;
                     count_r = 0;
                }
 
                if(count_r >= K)
                    rwin = 1;
 
                if(count_b >= K)
                    bwin = 1;
 
                if(rwin && bwin)
                    break;
             }
 
             if(rwin && bwin)
                 break;
         }
         
         if(rwin && bwin)
             goto done;
 
         for(l = N - 1; l >= 0; l--) {
         
             count_r = 0;
             count_b = 0;
             for(k = N - 1, m = N - 1, n = l; k >= l; k--, m--, n++) {
 
                     if(rot[m][n] == 'R') {
                         count_r++;
                         count_b = 0;
                     }
                     
                     if(rot[m][n] == 'B') {
                         count_b++;
                         count_r = 0;
                     }
 
                     if(rot[m][n] == '.') {
                         count_b = 0;
                         count_r = 0;
                     }
 
                     if(count_r >= K)
                         rwin = 1;
 
                     if(count_b >= K)
                         bwin = 1;
 
                     if(rwin && bwin)
                         break;
                 }   
 
                 if(rwin && bwin)
                     break;
         }
         
         if(rwin && bwin)
             goto done;
         
         for(l = N - 2; l >= 0; l--) {
         
             count_r = 0;
             count_b = 0;
             for(k = N - 2, m = 0, n = l; k >= l; k--, m++, n--) {
 
                     if(rot[m][n] == 'R') {
                         count_r++;
                         count_b = 0;
                     }
                     
                     if(rot[m][n] == 'B') {
                         count_b++;
                         count_r = 0;
                     }
 
                     if(rot[m][n] == '.') {
                         count_b = 0;
                         count_r = 0;
                     }
 
                     if(count_r >= K)
                         rwin = 1;
 
                     if(count_b >= K)
                         bwin = 1;
 
                     if(rwin && bwin)
                         break;
                 }   
 
                 if(rwin && bwin)
                     break;
         }
         
         if(rwin && bwin)
             goto done;
         
         for(l = 0; l < N; l++) {
         
             count_r = 0;
             count_b = 0;
             for(k = 0, m = N - 1, n = l; k <= l; k++, m--, n--) {
 
                     if(rot[m][n] == 'R') {
                         count_r++;
                         count_b = 0;
                     }
                     
                     if(rot[m][n] == 'B') {
                         count_b++;
                         count_r = 0;
                     }
 
                     if(rot[m][n] == '.') {
                         count_b = 0;
                         count_r = 0;
                     }
 
                     if(count_r >= K)
                         rwin = 1;
 
                     if(count_b >= K)
                         bwin = 1;
 
                     if(rwin && bwin)
                         break;
                 }   
 
                 if(rwin && bwin)
                     break;
         }
         
         if(rwin && bwin)
             goto done;
         
         for(l = N - 2; l >= 0; l--) {
         
             count_r = 0;
             count_b = 0;
             for(k = N - 2, m = l, n = N - 2; k >= l; k--, m--, n--) {
 
                     if(rot[m][n] == 'R') {
                         count_r++;
                         count_b = 0;
                     }
                     
                     if(rot[m][n] == 'B') {
                         count_b++;
                         count_r = 0;
                     }
 
                     if(rot[m][n] == '.') {
                         count_b = 0;
                         count_r = 0;
                     }
 
                     if(count_r >= K)
                         rwin = 1;
 
                     if(count_b >= K)
                         bwin = 1;
 
                     if(rwin && bwin)
                         break;
                 }   
 
                 if(rwin && bwin)
                     break;
         }
         
 done:
         output(i, rwin, bwin); 
     }
 
     return 1;
 }

