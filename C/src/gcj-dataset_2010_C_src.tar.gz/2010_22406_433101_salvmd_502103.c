#include <stdio.h>
 #include <stdlib.h>
 
 long fast_pow(long base, long power) {
 	if(power == 0) {
 		return 1;
 	}
 	else if(power % 2 == 0) {
 		long temp = fast_pow(base,power/2);
 		return temp * temp;
 	}
 	else {
 		return base * fast_pow(base,power-1);
 	}
 }
 
 int main() {
 	int N, K, T, i;
 	scanf("%d",&T);
 	for(i = 0; i < T; i++) {
 		scanf("%d %d",&N,&K);
 		long x = fast_pow(2,N) - 1;
 		long res = x & K;
 		if(res == x) {
 			printf("Case #%d: ON\n",(i+1));
 		}
 		else {
 			printf("Case #%d: OFF\n",(i+1));
 		}
 	}
 }
 
 

