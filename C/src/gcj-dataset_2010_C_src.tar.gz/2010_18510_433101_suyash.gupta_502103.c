#include<stdio.h>
 main()
 {
     int t,n,k,min,y,fl,i;
     int a[30]={1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535,131071,
            262143,524287,1048575,2097151,4194303,8388607,16777215,33554431,67108863,
            134217727,268435455,536870911,1073741823};
     freopen("A-large.in","r",stdin);
 	freopen("output.txt","w",stdout);
     scanf("%d",&t);
     for(i=1;i<=t;i++)
     {
         fl=0;
         scanf("%d%d",&n,&k);
         if(n>=27)
         fl=0;
         else
         {
         min=a[n-1];
         y=min+1;
         if(k<min)
         fl=0;
         else if(k==min)
         fl=1;
         else if(k>min)
         {
             k=k-min;
             if(k%y==0)
             fl=1;
             else
             fl=0;
         }
         }
             if(fl==0)
             printf("Case #%d: OFF\n",i);
             else
             printf("Case #%d: ON\n",i);
     }
     return 0;
 }

