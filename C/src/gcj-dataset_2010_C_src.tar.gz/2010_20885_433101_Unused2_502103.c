#include <stdio.h>
 
 int main()
 {
 	FILE* fp=fopen("A-small-attempt0.in","r"),*fp2=fopen("output.out","w");
 	unsigned int T,N,K,i;
 
 	fscanf(fp,"%d",&T);
 
 	for (i=1; i<=T; i++)
 	{
 		fscanf(fp,"%d %d",&N,&K);
 		fprintf(fp2,"Case #%d: %s\n",i,((K+1)%(1<<N)) == 0 ? "ON":"OFF");
 	}
 
 	fclose(fp);
 	fclose(fp2);
 
 	return 0;
 }
