#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <assert.h>
 
 #define	min(a, b)	(((a) < (b)) ? (a) : (b))
 #define	max(a, b)	(((a) > (b)) ? (a) : (b))
 #define	abs(x)		(((x) >= 0) ? (x) : -(x))
 
 static int N, K, B, T;
 static int x[50];
 static int v[50];
 static int code[50];
 
 enum {
 	YES,
 	NO,
 	MAYBE
 };
 
 static void handle_test_case(int casenum) {
 	int i;
 	int nf = 0;
 	int k = 0;
 	int first_lag = N;
 	int done = 0;
 	int nlags = 0;
 	int nswaps = 0;
 
 	for (i = N - 1; i >= 0; i--) {
 		if (x[i] + v[i] * T >= B) {
 			if (!nf) {
 				code[i] = YES;
 				k++;
 			}
 			else
 				code[i] = MAYBE;
 		}
 		else {
 			code[i] = NO;
 			nf = 1;
 			if (!done) {
 				first_lag = i;
 				done = 1;
 			}
 		}
 	}
 	if (k >= K) {
 		printf("Case #%d: %d\n", casenum, 0);
 		return;
 	}
 	for (i = first_lag; i >= 0; i--) {
 		if (NO == code[i])
 			nlags++;
 		else if (MAYBE == code[i]) {	// MAYBE
 			nswaps += nlags;
 			k++;
 			if (k >= K)
 				break;
 		}
 		else
 			assert(0);
 	}
 	if (k >= K)
 		printf("Case #%d: %d\n", casenum, nswaps);
 	else
 		printf("Case #%d: IMPOSSIBLE\n", casenum);
 }
 
 static int parse_input(const char *infile) {
 	FILE *fp;
 	int C;
 	int i, j;
 
 	fp = fopen(infile, "r");
 	fscanf(fp, "%d\n", &C);
 	for (i = 1; i <= C; i++) {
 		fscanf(fp, "%d %d %d %d\n", &N, &K, &B, &T);
 		for (j = 0; j < N; j++)
 			fscanf(fp, "%d", &x[j]);
 		fscanf(fp, "\n");
 		for (j = 0; j < N; j++)
 			fscanf(fp, "%d", &v[j]);
 		fscanf(fp, "\n");
 		handle_test_case(i);
 	}
 	fclose(fp);
 	return 0;
 }
 
 int main(int argc, char *argv[]) {
 	if (parse_input(argv[1]))
 		exit(1);
 	return 0;
 }

