#include <stdio.h>
 #include <stdlib.h>
 
 void ride(int casenum);
 unsigned long long int calculate(int R, int k, int N, int* groups);
 
 int main(int argc, char** argv) {
 	int T = 0;
 	scanf("%u\n", &T);
 	for (int i = 0; i < T; i++) {
 		ride(i+1);
 	}
 	
 	return 0;
 }
 
 void ride(int casenum) {
 	int R, k, N;
 	int* groups;
 	scanf("%u %u %u\n", &R, &k, &N);
 	groups = (int*)malloc(sizeof(int) * N);
 	for (int i = 0; i < N; i++) {
 		scanf("%u", &(groups[i]));
 	}
 
 	unsigned long long int result = calculate(R, k, N, groups);
 	printf("Case #%u: %llu\n", casenum, result);
 
 	free(groups);
 }
 
 unsigned long long int calculate(int R, int k, int N, int* groups) {
 	int nextIndex = 0;
 	unsigned long long int grandtotal = 0;
 	for (int i = 0; i < R; i++) {
 		int runtotal = 0;
 		int nextgroup = 0;
 		for (int j = 0; j < N; j++) {
 			nextgroup = groups[nextIndex];
 			if (runtotal + nextgroup > k) {
 				break;
 			} else {
 				runtotal += nextgroup;
 				nextIndex++;
 				nextIndex = nextIndex % N;
 			}
 		}
 		grandtotal += runtotal;
 	}
 
 	return grandtotal;
 }

