#include <stdio.h>
 #include <math.h>
 
 int main(int argc, char** argv) {
 	int t = -1;
 	int n;
 	int k;
 	int i;
 	FILE *input;
 	FILE *output;
 	
 	if ((input = fopen(argv[1], "r")) == NULL || (output = fopen("Snapper_Out.txt", "w")) == NULL) {
 		printf("File could not be open\n");
 	}
 	else {
 		fscanf(input, "%d", &t);
 		
 		for(i = 1;i <= t; i++) {
 			fscanf(input, "%d", &n);
 			fscanf(input, "%d", &k);
 			if((k + 1) % (int)pow(2,n)) {
 				fprintf(output, "Case #%d: OFF\n", i);
 			}
 			else {
 				fprintf(output, "Case #%d: ON\n", i);
 			}
 		}
 		
 		fclose(input);
 		fclose(output);
 	}
 	return 0;
 }
 		
