#include <stdio.h>
 #include <stdlib.h>
 
 FILE *in, *out;
 
 #define NGROUPS 1005
 
 #define DEBUG
 
 /*#ifdef DEBUG
 #undef DEBUG
 #endif */
 
 struct circ_node;
 
 typedef struct circ_node {
     struct circ_node *right;
     struct circ_node *left;
     unsigned long long data;
     int end;
     int head_at_run;
 } circ_node;
 
 void del_circlist(circ_node *start) {
     start->left->end = 1;
     circ_node *this, *next;
     this = start;
     while (!this->end) {
         next = this->right;
         free(this);
         this = next;
     }
     free(this);
 }
 
 void print_list(circ_node *start, int n) {
     circ_node *curr = start;
     for (int i = 0; i < n; i++) {
         fprintf(stderr, "%llu ", curr->data);
         curr = curr->right;
     }
     fprintf(stderr, "\n");
 }
 
 circ_node* make_node(unsigned long long data) {
     circ_node *node = calloc(1, sizeof(circ_node));
     node->data = data;
     return node;
 }
 
 
 int main(int argc, char **argv) {
     in  = fopen(argv[1], "r");
     out = fopen(argv[2], "w");
 
     int T;
     unsigned long long R, k, N;
 
     fscanf(in, "%d\n", &T);
 
     for (int t = 1; t <= T; t++) {
         long long d;
         fscanf(in, "%llu %llu %llu\n", &R, &k, &N);
         fscanf(in, "%llu", &d);
 
         circ_node *head = make_node(d);
         circ_node *curr = head;
         circ_node *next;
         for (int i = 1; i < N; i++) {
             fscanf(in, "%llu", &d);
             next = make_node(d);
             curr->right = next;
             next->left = curr;
             curr = next;
         }
         curr->right = head;
         head->left = curr;
 
 #ifdef DEBUG
         fprintf(stderr, "=== T%d === === T%d ===\n", t, t);
         fprintf(stderr, "list made; 2 prints: ");
         print_list(head, 2 * N);
 #endif
 
         unsigned long long in_car;
         long long revenue = 0;
         for (int run = 0; run < R; run++) {
 #ifdef DEBUG
             fprintf(stderr, "R%d ", run);
             print_list(head, N);
 #endif
 
             in_car = 0;
             head->head_at_run = run;
             circ_node *curr = head;
             int groups_loaded = 0;
             while (in_car <= k && groups_loaded <= N) {
                 in_car += curr->data;
                 curr = curr->right;
                 groups_loaded++;
             }
             // now k > in_car, and curr is next
             curr = curr->left; // backtrack
             head = curr;
             in_car -= curr->data;
             revenue += in_car;
 #ifdef DEBUG
             fprintf(stderr, "R%d car: %llu, rev: %llu\n", run, in_car, revenue);
 #endif
         }
         del_circlist(head);
         fprintf(out, "Case #%d: %llu\n", t, revenue);            
     }
 
     fclose(in);
     fclose(out);
 
     return 0;
 }

