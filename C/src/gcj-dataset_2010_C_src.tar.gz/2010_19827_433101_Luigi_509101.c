#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <string.h>
 #include <ctype.h>
 
 #define MAXN (1000+1)
 
 int T = -1;
 unsigned long long ans;
 unsigned long long R, k, N;
 unsigned long long gis[MAXN];
 unsigned long long take[MAXN];
 unsigned long long worth[MAXN];
 
 void fill_sums()
 {
 	for (int i = 0; i < N; i++)
 	{
 		unsigned long long tot = 0LL;
 		for (int j = 0; j < N; j++)
 		{
 			tot += gis[(i+j)%N];
 			if (tot <= k)
 			{
 				take[i] = j+1;
 				worth[i] = tot;
 			}
 		}
 	}
 }
 
 unsigned long long go()
 {
 	int upto = 0;
 	unsigned long long ans = 0LL;
 	for (unsigned long long i = 0LL; i < R; i++)
 	{
 		ans += worth[upto];
 		upto = (upto+take[upto]) % N;
 	}
 	return ans;
 }
 
 int main(int argc, char *argv[])
 {
 	FILE *fp;
 	fp = fopen(argv[1], "r");
 	if (fp == NULL)
 	{
 		fprintf(stderr, "Fatal error: cannot open file '%s'\n", argv[1]);
 		exit(EXIT_FAILURE);
 	}
 
 	fscanf(fp, "%d\n", &T);
 
 	for (int i = 0; i < T; i++)
 	{
 		fscanf(fp, "%lld %lld %lld\n", &R, &k, &N);
 		for (int i = 0; i < N; i++)
 			fscanf(fp, "%lld", &gis[i]);
 		fill_sums();
 		printf("Case #%d: %llu\n", i+1, go());
 	}
 
 	return 0;
 }

