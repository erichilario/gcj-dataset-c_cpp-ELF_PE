#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int GCD(int a,int b );
 
 int main()
 {
 	int no,i,j,Temp,n,flag,gcd,p,d,q,k;
 	int *diff;
 	int *A;
 	scanf("%d",&no);
 	for(k=0;k<no;k++)
 	{
 		scanf("%d",&n);
 		A=(int *)malloc(n*sizeof(int));
 		diff=(int *)malloc((n-1)*sizeof(int));
 		for(j=0;j<n;j++)
 			scanf("%d",&A[j]);
 		for(i=1; i<n; i++)
 		{
 			Temp = A[i];
 			j = i-1;
 			while(Temp<A[j] && j>=0)
 			{
 				A[j+1] = A[j];
 				j = j-1;
 			}
 			A[j+1] = Temp;
 		}
 		for(i=1; i<n; i++)
 		{
 			diff[i-1]=A[i]-A[i-1];
 		}
 		if(n>2){
 		for(i=1; i<n-1; i++)
 		{
 			Temp = diff[i];
 			j = i-1;
 			while(Temp<diff[j] && j>=0)
 			{
 				diff[j+1] = diff[j];
 				j = j-1;
 			}
 			diff[j+1] = Temp;
 		}
 		}
 		if(n>2)
 		{	
 			gcd=GCD(diff[1],diff[0]);
 			for(i=2;i<n-1;i++)
 				gcd=GCD(diff[i],gcd);
 		}
 		else
 			gcd=diff[0];
 		p=A[0]/gcd;
 		if(p*gcd<A[0])
 			p++;
 		while(1)
 		{
 			d=p*gcd-A[0];
 			flag=0;
 			for(q=1;q<n;q++)
 			{
 				if((A[q]+d)%gcd!=0)
 				{	
 					flag=1;
 					break;
 				}
 			}
 			if(flag==1)
 				p++;
 			else
 			{
 				printf("Case #%d: %d\n",k+1,d);
 				break;
 			}
 		}
 	}
 return 0;
 }
 
 
 int GCD(int a,int b )
 {
     if( b== 0 )
         return a;
     else
         return GCD(b,a%b );
 }
 

