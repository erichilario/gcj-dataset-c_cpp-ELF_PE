#include <stdio.h>
 #include <stdlib.h>
 
 int main() {
 
   int T, i, n; 
   long long int k, temp;
 
   scanf("%d", &T);
 
   for(i=0; i<T; i++) {
     scanf("%d %lld", &n, &k);
 
     temp = (1 << n);
     k++;
     printf("Case #%d: ", (i+1));
     if(!(k%temp)) printf("ON\n");
     else printf("OFF\n");
   }
   
 
   return 0;
   
 }

