/* plantilla para la integracion de sistemas de ecuaciones diferenciales */
 
 
 #include <stdio.h>
 #include <stddef.h>
 #include <stdlib.h>
 #include <math.h>
 
 
 
 
 
 int main (int argc,char **argv){
 
 	FILE *pfich;
 	FILE *pfich2;
 	char *texto;
 	int flag = 0;
 	int x,numElms,j,i,n,k;
 	int valor = 2;
 	texto = (char *)malloc(25*sizeof(char));
 	
 	if(!(pfich=fopen("input.txt","r")))				//abrimos fichero
 	{	printf("Error al abrir fichero1\n");
 	return 0;		}
 	if(!(pfich2=fopen("output.txt","w")))				//abrimos fichero
 	{	printf("Error al abrir fichero1\n");
 	return 0;		}
 
 	fscanf(pfich,"%d \n",&numElms);				//tomamos numero de elementos
 	for(i=0;i<numElms;i++){
 		fscanf(pfich,"%d ",&n);
 		fscanf(pfich,"%d \n",&k);
 		valor = 2;
 		for(x=1;x<n;x++)
 			valor = valor*2;
 		for(j=valor-1;j<100;j =j+valor){
 			if (j == k)
 				flag = 1;
 		}
 		if (flag == 1)
 			texto = "ON";
 		else
 			texto = "OFF";
 		flag = 0;
 		fprintf(pfich2,"Case #%d: %s \n",i+1,texto);
 	}
 	fclose(pfich);
 	fclose(pfich2);
 	return 0;
 }
 

