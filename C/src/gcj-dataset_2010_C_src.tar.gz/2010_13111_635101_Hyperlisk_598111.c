
 #include <stdio.h>
 #include <stdint.h>
 
 uint16_t mem[500] = {0};
 uint16_t stack[501] = {0};
 uint16_t si;
 
 int check(int n,int num);
 
 int main(void){
   int T, n, i;
   scanf("%d",&T);
   stack[1] = 2;
   for(i=0;i<T;i++){
     scanf("%d",&n);
     si = 1;
     printf("Case #%d: %d\n",i+1,check(n,2)%100003);
   }
   return 0;
 }
 
 int check(int n,int num){
   int i,t,ti,r=0;
   if(n == num){
     ti = 1;
     while(ti < si){
       ti = stack[ti];
     }
     return (ti==si)?1:0;
   }
   for(i=0;i<2;i++){
     if(i){
       stack[si++] = num;
       r += check(n,num+1)%100003;
       --si;
     } else {
       r += check(n,num+1)%100003;
     }
   }
   return r;
 }

