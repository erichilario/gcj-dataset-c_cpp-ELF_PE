#include <stdio.h>
 
 #define MAX_N 1200
 int R, K, N;
 int G[MAX_N];
 
 void solve() {
     int r, i, j;
     int start = 0;
     int capacity = 0;
     __int64 sum = 0;
     for (r = 0; r < R; r++) {
         capacity = 0;
         i = start;
         while (capacity <= K) {
             if (capacity + G[i] <= K) {
                 capacity += G[i];
                 i = (i + 1) % N;
                 if (i == start)
                     break;
             }
             else {
                 break;
             }
         }
         sum += capacity;
         start = i;
         
         if (0 == start) {
             int div = R / (r + 1);
             int mod = R % (r + 1);
             sum = sum * div;
             r = (r + 1) * div - 1;
         }
         
     }
     printf("%I64d\n", sum);
 }
 
 int main(void)
 {
     int T, i, j;
 
     scanf("%d\n", &T);
     for (i = 0; i < T; i++) {
         scanf("%d %d %d\n", &R, &K, &N);
         for (j = 0; j < N; j++) {
             scanf("%d", &(G[j]));
         }
         printf("Case #%d: ", i + 1);
         solve();
     }
 
 
     return 0;
 }
