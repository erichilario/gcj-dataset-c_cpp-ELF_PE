#include<stdio.h>
 int hold_val[2000], hold_index[2000];
 int main(void){
 	int T, i;
 	scanf("%d", &T);
 	for(i = 0; i < T; ++i){
 		int R, K, N, j, ans = 0, now_index;
 		int group_size[2000];
 		scanf("%d%d%d", &R, &K, &N);
 		for(j = 0; j < N; ++j)
 			scanf("%d", &group_size[j]);
 		for(j = 0; j < N; ++j){
 			int sum = 0, k = 0;
 			while(sum + group_size[(j+k)%N] <= K){
 				sum += group_size[(j+k)%N];
 				++k;
 				if(k == N)
 					break;
 			}
 			hold_val[j] = sum;
 			hold_index[j] = k;
 		}
 		now_index = 0;
 		for(j = 0; j < R; ++j){
 			ans += hold_val[now_index];
 			now_index += hold_index[now_index];
 			now_index %= N;
 		}
 		printf("Case #%d: %d\n", i+1, ans);
 	}
 	return 0;
 }

