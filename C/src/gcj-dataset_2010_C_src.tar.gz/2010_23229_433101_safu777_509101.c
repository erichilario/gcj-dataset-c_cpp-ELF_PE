#include<stdio.h>
 #include<conio.h>
 void main()
 {
 	int n,t,i,m,l;
 	long r,k,g[10],j,c,e;
 	FILE *fptr1,*fptr2;
 	fptr1=fopen("input.txt","r");
 	fptr2=fopen("output.txt","w");
 	fscanf(fptr1,"%d",&t);
 	for(i=0;i<t;i++)
 	{
 		fscanf(fptr1,"%ld%ld%d",&r,&k,&n);
 		for(j=0;j<n;j++)
 			fscanf(fptr1,"%ld",&g[j]);
 		for(j=0,l=0,e=0;j<r;j++)
 		{
 			for(c=0,m=0;(c<k)&&(m<n);l=(l+1)%n,m++)
 				c+=g[l];
 			if(c>k)
 				if(l==0)
 				{
 					c-=g[n-1];
 					l=n-1;
 				}
 				else
 				{
 					c-=g[l-1];
 					l-=1;
 				}
 			e+=c;
 		}
 		fprintf(fptr2,"Case #%d: %ld\n",i+1,e);
 	}
 }
