#include <stdio.h>
 #include <stdlib.h>
 
 main()
 {
       FILE *entrada, *saida;
 
       entrada = fopen("c-small.txt", "r");
       saida = fopen ("saida.txt", "w");
 
       int T, R, k, N, i, j, *grupo, dinheiro, pos, lotado, cont, gruposdentro;
 
       fscanf(entrada, "%d", &T);
 
       for(i=0; i<T; i++)
       {
           dinheiro = 0;
           fscanf(entrada, "%d", &R);
           fscanf(entrada, "%d", &k);
           fscanf(entrada, "%d", &N);
           pos = 0;
 
           grupo = (int*) malloc (N*sizeof(int));
 
           for(j=0; j<N; j++)
           {
               fscanf(entrada, "%d", &grupo[j]);
           }
 
           for (j=0; j<R; j++)
           {
               lotado = 0;
               gruposdentro=0;
 
               while(1)
               {
                   if(grupo[pos] + lotado <= k)
                   {
                       dinheiro += grupo[pos];
                       lotado += grupo[pos];
                       pos ++;
                      gruposdentro++;
                       if(pos >= N)
                           pos = 0;
                      if(gruposdentro == N)
                          break;
 
                   }
                    else
                    {
                        break;
                    }
               }
           }
 
           fprintf(saida, "Case #%d: %d\n", i+1, dinheiro);
     }
 
 
 
 
 
     return 0;
 
 }
 
 
 
 

