#include<stdio.h>
 
 void main()
 {
 	  int t, i, n, j ;
 	  long  k , temp;
 	  
 	  scanf("%d",&t);
 	  
 	  for(i = 0; i < t ; i++)
 	  {  
 		 scanf("%d %ld",&n,&k);
 		 printf("Case #%d: ",i+1);
 		 
 		 temp = 0 ;
 		 
 		 for(j = n-1 ; j >= 0; j--)
 		   if( (k&(1L<<j)) == 0)
 		   {
 		      printf("OFF\n");
 		      break ;
 		   }
 		   
 		 if(j < 0)
 		   printf("ON\n");  
 		 
 	  }
 }

