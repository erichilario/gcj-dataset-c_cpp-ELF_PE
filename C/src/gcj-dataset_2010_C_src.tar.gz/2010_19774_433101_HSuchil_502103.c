
 int S[30];
 
 void checa(int n){
 int a=0,c;
 
 while(a<n){
 if(S[a]==1){
 		S[a]=0;
 		a++;
 	}
 if(S[a]==0){
 		S[a]=1;
 		break;
 	}
 }
 }
 
 int main(){
 int T,N,K,a,b,v,c;
 
 scanf("%i",&T);
 for(b=1;b<=T;b++){
 N=K=v=0;
 
 for(a=0;a<30;a++){
 S[a]=0;
 }
 
 scanf("%i %i",&N,&K);
 for(a=0;a<K;a++){
 checa(N);
 }
 
 for(a=0;a<N;a++){
 if(S[a]==0) v=1;
 }
 
 if(v==1){
 	printf("Case #%i: OFF\n",b);
 } else {
 	printf("Case #%i: ON\n",b);
 
 }
 }
 
 
 return 0;
 }

