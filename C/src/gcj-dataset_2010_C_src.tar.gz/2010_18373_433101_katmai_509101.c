#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 
 int main(void)
 {
   unsigned int T,N,i,j,l;
   unsigned long int R,k,ngroup;
   unsigned long int g[1000];
   unsigned long long y,oldy;
   FILE *file=fopen("input","r");
   fscanf(file,"%u\n",&T);
   for (i=0;i<T;i++)
   {
     fscanf(file,"%lu %lu %u\n",&R,&k,&N);
     for (j=0;j<N;j++)
     {
       fscanf(file,"%lu ",&(g[j]));
     }
     fscanf(file,"\n");
     printf("Case #%u: ",i+1);
     y=0;
     oldy=0;
     l=0;
     ngroup=0;
     for (j=0;j<R;j++)
     {
       while (((y+g[l]-oldy)<=k)&&(ngroup<N))
       {
 	y+=g[l];
 	l++;
 	if (l>=N)
 	{
 	  l=0;
 	}
 	ngroup++;
       }
       oldy=y;
       ngroup = 0;
     }
     printf("%llu\n",y);
   }
   fclose(file);
   return EXIT_SUCCESS;
 }
