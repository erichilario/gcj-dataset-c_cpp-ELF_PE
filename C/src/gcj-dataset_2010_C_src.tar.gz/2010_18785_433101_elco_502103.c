#define NOPOWER_OFF  0
 #define NOPOWER_ON  1
 #define POWER_OFF  2
 #define POWER_ON 3
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define loop(var, min, max) for(long var = min; var < max; var++)
 
 int main() {
 	int num_cases;
 	scanf("%d\n", &num_cases);
 	loop( i,1,num_cases+1) {
 		int n;
 		int k;
 		scanf("%d %d\n", &n, &k);
 		printf ("Case #%d: %s\n", i, (k>>(n-1))%2 ? "ON" : "OFF" );
 	}
 	return 0;
 }
 

