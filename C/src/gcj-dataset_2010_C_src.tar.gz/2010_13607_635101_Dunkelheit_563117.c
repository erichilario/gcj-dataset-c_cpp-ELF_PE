#include <stdio.h>
 #include <string.h>
 
 
 int main()
 {
 	static char dirs[200][100000];
 	static char news[100][10000];
 	static char str[10000];
 	int T,t,n,m,i,j,k,l1,l2,minl;
 	scanf("%d",&T);
 	sprintf(dirs[0],"/");
 	for(t=1;t<=T;t++){
 		scanf("%d %d\n",&n,&m);
 		n++;
 		//printf("%d %d\n",n,m);
 		
 		for(i=1;i<n;i++){
 			scanf("%s",str);
 			sprintf(dirs[i],"%s/",str);
 		}
 		for(i=0;i<m;i++){
 			scanf("%s",str);
 			sprintf(news[i],"%s/",str);
 		}	
 	//	for(i=0;i<n;i++) printf("%s\n",dirs[i]);
 
 
 		int maxs=0,sls;
 		int cnt = 0;
 		for(i=0;i<m;i++) {
 			l1 = strlen(news[i]);
 			maxs = 0;
 			for(j=0;j<n;j++){
 				l2 = strlen(dirs[j]);
 				//printf("strlen: %d\n",l2);
 				if(l1<=l2) minl = l1; else minl=l2;
 				sls = 0;
 				for(k=0;k<minl;k++) {
 					if(news[i][k]!=dirs[j][k]) {	
 						break;
 					}
 					if(dirs[j][k]=='/') sls++;
  
 				}
 				if(sls>maxs) maxs = sls;	
 			}
 			//printf("maxsls: %d\n",maxs);
 			sls = 0;
 			for(k=0;k<l1;k++){
 				if(news[i][k]=='/') sls++;
 			}
 			//printf("sls: %d\n",sls);
 			if(sls>=maxs) {
 				cnt+= sls-maxs;	
 				sprintf(dirs[n],news[i]);
 				n++;
 			}
 		}
 		printf("Case #%d: %d\n",t,cnt);
 	//	for(i=0;i<m;i++){
 	//		
 	//	}
 	}
 	//printf("dasdas\n");
 	
 }

