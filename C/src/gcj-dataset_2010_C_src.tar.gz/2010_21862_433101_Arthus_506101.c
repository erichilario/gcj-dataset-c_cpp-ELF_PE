#include<stdio.h>
 int g(int i,int j)
 {
 	int t,a,b;
 	if(i<j){ a = i;b = j;}
 	else {a = j;b = i;}
 
 	t = b%a;
 	while(t!=0)
 	{
 		a = t;
 		b = a;
 		t = b%a;
 	}
 	return a;
 }	
 
 	
 int gcd(int i,int j,int k)
 {
 	int t;
 	if(i == 0 || j == 0) t = k;
 	else t = g(i,j);
 	if(k == 0) return t;
 	return g(k,t);
 }	
 int main()
 {
 	int c,n,t[3],i,j,in,k;
 	scanf("%d",&c);
 	for(in=1;in<=c;in++)
 	{
 		printf("Case #%d: ",in);
 		scanf("%d",&n);
 		if(n==2)
 		{
 			scanf("%d %d",&t[0],&t[1]);
 			if(t[0] > t[1])
 			{
 				i = t[0]-t[1];
 				j = t[1]%i;
 				if(j != 0) j = i-j;
 			}	
 			else 
 			{
 				i = t[1]-t[0];
 				if(i == 0) j = 0;
 				else
 				{
 					j = t[0]%i;
 					if(j!=0) j = i-j;
 				}	
 			}	
 			printf("%d\n",j);
 		}
 		else
 		{
 			
 			scanf("%d %d %d",&t[0],&t[1],&t[2]);
 			if(t[0] > t[1] ) i = t[0]-t[1];
 			else i = t[1]-t[0];
 			if(t[0] > t[2])  j = t[0]-t[2];
 			else j = t[2]-t[0];
 			if(t[1] > t[2])  k = t[1]-t[2];
 			else k = t[2]-t[1];
 			
 			i = gcd(i,j,k);
 			if(i == 0) j = 0;
 			else j = t[0]%i;
 			if(j != 0) j = i-j;
 			printf("%d\n",j);
 		}
 	}return 0;
 }	

