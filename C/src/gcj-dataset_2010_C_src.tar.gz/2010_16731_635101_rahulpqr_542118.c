#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     int tc,n,k,b,t,**x,**v,**u;
     int count,swap,gap,i,j,max;
 
 
     FILE *input=fopen("B-small-attempt2.in","r");
     FILE *output=fopen("a1.out","w");
     fscanf(input,"%d",&tc);
     x=(int **)malloc(tc*sizeof(int *));
     v=(int **)malloc(tc*sizeof(int *));
     u=(int **)malloc(tc*sizeof(int *));
     for(j=0;j<tc;j++)
     {
         fscanf(input,"%d%d%d%d",&n,&k,&b,&t);
         x[j]=(int *)malloc(n*sizeof(int));
         v[j]=(int *)malloc(n*sizeof(int));
         u[j]=(int *)malloc(n*sizeof(int));
         for(i=0;i<n;i++)
             fscanf(input,"%d",&x[j][i]);
         for(i=0;i<n;i++)
         {
             fscanf(input,"%d",&v[j][i]);
             u[j][i]=x[j][i]+(v[j][i]*t); // u=finaldistance=x + vt;
         }
     }
     for(j=0;j<tc;j++)
     {
         count=0;
         gap=0;
         swap=0;
         max=0;
         fprintf(output,"Case #%d: ",(j+1));
         for(i=n-1;i>=0;i--)
         {
             if((u[j][i]>=b))
             {
                 count++;
                 swap=swap+gap;
             }
             else
             {
                 gap++;
                 //max=(v[j][i]>max)?v[j][i]:max;
 
             }
 
             if(count>=k)
                 break;
 
 
         }
         if(count>=k)
             fprintf(output,"%d\n",swap);
         else
             fprintf(output,"IMPOSSIBLE\n");
 
 
     }
 
 
 
 
 }

