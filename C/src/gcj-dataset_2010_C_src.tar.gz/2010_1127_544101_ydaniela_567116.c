#include <stdio.h>
 #include <stdlib.h>
 
 int main() {
 	int i, j, k, l, m, n, o, p, r, q, s, t,b;
 	char mat1[55][55], mat2[55][55];
 	
 	scanf("%d", &t);
 	for (q = 1; q<= t; q++) {
 		scanf(" %d %d ", &n, &k);
 		for (i = 0; i < n; i++) {
 			scanf(" %s ", mat1[i]);
 		}
 		m = 0;
 		for (i = n-1; i >= 0; i--) {
 			l = n-1;
 			for (j = n-1; j >= 0; j--) {
 				if (mat1[i][j] != '.') {
 					mat2[l][m] = mat1[i][j];
 					l--;
 				}
 			}	
 			for (; l >= 0; l--) {
 				mat2[l][m] = '.';	
 			}
 			m++;
 		}
 		r = 0;
 		b = 0;
 		for (i = 0; i < n; i++) {
 			j = 1;
 			if (mat2[i][0] == mat2[i][1] && mat2[i][1] != '.') {
 				l = 1;	
 			} else {
 				l = 0;
 			}
 			while (j < n) {
 				if (mat2[i][j-1] == mat2[i][j] && mat2[i][j] != '.') {
 					j++;
 					l++;	
 				} else {
 					j++;
 					if (mat2[i][j-1] == mat2[i][j] && mat2[i][j] != '.') {
 						l = 1;	
 					} else {
 						l = 0;
 					}
 				}
 				if (l == k) {
 					if (mat2[i][j-1] == 'R') {
 						r++;	
 					} else {
 						b++;	
 					}
 				}
 			}	
 		}
 		for (i = 0; i < n; i++) {
 			j = 1;
 			if (mat2[0][i] == mat2[1][i] && mat2[0][i] != '.') {
 				l = 1;	
 			} else {
 				l = 0;
 			}
 			while (j < n) {
 				if (mat2[j-1][i] == mat2[j][i]  && mat2[j][i] != '.') {
 					j++;
 					l++;	
 				} else {
 					j++;
 					if (mat2[j-1][i] == mat2[j][i] && mat2[j][i] != '.') {
 						l = 1;	
 					} else {
 						l = 0;
 					}
 				}
 				if (l == k) {
 					if (mat2[j-1][i] == 'R') {
 						r++;	
 					} else {
 						b++;	
 					}
 				}
 			}	
 		}
 		for (i = 0; i < n; i++) {
 			for (j = 0; j < n; j++) {
 				if (mat2[i][j] != '.') {
 					l = i;
 					m = j;
 					o = 0;
 					p = mat2[i][j];
 					while (l < n && m < n && p == mat2[l][m]) {
 						l++;
 						m++;
 						o++;
 					}	
 					if (o >= k) {
 						if (mat2[i][j] == 'R') {
 							r++;	
 						} else {
 							b++;	
 						}
 					}
 				}	
 			}	
 		}
 		for (i = 0; i < n; i++) {
 			for (j = n-1; j >= 0; j--) {
 				if (mat2[i][j] != '.') {
 					l = i;
 					m = j;
 					o = 0;
 					p = mat2[i][j];
 					while (l < n && m >= 0 && p == mat2[l][m]) {
 						l++;
 						m--;
 						o++;
 					}	
 					if (o >= k) {
 						if (mat2[i][j] == 'R') {
 							r++;	
 						} else {
 							b++;	
 						}
 					}
 				}	
 			}	
 		}
 		if (r > 0 && b > 0) {
 			printf("Case #%d: Both\n", q);	
 		} else if (r > 0 && b == 0) {
 			printf("Case #%d: Red\n", q);
 		} else if (r == 0 && b > 0) {
 			printf("Case #%d: Blue\n", q);
 		} else {
 			printf("Case #%d: Neither\n", q);
 		}
  	}
 	
 	return 0;	
 }

