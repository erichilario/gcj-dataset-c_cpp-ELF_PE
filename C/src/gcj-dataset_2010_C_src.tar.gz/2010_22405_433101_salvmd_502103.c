#include <stdio.h>
 #include <stdlib.h>
 
 unsigned long long fast_pow(unsigned long long base, unsigned long long power) {
 	if(power == 0) {
 		return 1;
 	}
 	else if(power % 2 == 0) {
 		unsigned long long temp = fast_pow(base,power/2);
 		return temp * temp;
 	}
 	else {
 		return base * fast_pow(base,power-1);
 	}
 }
 
 int main() {
 	unsigned long long N, K, T, i;
 	scanf("%llu",&T);
 	for(i = 0; i < T; i++) {
 		scanf("%llu %llu",&N,&K);
 		unsigned long long x = fast_pow(2,N) - 1;
 		unsigned long long res = x & K;
 		if(res == x) {
 			printf("Case #%llu: ON\n",(i+1));
 		}
 		else {
 			printf("Case #%llu: OFF\n",(i+1));
 		}
 	}
 }
 
 

