#include <stdlib.h>
 #include <stdio.h>
 #include <stdbool.h>
 #include <assert.h>
 #include <string.h>
 #include <stdint.h>
 
 struct snapper
 {
 		bool state;
 		bool power;
 };
 
 struct snapper *snappers = NULL;
 uint64_t snappers_length = 0;
 bool light_is_on = false;
 
 void allocate_chain(void)
 {
 		if (snappers) {
 				free(snappers);
 		}
 		snappers = malloc(sizeof(struct snapper) * snappers_length);
 		memset(snappers, false, 
 				snappers_length * sizeof(struct snapper));
 		assert(snappers != NULL);
 }
 
 void output(const uint64_t _case)
 {
 		printf("Case #%llu: %s\n", _case, (light_is_on ? "ON" : "OFF"));
 }
 
 void set_power(void)
 {
 		bool power = true;
 		uint64_t it = 0;
 		while (it < snappers_length) {
 				snappers[it].power = power;
 				power = snappers[it].power && snappers[it].state;
 				++it;
 		}
 		light_is_on = snappers[it-1].power && snappers[it-1].state;
 }
 
 
 void toggle_chain(void)
 {
 		uint64_t it = snappers_length;
 		do {
 				--it;
 				if (snappers[it].power) {
 						snappers[it].state = !snappers[it].state;
 				}
 		} while (it > 0);
 		set_power();
 }
 
 int main(const int argc, const char **argv)
 {
 		FILE *entry = fopen(argv[1], "r");
 		uint64_t cases, snaps, it = 0;
 
 		assert(entry != NULL);
 		assert(fscanf(entry, "%llu", &cases) == 1);
 
 		while (it < cases) {
 				assert(fscanf(entry, "%llu %llu", &snappers_length, 
 								&snaps) == 2);
 				allocate_chain();
 				snappers[0].power = true;
 				snappers[0].state = false;
 				uint64_t it2 = 0;
 				while (it2 < snaps) {
 						toggle_chain();
 						it2++;					  
 				}
 				
 				output(it + 1);
 				++it;
 				light_is_on = false;
 		}
 		
 		fclose(entry);
 		free(snappers);
 		return 0;
 }
 		

