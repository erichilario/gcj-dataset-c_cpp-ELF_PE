#include <stdio.h>
 #include <math.h>
 
 
 void quicksort (int*, int, int);
 
 int funcao (int, int);
 
 main()
 {
     FILE *saida, *entrada;
 
     saida = fopen("texto2.txt", "w");
     entrada = fopen ("A-small.txt", "r");
 
     int C, N, *t, i, j, result, aux;
 
     fscanf(entrada, "%d", &C);
     for(i=0; i<C; i++)
     {
         fscanf(entrada, "%d", &N);
         t = (int*) malloc (N*sizeof(int));
 
         for(j=0; j<N; j++)
         {
             fscanf(entrada, "%d", &t[j]);
         }
 
         quicksort (t, 0, N-1);
 
         for(j=0; j<=N-2; j++)
         {
             if(t[N-2-j] > t[N-1]/2)
             {
                 result = 0;
                 break;
             }
 
             result = funcao(t[N-1], t[N-2-j]);
 
             if(j == 0)
             aux = result;
 
             if(result != aux)
             result = 0;
             break;
         }
             fprintf(saida, "Case #%d: %d\n", i+1, result);
         }
 
         free(t);
     return 0;
 }
 
 int funcao (int x, int y)
 {
 
     int k, resp;
 
     k = floor(x/y);
     resp = (x-y*k)/(k-1);
     return resp;
 }
 
 
 
 void quicksort (int *v, int A, int B)
 {
   int i, j;
   int x, y;
 
   i=A; j=B;
   x=v[(A+B)/2];
 
   do {
     while(v[i]<x && i<B) i++;
     while(x<v[j] && j>A) j--;
 
     if(i<=j) {
       y=v[i];
       v[i]=v[j];
       v[j]=y;
       i++; j--;
      }
     }while(i<=j);
 
     if(A<j) quicksort(v, A, j);
     if(i<B) quicksort(v, i, B);
 }
 

