#include <stdio.h>
 #include <math.h>
 
 int main(int argc, char ** argv) {
 	char c;
 	unsigned int T, R, k, N;
 
 	T = 0;
 	while((c = getchar()) != '\n')
 		T = T*10 + c - '0';
 	
 	int i;
 	for(i = 0; i < T; ++i) {
 		
 		R = 0; // number of runs
 		while((c = getchar()) != ' ')
 			R = R*10 + c - '0';
 
 		k = 0;  // max capacity
 		while((c = getchar()) != ' ')
 			k = k*10 + c - '0';
 
 		N = 0;  // number of groups
 		while((c = getchar()) != '\n')
 			N = N*10 + c - '0';
 
 		unsigned int g[N];
 		
 		unsigned int j;
 		for(j = 0; j < N; ++j) {
 			g[j] = 0;
 			while((c = getchar()) != ' ' && c != '\n' && c != EOF)
 				g[j] = g[j]*10 + c - '0';
 
 		}
 		
 		int index = 0, prev = 0;
 		unsigned int sum = 0;
 		for(j = 0; j < R; ++j) {
 			unsigned int num = 0;
 			prev = index;
 			while((num + g[index]) <= k) {
 				num += g[index];
 				index++;
 				index = index%N;
 				if(index == prev)
 					break;
 			}
 			
 			sum += num;
 		}
 
 		printf("Case #%d: %u\n", i+1, sum);
 		
 
 	
 
 	}
 
 
 }

