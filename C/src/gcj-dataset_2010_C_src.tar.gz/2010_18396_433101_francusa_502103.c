#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 
 int main(void){
   bool * status= NULL;
   int n=0, k=0, t=0;
   int plug= 0;     /* plug me dice hasta que posicion hay electricidad. */
   int i=0, j=0, l=0, m=0;
   FILE *fin= NULL;
   char *in= NULL;
   
   fin= fopen("input3", "r");
   fscanf(fin, "%i", &t);
   for(m=0;m<t;m++){
     plug= 0;
     fscanf(fin, "%i %i", &n, &k);
     status= (bool *)calloc(n, sizeof(bool));
 
     for(i=0;i<n;i++){
       status[i]= false;
     }
 
     for(j=0;j<k;j++){
       for(i=0;i<=plug;i++){
         status[i]= !status[i];
       }
       l=0; plug= 0;
       while(l<=n-1 && status[l]){
         plug++; l++;
       }
     }
     printf("Case #%i: %s", m+1, (plug == n) ? "ON\n" : "OFF\n");
     free(status);
   }
   fclose(fin);
   return 0;
 }
