#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 typedef enum {ON=0,OFF} state;
 
 int main(void)
 {
   unsigned int ncase,N,K,i,j,k;
   state curstate[40];
   state lamp;
   FILE *file=fopen("input","r");
   fscanf(file,"%u\n",&ncase);
   for (i=0;i<ncase;i++)
   {
     fscanf(file,"%u %u\n",&N,&K);
     printf("Case #%u: ",i+1);
     for (j=0;j<N;j++)
     {
       curstate[j]=OFF;
     }
     for (j=0;j<K;j++)
     {
       k=0;
       while(curstate[k]!=OFF)
       {
 	curstate[k]=OFF;
 	k++;
       }
       curstate[k]=ON;
     }
     lamp=ON;
     for (j=0;j<N;j++)
     {
       if (curstate[j]==OFF) lamp=OFF;
     }
     if (lamp==OFF) printf("OFF\n");
     else printf("ON\n");
   }
   fclose(file);
   return EXIT_SUCCESS;
 }
