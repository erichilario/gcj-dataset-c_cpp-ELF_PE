//#define DEBUG_PRINTS
 
 #ifdef DEBUG_PRINTS
 #define PRINT(X) printf X
 #else
 #define PRINT(X)
 #endif
 
 #include <stdio.h>
 
 FILE *fpIn, *fpOut;
 void exec( int testcase );
 
 int main( void )
 {	
 	int i,cases;
 
 	fpIn = fopen ( "A-large.in", "r" );
 	fpOut = fopen ( "output.out", "w" );
 
 	if ( fpIn == NULL || fpOut == NULL ) 
 	{	
 		PRINT (("Error: Input file not found\n"));
 		return 0;
 	}
 
 	fscanf (fpIn, " %d", &cases);
 
 	PRINT (("Total test cases:%d\n",cases));
 
 	for (i=1;i<=cases;i++)
 	{
 		exec(i);
 	}
 
 	fclose (fpIn);
 	fclose (fpOut);
 
 	return 0;
 }
 
 void exec( int testcase )
 {
 	int N, K,temp;
 	char *light="OFF";
 
 	fscanf (fpIn, " %d %lu", &N, &K);
 
 	temp = pow (2,N);
 	
 	if ( (K%temp) == (temp-1) )
 	{
 		light="ON";
 	}
 
 	PRINT ( ("Case #%d: %s\n", testcase, light ));
 
 	fprintf ( fpOut, "Case #%d: %s\n", testcase, light );
 
 	PRINT (("N=%d K=%d\n", N,K));
 }

