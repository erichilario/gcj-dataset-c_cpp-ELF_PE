
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 typedef enum { false = 0, true  = 1 } bool;
 bool  verbose = false;
 
 int getn(FILE *input) {
   char  buffer[256];
   int   pos = 0;
   short c;
   
   memset(buffer, 0, 256);
   
   while ((((c = fgetc(input)) != EOF) && (c != ' ')) && c != '\n') {
     buffer[pos++] = c;
   }
   return atoi(buffer);
 }
 
 int sequences_between(int len, int low, int high) {
   int i;
   int count = 0;
   
   if (len <= 0) return 0;
   if (len == 1) return 1;
   if (low >= high) return 0;
   if ((high - low) == 1) return 1;
   if ((high - low) >= len) return 0;
   
   for (i = low + 1; i < high; i++) {
     count += sequences_between(len - 1, i, high);
   }
   
   return count;
 }
 
 int calc_purities(int n) {
   int length;
   int count = 0;
   int len_position;
   int c;
     
   for (length = 1; length < n; length++) {
     // automatically set last item to n
     for (len_position = 0; len_position < length - 1; len_position++) {
       c = sequences_between(len_position, 1, length);
       if (verbose) printf("[%i] %i [", c, length - len_position - 1);  
       count += c;
       c = sequences_between(length - len_position - 2, length, n);
       if (verbose) printf("%i]\n", c);
       count += c;
     }
   }
   
   return count;
 }
 
 int main(int argc, char *argv[]) {  
   if ((argc < 2) || (argc > 3)) {
     printf("Input file required. Usage: %s filename [--verbose]\n", argv[0]);
     return 0;
   }
   if (argc == 3) {
     if (strcmp(argv[2], "--verbose") == 0) {
       verbose = true;
     } else {
       printf("Unknown option: %s\n", argv[2]);
     }
   }
   
   FILE *input;
   FILE *output;
   char  outfile[256]  = "";
   int   i, j;
   
   input = fopen(argv[1], "r");
   
   strcpy(outfile, argv[1]);
   i = (ulong)strrchr(outfile, '.') - (ulong)outfile;
   outfile[i + 1] = 'o';
   outfile[i + 2] = 'u';
   outfile[i + 3] = 't';
   output = fopen(outfile, "w");
   
   char  outdata[256]  = "";
   int   n_cases = 0;
   
   n_cases = getn(input);
   
   // case testing here
     // variables
   int n;
   int purities;
   
   for (i = 0; i < n_cases; i++) {
     
     // read input
     n = getn(input);
     
     // process data
     purities = calc_purities(n);
     
     // write output    
     sprintf(outdata, "Case #%i: %i\n", i + 1, purities);
     printf(outdata);
     fprintf(output, outdata);
   }
  
   fclose(input); 
   fclose(output); 
   return 0;
 }

