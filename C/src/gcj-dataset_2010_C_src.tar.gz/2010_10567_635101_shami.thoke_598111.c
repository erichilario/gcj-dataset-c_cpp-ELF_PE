#include <iostream>
 #include <vector>
 #include <set>
 #include <map>
 #include <string>
 using namespace std;
 
 long long com(long long x) 
 {
   if(x <= 4) 
     return (x-1);
   long long y = 0;
   for(long long i = x-2; i >= 3; --i) {
     long long z = x - i; 
     z = z % 100003;
     y = y + z;
   }
   return (y + 3);
 }
 
 int main(int argc, char* argv[])
 {
   if(argc != 2) {
     cout << "Usage: ./a.out <input_file>" << endl;
     exit(0);
   }
   FILE* fp = fopen (argv[1], "r");
   if(fp == NULL) {
     cout << "Can't open file " << argv[1] << " for read operation" << endl;
     exit(0);
   }
   int T;
   fscanf (fp, "%d", &T);
   for(int tc = 1; tc <= T; ++tc) {
     int N;
     fscanf (fp, "%d", &N);
     cout << "Case #" << tc << ": " << com(N) << endl;
   }
 }

