#include <stdio.h>
 #include <stdlib.h>
 
 #define IN fpin
 #define OUT fpout
 
 FILE *fpin,*fpout;
 
 typedef struct node_s{
 	int size;
 	struct node_s* next;
 	long long dollar;
 	struct node_s* next_head;
 }node,*node_p;
 
 node_p create_list(int n)
 {
 	int i = 0;
 	node_p head = NULL, tail= NULL;
 	for(i = 0; i < n; i ++)
 	{
 		node_p tmp = (node_p)malloc(sizeof(node));
 		tmp->next_head = NULL;
 		tmp->dollar = 0;
 		tmp->next = 0;
 		fscanf(IN, "%d", &(tmp->size));
 		if(head == NULL){
 			head = tmp;
 			tail = tmp;
 		}else{
 			tail->next = tmp;
 			tail = tmp;
 		}
 
 	}
 	tail->next = head;
 	return head;
 }
 
 node_p fill_a_run(node_p queue_head, long long capacity, int total_groups, long long *dollar)
 //rutern the new head of queue, increment the income of this run
 {
 	node_p iter = queue_head;
 	long long load = 0;
 	int loaded_groups = 0;
 	while((load + iter->size) <= capacity && loaded_groups+1 <= total_groups){
 		load += iter->size;
 		loaded_groups ++;
 //		printf("loaded groups: %d\n", loaded_groups);
 		iter = iter->next;
 	}
 	*dollar = load;
 	return iter;
 }
 
 void compute_list(node_p head, long long capacity, int total_groups)
 //computer dollars and next head
 {
 	node_p iter = head;
 	while(iter-> next_head == NULL)
 	{	
 		long long dollar;
 		iter->next_head = fill_a_run(iter, capacity, total_groups, &dollar);
 		iter->dollar = dollar;
 		iter = iter->next;
 	}
 }
 
 
 void main()
 {
 	fpin = fopen("C-small-attempt0.in", "r");
 	fpout = fopen("themepark_small.out", "w");
 
 	printf("1\n");
 
 	int t;
 	fscanf(IN, "%d", &t);
 
 	printf("2\n");
 	int i;
 	for(i = 0; i < t; i++)
 	//loop for t test cases
 	{
 		long long r, k;
 		int n;
 
 
 		printf("%d test cases\n", i);
 
 		fscanf(IN, "%llu", &r);	//r: number of runs 10^8
 		printf(" runs: %llu\n", r);
 		fscanf(IN, "%llu", &k);	//k: capacity of a single run 10^9
 		printf(" capacity: %llu\n", k);
 		fscanf(IN, "%d", &n);	//n: number of groups 10^7
 		printf(" groups: %d\n", n);
 
 		long long income_sum = 0;
 		node_p queue_head = create_list(n);
 		compute_list(queue_head, k, n);
 		node_p iter = queue_head;
 		long long runs = 0;
 		for(runs = 0; runs < r; runs++){
 			income_sum+=iter->dollar;
 			iter = iter->next_head;
 //			if(runs > 10000)
 //				exit(0);
 		}
 
 		fprintf(OUT ,"Case #%d: %llu\n", i+1, income_sum);
 
 		//free list
 	/*	if(n == 1)
 			free(queue_head);
 		else{
 			node_p pre = queue_head;
 			while(queue_head != NULL){
 				pre = queue_head;
 				queue_head = queue_head->next;
 				free(pre);
 			}
 				
 		}*/
 	}
 }

