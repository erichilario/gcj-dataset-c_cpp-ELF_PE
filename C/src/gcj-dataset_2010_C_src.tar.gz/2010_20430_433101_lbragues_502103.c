#include <stdio.h>
 #include <string.h>
 
 int main(){
 	int tcase=0;
 	int cases;
 	int nsockets,snaps;
 	int i,tmp,state,sockets,test=0;
 	scanf("%d",&cases);
 	for(tcase=1;tcase<=cases;++tcase){
 		scanf("%d %d",&nsockets,&snaps);
 		printf("Case #%d: ",tcase);
 		state=0;
 		sockets=0;
 		test=0;
 		for(i=0;i<nsockets;++i){
 			sockets=(sockets << 1) | 0x01;
 		}
 		for(i=0;i<snaps;++i){
 			if(state==sockets){
 				test=1;	
 			}
 			if(i<4){
 				state=i+1;
 			}else{
 				tmp=state & 0x01;
 				if(tmp==0x00){
 					if(test==0)
 						state=state*2-1;
 					else
 						if(i%2==0)
 							state=sockets;
 						else
 							state=0;
 				}else{
 					if(test==0)
 						++state;
 					else
 						if(i%2==0)
 							state=sockets;
 						else
 							state=0;
 				}	
 			}	
 		}
 		if(sockets==state)
 			printf("ON\n");
 		else
 			printf("OFF\n");
 		
 		
 	}
 	return 0;	
 }
