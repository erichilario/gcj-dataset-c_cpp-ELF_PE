#include <stdio.h>
 #include <stdlib.h>
 
 void snap(int casenum);
 int manual[30];
 
 int manualCheck(int N, int K) {
 	for (int i = 0; i < N; i++) {
 		manual[i] = 0;
 	}
 	
 	for (int k = 0; k < K; k++) {
 		int powerindex = 0;
 		for (int i = 0; i < N; i++) {
 			if (powerindex == i) {
 				if (manual[i] == 1) {
 					powerindex++;
 				}
 				manual[i] = (manual[i] + 1) % 2;
 			}
 //			printf("%d ", manual[i]);
 		}
 //		printf("\n");
 	}
 	
 	int result = 0;
 	for (int i = 0; i < N; i++) {
 		result += manual[i];
 	}
 	
 	if (N == result) {
 		return 1;
 	} else {
 		return 0;
 	}
 }
 
 int main(int argc, char** argv) {
 	int T = 0;
 	scanf("%u\n", &T);
 	for (int i = 0; i < T; i++) {
 		snap(i+1);
 	}
 	
 	return 0;
 }
 
 void snap(int casenum) {
 	int N;
 	int twoN;
 	unsigned long int K;
 	scanf("%u %lu\n", &N, &K);
 	twoN = 1 << N;		//2^N
 
 	//ON iff K mod 2^N == 2^N-1
 	if ((K % twoN) == twoN - 1) {
 	//	if (manualCheck(N, K) != 1) {
 	//		printf("Case #%u: ON error\n", casenum);
 	//	} else {
 			printf("Case #%u: ON\n", casenum);
 	//	}
 	} else {
 	//	if (manualCheck(N, K) != 0) {
 	//		printf("Case #%u: OFF error\n", casenum);
 	//	} else {
 			printf("Case #%u: OFF\n", casenum);
 	//	}
 	}
 }

