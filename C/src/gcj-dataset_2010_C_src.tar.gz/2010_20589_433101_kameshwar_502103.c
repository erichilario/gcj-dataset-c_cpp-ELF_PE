#include <stdio.h>
 #include <stdlib.h>
 
 #define ON 1
 #define OFF 0
 
 int main() {
 
 	FILE* op;
 	int N, T, i, h;
 	long long int K, j;
 	int *snapper, sum;
 
 	op = fopen("output.txt", "w");
 	scanf("%d", &T);
 
 	for ( i = 1; i <= T; i++ ) {
 		scanf("%d%lld", &N, &K);
 		snapper = (int *)malloc(N*sizeof(int));
 		for ( h = 0; h < N; h++ ) snapper[h] = 0;
 
 		for ( j = 0; j < K; j++ ) {
 			h = 0;
 			while( snapper[h]!=0 && h < N) {
 				snapper[h] = snapper[h]?0:1;
 				h++;
 			}
 			if ( h < N )
 				snapper[h] = 1;
 		}
 		sum = 0;
 		for ( h = 0; h < N; h++ ) {
 			sum += snapper[h];
 		}
 
 		fprintf(op, "Case #%d: ", i);
 		if ( sum == N ){
 			fprintf(op, "ON\n");
 		}
 		else {
 			fprintf(op, "OFF\n");
 		}
 		free(snapper);
 	}
 	fclose(op);
 	
 	return 0;
 }
 
 

