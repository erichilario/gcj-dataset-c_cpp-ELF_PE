#include<stdio.h>
 #include<string.h>
 
 int main()
 {
     freopen("00C.in","r",stdin);
     freopen("00C.out","w",stdout);
 
     int t,r,k,n,ans;
     int g[12];
     int i,j,ii,jj;
     scanf("%d",&t);   
     for (i=1;i<=t;i++)
     {
         scanf("%d%d%d",&r,&k,&n);
         for (j=1;j<=n;j++) scanf("%d",&g[j]);
         ans=0;
         for (ii=1;ii<=r;ii++)                
         {
             int temp=0,flag;
             for (j=1;j<=n;j++) 
             {
                 if (temp+g[j]<=k) temp=temp+g[j];
                 else break;
             }
             flag=j-1;
             ans=ans+temp;
             for (j=1;j<=flag;j++)
             {
                 for (jj=1;jj<=n;jj++) g[jj-1]=g[jj];
                 g[n]=g[0];
             }
         }
         printf("Case #%d: %d\n",i,ans);
     }
     return 0;
 }

