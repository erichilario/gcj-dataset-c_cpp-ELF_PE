#include <stdio.h>
 
 int main(void)
 {
    int F[512], i, C, c;
 
    F[0] = F[1] = 1;
 
    for(i = 2; i < 512; ++i)
    {
       F[i] = (F[i-2] + F[i-1]) % 100003;
    }
 
    scanf("%d", &C);
    for(c = 1; c <= C; ++c)
    {
       int x;
       scanf("%d", &x);
 
       printf("Case #%d: %d\n", c, F[x-1]);
    }
 
    return 0;
 }

