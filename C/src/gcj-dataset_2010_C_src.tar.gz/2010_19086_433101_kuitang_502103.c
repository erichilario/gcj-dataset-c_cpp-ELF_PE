#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define SNAPPERS 34
 #define SNAPS    1000
 
 #ifdef DEBUG
 #undef DEBUG
 #endif // DEBUG
 
 int s[SNAPPERS][2];
 FILE *in, *out;
 
 inline int powered(int n) {
     return s[n][0];
 }
 
 inline int on(int n) {
     return s[n][1];
 }
 
 int main(int argc, char **argv) {
     in  = fopen(argv[1], "r");
     out = fopen(argv[2], "w");
 
     int t;
     fscanf(in, "%d\n", &t);
 
     int n, k;
     for (int i = 1; i <= t; i++) {
         memset(s, 0, sizeof(s));
         fscanf(in, "%d %d\n", &n, &k);
 
         for (int sn = 0; sn < k; sn++) { // snap
             s[0][0] = 1; // first snapper always powered
             for (int ap = 0; ap < n; ap++) { // snapper
                 if (s[ap][0]) { // if powered
                     s[ap][1] = !s[ap][1]; // toggle
                 }
             }
             // resolve power: powered if previous is on and powered
             for (int ap = 1; ap < n; ap++) {
                 s[ap][0] = s[ap - 1][0] && s[ap - 1][1];
             }
             // Check
         }
         fprintf(out, "Case #%d: ", i);
         if (s[n - 1][0] && s[n - 1][1]) {
             fprintf(out, "ON\n");
         } else {
             fprintf(out, "OFF\n");
         }
     }
     fclose(in);
     fclose(out);
     return 0;
 }
 

