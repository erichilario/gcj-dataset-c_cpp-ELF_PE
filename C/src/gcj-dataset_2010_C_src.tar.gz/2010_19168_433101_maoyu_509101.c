#include<stdio.h>
 #include<string.h>
 int cmp[1001][1001];
 int num[100001];
 
 int main()
 {
     freopen("00C.in","r",stdin);
     freopen("00C.out","w",stdout);
 
     int t,r,k,n;
     long long ans;
     int i,j,ii,jj;
     int panduan,len,be;
     scanf("%d",&t);   
     for (i=1;i<=t;i++)
     {
         scanf("%d%d%d",&r,&k,&n);
         memset(num,0,sizeof(num));
         for (j=1;j<=n;j++) scanf("%d",&cmp[1][j]);
 
         long long temp=0;
         int flag;
         for (j=1;j<=n;j++) 
         {
             if (temp+cmp[1][j]<=k) temp=temp+cmp[1][j];
             else break;
         }
         flag=j-1;
         num[1]=temp;
         for (j=flag+1;j<=n;j++) cmp[2][j-flag]=cmp[1][j];
         for (j=1;j<=flag;j++) cmp[2][n-flag+j]=cmp[1][j];
         panduan=1;
         len=1; be=1;
         for (j=1;j<=n;j++)
             if (cmp[1][j]!=cmp[2][j])
             {
                 panduan=0;
                 break;
             }
 
         while (panduan==0)
         {
             len++;
             int temp=0;
             for (j=1;j<=n;j++) 
             {
                 if (temp+cmp[len][j]<=k) temp=temp+cmp[len][j];
                 else break;
             }
             flag=j-1;
             num[len]=temp;
             for (j=flag+1;j<=n;j++) cmp[len+1][j-flag]=cmp[len][j];
             for (j=1;j<=flag;j++) cmp[len+1][n-flag+j]=cmp[len][j];
             for (ii=1;ii<=len;ii++)
             {
                 panduan=1;
                 for (jj=1;jj<=n;jj++)
                     if (cmp[ii][jj]!=cmp[len+1][jj])
                     {
                         panduan=0;
                         break;
                     }
                 if (panduan)
                 {
                     be=ii;
                     break;
                 }
             }    
         }
 
         ans=0;
         j=1;
         while (j<=be-1 && (r-1)>=0)
         {
             ans=ans+num[j];
             r--;
             j++;
         }
         temp=0;
         for (j=be;j<=len;j++) temp=temp+num[j];
         ans=ans+(r/(len-be+1)*temp);
         r=r-(r/(len-be+1)*(len-be+1));
         for (j=1;j<=r;j++)
         {
             ans=ans+num[be+j-1];
         }
 
         printf("Case #%d: %lld\n",i,ans);
     }
     return 0;
 }

