#include<stdio.h>
 #include<math.h>
 int Gcd(int i,int j){
  if(i==0) return j;
  else if(j==0) return i;
  if(i>=j) Gcd(i%j,j);
  else if(j>i) Gcd(i,j%i);
 
 }
 
 int main()
 {
   
   FILE *p=fopen("a.txt","w");
   int T,N,i,j,k,c=0,a[10];
   int gcd[10];
   scanf("%d",&T);
   
   while(T--){
     scanf("%d",&N);
     for(i=1;i<=N;i++)
       scanf("%d",&a[i]);
     for(i=1;i<=N;i++)
       for(j=1;j<=N;j++)
           if(a[i]>a[j]){k=a[i];a[i]=a[j];a[j]=k;} 
 
      //printf("%d%d%d",a[1],a[2],a[3]); 
     if(N==2)
        gcd[1]=a[1]-a[2];
     else if(N==3){
        gcd[2]=Gcd(a[1]-a[2],a[2]-a[3]);
        gcd[3]=Gcd(a[1]-a[3],a[1]-a[2]);
        gcd[1]=Gcd(gcd[2],gcd[3]);
        }
 
     fprintf(p,"Case #%d: %d\n",++c,(gcd[1]-1));
     
    }
    fclose(p);
    
 return 0;
 }

