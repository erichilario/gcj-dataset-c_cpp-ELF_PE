#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc,char** argv)
 {
     FILE* in = fopen(argv[1],"r");
 	FILE* out = fopen("output","w+");
 	int T,N,K;
     fscanf(in,"%d",&T);
     if(T>=1 && T<=10000){
     	int i = 0;
     	while(i < T){
         	i++;
         	fscanf(in,"%d %d",&N,&K);
        		 if(N >=1 && N <= 10 && K >= 0 && K <= 100){
 			int j = 1;
 			j = j<<N;
 			K = K % j;
 			if(K+1 == j)
 				fprintf(out,"Case #%d: ON\n",i);
 			else
 				fprintf(out,"Case #%d: OFF\n",i);
     		}
     	}	
     }
 }
 

