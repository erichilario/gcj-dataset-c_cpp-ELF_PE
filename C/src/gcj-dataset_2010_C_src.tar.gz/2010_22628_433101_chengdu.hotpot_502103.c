#include <stdio.h>
 
 #define MAX_N 30
 
 unsigned long c[MAX_N];
 
 void precompute(int n){
 	c[0] = 1; 
 	int i;
 	for(i = 1; i < n; i++){
 		c[i] = 2*c[i-1] + 1;
 	}
 }
 
 void main()
 {
 	FILE *infp = fopen("A-small-attempt0.in", "r");
 	FILE *fp = fopen("snapper_small.out", "w");
 	precompute(MAX_N);
 	int t;
 	fscanf(infp, "%d", &t);
 	int i;
 	for(i = 0; i < t; i++)
 	{
 		int n;
 		unsigned long  k;
 		fscanf(infp, "%d", &n);
 		fscanf(infp,"%lu", &k);
 		if(k%(c[n-1]+1) == c[n-1])
 			fprintf(fp, "Case #%d: ON\n", i+1);
 		else
 			fprintf(fp, "Case #%d: OFF\n", i+1);
 
 	}
 }
 

