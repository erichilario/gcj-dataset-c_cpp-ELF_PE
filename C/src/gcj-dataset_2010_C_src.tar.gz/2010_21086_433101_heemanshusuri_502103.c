#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc,char** argv)
 {
     FILE* in = fopen(argv[1],"r");
 	FILE* out = fopen("output","w+");
 	int T,N;
 	long int K;
     fscanf(in,"%d",&T);
     if(T>=1 && T<=10000){
     	int i = 0;
     	while(i < T){
         	i++;
         	fscanf(in,"%d %ld",&N,&K);
        		 if(N >=1 && N <= 30 && K >= 0 && K <= 100000000){
 			int j = 1;
 			j = j<<N;
 			K = K % j;
 			if(K+1 == j)
 				fprintf(out,"Case #%d: ON\n",i);
 			else
 				fprintf(out,"Case #%d: OFF\n",i);
     		}
     	}	
     }
 }
 

