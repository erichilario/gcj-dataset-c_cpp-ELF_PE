#include<stdio.h>
 #include<stdlib.h>
 int D,I,M,N;
 /*inline int max(int a,int b){return a>b?a:b;}
 int comp(const void *p, const void *q){
     return *(int*)p - *(int*)q;
 }
 int middle(int a[],int n){
 	int b[100];
 	int i,c=0;
 	for(i=0;i<n;i++)
 		b[i]=a[i];
 	qsort(b,n,sizeof(int),comp);
 	return b[n/2];
 }*/
 int cost(int diff){
 	int needadjustcost,needinsertcost,c;
 	if(diff>M){
 		if(M==0)needinsertcost=999999;else needinsertcost=I*((diff-1)/M);
 		needadjustcost=diff-M;
 		if(needinsertcost>needadjustcost)c=needadjustcost;else c=needinsertcost;
 		if(c>D)return D;else return c;
 	}else{
 		return 0;
 	}
 }
 int main(){
 	int T,t,a[3],n,i,j,k,c,c1,c2,c3,c4,tmp,diff,diff1,diff2;
 	FILE *fp1=fopen("A-small.in","r");
 	FILE *fp2=fopen("A-small.out","w");
 	fscanf(fp1,"%d",&T);
 	for(i=1;i<=T;i++){
 		fscanf(fp1,"%d%d%d%d",&D,&I,&M,&N);
 		for(j=0;j<N;j++){
 			fscanf(fp1,"%d",&a[j]);
 		}
 		if(N==1){
 			c=0;
 		}else if(N==2){
 			c=0;
 			if(a[0]>a[1])t=a[0],a[0]=a[1],a[1]=t;
 			diff=a[1]-a[0];
 			c=cost(diff);
 		}else if(N==3){
 			c=0;
 			if(a[0]>a[2])t=a[0],a[0]=a[2],a[2]=t;
 			diff=a[2]-a[0];
 			if(a[1]<a[0])a[1]=a[0]+a[2]-a[1];
 			if(a[1]>=a[0] && a[1]<=a[2]){
 				diff1=a[1]-a[0];
 				diff2=a[2]-a[1];
 				c1=cost(diff);
 				c2=cost(diff1);
 				c3=cost(diff2);
 				c4=c2+c3;c=c4;
 				c4=c1+D;if(c4<c)c=c4;
 				c4=c2+D;if(c4<c)c=c4;
 				c4=c3+D;if(c4<c)c=c4;
 				c4=D+D;if(c4<c)c=c4;
 			}else{
 				diff1=a[1]-a[0];
 				diff2=a[1]-a[2];
 				c1=cost(diff);
 				c2=cost(diff1);
 				c3=cost(diff2);
 				c4=c2+c3;c=c4;
 				c4=c1+D;if(c4<c)c=c4;
 				c4=c2+D;if(c4<c)c=c4;
 				c4=c3+D;if(c4<c)c=c4;
 				c4=D+D;if(c4<c)c=c4;
 			}
 		}
 		fprintf(fp2,"Case #%d: %d\n",i,c);
 	}
 	fclose(fp1);
 	fclose(fp2);
 	return 0;
 }

