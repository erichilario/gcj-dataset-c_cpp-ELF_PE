#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <ctype.h>
 
 int debug = 0;
 #define DEB(n) if (debug) {n;}
 
 char line[100000];
 char level[100][100000];
 int nlevels, M, N;
 
 struct entry_s {
 	char name[100000];
 	struct entry_s *subdir;
 	struct entry_s *next;
 } *root;
 
 void split(char *line)
 {
 	nlevels = -1;
 	char *cp = line;
 	while (*cp++) 
 		{}
 	cp--;
 	while (!isprint((int)*cp))
 		*cp-- = '\0';
 	cp = strtok(line, "/");
 	do {
 		strcpy(level[++nlevels], cp);
 		DEB(printf("  got '%s'\n", cp))
 	} while ((cp = strtok(NULL, "/")) != NULL);
 }
 
 void dump(struct entry_s *first, int lev)
 {
 	while (first) {
 		printf("%*s%s\n", lev, "", first->name);
 		dump(first->subdir, lev+2);
 		first = first->next;
 	}
 }
 
 int add(struct entry_s *parent, int lev, int created)  {
 	if (lev > nlevels) return created;
 	DEB(printf("  %*sAdding '%s' @ %d\n", lev + 2, "", level[lev], lev))
 	if (!root) {
 		root = malloc(sizeof *root);
 		strcpy(root->name, level[0]);
 		root->next = root->subdir = NULL;
 		return add(root, lev+1, created+1);
 	}
 	struct entry_s *entry = !parent ? root : parent->subdir;
 	if (!entry) {
 		parent->subdir = malloc(sizeof *root);
 		parent->subdir->next = parent->subdir->subdir = NULL;
 		strcpy(parent->subdir->name, level[lev]);
 		return add(parent->subdir, lev+1, created+1);
 	}
 	struct entry_s *prev;
 	do {
 		if (!strcmp(entry->name, level[lev]))
 		{
 			return add(entry, lev+1, created);
 		}
 		prev = entry;
 		entry = entry->next;
 	} while (prev->next);
 	prev->next = malloc(sizeof *root);
 	strcpy(prev->next->name, level[lev]);
 	prev->next->next = prev->next->subdir = NULL;
 	return add(prev->next, lev+1, created + 1);
 }
 
 int main(int argc, char **argv)
 {
 	int cases, cas;
 	if (argc < 2) exit(1);
 	debug = argc > 2;
 	FILE *infile = fopen(argv[1], "rt");
 	if (!infile) exit(1);
 	fgets(line, sizeof line, infile);
 	sscanf(line, "%d", &cases);
 	for (cas = 1; cas<=cases; cas++) {
 		fgets(line, sizeof line, infile);
 		sscanf(line, "%d%d", &N, &M);
 		root = NULL;
 		DEB(printf("-- Case %d, N=%d M=%d - line='%s'\n", cas, N, M, line))
 		for (int i = 0; i < N; i++) {
 			fgets(line, sizeof line, infile);
 			DEB(printf("  Previous %s", line))
 			split(line);
 			add(NULL, 0, 0);
 		}
 		DEB(printf("<Previous>\n"); dump(root, 2); printf("</Previous>\n"))
 		int count = 0;
 		for (int i = 0; i < M; i++) {
 			fgets(line, sizeof line, infile);
 			DEB(printf("  Adding %s" , line))
 			split(line);
 			count = add(NULL, 0, count);
 		}
 		DEB(printf("<Added>\n"); dump(root, 2); printf("</Added>\n"))
 		printf("Case #%d: %d\n", cas, count);
 	}
 }

