#include<stdio.h>
 #include<math.h>
 
 
 int main()
 {
   int t,j=0;
   unsigned int n,k,an;
 
 
   scanf("%d",&t);
 
   for(j=0;j<t;j++)
   {
         an=0;
         scanf("%u %u",&n,&k);
         k++;
        // n++;
         n=pow(2,n)-1;
        // printf(" %d ",n);
         if(k%(n+1)==0)
         printf("Case #%d: ON\n",j+1);
         else
         printf("Case #%d: OFF\n",j+1);
 
 
   } //END TEST CASES WHILE
 
     return 0;
 }

