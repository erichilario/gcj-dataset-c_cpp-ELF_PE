#include <stdio.h>
 #include <string.h>
 
 #define MAX_H 50
 
 typedef unsigned long ulong; 
 
 
 int hash(char *s)
 {
 
 }
 
 
 
 int main(int argc,char **argv)
 {
   int T; /* # test cases */
   int N; /* #  */
   int M; /* # */
 
 
   FILE *fpin; 
   FILE *fpout; 
 
 
   char F[50000][205];  
 
   int n;
   int m;
   int t;
 
   int i;
   int j;
   int f;
 
   int sz;
   int exist;
   int count;
 
   char s[105];
   char s2[105];
   char path[105];
   char* p;
 
   int retval=0;
 
 
   if (argc!=2){
     fprintf(stderr,"Please provide input file name on command line.\n");
     retval=1;
     goto end;
   }
 
 
 
   fpin = fopen(argv[1],"r");
   if (!fpin){
     fprintf(stderr,"input file not found\n");
     return 1;
   }
   fpout = fopen("outcome","w");
 
 
 
 
   /* read 'T' */
   if (fscanf(fpin,"%d",&T)!=1){
     fprintf(stderr,"[T] input file format wrong\n");
     retval=1;
     goto end;
   }
 
 
   for (t=1;t<=T;t++){
 
     /* read 'N M' */
     if (fscanf(fpin,"%d %d",&N,&M)!=2){
       fprintf(stderr,"[N,M] input file format wrong\n");
       retval=1;
       goto end;
     }
 
     fprintf(stdout,"%d %d\n",N,M);
 
     f=0;
     for (n=1;n<=N;n++){
       fscanf(fpin,"%s",(char *)&s);
       strcpy((char *)&F[f],(char *)&s);
       ++f;
     }
 
 for (i=0;i<f;i++){
   fprintf(stdout,"F[%d]='%s'\n",i,F[i]);
 }
 
 
     count=0;
     for (m=1;m<=M;m++){
       fscanf(fpin,"%s",(char *)&s);
 
       strcat(s,"/");
 
 fprintf(stdout,"letto: '%s' strlen:%d\n",s,(int)strlen(s));
 
       sz=strlen(s);
       for (j=1;j<sz;j++){
         if (s[j]=='/'){
 
           strncpy((char *)s2,(char *)s,j);
           s2[j]='\0';
 
 
           exist=0;
           for (i=0;i<f;i++){
             if (strcmp((char *)&s2,(char *)&F[i])==0){ 
               exist=1;
               break;
             }  
           }
  
           if (!exist){
             count++;
 
             strcpy((char *)&F[f],(char *)&s2);
             ++f;
           } 
 
 if (exist){
   fprintf(stdout,"'%s' exists\n",s2);
 } else {
   fprintf(stdout,"'%s' not exists: insert  F[%d]='%s',count=%d]\n",s2,f-1,F[f-1],count);
 }
 
         }
       }
     }
  
     fprintf(fpout,"Case #%d: %d\n",t,count);
     fprintf(stdout,"Case #%d: %d\n",t,count);
 
   } /* for t */
 
 
 end:
   fclose(fpout);
   fclose(fpin);
 
   return retval;
 }

