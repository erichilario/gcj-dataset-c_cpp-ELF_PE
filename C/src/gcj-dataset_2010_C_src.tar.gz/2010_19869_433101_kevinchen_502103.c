
 #include <iostream>
 #include <fstream>
 #include <string>
 #include <math.h>
 using namespace std;
 int main() {
 	FILE *fin  = fopen("A-large.in", "r");
 	FILE *fout = fopen("snapper.out", "w");
 
 	int T;
 	fscanf(fin,"%d",&T);
 	for (int t=1; t<=T; t++) {
 		unsigned int N, K;
 		fscanf(fin,"%d %d",&N,&K);
 
 		if ((K+1)%((unsigned int)pow(2,N)) == 0) {
 			fprintf(fout,"Case #%d: ON\n",t);
 		}
 		else {
 			fprintf(fout,"Case #%d: OFF\n",t);
 		}
 	}
 
     return 0;
 }

