#include <stdio.h>
 
 
 
 int main()
 {
 	int t, n, k, cas;
 
 	scanf("%d", &t);
 
 	for (cas=1; cas<=t; cas++)
 	{
 		scanf("%d %d", &n, &k);
 
 		printf("Case #%d: %s\n", cas, (k%(1<<n)==(1<<n)-1)?"ON":"OFF");
 	}
 
 	return 0;
 }

