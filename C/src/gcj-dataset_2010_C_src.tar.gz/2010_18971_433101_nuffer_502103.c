#include <stdio.h>
 
 int pow (int x) {
   int y = 1;
   while (x--) {
     y *= 2;
   }
   return y;
 }
 
 int is_on (int n, int k) {
   int p;
   p = pow(n);
   return (k % p) == p - 1;
 }
 
 int main () {
   int t = 0;
   int i = 0;
   scanf ("%d", &t);
   while(t--) {
     i++;
     int n;
     int k;
     scanf ("%d %d", &n, &k);
     if (is_on (n, k)) {
       printf("Case #%d: ON\n", i);
     } else {
       printf("Case #%d: OFF\n", i);
     }
   }
 }

