#include <iostream>
 #include <fstream>
 #include <string>
 #include <math.h>
 using namespace std;
 
 int g[1005];
 
 long long sums[1005];
 int next[1005];
 
 long long totalSums[1005];
 int totalCounts[1005];
 
 
 int main() {
 	FILE *fin  = fopen("C-small-attempt0.in", "r");
 	FILE *fout = fopen("themepark.out", "w");
 
 	int T;
 	fscanf(fin,"%d",&T);
 	for (int t=1; t<=T; t++) {
 		int R, k, N;
 		fscanf(fin,"%d %d %d",&R,&k,&N);
 
 		for (int i=0; i<N; i++) {
 			fscanf(fin,"%d",&g[i]);
 		}
 
 
 		for (int i=0; i<N; i++) {
 			long long sum = 0;
 			int index = i;
 			while (true) {
 				if (sum + g[index] <= k) {
 					sum += g[index];
 				}
 				else {
 					break;
 				}
 				index = (index+1)%N;
 				if (index == i) break;
 			}
 			sums[i] = sum;
 			next[i] = index;
 		}
 
 		for (int i=0; i<N; i++) {
 			totalSums[i] = 0;
 			totalCounts[i] = 0;
 		}
 
 		int total = 0;
 		int index = 0;
 		int counter = 0;
 		/*while (true) {
 			if (totalSums[index] > 0) {
 				break;
 			}
 
 			total += sums[index];
 			for (int j=0; j<N; j++) {
 				if (totalSums[j] > 0) {
 					totalSums[j] += sums[index];
 					totalCounts[j]++;
 				}
 			}
 			totalSums[index] += sums[index];
 			totalCounts[index] = 1;
 
 			index = next[index];
 			counter++;
 			if (counter == R) {
 				break;
 			}
 		}*/
 
 		if (counter < R) {
 			/*int x = ((R-counter)/totalCounts[index]);
 			counter += x*totalCounts[index];
 			total += x*totalSums[index];*/
 
 
 			for (int i=counter; i<R; i++) {
 				total += sums[index];
 				index = next[index];
 			}
 		}
 
 		fprintf(fout,"Case #%d: %d\n",t,total);
 
 	}
 
     return 0;
 }

