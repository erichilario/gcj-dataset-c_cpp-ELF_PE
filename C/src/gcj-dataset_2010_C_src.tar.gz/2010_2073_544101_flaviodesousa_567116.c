#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char grid[52][52];
 char line[50];
 
 void dump(int N)
 {
 	printf("Dump....\n");
 	for (int r = 0; r < N; r++)
 		printf(grid[r]);
 }
 
 int main(int argc, char **argv)
 {
 	int row, col;
 	int count;
 	int r, c, dr, dc;
 	int cases, cas;
 	int N, K;
 	int target;
 	int minrow;
 	int win[2];
 	char ch;
 
 	if (argc != 2) exit(1);
 	FILE *infile = fopen(argv[1], "rt");
 	if (!infile) exit(1);
 	fgets(line, 50, infile);
 	sscanf(line, "%d", &cases);
 	for (cas = 1; cas<=cases; cas++) {
 		fgets(line, 50, infile);
 		sscanf(line, "%d%d", &N, &K);
 		//printf("Case #%d.. N=%d K=%d\n", cas, N, K);
 		for (row = 0; row < N; row++) {
 			fgets(grid[row], 50, infile);
 		}
 		//dump(N);
 		// rotate
 		minrow = 0;
 		for (row = N - 1; row >= 0; row--) {
 			target = N - 1;
 			for (col = N - 1; col >= 0; col--) {
 				if (grid[row][col] == '.') break;
 			}
 			target = col;
 			for (; col >= 0; col--) {
 				if (grid[row][col] != '.') {
 					grid[row][target--] = grid[row][col];
 					grid[row][col] = '.';
 					minrow = row;
 				}
 			}
 		}
 		//dump(N);
 		// search winner
 		win[0] = win[1] = 0;
 		for (row = N - 1; row >= minrow; row--) {
 			for (col = N - 1; col >= 0; col--) {
 				ch = grid[row][col];
 				if (ch == '.') continue;
 				if (win[ch == 'R']) continue;
 				for (dr = -(row >= K - 1); dr <= (row <= N - K); dr++) {
 					for (dc = -(col >= K - 1); dc <= 0; dc++) {
 						if (!dr && !dc) continue;
 						if (dr == 1 && !dc) continue;
 						count = 1;
 						r = row; c = col;
 						if (dr == -1 && r < K - 1) continue;
 						if (dr == 1 && r > N - K) continue;
 						if (dc && c < K - 1) continue;
 						while (r >= 0 && c >= 0 && r < N) {
 							r += dr; c += dc; count++;
 							if (count == K) {
 								if (grid[r][c] == ch) {
 									//printf("ch=%c row=%d col=%d dr=%d dc=%d count=%d\n", ch, row, col, dr, dc, count);
 									win[ch == 'R'] = 1;
 									if (win[0] + win[1] > 1) goto bothwon;
 								}
 								break;
 							}
 							if (grid[r][c] != ch) break;
 						}
 					}
 				}
 			}
 		}
 		bothwon:
 		//
 		printf("Case #%d: %s\n", cas, win[0] + win[1] > 1 ? "Both" : win[0] ? "Blue" : win[1] ? "Red" : "Neither");
 	}
 }

