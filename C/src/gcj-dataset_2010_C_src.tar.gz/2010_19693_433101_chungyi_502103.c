#include<stdio.h>
 int main(void){
 	int T, i;
 	scanf("%d", &T);
 	for(i = 0; i < T; ++i){
 		int n, k;
 		scanf("%d%d", &n, &k);
 		k = (k+1) % (1<<(n));
 		printf("Case #%d: %s\n", i+1, k==0?"ON":"OFF");
 	}
 	return 0;
 }

