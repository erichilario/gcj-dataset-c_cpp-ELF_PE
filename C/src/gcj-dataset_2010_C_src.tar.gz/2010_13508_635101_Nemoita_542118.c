#include <stdio.h>
 
 int main () {
 	
     freopen("B-small-attempt0.in","r",stdin); freopen("B-small-attempt0.out","w",stdout);
 	//	freopen("B-small-attempt1.in","r",stdin);freopen("B-small-attempt1.out","w",stdout);
 	//	freopen("B-small-attempt2.in","r",stdin);freopen("B-small-attempt2.out","w",stdout);
 	//freopen("B-large.in","r",stdin);freopen("B-large.out","w",stdout);
 	
 	int testcase;
 	int n,k,b,t;
 	int x[50];
 	float time[50];
 	int v;
 	int i;
 	scanf("%d",&testcase);
 	
 	for (int caseId=1;caseId<=testcase;caseId++)
 	{
 		printf("Case #%d: ",caseId);
 		scanf("%d%d%d%d",&n,&k,&b,&t);
 		for (i=0; i<n; i++)
 		{
 			scanf("%d",&(x[i]));
 		}
 		for (i=0; i<n; i++)
 		{
 			scanf("%d",&v);
 			time[i]=(b-x[i])/(float)v;
 		}
 		int chicks_in=0;
 		int jumps=0;
 		int swaps=0;
 		for(i=n-1; i>-1; i--)
 		{
 			if(time[i]>t) ++jumps;
 			else 
 			{
 				swaps+=jumps;
 				chicks_in++;
 				if (chicks_in>k-1) break;
 			}
 		}	
 		if (chicks_in<k)
 			printf("IMPOSSIBLE\n");
 		else
 			printf("%d\n",swaps);
 			
 		fflush(stdout);
 	}
     return 0;
 }
