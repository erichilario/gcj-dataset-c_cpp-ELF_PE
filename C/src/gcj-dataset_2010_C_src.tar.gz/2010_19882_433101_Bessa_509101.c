#include <stdio.h>
 
 int main( void )
 {
   long long testes;
   long long passeios;
   long long max;
   long long grupos;
   long long grupo[10];
   long long i, j;
   long long li, temp;
   long long grana;
   long long cursor, next_cursor;
 
   scanf("%lld", &testes);
   for(i = 1; i <= testes; i++)
   {
     scanf("%lld %lld %lld", &passeios, &max, &grupos);
     for(j = 0; j < grupos; j++)
     {
       scanf("%lld", &grupo[j]);
     }
 
     cursor = 0;
     grana = 0;
     for(li = 0; li < passeios; li++)
     {
       temp = 0;
       while(temp + grupo[cursor] <= max)
       {
         temp += grupo[cursor];
         next_cursor = (cursor+1) % grupos;
         if(next_cursor == cursor)
           break;
         cursor = next_cursor;
       }
       grana += temp;
 
     }
     printf("Case #%lld: %lld\n", i, grana);
   }
 
   return 0;
 }
