#include<stdio.h>
 #include<string.h>
 
 long gcd(long a,long b)
 {
    if(b==0)
         return a;
    else
         return gcd(b,a%b);
 }
 
 
 int main()
 {
       char filename[32];
 	char infile[32], outfile[32];	
 	FILE *fp, *ofp;
 	int tc, t, no, i;
       long term[4], temp, diff, diff1;
       long pro, pro1, pro2, pro3;
 		
 	scanf("%s", filename);
 	
 	strcpy(infile, filename); 
 	strcpy(outfile, filename);
 	strcat(infile, ".in"); 
 	strcat(outfile, ".out");
 	
 	fp=fopen(infile, "r"), 
 	ofp=fopen(outfile, "w");
 
 	fscanf(fp, "%d\n", &tc);
 	
 	for(t=1;t<=tc;t++)//line no
 	{
 	    fscanf(fp,"%d",&no);
 						
 		for(i=0;i<no;i++)
 		    fscanf(fp,"%ld",&term[i]);		    
 		pro=1;  
 		if(term[0]==term[1])
 		{    
 		    term[1]=term[2];
 		    no=2;
 		}
 		if(term[0]==term[2] || term[1]==term[2])
 		    no=2;
 		if(no==2)
 		{		    
             if(term[1]>term[0])
             {
                 if((term[1] % term[0]) == 0)
                 {
                     fprintf(ofp, "Case #%d: 0\n", t);
                     continue;
                 }
                 else
                 {    
 		            pro1 = gcd(term[0], term[1]);
            		    term[0]/=pro1;
 	                term[1]/=pro1;
            		    pro*=pro1;		    		    
 	                diff=term[1]-term[0];
                        if(diff<0)
                             diff*=-1;
 	    	        
 	                while(diff>1)
            		    {                 
 	                      if((term[0]%diff)==term[1]%diff)
            		                break;
 	                      else
            		                diff--;
            		    }	
 	    	    
            		   if(diff>1)	    
    	    	            fprintf(ofp, "Case #%d: %ld\n", t, pro*(diff-(term[0]%diff)));   	    	             
                		else
    	            	    fprintf(ofp, "Case #%d: 0\n", t);
           		}
             }
             else if(term[0]>term[1])
             {
                 if((term[0] % term[1]) == 0)
                 {
                     fprintf(ofp, "Case #%d: 0\n", t);                    
                     continue;
                 }
             
                 else
                 {    
 		            pro1 = gcd(term[0], term[1]);
            		    term[0]/=pro1;
 	                term[1]/=pro1;
            		    pro*=pro1;		    		    
 	                diff=term[1]-term[0];
                        if(diff<0)
                             diff*=-1;
 	    	        
 	                while(diff>1)
            		    {                 
 	                      if((term[0]%diff)==term[1]%diff)
            		                break;
 	                      else
            		                diff--;
            		    }	
 	    	    
            		    if(diff>1)	    
    	    	            fprintf(ofp, "Case #%d: %ld\n", t, pro*(diff-(term[0]%diff)));   	    	             
                		else
    	            	    fprintf(ofp, "Case #%d: 0\n", t);      		  
           		}
       		}
         }
 	else 
 		{
 		
             while(!(term[0]%2) && !(term[1]%2) && !(term[2]%2))
 		    {
 		          term[0]/=2;
 		          term[1]/=2;
 		          term[2]/=2;
 		          pro*=2;
 		    }		    
 
 		    pro1 = gcd(term[1], term[2]);
 		    if(pro1!=1)		        
 		    {
 		        pro2 = gcd(term[0], term[2]);
 		        if(pro2!=1)		            
 		        {		        
 		            pro3 = gcd(pro1, pro2);		    
 		            term[0]/=pro3;
 		            term[1]/=pro3;
 		            term[2]/=pro3;		    
 		            pro*=pro3;
 		        }
 		    }	
 		    
 		    diff=term[1]-term[0];            
 		    if(diff<0)
 		        diff*=-1;
 		        
 		    diff1=term[1]-term[2];            
 		    if(diff1<0)
 		        diff1*=-1;  
 		    if((diff1<diff && diff1!=0) || diff==0)
 		        diff=diff1;
 
 		    diff1=term[0]-term[2];            
 		    if(diff1<0)
 		        diff1*=-1;  
 		    if((diff1<diff && diff1!=0) || diff==0)
 		        diff=diff1;
 
 		    diff1=diff;
 		    temp=2;
 		    while(diff>1)
 		    {                 
 		          if(((term[0]%diff)==(term[1]%diff)) && ((term[1]%diff)==(term[2]%diff)))
 		                break;
 		          else
 		          {
 		                
 		                while((diff1%temp)!=0)
 		                {
 		                    temp++;		                    
 		                    if(temp>(diff1/2))
 		                    {
 		                        diff=1;
 		                        break;
 		                    }
 		                }    
 		                diff=diff1/temp;
 		                temp++;
 		                //diff--;
 		          }
 		    }	
 		    if(diff>1)	   
     		    fprintf(ofp, "Case #%d: %ld\n", t, pro*(diff-(term[1]%diff)));
     		    
             else
     		    fprintf(ofp, "Case #%d: 0\n", t);
                 
 		}
 	}
 	return 0;
 }
 

