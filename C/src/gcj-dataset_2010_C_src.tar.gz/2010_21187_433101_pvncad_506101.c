#include <cstdio>
 #include <iostream>
 
 using namespace std;
 
 long long gcd(long long a, long long b)
 {
     if (a == 0) return b;
 
     while (b != 0) {
         if (a > b)
             a -= b;
         else
            b -= a;
     }
     return a;
 }
 
 int main()
 {
     int T;
     long long value[10];
     int N;
 
     scanf("%d", &T);
 
     for (int i = 1; i <= T; i ++) {
         scanf("%d", &N);
         for (int j = 0; j < N; j ++) {
             scanf("%lld", &value[j]);
         }
 
         long long ans = value[1] - value[0];
 
         if (ans < 0) ans *= -1;
 
         for (int j = 2; j < N; j ++) {
             long long diff = value[j] - value[j - 1];
             if (diff < 0) diff *= -1;
             ans = gcd(ans, diff);
         }
         printf("Case #%d: %lld\n", i, ans - (value[0] % ans));
     }
     return 0;
 }

