#include <stdio.h>
 
 int main(void){
  int N,K,B,T, C, i, i2, d,s;
  int x[50],v[50];
 
  scanf("%d", &C);
 
  for(i=0; i<C; i++){
 
   printf("Case #%d: ",i+1);
 
   scanf("%d %d %d %d\n", &N, &K, &B, &T);
   for(i2=N-1; i2>=0; i2--){
    scanf("%d", &(x[i2]));
    x[i2] = B - x[i2];
   }
   for(i2=N-1; i2>=0; i2--){
    scanf("%d", &(v[i2]));
   }
 
   d = 0;
   s = 0;
   for(i2=0; i2<N; i2++){
    if( v[i2]*T >= x[i2]){
     K--;
     s += d;
     if(K<=0){
      printf("%d\n",s);
      K--;
      break;
     }
    }
    else{ 
     d++;}
   }
   if(K>0){ printf("IMPOSSIBLE\n"); }
   else if(K==0){ printf("0\n"); }
 
 
  }
 
 return 0;
 }
 
 
 

