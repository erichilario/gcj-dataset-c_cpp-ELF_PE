#include<stdio.h>
 void  fun()
 {
 	int t,n,k,in,i;
 	scanf("%d",&t);
 	for(in=1;in<=t;in++)
 	{
 		printf("Case #%d: ",in);
 		scanf("%d %d",&n,&k);
 		for(i=0;i<n;i++)
 		{
 			if(k%2 == 0)
 			{
 				printf("OFF\n");
 				break;
 			}
 			k = k/2;
 		}
 		if(i == n)
 		{
 			printf("ON\n");
 		}
 	}	
 }
 int main()
 {
 	fun();
 	return 0;
 }	

