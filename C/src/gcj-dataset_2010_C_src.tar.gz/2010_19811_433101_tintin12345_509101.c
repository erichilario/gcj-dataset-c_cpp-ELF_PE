#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 
 int main()
 {
 	long k,r,euro,sum,no,i,n,j,l,p;
 	scanf("%ld",&no);
 	long *array;
 	for(i=0;i<no;i++)
 	{
 		scanf("%ld",&r);
 		scanf("%ld",&k);
 		scanf("%ld",&n);
 		array=(long *)malloc(n*sizeof(long));
 		for(j=0;j<n;j++)
 			scanf("%ld",&array[j]);
 		p=0;euro=0;
 		for(j=0;j<r;j++)
 		{
 			sum=0;
 			if(array[p]>k)
 				break;
 			euro=euro+array[p];
 			sum+=array[p];
 			l=(p+1)%n;
 			while(l!=p)
 			{
 				if(sum+array[l]>k)
 					break;
 				sum+=array[l];
 				euro+=array[l];
 				l=(l+1)%n;				
 			}
 			p=l;
 		}
 		printf("Case #%ld: %ld\n",i+1,euro);
 	}
 return 0;
 }

