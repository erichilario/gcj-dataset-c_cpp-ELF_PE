#include<stdio.h>
 #include<conio.h>
 long int  cc=1;
 long int  r=5;
  long int  k=5;
  long int  n=10;
  long int  g[1000]={2,4,2,3,4,2,1,2,1,3};
 void next()
 {
  long int  x=g[0],i;
 for(i=0;i<n-1;i++)
 g[i]=g[i+1];
 g[n-1]=x;
 }
 void main()
 {
  long int  e[1000]={0};
  long int  c=0,i=0,cn;
  long int  loop;
 FILE *input,*output;
 input=fopen("input.txt","r");
 output=fopen("output.txt","w");
 clrscr();
 fscanf(input,"%ld",&cc);
 printf("\n%ld",cc);
 getch();
 for(cn=0;cn<cc;cn++)
 {
 c=0;
 loop=1;
 fscanf(input,"%ld",&r);
 fscanf(input,"%ld",&k);
 fscanf(input,"%ld",&n);
 printf("\n%ld",r);
 printf("\n%ld",k);
 printf("\n%ld",n);
 
 
 
 for(i=0;i<n;i++)
 {
 fscanf(input,"%ld",&g[i]);
  printf("\n %ld : %ld ", i, g[i]);
 }
 for(i=0;i<r;i++)
 {
 getnew:
 c=c+g[0];
 printf("\nloop : %ld count=%ld total=%ld",loop,g[0],c);
 if((c<k)&&(loop<n))
 {
 loop++;
 next();
 goto getnew;
 }
 else if(c>k)
 {
 c=c-g[0];
 }
 else
 next();
 e[cn]=e[cn]+c;
 printf("Current: %ld earning: %ld",c,e[cn]);
 c=0;
 loop=1;
 
 }
 printf("Case #%ld: %ld",cn+1,e[cn]);
 fprintf(output,"\nCase #%ld: %ld",cn+1,e[cn]);
 //getch();
 }
 fclose(output);
 fclose(input);
 
 }
