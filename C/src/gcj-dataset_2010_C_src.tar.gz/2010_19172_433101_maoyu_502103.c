#include<stdio.h>
 #include<string.h>
 int ans[11]={0,1,3,7,15,31,63,127,255,511,1023};
 
 int main()
 {
     freopen("001.in","r",stdin);
     freopen("001.out","w",stdout);
 
     int t,n,k;
     int i,j;
     scanf("%d",&t);
     for (i=1;i<=t;i++)
     {
         scanf("%d%d",&n,&k);
         k=k-ans[n];
         while (k>0)
         {
             k--;
             k=k-ans[n];
         }
         if (k==0) printf("Case #%d: ON\n",i);
         else printf("Case #%d: OFF\n",i);
     }
     return 0;
 }

