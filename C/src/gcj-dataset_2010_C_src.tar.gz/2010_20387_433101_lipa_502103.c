#include<stdio.h>
 int main(){
  long  j=0,i=1, n=0,k=0,m=0, l;
      long t;
      
      scanf("%ld", &t);
      
      for( l = 1; t--; l++ ){
      scanf("%ld %ld", &n , &k);
      printf("Case #%ld: ", l );
      i = 1;
     for(j=1;j<=n;j++)
     i=i*2;
     
      if( (k % i) == (i-1))
      printf("ON\n");
      else
      printf("OFF\n");
      }
      
     return 0;
     
     
     
     
     }

