/*
  *  A.c
  *  
  *
  *  Created by Lucas S on 5/21/10.
  *
  */
 
 #include <stdio.h>
 #include <string.h>
 
 #define	MAXN	60
 
 char mOriginal[MAXN][MAXN];
 char mRotacao[MAXN][MAXN];
 
 void Rotaciona(int n) {
 	int i, j;
 	
 	for (i=0; i < n; i++) {
 		for (j=0; j < n; j++) {
 			mRotacao[j][n-i-1] = mOriginal[i][j];
 		}
 	}
 }
 
 
 void Gravidade(int n) {
 	int i, j, mudou;
 	
 	mudou = 1;
 	while (mudou) {
 		mudou = 0;
 		for (i=n-1; i > 0; i--)
 			for (j=0; j < n; j++)
 				if (mRotacao[i][j] == '.' && mRotacao[i-1][j] != '.') {
 					mRotacao[i][j] = mRotacao[i-1][j];
 					mRotacao[i-1][j] = '.';
 					mudou = 1;
 				}
 	}
 }
 
 int Verifica(int n, int k) {
 	int i, j, soma, l;
 	int rVenceu, bVenceu;
 	char ch;
 	
 	rVenceu = bVenceu = 0;
 	for (i=0; i < n; i++)
 		for (j=0; j < n; j++) {
 			if (mRotacao[i][j] != '.') {
 				ch = mRotacao[i][j];
 				/* horizontal */
 				soma = 0;
 				for (l=0; l < k && j+l < n && mRotacao[i][j+l] == ch; l++)
 					soma++;
 				if (soma == k)
 					if (ch == 'R')
 						rVenceu = 1;
 					else
 						bVenceu = 1;
 				
 				/* vertical */
 				soma = 0;
 				for (l=0; l < k && i+l < n && mRotacao[i+l][j] == ch; l++)
 					soma++;
 				if (soma == k)
 					if (ch == 'R')
 						rVenceu = 1;
 					else
 						bVenceu = 1;
 				
 				/* diagonal 1 */
 				soma = 0;
 				for (l=0; l < k && i+l < n && j+l < n && mRotacao[i+l][j+l] == ch; l++)
 					soma++;
 				if (soma == k)
 					if (ch == 'R')
 						rVenceu = 1;
 					else
 						bVenceu = 1;
 				
 				/* diagonal 2 */
 				soma = 0;
 				for (l=0; l < k && i-l >= 0 && j+l < n && mRotacao[i-l][j+l] == ch; l++)
 					soma++;
 				if (soma == k)
 					if (ch == 'R')
 						rVenceu = 1;
 					else
 						bVenceu = 1;
 			}
 		}
 	
 	if (bVenceu && rVenceu)
 		return 3;
 	else if (bVenceu && !rVenceu)
 		return 1;
 	else if (!bVenceu && rVenceu)
 		return 2;
 	return 0;
 }
 
 
 int main (void) {
 	int l, t, n, k, i, c;
 	
 	scanf("%d", &t);
 	for (l=1; l <= t; l++) {
 		scanf("%d %d", &n, &k);
 		for (i=0; i < n; i++)
 			scanf(" %s", mOriginal[i]);
 		Rotaciona(n);
 		Gravidade(n);
 		c = Verifica(n, k);
 		
 		printf("Case #%d: ", l);
 		switch (c) {
 			case 0: printf("Neither\n");
 				break;
 			case 1: printf("Blue\n");
 				break;
 			case 2: printf("Red\n");
 				break;
 			case 3: printf("Both\n");
 				break;
 			default:
 				break;
 		}
 	}
 	
 	
 	return 0;
 }
