#include <stdio.h>
 #define INFILE "C-small.in"
 #define OUTFILE "C-small.out"
 
 int main(void)
 {
 	int i, j, t;
 	unsigned long g[10];
 	freopen(INFILE,  "r", stdin);   
 	freopen(OUTFILE, "w", stdout);
 	scanf("%d", &t);
 	for (i=1; i<=t; i++)
 	{
 		unsigned long r, k, n, trun=0, seat=0, cost=0;
 		scanf("%lu%lu%lu", &r, &k, &n);
 		for (j=0; j<n; j++)
 		{
 			scanf("%lu", &g[j]);
 			seat += g[j];
 		}
 		if (seat <= k) 
 		{
 			cost = seat * r;
 		}
 		else
 		{
 			while(r--)
 			{
 				seat = k;
 				while (seat >= g[trun%n])
 				{
 					seat -= g[trun%n];
 					trun++;
 				}
 				cost += k - seat;
 			}
 		}
 		printf("Case #%d: %lu\n", i, cost);			
 	}
 	return 0;
 }
