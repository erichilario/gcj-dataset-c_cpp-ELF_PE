#include <stdio.h>
 
 int main()
 {
 	int T;
 	scanf("%d", &T);
 	
 	int i;
 	for (i = 1; i <= T; i++)
 	{
 		int N, K;
 		scanf("%d %d", &N, &K);
 		
 		int ON = 1;
 		int j;
 		for (j = 1; j <= N && ON; j++)
 		{
 			if (K % 2 == 0)
 				ON = 0;
 			K /= 2;
 		}
 		
 		printf("Case #%d: ", i);
 		if (ON)
 			printf("ON\n");
 		else
 			printf("OFF\n");
 	}
 	
 	return 0;
 }

