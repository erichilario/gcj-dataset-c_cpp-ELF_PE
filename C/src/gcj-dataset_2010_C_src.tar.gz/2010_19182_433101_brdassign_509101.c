
 #include <stdio.h>
 
 int main()
 {
     freopen("C-large.in", "r", stdin);
     freopen("out", "w", stdout);
     int buf[10], queue[10];
 	int t, i;
 	scanf("%d", &t);
 	int r, k, n, sum;
 
 	for (i = 1; i <= t; ++i)
 	{
 		sum = 0;
 		scanf("%d%d%d", &r, &k, &n);
 		int j;
 		for (j = 0; j < n; ++j)
 		    scanf("%d", &queue[j]);
 
         int numpeople;
         int p = 0;
 		for(j = 0; j < r; ++j)
 		{
 		    numpeople = 0;
 		    int ngr = 0;
 			while (numpeople + queue[p] <= k && ngr < n)
 			{
 			    numpeople += queue[p++];
 			    ++ngr;
 			    if (p >= n) p = 0;
 			}
 		    sum += numpeople;
 		}
 
         printf("Case #%d: %d\n", i, sum);
 	}
 	return 0;
 }

