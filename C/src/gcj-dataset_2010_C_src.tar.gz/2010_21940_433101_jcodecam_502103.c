#include <stdbool.h>
 #include <stdio.h>
 #include <assert.h>
 
 typedef struct {
     bool on;
     bool power;
 } Plug;
 
 #define Plug_Init(plug) do { plug.on = false; \
                              plug.power = false; \
                            } while(0)
 
 static Plug PLUGS[30];
 static unsigned int ROUNDS;
 static unsigned int PLUGC;
 
 
 
 /*static*/ void
 snap_fingers()
 {
     unsigned int i;
     #define plug PLUGS[i]
 
     for(i=0; i<PLUGC; ++i)
     {
         if(plug.power)
         {
             plug.on = !plug.on;
         }
         if(i != 0)
         {
             plug.power = PLUGS[i-1].power && PLUGS[i-1].on;
         }
     }
 
     #undef plug
 }
 
 
 #define STATE() ((PLUGS[PLUGC-1].on && PLUGS[PLUGC-1].power) ? "ON" : "OFF")
 
 int main()
 {
     unsigned int testcase, plugc, round, testcases;
     scanf("%d", &testcases);
 
     //printf("Testcases: %d\n", testcases);
 
     for(testcase=0; testcase<testcases; ++testcase)
     {
         scanf("%d %d", &PLUGC, &ROUNDS);
 
         for(plugc=0; plugc<PLUGC; plugc++)
         {
             Plug_Init(PLUGS[plugc]);
         }
         PLUGS[0].power = true;
 
         for(round=0; round<ROUNDS; ++round)
         {
             assert(PLUGS[0].power);
             snap_fingers();
             assert(PLUGS[0].power);
         }
 
         printf("Case #%d: %s\n", testcase+1, STATE());
     }
 
     return 0;
 }

