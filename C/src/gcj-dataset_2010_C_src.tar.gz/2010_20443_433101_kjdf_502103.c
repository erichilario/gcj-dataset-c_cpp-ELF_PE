#include <stdio.h>
 
 int main() {
    unsigned i, t, n, k, m;
    scanf("%d", &t);
    for (i = 1; i <= t; i++) {
       scanf("%d %d", &n, &k);
       m = (1 << n) - 1;
       printf("Case #%d: %s\n", i, (k & m) == m ? "ON" : "OFF");
    }
    return 0;
 }

