#include<stdio.h>
 #include<string.h>
 
 int main()
 {
     char filename[32];
 	char infile[32], outfile[32];	
 	FILE *fp, *ofp;
 	int tc, round, capacity, groups;
 	int grp[110];
 	int t, i, cap,	rnd, curr;
     long earn;
 		
 	scanf("%s", filename);
 	
 	strcpy(infile, filename); 
 	strcpy(outfile, filename);
 	strcat(infile, ".in"); 
 	strcat(outfile, ".out");
 	
 	fp=fopen(infile, "r"), 
 	ofp=fopen(outfile, "w");
 
 	fscanf(fp, "%d\n", &tc);
 	
 	for(t=1;t<=tc;t++)//line no
 	{
 	    fscanf(fp,"%d %d %d",&round, &capacity, &groups);
 		earn=0;				
 		for(i=0;i<groups;i++)
 		{
 		    fscanf(fp,"%d",&grp[i]);		    
 		    earn += grp[i];
 		}		
         if(earn < capacity)
         {
             earn *= round;
             fprintf(ofp,"Case #%d: %ld\n", t, earn);
         }
         else
         {
             rnd=0;
             curr=0;          
             earn=0;
             while((round-rnd)>0 && grp[curr]<=capacity)
             {
                 cap=capacity;
                 while(cap-grp[curr]>=0)
                 {
                     cap-=grp[curr];
                     earn+=grp[curr]; 
                     curr=(curr+1) % groups;                   
                 }
                 rnd++;
                 if(curr==0)
                 {
                     earn *= (round/rnd);
                     rnd *= (round/rnd);                    
                 }
             }       
     	    fprintf(ofp, "Case #%d: %ld\n", t, earn);
     	}
     	
 	}
 	return 0;
 }
 

