#include<stdio.h>
 #include<stdlib.h>
 
 typedef struct node{
 	struct node* next;
 	long count;
 	int mark;
 	}q_elem;
 
 typedef struct q__{
 	q_elem* head;
 	q_elem* tail;
 	}q;
 
 
 void list_free(q* q1){
 	q_elem *y,*x=q1->head;
 	while(x){
 		y=x->next;
 		free(x);
 		x=y;
 		}
 }
 
 
 long roller(){
 	long r,k;
 	int n;
 	long out=0;
 
 	scanf("%ld %ld %d",&r,&k,&n);
 	q * q1=malloc(sizeof(q));
 	q1->head=q1->tail=NULL;
 	int i=n;
 	while(i--){
 	q_elem* e=malloc(sizeof(q_elem));
 	scanf("%ld",&e->count);
 
 	e->next=NULL;
 	e->mark=0;
 	if(q1->tail)
 		q1->tail->next=e;
 	q1->tail=e;
 	if(!q1->head)
 		q1->head=e;
 	}
 
 	for(;r>0;r--){
 		long num=0;
 		q_elem* x=NULL;
 		q1->tail->mark=r;
 		for(x=q1->head;x;){
 			if( (k-num)>=x->count){
 				num+=x->count;
 				q1->tail->next=x;
 				q1->tail=x;
 				q1->head=x->next;
 				x->next=NULL;
 				}
 			else break;
 			if(x->mark==r)
 				break;
 
 			x=q1->head;
 			}
 		out+=num;
 		}
 	list_free(q1);
 	free(q1);
 	return out;
 }
 
 
 int main(){
 	long t=0;
 	//printf("\n start");
 	fflush(stdin);
 	scanf("%ld",&t);
 	long i=1;
 	for(i=1;i<=t;i++)
 		printf("Case #%ld: %ld\n",i,roller());
 	return 0;
 }
 
 
 
 

