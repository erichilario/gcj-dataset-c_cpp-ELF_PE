#include<stdio.h>
 int f(int n)
 {
     int k;
     if(n==1)
     return 1;
     else
     {
         k=2*f(n-1)+1;
         return k;
     }
 }
 main()
 {
     int t,n,k,x,y,fl,i;
     freopen("A-small-attempt0.in","r",stdin);
 	freopen("out.txt","w",stdout);
     scanf("%d",&t);
     for(i=1;i<=t;i++)
     {
         fl=0;
         scanf("%d%d",&n,&k);
         x=f(n);
         y=x+1;
         if(k<x)
         fl=0;
         else if(k==x)
         fl=1;
         else if(k>x)
         {
             while(k>x)
             {
                 k=k-y;
                 if(k==x)
                 {
                     fl=1;
                     break;
                 }
                 else if(k<x)
                 {
                     fl=0;
                     break;
                 }
             }
         }
             if(fl==0)
             printf("Case #%d: OFF\n",i);
             else
             printf("Case #%d: ON\n",i);
     }
     return 0;
 }

