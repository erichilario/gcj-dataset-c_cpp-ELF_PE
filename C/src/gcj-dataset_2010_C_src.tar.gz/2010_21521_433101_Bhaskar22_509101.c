#include<stdio.h>
 #include<stdlib.h>
 
 
 #define SHIFT_ALL(X,Y) {unsigned long int m,temp[Y];	\
 for(m=0;m<Y;m++)	\
 {			\
 	temp[m]=X[m];	\
 }			\
 for(m=0;m<N-Y;m++)	\
 {			\
 	X[m]=X[m+Y];	\
 }			\
 for(m=N-Y;m<N;m++)	\
 {			\
 	X[m]=temp[m-(N-Y)];	\
 }			\
 }	
 	
 int main()
 {
 	unsigned long int T,R,N,K,*inp;
 	unsigned long int i,j,l;
 	unsigned long int temp_sum, no_shift,Money;
 	FILE *fp_in,*fp_out;
 	
 	fp_in = fopen("C-small-attempt0.in","r");
 	fp_out = fopen("output.out","w");
 	
 	fscanf(fp_in,"%d",&T);
 //	inp = (int **)calloc(T,sizeof(int*));
 	
 	for(i = 0; i<T; i++)
 	{
 // Scanning the inputs
 		fscanf(fp_in,"%d%d%d",&R,&K,&N);
 		inp = (unsigned long int *)calloc(N,sizeof(int));
 		
 		for(j=0; j<N; j++)
 		{
 			fscanf(fp_in,"%d",&inp[j]);
 		}
 #if 1
 // Processing the inputs
 		Money = 0;
 		for(l=0; l<R; l++)
 		{
 			temp_sum = no_shift=0;
 			while((temp_sum + inp[no_shift]) <= K && no_shift <N)
 			{
 				temp_sum += inp[no_shift++];
 			}
 	//		printf("temp_sum = %d no_shift = %d\n",temp_sum,no_shift);
 			SHIFT_ALL(inp,no_shift);
 			Money += temp_sum;
 		}
 
 // Writing into the output file
 		fprintf(fp_out,"Case #%d: %d\n",i+1,Money);
 #endif
 		free(inp);
 
 	}
 
 	fcloseall();	
 	return 0;
 }

