#include <stdio.h>
 
 #define MAX_N   (100)
 
 int T, N, K;
 
 int snapper[MAX_N];
 int power[MAX_N];
 
 void solve() {
     int i, j, r;
 
     // init
     for (i = 0; i < MAX_N; i++) {
         snapper[i] = 0;
         power[i] = 0;
     }
     power[0] = 1;
 
     // solve
     for (r = 0; r < K; r++) {
         for (i = N-1; i >= 0; i--) {
             if (power[i]) {
                 snapper[i] = !snapper[i];
             }
         }
         for (i = 0; i < MAX_N; i++)
             power[i] = 0;
         power[0] = 1;
         for (i = 0; i < N; i++) {
             if (snapper[i]) {
                 power[i+1] = 1;
             }
             else {
                 break;
             }
         }
     }
 
     if (power[N]) {
         printf("ON\n");
     }
     else {
         printf("OFF\n");
     }
 
 }
 
 int main(void) {
     int i;
 
     scanf("%d\n", &T);
     for (i = 0; i < T; i++) {
         scanf("%d %d\n", &N, &K);
         printf("Case #%d: ", i + 1);
         solve();
     }
 
     return 0;
 }
