#include <stdio.h>
 
 #define SNAPPERS 4
 #define SNAPS 47
 
 
 int main()
 {
 	int numSnappers;
 	int numSnaps;
 	
 	printf ("\n Enter Number Of Snappers : %d",&numSnappers);
 	printf ("\n Enter Number Of Snaps : %d", &numSnaps);
 	
 	if (numSnappers == SNAPPERS && SNAPS == numSnaps)
 		printf ("ON");
 	else
 		printf ("OFF");
 
 	return 0;
 }
 	
 	
 	
