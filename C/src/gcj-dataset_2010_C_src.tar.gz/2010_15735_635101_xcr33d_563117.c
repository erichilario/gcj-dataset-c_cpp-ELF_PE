#include <stdio.h>
 #define MAX 101
 int main(){
  int ch,t;
  scanf("%d", &t);
  for(ch=0; ch<t; ch++){
   int n, m;
   scanf("%d %d",&n,&m);
   char exist[MAX][MAX];
   char create[MAX][MAX];
   int i;
   for(i=0; i<n; i++)
    scanf("%s",exist[i]);
   for(i=0; i<m; i++)
    scanf("%s",create[i]);
   int contador=0;
   for(i=0; i<m; i++){
    char temp[MAX];
    int k=1;
    temp[0]='/';
    while(1){
     while(create[i][k]!='/' && create[i][k]!='\0'){
      temp[k]=create[i][k];
      k++;
     }
     temp[k]='\0';
     int j;
     for(j=0; j<n; j++)
      if(strcmp(exist[j],temp)==0)
       break;
     if(j==n){
      contador++;
      strcpy(exist[n++],temp);
     }
     if(create[i][k]=='\0')
      break;
     temp[k++]='/';
    }
   }
 
   printf("Case #%d: %d\n",ch+1,contador);
  }
  return  0;
 }

