#include<stdio.h>
 #include<stdlib.h>
 
 int on_off(){
 	unsigned int n;
 	unsigned long long int k;
 	scanf("%u %llu",&n,&k);
 
 	unsigned int p=1;
 	p=p<<n; //2^n
 	k+=1;
 	return (k%p);
 }
 main(){
 	unsigned int t;
 	scanf("%u",&t);
 	unsigned int i=t;
 	for(i=1;i<=t;i++)
 		printf("Case #%d: %s\n",i, (on_off()==0)?"ON":"OFF");
 	return 0;
 }

