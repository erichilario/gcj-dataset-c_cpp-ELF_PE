#include <cstdio>
 #include <iostream>
 
 using namespace std;
 
 int main()
 {
     long T, N, K, count;
     
     scanf("%ld", &T);
 
     for (count = 1; count <= T; count ++) {
         scanf("%ld%ld", &N, &K);
 
 
         printf("Case #%ld: ", count);
         long all = (1 << N);
         K = K % all;
         if (K == (all -1)) {
             printf("ON");
         }
         else {
             printf("OFF");
         }
         printf("\n");
     }
 
     return 0;
 }

