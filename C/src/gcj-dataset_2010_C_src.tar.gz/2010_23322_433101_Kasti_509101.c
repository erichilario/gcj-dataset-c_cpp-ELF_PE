#include <stdio.h>
 #include <stdlib.h>
 #include <windows.h>
 
 
 DWORD GroupSize[1000];
 DWORD R, k, N;
 DWORD fila;
 
 
 DWORD LlenaViaje()
 {
   DWORD personasdentro = 0;
   DWORD gruposdentro = 0;
   while ((gruposdentro < N) && (personasdentro + GroupSize[fila] <= k))
   {
     gruposdentro++;
     personasdentro += GroupSize[fila];
     if (++fila == N)
     {
       fila = 0;
     }
   }
   return personasdentro;
 }
 
 
 DWORD DoCase()
 {
   DWORD euros = 0;
   fila = 0;
   while (R--)
   {
     euros += LlenaViaje();
   }
   return euros;
 }
 
 
 void main()
 {
   FILE * f;
   f = fopen("d:\\a.txt", "r");
   if (f != NULL)
   {
     DWORD n, T;
     fscanf(f, "%d\n", &T);
     for (n=1; n<=T; n++)
     {
       DWORD i;
       fscanf(f, "%d %d %d\n", &R, &k, &N);
       for (i=0; i< N-1; i++)
       {
         fscanf(f, "%d ", &(GroupSize[i]));
       }
       fscanf(f, "%d\n", &(GroupSize[i]));
       printf("Case #%d: %d\n", n, DoCase());
     }
     fclose(f);
   }
 }
 

