#include <stdio.h>
 #include <stdlib.h>
 
 struct node{int info;
 struct node *next,*prev;
 };
 typedef struct node NODE;
 struct node *start,*temp,*last;
 int calculate_revenue(int trips,int seats);
 
 void insertatend()
 {temp=(NODE *)malloc(sizeof(NODE));
 scanf("%d",&temp->info);
 if(start==NULL)
 {temp->next=temp;
 temp->prev=temp;
 start=temp;
 }
 else
 {last=start;
 while(last->next!=start)
 last=last->next;
 temp->next=start;
 start->prev=temp;
 last->next=temp;
 temp->prev=last;
 last=temp;
 }
 }
 void deleteatbegin()
 {if(start==NULL)
 return;
 else
 {NODE *p;
 if(start->next==start)
 {temp=start;
 start=NULL;
 free(temp);}
 else
 {temp=start;
 p=start->prev;
 start=start->next;
 start->prev=p;
 p->next=start;
 free(temp);
 }
 }
 
 }
 
 int calculate_revenue(int trips,int seats)
 {
 int round_num = 1,size=0,revenue = 0;
 for( round_num=1;round_num<=trips;round_num++)
 {
 temp=start;
 size=0;
 while(size<=seats)
 {
 size = size+temp->info;
 temp = temp->next;
 }
 if(size >seats)
 {
 temp = temp->prev;
 size = size-temp->info;
 }
 
 start = temp;
 revenue = revenue+size;
 }
 return revenue;
 }
 int calc_rev_less_ppl(int seats,int iter,int trips)
 {
 int num_ppl = 0;
 temp=start;
 if(start!=NULL)
 {
 while(temp->next!=start)
 {
 num_ppl = num_ppl +temp->info;
 temp=temp->next;
 }
 num_ppl = num_ppl +temp->info;
 //printf("\nnum_ppl = %d,seats= %d\n",num_ppl,seats);
 if(num_ppl > seats)
 return 1;
 else
 printf("Case #%d: %d\n",iter,num_ppl*trips);
 }
 return 0;
 }
 int main()
 {
 int T_testcases = 0, N_noOfGroups = 0;;
 int R_noOfRounds = 0, seats = 0 ;
 int iter=1,j =0;
 scanf("%d",&T_testcases);
 
 
 for(iter=1; iter<=T_testcases; iter++  )
 {
 scanf("%d%d%d",&R_noOfRounds, &seats, &N_noOfGroups);
 for(j=0; j < N_noOfGroups; j++)
 insertatend();
 if(calc_rev_less_ppl(seats,iter,R_noOfRounds))
 printf("Case #%d: %d\n",iter,calculate_revenue(R_noOfRounds,seats)); 
 for(j=0; j < N_noOfGroups; j++)
 deleteatbegin();
 }
 
 return 0;
 }

