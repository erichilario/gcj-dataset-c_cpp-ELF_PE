#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 #define MAX 20000
 #define LEN 101
 
 char build[MAX][LEN];
 int n_build;
 char new[MAX][LEN];
 int n_new;
 
 int print_dir(char dir[MAX][LEN],int len){
 	int i;
 	fprintf(stderr,"len=%d\n",len);
 	for(i=0;i<len;i++)
 		fprintf(stderr,"%d: %s\n",i,dir[i]);
 	return 0;
 }
 
 int add_dir(char *aux,char dir[MAX][LEN],int *len){
 	int slen=strlen(aux);
 	int i;
 	//fprintf(stderr,"parsing %s\n",aux);
 	//print_dir(dir,*len);
 	for(i=1;i<slen;i++){
 		if(aux[i]=='/'){
 			//fprintf(stderr,"pum\n");
 			memcpy(&(dir[*len][0]),aux,i);
 			dir[*len][i]='\0';
 			(*len)++;
 		}
 	}
 	if(aux[i-1]!='/'){
 		memcpy(&(dir[*len][0]),aux,i);
 		dir[*len][i]='\0';
 		(*len)++;
 		//fprintf(stderr,"pum\n");
 	}
 	//print_dir(dir,*len);
 	return 0;
 }
 int my_cmp(const void *a, const void *b){
 	char *sa=(char *)a;
 	char *sb=(char *)b;
 
 	return strcmp(sa,sb);
 }
 
 int sort_unique(char dir[MAX][LEN],int *len){
 	int i;
 	int aux=*len;
 	int red=0;
 
 	qsort(dir,aux,sizeof(dir[0]),my_cmp);
 	for(i=1;i<aux;i++){
 		if(strcmp(dir[i-1],dir[i])==0){
 			dir[i-1][0]='Z';
 			red++;
 		}
 	}
 	qsort(dir,aux,sizeof(dir[0]),my_cmp);
 	*len-=red;
 
 	return 0;
 }
 
 int find_all(){
 	int i;
 	int ret=0;
 
 	for(i=0;i<n_new;i++){
 		if(bsearch(new[i],build,n_build,sizeof(new[0]),my_cmp)==NULL)
 			ret++;
 	}
 	return ret;
 }
 
 int main(int argc, char *argv[]){
 	int i,j,n_cases;
 	int build_j,new_j,k;
 	char dir[LEN];
 	int res;
 
 	if (1!=fscanf(stdin,"%d",&n_cases)){
 		return -1;
 	}
 
 	for(i=1;i<=n_cases;i++){
 		n_build=0;
 		n_new=0;
 		res=0;
 		if (2!=scanf("%d %d\n",&build_j, &new_j)){
 			fprintf(stderr,"not 2\n");
 			return -1;
 		}
 		for (j=0;j<build_j;j++){
 			gets(dir);
 			add_dir(dir,build,&n_build);
 		}
 		sort_unique(build,&n_build);
 		for (j=0;j<new_j;j++){
 			//n_new=0;
 			gets(dir);
 			add_dir(dir,new,&n_new);
 			/*for(k=0;k<n_new;k++){
 				strcpy(&(build[n_build][0]),&(new[k][0]));
 				n_build++;
 			}*/
 		}
 		sort_unique(new,&n_new);
 		res=find_all();
 		printf("Case #%d: %d\n",i,res);
 	}
 
 	return 0;
 }

