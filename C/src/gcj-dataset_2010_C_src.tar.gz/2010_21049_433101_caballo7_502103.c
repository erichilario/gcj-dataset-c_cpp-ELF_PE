// Snapper problem on Google CodeJam qualification round.
 // Author: Dhruv Garg
 
 #include<stdio.h>
 #include<math.h>
 int main(int argc, char *argv[]) {
 	FILE *infile = fopen(argv[1],"r");
 	FILE *outfile = fopen("snapper.out","w");
 	if (infile == NULL) {
 		printf("Unable to open file.\n");
 	}
 	int num_inputs;
 	fscanf(infile, "%d", &num_inputs);
 	int N, i;
 	long K;
 	for (i = 0; i < num_inputs; i++) {
 		fscanf(infile,"%d",&N); // N = number of snappers
 		fscanf(infile,"%ld",&K); // K = number of snaps
 		int rem = (K+1)%(int)(pow(2,N));
 		if (rem == 0) {
 			fprintf(outfile,"Case #%d: %s\n",i+1,"ON");
 		} else {
 			fprintf(outfile,"Case #%d: %s\n",i+1,"OFF");
 		}
 	}
 }
