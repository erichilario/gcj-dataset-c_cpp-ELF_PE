#include <iostream>
 #include <stdlib.h>
 #include <stdio.h>
 using namespace std;
 
 bool get_if_win(long a,long b)
 {
 	long h,l;
 	
 	if (a == b)
 	{
 		return false;
 	}
 	else
 	{
 		l = a<b?a:b;
 		h = a<b?b:a;
 		if ( h >= 2*l )
 		{
 			return true;
 		}
 		else
 		{
 			return !(get_if_win(h-l,l));
 		}
 	}
 }
 
 int main()
 {
 	int t,T;
 	long long win_cnt;
 	
 	long A1,A2,B1,B2,a,b;
 	bool A_turn;
 	
 	cin >> T;
 	
 	for ( t = 0; t < T; t++ )
 	{
 		cin >> A1 >> A2 >> B1 >> B2;
 		
 		win_cnt = 0;
 		for ( a = A1; a <= A2; a++ )
 		{
 			for ( b = B1; b <= B2; b++ )
 			{
 				if ( get_if_win(a,b) ) win_cnt++;
 			}
 		}
 		
 		cout << "Case #" << t + 1 << ": " << win_cnt << "\n";
 	}
 	
 	return 0;
 }
