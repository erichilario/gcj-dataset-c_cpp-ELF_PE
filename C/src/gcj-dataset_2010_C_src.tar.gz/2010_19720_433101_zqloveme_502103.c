#include "stdafx.h"
 #include <iostream>
 #include <iomanip>
 #include <stdlib.h>
 using namespace std;
 
 struct snapper {
 	bool power;
 	bool on;
 } a [30 + 2];
 
 void reset (int n)
 {
 	for ( int i = 0; i < n; i++ ) {
 		a [i].power = false;
 		a [i].on = false;
 	}
 	a [0].power = true;
 }
 bool SnapperJudgeInter(int n,int k){
 
 	reset(n);
 
 	for ( int i = 0; i < k; i++ ) {
 		for ( int j = 0; j < n; j++ ) {
 			if ( a [j].power )
 				a [j].on = a [j].on ? false : true;
 		}
 		for ( int j = 0; j < n; j++ ) {
 			if ( a [j].power && a [j].on )
 				a [j + 1].power = true;
 			else
 				a [j + 1].power = false;
 		}
 	}
 
 	if ( a [n - 1].power && a [n - 1].on )
 		return true;
 	else
 		return false;
 }
 void SnapperChain(){
 	FILE *fin,*fout;
 	char inputFile[] = "A-small-attempt11.in";
 	char outFile[] = "pengjinningSubmition11.out";
 
 	int numOfLines = 0,N = 0,K = 0,count = 1;
 
 	if ((fin = fopen(inputFile,"r"))==NULL)
 	{
 		printf("can not open file %s\n",inputFile);
 		//exit(-1);
 	}
 	if ((fout = fopen(outFile,"w"))==NULL)
 	{
 		printf("can not open file %s\n",outFile);
 		//exit(-1);
 	}
 
 	fscanf(fin,"%d",&numOfLines);
 
 	while (count <= numOfLines)
 	{
 		fscanf(fin,"%d%d",&N,&K);
 
 		//if (SnapperJudge(N,K))
 		if (SnapperJudgeInter(N,K))
 		{
 			fprintf(fout,"Case #%d:%s",count++," ON");
 		} 
 		else
 		{
 			fprintf(fout,"Case #%d:%s",count++," OFF");
 		}
 		if (count <= numOfLines)
 		{
 			fprintf(fout,"%s\n","");
 		}		
 	}
 	fclose(fin);
 	fclose(fout);
 }
 
 //int _tmain(int argc, _TCHAR* argv[])
 //{
 //
 //	////////////////////////////////////////////////////////
 //
 //	SnapperChain();
 //
 //	///////////////////////////////////////////////////////
 //
 //	system("pause");
 //	return 0;
 //}

