#include<stdio.h>
 
 int main()
 {
    int c,n,a[3],b[3],ytemp,y;
    int i,j,k,temp,max,hcf,rem,r;
    
    scanf("%d",&c);
    for(i=1;i<=c;i++){
       scanf("%d",&n);                  
       for(j=0;j<n;j++){
          scanf("%d",&a[j]);                 
       }
       
       for(j=n-2;j>=0;j--){
          for(k=0;k<=j;k++){
             if(a[k]<a[k+1]){
                 temp=a[k];
                 a[k]=a[k+1];
                 a[k+1]=temp;            
             }                  
          }                   
       }
       
       max=a[0];  
       k=1;  
       for(j=0;j<n-1;j++){
           b[j]=max-a[k];
           k++;
           if(b[j]==0){
              n--;
              j--;         
           }
          /* printf("%d ",b[j]);              */
       }
       
       if((n-2)!=0){
          rem=b[0];r=rem;hcf=rem;
          for(k=1;k<=(n-2);k++){
             hcf=b[k];              
             while(r!=0){
                rem=hcf%r;
                hcf=r;
                r=rem;           
              }           
          }
       }
       else{
         hcf=b[0];     
       }
      
       ytemp=max%hcf;
       if(ytemp==0){
         y=0;
       }
       else{
         y=hcf-ytemp;
       }
       
       printf("Case #%d: %d",i,y);
       printf("\n");
       
       
    }   
 
    return 0;
     
 }

