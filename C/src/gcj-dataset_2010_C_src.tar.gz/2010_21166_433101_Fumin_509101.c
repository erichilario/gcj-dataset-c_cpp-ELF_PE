#include <conio.h>
 #include <stdio.h>
 
 void p(FILE *output, long T, long R, long k, long N, long *g) {
   int pointer = 1;
   int round;
   int i;
   long long sum = 0;
 
   for(round = 0; round < R; round++) {
     long t = 0;
     for(i = 0; i < N; i++) {
       t += g[pointer];
       
       pointer++;
       if(pointer > N) pointer = 1;
     
       if(t+g[pointer] > k) {
         break;
       }
     }
     sum += t;
   }
 
   fprintf(output, "Case #%d: %d\n", T, sum);
   printf("Case #%d: %d\n", T, sum);
 }
 
 int main()
 {
   FILE *input = fopen("input.txt", "r"); 
   FILE *output = fopen("output.txt", "w");
   long T=0, CaseNum, R, k, N, g[1001];
   int i;
   
   fscanf(input, "%d\n", &CaseNum);
   printf("%d\n", CaseNum);
   for( T=1; T<=CaseNum; T++) {      
     fscanf(input, "%d %d %d\n", &R, &k, &N);        
     printf("%d %d %d\n", R, k, N);
     for(i = 1; i <= N; i++) {
       fscanf(input, "%d\n", &g[i]);
       printf("%d ", g[i]);
     }
     printf("\n");
     p(output, T, R, k, N, g);
   }  
 
   fclose(input);
   fclose(output);
   return 0;
 }

