#include <stdio.h>
 #include <stdlib.h>
 
 #define true 1
 #define false 0
 
 typedef unsigned char bool;
 
 bool power[110][12], on[110][12];
 
 int main()
 {
    int T, cont = 0;
    int i, k;
    
    scanf("%d\n", &T);
    
    for(i = 0; i < 10; i++)
       power[0][i] = on[0][i] = false;
    power[0][0] = true;
    
    for(i = 1; i < 110; i++)
       for(k = 0; k < 12; k++)
       {
          if(power[i-1][k] == true)
          {
             on[i][k] = (on[i-1][k] == true) ? false : true;
          }
          else
          {
             on[i][k] = on[i-1][k];
          }
          
          if(k > 0)
          {
             if(power[i][k-1] == true && on[i][k-1] == true)
                power[i][k] = true;
             else
                power[i][k] = false;
          }
          else
          {
             power[i][k] = true;
          }
       }
 
    while(T--)
    {
       int n;
       
       scanf("%d %d", &n, &k);
       printf("Case #%d: %s\n", ++cont, (on[k][n-1] == true && power[k][n-1] == true) ? "ON" : "OFF");
    }
    
 return 0;
 }

