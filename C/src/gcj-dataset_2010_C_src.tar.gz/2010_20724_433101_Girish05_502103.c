 #include<stdio.h>
     #include<conio.h>
     #include<stdlib.h>
     #include<math.h>
 
     void main()
     {
 	FILE *fs,*ft;
 	int t=10,n,k,l,c;
      //	char ch;
 	int i=0,j;
 	char a[25]="OFF";
 	clrscr();
 
 
       fs = fopen("c:/a.txt","r");
       if(fs==NULL)
        {
       printf("Cannot open source file ! Press key to exit.");
       getch();
       exit(0);
       }
 
       ft = fopen("c:/output.txt","w");
       if(ft==NULL)
       {
       printf("Cannot copy file ! Press key to exit.");
       fclose(fs);
       getch();
       exit(0);
       }
 
       while(i<=t)
       {
 
 	  strcpy(a,"OFF");
 
 	  if(i==0)
 	  {
 	   fscanf(fs,"%d",&j);
 	   t=j;
 	  }
 	  else
 	  {
 	    fscanf(fs,"%l %l",&n,&k);
 
 	    c=pow(2,n);
 	 // printf("%d\n",c);
 	    c=c-1;
 
 
 	    while(c<=k)
 	    {
 
 		if(c==k)
 		strcpy(a,"ON");
 
 		c=c+pow(2,n);
 
 	    }
 	  }
 
 	if(i!=0)
 	fprintf(ft,"%s #%d: %s\n","Case",i,a);
 	i++;
       }
 
 
     //  scanf("%d",&i);
       fclose(fs);
       fclose(ft);
   }
 
 
 
 

