#include<stdio.h>
 //~
 int main()
 {
 int T,N,K,Num,result,flag,i;
 scanf("%d",&T);
 for(i=1;i<=T;i++)
 	{ Num=0;
 	scanf("%d%d",&N,&K);
 	Num = (1<<(N))-1;
 	//printf("%d NUM\n",Num);
 	result=(K)%(Num+1);
 	//printf("%d %d result Num\n",result,Num);
 	//result++;
 	//flag=!(result&(result-1));
 	flag= Num==result;
 	//printf("%d flag\n",flag);
 	if(flag)
 	printf("Case #%d: ON\n",i);
 	else
 	printf("Case #%d: OFF\n",i);
 	}
 return 0;	
 
 }

