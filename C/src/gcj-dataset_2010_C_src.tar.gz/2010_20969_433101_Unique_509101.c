#include<stdio.h>
 #include<stdlib.h>
 int n,t,r,in,chek;
 int *grp,*nxt;
 long long int *mem;
 int k,kt,temp,i;
 long long int count,cnt;
 void calc()
 {
 	int st =0;
 	count = 0;
 	cnt = 0;
 	temp = 0;
 	kt = k;
 	chek = 0;
 	while(r>0)
 	{
 		count =0 ;
 		if(mem[st] != 0)
 		{
 			cnt+=mem[st];
 			st = nxt[st];
 			r--;
 		}
 		else
 		{	
 			temp = st;
 			while(!(grp[temp] > kt || chek>=n))
 			{
 				chek++;
 				kt = kt-grp[temp];
 				count = count+grp[temp];			
 				temp = (temp+1)%n;
 			}
 			nxt[st] = temp;
 			mem[st] = count;
 			cnt+=count;
 			r--;
 			kt = k;
 			chek = 0;
 			st = temp;
 		}	
 	}
 }
 int main()
 {
 
 	scanf("%d",&t);
 	for(in =1;in<=t;in++)
 	{
 		scanf("%d %d %d",&r,&k,&n);
 		grp=(int*)malloc(sizeof(int)*n);
 		mem=(long long int*)malloc(sizeof(long long int)*n);
 		nxt=(int*)malloc(sizeof(int)*n);
 		for(i=0;i<n;i++)
 		{
 			scanf("%d",&grp[i]);
 			mem[i] = 0;
 			nxt[i] = 0;
 		}	
 		calc();
 		printf("Case #%d: %lld\n",in,cnt);
 		free(grp);
 		free(mem);
 	}
 return 0;
 }

