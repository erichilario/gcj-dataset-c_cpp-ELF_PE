#include <stdio.h>
 #define IN input
 #define OUT output
 #define MAXNUM 3
 
 FILE *input, *output;
 
 
 long long gcd(long long x, long long y)
 {
 	if(x < y)
 		return gcd(y, x);
 	if(y == 0)
 		return x;
 	else
 		return gcd(x-y, y);
 }
 
 void sort(long long num[], int count)
 {
 	if(count == 2){
 		if(num[0] < num[1]){
 			num[0] ^= num[1];
 			num[1] ^= num[0];
 			num[0] ^= num[1];
 		}
 	}
 	else if(count == 3)
 	{
 		if(num[0] < num[1]){
 			num[0] ^= num[1];
 			num[1] ^= num[0];
 			num[0] ^= num[1];
 		}
 		if(num[1] < num[2]){
 			num[1] ^= num[2];
 			num[2] ^= num[1];
 			num[1] ^= num[2];
 		}
 		if(num[0] < num[1]){
 			num[0] ^= num[1];
 			num[1] ^= num[0];
 			num[0] ^= num[1];
 		}
 	}
 }
 
 void main()
 {
 	input = fopen("B-small-attempt1.in","r");
 	output = fopen("fair_small.out", "w");
 	int t;
 	long long number[MAXNUM], substr[MAXNUM-1];
 	int count = 0;
 	fscanf(IN, "%d", &t);
 	int i;
 	for(i = 0; i < t; i ++)
 	{
 		fscanf(IN, "%d", &count);
 		int j;
 		for(j = 0; j < count; j++)
 			fscanf(IN, "%llu", &number[j]);
 		sort(number, count);
 		for(j = 0; j < count-1; j++)
 			substr[j] = number[j]-number[j+1];
 		long long gcdv = (count == 2)?substr[0]:gcd(substr[0], substr[1]);
 
 		long long target = gcdv;
 		if(gcdv > 0){
 		while(target < number[count-1])
 			target += gcdv;
 			fprintf(OUT, "Case #%d: %llu\n", i+1, target - number[count-1] );
 		}else if(gcdv == 0)
 			fprintf(OUT, "Case #%d: %llu\n", i+1, number[count-1] );
 		
 	}
 }

