#include <stdio.h>
 
 int main() {
     unsigned long int t, k, n, i, p;
     char *on = "ON";
     char *off = "OFF";
     char *res;
     scanf("%lu", &t);
     for(i=1; i<=t; i++) {
 	scanf("%lu %lu", &n, &k);
 	k++;
 	p = 1 << n;
 	res = (k % p) ? off : on;
 	printf("Case #%lu: %s\n", i, res);
     }
     return 0;
 }

