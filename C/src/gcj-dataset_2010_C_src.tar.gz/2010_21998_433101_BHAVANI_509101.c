#include <stdio.h>
 #define MAXN 10
 unsigned long long k,r,g[MAXN];
 int n,testCase;
 void compute();
 struct theme{
 	int visited;
 	int endP;
 	int noElem;
 	int noElemSeen;
 	int roundSeen;
 	int round;
 };
 struct theme data[MAXN];
 int j,i;	
 int noElem = 0;
 int main() {
 scanf("%d",&testCase);
 for( i = 1; i <= testCase; i++ ) {
 	scanf("%llu %llu %d",&r,&k, &n);
 	noElem = 0;
 	for ( j = 0; j < n; j++ ) {
 		scanf("%llu",&g[j]);	
 		noElem += g[j];
 		data[j].visited = 0;
 	}
 	printf("Case #%d: ",i);
 	if ( noElem <= k ) {
 		printf("%llu\n",r*noElem);
 	}
 	else {
 		compute();
 	}
 	}
 return 0;
 }
 void compute() {
 	
 	int start = 0;
 	int noElemSeen = 0;
 	noElem = 0;
 	for ( j = 0; j < r; j++ ) {
 		
 		if (1) {
 			data[start].visited = 1;
 			data[start].noElemSeen = noElemSeen;
 			data[start].roundSeen = j;
 			int l;	
 			for ( l = 0; l < n; l++ ) {
 				noElem += g[(start+l)%n];
 				if ( noElem > k ) {
 					noElem -= g[(start+l)%n];
 					break;				
 				} 			
 			}
 			data[start].noElem = noElem;
 			noElemSeen += noElem;
 			data[start].endP = (start+l - 1)%n;
 			start = (data[start].endP + 1)%n; 
 			noElem = 0;
 		}
 		if ( r - 1 == j ) {
 			printf("%d\n",noElemSeen);			
 			return;
 		}
 	}	
 	return;	
 
 }

