#include<stdio.h>
 #include<math.h>
 
 int main(){
 
 	int i,T,N,K;	
 
 	scanf("%d",&T);
 	
 	for(i=0;i<T;i++){
 		scanf("%d %d",&N,&K);
 		int num= pow(2,N);
 		if( (K%num) == num-1 )			
 			printf("Case #%d: ON\n",i+1);
 		else
 			printf("Case #%d: OFF\n",i+1);
 	}	
 
 	return 1;
 }
 
 
 
 
 

