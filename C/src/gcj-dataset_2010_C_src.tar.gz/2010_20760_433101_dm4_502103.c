#include <stdio.h>
 #include <math.h>
 
 int main() {
     int power[11];
     int on[11];
     power[0] = 1;
     int N, K;
     int times;
     scanf("%d", &times);
     int i, j;
     for(i=0;i<times;i++) {
         scanf("%d %d", &N, &K);
         int ans = (K+1) % (int)pow(2, N);
         printf("Case #%d: %s\n", i+1, ans ? "OFF" : "ON");
     }
 }

