#include<stdio.h>
 int main(){
 	long long int N, K , R ;
 	int tc;
 	int i,j,k;
 
 	int groups[1200];
 
 	long long int ans=0;
 	long long int maxPeoplei [1200];
 	int next[1200];
 
 	scanf("%d",&tc);
 
 	for(i=1 ; i<=tc; i++)
 	{
 		ans=0;
 		scanf("%lld%lld%lld",&R,&K,&N);
 		for( j=0 ; j<N ; j++)
 		{
 			scanf("%d",&groups[j]);
 		}
 
 		for ( j=0 ; j<N ; j++)
 		{
 			maxPeoplei[j] = groups[j];
 			for( k=j+1 ; k != j ; k++)
 			{
 				if(k == N)
 					k=0;
 				if( k == j)
 					break;
 				
 					if(maxPeoplei[j] + groups[k] > K)
 					{
 						break;
 					}
 
 					else
 						maxPeoplei[j] += groups[k];
 			}
 
 			next[j] = k;
 
 
 		}
 		int cur=0;
 		for( j=0 ; j<R ; j++)
 		{
 			ans += maxPeoplei[cur];
 			cur = next [cur];
 		}
 		printf("Case #%d: %lld\n",i,ans);
 
 	}
 
 	return 0;
 }

