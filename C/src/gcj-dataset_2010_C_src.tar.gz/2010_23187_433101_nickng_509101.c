#include <stdio.h>
 
 int main()
 {
     int T;
     int c, i, n;
     long run, spaces_left;
 
     int head_of_queue;
     int number_admitted;
 
     long result;
     long R, k, N;
     long g[1000];
 
     scanf("%d\n", &T);
     for (c=1; c<=T; ++c) {
         scanf("%ld %ld %ld\n", &R, &k, &N);
 
         // g_i
         for (i=0; i<N; ++i) { scanf("%ld ", &g[i]); }
 
         head_of_queue = 0;
 
         result = 0;
         for (run=0; run<R; ++run) {
             fprintf(stderr, "Run #%d: ", run);
             spaces_left = k;
             number_admitted = 0;
             while (spaces_left >= g[head_of_queue]) {
                 spaces_left -= g[head_of_queue];
                 head_of_queue = (head_of_queue + 1) % N;
                 ++ number_admitted;
                 if (number_admitted >= N) break;
             }
             fprintf(stderr, "spaces_left = %d, head_of_queue = %d ", spaces_left, head_of_queue);
             result += k - spaces_left;
             fprintf(stderr, "euros =  %ld\n ", result);
         }
 
         printf("Case #%d: %ld\n", c, result);
     }
     return 0;
 }

