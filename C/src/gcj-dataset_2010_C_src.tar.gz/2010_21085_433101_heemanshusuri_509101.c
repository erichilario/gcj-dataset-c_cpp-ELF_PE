#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc,char** argv)
 {
 	FILE* in = fopen(argv[1],"r+");
 	FILE* out = fopen("output","w+");
 	int T,R,K,N;
 	fscanf(in,"%d",&T);
     	if(T>=1 && T<=50){
     		int i = 0;
     		while(i < T){
         		i++;
         		fscanf(in,"%d %d %d",&R,&K,&N);
 	     		if(N >=1 && N <= 10 && K >= 1 && K <= 100 && R >= 1 && R <= 1000){
 				int j=0,*a = (int *)malloc(N*sizeof(int));
 				for(j = 0;j < N-1;j++)
 					fscanf(in,"%d ",&a[j]);
 				fscanf(in,"%d",&a[j]);
 				int str,strt = 0,tot,res = 0;
 				for(j = 0;j < R;j++){
 					tot = 0;
 					str = strt;
 					while(a[strt] + tot <= K){
 						tot += a[strt];
 						strt = (strt+1)%N;
 						if(str == strt)break;
 					}
 					res += tot;
 				}
 				fprintf(out,"Case #%d: %d\n",i,res);
 			}
     		}	
     	}
 }
 

