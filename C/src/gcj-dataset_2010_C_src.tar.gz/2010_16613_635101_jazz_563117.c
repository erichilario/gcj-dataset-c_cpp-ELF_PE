#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 
 
 int mc(const char* a, const char* b)
 {
 	int r = 0;
 	while( *a != '\0' && *a == *b) { a++; b++; }
 	if ( *a == '\0' && *b == '\0' )
 		return 0;
 	while( *b != '/' ) b--;
 	for(;*b;b++)
 		if (*b=='/') r++;
 	return r;
 }
 
 // FixIt
 int main()
 {
 	char  dirs[1024][128];	// sorted array of strings... (existing, new one)
 	int c,t,n,m,i,j,e,f,g;
 	scanf("%d", &c);
 	t = 0;
 	while(t<c) {
 		scanf("%d %d", &n, &m);
 		for(i=0;i<n;i++)
 			scanf("%s", dirs[i]);	// 0..N-1
 		for(;i<(n+m);i++)
 			scanf("%s", dirs[i]);	// N..(N+M-1)
 		// sort N..
 		qsort(&dirs[0],n,128,strcmp);
 		qsort(&dirs[n],m,128,strcmp);
 		e = 0;
 		j = 0;
 	//	for(i=0;i<n;i++)
 	//		printf("e: %s\n", dirs[i]);
 		// N.. check
 		for(i=n;i<(n+m);i++) {
 			f = mc("",dirs[i]);
 			for(j=0;j<i;j++) {
 				if ((g = mc(dirs[j],dirs[i])) < f && g >= 0)
 					f = g;
 			}
 			e += f;
 	//		printf("%d = %s (i:%d,j:%d)\n", f, dirs[i], i, j);
 		}
 		printf("Case #%d: %d\n", ++t, e);
 	}
 	return 0;
 }

