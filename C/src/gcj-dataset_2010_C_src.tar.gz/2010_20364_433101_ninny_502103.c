#include<stdio.h>
 
 // 0 if OFF and 1 is On for both state and power
 int main()
 {
 
 int t,i,j,n,k,tc;
 
 FILE *f=fopen("D:/A-small-attempt2.in","r");
 
 fscanf(f,"%d",&tc);
 
 for(t=0;t<tc;t++)
 {
 
 fscanf(f,"%d",&n);
 fscanf(f,"%d",&k);
 
 int power[n],state[n];
 
 
 for (i=0;i<n;i++)
 {
 state[i]=0;
 power[i]=0;
 }
 
 power[0]=1;
 
 for(j=1;j<=k;j++)
 	{
 
 	for(i=0;i<n;i++)
 		{
 		if(power[i]==1)
 		state[i]=1-state[i];
 		}
 
 	for(i=1;i<n;i++)
 		{
 		if(power[i-1]==1 && state[i-1]==1)
 		{power[i]=1;}
 		else
 		{power[i]=0;}
 
 		}
 	}
 
 
 
 if(power[n-1]==1 && state[n-1]==1)
 printf("Case #%d: ON \n",t+1);
 
 else
 printf("Case #%d: OFF \n",t+1);
 
 }
 }

