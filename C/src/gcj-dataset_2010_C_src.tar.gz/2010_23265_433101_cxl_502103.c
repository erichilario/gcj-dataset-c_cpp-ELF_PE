#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 
 void click(int a[], int snappers) {
 	int i;
 	int count=0;
 	int pos=0;
 
 	if(a[0] == 0){
 		a[0] = 1;
 	} else {
 		click(a+1,snappers-1);
 		a[0] = 0;
 	}
 
 }
 
 
 int test(FILE* out, int snappers, int clicks) {
 	unsigned int buf[100];
 	int i,j;
 	int pos;
 	int ret=1;
 
 	for(i=0;i<100;i++) {
 		buf[i]=0;
 	}
 
 	for(i = 0;i<clicks;i++) {
 		click(buf,snappers);
 	}
 
 	for(i=0;i<snappers;i++) {
 		if(buf[i] != 1)
 			return 0;
 	}
 	return 1;
 
 }
 
 int main(void) {
 	FILE *fin, *fout;
 	int n_cases=0;
 	int snappers, clicks;
 	int i;
 	int a;
 
 	fin = fopen("A-small-attempt12.in", "r");
 	fout = fopen("output.txt", "w");
 	
 	fscanf(fin, "%d", &n_cases);
 	
 	for(i=0;i<n_cases;i++) {
 		fscanf(fin, "%d %d", &snappers, &clicks);
 		a = test(fout, snappers, clicks);
 		if(a == 1) {		
 			fprintf(fout, "Case #%d: ON\n", i+1);
 		}
 		else if(a == 0) {
 			fprintf(fout, "Case #%d: OFF\n", i+1);
 		}
 	}
 	
 /*
 	int buf[50];
 	for(i=0;i<50;i++) {
 		buf[i]=0;
 	}
 
 	while(1) {
 		click(buf,4);
 	}
 	
 	fclose(fin);
 	fclose(fout);*/
 
 	return 0;
 
 }
