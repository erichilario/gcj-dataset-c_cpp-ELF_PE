#include<stdio.h>
 #include<string.h>
 
 char a[101][101];
 char b[101][101];
 char c[101][1000];
 int n,m,ind,ind2;
 char *p;
 char cad[101];
 
 void insertar()
 {
  int i,j,b;
  b=0;
  for(i=0;i<ind;i++)
   if(strcmp(c[i],cad)==0&&!b){b=1;}
  if(!b)
  {
   strcpy(c[ind],cad);
   ind++;
  }
 }
 
 void insertar2()
 {
  int i,j,b;
  b=0;
  for(i=0;i<ind2;i++)
   if(strcmp(c[i],cad)==0&&!b){b=1;}
  if(!b)
  {
   strcpy(c[ind2],cad);
   ind2++;
  }
 }
 
 
 
 main()
 {
  int i,j,t,c;
  char aux[101],ant[1000]; 
  scanf("%d",&t);
  c=1;
  for(i=0;i<t;i++)
  {
   scanf("%d %d",&n,&m);
   getchar();
   for(j=0;j<n;j++)scanf("%s",a[j]);
   for(j=0;j<m;j++)scanf("%s",b[j]);
   
   ind=0;
   for(j=0;j<n;j++)
   {
    strcpy(aux,a[j]);
    p=strtok(&aux[1],"/");
    strcpy(ant,"");
    while(p!=NULL)
    {
      strcpy(cad,"/");
      strcat(cad,p);
      strcat(ant,cad);
      strcpy(cad,ant);
      insertar();
      p=strtok(NULL,"/");
    }
   }
   ind2=ind;
   for(j=0;j<m;j++)
   {
    strcpy(aux,b[j]);
    p=strtok(&aux[1],"/");
    strcpy(ant,"");
    while(p!=NULL)
    {
      strcpy(cad,"/");
      strcat(cad,p);
      strcat(ant,cad);
      strcpy(cad,ant);
      insertar2();
      p=strtok(NULL,"/");
    }
   }
   printf("Case #%d: %d\n",c++,abs(ind2-ind));
  }
 }
 

