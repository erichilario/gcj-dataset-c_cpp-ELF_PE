#include <stdio.h>
 #define MAX 10
 
 
 int main(int argc, char *argv[])
 {
     FILE *fp, *output;
     int power[MAX];
     int state[MAX];
     int total;
     int clicks;
     int cycles, loop;
     char str[100];
     char *value, *abcd;
     int i, j, k, pow_total;
 
     fp = fopen("in", "r");
     if(fp == NULL)
     {
         printf("Failed to open A.in file\n");
 	return -1;
     }
 
     output = fopen("out", "w");
     if(output == NULL)
     {
         printf("Failed to open A.out file\n");
 	return -1;
     }
 
     cycles = atoi(fgets(str, 100, fp));
     printf("Cycles = %d\n", cycles);
 
 
     for(loop = 0; loop < cycles; loop++)
     {
 
         fgets(str, 100, fp);
         value = (char*)strtok_r(str, " ", &abcd);
         total = atoi(value);
         value = (char*)strtok_r(NULL, " ", &abcd);
         clicks = atoi(value);
 	
         printf("Total - %d, Clicks - %d\n", total, clicks);
          
     /* Initializing */
     power[0] = 1; /*Power is always 1*/
     state[0] = 0;
     for(i=1; i<MAX; i++)
     {
 	state[i] = 0;
 	power[i] = 0;
     }
 
     for(i=0; i<clicks; i++)
     {
 	if(state[0])
 	{
 	    state[0] = 0;
 	}
 	else
 	{
 	    state[0] = 1;
         }
 
 	for(j=1; j<total; j++)    
 	{
             if((power[j]))
     	    {
 	        if(state[j])
 		    state[j] = 0;
 	        else
 	            state[j] = 1;
             }  
 	}
 
 	for(k=1; k<total; k++)
 	{
 	    if(power[k-1] && state[k-1])
 		power[k] = 1;
 	    else
 		power[k] = 0;
 	}
     }
 
 	if(power[total-1] && state[total-1])
 	{
             printf("Case #%d: ON\n", loop+1);
             fprintf(output, "Case #%d: ON\n", loop+1);
 	}
         else
 	{
             printf("Case #%d: OFF\n",loop+1);
             fprintf(output, "Case #%d: OFF\n",loop+1);
 	}
     }
 
     fclose(fp);
     fclose(output);
 }

