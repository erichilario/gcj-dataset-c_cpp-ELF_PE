/* KRIOZERO */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <unistd.h>
 
 #define OFF 0
 #define ONN 2
 #define ONP 3
 
 typedef struct{
 	char p;
 	char a;
 } snapper;
 
 int main(int argc, char **argv){
 	int cases,rcases;
 	FILE *fd,*outfd;
 	char lin[40];
 	char outlin[40];
 	int ndevs;
 	long long int snps;
 	long long int s,d;
 	long long int cascade;
 	snapper *devices; // OFF:0 ON-NoPower:2 ON-Power:3
 	snapper *devstat;
 
 	printf("Fichero OUT: %s\n",argv[2]);
 	outfd = fopen(argv[2],"w");
 
 	printf("Fichero IN: %s\n\n",argv[1]);
 	fd = fopen(argv[1],"r");
 
 	fgets(lin,39,fd);
 	sscanf(lin,"%d",&cases);
 	rcases = cases;
 
 	//printf("%d\n",cases);
 	for(;cases!=0;--cases){
 		fgets(lin,39,fd);
 		sscanf(lin,"%d %lld",&ndevs,&snps);
 		//printf("%d %lld\n",ndevs,snps);	
 		
 		//free(devices);
 		if(rcases==cases){
 			devices = (snapper *)malloc(ndevs*sizeof(snapper));
 		} else {
 			devices = realloc(devices,ndevs*sizeof(snapper));
 		}
 		
 		for(d=0;d!=ndevs;++d){
 			devices[d].p=0;
 			devices[d].a=0;
 		}
 		
 		cascade = 1;
 		for(s=snps;(s!=0 /*&& cascade<=ndevs*/);--s){
 			//fprintf(stderr,"%lld: \n",snps-s);
 			for(d=0;d!=cascade;d++){
 				if(d==0){
 					if(devices[d].p==OFF){
 							//devices[d].p=devices[d].a;
 							devices[d].a=ONP;
 					} else {
 							//devices[d].p=devices[d].a;
 							devices[d].a=OFF;
 					}
 				} else {
 					if(devices[d-1].p==OFF && devices[d].p==ONN){
 						if(devices[d-1].a==ONP){
 							devices[d].a=ONP;
 						}
 					} else if(devices[d-1].p==ONP && devices[d].p==OFF){
 						devices[d].a=ONN;
 					} else if(devices[d-1].p==ONP && devices[d].p==ONP){
 						devices[d].a=OFF;						
 					//} else if(devices[d-1].p==ONN && devices[d].p==OFF){
 					//	devices[d].a=OFF;
 					} else if(devices[d-1].p==ONN && devices[d].p==ONN){
 						if(devices[d-1].a==ONP){
 							devices[d].a=ONP;
 						}
 						else{
 							devices[d].a=ONN;
 						}
 					}
 				}
 				
 				if(devices[cascade-1].a==ONP)
 					++cascade;
 			}
 
 			for(d=0;d!=cascade;d++){	
 				devices[d].p=devices[d].a;
 			}
 
 		}
 		if(devices[ndevs-1].a==ONP){
 			//fprintf(stderr,"Case #%d: ON\n",rcases-cases+1);
 			fprintf(outfd,"Case #%d: ON\n",rcases-cases+1);
 		} else {
 			//fprintf(stderr,"Case #%d: OFF\n",rcases-cases+1);
 			fprintf(outfd,"Case #%d: OFF\n",rcases-cases+1);
 		}
 		
 	}
 	if(ndevs!=0){
 			free(devices);
 		}
 
 	fclose(fd);
 	return 0;
 }

