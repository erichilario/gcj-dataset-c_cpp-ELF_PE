
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 typedef enum { false = 0, true  = 1 } bool;
 
 typedef struct {
   char path[128];
 } DIRECTORY;
 
 #define builtindirs 1000
 
 bool verbose = false;
 
 int getn(FILE *input) {
   char  buffer[256];
   int   pos = 0;
   short c;
   
   memset(buffer, 0, 256);
   
   while ((((c = fgetc(input)) != EOF) && (c != ' ')) && c != '\n') {
     buffer[pos++] = c;
   }
   return atoi(buffer);
 }
 
 bool dir_exists(DIRECTORY *dirs, char *dir) {
   int i;
   for (i = 0; i < builtindirs; i++) {
     if (dirs[i].path[0] == 0) {
       if (verbose) printf("Dir '%s' does not exist.\n", dir);
       return false; // no path string, end of list
     }
     if (strcmp(dirs[i].path, dir) == 0) {
       if (verbose) printf("Dir '%s' exists\n", dir);
       return true; // path matches
     }
   }
   
       if (verbose) printf("Dir '%s' does not exist.\n", dir);
       return false; // no path string, end of list
 }
 
 bool add_dir(DIRECTORY *dirs, char *dir) {
   int i;
   
   if (dir[strlen(dir) - 1] == '\n') dir[strlen(dir) - 1] = 0;
   
   for (i = 0; i < builtindirs; i++) {
     if (dirs[i].path[0] == 0) {
       strcpy(dirs[i].path, dir);
       if (verbose) printf("Added dir '%s'\n", dirs[i].path);
       return true;
     }
   }
   printf("out of directory space :(\n");
   return false;
 }
 
 int operation_count(DIRECTORY *dirs, char *path) {
   char *token;
   char curpath[256] = "";
   int count = 0;
   
   if (dir_exists(dirs, path)) return 0;
   
   token = strtok(path + 1, "/\n");
   while (token[0] != 0) {
     if (verbose) printf("  Cur token: %s\n", token);
     strcat(curpath, "/");
     strcat(curpath, token);
     
     if (verbose) printf("Checking for %s\n", curpath);
     
     if (!(dir_exists(dirs, curpath))) {
       if (!(add_dir(dirs, curpath))) return 0;
       count++;
     }
     
     token = strtok(NULL, "/\n");
     if (token == NULL) return count;
   }
   
   return count;
 }
 
 int main(int argc, char *argv[]) {  
   if ((argc < 2) || (argc > 3)) {
     printf("Input file required. Usage: %s filename [--verbose]\n", argv[0]);
     return 0;
   }
   if (argc == 3) {
     if (strcmp(argv[2], "--verbose") == 0) {
       verbose = true;
     } else {
       printf("Unknown option: %s\n", argv[2]);
     }
   }
   
   FILE *input;
   FILE *output;
   char  outfile[256]  = "";
   int   i, j;
   
   input = fopen(argv[1], "r");
   
   strcpy(outfile, argv[1]);
   i = (ulong)strrchr(outfile, '.') - (ulong)outfile;
   outfile[i + 1] = 'o';
   outfile[i + 2] = 'u';
   outfile[i + 3] = 't';
   output = fopen(outfile, "w");
   
   char  outdata[256]  = "";
   int   n_cases = 0;
   
   n_cases = getn(input);
   
   // case testing here
   DIRECTORY dirs[builtindirs];
   DIRECTORY todo[100];
   
   int existing_dirs;
   int desired_dirs;  
   int total_dirs;
   int operations;
   
   for (i = 0; i < n_cases; i++) {
     
     // read input
     existing_dirs = getn(input);
     desired_dirs = getn(input);
             
     // process data
     memset(dirs, 0, builtindirs * sizeof(DIRECTORY));
     memset(todo, 0, 100 * sizeof(DIRECTORY));
     total_dirs = 0;
     operations = 0;
     
     if (verbose) printf("Existing dirs:\n");
     for (j = 0; j < existing_dirs; j++) {
       fgets(dirs[j].path, 256, input);
       if (dirs[j].path[strlen(dirs[j].path) - 1] == '\n')
         dirs[j].path[strlen(dirs[j].path) - 1] = 0;
       if (verbose) printf("  '%s'\n", dirs[j].path);
     }
     if (verbose) printf("New dirs:\n");
     for (j = 0; j < desired_dirs; j++) {
       fgets(todo[j].path, 256, input);
       if (todo[j].path[strlen(todo[j].path) - 1] == '\n')
         todo[j].path[strlen(todo[j].path) - 1] = 0;
       if (verbose) printf("  '%s'\n", todo[j].path);
     }
     for (j = 0; j < desired_dirs; j++) {
       operations += operation_count(dirs, todo[j].path);
     }
 
     // write output    
     sprintf(outdata, "Case #%i: %i\n", i + 1, operations);
     fprintf(output, outdata);
     if (verbose) printf(outdata);
   }
  
   fclose(input); 
   fclose(output); 
   return 0;
 }

