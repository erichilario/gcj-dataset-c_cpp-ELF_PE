#include <stdio.h>
 
 int main(void){
 
 	unsigned k,t,tests,n,aux,r_win,b_win,r,b;
 	int i,j,i_aux,j_aux;
 	char matriz[70][70],matriz2[70][70];
 
 	scanf("%u",&tests);
 	for(t=1;t<=tests;t++){
 		scanf("%u %u",&n,&k);
 
 		for(i=0;i<n;i++)
 			for(j=0;j<n;j++)
 				matriz2[i][j]='.';
 
 		for(i=0;i<n;i++)
 		{
 			scanf("%s",matriz+i);
 		}
 
 		//Gravidade
 		for(i=0;i<n;i++)
 		{
 			aux=n-1;
 			
 			for(j=n-1;j>=0;j--)
 			{						
 				if(matriz[i][j]!='.'){
 					matriz2[i][aux]=matriz[i][j];
 					aux--;
 				}
 			}
 		}
 
 		r_win=0;
 		b_win=0;
 
 		for(i=0;i<n;i++)
 		{
 			r=0;
 			b=0;
 			for(j=0;j<n;j++)
 			{	
 				switch(matriz2[i][j]){
 					case 'R':
 							r++;
 							b=0;
 							break;
 					case 'B':
 							b++;
 							r=0;
 							break;
 					default:					
 							r=0;
 							b=0;
 				}
 				if(r>=k) r_win=1;
 				if(b>=k) b_win=1;
 			}
 			
 		}
 
 
 		for(j=0;j<n;j++)
 		{
 			r=0;
 			b=0;
 			for(i=0;i<n;i++)
 			{
 				switch(matriz2[i][j]){
 					case 'R':
 							r++;
 							b=0;
 							break;
 					case 'B':
 							b++;
 							r=0;
 							break;
 					default:					
 							r=0;
 							b=0;
 				}
 				if(r>=k) r_win=1;
 				if(b>=k) b_win=1;
 			}
 			
 		}
 
 		for(i=n-1,j=0;;)
 		{
 			r=0;
 			b=0;
 //			printf("i=%d,j=%d\n",i,j);
 		
 			for(i_aux=i,j_aux=j; (i_aux<n && j_aux<n);i_aux++,j_aux++)
 			{
 
 //				printf("r=%u,b=%u\n",r,b);
 
 				switch(matriz2[i_aux][j_aux]){
 						case 'R':
 								r++;
 								b=0;
 								break;
 						case 'B':
 								b++;
 								r=0;
 								break;
 						default:					
 								r=0;
 								b=0;
 					}
 					if(r>=k) r_win=1;
 					if(b>=k) b_win=1;
 
 
 //					printf("i_aux=%d,j_aux=%d, r=%u,b=%u\n",i_aux,j_aux,r,b);
 
 
 			}
 		
 				
 			if(i==0 && j==n-1)
 				break;
 			
 			if(i!=0)
 				i--;
 			else
 				j++;
 						
 		}
 		
 		for(i=n-1,j=n-1;;)
 		{	
 				r=0;
 				b=0;
 		
 			for(i_aux=i,j_aux=j; (i_aux<n && j_aux>=0);i_aux++,j_aux--)
 			{
 				
 						switch(matriz2[i_aux][j_aux]){
 						case 'R':
 								r++;
 								b=0;
 								break;
 						case 'B':
 								b++;
 								r=0;
 								break;
 						default:					
 								r=0;
 								b=0;
 					}
 					if(r>=k) r_win=1;
 					if(b>=k) b_win=1;
 			}
 			
 			if(i!=0)
 				i--;
 			else
 				j--;
 				
 			if(i==0 && j==0)
 				break;				
 		}
 
 		printf("Case #%u: ",t);
 		if(r_win && b_win)	printf("Both");
 			else if(r_win && !b_win) printf("Red");
 				else if(!r_win && b_win) printf("Blue");
 					else if(!r_win && !b_win) printf("Neither");
 		printf("\n");
 			}	
 	return 0;
 }
