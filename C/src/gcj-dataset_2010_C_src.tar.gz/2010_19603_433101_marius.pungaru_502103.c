#include <assert.h>
 #include <stdio.h>
 
 int main(int argc, char **argv) {
   int tests, tno;
 
   assert(argc >= 3);
 
   freopen(argv[1], "r", stdin);
   freopen(argv[2], "w", stdout);
 
   scanf("%d", &tests);
 
   for (tno = 1; tno <= tests; ++tno)  {
       long long n, k, pow;
 
       scanf("%lld%lld", &n, &k);
       pow = 1ll << n;
       k %= pow;
       printf("Case #%d: %s\n", tno, ((k + 1) == pow) ? "ON" : "OFF");
   }
 
   return 0;
 }

