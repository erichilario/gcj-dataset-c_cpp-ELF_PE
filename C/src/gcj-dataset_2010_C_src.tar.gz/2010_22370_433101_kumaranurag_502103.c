#include<stdio.h>
 #include<math.h>
 
 
 int main()
 {
   int T,N,K;
   int i,j,k,c=0;
   int onoff[35],power[35];
   int NN[35],flag;
   FILE *p=fopen("a.txt","w");
 
   scanf("%d",&T);
   for(i=1;i<=10;i++)
    NN[i]=((int)pow(2,i)-1);
   while(T--){
     scanf("%d%d",&N,&K);
     //printf("%d",NN[30]);
     flag=0;
     if(N==1){
         if(K==0) flag=0;
         else if(K%2!=0) flag=1;
         else flag=0;
         }
     else{
           if(K==0) flag=0;
           else if(K==NN[N]) flag=1;
           else if(K<NN[N]) flag=0;
           else if(K>NN[N]){
              k=K+1;
              j=k%(NN[N]+1);
             //printf("%d %d",j,k);
              if(j==0) flag=1;
              else flag=0;
              }
          }
 
 
     if(flag==1) fprintf(p,"Case #%d: ON\n",++c);
     else fprintf(p,"Case #%d: OFF\n",++c);
    }
    fclose(p);
 return 0;
 }

