#include<stdio.h>
 
 int main()
 {
    long int R, k, T, N, g, gr[1000];
    int i, j, q_pos, tk, dollars, tdollars, gr_sum=0;
    
    FILE *p = fopen( "C-small-attempt1.in", "r");
    fscanf(p, "%d", &T);
    for(j=1; j<=T;++j){
     dollars=0;        
     fscanf(p, "%d", &R);
     fscanf(p, "%d", &tk);
     fscanf(p, "%d", &g);
     gr_sum=0;
     for(i=0;i<g;++i){ 
      fscanf(p, "%d", &gr[i]);
      gr_sum+=gr[i];
      }
 //    printf("R=%d tk=%d g=%d gr_sum = %d    ",R,tk,g,gr_sum);    
     k = gr_sum > tk ? tk : gr_sum;
     q_pos = tdollars=0;
     for(i=0;i<R;++i) {
      while(1){ 
       if(tdollars + gr[q_pos] > k )
        break; 
       tdollars += gr[q_pos];
       q_pos = (q_pos+1)%g;
      }
      dollars+=tdollars;
      tdollars=0;
     }                      
      
     printf( "Case #%d: %d \n",j,dollars);
    } 
     return 0;
 }
 
       

