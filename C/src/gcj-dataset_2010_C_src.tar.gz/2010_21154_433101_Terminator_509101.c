#include<stdio.h>
 
 int main()
 {
   int t, n, i, j, x ;
   unsigned long  r, k, a[1000] , l, diff;
   double sum;
   
   scanf("%d",&t);
 	  
 	  for(i = 0; i < t ; i++)
 	  {  
 		 scanf("%ld %ld %d", &r, &k, &n);
 		 for(j = 0; j < n; j++)
 		   scanf("%ld ", &a[j]) ;
 		 
 		 printf("Case #%d: ",i+1);
 		 
 		 sum = 0 ;
 		 j = 0 ;		 		 
 		 for(l = 0; l < r; l++)
 		 {
 		   diff = k ;
 		   for( x = 0 ; x < n ; ((j<n-1)? j++ : (j=0)), x++ )
 		   {
 		     
 		     if( diff >= a[j] )
 		     {
 			  sum += a[j] ;
 			  diff -= a[j] ;
 		     }
 		     else
 		       break ;		     
 		   }
 		 }
 		 
 		 printf("%.0lf\n", sum) ;
 	  }
 	  
   return 0 ;
 }
