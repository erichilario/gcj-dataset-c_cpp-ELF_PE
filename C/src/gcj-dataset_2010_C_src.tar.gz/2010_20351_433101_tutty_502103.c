#include<stdio.h>
 #define infile "snapper.in"
 #define outfile "snapper.out"
 
 int main()
 {
 	int i,t,n,k;
 	freopen(infile,"r",stdin);
 	freopen(outfile,"w",stdout);
 
 	scanf("%d\n",&t);
 	for(i=1;i<=t;i++)
 	{
 		scanf("%d %d\n",&n,&k);
 		printf("Case #%d: ",i);
 		if(k==((1<<n)-1) + (1<<n)*(k/(1<<n))) printf("ON\n");
 		else printf("OFF\n");
 	}
 
 	fclose(stdin);
 	fclose(stdout);
 	return 0;
 }

