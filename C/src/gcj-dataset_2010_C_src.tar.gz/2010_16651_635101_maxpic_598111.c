#include <stdio.h>
 
 double	a[500];
 
 int main()
 {
 long i;
 long	T,n;
 char	riga[1024];
 
 FILE	*flin, *flout;
 
 flin = fopen("in.txt", "r");
 flout= fopen("out.txt", "w");
 
 a[0]=1; a[1]=2;
 for (i=2; i < 25; i++)
 	{
 	a[i] = a[i-1] + i-1;
 	printf("n[%ld]=%.0f\n", i+2, a[i]);
 	}
 
 fgets(riga, sizeof(riga), flin);
 T=atol(riga);
 printf ("%ld cases\n", T);
 
 for (i=0; i < T; i++)
 	{
 	fgets(riga, sizeof(riga), flin);
 	n = atol(riga);
 	printf("%ld->%ld==>%.0f\n", i+1, n, a[n-2]);
 	fprintf(flout, "Case #%ld: %.0f\n", i+1, a[n-2]);
 	}
 
 fclose(flout);
 fclose(flin);
 }

