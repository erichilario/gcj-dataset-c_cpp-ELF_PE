#include<stdio.h>
 #include<string.h>
 
 int main()
 {
     freopen("00B.in","r",stdin);
     freopen("00B.out","w",stdout);
 
     int c,n,ans,gongyue;
     int t[4],p[4];
     int iii,i,j,k;
     int temp,flag;
     scanf("%d",&c);
     for (iii=1;iii<=c;iii++)
     {
         scanf("%d",&n);
         for (i=1;i<=n;i++) scanf("%d",&t[i]);
         if (n==2 && t[1]==t[2]) printf("Case #%d: 0\n",iii);    
         else if (n==3 && t[1]==t[2] && t[2]==t[3]) printf("Case #%d: 0\n",iii);
         else
         {
         for (i=1;i<=n-1;i++)
             for (j=i+1;j<=n;j++)
                 if (t[i]>t[j])
                 {
                     temp=t[i];
                     t[i]=t[j];
                     t[j]=temp;
                 }
         if (n==3 && t[1]==t[2])
         {
             n=2;
             t[2]=t[3];
         }
         for (i=1;i<=n;i++) p[i]=t[i]-t[1]; 
         for (i=p[2];i>=1;i--)
         {
             flag=1;
             for (j=2;j<=n;j++)
                 if (p[j] % i != 0)
                 {
                     flag=0;
                     break;
                 }
             if (flag)
             {
                 gongyue=i; 
                 break;
             }
         }
 //        printf("gongyue=%d\n",gongyue);
         ans=gongyue;
         while (ans<t[1]) ans=ans+gongyue;
         ans=ans-t[1];
 
         printf("Case #%d: %d\n",iii,ans);
         }
     }
     return 0;
 }               

