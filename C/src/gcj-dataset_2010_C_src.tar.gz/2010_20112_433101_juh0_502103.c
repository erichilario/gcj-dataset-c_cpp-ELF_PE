#include <stdio.h>
 #include <math.h>
 
 
 main()
 {
     FILE *saida, *entrada;
 
     saida = fopen("texto.txt", "w");
     entrada = fopen ("A-small.txt", "r");
 
     int T, N, K, i, aux, aux2;
 
     fscanf(entrada, "%d", &T);
 
     for (i=0; i<T; i++)
     {
        // fflush(stdin);
         fscanf(entrada,"%d", &N);
         fscanf(entrada, "%d", &K);
 
         aux2 = pow (2, N);
         aux = K % aux2;
 
 
 
         if (aux == aux2-1 && K!=0)
         fprintf(saida, "Case #%d: ON\n", i+1);
         else
         fprintf(saida, "Case #%d: OFF\n", i+1);
 
 
     }
 
 
         fclose(entrada);
         fclose(saida);
 
     return 0;
 }

