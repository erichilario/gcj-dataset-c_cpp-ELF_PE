#include <stdio.h>
 #include <string.h>
 #include <errno.h>
 #include <math.h>
 
 #define IN_FILE	"A-large.in"
 #define OU_FILE	"A-large.ou"
 //#define NULL 	0
 #define FREE(x) if(x) {free(x); x=NULL;}
 #define BUFSZ	64
 
 int main(){
 
         FILE *pinf, *pouf;
         char buf[BUFSZ];
 	int i;
 	int T;	//cases
 	int N;	//devices 1 <= N <= 30
 	unsigned long K;	// snaps 0 <= K <= 10E8
 	unsigned long pown;
 
         pinf = fopen(IN_FILE, "r");
         pouf = fopen(OU_FILE, "w");
         if(pinf && pouf){
 
                 fgets(buf, BUFSZ, pinf);
                 sscanf(buf, "%d", &T);
 
                 for(i = 1; i <= T; i++){
 	                fgets(buf, BUFSZ, pinf);
         	        sscanf(buf, "%d %lu", &N, &K);
 /////////////////////////////////////////////// the real thing...
 			pown = (unsigned long) pow((double)2, (double)N);
 
 			//printf("Case %d/%d\nN devices: %d\nK snaps: %lu\npower: %lu\n\n", i, T, N, K, pown);
 
 			if((K+1)%pown == 0){
 				sprintf(buf, "Case #%d: ON\n", i);
 			} else {
 				sprintf(buf, "Case #%d: OFF\n", i);
 			}
 			fputs(buf, pouf);
 ///////////////////////////////////////////////
 		}	// T cases
 		fclose(pinf);
 		fclose(pouf);
         } else printf("Error leyendo archivo: %s\n", strerror(errno));
 
         return 1;
 }
 

