#include<stdio.h>
 void main()
 {
 	int i,j,k,n,t,cake[100],tot=0,op=0,max=0,tt=0,temp;
 	FILE *fp;
 	fp=fopen("input.txt","r");
 	fscanf(fp,"%d",&t);
 	for(i=0;i<t;i++)
 	{	max=0;
 		fscanf(fp,"%d",&n);
 		for(j=0;j<n;j++)
 		{	tt=0;
 			fscanf(fp,"%d",&cake[j]);
 			temp=cake[j];
 			while(temp!=0)
 			{
 				if(temp%2==0){	temp/=2;	tt++;	}
 				else{	temp--;	tt++;}
 			}
 			if(tt>max)	max=tt;
 		}
 		printf("Case #%d: %d\n",i+1,max);
 	}
 }
