#include <stdio.h>
 #include <stdlib.h>
 
 #define forn(i, n) for(i=0; i<n; i++)
 #define forj(i, j, n) for(i=j; i<n; i++)
 
 int foo(char *s, int n) {
 	int a[n], i, j, sum, count = 0;
        	
 	forn(i, n) a[i] = s[i] - 48;
 	
 	forn(i, n-1) {
 		sum = 0;
 		forn(j, i+1) sum += a[j];
 
 		if(sum < i+1) {
 			count++;
 			a[i]++;
 		}
 	}
 
 	return count;
 }
 
 int main() {
 	int T, n, i;
 	scanf("%d", &T);
 	forn(i, T) {
 		scanf("%d", &n);
 		char s[n];
 		scanf("%s", s);
 		printf("Case #%d: %d\n", i+1, foo(s, n+1));
 	}
 	return 0;
 }

