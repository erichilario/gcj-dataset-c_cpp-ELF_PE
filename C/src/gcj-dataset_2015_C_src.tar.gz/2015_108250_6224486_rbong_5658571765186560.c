#include <stdio.h>
 int main (int argc, const char **argv)
 {
     FILE *fp = fopen (argv [1], "r");
     int t, x, r, c;
     int i;
     fscanf (fp, "%d", &t);
     for (i = 0; i < t; i++)
     {
         fscanf (fp, "%d %d %d", &x, &r, &c);
         if (x != 1 && (x >= 7 || r * c % x != 0 || r * c <= x || (r < x && c < x)))
             printf ("Case #%d: RICHARD\n", i + 1);
         else
             printf ("Case #%d: GABRIEL\n", i + 1);
     }
     return 0;
 }

