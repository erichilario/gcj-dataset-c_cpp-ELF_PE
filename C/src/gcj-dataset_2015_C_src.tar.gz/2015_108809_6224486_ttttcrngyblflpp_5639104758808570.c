#include<stdio.h>
 int S;
 int A[1001];
 int main2(void){
 	int co=0;
 	int res=0;
 	int i;
 	for(i=0;i!=S+1;++i){
 		if(co>=i){
 			co+=A[i];
 		}else{
 			if(A[i]==0)continue;
 			res+=i-co;
 			co=i;
 			co+=A[i];
 		}
 	}
 	return res;
 }
 int main(void){
 	FILE *fin=fopen("a.in","r");
 	FILE *fout=fopen("a.soln","w");
 	int T;
 	int i;
 	int j;
 	char c;
 	fscanf(fin,"%d",&T);
 	for(i=0;i!=T;++i){
 		fscanf(fin,"%d",&S);
 		fgetc(fin);
 		for(j=0;j!=S+1;++j)
 			fscanf(fin,"%c",&c),A[j]=c-'0';
 		fprintf(fout,"Case #%d: %d\n",i+1,main2());
 	}
 	fclose(fin);
 	fclose(fout);
 	return 0;
 }

