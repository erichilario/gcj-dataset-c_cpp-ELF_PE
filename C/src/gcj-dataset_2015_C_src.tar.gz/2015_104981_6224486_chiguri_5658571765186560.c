#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 
 // for qsort
 /*
 int compare(int *t, int *s) {
     return *t - *s;
 }
 */
 
 int N;
 
 int search(int X, int R, int C) {
     int i;
     if(R * C % X != 0) return 0; // of course we can't!
     if(X >= 7) return 0; // Rechard can choose X-omino with a hole! we never fill the hole!
     for(i = 1; i <= X; ++i) {
         if((X-i+1 > R || i > C) && (X-i+1 > C || i > R)) return 0; // stick or something like 'L' or 'T' cannot be put.
     }
     if(X == 4 && (R == 2 || C == 2)) return 0; // T can be put but we can't fill the rest.
     // X == 5 may not be difficult...
     if(X == 6 && (R == 3 || C == 3)) return 0; // + can be put but we can't fill the rest.
 
     return 1; // otherwise GABRIEL wins
 }
 
 
 int main(void) {
     int dataset_num, case_num;
     int X, R, C;
 
     scanf("%d", &dataset_num);
     for(case_num = 1; case_num <= dataset_num; ++case_num) {
 
         scanf("%d %d %d", &X, &R, &C);
 
         printf("Case #%d: ", case_num);
         if(search(X, R, C)) {
             printf("GABRIEL\n");
         }
         else {
             printf("RICHARD\n");
         }
     }
 
     return 0;
 }

