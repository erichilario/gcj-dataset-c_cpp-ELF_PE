
 main()
 {
     int t;
     scanf("%d",&t);
     int nnn=t,res[t];
     while(nnn)
     {
     int lml=0;
     int m,n;
     scanf("%d %d",&m,&n);
     char b[m+1];
     scanf("%s",b);
     char a[(m*n)+1];
     strcpy(a,b);
     while(n-1)
     {
         strcat(a,b);
 
         n--;
     }
     int len=strlen(a);
     char c=a[0],sn=0;
     int i=0;
     int rnt=0;
     for(i=1;i<len;i++)
     {
 
         if(c=='j'&&a[i]=='k'&&sn==0){rnt++;c='i';sn=0;}
         else if(c=='j'&&a[i]=='k'&&sn==-1){rnt++;c='k';sn=-1;}
         else if(c=='j'&&a[i]=='i'&&sn==0){rnt++;c='k';sn=-1;}
         else if(c=='j'&&a[i]=='i'&&sn==-1){rnt++;c='k';sn=0;}
         else if(c=='k'&&a[i]=='i'&&sn==0){rnt++;c='j';sn=0;}
         else if(c=='k'&&a[i]=='i'&&sn==-1){rnt++;c='k';sn=-1;}
         else if(c=='k'&&a[i]=='j'&&sn==-1){rnt++;c='i';sn=0;}
         else if(c=='k'&&a[i]=='j'&&sn==0){rnt++;c='i';sn=-1;}
         else if(c==a[i]&&sn==0){rnt++;c='1';sn=-1;}
         else if(c==a[i]&&sn==-1){rnt++;c='1';sn=0;}
         else if(c=='1'&&sn==0){rnt++;c=a[i];sn=0;}
         else if(c=='1'&&sn==-1){rnt++;c=a[i];sn=-1;}
         else if(c=='i'&&a[i]=='k'&&sn==-1){rnt++;c='j';sn=0;}
 
 else if(c=='i'&&a[i]=='j'&&sn==-1){rnt++;c='k';sn=-1;}
 
     if(c==105&&sn==0){lml++;break;}
     }
 
     int p1=i+1;
     if(rnt==0)p1--;
     c=a[p1],sn=0,rnt=0;
             for(i=p1+1;i<len;i++)
     {
 
         if(c=='i'&&a[i]=='k'&&sn==0){rnt++;c='j';sn=-1;}
         else if(c=='i'&&a[i]=='k'&&sn==-1){rnt++;c='j';sn=0;}
         else if(c=='i'&&a[i]=='j'&&sn==0){rnt++;c='k';sn=0;}
         else if(c=='i'&&a[i]=='j'&&sn==-1){rnt++;c='k';sn=-1;}
         else if(c=='k'&&a[i]=='i'&&sn==0){rnt++;c='j';sn=0;}
         else if(c=='k'&&a[i]=='i'&&sn==-1){rnt++;c='j';sn=-1;}
         else if(c=='k'&&a[i]=='j'&&sn==-1){rnt++;c='i';sn=0;}
         else if(c=='k'&&a[i]=='j'&&sn==0){rnt++;c='i';sn=-1;}
         else if(c==a[i]&&sn==0){rnt++;c='1';sn=-1;}
         else if(c==a[i]&&sn==-1){rnt++;c='1';sn=0;}
         else if(c=='1'&&sn==0){rnt++;c=a[i];sn=0;}
         else if(c=='1'&&sn==-1){rnt++;c=a[i];sn=-1;}
 
         else if(c=='j'&&a[i]=='i'&&sn==-1){rnt++;c='k';sn=0;}
         else if(c=='j'&&a[i]=='k'&&sn==-1){rnt++;c='i';sn=-1;}
 
 
 
     if(c==106&&sn==0){lml++;break;}
     }
 
     int p2=i+1;
 if(rnt==0)p2--;
 c=a[p2],sn=0;
 
 if(p2==len-1&&c=='k')lml++;
     for(i=p2+1;i<len;i++)
     {
 
         if(c=='i'&&a[i]=='k'&&sn==0){rnt++;c='j';sn=-1;}
         else if(c=='i'&&a[i]=='k'&&sn==-1){rnt++;c='j';sn=0;}
         else if(c=='i'&&a[i]=='j'&&sn==0){rnt++;c='k';sn=0;}
         else if(c=='i'&&a[i]=='j'&&sn==-1){rnt++;c='k';sn=-1;}
         else if(c=='j'&&a[i]=='i'&&sn==0){rnt++;c='k';sn=-1;}
         else if(c=='j'&&a[i]=='i'&&sn==-1){rnt++;c='k';sn=0;}
 
         else if(c=='k'&&a[i]=='i'&&sn==-1){rnt++;c='j';sn=-1;}
         else if(c=='k'&&a[i]=='j'&&sn==-1){rnt++;c='i';sn=0;}
 
 
         else if(c=='j'&&a[i]=='k'&&sn==-1){rnt++;c='i';sn=-1;}
         else if(c=='j'&&a[i]=='k'&&sn==0){rnt++;c='i';sn=0;}
         else if(c==a[i]&&sn==0){rnt++;c='1';sn=-1;}
         else if(c==a[i]&&sn==-1){rnt++;c='1';sn=0;}
         else if(c=='1'&&sn==0){rnt++;c=a[i];sn=0;}
         else if(c=='1'&&sn==-1){rnt++;c=a[i];sn=-1;}
   if(c==107&&sn==0){lml++;break;}
     }
     if(lml==3)res[t-nnn]=1;
     else res[t-nnn]=0;
     nnn--;
     }
     for(nnn=0;nnn<t;nnn++)
     {
         printf("Case #%d: ",nnn+1);
         if(res[nnn])printf("YES\n");
         else printf("NO\n");
     }
 }

