#include <stdio.h>
 #include<string.h>
 
 int main() {
   int T;
   scanf("%d",&T);
   int cases = 0;
   while(T--){
     int n;
     scanf("%d",&n);
     char s[10000];
     char dummy;
     dummy = getchar();
     //printf("%d\n",n);
     gets(s);
     //printf("%s\n",s);
     int sum = 0;
     int ans = 0;
     int i = 0;
     for(i = 0; s[i];i++){
       if(sum<i){
         ans = ans + (i-sum);
         sum = i + s[i] -'0';
       }
       else{
         sum = sum + s[i] - '0' ;
       }
     }
       printf("Case #%d: %d\n",++cases,ans);
       
     
     
   }
   
   return 0;
 }

