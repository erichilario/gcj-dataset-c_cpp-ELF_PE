#include <stdio.h>
 
 int main()
 {
     FILE *fi;
     FILE *fout;
 
     fi = fopen("in","r");
     fout = fopen("out","w");
 
     int t,i,j,smax,ps,p,c;        //ps = Persons standing,smax = max shyness level, = persons to be taken
 
     fscanf (fi, "%i", &t);
 
     for(i=0;i<t;i++)
     {ps=p=0;
 
         fscanf (fi, "%i", &smax);
 
         c = getc(fi);
 
         for(j=0;j<=smax;j++)
         {
             c = getc(fi)-48;
 
 
             if(c==0)
             { continue;}
             if(ps>=j)
             {   ps=ps+c;  }
             else
             {   p=p+j-ps;   ps=j+c;    }
 
         }
 
         fprintf (fout, "Case #%i: %i\n",i+1,p);
     }
 
     fclose(fi);
     fclose(fout);
 
     return 0;
 }

