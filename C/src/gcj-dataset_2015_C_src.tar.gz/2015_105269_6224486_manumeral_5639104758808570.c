#include <stdio.h>
 int main(void)
 {
 	long long int n,c,test,k = 1,i,j,rec,a[10000];
 	char s[10001];
 	scanf("%lld",&test);
 	while(test--)
 	{
 		scanf("%lld",&n);
 		scanf("%s",s);
 		c = 0 ;
 		a[i] = 0;
 		rec = 0 ;
 		for(i = 1 ; i <= n+1 ; i++)
 		{
 			if( ( i - 1 ) <= c )
 			{
 				c += (s[i-1]-'0') ;
 			}
 			else
 			{
 				rec += (i-1-c);
 				c += (s[i-1] - '0' + (i-1-c)) ;
 			}
 		}
 		printf("Case #%lld: %lld\n",k,rec);
 		k++;
 	}
 	return 0;
 }
