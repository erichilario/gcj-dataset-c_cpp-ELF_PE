#include <stdio.h>
 
 int T, t, i, sol, s, p, chk;
 char car[1000];
 int arr[1001];
 int main()
 {
 	scanf( "%d", &T );
 	for( t = 1; t <= T; t++ )
 	{
 		scanf( "%d", &s );
 		fscanf( stdin, "%s", &car );
 		
 		for(i=0; i<=s ; i++)
 		{
 			arr[i] = (int) car[i] - 48;
 			
 		}
 
 		sol=0;
 		chk=0;
 		i=0;
 		while(i<=s)
 		{
 			p= arr[i++];
 			chk = chk +p;
 			if(chk==0)
 				sol++;
 			else
 				chk--;
 		}
 
 		printf( "Case #%d: %d\n", t, sol );
 	}
 	return 0;
 }

