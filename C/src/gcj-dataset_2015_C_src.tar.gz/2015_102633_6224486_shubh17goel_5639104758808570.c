#include<stdio.h>
 //#include<iostream>
 //#include<string>
 //using namespace std;
 int main()
 {
     int t,i,j;
     int s,person=0,needed=0;
     char str[1005];    
     FILE *fp1=fopen("input.txt","r");
     FILE *fp2=fopen("output.txt","wb");
     fscanf(fp1,"%d\n",&t);
     for(i=1;i<=t;i++)
     {
         person=0;
         needed=0;
         fscanf(fp1,"%d ",&s);
         fscanf(fp1,"%s\n",str);
         person=(str[0]-'0');
         for(j=1;j<strlen(str);j++)
         {
             if(person>=j)
             person+=(str[j]-'0');
             else
             {
                 needed++;
                 person++;
                 //cout<<" "<<j<<" ";
                 person+=(str[j]-'0');
             }
         }
         fprintf(fp2,"Case #%d: %d\n",i,needed);
     }
     fclose(fp2);
     fclose(fp1);
     return 0;
 }

