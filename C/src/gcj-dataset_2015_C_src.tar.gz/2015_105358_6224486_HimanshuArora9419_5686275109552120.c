#include<stdio.h>
 int main()
 {
  long int t,da[1000],d,di,ti,dt,ma,mb,fb,fa,ans,anst,f;
  scanf("%ld",&t);
  for(ti=0;ti<t;ti++)
  { anst=0; f=0;
      scanf("%ld",&d);
      for(di=0;di<1000;di++){da[di]=0;}
      for(di=0;di<d;di++)
      {
          scanf("%ld",&dt);
          da[dt]++;
      }
      fb=fa=da[0]; ma=mb=0;
      for(di=0;di<1000;di++)
      {
          if(da[di]>0){if(di>ma){ ma=di; fa=da[di];}}
     ans=ma; }
     do { { anst=ma+f;f+=fa; da[ma]=0;da[ma/2]+=fa;
     da[ma-ma/2]+=fa;  ans=ans<=anst?ans:anst; }
 fa=da[0]; ma=0;
       for(di=0;di<1000;di++)
      {
          if(da[di]>0){if(di>ma){ ma=di; fa=da[di];}}
      }
 
      }while(ma>1);
 printf("Case #%ld: %ld\n",ti+1,ans);
  }
 return 0;
 }

