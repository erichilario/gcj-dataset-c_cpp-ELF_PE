#include <stdio.h>
 #include <stdlib.h>
 #include <ctype.h>
 #include <string.h>
 
 void do_test(int t)
 {
 	int d;
 	int p[1001] = { 0 };
 	int highest_stack = 0;
 	int timestep = 0;
 	int splits = 0;
 	int i;
 
 	scanf(" %d", &d);
 
 	for (i = 0; i < d; i++)
 	{
 		int p_i;
 	
 		scanf(" %d", &p_i);
 		p[p_i]++;
 
 		if (p_i > highest_stack)
 			highest_stack = p_i;
 	}
 
 /*	printf("highest_stack = %d\n", highest_stack);*/
 
 	while (timestep < highest_stack)
 	{
 		int half = (highest_stack - timestep + 1) / 2;
 		int half_rounddown = (highest_stack - timestep) / 2;
 		int count = 0;
 
 		for (i = half + timestep + 1; i <= highest_stack; i++)
 			count += p[i];
 	
 		if (half > 1 && count < half_rounddown)
 		{
 /*			printf("Splitting %d stacks of height %d\n", p[highest_stack], highest_stack - timestep);*/
 			/* SPLIT */
 			splits += p[highest_stack];
 			p[half + timestep] += p[highest_stack];
 			p[half_rounddown + timestep] += p[highest_stack];
 			p[highest_stack] = 0;
 			while (p[highest_stack] == 0)
 				highest_stack--;
 		}
 		else
 		{
 /*			printf("Eat!\n");*/
 			timestep++;
 		}
 	}	
 
 	printf("Case #%d: %d\n", t + 1, timestep + splits);
 }
 
 int main()
 {
 	int t, i;
 
 	scanf("%d", &t);
 	
 	for (i = 0; i < t; i++)
 		do_test(i);
 
 	return 0;
 }

