#include<stdio.h>
 int main()
 {
 	long long int t,i,a,b,c,p;
 	scanf("%lld",&t);
 	for(i=1;i<=t;i++)
 	{
 		scanf("%lld%lld%lld",&a,&b,&c);
 		p=b*c;
 		if(a==1)
 		{
 			printf("Case #%lld: GABRIEL\n",i);
 		}
 		else if(a==2)
 		{
 			if(p%a==0)
 			{
 				printf("Case #%lld: GABRIEL\n",i);					}
 			else
 			{
 				printf("Case #%lld: RICHARD\n",i);
 			}
 		}
 		else if(a==3)
                 {
                         if(p%a==0)
                         {
                                 if(b==1||c==1)
                                 {
                                         printf("Case #%lld: RICHARD\n",i);
                                 }
                                 else
                                 {
                                         printf("Case #%lld: GABRIEL\n",i);
                                 }
                         }
                         else
                         {
                                 printf("Case #%lld: RICHARD\n",i);
                         }
                 }
 
 		else
 		{
 			if(p%a==0)
 			{
 				if(b<=2||c<=2)
 				{
 					printf("Case #%lld: RICHARD\n",i);
 				}
 				else
 				{
 					printf("Case #%lld: GABRIEL\n",i);
 				}
 			}
 			else
 			{
 				printf("Case #%lld: RICHARD\n",i);
 			}
 		}
 	}
 	return 0;
 }

