#include<stdio.h>
 char s[1001];
 int main()
 {
 	FILE *p;
 	p=fopen("A-large.in","r");
 	FILE *o;
 	o=fopen("A-large1.out","w");
 	int t,i,j,n,f,sum;
 	fscanf(p,"%d",&t);
 	for(j=1;j<=t;j++)
 	{
 		f=0;
 		sum=0;
 		fscanf(p,"%d",&n);
 		fscanf(p,"%s",s);
 		for(i=0;i<=n;i++)
 		{
 				if(sum<i){
 				f=f+i-sum;
 				sum=i;
 			}
 			sum+=(s[i]-48);
 		}
 		fprintf(o,"Case #%d: %d\n",j,f);
 		
 	}
 }

