#include<stdio.h>
 int main() {
     int t, cases = 1;
     scanf("%d", &t);
     while(t--) {
         int cs = 0, ex = 0, smax;
         char ch[2000];
         scanf("%d%s", &smax, ch);
         int i;
         for(i = 0; ch[i]; i++) {
             ch[i] -= '0';
         }
         cs = ch[0];
         for(i = 1; i <= smax; i++) {
             if(ch[i] == 0)
                 continue;
             if(cs >= i) {
                 cs += ch[i];
             } else {
                 ex += i - cs;
                 cs += i - cs + ch[i];
             }
         }
         printf("Case #%d: %d\n", cases++, ex);
     }
 }

