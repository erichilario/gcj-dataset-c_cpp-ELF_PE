#include <stdio.h>
 #include <errno.h>
 
 int main()
 {
     int numberOfTestCases = 0;
     errno = 0; 
     FILE *ifp = fopen("B-small-attempt2.in", "r");
     FILE *ofp = fopen("B-small-attempt2.out", "w");
     int n = fscanf(ifp, "%d", &numberOfTestCases);
 
     if (n == 1) {
         if (numberOfTestCases >= 1 && numberOfTestCases <= 100){
             for (int caseNumber = 1; caseNumber <= numberOfTestCases; caseNumber++) {
                 int minutes = 0;
                 int nonEmptyPlates = 0;
                 n = fscanf(ifp, "%d", &nonEmptyPlates);
                 int diners = nonEmptyPlates;
                 int *pancakes;
                 for(int i = 0; i < nonEmptyPlates; i++){
                     n = fscanf(ifp, "%d", &pancakes[i]);
                 }
 
                 while(pancakes[0] > 0 && nonEmptyPlates > 0) {
                     int special = 0;
                     for (int i = 0; i < nonEmptyPlates; i++){ 
                         if (pancakes[i] > 3){
                             special = 1;
                             nonEmptyPlates++; //add a new plate
                             pancakes[nonEmptyPlates - 1] = pancakes[i] / 2;
                             pancakes[i] -= (pancakes[i] / 2);
                         } 
                     }
 
                     if (special)
                         minutes++;
                     else{
                         for (int i = 0; i < nonEmptyPlates; i++)
                             pancakes[i]--;
                         minutes++;
                     }
 
                     for (int i = 0; i < nonEmptyPlates; i++){
                         if (pancakes[i] == 0){ 
                             for (int j = i; j < nonEmptyPlates ; j++){
                                 pancakes[j] = pancakes[j + 1];
                                 pancakes[j + 1] = 0;
                             }
                             nonEmptyPlates--; //remove a plate
                         }
                     }
 
                     for (int i = 0; i < nonEmptyPlates; i++)
                         printf("%d ", pancakes[i]);
                     printf("\n");
                 }
 
                 fprintf(ofp, "Case #%d: %d\n", caseNumber, minutes);
                 printf("Case #%d: %d\n", caseNumber, minutes);
             }
         }
     } 
     
     fclose(ofp);
     fclose(ifp);
 
     return 0;
 }

