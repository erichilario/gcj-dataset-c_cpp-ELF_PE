#include <iostream>
 #include<vector>
 #include<iterator>
 #include<math.h>
 using namespace std;
 
 int main() {
 	
 	int max=0,ini_count,new_count=0,val,t,pan_no,d,i=0,count=0,k=1,ind,j,siz;
 	vector <int> v,index_max;
 	
 	cin >> t;
 	while(t>0)
 	{
 			cin >> d;
 			v.clear();
 			index_max.clear();
 			max =0;
 			count=0;
 			j=0;
 			for(i=0;i<d;i++)
 			{
 				cin >> pan_no;
 				v.push_back(pan_no);
 			
 				if(pan_no>=max)
 				{
 				//	cout << "i "<<i<<endl;
 					max = pan_no;
 					
 				}
 			}
 			for(i=0;i<d;i++)
 			{
 				if(v.at(i)==max)
 				index_max.push_back(i);
 			}
 			count=0;
 			siz = index_max.size();
 		
 			ini_count=max;
 			new_count = max;
 			while(ini_count >= new_count)
 			{
 		//	cout << "max " <<max << " size " << siz <<endl;
 			
 				while(!(index_max.empty()))
 				{
 					ind = index_max.back();
 				//	cout << ind<<endl;
 					index_max.pop_back();
 					val = ceil(v.at(ind)/2);
 					v.at(ind) = v.at(ind)-val;
 					v.push_back(val);
 					
 				}
 				
 				max = v.at(0);
 				j=0;
 				for(i=0;i<v.size();i++)
 				{
 					if(v.at(i) >= max)
 					{
 						max = v.at(i);
 					
 					}
 				}
 				for(i=0;i<v.size();i++)
 				{
 					if(v.at(i)==max)
 						index_max.push_back(i);
 				}
 				ini_count = new_count;
 				count = count + siz;
 				siz = index_max.size();
 				new_count=max+count;
 				
 			
 			}
 		if(new_count <ini_count)	
 		cout << "Case #"<< k <<": "<<new_count<<endl;
 		else
 			cout << "Case #"<< k <<": "<<ini_count<<endl;
 		t--;
 		k++;
 	}
 	
 	return 0;
 }

