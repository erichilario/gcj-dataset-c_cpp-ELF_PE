#include <stdio.h>
 #include <string.h>
 int main()
 {
 	long long int t,i,sum=0,j=0,n,len[1001],count=0,k=0;
 	long long int max=0;
 	
 	char name[100100];
 	//scanf("%d",&t);
 	FILE *ptrIn;
 	FILE *ptrOut;
 
 
 	ptrIn = fopen("input.txt", "r");
 	ptrOut = fopen("output.txt", "w");
 	fscanf(ptrIn, "%lld", &t);
 	while(t--)
 	{ 
      	max = 0;
         sum=0;
 		j=0;
 		count+=1;
 
 		fscanf(ptrIn, "%lld %s",&n,name);
 		//sum=name[0];
 		for(i=0;i<n;i++)
         { 
             sum=sum+name[i]-48;
         	if(name[i]-48==0 && name[i+1]-48!=0)
         	{
         		//len[k]=i+1-sum;
         	    	if(max < i+1-sum)
         	    		max = i+1-sum;
         	        
         	    }
         	        
         	
         }
         
         fprintf(ptrOut, "Case #%lld: %lld\n",count,max);
 
 	}
 	fclose(ptrOut);
 	fclose(ptrIn); 
 	return 0;
 }

