#include <stdio.h>
 #include <stdlib.h>
 FILE *fin, *fout;
 int L;
 long long X;
 int l[10010];
 
 char mult[4][4];
 
 int multquaternion(int a, int b){
 	int sig = 1;
 	if(a < 0) sig = -1;
 	return sig*mult[abs(a)-1][abs(b)-1];
 }
 
 void fillTable(){
 	mult[0][0] = 1;
 	mult[0][1] = 2;
 	mult[0][2] = 3;
 	mult[0][3] = 4;
 	mult[1][0] = 2;
 	mult[1][1] = -1;
 	mult[1][2] = 3;
 	mult[1][3] = -4;
 	mult[2][0] = 3;
 	mult[2][1] = -4;
 	mult[2][2] = -1;
 	mult[2][3] = 2;
 	mult[3][0] = 4;
 	mult[3][1] = 3;
 	mult[3][2] = -2;
 	mult[3][3] = -1;
 }
 
 void solve(){
 	int i, j, k;
 	char kk;
 	int a, b, c;
 	fscanf(fin, "%d %lld", &L, &X);
 	fscanf(fin, "%c", &kk);
 	for(i=0; i<L; i++){
 		fscanf(fin, "%c", &kk);
 		if(kk=='i') l[i] = 2;
 		else if(kk=='j') l[i] = 3;
 		else l[i] = 4;
 	}
 	for(i = L; i<X*L; i++){
 		l[i] = l[i%L];
 	}
 	
 	if(L*X<3){
 		fprintf(fout, "NO\n");
 		return;
 	}
 	fillTable();
 	//323232323232
 	a = 1;
 	for(i=0; i < L*X-2; i++){
 		a = multquaternion(a, l[i]); 
 		//printf("Investigando i = %d, a = %d\n", i, a);
 		if(a == 2){
 			b=1;
 			//printf("%d\n", b);
 			for(j = i+1; j < L*X - 1; j++){
 				//printf("j:%d\n", j);
 				b = multquaternion(b, l[j]);
 				//printf("Investigando i = %d, b = %d\n", i, b);
 				//printf("%d\n", b);
 				if(b == 3){
 					//printf("2\n");
 					c = 1;
 					for(k = j+1; k < L*X; k++){
 						c = multquaternion(c, l[k]);
 					}
 					if(c == 4){
 						fprintf(fout, "YES\n");
 						return;
 					}
 					else{
 						break;
 					}
 				}
 			}
 		}
 	}
 	fprintf(fout, "NO\n");
 }
 
 int main(int argc, char *argv[]){
 	char kk;
 	int total, i;
 
 	fin=fopen(argv[1], "r");
 	fout=fopen("out", "w");
 	if (fin==NULL || fout == NULL)
 	{
 		printf("Fitxer out.\n");
 	}
 	else 
 	{
 		fscanf(fin, "%d", &total);
 		fscanf(fin, "%c", &kk);
 		for (i = 0; i<total; i++)
 		{
 			fprintf(fout, "Case #%d: ", i+1);
 			printf("Case #%d: \n", i+1);
 			solve();
 		}
 		fclose(fin);
 		fclose(fout);
 	}
 	return 0;
 }
