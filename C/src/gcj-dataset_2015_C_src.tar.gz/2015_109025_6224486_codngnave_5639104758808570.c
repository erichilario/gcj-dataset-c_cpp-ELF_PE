#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 int main()
 {
 	int test,i,j,size,index;
 	long long int sum=0,friend=0,temp;
 	int arr[2000];
 	char value[2000];
 	scanf("%d",&test);
 	for(i=1;i<=test;i++)
 	{
 		memset(arr,0,2000*4);
 		scanf("%d",&size);
 		scanf("%s",value);
 		sum =0;
 		friend = 0;
 		for(j=0;j<=size;j++)
 		{
 			arr[j] = value[j] - '0'; 	
 		}
 		for(index =0;index<=size;index++)
 		{
 			if(arr[index] > 0)
 			{
 				if(index <= sum)
 				{
 				sum = sum + arr[index];
 		//		printf(" index %d sum %lld \n",index,sum);
 				} 
 			else
 			{
 				temp = index - sum;
 				friend = friend + temp;
 				sum = sum + temp+arr[index];
 			//	printf(" index %d sum %lld \n",index,sum);
 		//		printf(" temp %lld \n",temp);
 			}
 			}
 		}
 		printf("case #%d: %lld\n",i,friend);
 
 	}
 	return 0;
 }

