#include <stdio.h>
 #include <stdlib.h>
 
 #define S_SMALL_LEN 6
 #define S_LARGE_LEN 1000
 
 int charToInt(char);
 
 int main(int argc, char **argv)
 {
 	int t, tc, i;
 	int s_max, p_stdup, donna_friend;
 	char digits[S_LARGE_LEN+1+1];
 	FILE *in, *out;
 	
 	in = fopen("A-large.in", "r");
 	out = fopen("resultA.out", "w");
 	
 	fscanf(in, "%d", &tc);
 	for(t=1; t<=tc; t++) {
 		fscanf(in, "%d %s", &s_max, digits);
 		
 		for(i=0, p_stdup=0, donna_friend=0;
 			digits[i]!='\0';
 			i++)
 		{
 			if(i > p_stdup) {
 				donna_friend += (i-p_stdup);
 				p_stdup += (i-p_stdup);
 			}
 			p_stdup += charToInt(digits[i]);
 		}
 		
 		fprintf(out, "Case #%d: %d\n", t, donna_friend);
 	}
 	
 	fclose(in);
 	fclose(out);
 	return 0;
 }
 
 int charToInt(char c)
 {
 	return (int)(c-'0');
 }
 

