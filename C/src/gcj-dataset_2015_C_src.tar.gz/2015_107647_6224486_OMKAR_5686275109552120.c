#include<stdio.h>
 int main(){
 
     int n,a[20],sum,i,div,k,count,p,t;
     scanf("%d",&t);
     for(p=0;p<t;p++){
                 scanf("%d",&n);
                 for(i=0;i<n;i++){
                     scanf("%d",&a[i]);
                 }
             count=0;
             sum=999;
         while(sum!=0){
             sum=0;
             count++;
             for(i=0;i<n;i++){
               if(a[i]>0){
                             if(a[i]%2==0 && a[i]!=2){
                                 //not eat
                                 div=a[i]/2;
                                 a[i]=div;
                                 a[n]=div;
                                 n++;
 
                             }else{
                                 //eat
                                 for(k=0;k<n;k++){
                                     if(a[k]>0){
                                         a[k]=a[k]-1;
                                     }
                                 }
                             }
                             break;
 
               }
 
             }
 
             for(i=0;i<n;i++){
                 sum+=a[i];
             }
         }
 
         printf("Case #%d: %d\n",p+1,count);
 
     }
 
 
 
 return 0;
 }

