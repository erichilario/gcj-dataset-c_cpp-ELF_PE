#include <stdio.h>
 int main(void) {
 
 	int t=0,i=1,total=0,smax,size,count=0,j=0,digit;
 	char s[1000];
 	scanf("%d",&t);
 	
 	while(t>0)
 	{
 		scanf("%d",&smax);
 		size = smax+1;	
 		scanf("%s",s);
 		
 		total=0;
 		count=0;
 		j=0;
 		while(j<size)
 		{
 			digit = s[j]-48;
 			if(total < j && digit > 0)
 					{
 						count = count + j-total;
 						total = total+count;
 					
 					}
 			total = total + digit;			
 			j++;
 		}
 		printf("Case #%d: %d\n",i,count);
 		t--;
 		i++;
 	}
 
 	return 0;
 }

