#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 int main(){
   int i, j, res;
   int t, x, r, c, n;
 
   scanf("%d", &t);
   for (n = 1; n <= t; n++) {
     scanf("%d %d %d", &x, &r, &c);
 
     res = 1;
 
     if((x > r && x > c) // ganha fazendo 1x*
     || (r * c % x > 0 || r*c < x)  //sobra espaco ou nem cabe
     || (r == 1 && x > 2) //caso linha
     || (c == 1 && x > 2) // caso coluna
     || x > 6
     || (x == 4 && (r == 2 || c == 2)))
       res = 0;
     //printf("%d %d %d ", x, r, c);
     if(res)
       printf("Case #%d: GABRIEL\n", n);
     else
       printf("Case #%d: RICHARD\n", n);
   }
   return 0;
 }

