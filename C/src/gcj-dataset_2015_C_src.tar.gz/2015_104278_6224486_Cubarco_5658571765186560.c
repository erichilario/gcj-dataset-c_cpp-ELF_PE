#include <stdio.h>
 
 #define max(a,b) ((a) > (b) ? (a) : (b))
 #define min(a,b) ((a) < (b) ? (a) : (b))
 
 int candivide(int d, int m)
 {
     return m == (m/d)*d;
 }
 
 int main(int argc, char **argv)
 {
     int t,x,r,c;
     int i,j,done;
     scanf("%d", &t);
     for (i=0; i<t; i++) {
         scanf("%d %d %d", &x, &r, &c);
         if (x > max(r, c)) {
             printf("Case #%d: RICHARD\n", i+1);
             continue;
         } else if (!candivide(x, r*c)) {
             printf("Case #%d: RICHARD\n", i+1);
             continue;
         } else {
             if (x >= 3 && min(r,c) <= x/2) {
                 printf("Case #%d: RICHARD\n", i+1);
                 continue;
             }
         }
         printf("Case #%d: GABRIEL\n", i+1);
     }
 
     return 0;
 }

