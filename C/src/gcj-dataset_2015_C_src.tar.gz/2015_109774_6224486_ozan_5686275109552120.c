#include <stdio.h>
 #include <stdlib.h>
 
 int helper(int N, int m)
 {
 	return (N-1)/m;
 }
 
 int solve(void)
 {
 	int D, *P, m, min, max, i, current;
 	scanf("%d", &D);
 	max = 0;
 	P = (int *) malloc(sizeof(int) * D);
 	for (i=0; i<D; i++)
 	{
 		scanf("%d", &P[i]);
 		max = max > P[i] ? max : P[i];
 		min += P[i];
 	}
 	if (max < 3)
 	{
 		free(P);
 		return max;
 	}
 	for (m=2; m<=max; m++)
 	{
 		current = m;
 		for (i=0; i<D; i++)
 			current += helper(P[i], m);
 		min = min < current ? min : current;
 	}
 	free(P);
 	return min;
 }
 
 void print(int tCount, int result)
 {
 	printf("Case #%d: %d\n", tCount, result);
 }
 
 int main(void)
 {
 	int T, i;
 	scanf("%d", &T);
 	for (i=1; i<=T; i++)
 		print(i, solve());
 	return 0;
 }
