#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     long int t,n,i,count,j,sum;
     FILE *fp;
     
     fp = fopen("A-large.in","r");
     
     fscanf(fp,"%ld",&t);
     char a[10001];
     long int s[10001];
     j=1;
     while(j<=t)
     {
         fscanf(fp,"%ld %s",&n,a);
 
 
         if(n==0 )
         {
             if(a[0]=='0')
             {
                 printf("Case #%ld: 1\n",j);
             }
             else
             {
                 printf("Case #%ld: 0\n",j);
             }
            j++;
            continue;
         }
         
         
         i=0;
         while(i<=n)
         {
             if(a[i]=='0')
             {
                 s[i]=0;
             }
             else
             if(a[i]=='1')
             {
                 s[i]=1;
             }
             else
             if(a[i]=='2')
             {
                 s[i]=2;
             }
             else
             if(a[i]=='3')
             {
                 s[i]=3;
             }
             else
             if(a[i]=='4')
             {
                 s[i]=4;
             }
             else
             if(a[i]=='5')
             {
                 s[i]=5;
             }
             else
             if(a[i]=='6')
             {
                 s[i]=6;
             }
             else
             if(a[i]=='7')
             {
                 s[i]=7;
             }
             else
             if(a[i]=='8')
             {
                 s[i]=8;
             }
             else
             {
                 s[i]=9;
             }
             i++;
         }
         
         i=1;
         count =0;
         sum =s[0];
         while(i<=n)
         {
                 if(sum<i)
                 {
                     count++;
                     sum = sum+s[i] +1;
                 }
                 else
                 {
                     sum = sum+s[i];
                 }
             
             
             i++;
         }
         
         printf("Case #%ld: %ld\n",j,count);
         j++;
     }
     fclose(fp);
     
     return 0;
 }
