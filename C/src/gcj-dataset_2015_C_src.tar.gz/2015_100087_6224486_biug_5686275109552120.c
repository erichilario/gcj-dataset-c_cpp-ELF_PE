#include <stdio.h>
 #include <string.h>
 int main()
 {
 	int t, T;
 	int D, P[1111], M, C, result, i, j;
 	scanf("%d", &T);
 	for (t = 1; t <= T; ++t)
 	{
 		scanf("%d", &D);
 		M = 0;
 		for (i = 0; i < D; ++i)
 		{
 			scanf("%d", P + i);
 			if (M < P[i])
 			{
 				M = P[i];
 			}
 		}	
 		result = M;
 		for (i = 1; i <= M; ++i)
 		{
 			C = 0;
 			for (j = 0; j < D; ++j)
 			{
 				C += P[j] % i == 0 ? P[j] / i - 1 : P[j] / i;
 			}
 			result = C + i < result ? C + i : result;
 		}
 		printf("Case #%d: %d\n", t, result);
 	}
 }

