#include<cstdio>
 #include<cstring>
 #include<algorithm>
 using namespace std ;
 int a[1200] ;
 int main() {
     int t , step = 0 ;
     int n , i , j , maximum , minimum , summation ;
     scanf("%d", &t) ;
     while( t-- ) {
         scanf("%d", &n) ;
         for(i = 0 ; i < n ; i++) {
             scanf("%d", &a[i]) ;
             maximum = max(maximum,a[i]) ;
         }
         minimum = maximum ;
         for(i = 1 ; i <= maximum ; i++) {
             summation = i ;
             for(j = 0 ; j < n ; j++) {
                 if( a[j] > i ) {
                     if( a[j]%i == 0 )
                         summation += (a[j]/i-1) ;
                     else
                         summation += (a[j]/i) ;
                 }
             }
             minimum = min(minimum,summation) ;
         }
         printf("Case #%d: %d\n", ++step, minimum) ;
     }
     return 0 ;
 }
 

