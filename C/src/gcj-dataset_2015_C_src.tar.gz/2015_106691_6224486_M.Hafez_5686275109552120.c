#include <stdio.h>
 #include <stdlib.h>
 
 int D [6];
 
 int comp (const void * elem1, const void * elem2) 
 {
     int f = *((int*)elem1);
     int s = *((int*)elem2);
     if (f > s) return -1;
     if (f < s) return 1;
     return 0;
 }
 
 int max (int length)
 {
 	int i = 0;
 	int max = 0;
 	for (;i < length; i++)
 		max = max > D[i]?max:D[i];
 	return max;	
 }
 
 int divided(int x, int j)
 {
 	if(!j)
 		return x;
 	int out = x >> j;
 	if (x%2)
 		out += 1;
 //	printf("[divided] (%d, %d) = %d\n", x, j, out);	
 	return out;	
 }
 
 int avg(int length)
 {
 	int i = 0;
 	int sum = 0;
 	for (; i < length; i++)
 		sum += D[i];
 	return sum%length? sum/length + 1 : sum/length;	
 }
 
 int main()
 {
 	int T, k = 0, solution;
 	int i, d_length, average, maximum, j;
 	int prev_max;
 	int temp; 
 	scanf("%d",&T);
 
 	while(k++ < T)
 	{
 		i = 0;
 		solution = 1;
 		scanf("%d", &d_length);
 		while(i < d_length)
 			scanf("%d", &D[i++]);
 		while(i < 6)	
 			D[i++] = 0;
 /**
 		average = avg(d_length);
 		for(i = 0; i < d_length; i++)
 			if (D[i] >= average)
 				solution ++;
 		maximum = max(d_length);		
 		solution += maximum % 2 ? maximum/2 + 1 : maximum/2;
 		if (solution < maximum)		
 			printf("Case #%d: %d\n", k, solution);
 		else
 			printf("Case #%d: %d\n", k, maximum);
 			*/
 		qsort (D, sizeof(D)/sizeof(*D), sizeof(*D), comp);
 		maximum = D[0];
 		while(solution < maximum)
 		{
 			temp = 1;
 			prev_max = 0;
 			for(i = 0; i < d_length; i++)
 			{
 				j = 0;
 				// printf("sol = %d, temp = %d, div = %d\n", solution, temp, divided(D[i], j));
 				while (temp <= solution && divided(D[i], j) > solution - temp + 1)
 				{
 					temp += (1 << j);
 					j ++;
 					// printf("sol = %d, temp = %d, div = %d\n", solution, temp, divided(D[i], j));
 					prev_max = prev_max > divided(D[i], j) ? prev_max : divided(D[i], j);
 				}
 				if (temp > solution)
 					break;
 			}
 			// printf("sol = %d, temp = %d, div = %d, prev_max = %d\n", solution, temp, divided(D[i], j), prev_max);
 			if (temp <= solution && i == d_length && prev_max <= solution - temp + 1)
 				break;
 			solution ++;
 		}
 		if (solution < maximum)		
 			printf("Case #%d: %d\n", k, solution);
 		else
 			printf("Case #%d: %d\n", k, maximum);
 	}
 	return 0;
 }

