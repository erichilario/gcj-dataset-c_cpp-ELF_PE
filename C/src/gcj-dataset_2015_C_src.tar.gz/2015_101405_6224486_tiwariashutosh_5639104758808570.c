#include<stdio.h>
 int main()
 {
 	int nt,smax,i,sum,j,fz;
 	scanf("%d",&nt);
 	for(i=1;i<=nt;i++)
 	{
 		char p[1002];
 		scanf("%d %s",&smax,p);
 		
 		int people[smax+1];
 			for(j=0;j<=smax;j++)
 			{
 				 people[j]=p[j]-48;
 			}
 			
 		
 		sum=0;fz=0;
 		for(j=0;j<=smax;j++)
 		{
 			if(fz < j && people[j]!=0)
 			{
 				sum= sum+(j-fz);
 				fz= j+people[j];
 			}
 			else
 			{
 				fz+=(people[j]);
 			}
 		
 		}
 		printf("Case #%d: %d\n",i,sum);
 	}
 	return 0;
 }

