#include<stdio.h>
 #include<string.h>
 int main()
 {
     int t,req,ts,i,d,x;
     char arr[10000];
     scanf("%d",&t);
     x=t;
     while(t--)
     {
         scanf("%d %s",&d,arr);
         ts=0;
         req=0;
         for(i=0;i<strlen(arr);i++)
         {
              if(i>ts && arr[i]!='0')
              {
                 req=req+(i-ts);
                 ts=ts+req;
              }
              ts=ts+(arr[i]-'0');
 
         }
 
         printf("Case #%d: %d\n",(x-t),req);
 
 
 
     }
 
 
 return 0;
 }

