#include<stdio.h>
 #include<conio.h>
 void main()
 {
  FILE *p1,*p2;
  int ncase,i,smax,sum=0,total=0,j;
  int s[100][7];
  p1=fopen("sto.txt","w");
  p2=fopen("inp.txt","r");
  fscanf(p2,"%d",&ncase);
  for(i=0;i<ncase;i++)
  {    sum=0;
       total=0;
       fscanf(p2,"%1d ",&smax);
       for(j=0;j<=smax;j++)
 	{
 	fscanf(p2,"%1d",&s[i][j]);
 	}
       for(j=0;j<=smax;j++)
       {
       if(s[i][j]==0 && j==0)
       {
       total=1;
       sum=sum+total;
       }
       else
       {
       sum=sum+s[i][j];
       if(sum<j)
 	 {
 	 total+=(j-sum);
 	 sum=sum+total;
 	 }
 	 else if(sum==j)
 	 {
 	 total++;
 	 sum++;
 	 }
       }
 
       }
 
      fprintf(p1,"Case #%d: %d \n",i+1,total);
  }
  fclose(p1);
  fclose(p2);
  getch();
 }

