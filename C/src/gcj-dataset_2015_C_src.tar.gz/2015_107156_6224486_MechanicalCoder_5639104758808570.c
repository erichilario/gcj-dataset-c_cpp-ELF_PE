#include <stdio.h>
 #include <stdlib.h>
 
 int test,t, smax, flag=0;
 
 int main(){
 	scanf("%d",&t);
 	test=t;
 	while(t--){
 		scanf("%d",&smax);
 		int i, count=0, a[smax];
 		char s[smax+1];
 		scanf("%s",s);
 		for(i=0;i<smax+1;i++){
 			a[i]=s[i]-'0';
 		}
 		flag=a[0];
 		
 		for(i=1;i<smax+1;i++){
 			if(flag<i){
 				count++;
 				flag+=a[i]+1;
 			}
 			else{
 				flag+=a[i];
 			}
 		}
 		printf("Case #%d: %d\n",test-t,count);
 	}
 	return 0;
 }
