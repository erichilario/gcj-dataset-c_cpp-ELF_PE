#include<stdio.h>
 int main()
 {
 	int t,k;
 	scanf("%d",&t);
 	for(k=1;k<=t;k++)
 	{
 		int smax,i,sum=0,inv=0;
 		scanf("%d",&smax);
 		char arr[smax+1];
 fflush(stdin);
 		scanf("%s",arr);
 		for(i=0;i<=smax;i++)
 		{
 			sum=sum+arr[i]-48;
 			if(sum>=smax)
 			break;
 			while(sum<=i)
 			{
 				inv++;
 				sum++;
 			}
 			
 		}
 		printf("Case #%d: %d\n",k,inv);
 		
 	}
 return 0;
 }

