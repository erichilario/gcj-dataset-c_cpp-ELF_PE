#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 void main()
 {
 	FILE *fpin,*fpout;
 	fpin = fopen("A-small-attempt0.in","r");
 	fpout = fopen("write.txt","w");
 	
 	int smax,num,i,j,N,add=0;
 	fscanf(fpin,"%d\n",&N);
 	for(i=0;i<N;i++)
 	{
 		add=0;
 		fscanf(fpin,"%d %d\n",&smax,&num);
 		int *arr = malloc(sizeof(int)*(smax+1));
 		for(j=smax;j>=0;j--)
 		{
 			arr[j]=num%10;
 			num=num/10;
 		}
 		for(j=1;j<=smax;j++)
 		{
 			arr[j]=arr[j]+arr[j-1];
 		}
 		for(j=1;j<=smax;j++)
 		{
 			if(j>arr[j-1]+add)
 			add+= j-arr[j-1]-add;
 		}
 		fprintf(fpout,"Case #%d: %d\n",i+1,add);
 	}
 	fclose(fpin);
 	fclose(fpout);
 }
 	

