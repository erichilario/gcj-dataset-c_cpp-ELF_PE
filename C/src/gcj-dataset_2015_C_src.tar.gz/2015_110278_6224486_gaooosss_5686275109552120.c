/* gcc -o pb1 pb1.c  */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define TRUE 1
 #define FALSE 0
 #define MIN(a,b) ( ( a > b) ? b : a ) 
 
 static void solve (void);
 
 int main () 
 {
     freopen ("in.txt", "r", stdin);
     freopen ("out.txt", "w", stdout);
     int t,i;
     scanf ("%d", &t);
     for (i = 0; i < t; i++) {
         fprintf(stderr,"solving case #%d\n",i+1);
         printf ("Case #%d: ", i + 1);
         solve ();
     }
     return 0;
 }
 
 
 int cmpfunc (const void * a, const void * b)
 {
     return ( *(int*)b - *(int*)a );
 }
 
 #if 0
 int iter(int* p, int d){
 
     int i;
     qsort(p,d,sizeof(int),cmpfunc);
     if(p[0] <= 3)
         return p[0];
 
     printf("p=");
     for(i=0;i<d;i++){
         printf("%d ",p[i]);
     }
     printf("\n");
 
     int* p1 = (int*)malloc((d)*sizeof(int));
     int* p2 = (int*)malloc((d+1)*sizeof(int));
     int* p3 = (int*)malloc((d+1)*sizeof(int));
 
     for(i = 0; i < d; i++){
         p1[i] = p[i];
         p2[i] = p[i];
     }
 
     p2[0] = p[0] - p[0]/2;
     p2[d] = p[0]/2;
 
     /* p3[0] = p[0] - p[0]/3; */
     /* p3[d] =  */
     
     for(i=0;i<d;i++){
         if(p1[i] > 0)
             p1[i]--;
     }
 
     printf("p=");
     for(i=0;i<d;i++){
         printf("%d ",p[i]);
     }
     printf("\n")
     printf("p=");
     for(i=0;i<d;i++){
         printf("%d ",p[i]);
     }
     printf("\n")
 
     int b = iter(p2,d+1);
     p2[0] = p[0] - p[0]/3 - 1;
     p2[d] = p[0]/3 + 1;
     int bb = iter(p2,d+1);
     if(bb < b)
         b = bb;
     
     
     int a = iter(p1,d);
     int s = MIN(a,b);
     free(p1);
     free(p2);
     return s+1;
 }
 
 #endif
 int score(int* p, int d, int n){
     int i;
     int score = 0;
 
     /* printf("p="); */
     /* for(i=0;i<d;i++){ */
     /*     printf("%d ",p[i]); */
     /* } */
     /* printf("\n"); */
 
     for(i=0;i<d;i++){
         score += (p[i]-1)/n;
     }
     /* printf("n=%d, score=%d\n",n,score); */
     score += n;
     /* printf("n=%d, score=%d\n",n,score); */
     return score;
 }
 
 
 void solve (void) 
 {
     int i;
     int res = 0;
     int d,s;
     int* plates;
     
     scanf("%d", &d);
     plates = (int*)malloc(d*sizeof(int));
     for(i = 0; i < d; i++){
         scanf("%d",&plates[i]);
     }
     
     qsort(plates,d,sizeof(int),cmpfunc);
 
     res = plates[0];
     for(i=plates[0];i>1;i--){
         s = score(plates,d,i);
         if(s < res)
             res = s;
     }
 
     free(plates);
     printf("%d\n",res);
 }
 
 

