#include <stdlib.h>
 #include <stdio.h>
 #define max(a,b) (a>b?a:b)
 
 int main(void) {
 
   int t, i;
   int smax, s_total, j;
   char c;
   int invite_max;
 
   scanf("%d", &t);
 
   for (i=1; i<=t; i++) {
 
     scanf("%d ", &smax);
 
     invite_max = 0;
     s_total = 0;
 
     for (j=0; j<=smax; j++) {
       invite_max = max(invite_max, j-s_total);
       scanf("%c", &c);
       s_total += c-'0';
     }
 
     printf("Case #%d: %d\n", i, invite_max);
 
   }
 
   return 0;
 }

