#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 int main(){
   int i, j;
   int t, n, res, max, count;
   char s[1001];
 
   scanf("%d", &t);
   for (n = 1; n <= t; n++) {
     scanf("%d %s", &max, s);
 
     res = count = 0;
     for (j = 0; j < max + 1; j++) {
       if(s[j] != '0' && j > res + count){
         res += (j - (count + res));
       }
       count += (s[j] - '0');
       //printf("i = %d => res %d c %d\n", j, res, count);
     }
     //printf("%s ", s);
     printf("Case #%d: %d\n", n, res);
   }
 
   return 0;
 }

