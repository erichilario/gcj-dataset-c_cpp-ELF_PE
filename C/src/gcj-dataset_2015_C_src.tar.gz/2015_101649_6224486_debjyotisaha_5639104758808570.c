#include<stdio.h>
 main()
 {
 	int t,tcount=1,smax,tot,req,i;
 	char str[1001];
 	scanf("%d\n",&t);
 	while(tcount<=t)
 	{
 		scanf("%d %s",&smax,&str);
 		req=0;
 		tot=str[0]-'0';
 		for(i=1;i<=smax;i++)
 		{
 			req=(tot<i)?(i-tot)+req:req;
 			tot=(tot<i)?(i-tot)+tot+str[i]-'0':tot+str[i]-'0';
 		}
 		printf("Case #%d: %d\n",tcount,req);
 		tcount++;
 	}
 	return(0);
 }

