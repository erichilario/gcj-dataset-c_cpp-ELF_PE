#include<stdio.h>
 #include<stdlib.h>
 int ti[10001],tj[10001],tk[10001];
 int ii=0,ij=0,ik=0;
 int existi(int st)
 {
     int i;
     for(i=0;i<ii;i++)
     if(ti[i]==st) return 0;
     return 1;
 }
 int existj(int st)
 {
     int i;
     for(i=0;i<ij;i++)
     if(tj[i]==st) return 0;
     return 1;
 }
 int existk(int st)
 {
     int i;
     for(i=0;i<ik;i++)
     if(tk[i]==st) return 0;
     return 1;
 }
 char res(char a,char b)
 {
     if     (a=='i'&&b=='j') return 'k';
     else if(a=='j'&&b=='i') return 'k';
     else if(a=='i'&&b=='k') return 'j';
     else if(a=='k'&&b=='i') return 'j';
     else if(a=='j'&&b=='k') return 'i';
     else if(a=='k'&&b=='j') return 'i';
     else if(a=='1') return b;
     else if(b=='1') return a;
     else if(a==b) return '1';
     return '1';
 }
 int sin(char a,char b)
 {
     if     (a=='i'&&b=='j') return 1;
     else if(a=='j'&&b=='i') return -1;
     else if(a=='i'&&b=='k') return -1;
     else if(a=='k'&&b=='i') return 1;
     else if(a=='j'&&b=='k') return 1;
     else if(a=='k'&&b=='j') return -1;
     else if(a=='1') return 1;
     else if(b=='1') return 1;
     else if(a==b) return -1;
     return 1;
 }
 int It1(char *s,int *st,int l,int x)
 {
     int i,si;
     char c='1';
     si=1;
     do
     {
         si*=sin(c,s[(*st)%l]);
         c=res(c,s[(*st)%l]);
         (*st)++;
     }
     while(*st<l*x);
     if(c=='1'&&si==1)
     return 1;
     return 0;
 }
 int It(char *s,int *st,int l,int x)
 {
     int i,si;
     char c='1';
     si=1;
     do
     {
         si*=sin(c,s[(*st)%l]);
         c=res(c,s[(*st)%l]);
         if(c=='i'&&si==1&&existi(*st)) {ti[ii++]=*st;(*st)++;ik=0;ij=0;return 1;break;}
         (*st)++;
     }
     while(*st<l*x);
     return 0;
 }
 int Jt(char *s,int *st,int l,int x)
 {
     int i,si;
     char c='1';
     si=1;
     do
     {
         si*=sin(c,s[(*st)%l]);
         c=res(c,s[(*st)%l]);
         if(c=='j'&&si==1&&existj(*st)) {tj[ij++]=(*st);(*st)++;ik=0;return 1;break;}
         (*st)++;
     }
     while((*st)<l*x);
     return 0;
 }
 int Kt(char *s,int *st,int l,int x)
 {
     int i,si;
     char c='1';
     si=1;
     do
     {
         si*=sin(c,s[(*st)%l]);
         c=res(c,s[(*st)%l]);
         if(c=='k'&&si==1&&existk(*st)) {tk[ik++]=*st;(*st)++;return 1;break;}
         (*st)++;
     }
     while(*st<l*x);
     return 0;
 }
 int main()
 {
     FILE *f=fopen("C-small-attempt6.in","r");
     FILE *g=fopen("C-small-attempt6.out","w");
     int t,i,j,l,x,st,I,J,K;
     char s[10001];
     fscanf(f,"%d",&t);
     while(t--)
     {  ii=0;ij=0;ik=0;
        fscanf(f,"%d %d\n",&l,&x);
        fscanf(f,"%s\n",s);
        here:
         st=0;
        I=It(s,&st,l,x);J=Jt(s,&st,l,x);K=Kt(s,&st,l,x);
       if(I&J&K&(st==l*x)) fprintf(g,"Case #%d: YES\n",100-t);
       else if(I&J&K&It1(s,&st,l,x)) fprintf(g,"Case #%d: YES\n",100-t);
       else if(st<l*x) goto here;
       else fprintf(g,"Case #%d: NO\n",100-t);
     }
 
 }

