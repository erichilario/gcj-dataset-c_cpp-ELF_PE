#include<stdio.h>
 #include<stdlib.h>
 int main(void){
   int T, i, j, S, dePie, invitados, invitadosExtra;
   char cadenaS[1010], digito;
   scanf("%d", &T);
   for(i=1; i<=T; i++){
     scanf("%d", &S);
     scanf("%s", cadenaS);
     dePie=0;
     invitados=0;
     for(j=0; cadenaS[j]!='\0'; j++){
       if((dePie<j)&&(cadenaS[j]!='0')){
 	invitadosExtra=j-dePie;
 	invitados+=invitadosExtra;
 	dePie+=invitadosExtra;
       }
       digito=cadenaS[j];
       dePie+=atoi(&digito);
     }
     printf("Case #%d: %d\n", i, invitados);
   }
   return 0;
 }

