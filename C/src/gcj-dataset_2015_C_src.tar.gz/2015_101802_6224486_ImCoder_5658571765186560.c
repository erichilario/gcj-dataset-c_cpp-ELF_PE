#include<stdio.h>
 int main()
 {
     int test,xo,row,col,j;
     #ifndef ONLINE_JUDGE
     freopen("input.txt","r",stdin);
     freopen("output.txt","w",stdout);
     #endif
     scanf("%d",&test);
     for(j=0;j<test;j++)
     {
         scanf("%d%d%d",&xo,&row,&col);
         if(xo>row+1 || xo>col+1 || xo>=8 || (row*col)%xo)
             printf("Case #%d: RICHARD\n",j+1);
         else
             printf("Case #%d: GABRIEL\n",j+1);
     }
     return 0;
 }

