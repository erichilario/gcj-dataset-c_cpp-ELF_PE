#include<stdio.h>
 int solve(int a,int b,int c)
 {
     if(a==1)
         return 1;
     if(a==2)
     {
         if((b*c)%2==0)
             return 1;
         else
             return 0;
     }
     if(a==3)
     {
         if(b*c==3)
             return 0;
         else if((b*c)%3==0)
             return 1;
         else
             return 0;
     }
     if(a==4)
     {
         if(b*c==16)
             return 1;
         else if(b*c==12)
             return 1;
         else
             return 0;
 
     }
 }
 int main()
 {
     int t,n,x,r,c,flag;
     scanf("%d",&t);
     n=t;
     while(t--)
     {
         scanf("%d%d%d",&x,&r,&c);
         flag=solve(x,r,c);
         if(flag)
             printf("Case #%d: GABRIEL\n",(n-t));
         else
             printf("Case #%d: RICHARD\n",(n-t));
     }
     return 0;
 }

