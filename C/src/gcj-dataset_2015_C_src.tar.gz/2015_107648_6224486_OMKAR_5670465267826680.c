#include<stdio.h>
 #include<string.h>
 int main(){
 
     int leave,i,got1,got2,got3,neg,neg2,a1,a2,v,p;
     int t;
     scanf("%d",&t);
     for(p=0;p<t;p++){
 
     char str[99999]="";
     char in[99999];
     int n1;
     int n;
     scanf("%d",&n1);
     scanf("%d",&n);
 
     scanf("%s",in);
     for(i=0;i<n;i++){
         strcat(str,in);
     }
     n1=n1*n;
     str[n1]='\0';
     //printf("%s",str); getch();
     char ans[10]="";
     char temp[99999]="";
     char stock[99999];
     strcpy(stock,str);
     char mat[][4][4]={
             {"1","i","j","k"},
             {"i","-1","k","-j"},
             {"j","-k","-1","i"},
             {"k","j","-i","-1"},
 
             };
 
             //printf("%s\n",mat[3][0]);
             leave=0;
 
             i=0; got1=0; got2=0; got3=0;
             while(str[i]!='\0'){
 
                 if(got1==0){
 
                         ans[0]=str[i];
 
                         //ans[1]='\0';
                         v=0;
                         if(ans[0]=='i'){
                             v=1;
                         }
 
                         i++;
 
                         while(ans[0]!='i'){
 
 
                             neg=0;
                             //ans[1]='\0';
                                    //printf("hey %s",ans); getch();
                                     if(ans[0]=='1' || ans[1]=='1'){
                                         a1=0; //puts("a");
                                         if(ans[1]=='1'){
                                            neg=1;
                                         }
                                     }else if(ans[0]=='i' || ans[1]=='i'){
                                         a1=1;//puts("b");
                                         if(ans[1]=='i'){
                                            neg=1;
                                         }
 
                                     }else if(ans[0]=='j' || ans[1]=='j'){
                                         a1=2;//puts("c");
                                         if(ans[1]=='j'){
                                            neg=1;// puts("neg got\n");
                                         }
                                     }else if(ans[0]=='k' || ans[1]=='k'){
                                         a1=3;//puts("d");
                                         if(ans[1]=='k'){
                                            neg=1;
                                         }
                                     }
 
                                     //str[0]='j';
                                     //printf("%c",str[1]);getch();
                                     if(str[i]=='1'){
                                         a2=0;//puts("e");
                                     }else if(str[i]=='i'){
                                         a2=1;//puts("f");
                                     }else if(str[i]=='j'){
                                         a2=2;//puts("g");
                                     }else if(str[i]=='k'){
                                         a2=3;//puts("h");
                                     }
 
                             neg2=0;
 
                             strcpy(ans,mat[a1][a2]);
 
                             //printf("%s",ans); getch();
                             if(ans[0]=='-'){
                                     ans[2]='\0';
                             }else{
                                     ans[1]='\0';
                             }
 
                             if(strcmp(ans,"-1")==0){
                                 neg2=1; strcpy(ans,"1");
                                 //puts("1");
                             }else if(strcmp(ans,"-i")==0){
                                 neg2=1; strcpy(ans,"i");
                                 //puts("2");
                             }else if(strcmp(ans,"-j")==0){
                                 neg2=1; strcpy(ans,"j");
                                 //puts("3");
                             }else if(strcmp(ans,"-k")==0){
                                 neg2=1; strcpy(ans,"k");
                                 //puts("4");
                             }
                             //printf("%d %d ",neg,neg2); getch();
                             if((neg==1 && neg2==0) || (neg==0 && neg2==1)){
                                     strcpy(temp,ans);
                                     strcpy(ans,"-");
                                     strcat(ans,temp);
                                     ans[2]='\0';
                             }
                             //printf("%s",ans); getch();
 
                             i++;
                             if(str[i]=='\0'){
                                 leave=1;break;
                             }
                         }
                     got1=1;
                 }else if(got2==0){
 
 
                         i--;
                         //printf("Done\n");
                         strcpy(str,stock);
                         //printf("%c",str[3]); getch();
 
                         ans[0]=str[i];
 
                         v=0;
                         if(ans[0]=='j'){
                             v=1;i--;
                         }
                         i++;
 
                         while(ans[0]!='j'){
 
                             neg=0;
                           //  ans[1]='\0';
                                    //printf("hey %s",ans); getch();
                                     if(ans[0]=='1' || ans[1]=='1'){
                                         a1=0; //puts("a");
                                         if(ans[1]=='1'){
                                            neg=1;
                                         }
                                     }else if(ans[0]=='i' || ans[1]=='i'){
                                         a1=1;//puts("b");
                                         if(ans[1]=='i'){
                                            neg=1;
                                         }
 
                                     }else if(ans[0]=='j' || ans[1]=='j'){
                                         a1=2;//puts("c");
                                         if(ans[1]=='j'){
                                            neg=1;// puts("neg got\n");
                                         }
                                     }else if(ans[0]=='k' || ans[1]=='k'){
                                         a1=3;//puts("d");
                                         if(ans[1]=='k'){
                                            neg=1;
                                         }
                                     }
 
                             //        str[0]='j';
                                     //printf("%c",str[1]);getch();
                                     if(str[i]=='1'){
                                         a2=0;//puts("e");
                                     }else if(str[i]=='i'){
                                         a2=1;//puts("f");
                                     }else if(str[i]=='j'){
                                         a2=2;//puts("g");
                                     }else if(str[i]=='k'){
                                         a2=3;//puts("h");
                                     }
 
                             neg2=0;
 
                             strcpy(ans,mat[a1][a2]);
 
                             //printf("%s",ans); getch();
                             if(ans[0]=='-'){
                                     ans[2]='\0';
                             }else{
                                     ans[1]='\0';
                             }
 
                             if(strcmp(ans,"-1")==0){
                                 neg2=1; strcpy(ans,"1");
                                 //puts("1");
                             }else if(strcmp(ans,"-i")==0){
                                 neg2=1; strcpy(ans,"i");
                                 //puts("2");
                             }else if(strcmp(ans,"-j")==0){
                                 neg2=1; strcpy(ans,"j");
                                 //puts("3");
                             }else if(strcmp(ans,"-k")==0){
                                 neg2=1; strcpy(ans,"k");
                                 //puts("4");
                             }
                             //printf("%d %d ",neg,neg2); getch();
                             if((neg==1 && neg2==0) || (neg==0 && neg2==1)){
                                     strcpy(temp,ans);
                                     strcpy(ans,"-");
                                     strcat(ans,temp);
                                     ans[2]='\0';
                             }
                           //  printf("%s",ans); getch();
 
                             i++;
                             if(str[i]=='\0'){
                                 leave=1;break;
                             }
                         }
                     got2=1;
 
 
 //////////////////////////////////////////////////////////////////////////////////
                 }else if(got3==0){
 
                         if(v==1){
                             i++;
                         }
                         i--;
                         //printf("Done\n");
                         strcpy(str,stock);
                         //printf("%c",str[3]); getch();
                         ans[0]=str[i];
 
                         i++;
 
                         while(ans[0]!='k'){
 
                             neg=0;
                             //ans[1]='\0';
                                    //printf("hey %s",ans); getch();
                                     if(ans[0]=='1' || ans[1]=='1'){
                                         a1=0; //puts("a");
                                         if(ans[1]=='1'){
                                            neg=1;
                                         }
                                     }else if(ans[0]=='i' || ans[1]=='i'){
                                         a1=1;//puts("b");
                                         if(ans[1]=='i'){
                                            neg=1;
                                         }
 
                                     }else if(ans[0]=='j' || ans[1]=='j'){
                                         a1=2;//puts("c");
                                         if(ans[1]=='j'){
                                            neg=1;// puts("neg got\n");
                                         }
                                     }else if(ans[0]=='k' || ans[1]=='k'){
                                         a1=3;//puts("d");
                                         if(ans[1]=='k'){
                                            neg=1;
                                         }
                                     }
 
                               //      str[0]='j';
                                     //printf("%c",str[1]);getch();
                                     if(str[i]=='1'){
                                         a2=0;//puts("e");
                                     }else if(str[i]=='i'){
                                         a2=1;//puts("f");
                                     }else if(str[i]=='j'){
                                         a2=2;//puts("g");
                                     }else if(str[i]=='k'){
                                         a2=3;//puts("h");
                                     }
 
                             neg2=0;
 
                             strcpy(ans,mat[a1][a2]);
 
                             //printf("%s",ans); getch();
                             if(ans[0]=='-'){
                                     ans[2]='\0';
                             }else{
                                     ans[1]='\0';
                             }
 
                             if(strcmp(ans,"-1")==0){
                                 neg2=1; strcpy(ans,"1");
                                 //puts("1");
                             }else if(strcmp(ans,"-i")==0){
                                 neg2=1; strcpy(ans,"i");
                                 //puts("2");
                             }else if(strcmp(ans,"-j")==0){
                                 neg2=1; strcpy(ans,"j");
                                 //puts("3");
                             }else if(strcmp(ans,"-k")==0){
                                 neg2=1; strcpy(ans,"k");
                                 //puts("4");
                             }
                             //printf("%d %d ",neg,neg2); getch();
                             if((neg==1 && neg2==0) || (neg==0 && neg2==1)){
                                     strcpy(temp,ans);
                                     strcpy(ans,"-");
                                     strcat(ans,temp);
                                     ans[2]='\0';
                             }
                             //printf("%s",ans); getch();
 
                             i++;
                             if(str[i]=='\0'){
                                 leave=1;break;
                             }
                         }
                     got3=1; break;
                 }
                 if(leave==1){
                     break;
                 }
                 i++;
             }
             printf("Case #%d: ",p+1);
 if(got3==1){
 
     printf("YES\n");
 }else{
     printf("NO\n");
 }
     }
 return 0;
 }

