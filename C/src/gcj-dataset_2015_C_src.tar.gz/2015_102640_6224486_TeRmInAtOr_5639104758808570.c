#include <stdio.h>
 
 int main ()
 {
 		int tc, max_shyness, i, j, people_standing, friends_added, friends_needed;
 		char arr[1001];
 
 		scanf ("%d",&tc);
 		for (j=1; j<=tc; j++) {
 				scanf("%d %s", &max_shyness, &arr);
 				people_standing = 0;
 				friends_needed = 0;
 
 				for (i=0;i<=max_shyness;i++) {
 						friends_added = 0;
 						if (people_standing < i) {
 								friends_added = (i-people_standing);
 								friends_needed = friends_needed + friends_added;
 						}
 						people_standing = people_standing + friends_added + (arr[i]-'0');
 				}
 				printf ("Case #%d: %d\n", j, friends_needed);
 		}
 		return 0;
 }

