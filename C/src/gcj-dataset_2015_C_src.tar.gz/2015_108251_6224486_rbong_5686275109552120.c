#include <stdio.h>
 #include <string.h>
 #include <math.h>
 int main (int argc, const char **argv)
 {
     FILE* fp = fopen (argv [1], "r");
     int cases, diners, max, tmax, mins, smins;
     int pancake [1001];
     int temp [2002];
     int i, j;
     fscanf (fp, "%d", &cases);
     for (i = 0; i < cases; i++)
     {
         fscanf (fp, "%d", &diners);
         tmax = max = 0;
         for (j = 0; j < diners; j++)
         {
             fscanf (fp, "%d", &(pancake [j]));
             temp [j] = pancake [j];
             if (pancake [j] > pancake [max])
                 tmax = max = j;
         }
         mins = pancake [max];
         smins = 0;
         while (smins < pancake [max])
         {
             smins++;
             temp [tmax] = ceil (temp [tmax] / 2.0);
             tmax = 0;
             for (j = 0; j < diners; j++)
                 if (temp [j] > temp [tmax])
                     tmax = j;
             if (temp [tmax] + smins <= mins)
                 mins = temp [tmax] + smins;
         }
         printf ("Case #%d: %d\n", i + 1, mins);
     }
     return 0;
 }

