#include <stdio.h>
 
 int main() {
 	FILE* in  = fopen("A-large.in","r");
 	FILE* out = fopen("q1_ans_large.txt","w");
 
 	int T,S;
 	int sum, res;
 	int i,j;
 	char c;
 
 	fscanf(in,"%d", &T);
 
 	for (i=0; i<T; i++) {
 		fscanf(in,"%d ", &S);
 		sum = 0;
 		res = 0;
 		for (j=0; j<=S; j++) {
 			fscanf(in,"%c", &c);
 
 			if (sum < j) {
 				res++;
 				sum++;
 			}
 
 			sum += c-48;
 		}
 
 		fprintf(out, "Case #%d: %d", i+1, res);
 
 		if (i+1 != T)
 			fprintf(out, "\n");
 	}
 
 	return 0;
 }
