#include<stdio.h>
 #include<stdlib.h>
 
 #define N 100
 #define S 1000
 
 char line[S];
 
 char temp[10];
 
 void getppl(char [],int ,int );
 int main(){
   size_t len = 0;
   int no_line=0,pointer=0,j=0,i=0,z=0,max_credit=0;
   char *ptr=NULL;
   FILE *ptr_file;
 
   ptr_file =fopen("A-large.in","r");
   if (!ptr_file)
       return 1;
 
   if(fgets(line,S, ptr_file)!=NULL)
       no_line=atoi(line);
   //printf("%d",no_line);
   for(i=1;i<=no_line;i++){
 	   printf("Case #%d: ",i);
      if(fgets(line,S, ptr_file)!=NULL)
      //printf("%s",line);
      for(z=0,j=0;line[z]!='\0';z++){
        if(line[z] == ' '){
          temp[j]='\0';
          max_credit=atoi(temp);
          break;
        }
        else
          temp[j++]=line[z];
     }
     pointer=z;
     for(;line[z]!='\0';z++);
     getppl(line,pointer,max_credit);
     //printf("%d %d \n",z-pointer-1,max_credit+1);
     printf("\n");
   }
   return 1;
 }
 
 void getppl(char list[],int pnt,int max_cr){
   int x=0,y=0,sum=0,tmp=0,req=0;
   //for(x=pnt+1,y=0;list[x]!='\n';x++,y++){
   for(x=pnt+1,y=0;y<=max_cr;x++,y++){
     tmp=(list[x]-'0');
     //printf("%d %d %d %d\n",tmp,sum,y,req);
     sum=sum+tmp;
     if(tmp==0)
     {
       if(y+1>sum){
         sum=sum+1;
         req=req+1;
       }
     }
   }
   printf("%d",req);
 }

