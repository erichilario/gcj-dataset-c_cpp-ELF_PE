#include <stdio.h>
 #include <stdlib.h>
 #define GABRIEL 0
 #define RICHARD 1
 #define ISNT_MULTIPLE(X, Y) ((X)%(Y))
 #define IS_MULTIPLE(X, Y) !ISNT_MULTIPLE(X, Y)
 
 int whoWins(int x, int r, int c) {
 	if((x>r && x>c) || x>3 || r*c<x || ISNT_MULTIPLE(r*c, x) || (x==3 && (!((IS_MULTIPLE(r, 2) && IS_MULTIPLE(c, 3)) || (IS_MULTIPLE(r, 3) && IS_MULTIPLE(c, 2)))))) return RICHARD;
 	return GABRIEL;
 }
 
 int main(void) {
 	int t=0, T, x, r, c;
 	scanf("%d", &T);
 	while(t++ < T) {
 		scanf("%d %d %d", &x, &r, &c);
 		printf("Case #%d: %s\n", t, (whoWins(x, r, c)==GABRIEL?"GABRIEL":"RICHARD"));
 	}
 	return 0;
 }

