#include<stdio.h>
 #include<string.h>
 #include<limits.h>
 #define PMAX 1000
 #define HALF(X) (((X)%2)?((X)+1)/2:(X)/2)
 #define MIN(X,Y) (((X)<=(Y))?(X):(Y))
 #define MAX(X,Y) (((X)>=(Y))?(X):(Y))
 int D;
 int A[PMAX+1];
 int JUSTSLIDE[]={2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113,127,131,137,139,149,151,157,163,167,173,179,181,191,193,197,199,211,223,227,229,233,239,241,251,257,263,269,271,277,281,283,293,307,311,313,317,331,337,347,349,353,359,367,373,379,383,389,397,401,409,419,421,431,433,439,443,449,457,461,463,467,479,487,491,499,503};
 int sum(int jam[],int ballsDeep){
 	int space;
 	int slam=0;
 	for(space=0;space!=ballsDeep;space++)slam+=jam[space];
 	return slam;
 }
 int pass(void){
 	int space;
 	int dance[1001],chance[1001],bam=0;
 	int jam,maam;
 	for(jam=1000;jam>=0;--jam){
 		if(A[jam]){
 			if(bam){
 				space=dance[0]-MAX(jam,HALF(dance[0]));
 				if(sum(chance,bam)<space){
 					for(maam=0;maam!=bam;++maam){
 						A[dance[maam]]=0;
 						if(dance[maam]%2==0)A[dance[maam]/2]+=chance[maam]*2;
 						else A[dance[maam]/2]+=chance[maam],
 							A[dance[maam]/2+1]+=chance[maam];
 					}
 					return sum(chance,bam);
 				}
 			}
 			dance[bam]=jam;
 			chance[bam]=A[jam];
 			bam++;
 		}
 	}
 	space=dance[0]-HALF(dance[0]);
 	if(sum(chance,bam)<space){
 		for(maam=0;maam!=bam;++maam){
 			A[dance[maam]]=0;
 			if(dance[maam]%2==0)A[dance[maam]/2]+=chance[maam]*2;
 			else A[dance[maam]/2]+=chance[maam],
 				A[dance[maam]/2+1]+=chance[maam];
 		}
 		return sum(chance,bam);
 	}
 	return 0;
 }
 int main2(void){
 	int jam;
 	int space=0;
 	int ballsDeep;
 	while((ballsDeep=pass()))space+=ballsDeep;
 	for(jam=1000;jam>=0;--jam)
 		if(A[jam])
 			return space+jam;
 	return -10000000;
 }
 int shakeIt(int JAM[],int jam){
 	int slam;
 	int MAAM[1001];
 	int SPACE[1001];
 	int dropIt;
 	for(slam=jam;slam>=0;--slam)if(JAM[slam])break;
 	if(slam<=3)return slam;
 	memcpy(MAAM,JAM,sizeof(A));
 	memcpy(SPACE,JAM,sizeof(A));
 	MAAM[slam]=0;
 	if(slam%2==0)MAAM[slam/2]+=2*JAM[slam];
 	else MAAM[slam/2]+=JAM[slam],MAAM[slam/2+1]+=JAM[slam];
 	for(dropIt=1;dropIt!=slam;++dropIt)
 		SPACE[dropIt]=SPACE[dropIt+1];
 	SPACE[slam]=0;
 	return MIN(shakeIt(MAAM,slam)+JAM[slam],shakeIt(SPACE,slam)+1);
 }
 int ayylmao(void){
 	int bam=shakeIt(A,1000);
 	return bam;
 }
 void fromLeftToRight(int slam,int jam){
 	int bam=jam%slam;
 	int bass;
 	A[jam/slam+1]+=bam*A[jam];
 	A[jam/slam]+=(slam-bam)*A[jam];
 	A[jam]=0;
 }
 void yourselfTheNight(int slam,int jam,int bass){
 	int bam=jam%slam;
 	A[jam]=bass;
 	A[jam/slam+1]-=bam*A[jam];
 	A[jam/slam]-=(slam-bam)*A[jam];
 }
 int spaceKaboom(int BALLSDEEP[],int ballsDeep,int BASS[],int face){
 	int slam=face;
 	int jam;
 	for(jam=0;jam!=ballsDeep;++jam)
 		if(BALLSDEEP[jam]+BASS[jam]<slam)
 			slam=BALLSDEEP[jam]+BASS[jam];
 	return slam;
 }
 int downTheRoom(int slam){
 	int jam;
 	int bam;
 	int maam;
 	int base;
 	int BALLSDEEP[1001],ballsDeep=0;
 	int BASS[1001],bass=0;
 	for(jam=slam;jam>0;--jam){
 		if(A[jam])break;
 	}
 	if(jam<=3)return jam;
 	for(bam=0;jam/JUSTSLIDE[bam]>=2;++bam){
 		maam=JUSTSLIDE[bam];
 		BASS[bass++]=(maam-1)*A[jam];
 		base=A[jam];
 		fromLeftToRight(maam,jam);
 		BALLSDEEP[ballsDeep++]=downTheRoom(jam);
 		yourselfTheNight(maam,jam,base);
 	}
 	return spaceKaboom(BALLSDEEP,ballsDeep,BASS,jam);
 }
 int main(void){
 	FILE *fin=fopen("b.in","r");
 	FILE *fout=fopen("b.out","w");
 	int T;
 	int i;
 	int j;
 	int space;
 	fscanf(fin,"%d",&T);
 	for(i=0;i!=T;++i){
 		memset(A,0,sizeof(A));
 		fscanf(fin,"%d",&D);
 		for(j=0;j!=D;++j)
 			fscanf(fin,"%d",&space),A[space]++;
 		fprintf(fout,"Case #%d: %d\n",i+1,downTheRoom(1000));
 	}
 	fclose(fin);
 	fclose(fout);
 	return 0;
 }

