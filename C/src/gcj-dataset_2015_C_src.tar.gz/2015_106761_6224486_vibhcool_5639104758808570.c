#include<stdio.h>
 int main()
 {
 char s[1000];
 long long int t,j=0,k,p,q;
 int l;
 scanf("%lld",&t);
 while(j<t)
 {
 p=0;q=0;
 scanf("%lld",&k);
 scanf("%s",&s);
 for(k=0;s[k]!='\0';k++)
 {
 l=(int)s[k]-48;
 if(l!=0)
 if(p>=k || k==0)
 p=p+l;
 else
 {
 q=(k-p)+q;
 p=p+q+l;
 }
 }
 printf("Case #%lld: %lld\n",j+1,q);
 j++;
 }
 return 0;
 }

