#include <stdio.h>
 #include <stdlib.h>
 #include <algorithm>
 void g_win(int case_num){
   printf("Case #%d: GABRIEL\n", case_num);
 }
 void r_win(int case_num){
   printf("Case #%d: RICHARD\n", case_num);
 }
 
 void solve_the_case(int case_num){
   int X,R,C;
   scanf("%d", &X);
   scanf("%d", &R);
   scanf("%d", &C);
   int min_edge = std::min(R, C);
   if ((R*C)%X !=0) {
      r_win(case_num); 
      return;
   }
   if (X==1 || X==2) {
      g_win(case_num);
      return;
   }
   switch (X){
   case 3:
     if (min_edge == 1) r_win(case_num);
     else g_win(case_num);
     break;
   case 4: 
   case 5:
     if (min_edge <= 2) r_win(case_num);
     else g_win(case_num);
     break;
   case 6:
     if (min_edge <= 3) r_win(case_num);
     else g_win(case_num);
     break;
   default:
     r_win(case_num);
   }
   return;
 }
 
 int main(){
   int T, i;
   scanf("%d", &T);
   for (i = 1; i<=T; ++i )
     solve_the_case(i);
   return 0;
 }

