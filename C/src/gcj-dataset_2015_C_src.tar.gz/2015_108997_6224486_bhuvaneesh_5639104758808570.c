#include<stdio.h>
 #include<string.h>
 void main()
 {
 	int n,t,s[110],i,j,k,req,ps=0;
 	char c[10];
 	FILE *fp;
 	fp=fopen("input.txt","r");
 	fscanf(fp,"%d",&t);
 	for(i=0;i<t;i++)
 	{	 n=0;	ps=0;	req=0;
 		fscanf(fp,"%d",&n);
 		fscanf(fp,"%s",c);
 		for(j=0;j<=n;j++)
 		{	
 			s[j]=c[j]-'0';
 			if(j==0&&s[j]==0){	req=1;	ps=1;}
 			
 			if(ps<j){
 				req+=j-ps;
 				ps=j;
 			}
 			ps+=s[j];
 		}
 		printf("Case #%d: %d\n",i+1,req);
 	}
 	fclose(fp);
 }
