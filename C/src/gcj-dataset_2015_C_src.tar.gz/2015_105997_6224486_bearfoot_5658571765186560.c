#include <stdio.h>
 #include <stdlib.h>
 
 FILE * fin, *fout;
 int cases;
 
 unsigned int plus;
 int num;
 int act;
 int x,r,c;
 char buf[2000];
 
 int main(){
 	int i,j;
 	fin=fopen("in.txt","r");
 	fout=fopen("out.txt","w");
 	if(fin == NULL){
 		printf("AAAA \n");
 		return(1);
 	}
 	/*while(fgets(buf,255,fin)){
 		printf("%s\n",buf);
 	}*/
 	fscanf(fin,"%d\n", &cases);
 	//fscanf(fin,"%s",buf);
 	//printf("ok? :%s\n",buf);
 	printf("cases: %d\n",cases);
 	for(i=1;i<=cases;i++){
 		memset(buf,0,sizeof(buf));
 		printf("Case #%d\n",i);
 		fscanf(fin,"%d %d %d\n",&x , &r, &c);
 		printf("x: %d, r: %d, c: %d\n", x,r,c);
 		fprintf(fout,"Case #%d: ",i);
 		if(c<r)
 		{
 			num=c;
 			c=r;
 			r=num;
 		}
 		if(r*c<x)
 			goto impossible;
 		if( (r*c) % x != 0)
 			goto impossible;
 		if( 3 == x )
 		{
 			if (1==r)
 				goto impossible;
 		}
 		else if ( 4 == x )
 		{
 			if(1==r || 2 ==r || 2==c)
 				goto impossible;
 		}
 		printf("possible, GABRIEL\n");
 		fprintf(fout,"GABRIEL\n");
 		continue;
 		impossible:
 			fprintf(fout,"RICHARD\n");
 			printf("impossible, RICHARD\n");
 
 	}
 	return(0);		
 } 

