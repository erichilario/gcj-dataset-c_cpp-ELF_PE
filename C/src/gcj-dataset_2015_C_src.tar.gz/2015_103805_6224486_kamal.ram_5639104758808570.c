#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <malloc.h>
 #define MAXLENGTH (10)
 FILE *inputfp = NULL;
 FILE *outputfp = NULL;
 char *readInput();
 int main()
 {
     int testCases, sMax, sum, i, diff, n;
     char *str=NULL;
     inputfp = fopen("input.in", "r");
     outputfp = fopen("output.out", "w");
     if(inputfp)
     {
         str = readInput();
         testCases = atoi(str);
         n = 1;
         while(n <= testCases)
         {
             sMax = atoi(readInput());
             str = readInput();
             sum = 0;
             diff = 0;
             for(i = 0; (str[i] != 0)&&(i <= sMax); i++)
             {
                 if(sum < i)
                 {
                     diff = diff + (i - sum);
                     sum = i + (str[i] - 48);
                 }
                 else
                 {
                     sum = sum + (str[i] - 48);
                 }
             }
             fprintf(outputfp, "%s%d%s%d%s", "Case #", n, ": ", diff, "\n");
             n++;
         }
     }
     fclose(inputfp);
     fclose(outputfp);
     return 0;
 }
 char *readInput()
 {
     int   inputChar;              /* Input Character */
     int   index;                  /* To update array */
     char *str;
     /* Initialise */
     str = (char *) malloc(MAXLENGTH);
     index = 0;
     /* Read Line */
     while ( ((inputChar = fgetc(inputfp)) != EOF) && (inputChar != '\n') && (inputChar != ' '))
     {
         /* Update Array */
         if (index < MAXLENGTH) { str[index] = inputChar; }
         index++;
     }
     str[index] = 0;
     /* Store Line */
 
     return(str);
 }

