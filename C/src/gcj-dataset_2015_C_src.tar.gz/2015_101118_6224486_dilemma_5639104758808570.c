#include<stdio.h>
 #include<stdlib.h>
 char a[1010];
 int main(void)
 {
 	int i,u,n,pi,qi,now,ans;
 	freopen("A-small-attempt3.in","r",stdin);
 	freopen("A-small-attempt3.out","w",stdout);
 	scanf("%d",&pi);
 	for(qi=1;qi<=pi;qi++)
 	{
 		scanf("%d%s",&n,a);
 		now=a[0]-'0';
 		ans=0;
 		for(i=1;i<=n;i++)
 		{
 			if(now<i)
 			{
 				u=i-now;
 				ans=ans+u;
 				now=now+u+a[i]-'0';
 			}
 			else
 			{
 				now=now+a[i]-'0';
 			}
 		}
 		printf("Case #%d: %d\n",qi,ans);
 	}
 	return 0;
 }
