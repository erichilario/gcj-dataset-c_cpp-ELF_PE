#include <errno.h>
 #include <stdio.h>
 #include <stdint.h>
 #include <stdlib.h>
 
 
 int main(int argc, char **argv) {
   char buffer[BUFSIZ];
   uint32_t records, i;
   FILE *src = stdin, *dst = stdout;
 
   if(argc >= 2) {
     src = fopen(argv[1], "rb");
   }
 
   if(argc >= 3) {
     dst = fopen(argv[2], "wb");
   }
 
   if(!fgets(&buffer[0], sizeof(buffer), src)) {
     return 1;
   }
 
   if(sscanf(&buffer[0], "%u", &records) != 1) {
      return 2;
   }
 
   for(i = 0; i < records; i++) {
     char *ptr = &buffer[0], *end;
     uint32_t x, r, c, m;
 
     if(!fgets(ptr, sizeof(buffer), src)) {
       return 3;
     }
 
     if(sscanf(&buffer[0], "%u %u %u", &x, &r, &c) != 3) {
        return 4;
     }
 
     if((r * c) % x) {
       goto richard;
     }
 
     if(x <= 2) {
       goto gabriel;
     }
 
     if(x >= 7) {
       goto richard;
     }
 
     if(x > r && x > c) {
       goto richard;
     }
 
     m = r < c ? r : c;
 
     if(x >= (m * 2 + 1)) {
       goto richard;
     }
 
     if(x >= 4 && m <= ((x + 1) / 2)) {
       goto richard;
     }
 
 gabriel:
     fprintf(dst, "Case #%u: GABRIEL\n", i + 1);
     continue;
 
 richard:
     fprintf(dst, "Case #%u: RICHARD\n", i + 1);
   }
 }
 

