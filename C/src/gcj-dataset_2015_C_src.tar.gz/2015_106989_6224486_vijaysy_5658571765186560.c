#include <stdio.h>
 int main(){
 
 FILE *fpI,*fpO;
 int i=0,t,x,r,c,tmp;
 
 
     fpI=fopen("D-large.in","r");
     fpO=fopen("output.txt","w");
 
     fscanf(fpI,"%d",&t);
 
 
     for(i=0;i<t;i++){
 
         fscanf(fpI,"%d%d%d",&x,&r,&c);
 
         if(x==1)
             fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
 
         else if(x==2){
             tmp=r*c;
             if(tmp%x==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==3){
             tmp=r*c;
             if(tmp==6||tmp==12||tmp==9)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==4){
                 tmp=r*c;
                 if(r*c>=12)
                     fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
                 else
                     fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==5){
             tmp=r*c;
             if(tmp>=20&&tmp%5==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==6){
             tmp=r*c;
             if(tmp>=30&&tmp%6==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==7){
                 tmp=r*c;
                 if(tmp>=42&&tmp%7==0)
                     fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
                 else
                     fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
 
         else if(x==8){
             tmp=r*c;
             if(tmp>=56&&tmp%8==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==9){
             tmp=r*c;
             if(tmp>=72&&tmp%9==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==10){
                 tmp=r*c;
                 if(tmp>=90&&tmp%10==0)
                     fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
                 else
                     fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==11){
             tmp=r*c;
             if(tmp>=110&&tmp%11==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==12){
             tmp=r*c;
             if(tmp>=132&&tmp%12==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==13){
                 tmp=r*c;
                 if(tmp>=156&&tmp%13==0)
                     fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
                 else
                     fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==14){
             tmp=r*c;
             if(tmp>=182&&tmp%14==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==15){
             tmp=r*c;
             if(tmp>=210&&tmp%15==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==16){
                 tmp=r*c;
                 if(tmp>=240&&tmp%16==0)
                     fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
                 else
                     fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==17){
             tmp=r*c;
             if(tmp>=272&&tmp%17==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==18){
             tmp=r*c;
             if(tmp>=306&&tmp%18==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==19){
                 tmp=r*c;
                 if(tmp>=342&&tmp%19==0)
                     fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
                 else
                     fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else{
             tmp=r*c;
                 if(tmp>=380&&tmp%20==0)
                     fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
                 else
                     fprintf(fpO,"Case #%d: RICHARD\n",i+1);
 
         }
     }
     return 0;
 }

