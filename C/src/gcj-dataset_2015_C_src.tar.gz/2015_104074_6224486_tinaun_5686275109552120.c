// dividing pancakes
 //
 
 #include <stdio.h>
 #include <stdlib.h>
 
 #define MAX_P 10
 
 
 int main(){
 
 	int t, d;
 	scanf(" %d ", &t);
 
 	int * plates = (int *) calloc(MAX_P, sizeof(int));
 
 	int i, j, cake_v;
 	for(i = 0; i < t; i++){
 		scanf(" %d ", &d);
 		int time = 0;
 
 		for(j = 0; j < d; j++){
 			scanf(" %d ", &cake_v);
 			plates[cake_v]++;
 		}
 
 		int can_cut = 1;
 		for(j = MAX_P - 1; j > 0; j--){
 			//printf("%d pancake plates: %d\n", j, plates[j]);
 			if(can_cut && plates[j] != 0){
 
 				if(plates[j] + time > j/2){
 					can_cut = 0;
 				} else if(plates[j] > 1){
 					int k;
 					for(k = 1; k < plates[j]; k++){
 						if(plates[j - k] != 0){
 							can_cut = 0;
 						}
 					}
 				}
 				
 				if(can_cut){	
 					time += plates[j];
 					if(j & 1){
 						plates[j/2] += plates[j];
 						plates[j/2 + 1] += plates[j];
 					} else {
 						plates[j/2] += 2*plates[j];
 					}
 				} else {
 					time += j;
 				}
 			}
 
 			plates[j] = 0;
 		}
 
 		printf("Case #%d: %d\n", i+1, time);
 	}
 
 	free(plates);
 	return 0;
 }

