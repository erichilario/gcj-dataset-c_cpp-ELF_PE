#include <stdio.h>
 #include <string.h>
 #include <assert.h>
 int main()
 {
   int t, casen, len, cake, maxcakenum, maxcakecount, plate, elapsed, i, lowest;
   int numcake[1001];
   int save;
   
   scanf("%d\n", &t);
   for (casen=1;casen<=t;casen++)
     {
       elapsed=0;
       maxcakenum=0;
       maxcakecount=0;
       memset(numcake, 0, 1001*sizeof(int));
       scanf("%d", &len);
       for(plate=0;plate<len;plate++)
 	{
 	  scanf("%d", &cake);
 	  numcake[cake]++;
 	  if (maxcakenum <= cake)
 	    {
 	      maxcakenum = cake;
 	      maxcakecount = numcake[cake];
 	    }
 	}
       save = lowest = maxcakenum;
       while(maxcakenum!=1)
 	{
 	  elapsed += maxcakecount;
 	  numcake[maxcakenum/2]+=maxcakecount;
 	  numcake[(maxcakenum+1)/2]+=maxcakecount;
 	  numcake[maxcakenum]=0;
 	  maxcakenum = (maxcakenum+1)/2;
 	  for (i=0; i< 1001;i++)
 	    if (numcake[i] > 0)
 	      {
 		maxcakenum = i;
 		maxcakecount=numcake[i];
 	      }
 	  if (maxcakenum + elapsed < lowest)	    
 	      lowest=maxcakenum + elapsed;
 	}
       assert(save >= lowest);
       printf("Case #%d: %d\n",casen, lowest);
     }
   return 0;
 }

