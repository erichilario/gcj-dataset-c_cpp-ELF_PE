#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 #define i 2
 #define j 3
 #define k 4
 
 int tabla[5][5]={
   {0, 0, 0, 0, 0},
   {0, 1, i, j, k},
   {0, i, 1, k, j},
   {0, j, k, 1, i},
   {0, k, j, i, 1}
 };
 
 int signos[5][5]={
   {1, 1, 1, 1, 1},
   {1, 1, 1, 1, 1},
   {1, 1, -1, 1, -1},
   {1, 1, -1, -1, 1},
   {1, 1, 1, -1, -1}
 };
 
 int maximo;
 int anterior;
 char cadena[1000000000];
 
 int generar(int simbolo, int inicio){
   char siguiente[2]="";
   int signo=1;
   while(inicio<maximo){
     siguiente[0]=cadena[inicio];
     signo*=signos[anterior][atoi(siguiente)];
     anterior=tabla[anterior][atoi(siguiente)];
     if((anterior==simbolo)&&(signo==1))
       break;
     inicio++;
   }
   return inicio;
 }
 
 int main(void){
   int T, ii, L, X, jj, flg, inicioI, inicioJ, inicioK, fin;
   char cadenaCorta[10000];
   scanf("%d", &T);
   for(ii=1; ii<=T; ii++){
     scanf("%d", &L);
     scanf("%d", &X);
     scanf("%s", cadenaCorta);
     for(jj=0; jj<L; jj++)
       if(cadenaCorta[jj]=='i')
 	cadenaCorta[jj]='2';
       else if(cadenaCorta[jj]=='j')
 	cadenaCorta[jj]='3';
       else if(cadenaCorta[jj]=='k')
 	cadenaCorta[jj]='4';
     strcpy(cadena, cadenaCorta);
     for(jj=1; jj<X; jj++)
       strncat(cadena, cadenaCorta, L);
     maximo=L*X;
     flg=1;
     inicioI=0;
     anterior=1;
     while((inicioI<maximo)&&flg){
       inicioJ=generar(i, inicioI)+1;
       anterior=1;
       while((inicioJ<maximo)&&flg){
 	inicioK=generar(j, inicioJ)+1;
 	anterior=1;
 	while((inicioK<maximo)&&flg){
 	  fin=generar(k, inicioK)+1;
 	  if(fin==maximo)
 	    flg=0;
 	  anterior=k;
 	  inicioK=fin;
 	}
 	anterior=j;
 	inicioJ=inicioK;
       }
       anterior=i;
       inicioI=inicioJ;
     }
     printf("Case #%d: ", ii);
     if(flg)
       printf("NO\n");
     else
       printf("YES\n");
   }
   return 0;
 }

