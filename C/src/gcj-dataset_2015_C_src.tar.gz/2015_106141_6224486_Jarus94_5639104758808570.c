#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 
 int main()
 {
 	int n,m;
 	int ptr[1005];
 	int x=0;
 	int count =0;
 	char s[1005];
 	char ch;
 	int sn=1;
 	scanf("%d",&n);
 	for(int i=0;i<n;i++)
 	{count=0;
 		x=0;
 		scanf("%d",&m);
 		scanf("%s",s);
 		for(int j=0;j<=m;j++)
 		{
 			ch = s[j];
 			ptr[j] = ch -'0';
 		}
 		for(int j=0;j<=m;j++)
 		{
 			if(ptr[j]>0)
 			{
 				if(j<=x){x=x+ptr[j];}
 				else
 					{	count = count + (j-x);
 						x=j+ptr[j];
 					}
 			}					
 		}
 		printf("Case #%d: %d\n",sn,count);
 		sn++;
 	}
 	return 0;
 }
 			

