/*
 language used : C
 source of stdio.h file : http://www.nongnu.org/avr-libc/user-manual/stdio_8h_source.html
 source of stdlib.h file : http://www.nongnu.org/avr-libc/user-manual/stdlib_8h_source.html
 */
 #include<stdio.h>
 #include<stdlib.h>
 int main(){
 int t,max,y=1,i,count;
 long long int x,r;
 long long int s[1001];
 FILE *fp ,*fw;
 fp=fopen("A-large.in","r");
 fw=fopen("output2.txt","w");
 if(fp == NULL){
     printf("cantopen file");
     exit(1);
 }
 fscanf(fp,"%d",&t);
 while(t--){
         r=0;
     fscanf(fp,"%d %lld",&max,&x);
     i=max;
     while(x>0 || i>=0){
         s[i]=x%10;
         x=x/10;
         i--;
     }
     count =s[0];
     for(i=1;i<=max;i++){
         if(count<i){
             x=i-count;
             r+=x;
             count+=s[i]+x;
         }
         else count+=s[i];
     }
     fprintf(fw,"Case #%d: %lld\n",y++,r);
 }
 fclose(fp);
 fclose(fw);
 return 0;
 }

