#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int main()
 {
 	int T, size, i, counter;
 	int sum, number, requirement, totRequirement;
 	char fileName[20];
 	char input[1000];
 	FILE *fp, *fo;
 
 	printf("Enter the filename:");
 	scanf("%s", fileName);
 
 	fp = fopen(fileName, "r");
 	fo = fopen("ans", "w");	
 
 
 	fscanf(fp, "%d", &T);
 
 	counter = 1;
 
 	while(T > 0)
 	{
 		sum = 0;
 		requirement = 0;
 		totRequirement = 0;
 		fscanf(fp, "%d %s", &size, input);
 		
 		printf("Size is: %d\n", size);
 		printf("Input is: %s\n", input);  
 		
 		for(i = 0; i < strlen(input); i++)
 		{
 			number = input[i] - 48;
 
 			printf("Processing number %d\n", number);
 			if(number > 0 && sum >= i)
 			{
 				sum = sum + number;
 			}
 			else if (number > 0)
 			{
 				
 				requirement = i - sum;
 				totRequirement = totRequirement + requirement;
 				sum = sum + requirement + number;
 				
 			}
 			else
 			{
 
 			}
 
 			printf("Sum is %d\n", sum);
 			printf("Requirement is %d\n", requirement);
 		}
 
 		fprintf(fo, "Case #%d:", counter);
 		fprintf(fo, " %d\n", totRequirement);		
 		
 		counter++;
 		T--;
 	}  
 
 	fclose(fo);
 	return 0;
 }

