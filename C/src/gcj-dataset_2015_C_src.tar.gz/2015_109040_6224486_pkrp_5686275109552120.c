#include<stdio.h>
 void quicksort(int x[],int first,int last)
 {
 	int pivot,j,temp,i;
 	if(first<last)
 	{
 		pivot=first;
     	i=first;
     	j=last;
     	while(i<j)
 		{
     		while(x[i]>=x[pivot]&&i<last)
         	i++;
         	while(x[j]<x[pivot])
         	j--;
         	if(i<j)
 			{
         		temp=x[i];
             	x[i]=x[j];
             	x[j]=temp;
         	}
      	}
      	temp=x[pivot];
      	x[pivot]=x[j];
      	x[j]=temp;
      	quicksort(x,first,j-1);
      	quicksort(x,j+1,last);
     }
 }
 int main()
 {
 	FILE *fp1,*fp2;
 	int t,d,tm,i,c=1;
 	fp1=fopen("B-small-attempt1.in","r");
 	fp2=fopen("short.txt","w");
 	fscanf(fp1,"%d",&t);
 	while(t--)
 	{
 		long a[1001]={0};
 		int b[1001],k=-1,nxt,time,sp=0;
 		fscanf(fp1,"%d",&d);
 		for(i=0;i<d;++i)
 		{
 			fscanf(fp1,"%d",&tm);
 			if(!a[tm])
 			b[++k]=tm;
 			++a[tm];
 		}
 		quicksort(b,0,k);
 		time=b[0]+sp;
 		while(1)
 		{
 			if(b[0]%2==0)
 			{
 				if(k==0)
 				nxt=b[0]/2;
 				else if(b[1]<b[0]/2)
 				nxt=b[0]/2;
 				else nxt=b[1];
 			
 				if(a[b[0]]+nxt+sp<=time)
 				{
 					sp+=a[b[0]];
 					tm=b[0];
 									
 					if(a[b[0]/2])
 					b[0]=b[k--];
 					else
 					b[0]/=2;
 					
 					a[tm/2]+=2*a[tm];
 					a[tm]=0;
 					
 					quicksort(b,0,k);
 					time=b[0]+sp;
 				}
 				else break;
 			}
 			else
 			{
 				if(k==0)
 				nxt=b[0]/2+1;
 				else if(b[1]<(b[0]/2+1))
 				nxt=b[0]/2+1;
 				else nxt=b[1];
 			
 				if(a[b[0]]+nxt+sp<=time)
 				{
 					sp+=a[b[0]];
 					tm=b[0];
 									
 					if(a[b[0]/2] && a[b[0]/2+1])
 					b[0]=b[k--];
 					else if(a[b[0]/2])
 					b[0]=b[0]/2+1;
 					else if(a[b[0]/2+1])
 					b[0]/=2;
 					else
 					{
 						b[0]/=2;
 						b[++k]=b[0]+1;
 					}
 					
 					a[tm/2]+=a[tm];
 					a[tm/2+1]+=a[tm];
 					a[tm]=0;
 					
 					quicksort(b,0,k);
 					time=b[0]+sp;
 				}
 				else break;
 			}
 		}
 		fprintf(fp2,"Case #%d: %d\n",c++,time);
 	}
 	
 	fclose(fp1);
 	fclose(fp2);
 	return 0;
 }

