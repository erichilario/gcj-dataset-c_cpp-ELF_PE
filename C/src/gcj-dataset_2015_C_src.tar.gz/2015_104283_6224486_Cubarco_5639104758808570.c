#include <stdio.h>
 
 int main(int argc, char **argv)
 {
     int T,i,j,count,sm,sdu;
     char c;
     scanf("%d", &T);
     getchar();
     for (i=0; i<T; i++) {
         scanf("%d", &sm);
         getchar();
         count = 0;
         sdu = 0;
         for (j=0; j<=sm; j++) {
             c = getchar();
             if ( c - '0' > 0) {
                 if (sdu < j)
                     count += j-sdu;
                 sdu += count + c - '0';
             }
         }
         printf("Case #%d: %d\n", i+1, count);
     }
 
     return 0;
 }

