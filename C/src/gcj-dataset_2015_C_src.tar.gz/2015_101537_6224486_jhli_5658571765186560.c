#include <stdlib.h>
 #include <stdio.h>
 
 int main(void) {
 
   int t, i;
   int winner; // 1 = GABRIEL, 2 = RICHARD
   int x, r, c;
 
   scanf("%d", &t);
 
   for (i=1; i<=t; i++) {
 
     scanf("%d %d %d", &x, &r, &c);
 
     winner = 0;
 
     if (x == 1) winner = 1;
     if (x == 2) {
       if ((r*c)%2) winner = 2;
       else winner = 1;
     }
     if (x == 3) {
       if ((r*c)%3) winner = 2;
       else if (r == 1 || c == 1) winner = 2;
       else winner = 1;
     }
     if (x == 4) {
       if ((r*c)%4) winner = 2;
       else if (r <= 2 || c <= 2) winner = 2;
       else winner = 1;
     }
 
     printf("Case #%d: ", i);
     if (winner == 1) printf("GABRIEL\n");
     else if (winner == 2) printf("RICHARD\n");
 
   }
 
   return 0;
 }

