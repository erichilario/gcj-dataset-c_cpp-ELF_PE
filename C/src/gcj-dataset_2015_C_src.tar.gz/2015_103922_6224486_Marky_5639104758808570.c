#include<stdio.h>
 int main(){
 	int t, i;
 	scanf("%i",&t);
 	for(i=1; i <= t; i++){
 		int a, n, j;
 		char s[1024];;
 		scanf("%i%s", &a, s);
 		for(j=a=n=0; s[j]; j++){
 			int p = j<n ? 0 : j-n;
 			a += p;
 			n += s[j]-'0' + p;
 		}
 		printf("Case #%i: %i\n", i, a);
 	}
 }
