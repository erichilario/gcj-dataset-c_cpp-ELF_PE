/* 
  * File:   main.c
  * Author: mm
  *
  * Created on April 11, 2015, 4:46 PM
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 /*
  * 
  */
 int main(int argc, char** argv) {
 
     int i,cases,shy,pers,need,j;
     char aux;
     FILE* input=fopen("fich.in","r");
     FILE* output=fopen("fich.out","w");
 
     fscanf(input,"%d",&cases);
     
     for(i=0;i<cases;i++){
         need=0;
         pers=0;
         shy=0;
         fscanf(input,"%d",&shy);
         fscanf(input,"%c",&aux);
         for(j=0;j<=shy;j++){
             fscanf(input,"%c",&aux);
             
             while(pers<j && aux>0){
                 pers++;
                 need++;  
             }
             pers+=atoi(&aux);
         }
         fprintf(output,"Case #%d: %d\n",i+1,need);
         
     }
     
     
     return (EXIT_SUCCESS);
 }
 
 
  

