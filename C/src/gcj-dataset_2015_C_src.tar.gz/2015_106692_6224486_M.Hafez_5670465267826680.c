#include <stdio.h>
 #include <stdlib.h>
 
 int sign(int i)
 {
 	if (i > 0)
 		return 1;
 	if (i < 0)
 		return -1;
 	return 0;	
 }
 
 int abs(int i)
 {
 	if (i < 0)
 		return -i;
 	return i;	
 }
 
 int map(char i)
 {
 	switch(i)
 	{
 		case 'i':
 			return 2;
 		case 'j':
 			return 3;
 		case 'k':
 			return 4;
 		default:
 			return 1;	
 	}
 	return 1;
 }
 
 int main()
 {
 	int T, k = 0;
 	int L, X;
 	int i, j;
 	int current_state;
 	int signal;
 	int accepting_states [4] = {2, 3, 4, 1};
 	int accepting_state_index;
 	char input [10000];
 	int parse_table [5][5] = {{0, 0, 0, 0, 0}, {0, 1, 2, 3, 4}, {0, 2, -1, 4, -3}, {0, 3, -4, -1, 2}, {0, 4, 3, -2, -1}};
 	scanf("%d",&T);
 
 	while(k++ < T)
 	{
 		scanf("%d %d", &L, &X);
 		scanf("%s", input);
 		i = j = 0;
 		current_state = 1;
 		accepting_state_index = 0;
 		signal = 1;
 		while(i < X)
 		{
 			while(j < L)
 			{
 				current_state = parse_table[current_state][map(input[j])];
 				signal *= sign(current_state);
 				current_state = abs(current_state);
 				if (signal > 0 && accepting_state_index < 3 && current_state == accepting_states[accepting_state_index])
 				{
 						accepting_state_index ++;
 						current_state = 1;
 				}
 				j ++;
 			}
 			j = 0;
 			i ++;
 		}
 		if (signal > 0 && current_state == 1 && accepting_state_index == 3)
 			printf("Case #%d: YES\n", k);
 		else
 			printf("Case #%d: NO\n", k);
 	}
 	return 0;
 }

