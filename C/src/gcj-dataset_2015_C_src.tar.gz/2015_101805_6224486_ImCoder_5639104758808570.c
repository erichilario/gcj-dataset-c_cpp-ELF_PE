#include<stdio.h>
 int main()
 {
     int test,x,y,n,i,j;
     char str[1002];
     #ifndef ONLINE_JUDGE
     freopen("input.txt","r",stdin);
     freopen("output.txt","w",stdout);
     #endif
     scanf("%d",&test);
     for(j=0;j<test;j++)
     {
         scanf("%d",&n);
         x=y=0;
         scanf("%s",str);
         for(i=0;i<=n;i++)
         {
             if(x<i && i>x+y)
                 y=i-x;
             x=x+str[i]-48;
         }
         printf("Case #%d: %d\n",j+1,y);
     }
     return 0;
 }

