#include <stdio.h>
 
 #define forn(i, n) for(i=0; i<n; i++)
 #define forj(i, j, n) for(i=j; i<n; i++)
 
 int get_max(int *p, int n) {
 	int i;
 	int max = 0;
 	forn(i, n)
 		max = (max > p[i])? max : p[i];
 	return max;
 }
 
 int empty(int *p, int n) {
 	int i;
 	forn(i, n)
 		if(p[i] != 0) return 0;
 	return 1;
 }
 
 int foo(int *p, int n) {
 	int max, i, minutes = 0;
 	while(!empty(p, n)) {
 		max = get_max(p, n);
 		if(max%2 == 0) {
 			forn(i, n)
 				if(p[i]%2 ==0)
 					p[i] /= 2;
 		} else {
 			forn(i, n)
 				if(p[i] > 0) p[i]--;
 		}
 		minutes++;
 	}
 	return minutes;
 }
 
 
 int main() {
 	int T;
 	scanf("%d", &T);
 	int D, index = 1;
 	while(T--) {
 		scanf("%d", &D);
 		int p[1000] = {0}, i;
 		forn(i, D)
 			scanf("%d", &p[i]);
 		printf("Case #%d: %d\n", index++, foo(p, D));
 	}
 	return 0;
 }
