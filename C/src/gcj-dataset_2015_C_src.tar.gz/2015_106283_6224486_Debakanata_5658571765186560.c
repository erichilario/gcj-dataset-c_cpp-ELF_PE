#include<stdio.h>
 #include<stdlib.h>
 
 #define N 100
 #define B 20
 
 int cube[B][B];
 
 char line[N];
 int  info[3];
 char temp[20];
 void omino_winner(int,int,int);
 
 int main(){
   size_t len = 0;
   int no_line=0,k=0,j=0,i=0,z=0,x=0;
   char *ptr=NULL;
   FILE *ptr_file;
 
   ptr_file =fopen("D-small-attempt0.in","r");
   if (!ptr_file)
       return 1;
 
   if(fgets(line,N, ptr_file)!=NULL)
       no_line=atoi(line);
   //printf("%d",no_line);
   for(i=1;i<=no_line;i++){
 	   printf("Case #%d: ",i);
      if(fgets(line,N, ptr_file)!=NULL)
      //printf("%s \n",line);
      for(z=0,j=0,k=0;line[z]!='\n';z++){
        if(line[z] == ' '){
          temp[j]='\0';
          info[k++]=atoi(temp);
          j=0;
        }
        else
          temp[j++]=line[z];
     }
     temp[j]='\0';
     info[k++]=atoi(temp);
     //for(x=0;x<3;x++)
       //printf("%d ",info[x]);
     omino_winner(info[0],info[1],info[2]);
     printf("\n");
   }
   return 1;
 }
 
 void omino_winner(int nblock,int row,int col){
     int b=0,sum=0;
     b=row*col;
     sum=2*nblock;
     if(sum==b)
       printf("GABRIEL");
     else
       printf("RICHARD");
 }

