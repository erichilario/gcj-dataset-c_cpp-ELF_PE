#include<stdio.h>
 int main()
 {
 	int t,shy,i,j,cnt,sum,temp;
 	char s[1001];
 	scanf("%d",&t);
 	for(j=1;j<=t;j++)
 	{
 		scanf("%d",&shy);
 		scanf("%s",s);
 		sum=0;temp=0;cnt=0;
 		for(i=0;s[i]!='\0';i++)
 		{
 			if(i>sum&&s[i]!='0')
 			{
 				temp=i-sum;
 				sum+=temp;
 				cnt+=temp;
 			}
 			sum+=s[i]-48;
 		}
 		printf("Case #%d: %d\n",j,cnt);
 	}
 	return 0;
 }

