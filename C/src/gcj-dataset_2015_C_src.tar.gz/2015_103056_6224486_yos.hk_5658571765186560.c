#include <stdio.h>
 #include <math.h>
 
 int main()
 {
 	int i,j,k,m,n,t,T;
 	int w;
 	int X,R,C;
 	char *win[2];
 	
 	win[0]="RICHARD";
 	win[1]="GABRIEL";
 	
 	fscanf(stdin, "%d", &T);
 	
 	for(t=1;t<=T;t++)
 	{
 		fscanf(stdin, "%d%d%d", &X,&R,&C);
 		if(R>C) 
 		{
 			m=C; C=R; R=m;
 		}
 		
 		w=1;
 		if(R*C%X!=0) w=0;	
 		if(R*C<X*2) w=0;
 		if(X==4 && R==1) w=0;
 		if(X==4 && R==2) w=0;
 		if(X==4 && R==3) w=0;
 		if(X==4 && R==4) w=0;
 		if(X>=7) w=0;
 		if(R<ceil(X/2)) w=0;
 		//printf("Case #%d: %d %d %d %s\n", t, X,R,C,win[w]);
 		printf("Case #%d: %s\n", t, win[w]);
 	}
 
 }

