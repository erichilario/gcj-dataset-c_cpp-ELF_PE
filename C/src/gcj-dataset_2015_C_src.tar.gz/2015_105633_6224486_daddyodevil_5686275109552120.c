#include "stdio.h"
 #include "stdlib.h"
 int d;
 int max(int *);
 void main()
 {
     FILE *f2 = fopen("i.txt", "r");
     FILE *f1 = fopen("o.txt", "w");
     int t,c,v=0,u,cnt=0;
     int i,d,f=0,h,tt,k;
     int a[2000],b[2000],col[100];
     for(i=0;i<2000;i++)
     {
         a[i] = 0;
         b[i] = 0;
     }
     for(i=0;i<100;i++)
         col[i] = 0;
     fscanf(f2, "%d",&t);
     tt=t;
     while(t>0)
     {
         fscanf(f2, "%d",&d);
         for(i=0;i<d;i++)
         {
             fscanf(f2, "%d",&a[i]);
             b[i]=a[i];
         }
         for(h=1;h>0;h++)
         {
             k=0;
             for(i=0;i<d-1;i++)
             {
                 if(a[i] < a[i+1])
                     k=i+1;
             }
             c=a[k]/2;
             b[d]=c;
             b[k]=a[k]-c;
             for(i=0;i<d;i++)
             {
                 if(b[i] < b[i+1])
                     f=i+1;
             }
             if(a[k] <= (1+b[f]))
             {
                 col[v]=a[k]+cnt;
                 v++;
                 break;
             }
             else
             {
                 for(u=0;u<d+1;u++)
                     a[u]=b[u];
                 cnt++;
                 d++;
             }
         }
         t--;
     }
     for(h=0;h<tt;h++)
         fprintf(f1, "Case #%d: %d \n",(h+1),(col[h]));
 }
 
 

