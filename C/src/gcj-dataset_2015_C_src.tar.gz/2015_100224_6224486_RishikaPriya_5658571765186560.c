#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #define MAX_SIZE 10
 #define SIZE 70
 
 int main()
 {
 	int T,X,R,C,result[SIZE]={0},index1;
 	
 	scanf("%d",&T);
 	for(index1=0;index1<T;index1++)
 	{
 		scanf("%d%d%d",&X,&R,&C);
 		if(X==1 && R==1 && C==1)
 			result[index1]=1;
 		if(X==2 && (R==2||R==4||(R==1&&(C==2||C==4))||(R==3&&(C==2||C==4))))
 			result[index1]=1;
 		if(X==3 && ((R==3&&(C==2||C==4))||(C==3&&(R==2||R==4))||(R==3&&C==3)))
 			result[index1]=1;
 		if(X==4 && ((R==4&& C==3)||(C==4&&R==3)||(R==4&&C==4)))
 			result[index1]=1;
 	}
 	for(index1=0;index1<T;index1++)
 	{
 		if(result[index1]==1)
 			printf("Case #%d: GABRIEL\n",index1+1);
 		else
 			printf("Case #%d: RICHARD\n",index1+1);	
 	}
 	return 0;
 }

