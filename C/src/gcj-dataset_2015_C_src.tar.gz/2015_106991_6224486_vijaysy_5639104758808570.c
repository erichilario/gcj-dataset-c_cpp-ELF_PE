#include <stdio.h>
 int main(){
 
 FILE *fpI,*fpO;
 int i,k;
 int n,tmpN;
 int Sh[1002];
 char ShD[1002][1002];
 int count2=0,tmpC=0;
 
 
     fpI=fopen("A-large.in","r");
     fpO=fopen("output2.txt","w");
 
     fscanf(fpI,"%d",&n);
     tmpN=n;
 
     for(i=0;i<tmpN;i++){
 
         fscanf(fpI,"%d",&Sh[i]);
         fscanf(fpI,"%s",ShD[i]);
         count2=0;
         for(k=0;k<=Sh[i];k++){
             count2+=(ShD[i][k]-'0');
 
             while(count2<=k){
                 tmpC++;count2++;
             }
         }
 
         fprintf(fpO,"Case #%d: %d\n",i+1,tmpC);
         tmpC=0;
 
     }
 
 
           return 0;
 }

