#include <stdlib.h>
 #include <stdio.h>
 #define swap(a, b, t) (t=a, a=b, b=t)
 #define min(a, b) a<b?a:b
 
 int comp (const void *elem1, const void *elem2) 
 {
     int f = *((int*)elem1);
     int s = *((int*)elem2);
     if (f > s) return  1;
     if (f < s) return -1;
     return 0;
 }
 
 int main(void) {
 
   int t, i, j, k, l, tmp;
   int d, pancakes[2050];
   int minsteps;
 
   scanf("%d", &t);
 
   for (i=1; i<=t; i++) {
 
     scanf("%d ", &d);
     for (j=0; j<d; j++) scanf("%d", pancakes+j);
 
     qsort(pancakes, d, sizeof(int), comp);
     minsteps = *(pancakes+d-1);
 
     //for (j=0; j<d; j++) printf("%d ", *(pancakes+j));
     //printf("\n");
 
     for (j=1; j<=1000; j++) {
       //division
       if (*(pancakes+d-1) == 1) break;
       *(pancakes+d) = *(pancakes+d-1)/2;
       *(pancakes+d-1) -= *(pancakes+d);
       //sort
       for (k=d-1; k<=d; k++) {
         for (l=k; l>0; l--) {
           if (*(pancakes+l) < *(pancakes+l-1)) swap(*(pancakes+l), *(pancakes+l-1), tmp);
           else break;
         }
       }
       //recalculer min
       minsteps = min(minsteps, j+*(pancakes+d));
       d++;
       //for (k=0; k<d; k++) printf("%d ", *(pancakes+k));
       //printf("\n min: %d, %d\n", minsteps, j+*(pancakes+d-1));
     }
 
 
 
 
     printf("Case #%d: %d\n", i, minsteps);
 
   }
 
   return 0;
 }

