#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 
 char matrix_mul(char x,char y, int flag)
 {
 	if(x == '1')
 	{
 		if(y == '1'){return '1';}
 		else if(y == 'i'){return 'i';}
 		else if(y == 'j'){return 'j';}
 		else{return 'k';}
 	}
 	else if(x == 'i')
 	{
 		if(y == '1'){return 'i';}
 		else if(y == 'i'){return '1';flag = -flag;}
 		else if(y == 'j'){return 'k';}
 		else{return 'j';flag = -flag;}
 	}
 	else if(x == 'j')
 	{
 		if(y == '1'){return 'j';}
 		else if(y == 'i'){return 'k';flag = -flag;}
 		else if(y == 'j'){return '1';flag = -flag;}
 		else{return 'i';}
 	}
 	else
 	{
 		if(y == '1'){return 'k';}
 		else if(y == 'i'){return 'j';}
 		else if(y == 'j'){return 'i';flag = -flag;}
 		else{return '1';flag = -flag;}
 	}
 }
 
 int main()
 {	int n,l,x,limit1,limit2;
 	int flag;
 	char *s1;
 	char *s2;
 	char z1;
 	scanf("%d",&n);
 	for(int i=0;i<n;i++)
 	{
 		scanf("%d %d",&l,&x);
 		s1=(char *)malloc((l*x)*sizeof(char));
 		s2=(char *)malloc(l*sizeof(char));
 		scanf("%s",s2);
 		for(int j=0;j<x;j++)
 		{
 				strcat(s1,s2);
 		}
 		z1=s1[0];
 		limit1 = 1;
 		flag=1;
 		while(z1 != 'i' && limit1<((l*x)-2) && flag == 1)
 		{
 			z1 = matrix_mul(z1,s1[limit1],flag);
 			limit1++;
 		}
 		if(z1 != 'i'){printf("Case #%d: NO\n",i+1);}
 		else
 		{	flag=1;
 			z1 = s1[(l*x)-1];
 			limit2 = (l*x)-2;
 			while(z1 != 'k' && limit2>limit1 && flag == 1)
 			{
 				z1 = matrix_mul(z1,s1[limit2],flag);
 				limit2--;
 			}
 			if(z1 !='k'){printf("Case #%d: NO\n",i+1);}
 			else
 			{	flag=1;
 				z1=s1[limit1];
 				for(int j=limit1+1;j<=limit2;j++)
 				{
 					z1=matrix_mul(z1,s1[j],flag);
 				}
 				if(z1 == 'j' && flag == 1){printf("Case #%d: Yes\n",i+1);}
 				else{printf("Case #%d: NO\n",i+1);}
 			}
 		}
 	}
 return 0;
 }
 

