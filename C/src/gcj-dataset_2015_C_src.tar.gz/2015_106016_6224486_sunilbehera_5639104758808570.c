#include<stdio.h>
 #include<stdlib.h>
 void main()
 {
     int t=0,i=0,j=0,smax,sp1,tas,res,fnd,q;
     char st[1000];
     FILE * infile;
     FILE * outfile;
     infile=fopen("in.in","r");
     outfile=fopen("out.out","w");
     fscanf(infile,"%d",&t);
     for(i=0;i<t;i++)
     {
         smax=0;
         sp1=0;
         tas=0;
         res=0;
         fnd=0;;
         fscanf(infile,"%d",&smax);
         fscanf(infile,"%s",&st);
         sp1=smax+1;
         tas=st[0]-48;
         j=1;
         for(j=0;j<smax;j++)
         {
             if(j>tas)
             {
                 fnd++;
                 tas++;
             }
             tas=tas + (int)st[j]-48;
             if(tas>=smax)
                 break;
         }
 
         fprintf(outfile,"Case #%d: %d\n",i+1,fnd);
         //fprintf(outfile,"%s\n",st);
     }
     fclose(infile);
     fclose(outfile);
 }

