#include <stdio.h>
 
 #define max(a,b) ((a) > (b) ? (a) : (b))
 #define min(a,b) ((a) < (b) ? (a) : (b))
 #define N 1001
 
 int main()
 {
     int i,j,n,f[N],ans,Case=0,MAX,n1,i1;
 
     scanf("%d", &n1);
 
     for (i1=0; i1<n1; i1++) {
         scanf("%d", &n);
         MAX=0;
         for (i=1; i<=n; i++) {
             scanf("%d", &f[i]);
             MAX = max(MAX, f[i]);
         }
 
         ans = N;
         for (i=1; i<=MAX; i++) {
             int tmp=i;
             for (j=1; j<=n; j++) {
                 if (f[j] > i) {
                     if (f[j] % i == 0)
                         tmp += f[j]/i-1;
                     else
                         tmp += f[j]/i;
                 }
             }
             ans = min(ans, tmp);
         }
         printf("Case #%d: %d\n", ++Case, ans);
     }
 
     return 0;
 }

