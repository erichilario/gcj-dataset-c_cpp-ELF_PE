// standing ovations
 //
 
 #include <stdio.h>
 
 
 int main(){
 
 	int t;
 	scanf(" %d ", &t);
 
 	int i, j, s_max, total, sum;
 	for(i = 0; i < t; i++){
 		scanf(" %d ", &s_max);
 		
 		total = 0; sum = 0;
 		for(j = 1; j <= s_max + 1; j++){
 			sum += getchar() - 48;
 			if( sum < j ){
 				sum++; total++;
 			}
 		}
 		printf("Case #%d: %d\n", i+1, total);
 	}
 
 	return 0;
 }

