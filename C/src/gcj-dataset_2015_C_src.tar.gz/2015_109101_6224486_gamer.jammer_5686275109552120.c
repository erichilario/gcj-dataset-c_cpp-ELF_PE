#include <stdio.h>
 
 int max(int *);
 
 int main()
 {
 	int t, d, i, j, best_time, temp_time, mx, a;
 
 	scanf("%d", &t);
 
 	for(i = 0; i < t; i++)
 	{
 		scanf("%d", &d);
 		int p[10] = {0};
 
 		for(j = 0; j < d; j++)
 		{
 			scanf("%d", &a);
 			p[a]++;
 		}
 
 		best_time = mx = max(p);
 		temp_time = 0;
 		while(mx > 3)
 		{
 			temp_time += p[mx];
 			p[mx / 2] += p[mx];
 			p[mx - (mx / 2)] += p[mx];
 			p[mx] = 0;
 			mx = max(p);
 			if(temp_time + mx < best_time)
 				best_time = temp_time + mx;
 		}
 
 		printf("Case #%d: %d\n", i + 1, best_time);
 	}
 
 }
 
 int max(int a[])
 {
 	int i, mx = 0;
 	for(i = 1; i < 10; i++)
 		if(a[i] != 0)
 			mx = i;	
 	return mx;
 }

