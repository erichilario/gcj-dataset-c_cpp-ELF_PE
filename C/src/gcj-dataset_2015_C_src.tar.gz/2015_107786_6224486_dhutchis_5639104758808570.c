#include <stdio.h>
 #include <stdlib.h>
 int main()
 {
   int T,maxshy,cnt,addf,shy,cur,t;
   scanf("%d",&T);
   for (t=1;t<=T;t++)
     {
       scanf("%d ",&maxshy);
       do {
       cur = getchar();
       } while (cur == ' ');
       ungetc(cur,stdin);
 
       cnt=addf=0;
       for (shy=1;shy<=maxshy;shy++) {
 	//int c;
 
 	cur = getchar() - '0';
 	//scanf("%d",&cur);
 	//printf("cur is %d\n",cur);
 	cnt += cur;
 	if (cnt<shy) {
 	  addf++;
 	  cnt++;
 	}
       }
       cur = getchar();
       //printf("throwaway: %c\n",cur);
       cur = getchar();
       //printf("throwaway: %c\n",cur);
       //Scanf("%d",&cur); // last one on line
 			
       printf("Case #%d: %d\n",t,addf);
     }
   return 0;	
 }

