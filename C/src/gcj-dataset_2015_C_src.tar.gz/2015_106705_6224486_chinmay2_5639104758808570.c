#include<stdio.h>
 #include<malloc.h>
 
 int main()
 {
 	int t, j;
 	int n;
 	char *s;
 	
 	int i, current, required;
 	
 	FILE *fp1 = fopen("A-large.in", "r");
 	FILE *fp2 = fopen("A-large.out", "w");
 	
 	fscanf(fp1, "%d", &t);
 	
 	for(j=1; j<=t; j++)
 	{
 		fscanf(fp1, "%d", &n);
 		
 		s = (char*)malloc(sizeof(char)*(n+2));
 		
 		fscanf(fp1, "%s", s);
 		
 		required = 0;
 		current = s[0] - '0';
 		for(i=1; i<n+1; i++)
 		{
 			if(current < i)
 			{
 				required += (i - current);
 				current += (i - current);
 			}
 			
 			current += (s[i] - '0');
 		}
 		
 		fprintf(fp2, "Case #%d: %d\n", j, required);
 	}
 	
 	fclose(fp1);
 	fclose(fp2);
 	
 	return 0;
 }
 

