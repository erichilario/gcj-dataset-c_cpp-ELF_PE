#include <stdio.h>
 #include <stdlib.h>
 
 int eat(int* arr,int n)
 {
 	int arr_tmp[100];
 	int i,cnt=0;
 	for(i=0 ; i<n ; i++)
 	{
 		arr_tmp[cnt] = arr[i]-1;
 		if(arr_tmp[cnt]!=0)
 		{
 			cnt++;
 		}
 	}
 	for(i=0;i<cnt;i++)
 		arr[i] = arr_tmp[i];
 	return cnt;
 }
 int split(int* arr, int n)
 {
 	int max;
 	int i,j;
 	int cnt=n;
 	int arr_tmp[100];
 	for(max=0,i=0 ; i<n ; i++)
 	{
 		if(max==0 || arr[i] > max)
 		{
 			if(arr[i]%2 == 0)
 			{
 				max = arr[i];
 				j=i;
 			}
 		}
 	}
 	if(max!=0)
 	{
 		cnt++;
 		arr[j] = arr[j]/2;
 		arr[n] = arr[j];
 	}
 
 	return cnt;
 }
 
 int recu(int* arr, int cnt)
 {
 	int tmp[100];
 	int tmp2[100];
 	int i;
 	int t1,t2;
 	int result1,result2;
 	
 	if(cnt == 0)
 		return 0;
 
 	for(i=0;i<cnt;i++)
 	{
 		tmp[i] = arr[i];
 		tmp2[i] = arr[i];
 	}
 
 	t1 = eat(tmp,cnt);
 	t2 = split(tmp2,cnt);
 
 	if(t2 == cnt)
 		return recu(tmp,t1)+1;
 	else
 	{
 		result1 = recu(tmp,t1);
 		result2 = recu(tmp2,t2);
 
 		if(result1 < result2)
 			return result1+1;
 		else 
 			return result2+1;
 	}
 }
 
 int main()
 {
 	FILE* f = fopen("B-small-attempt2.in.txt","r");
 	FILE* fp = fopen("result.txt","w");
 	int T,D;
 	int n;
 	int i,j;
 	int result;
 	int max;
 	int arr[100];
 
 	fscanf(f,"%d",&T);
 	for(n=0 ; n<T ; n++)
 	{
 		fscanf(f,"%d",&D);
 		for(i=0 ; i<D ; i++)
 			fscanf(f,"%d",&arr[i]);
 		result = recu(arr,D);
 		fprintf(fp,"Case #%d: %d\n",n+1,result);
 	}
 	fclose(fp);
 	fclose(f);
 	return 0;
 }
