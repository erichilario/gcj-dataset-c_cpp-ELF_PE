#include<stdio.h>
 #include<stdlib.h>
 #define pf printf
 #define sf scanf
 #define N 1004
 
 int main()
 {
 	int i, j, t, SiMax, currentStandingPeople, friends;;
 	char string[N];
 	
 	sf("%d", &t);
 	for(i = 1; i <= t; i++){
 		sf("%d", &SiMax);
 		sf("%s", string);
 		//pf("simax --> %d", SiMax);
 		//pf("string--> %s", string);
 		currentStandingPeople = friends = 0;
 		/*for(i = 0; string[i] != '\0'; i++)
 			if(string[i] != '0')
 				numberOfPeople++;*/
 		for(j = 0; j <= SiMax; j++){
 			if(string[j] != '0'){
 				if(currentStandingPeople >= j)
 					currentStandingPeople = currentStandingPeople + string[j] - '0';
 				else{
 					while(currentStandingPeople < j){
 						currentStandingPeople++;
 						friends++;
 					}
 					currentStandingPeople = currentStandingPeople + string[j] - '0';
 				}
 			}
 		}
 		pf("Case #%d: %d\n", i, friends); 
 	}
 	
 	return 0;
 }

