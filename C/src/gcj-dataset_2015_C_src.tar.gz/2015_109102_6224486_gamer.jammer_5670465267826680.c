#include <stdio.h>
 #include <math.h>
 
 int look_up[5][5] = {   {0, 0, 0, 0, 0},
 						{0, 1, 2, 3, 4},
 						{0, 2, -1, 4, -3},
 						{0, 3, -4, -1, 2},
 						{0, 4, 3, -2, -1}
 					};
 
 int main()
 {
 	int t, i, j;
 
 	long l, x;
 	char str[10001];
 
 	scanf("%d", &t);
 	for(j = 0; j < t; j++)
 	{
 		int flagi, flagj, flagk;
 		flagi = flagj = flagk = 0;
 		int prod = 1;
 		scanf("%ld %ld", &l, &x);
 		scanf("%s", str);
 		for(i = 0; i < l * x; i++)
 		{
 			prod = look_up[abs(prod)][str[i % l] + 2 - 'i'] * (prod / abs(prod));
 			if(flagi == 0 && (prod + 'i' - 2 == 'i'))
 				flagi = 1;
 			else if(flagi == 1 && flagj == 0 && (prod + 'i' - 2 == 'k'))
 				flagj = 1;
 		}
 		if(flagi == 1 && flagj == 1 && flagk == 0 && prod == -1)
 			flagk = 1;
 
 		if(flagi == 1 && flagj == 1 && flagk == 1)
 			printf("Case #%d: YES\n", j + 1);
 		else
 			printf("Case #%d: NO\n", j + 1);
 	}
 }
