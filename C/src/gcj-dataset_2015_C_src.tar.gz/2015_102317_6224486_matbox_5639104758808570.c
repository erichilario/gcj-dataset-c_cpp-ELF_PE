//
 //  main.c
 //  GoogleJam
 //
 //  Created by Prat-Fourcade Matthieu on 11/04/2015.
 //  Copyright (c) 2015 matbox. All rights reserved.
 //
 
 #include <stdio.h>
 
 int NbFriends(int Smax, char Si[1001]);
 int NbPeopleLackSk(int Smax, char Si[1001], unsigned short k, int AddElement);
 int NextSi(int Smax, char Si[1001]);
 int SumElmtBeforeK(char Si[1001], unsigned short k);
 
 int main(int argc, const char * argv[]) {
     
     int NbTests=0; // T
     int Smax[100];
     char Si[100][1001];
     
     //Read inputs
     scanf("%d", &NbTests);
     
     for(unsigned char test=0; test<NbTests; test++)
     {
         scanf("%d",  &Smax[test]);
         scanf("%s", &Si[test][0]);
     }
     
     //Process output
     
     for(unsigned char test=0; test<NbTests; test++)
         printf("Case #%d: %d\n", test+1, NbFriends(Smax[test], &Si[test][0]));
     
     return 0;
 }
 
 int NbFriends(int Smax, char Si[1001])
 {
     int NbFriends=0;
     for(int i=0; i<=Smax; i++)
     {
         int Nb=NbPeopleLackSk(Smax, Si, i, NbFriends);
         if(Nb>0)
             NbFriends+=Nb;
     }
     return NbFriends;
 }
 
 int NbPeopleLackSk(int Smax, char Si[1001], unsigned short k, int AddElement)
 {
     if(k==0)
         return NextSi(Smax, Si)-(Si[0]-'0');
     else
     {
         if(Si[k]==0)
             return 0;
         else
             return  k-(SumElmtBeforeK(Si , k)+AddElement);
     }
 }
 
 //Return the next non 0 Si value in the string after k=0
 int NextSi(int Smax, char Si[1001])
 {
     for(int i=1; i<Smax+1; i++)
     {
         if(Si[i]=='\0')
             return 0;
         if(Si[i]>'0')
             return i;
     }
     return 0;
 }
 
 int SumElmtBeforeK(char Si[1001], unsigned short k)
 {
     int total=0;
     for(int i=0; i<k; i++)
         total+=(Si[i]-'0');
     return total;
 }
