#include <stdio.h>
 #include <string.h>
 
 int count[1005];
 
 int main() {
   int t,c,i,d,max,j,max1,r,rr;
   scanf("%d", &t);
   for (c = 1; c <= t; c++) {
     scanf("%d", &d);
     memset(count, 0, sizeof(int) * 1005);
     max = 0;
     rr = 0;
     for (i = 0; i < d; i++) {
       scanf("%d", &j);
       count[j]++;
       if (j > max) max = j;
     }
     r = max;
     while (max > 1) {
       for (i = max - 1; i >=1 ; i--) {
 	if (count[i] > 0) break;
       }
       j = max % 2 == 0 ? max / 2 : max / 2 + 1;
       if (j > i) {
 	i = j;
       }
       if (r > count[max] + i + rr) {
 	r = count[max] + i + rr;
       }
       if (max % 2 == 0) {
 	count[max/2] += 2 * count[max];
       }
       else {
 	count[max/2] += count[max];
 	count[max/2+1] += count[max];
       }
       rr += count[max];
       count[max] = 0;
       max = i;
     }
     printf("Case #%d: %d\n", c, r);
   }
   return 0;
 }

