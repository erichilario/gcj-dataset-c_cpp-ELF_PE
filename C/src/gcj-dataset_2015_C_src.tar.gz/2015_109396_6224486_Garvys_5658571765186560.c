#include <stdio.h>
 
 int main(void) {
         int nbTest;
         scanf_s("%d",&nbTest);
         int i;
         for (i=1;i<=nbTest;i++) {
             int X,R,C;
             int Res;
             // Si Res vaut 1, on affiche GABRIEL, sinon on affiche RICHARD
             scanf_s("%d%d%d",&X,&R,&C);
             int Mult;
             Mult=R*C;
             int Max;
             if (R<C) {
                 Max=C;
             }
             else {
                 Max=R;
             }
             if ((X<Mult)&&((Mult % X)==0)) {
                     if (((R>(X/2))&&(C>(X/2)))||(X<=(Max-(X/2)))) {
                         Res=1;
                     }
                     else {
                         Res=0;
                     }
             }
             else {
                 if ((X==2)&&(Mult==2)) {
                     Res=1;
                 }
                 else if ((X==1)&&(Mult==1)) {
                     Res=1;
                 }
                 else {
                     Res=0;
                 }
             }
 
             if (Res==0) {
                 printf("Case #%d: RICHARD\n",i);
             }
             else {
                 printf("Case #%d: GABRIEL\n",i);
             }
 
         }
 	return 0;
 }

