// COdeJam try
 
 
 #include<stdio.h>
 #include<string.h>
 int main()
 {
     int test,x,r,c,i;
     int D_area,R_area;
     char sol[20];
 
     freopen("1.in","r",stdin);
     freopen("out.txt","w",stdout);
     scanf("%d",&test);
     for(i=1;i<=test;i++)
     {
         scanf("%d%d%d",&x,&r,&c);
         D_area = x;
         R_area = r*c;
 
 
         if(!(R_area%D_area))
         {
             if(R_area>D_area)
                 strcpy(sol,"GABRIEL");
         }
         else
         {
             strcpy(sol,"RICHARD");
         }
 
 
 
         printf("Case #%d: %s\n",i,sol);
     }
 
     return 0;
 }

