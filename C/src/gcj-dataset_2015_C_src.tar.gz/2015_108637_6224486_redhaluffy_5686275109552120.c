#include <stdio.h>
 #include <stdlib.h>
 
 #include "pancakes.h"
 
 int main(int argc, char** argv)
 {
   int P[1000], P2[1000];
   int T, i, D, j, time, best_time, k, max_i, l;
   int special, over;
   FILE* file = fopen(argv[1], "r");
 
   fscanf(file, "%d\n", &T);
 
   for(i=0; i<T; i++){
     printf("Case #%d: ", i+1);
     time = 0;
     over = 0;
     // read D
     fscanf(file, "%d\n", &D);
     // init P[]
     fprintf(stderr, "-1 - init    : ");
     for(j=0; j<D-1; j++){
       fscanf(file, "%d ", P+j);
       fprintf(stderr, "%2d ", P[j]);
     }
     fscanf(file, "%d\n", P+j);
     fprintf(stderr, "%2d\n", P[j]);
     for(j=j+1; j<1000; j++)
       P[j] = 0;
 
     // main resolution loop
     best_time = 100000;
     for(l=1; l<5; l++){
       time = 0;
       over = 0;
       for(j=0; j<1000; j++)
 	P2[j] = P[j];
       while(!over){
 	special = 0;
 	fprintf(stderr, "%2d - ", time);
 	// check if max(P[]) > D
 	max_i = 0;
 	for(j=1; j<D; j++){
 	  if(P2[j] > P2[max_i])
 	    max_i = j;
 	}
 	//fprintf(stderr, " P2[max]=%d; D=%d; ", P2[max_i], D);
 	if(P2[max_i] > D+l){
 	  P2[D] = P2[max_i]/2;
 	  P2[max_i] -= P2[D];
 	  D++;
 	  special = 1;
 	  fprintf(stderr, "special : ");
 	}
 	// if not special, eat
 	if(!special){
 	  fprintf(stderr, "normal  : ");
 	  over = 1;
 	  for(j=0; j<D; j++){
 	    P2[j]--;
 	    if(P2[j] > 0)
 	      over = 0;
 	  }
 	}
 	for(k=0; k<D; k++)
 	  fprintf(stderr, "%2d ", P2[k]);
 	fprintf(stderr, "\n");
 	time++;
       }
       if(time < best_time)
 	best_time = time;
     }
     printf("%d\n", best_time);
   }
 
   fclose(file);
 }

