#include<stdio.h>
 char aud[1005];
 int main()
 {
 	  int t,i,j;
 	  scanf("%d",&t);
 	  int smax;
 	  int count = 0,tmp;
 	  for(i=1;i<=t;i++)
 	  { 
 	       count = 0;
 	  	   scanf("%d",&smax);
 	  	   scanf("%s",aud);
 	  	   tmp = aud[0]-48;
 	  	   for(j=1;j<=smax;j++)
 	  	   {
 	  	   	     if(tmp<j)
 	  	   	     {
 	  	   	     	    count+=j-tmp;
 	  	   	     	    tmp+=j-tmp;
 	  	   	     	    tmp+=aud[j]-48;
 	  	   	     }
 	  	   	     else
 	  	   	     {
 	  	   	     	   tmp +=aud[j]-48;
 	  	   	     }
 	  	   }
 	  	   printf("Case #%d: %d\n",i,count);
 	  }
 	  return 0;
 }

