// Code Jam try
 
 
 #include<stdio.h>
 
 char str[1003];
 int aud[1003];
 
 int main()
 {
     int test,j,i,sum=0,cnt,Smax,val,sol;
     freopen("1.in","r",stdin);
     freopen("opt.txt","w",stdout);
     scanf("%d",&test);
 
 
     for(i=1;i<=test;i++)
     {
         sol=0,sum=0;
         scanf("%d%s",&Smax,str);
 
 
         aud[0]=0;
         for(j=1;j<=Smax;j++)
             aud[j]=str[j-1]-'0' + aud[j-1];
 
         sol = Smax-aud[Smax];
         if(sol<0)
             sol =0;
 
         for(j=Smax;j>=0;j--)
         {
             if((aud[j]+sol)<j)
                 sol+=(j-(aud[j]+sol));
         }
         printf("Case #%d:\t%d\n",i,sol);
     }
 }

