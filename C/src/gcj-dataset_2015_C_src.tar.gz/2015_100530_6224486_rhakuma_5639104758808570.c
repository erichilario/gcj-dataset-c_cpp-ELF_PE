#include <stdio.h>
 
 #define MAX_LINE_BUFFER 1024
 
 int main(int argc, char* argv[]) {
     FILE *ifile;
     FILE *ofile;
     char* filename = NULL;
     char* outfile = "output.txt";
 
     int count, i;
     int max_s;
     char aud_str[MAX_LINE_BUFFER];
     int result;
     
     if (argc != 2) {
         printf("usage: problem_a input.txt\n");
         return 1;
     }
 
     filename = argv[1];
     printf("filename: %s\n", filename);
 
     ifile = (FILE *) fopen(filename, "r");
     ofile = (FILE *) fopen(outfile, "w");
 
     fscanf(ifile, "%d", &count);
     for (i=0; i<count; i++) {
         result = 0;
 
         fscanf(ifile, "%d %s", &max_s, aud_str);
 
         result = get_need_friends(max_s, aud_str); 
 
         fprintf(ofile, "Case #%d: %d\n", (i+1), result);
     }
 
     fclose(ifile);
     fclose(ofile);
 
     return 0;
 }
 
 int get_need_friends(int max_s, char* aud_str) {
     int i, s;
     int need_friends;
     int current_standing;
 
     need_friends = 0;
     current_standing = 0;
     for (i=0; i<max_s+1; i++) {
         s = aud_str[i] - '0';
         if (s > 0) {
             if (i != 0) {
                 if (current_standing < i) {
                     need_friends += (i - current_standing);
                     current_standing += (i - current_standing); 
                 }                
             }
             current_standing += s;
         }
     }
 
     return need_friends;
 }

