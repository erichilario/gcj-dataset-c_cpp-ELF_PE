#include <stdio.h>
 
 int min(int R, int C)
 {
 	return R < C ? R : C;
 }
 
 int max (int R, int C)
 {
 	return R > C ? R : C;
 }
 int max_r(int X)
 {
 	return (X >> 1) + 1;
 }
 
 int max_c(int X)
 {
 	if (X%2)
 		return max_r(X);
 	return X >> 1;	
 }
 
 int main()
 {
 	int T, k = 0;
 	int X, R, C;
 	scanf("%d",&T);
 
 	while(k++ < T)
 	{
 		scanf("%d %d %d", &X, &R, &C);
 		/**
 		switch(X)
 		{
 			case 1:
 				printf("Case #%d: GABRIEL\n", k);
 				break;
 			case 2:
 				if ((R*C)%X != 0)
 					printf("Case #%d: RICHARD\n", k);
 				else
 					printf("Case #%d: GABRIEL\n", k);
 				break;
 			case 3:
 				if (R == 1 || C == 1 || (R*C)%X != 0)
 					printf("Case #%d: RICHARD\n", k);
 				else
 					printf("Case #%d: GABRIEL\n", k);
 				break;
 			case 4:
 				if (R*C < 12 || (R*C)%X != 0)
 					printf("Case #%d: RICHARD\n", k);
 				else
 					printf("Case #%d: GABRIEL\n", k);
 				break;
 			default:
 				break;	
 		}
 		**/
 		/*
 		if (X == 1)
 		{
 			printf("Case #%d: GABRIEL\n", k);
 		}
 		else
 		{
 			if (X >= R*C || R*C%X != 0)
 				printf("Case #%d: RICHARD\n", k);
 			else
 				printf("Case #%d: GABRIEL\n", k);
 		}
 		*/
 		if (R*C%X != 0 || X > max(R, C) || (max_r(X) > min(R, C) && max_c(X) > min(R, C)) || (R*C == 8 && X > 2))
 			printf("Case #%d: RICHARD\n", k);
 		else
 			printf("Case #%d: GABRIEL\n", k);
 	}
 	return 0;
 }

