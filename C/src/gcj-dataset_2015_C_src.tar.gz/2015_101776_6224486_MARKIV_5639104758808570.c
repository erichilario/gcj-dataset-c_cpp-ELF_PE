#include <stdio.h>
 #include <stdlib.h>
 
 static int solveTestCase();
 
 int
 main(int argc, char ** argv) {
 	int nCnt = 0;
 	int i = 0;
 
 	scanf("%d", &nCnt);
 
 	for(i=1; i <= nCnt; i++) {
 		printf("Case #%d: %d\n", i, solveTestCase());
 	}
 
 	return 0;
 }
 
 static int
 solveTestCase() {
 	int reqdFriends = 0;
 	int clapCnt = 0;
 	int maxShy = 0;
 	int i = 0;
 	char buf[1001] = "";
 
 	scanf("%d %s", &maxShy, buf);
 	//fprintf(stderr, "MaxSHy=[%d] and buf=[%s]\n", maxShy, buf);
 
 	for(i=0; i <= maxShy; i++) {
 		if(clapCnt < i) {
 			reqdFriends += (i - clapCnt);
 			clapCnt = i + buf[i] - '0';
 		}
 		else {
 			clapCnt += buf[i] - '0';
 		}
 	}
 
 	//fprintf(stderr, "Returning [%d]\n", reqdFriends);
 
 	return reqdFriends;
 }

