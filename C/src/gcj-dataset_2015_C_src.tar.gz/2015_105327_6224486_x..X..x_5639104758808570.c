#include<stdio.h>
 #include<string.h>
 
 int main()
 {
     int j,t;
     scanf("%d",&t);
     for(j=1;j<=t;j++)
     {
         int aud,smx,i,res=0;
         char s[1005];
         scanf("%d",&smx);
         scanf("%s",s);
         aud=s[0]-48;
         for(i=1;i<strlen(s);i++)
         {
             if(aud<i && s[i]!='0')
             {
                 res+=(i-aud);
                 aud=(s[i]-48)+i;
             }
             else
                 aud+=(s[i]-48);
         }
         printf("Case #%d: %d\n",j,res);
     }
 }

