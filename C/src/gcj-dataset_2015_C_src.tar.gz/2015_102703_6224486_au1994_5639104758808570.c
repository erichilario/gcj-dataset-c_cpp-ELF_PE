#include<stdio.h>
 int main()
 {
     int t,smax,j=1,ans,count,i;
     char s[1005];
     freopen("abhiins2.txt","r",stdin);
     freopen("abhiouts2.txt","w+",stdout);
     scanf("%d",&t);
     while(j<=t)
     {
         scanf("%d",&smax);
         scanf("%s",s);
         count=s[0]-'0';
         ans=0;
         for(i=1;i<=smax;i++)
         {
             if(count>=i)
                 count+=s[i]-'0';
             else
             {
                 ans+=i-count;
                 count=i+s[i]-'0';
             }
 
         }
         printf("Case #%d: %d\n",j,ans);
        j++;
     }
     return 0;
 }

