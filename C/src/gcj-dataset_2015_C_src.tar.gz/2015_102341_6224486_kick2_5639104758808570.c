#include<stdio.h>
 int main ()
 {
 	int t=0,k=1;
 	scanf("%d",&t);
 	while(t--)
     {
         int s=0,f=0,arr[1001],ans=0,i=0,j=0;
         char a[1001];
 		scanf("%d",&s);
 		scanf("%s",a);
 		for(i=0;a[i];i++)
 		arr[j++]=(a[i]-'0');
 		for(i=0;i<=s;i++)
         {
             if(ans<i)
                 {
                     f+=i-ans;
                     ans=i+arr[i];
                 }
             else
                 ans+=arr[i];
         }
         printf("Case #%d: %d\n",k++,f);
 	}
 	return 0;
 }

