#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 FILE * fin, *fout;
 int cases;
 int reps,len, sumlen;
 int iidx, kidx;
 int actj,acti,actk;
 int iok,jok,kok;
 char buf[10001];
 
 int mul [4][4]= { { 1, 2, 3, 4},
 		  { 2,-1, 4,-3},
 		  { 3,-4,-1, 2},
 		  { 4, 3,-2,-1},
 		};
 
 char codes[4]= {'1','i','j','k'};
 
 void conv()
 {
 	int i,j;
 	for(i=0;i<sumlen;i++)
 	{
 		for(j=0;j<4;j++)
 		{
 			 if(codes[j]==buf[i])
 				 buf[i]=j+1;
 		}
 	}
 }
 
 char qmul(char a, char b)
 {
 	int a1,b1,i,res;
 	for(i=0;i<4;i++)
 	{
 		if(codes[i]==a)
 			a1=i+1;
 		if(codes[i]==b)
 			b1=i+1;
 	}
 	printf("a1: %d, b1: %d\n",a1,b1);
 	res=calc(a1,b1);
 	if(res<0)
 	{
 		printf("-");
 		res*=-1;
 	}
 	printf("res: %c, ret: %d\n",codes[res-1],res);
 
 }
 
 int calc(int i, int j)
 {
 	int lookup,ret;
 	int sign=1;
 	if(i<0)
 	{
 		i*=-1;
 		sign*=-1;
 	}
 	if(j<0)
 	{
 		j*=-1;
 		sign*=-1;
 	}
 	ret= mul[i-1][j-1];
 		ret*=sign;
 	return ret;
 }
 
 
 int main(){
 	int i,j;
 	qmul('1','1');
 	qmul('j','k');
 	qmul('k','j');
 	fin=fopen("in.txt","r");
 	fout=fopen("out.txt","w");
 	if(fin == NULL){
 		printf("AAAA \n");
 		return(1);
 	}
 	/*while(fgets(buf,255,fin)){
 		printf("%s\n",buf);
 	}*/
 	fscanf(fin,"%d\n", &cases);
 	//fscanf(fin,"%s",buf);
 	//printf("ok? :%s\n",buf);
 	printf("cases: %d\n",cases);
 	for(i=1;i<=cases;i++){
 		j=1;
 		memset(buf,0,sizeof(buf));
 		printf("Case #%d\n",i);
 		fscanf(fin,"%d %d\n",&len , &reps);
 		sumlen=len*reps;
 		printf("len: %d, reps: %d, sumlen: %d\n", len,reps,sumlen);
 		fscanf(fin,"%s\n",buf);
 		while(--reps > 0){
 			memcpy(buf+len*j++,buf,len);
 		}
 		//printf("buf: %s\n",buf);
 		conv();
 		//for(j=0;j<sumlen;j++)
 		//	printf("%d",buf[j]);
 		printf("\n");
 		iidx=-1;
 		kidx=sumlen;
 		iok=jok=kok=0;
 		acti=actk=1;
 		while(iidx+2<kidx && !jok)
 		{
 			iidx++;
 			acti=calc(acti,buf[iidx]);
 			//printf("acti: %d\n",acti);
 			if( acti!= 2)
 			{
 				continue;
 			}
 			kok=0;
 			while(iidx+2<kidx && !jok)
 			{
 				kidx--;
 				actk=calc(buf[kidx],actk);
 				//printf("actk: %d\n",actk);
 				if( actk!= 4)
 					continue;
 				actj=1;
 				for(j=iidx+1;j<kidx;j++)
 				{
 					actj=calc(actj,buf[j]);
 				}
 				//printf("actj: %d\n",actj);
 				if(actj==3)
 					jok=1;
 			}
 		
 		}
 		fprintf(fout,"Case #%d: ",i);
 		if(jok==1)
 		{
 			fprintf(fout,"YES\n");
 			printf("ok\n");
 		}
 		else
 		{
 			fprintf(fout,"NO\n");
 			printf("nok\n");
 		}
 		
 		
 		
 		
 		//printf("possible, GABRIEL\n");
 		continue;
 	}
 	return(0);		
 } 

