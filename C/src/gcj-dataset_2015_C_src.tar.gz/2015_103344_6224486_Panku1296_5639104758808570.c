#include <stdio.h>
 #include <stdlib.h>
 
 int main(){
 	int T;
 	//scanf("%d", &T);
 	int s;
 	char str[110];
 	int i=1, cas = 1, count;
 	FILE *ptrIn = fopen("A-small-attempt1.in", "r");
 	FILE *ptrOut = fopen("output.txt", "w");
 	fscanf(ptrIn, "%d", &T);
 	while(T-->0){
 		count = 0;
 		
 		//scanf("%d %s", &s, str);
 		fscanf(ptrIn, "%d %s", &s, str);
 		//printf("%s", str);
 		i=1;
 		int stood= str[0] - 48, required=0;
 		while(str[i] != '\0'){
 			required = (i-stood)>0?(i-stood):0;
 			stood += (str[i]-48);
 			stood += required;
 			i++;
 			count += required;
 		}
 		//printf("Case #%d: %d\n", cas, count);
 		fprintf(ptrOut, "Case #%d: %d\n",  cas, count);
 		cas++;
 	}
 	fclose(ptrIn);
 	fclose(ptrOut);
 	return 0;
 }
