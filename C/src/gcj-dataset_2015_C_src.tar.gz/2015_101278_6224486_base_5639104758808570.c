#include <stdio.h>
 
 int main()
 {
   int t, len, dig, peep, peepn, shylevel, peepup, casen;
   char ch;
   scanf("%d\n", &t);
   for (casen=1;casen<=t;casen++)
     {
       peepn=0;
       peepup=0;
       scanf("%d ", &len);
       for (shylevel=0;shylevel<=len; shylevel++)
 	{
 	  ch = getchar();
 	  peep = ch - '0';
 	  if (peepup>=shylevel)
 	    peepup+=peep;
 	  else if (peep > 0)
 	    {
 	      peepn+=(shylevel-peepup);
 	      peepup=shylevel+peep;
 	    }
 	}
       printf("Case #%d: %d\n",casen,peepn);
     }
   return 0;
 }

