#include <stdio.h>
 int main(){
 
 FILE *fpI,*fpO;
 int i=0,t,x,r,c,tmp;
 
 
     fpI=fopen("D-small-attempt1.in","r");
     fpO=fopen("output.txt","w");
 
     fscanf(fpI,"%d",&t);
 
 
     for(i=0;i<t;i++){
 
         fscanf(fpI,"%d%d%d",&x,&r,&c);
 
         if(x==1)
             fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
 
         else if(x==2){
             tmp=r*c;
             if(tmp%x==0)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==3){
             tmp=r*c;
             if(tmp==6||tmp==12||tmp==9)
                 fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
             else
                 fprintf(fpO,"Case #%d: RICHARD\n",i+1);
         }
 
         else if(x==4){
                 if(r*c>=12)
                     fprintf(fpO,"Case #%d: GABRIEL\n",i+1);
                 else
                     fprintf(fpO,"Case #%d: RICHARD\n",i+1);
 
         }
     }
     return 0;
 }

