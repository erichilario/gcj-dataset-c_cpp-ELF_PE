#include<stdio.h>
 int main()
 {
 int t,s,tot,ans,i,j,sti;
 char st[1001];
 scanf("%d",&t);
 for(j=1;j<=t;j++)
 {
 scanf("%d",&s);
 tot=0;ans=0;
 scanf("%s",&st);
 for(i=0;i<=s;i++)
 {
 sti=(int)st[i]-48;
 tot+=sti;
 if(tot<i+1){ans+=1;tot++;}
 }
 printf("Case #%d: %d\n",j,ans);
 }
 }

