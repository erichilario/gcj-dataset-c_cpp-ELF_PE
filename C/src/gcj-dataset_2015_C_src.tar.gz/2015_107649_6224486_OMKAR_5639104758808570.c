#include<stdio.h>
 int main(){
 
 
 
     int n,count,i,j,t,clapped,p,shy,req;
     char str[999999];
     scanf("%d",&t);
     for(j=0;j<t;j++){
 
             scanf("%d",&n);
             scanf("%s",str);
 
 
             count=0; clapped=0;
             for(i=0;i<=n;i++){
 
                 p=str[i]-48;//1 1 0 0 1
                 //i=0 1 2 3 4
 
                 if(p>=1){
                         if((i-clapped)>0){
                             count+=(i-clapped);
                             clapped+=(p+count);
                         }else{
 
                             clapped+=p;
                         }
 
                 }
 
             }
             printf("Case #%d: %d\n",j+1,count);
     }
 
 
 
 
     return 0;
 }

