
 #include <stdio.h>
 #include <stdlib.h>
 
 
 int main(int argc, char** argv) {
     int cases, best, new, line,i,j,divisions,max,divide,imax,odd;
     //int* tab;
     int tab[1000];
     
     FILE* input=fopen("fich.in","r");
     FILE* output = fopen("fich.out","w");
     
     fscanf(input,"%d",&cases);
     for(i=0;i<cases;i++){
         fscanf(input,"%d",&line);
         best=0;
         for(j=0;j<line;j++){
             fscanf(input,"%d",&tab[j]);
             if(tab[j]>best) best=tab[j];
             
         }
         new=best;
         divisions=0;
         max=tab[0];
         while(max>1){  
             max=tab[0];
             
             for(j=0;j<line;j++){
                 if(tab[j]>=max){
                     max=tab[j];
                     imax=j;
                     if(max%2==0) odd=0;
                     else odd=1;
                 }
                 
             }
             line++;
             
             if(max==9){
             tab[imax]=6;
             tab[line-1]=3;
             }
             else{
             tab[imax]/=2;
             tab[line-1]=tab[imax]+odd;
             }
             
             divisions++;
             max=tab[0];
             for(j=0;j<line;j++){
                 if(tab[j]>max){
                     max=tab[j];
                     imax=j;
                 }
                 
             }
             new=max+divisions;
             if(new<best) best=new;
             
             
             
         }
 
         fprintf(output,"Case #%d: %d\n",i+1,best);
         
     }
     
     
     
     return (EXIT_SUCCESS);
 }
 

