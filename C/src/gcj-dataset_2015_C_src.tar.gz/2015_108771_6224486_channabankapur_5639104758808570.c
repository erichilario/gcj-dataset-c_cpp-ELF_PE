#include <stdio.h>
 #include <stdlib.h>
 
 char smaxstr[1003]; /* 1000+1+1 */
 
 int main()
 {
     int t, smax, ppl, xtrappl, i, tcount = 1;
     scanf("%d", &t);
     while(t--)
     {
         scanf("%d", &smax);
         scanf("%s", smaxstr);
         ppl = xtrappl = 0;
         for(i = 0; i <= smax; i++)
         {
             ppl += smaxstr[i] - '0';
             if(ppl == i)
             {
                 ppl++;
                 xtrappl++;
             }
         }
         printf("Case #%d: %d\n", tcount++, xtrappl);
     }
     return 0;
 }

