#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
 	int Smax;
 	int Si;
 	int stand;
 	int need;
 	int i,j;
 	int T;
 	char arr[1002];
 	
 	FILE* f = fopen("A-small-attempt2.in.txt" , "r");
 	FILE* fp = fopen("result.txt" , "w");
 
 	fscanf(f,"%d",&T);
 	for(j=0 ; j<T ; j++)
 	{
 		fscanf(f,"%d",&Smax);
 		fscanf(f,"%s",arr);
 		for(stand = 0, need = 0, i=0 ; i<=Smax ; i++)
 		{
 			Si = arr[i] - '0';
 			if(Si != 0)
 			{
 				need += ((i - stand) < 0 ? 0 : (i-stand));
 				stand += Si + ((i - stand) < 0 ? 0 : (i-stand));
 			}
 		}
 
 		fprintf(fp, "Case #%d: %d\n",j+1,need);
 	}
 	fclose(f);
 	fclose(fp);
 	return 0;
 }
