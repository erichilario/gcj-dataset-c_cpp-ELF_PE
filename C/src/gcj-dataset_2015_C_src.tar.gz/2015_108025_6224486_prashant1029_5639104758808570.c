#include<stdio.h>
 
 int main()
 {
 	int num,i,j,m,p,k,a[1001];
 	
 	scanf("%d",&k);
 	for(j=0;j<k;j++)
 	{
 		scanf("%d",&m);
 		
 		for(p=0;p<=m;p++)
 		{
 			scanf("%1d",&a[p]);
 			
 		}
 		
 		num=0;
 		i=0;
 		
 		
 		for(p=0;p<=m;p++)
 		{
 			if(num>=p)
 			{
 				num+=a[p];
 				
 			}
 			else
 			{
 				if(a[p]!=0)
 				{
 				i+=p-num;
 				num=p;
 				num+=a[p];
 				}	
 			}
 		}
 		
 		printf("Case #%d: %d\n",j+1,i);
 		
 	}
 	
 	return 0;
 	
 }
