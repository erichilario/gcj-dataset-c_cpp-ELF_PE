
 #include <stdio.h>
 #include <stdlib.h>
 
 
 int main(int argc, char** argv) {
     int cases, x, r,c,i;
     
     FILE* input=fopen("fich.in","r");
     FILE* output=fopen("fich.out","w");
     
     fscanf(input,"%d",&cases);
     for(i=0;i<cases;i++){
         fprintf(output,"Case #%d: ",i+1);
         fscanf(input,"%d %d %d",&x,&r,&c);
         //fprintf(output,"x=%d r=%d c=%d\n",x,r,c);
         if(x==1) fprintf(output,"GABRIEL");
         else if((r*c)%x!=0 || (x>c && x>r) || (r*c)<x || (x==4 && (r<3 || c<3)) || ((r==1 || c==1) && x>2)  ) fprintf(output,"RICHARD");
         else fprintf(output,"GABRIEL");
         
         fprintf(output,"\n");
         
     }
     
     
     
     return (EXIT_SUCCESS);
 }
 

