#include <stdio.h>
 
 int T, t, i, j, k, sol, chk, len, key, spt, loc ;
 int arr[10000];
 int main()
 {
 	scanf( "%d", &T );
 	for( t = 1; t <= T; t++ )
 	{
 		scanf( "%d", &len );
 		for(i=0 ; i< len ; i++ )
 		{
 			scanf("%d" , &arr[i]);
 		}
 		
 		key = arr[0]; loc=0;	
 		for(i=1; i<len ; i++)
 		{
 			if(arr[i] > key);
 			{
 				key= arr[i];
 				loc = i;
 			}
 		}
 		sol = arr[loc];
 		k= key;
 		for(spt=1 ; spt<=9 ; spt++)
 		{
 			
 			
 			if(key % 2 == 0)
 			{
 				arr[loc] = arr[len] = key / 2;
 			}
 			else
 			{
 				arr[loc] = key / 2;
 				arr[len] = arr[loc] + 1;
 			}
 			len++;
 
 			
 			key = a[0]; loc=0;
 			for(i=1; i<len ; i++)
 			{
 				if(arr[i]>key)
 				{
 					key = arr[i];
 					loc=i;
 				}
 
 			}
 			
 
 			chk = key + spt;
 			if( chk < sol )
 				sol = chk;
 			
 
 		}
 
 		printf( "Case #%d: %d\n", t, sol );
 	}
 	return 0;
 }
