#include<stdio.h>
 
 
 int main(){
 
 
 int cases,i,j,k,time=0,count=0,cur;
 char str[1002];
 
 	scanf("%d",&cases);
 
 while(cases--){
 	time++;
  	count =0 ;
 	cur =0;	
 	scanf("%d", &k);
 	getchar();
 	scanf("%s",str);
 	getchar();
 //	printf("%s",str);
 
 	for(i=0;i<=k;i++){
 		if(str[i] != '0')
 			{	if(cur < i)
 				{
 				count += (i-cur) ;
 				cur = i ;
 				}
 				cur += (int)(str[i]-'0');
 			}
 	}
 	printf("Case #%d: %d\n",time,count);
 
 
 
 
 }
 
 
 
 
 return 0;
 
 }

