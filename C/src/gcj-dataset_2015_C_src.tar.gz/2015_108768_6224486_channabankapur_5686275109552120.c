#include <stdio.h>
 #include <stdlib.h>
 
 void insert(int i);
 void insert2(int half, int half2, int i);
 int isSplittable(int D);
 
 int P[1000001]; /* 1000*1000 = P * D */
 
 int main()
 {
     int t, tcount = 1;
 	int D, i, half, half2, splitCount;
     scanf("%d", &t);
     while(t--)
     {
         scanf("%d", &D); // num of nonempty diners
 		P[0] = 0;//sentinel having minus infinity
         for(i = 1; i <= D; i++)
         {
 			scanf("%d", &P[i]); // Pancakes in Diner i
 			//printf("%d ", P[i]);
 			insert(i); // insert P[i] at sorted array size of i
 		}
 		//printf("\n");
 
 		splitCount = 0;
 		int isSplit = isSplittable(D);
 		while(isSplit) {
 			if((P[D] == 9) && ((P[D-1] == 6) || (P[D-1] <= 3))) {
 				half = P[D] / 3;
 				half2 = (P[D] - half);
 				insert2(half, half2, D);
 				D++;
 				splitCount++;
 			} else {
 				half = P[D] / 2;
 				half2 = P[D] - half;
 				insert2(half, half2, D);
 				D++;
 				splitCount++;
 			}
 			isSplit = isSplittable(D);
 		}
         printf("Case #%d: %d\n", tcount++, splitCount + P[D]);
     }
     return 0;
 }
 
 //To keep array sorted. Insert ith element into sorted P[0.. i-1] array.
 //Assumes first (0th) location has 0
 void insert(int i) {
 	int a = P[i];
 	while(P[i-1] > a) {
 		P[i] = P[i-1];
 		i--;
 	}
 	P[i] = a;
 }
 
 //To keep array sorted.
 void insert2(int half, int half2, int i) {
 	while(P[i-1] > half2) {
 		P[i+1] = P[i-1];
 		i--;
 	}
 	P[i+1] = half2;
 	while(P[i-1] > half) {
 		P[i] = P[i-1];
 		i--;
 	}
 	P[i] = half;
 }
 
 int isSplittable(int D) {
 	int i = D-1, count = 1;
 	int half = P[D] / 2;
 	if(half <= 1) return 0;
 	if((P[D] == 9) && (P[D-1] <= 3)) {
 		return 2;
 	}
 
 	while((P[i] >= P[D] - count) && (P[i] > half)) { //(P[i]== P[D]) {
 		
 		count++;
 		if(count >= half) return 0;
 		i--;
 	}
 	return 1;
 }
 

