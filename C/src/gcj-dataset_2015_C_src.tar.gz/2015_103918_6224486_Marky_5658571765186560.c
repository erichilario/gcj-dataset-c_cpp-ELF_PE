#include<stdio.h>
 char G[]="GABRIEL", R[]="RICHARD";
 char* Ans(int x, int b, int s){
 	if(b<s){
 		int tmp = b;
 		b = s;
 		s = tmp;
 	}
 	if(x > 6  ||  s*b % x != 0  ||  x > 2*s  ||  x > b)
 		return R;
 	return G;
 }
 int main(){
 	int t, i;
 	scanf("%i",&t);
 	for(i=1; i <= t; i++){
 		int x,r,c;
 		scanf("%i%i%i",&x,&r,&c);
 		printf("Case #%i: %s\n", i, Ans(x,r,c));
 	}
 }
