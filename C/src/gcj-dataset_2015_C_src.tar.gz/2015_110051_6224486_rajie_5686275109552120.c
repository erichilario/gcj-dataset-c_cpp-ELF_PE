#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 void main()
 {
 	FILE *fpin,*fpout;
 	fpin = fopen("B-small-attempt3.in","r");
 	fpout = fopen("write.txt","w");
 	
 	int max,min,i,j,d,N,D,temp,next_big,sum=0;
 	fscanf(fpin,"%d\n",&N);
 	for(i=0;i<N;i++)
 	{
 		sum=0;
 		fscanf(fpin,"%d\n",&D);
 		int *arr = malloc(sizeof(int)*D);
 		for(d=0;d<D;d++)
 		{
 			fscanf(fpin,"%d\n",&arr[d]);
 		}
 		max=arr[0];
 		for(d=1;d<D;d++)
 		{
 			if(arr[d]>max)
 			max = arr[d];
 		}
 		int *occur = malloc(sizeof(int)*(max+1));
 		for(d=0;d<max+1;d++)
 			occur[d]=0;
 		for(d=0;d<D;d++)
 			{
 			temp = arr[d];
 			occur[temp]+=1;
 			}
 		int *reduce = malloc(sizeof(int)*(max+1));
 		for(d=0;d<=max;d++)
 		reduce[d]=occur[d];
 		for(d=max;d>2;d--)
 		{
 			if(d%2==0)
 			reduce[d/2]+=2*reduce[d];
 			else
 			{
 				reduce[d/2]+=reduce[d];
 				reduce[d/2+1]+=reduce[d];
 			}			
 			j=d-1;
 			while(reduce[j]==0 && j>0) j--;
 			next_big = j;
 			sum+= reduce[d];
 			reduce[d]=next_big + sum;
 		}
 		min=max;
 		for(d=max;d>2;d--)
 		{
 			if(reduce[d]<min)
 			min=reduce[d];
 		}
 		fprintf(fpout,"Case #%d: %d\n",i+1,min);
 	}
 	fclose(fpin);
 	fclose(fpout);
 }
 

