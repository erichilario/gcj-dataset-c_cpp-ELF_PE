#include <stdio.h>
 
 int solve(void)
 {
 	int S;
 	int needed = 0;
 	int i;
 	char c;
 	int current = 0;
 	scanf("%d", &S);
 	scanf("%c", &c);
 	for (i=0; i<=S; i++)
 	{
 		scanf("%c", &c);
 		c -= '0';
 		needed += current<i ? i-current : 0;
 		current += current<i ? i-current+c : c;
 	}
 	return needed;
 }
 
 void print(int tCount, int result)
 {
 	printf("Case #%d: %d\n", tCount, result);
 }
 
 int main(void)
 {
 	int C, i;
 	scanf("%d", &C);
 	for (i=1; i<=C; i++)
 		print(i, solve());
 	return 0;
 }

