#include<stdio.h>
 int main()
 {
     int T,ans[101],X,C,R;
     int k=1;
     FILE *ptrIn;
     FILE *ptrOut;
     ptrIn = fopen("input.txt", "r");
     ptrOut = fopen("output.txt", "w");
    // FILE* file = fopen ("input.txt", "r");
     //scanf("%d",&T);
     fscanf (ptrIn, "%d", &T);
     int test=T;
     while(T--)
     {
         fscanf(ptrIn,"%d %d %d",&X,&R,&C);
         //scanf("%d %d %d",&X,&R,&C);
         if(X==1)
         {
             ans[k]=0;
         }
         else if(X==2)
         {
             if((C*R)%X==0)
                 ans[k]=0;
             else
                 ans[k]=1;
         }
         else if(X==3)
         {
             if((C*R)%X==0 && C>1 && R>1)
                 ans[k]=0;
             else
                 ans[k]=1;
         }
         else if(X==4)
         {
             if((C==4 || R==4) && C>2 && R>2)
                 ans[k]=0;
             else
                 ans[k]=1;
         }
         k++;
     }
    //  fclose(file);
    //  FILE * fp;
    // fp = fopen ("file2.o", "w+");
     for(k=1;k<=test;k++)
         {
             if(ans[k]==0)
             fprintf(ptrOut,"Case #%d: %s\n",k,"GABRIEL");
             else
             fprintf(ptrOut,"Case #%d: %s\n",k,"RICHARD");
         }
        // fclose(fp);
         fclose(ptrOut);
     fclose(ptrIn); 
     return 0;
 }

