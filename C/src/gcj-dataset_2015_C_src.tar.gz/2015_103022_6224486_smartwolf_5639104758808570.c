#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
    int n,x,r,i,j,T,t;
     char *ch;
 
     scanf("%d",&T);
     for(i=0;i<T;i++)
     {
         scanf("%d",&n);
         ch=(char *)malloc((n+2)*sizeof(char));
         scanf("%s",ch);
         x=0;
         t=0;
         for(j=0;j<=n;j++)
         {
             if (j>x)
                {    r=(j-x);
                     t+=(j-x);
                     x+=r;
                }
             x=x+ch[j]-48;
         }
 
         printf("Case #%d: %d\n",i+1,t);
         free(ch);
     }
 
     return 0;
 }

