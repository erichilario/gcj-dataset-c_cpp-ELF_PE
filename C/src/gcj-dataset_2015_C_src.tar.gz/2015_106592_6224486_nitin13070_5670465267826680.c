#include <stdio.h>
 #include <stdlib.h>
 
 int quest[4][4] = {
 	{1,2,3,4},
 	{2,-1,4,-3},
 	{3,-4,-1,2},
 	{4,3,-2,-1}
 };
 
 
 
 int multi,multj,multk,multin,multjn,multkn;
 
 
 int main(){
 	int T,L,i,j,k,l,mult,flag,negcount;
 	long long int X;
 	char *input;
 	int *convert;
 	int *backarray;
 	FILE *ifp,*ofp;
 	ifp = fopen("practice.in","r");
 	ofp = fopen("output.in","w");
 
 	fscanf(ifp,"%d",&T);
 //	scanf("%d",&T);
 	for(i=0;i<T;i++){
 		fscanf(ifp,"%d %lld",&L,&X);
 //		scanf("%d %lld",&L,&X);
 		input = (char *)malloc((L*X)*sizeof(char));
 		convert = (int *)malloc((L*X)*sizeof(int));
 		backarray = (int *)malloc((L*X)*sizeof(int));
 		fscanf(ifp,"%s",input);
 //		scanf("%s",input);
 		if(L == 1 || (L*X) < 3){
 			fprintf(ofp,"CASE #%d: NO\n",i+1);
 			printf("CASE #%d: NO\n",i+1);
 			continue;
 		}
 
 		k=0;
 		for(l=0;l<X;l++){
 			for(j=0;j<L;j++){
 				if(input[j] == 'i')
 					convert[k++] = 2;
 				else if(input[j] == 'j')
 					convert[k++] = 3;
 				else if(input[j] == 'k')
 					convert[k++] = 4;
 			}
 		}
 			
 		flag = 0;k=0;
 		multi = 1;multin=0;mult=1;negcount=0;
 		for(j=(L*X);j>0;j--){
 			mult = quest[convert[j-1]-1][mult-1];
 			if(mult < 0){
 				negcount++;
 				mult = -1*mult;
 			}
 
 			if(negcount%2 == 0)
 				backarray[k++] = mult;
 			else
 				backarray[k++] = -1*mult;
 
 		}
 		for(j=1;j<=(L*X)-2 && flag == 0;j++){
 
 //			negcount = 0;mult = 1;
 			multi = quest[multi-1][convert[j-1] - 1];
 /*			for(l=0;l<j;l++){
 				mult = quest[mult-1][convert[l]-1];
 				if(mult < 0){
 					negcount++;
 					mult = (0 - mult);
 				}
 			}
 */
 			if(multi < 0){
 				multin++;
 				multi = -1*multi;
 			}
 
 
 			if(multi != 2 || multin%2 != 0){
 				continue;
 			}
 
 			multj = 1;multjn=0;
 			for(k=j+1;k<=(L*X)-1;k++){
 
 //				negcount = 0;mult = 1;
 				multj = quest[multj-1][convert[k-1]-1];
 /*				for(l=j;l<k;l++){
 					mult = quest[mult-1][convert[l]-1];
 					if(mult < 0){
 						negcount++;
 						mult = (0 - mult);
 					}
 				}
 */
 				if(multj < 0){
 					multjn++;
 					multj =-1*multj;
 				}
 
 				if(multj != 3 || multjn%2 != 0){
 					continue;
 				}
 
 /*				multkn = 0;multk = 1;
 				for(l=k;l<(L*X);l++){
 					multk = quest[multk-1][convert[l]-1];
 					if(multk < 0){
 						multkn++;
 						multk = (0 - multk);
 					}
 				}
 */				
 				if(backarray[(L*X)-k-1] != 4){
 					continue;
 				}
 //				if(multk != 4 || multkn%2 != 0){
 //					continue;
 //				}
 				fprintf(ofp,"CASE #%d: YES\n",i+1);
 				printf("CASE #%d: YES\n",i+1);
 				flag = 1;break;
 			}
 			
 		}
 		if(flag == 0)
 			fprintf(ofp,"CASE #%d: NO\n",i+1);
 			printf("CASE #%d: NO\n",i+1);
 //		printf("Test\n");
 	}
 
 
 
 	return 0;
 }

