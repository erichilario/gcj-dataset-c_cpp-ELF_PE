#include <stdio.h>
 #define DEF
 
 int main (void){
 	#ifdef DEF
 	freopen("D-small-attempt0.in", "r", stdin);
 	#endif
 	
 	#ifdef DEF
 	freopen("D-small-attempt0.out", "w", stdout);
 	#endif
 	
 	int t,i,x,r,c,winner;
 	
 	scanf("%d",&t);
 	for (i = 0; i < t; i++){
 		scanf("%d %d %d", &x,&r,&c);
 		winner = 0; //gabriel
 		
 		if (x == 2){
 			if ((r*c) % 2 != 0) winner = 1;
 		}else if (x == 3){
 			if ((r*c) % 3 != 0 || (r*c) < 6) winner = 1;
 		}else if (x == 4){
 			if ((r*c) % 4 != 0 || (r*c) < 12) winner = 1;
 		}
 		
 		if (winner == 1) printf("Case #%d: RICHARD\n",i+1);
 		else printf("Case #%d: GABRIEL\n",i+1);
 	}
 	return 0;
 }

