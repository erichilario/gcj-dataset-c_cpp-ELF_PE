#include<stdio.h>
 int main()
 {
     int t,smax,i,a[100],sum[100],diff[100],max,n;
     char str[100],ch;
     scanf("%d",&t);
     n=t;
     while(t--)
     {
         scanf("%d",&smax);
         scanf("%s",str);
         for(i=0;i<(smax+1);i++)
         {
             ch=str[i];
             a[i]=ch-48;
         }
         sum[0]=0;
         for(i=1;i<(smax+1);i++)
             sum[i]=sum[i-1]+a[i-1];
         diff[0]=0;
         for(i=1;i<(smax+1);i++)
             diff[i]=i-sum[i];
         max=diff[0];
         for(i=1;i<(smax+1);i++)
             if(diff[i]>max)
             max=diff[i];
         printf("Case #%d: %d\n",(n-t),max);
     }
     return 0;
 }

