/* Problem B. Infinite House of Pancakes */
 #include<stdio.h>
 #define MAX 1000
 int D,P[MAX],temp,k,flag;
 int large()
 {
 	int z, max=-32000;
 	for (z=1; z<=D; z++)
 	{
 		if (P[z]>=max)
 		{
 			max=P[z];
 			k=z;
 		}
 	}
 	temp=max;
 	return(max);
 }
 int main()
 {
 	int TC,max,i,j,count=0,count1=0,result[MAX];
 	scanf("%d",&TC);
 	for(i=1;i<=TC;i++)
 	{	
 		scanf("%d",&D);
 		for(j=1;j<=D;j++)
 			scanf("%d",&P[j]);
 		if(D==1)
 		{
 			if(P[1]==1)
 				count=1;
 			else if(P[1]==2)
 				count=2;
 			else if(P[1]==3||P[1]==4)
 				count=3;
 			else if(P[1]==5||P[1]==6)
 				count=4;
 			else if(P[1]==7||P[1]==8)
 				count=5;
 			else
 				count=6;
 		}
 		else
 		{
 			for (j = 1; j < D; j++)
 			{         
 				if (P[j] != P[j+1])
 					flag=1;
 			}
 			if(flag==0)
 			{
 				count1=P[1];
 			}
 			max=large();
 			while(max>3)
 			{
 				temp=temp/2;
 				P[k]-=temp;
 				count++;	/* Special minute */		
 				for(j=1;j<=D;j++)
 					P[j]--;
 				count++;	/* Normal minute */
 				max=large();
 			}
 			if(max<=3)
 			{
 				if(max==1)
 					count++;
 				else if(max==2)
 					count+=2;
 				else
 					count+=3;
 			}
 		}
 		if(flag==0 && count1<count && D>1)
 				count=count1;
 		result[i]=count;
 		count=0;
 		flag=0;
 	}
 	for(i=1;i<=TC;i++)
 		printf("\nCase #%d: %d",i,result[i]);
 	return 0;
 }

