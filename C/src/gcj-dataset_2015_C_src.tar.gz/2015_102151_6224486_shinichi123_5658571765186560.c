#include <stdio.h>
 #include <string.h>
 #include <math.h>
 #include <stdlib.h>
 
 int main() {
     int t,i;
     scanf("%d",&t);
     for(i=1;i<=t;i++){
         int x,r,c;
         scanf("%d%d%d",&x,&r,&c);
         if(x==1)
             printf("Case #%d: GABRIEL\n",i);
         else if(x==2){
             if((r*c)%2!=0)
                 printf("Case #%d: RICHARD\n",i);
             else
                 printf("Case #%d: GABRIEL\n",i);
         }
         else if(x==3){
             if((r>=2)&&(c>=2)&&((r*c)%3==0))
                 printf("Case #%d: GABRIEL\n",i);
             else
                 printf("Case #%d: RICHARD\n",i);
         }
         else if(x==4){
             if(r*c>=12)
                 printf("Case #%d: GABRIEL\n",i);
             else
                 printf("Case #%d: RICHARD\n",i);
         }
     }
         return 0;
 }
 
 

