#include<stdio.h>
 int solve(int a,int b,int c)
 {
     int temp,res;
     if(a==1)
         return 1;
     if(a==2)
     {
         if((b*c)%2==0)
             return 1;
         else
             return 0;
     }
     if(a>2)
     {
         if(b==1 || c==1)
             return 0;
         else
         {
            temp=b*c;
            res=temp/a;
            if(res*a==temp)
            {
                if(res>=(a-1))
                 return 1;
                else
                 return 0;
            }
            else
             return 0;
         }
         else 
             return 0;
     }
 }
 int main()
 {
     int t,n,x,r,c,flag;
     scanf("%d",&t);
     n=t;
     while(t--)
     {
         scanf("%d%d%d",&x,&r,&c);
         flag=solve(x,r,c);
         if(flag)
             printf("Case #%d: GABRIEL\n",(n-t));
         else
             printf("Case #%d: RICHARD\n",(n-t));
     }
     return 0;
 }

