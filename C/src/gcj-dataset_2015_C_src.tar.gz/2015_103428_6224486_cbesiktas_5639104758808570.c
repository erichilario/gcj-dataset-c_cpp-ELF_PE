#include <stdio.h>
 
 int main() {
 	int i = 0;
 	int j = 0;
 	int T;
 	int smax;
 	char smaxarr[1024];
 
 	int up = 0;
 	int level = 0;
 	int n = 0;
 	
 	scanf("%d",&T);
 	for(i = 0; i < T; i++ ) {
 		up = 0; level = 0; n = 0;
 		scanf("%d %s", &smax, smaxarr);
 		//printf("%d %s\n", smax, smaxarr);
 		for(j = 0; j < smax + 1; j++) {
 			level = j;
 			up += smaxarr[j] - '0';
 			//printf("%d %d %d\n", up, level, n);
 			if((up - level) <= 0 ) {
 				n += 1;
 				up += 1;
 				//printf("n: %d\n", n);
 			}
 		}
 		printf("Case #%d: %d\n", i + 1, n);
 	}
 	return 0;
 }

