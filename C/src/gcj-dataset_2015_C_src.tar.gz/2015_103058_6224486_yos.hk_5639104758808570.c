#include <stdio.h>
 
 int main()
 {
 	int i,j,k,m,n;
 	int T,t;
 	int sum;
 	char a[10000];
 	
 	fscanf(stdin, "%d", &T);
 	for(t=1;t<=T;t++)
 	{
 		fscanf(stdin, "%d", &n);
 		fscanf(stdin, "%s", a);
 
 		//printf("%d %s ", n,a);
 		
 		sum=0; m=0;
 		for(i=0;i<n;i++)
 		{
 			k=a[i]-48;
 			sum=sum+k;
 			
 			if((a[i+1]>48) && (sum<i+1))
 			{
 				j=i+1-sum;
 				m=m+j;
 				sum=sum+m;
 			}
 		}
 		printf("Case #%d: %d\n", t, m);
 			
 	}
 	
 	return 0;
 }
 		
 		
 	
