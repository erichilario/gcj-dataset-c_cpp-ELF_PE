#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 int main(){
   int i, j;
   int t, n, res, d;
   long int special, max, maxvdd;
   int p[1001];
 
   scanf("%d", &t);
   for (n = 1; n <= t; n++) {
     scanf("%d", &d);
 
     memset(p, 0, sizeof(p));
 
     special = max = maxvdd = 0;
     for (j = 0; j < d; j++) {
       scanf("%d", &i); //printf("%d ", i);
       p[i]++;
 
       if(maxvdd < i)
         maxvdd = i;
     }
 
     max = 3;
     for (j = 9; j > max; j--) {
       if(!p[j]) continue;
 
       if(j == 9 && p[j] < 3){
         p[3]++;
         p[9] =0;
         special += (2*p[j]);
         max = 3 + (2*p[j]);
       }else if(j == 4){ //printf(".4.");
         if(special == 0){
           p[j] = 0;
           break;
         }
       }else if(j < 9 && ((j -1)/3)+3 + (p[j]-1) + special < j && ((j -1)/3)+3 + (p[j]-1) + special < max + p[j]){//printf(".%d.",j);
         p[j] = 0;
         p[3]++;
         max = ((j -1)/3)+3 + (p[j]-1) + special;
         special += p[j];
       }else break;
     }
 
     for (j = 9; j > 0; j--) {
         if(p[j]){
           max = j;
           break;
         }
     }
 
     if(maxvdd <  max)
       printf("Case #%d: %ld\n", n, maxvdd);
     else
       printf("Case #%d: %ld\n", n, max);
   }
 
   return 0;
 }

