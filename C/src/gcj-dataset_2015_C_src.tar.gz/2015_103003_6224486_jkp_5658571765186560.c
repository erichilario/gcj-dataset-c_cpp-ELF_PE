#include <stdio.h>
 #define DEF
 
 int main (void){
 	#ifdef DEF
 	freopen("D-large.in", "r", stdin);
 	#endif
 	
 	#ifdef DEF
 	freopen("D-large.out", "w", stdout);
 	#endif
 	
 	int t,i,x,r,c,winner;
 	
 	scanf("%d",&t);
 	for (i = 0; i < t; i++){
 		scanf("%d %d %d", &x,&r,&c);
 		winner = 1; //richard
 		
 		if ((r*c) % x == 0){
 			if (x <= 2) winner = 0;
 			else if (x == 3){
 				if ((r%3 == 0 && c >= 2) || (c%3 == 0 && r >= 2)) winner = 0;
 				
 			}else if (x == 4){
 				if (r%4 == 0 || c%4 == 0){
 					if ((r%4 == 0 && c >= 3) || (c%4 == 0 && r >= 3)) winner = 0;
 				}else{
 					if (r != 2 && c != 2) winner = 0;
 				}
 				
 			}else if (x == 5){
 				if ((r%5 == 0 && c >= 4) || (c%5 == 0 && r >= 4)) winner = 0;
 				
 			}else if (x == 6){
 				if (r%6 == 0 || c%6 == 0){
 					if ((r%6 == 0 && c >= 4) || (c%6 == 0 && r >= 4)) winner = 0;
 				}else{
 					if (r != 3 && c != 3){
 						if ((r != 2 || c != 9) && (c != 2 || r != 9)) winner = 0;
 					}
 				}
 			}
 		}
 		
 		if (winner == 1) printf("Case #%d: RICHARD\n",i+1);
 		else printf("Case #%d: GABRIEL\n",i+1);
 	}
 	return 0;
 }

