#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 int main()
 {
 	int test,x,r,c,i,condition,temp;
 	scanf("%d",&test);
 	for(i = 1;i<= test;i++)
 	{
 		scanf("%d %d %d",&x,&r,&c);
 		if(x == 1)
 			condition = 1;
 		else if(x== 2)
 		{
 			temp = r * c;
 			if(temp < 2)
 				condition = 0;
 			else if(temp % 2 == 0)
 				condition = 1;
 			else
 				condition = 0;
 			
 		} 
 		else if(x == 3)
 		{
 			if(r == 1)
 				condition = 0;
 			else if(c == 1)
 				condition = 0;
 			else if(r == 2)
 			{
 				if(c == 2)
 					condition = 0;
 				else if(c == 3)
 					condition = 1;
 				else if(c == 4)
 					condition = 0;
 							
 			}
 			else if(r == 3)
 			{
 				if(c == 2)
 					condition = 1;
 				else if(c == 3)
 					condition = 1;
 				else if(c == 4)
 					condition = 1;
 			}
 			else if(r == 4)
 			{
 				if(c == 2)
 					condition = 0;
 				else if(c == 3)
 					condition = 1;
 				else if(c == 4)
 					condition = 0;
 			}		
 		}
 		else if(x == 4)
 		{
 			temp = r * c;
 			if(r == 1)
 				condition = 0;
 			else if(c == 1)
 				condition = 0;
 			else if(temp < 4)
 				condition = 0;
 			else if(r == 2)
 			{
 				if(c == 2)
 					condition = 0;
 				else if(c == 3)
 					condition = 0;
 				else if(c == 4)
 					condition = 0;
 							
 			}
 			else if(r == 3)
 			{
 				if(c == 2)
 					condition = 0;
 				else if(c == 3)
 					condition = 0;
 				else if(c == 4)
 					condition = 1;
 			}
 			else if(r == 4)
 			{
 				if(c == 2)
 					condition = 0;
 				else if(c == 3)
 					condition = 1;
 				else if(c == 4)
 					condition = 1;
 			}		
 			
 		}
 		if(condition == 1)
 			printf("Case #%d: GABRIEL\n",i);
 		else
 			printf("Case #%d: RICHARD\n",i);
  	
 	}
 	return 0;
 }

