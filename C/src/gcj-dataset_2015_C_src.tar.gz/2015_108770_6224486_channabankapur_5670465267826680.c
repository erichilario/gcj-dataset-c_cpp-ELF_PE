#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char s[10003]; /* 10000+1 */
 char s2[10003]; /* 10000+1 */
 char tbl[128][128]; //symbol tbl
 
 int iCheck(int i);
 int jCheck(int i);
 int kCheck(int i);
 void initTbl();
 
 int main()
 {
     int t, tcount = 1;
 	int v1, v2, i;
 	initTbl();
 	
     scanf("%d", &t);
     while(t--)
     {
         scanf("%d", &v1);
         scanf("%d", &v2);
         scanf("%s", s);
 		strcpy(s2, s);
 		while(--v2) {
 			strcat(s, s2);		
 		}
 		i = 0;
 
 		i = iCheck(i);
 		if(i != -1) {
 			i = jCheck(i);
 			if(i != -1) {
 				i = kCheck(i);
 			}
 		}
         printf("Case #%d: %s\n", tcount++,
 			 (i == -1) ? "NO" : "YES");
     }
     return 0;
 }
 
 int iCheck(int i) {
 	if(!s[i]) return -1;
 
 	while(s[i+1] && s[i] != 'i') {
 		s[i+1] = tbl[s[i]][s[i+1]];
 		i++;
 	}
 
 	if(s[i] == 'i') return i+1;
 	return -1;
 }
 
 int jCheck(int i) {
 	if(!s[i]) return -1;
 
 	while(s[i+1] && s[i] != 'j') {
 		s[i+1] = tbl[s[i]][s[i+1]];
 		i++;
 	}
 
 	if(s[i] == 'j') return i+1;
 	return -1;
 }
 
 int kCheck(int i) {
 	if(!s[i]) return -1;
 
 	while(s[i+1] && s[i] != 'k') {
 		s[i+1] = tbl[s[i]][s[i+1]];
 		i++;
 	}
 
 	if(s[i] == 'k') return i+1;
 	return -1;
 }
 
 void initTbl() {
 	tbl['1']['1'] = '1';
 	tbl['1']['i'] = 'i';
 	tbl['1']['j'] = 'j';
 	tbl['1']['k'] = 'k';
 	tbl['1']['0'] = '0';
 	tbl['1']['I'] = 'I';
 	tbl['1']['J'] = 'J';
 	tbl['1']['K'] = 'K';
 	tbl['0']['1'] = '0';
 	tbl['0']['i'] = 'I';
 	tbl['0']['j'] = 'J';
 	tbl['0']['k'] = 'K';
 	tbl['0']['0'] = '1';
 	tbl['0']['I'] = 'i';
 	tbl['0']['J'] = 'j';
 	tbl['0']['K'] = 'k';
 
 	tbl['i']['1'] = 'i';
 	tbl['i']['i'] = '0';
 	tbl['i']['j'] = 'k';
 	tbl['i']['k'] = 'J';
 	tbl['i']['0'] = 'I';
 	tbl['i']['I'] = '1';
 	tbl['i']['J'] = 'K';
 	tbl['i']['K'] = 'j';
 	tbl['I']['1'] = 'I';
 	tbl['I']['i'] = '1';
 	tbl['I']['j'] = 'K';
 	tbl['I']['k'] = 'j';
 	tbl['I']['0'] = 'i';
 	tbl['I']['I'] = '0';
 	tbl['I']['J'] = 'k';
 	tbl['I']['K'] = 'J';
 
 	tbl['j']['1'] = 'j';
 	tbl['j']['i'] = 'K';
 	tbl['j']['j'] = '0';
 	tbl['j']['k'] = 'i';
 	tbl['j']['0'] = 'J';
 	tbl['j']['I'] = 'k';
 	tbl['j']['J'] = '1';
 	tbl['j']['K'] = 'I';
 	tbl['J']['1'] = 'J';
 	tbl['J']['i'] = 'k';
 	tbl['J']['j'] = '1';
 	tbl['J']['k'] = 'I';
 	tbl['J']['0'] = 'j';
 	tbl['J']['I'] = 'K';
 	tbl['J']['J'] = '0';
 	tbl['J']['K'] = 'i';
 
 	tbl['k']['1'] = 'k';
 	tbl['k']['i'] = 'j';
 	tbl['k']['j'] = 'I';
 	tbl['k']['k'] = '0';
 	tbl['k']['0'] = 'K';
 	tbl['k']['I'] = 'J';
 	tbl['k']['J'] = 'i';
 	tbl['k']['K'] = '1';
 	tbl['K']['1'] = 'K';
 	tbl['K']['i'] = 'J';
 	tbl['K']['j'] = 'i';
 	tbl['K']['k'] = '1';
 	tbl['K']['0'] = 'k';
 	tbl['K']['I'] = 'j';
 	tbl['K']['J'] = 'I';
 	tbl['K']['K'] = '0';
 }
 

