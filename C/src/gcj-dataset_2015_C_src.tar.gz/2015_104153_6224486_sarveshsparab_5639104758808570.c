#include<stdio.h>
 int main(){
     int t,t_temp,s_max,sum[1000],i,cnt,j;
     char s[1005];
     scanf("%d",&t);
     t_temp=t;
     while(t--){
         scanf("%d",&s_max);
         scanf("%s",s);
         cnt=0;
         for(i=0;i<=s_max;i++){
             sum[i]=0;
         }
         sum[0]=s[0]-'0'-1;
         for(i=1;i<=s_max;i++){
             sum[i]=sum[i-1]+s[i]-'0';
         }
         /*printf("\n\n");
         for(i=0;i<=s_max;i++){
             printf("%d ",sum[i]);
         }
         printf("\n\n");*/
         for(i=0;i<=s_max;i++){
             if(sum[i]<i){
                 cnt++;
                 for(j=i;j<=s_max;j++){
                     sum[j]++;
                 }
             }
         }
 
         /*for(i=0;i<=s_max;i++){
             printf("%d ",sum[i]);
         }
         printf("\n** %d **\n",cnt);
         getch();*/
 
         printf("Case #%d: %d\n",t_temp-t,cnt);
     }
     return 0;
 }

