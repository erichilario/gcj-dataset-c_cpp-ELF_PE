#include <stdio.h>
 
 int main() {
 	int i = 0;
 	int j = 0;
 	int T;
 	int D;
 	char Pstr[4096];
 	int P[2048];
 	
 	int maxindex = 0;
 	int max = 0;
 	int max2 = 0;
 	int zeroes = 0;
 	int mins = 0;
 	int curD = 0;
 	int sum = 0;
 	int avg = 0;
 	int maxcnt = 0;
 
 	scanf("%d",&T);
 	//printf("T is: %d\n",T );
 	for(i = 0; i < T; i++ ) {
 		mins = 0;		
 
 		scanf("%d", &D);
 		//printf("%d\n", D);	
 		for(j = 0; j < D; j++) {
 			scanf("%d", &P[j]);
 			//printf("%d ", P[j]);
 		}
 		//printf("\n");
 		curD = D;
 		//for(j = 0; j < D; j++) {
 		//	printf("%d ", P[j]);
 		//}
 		//printf("\n");
 
 		while(1) {
 			max = 0; maxindex = 0; zeroes = 0; sum = 0; avg = 0; max2 = 0;		
 			
 			for(j = 0; j < D; j++) {
 				if(max < P[j]){
 					maxindex = j;
 					max2 = max;
 					max = P[j];
 					maxcnt = 0;
 				}
 				if (max == P[j])
 				{
 					maxcnt++;
 				}
 				sum += P[j];
 			}
 			avg = sum / curD;
 			//printf("curD is %d, Max is P[%d] = %d\n",curD, maxindex,  P[maxindex]);
 			//printf("Max: %d maxcnt: %d max2: %d\n", max, maxcnt, max2);
 			if((max / 2) > maxcnt && P[maxindex] > 3)  {
 				if (maxcnt == 1 && max - max2 > 3 && max2 != 0 && max - max2 < max2)
 				{
 					P[D] = P[maxindex] - max2;
 					P[maxindex] = max2;					
 				} else {					
 					P[D] = P[maxindex] / 2;
 					P[maxindex] -= P[maxindex] / 2;
 				}			
 
 				D++;
 				curD++;
 				mins++;
 				//for(j = 0; j < D; j++) {
 				//	printf("%d ", P[j]);
 				//}
 				//printf("\n");
 				//printf("P[%d] = %d, P[%d] = %d\n", maxindex, P[maxindex], D - 1, P[D - 1] ); 
 			} else {
 				//printf("All are eating: ");
 				for(j = 0; j < D; j++) {
 					if(P[j] > 0) {
 						P[j] += -1; 
 					}
 					if(P[j] == 0) {
 						zeroes++;
 					}
 					//printf("%d ", P[j]);
 				}
 				//printf("\n");
 				mins++;
 				curD = D - zeroes;
 				if(D == zeroes) {
 					break;
 				}
 			}
 		}
 		printf("Case #%d: %d\n", i + 1, mins);
 	}
 	return 0;
 }

