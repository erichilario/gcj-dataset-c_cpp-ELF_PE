#include<stdio.h>
 #include<string.h>
 #include<math.h>
 main()
 {
 	int j,k,t,ans,tcount=1;
 	long long int i,l,x;
 	char str[10001];
 	int data[4][4]={{1,2,3,4},{2,-1,4,-3},{3,-4,-1,2},{4,3,-2,-1}};
 	scanf("%d\n",&t);
 	while(tcount<=t)
 	{
 		scanf("%lld %lld\n",&l,&x);
 		scanf("%s",&str);
 		ans=data[0][str[0]-'h'];
 		for(i=1;i<l*x && ans!=2;i++)
 		{
 			ans=((ans<0)?-1:1)*data[abs(ans)-1][str[i%l]-'h'];
 		}
 		if(ans==2)
 		{
 			ans=data[0][str[i%l]-'h'];
 			for(i=i+1;i<l*x && ans!=3;i++)
 			{
 				ans=((ans<0)?-1:1)*data[abs(ans)-1][str[i%l]-'h'];
 			}
 			if(ans==3)
 			{
 				ans=data[0][str[i%l]-'h'];
 				for(i=i+1;i<l*x;i++)
 				{
 					ans=((ans<0)?-1:1)*data[abs(ans)-1][str[i%l]-'h'];
 				}
 				if(ans==4)
 				{
 					printf("Case #%d: YES",tcount);
 				}
 				else
 				{
 					printf("Case #%d: NO",tcount);
 				}
 			}
 			else
 			{
 				printf("Case #%d: NO",tcount);
 			}
 		}
 		else
 		{
 			printf("Case #%d: NO",tcount);
 		}
 		printf("\n");
 		tcount++;
 	}
 	return(0);
 }

