#include<stdio.h>
 int main(void)
 {
 	int a,b;
 	scanf("%d",&a);
 	for(b=1;b<=a;b++)
 	{
 	      int x,y,z;
 	      scanf("%d%d%d",&x,&y,&z);
 	        if(x>y*z||y*z%x!=0)
 	 {
 	 	  printf("Case #%d: RICHARD\n",b);
 	      continue;
 	}
 	      	else 
 	      	{
 	      		if(x==1||x==2)
 	      		 {
 	 	  printf("Case #%d: GABRIEL\n",b);
 	      continue;
 	}
 	     else
 	     if(x==y*z)
 	      {
 	 	  printf("Case #%d: RICHARD\n",b);
 	      continue;
 	}
 	else if(x==4&&y*z==8)
   {
 	 	  printf("Case #%d: RICHARD\n",b);
 	      continue;
 	}
 	else 
 	     		 {
 	 	  printf("Case #%d: GABRIEL\n",b);
 	      continue;
 	}
 	      		
 	      	}
 	      	
 	}
 	return 0;
 }
