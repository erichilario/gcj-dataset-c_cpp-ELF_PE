#include<stdio.h>
 int mult(int pr1 , int pr2)
 {int m11=0;
 	if(pr1<0)
 	{
 		pr1=-pr1;
 		m11++;
 	}
 	if(pr2<0)
 	{
 		pr2=-pr2;
 		m11++;
 	}
 	int d;
 	if(pr1==1)
 		d=pr2;
 	else if(pr2==1)
 		d=pr1;
 	else if(pr1==pr2)
 		d=-1;
 	else if(pr1==105&&pr2==106)
 		d=107;
 	else if(pr1==106&&pr2==107)
 		d=105;
 	else if(pr1==107&&pr2==105)
 		d=106;
 	else if(pr1==105&&pr2==107)
 		d=-106;
 	else if(pr1==106&&pr2==105)
 		d=-107;
 	else if(pr1==107&&pr2==106)
 		d=-105;
 	if(m11==1)
 		d=-d;
 	return d;
 }
 int main()
 {
 	int t,i;
 	scanf("%d",&t);
 	for(i=1;i<t+1;i++)
 	{
 		int l,x,j;
 		char s[10000];
 		scanf("%d %d",&l,&x);
 		scanf("%s",&s);
 		for(j=0;j<(l*x);j++)
 		{
 			s[j]=s[j%l];
 		}
 		int k1,s1[10000];
 		for(k1=0;k1<(l*x);k1++)
 		{
 			if(s[k1]=='i')s1[k1]=105;
 			else if(s[k1]=='j')s1[k1]=106;
 			else if(s[k1]=='k')s1[k1]=107;
 		}
 		int a=1,b=1,c=1;
 		int k;
 		for(k=0;k<(l*x);k++)
 		{
 			if(a==105)
 				break;
 			a=mult(a,s1[k]);
 		}
 			
 		for(k=k;k<(l*x);k++)
 		{
 			if(b==106)
 				break;
 			b=mult(b,s1[k]);
 		}
 		
 		for(k=k;k<(l*x);k++)
 		{
 			c=mult(c,s1[k]);
 		}
 		
 		if(c==107)
 			printf("Case #%d: YES\n",i);
 		else
 			printf("Case #%d: NO\n",i);
 	}
 	return 0;
 }
