#include<stdio.h>
 int main()
 {
 	char a[1000];
 	int n,t,c,i,ct,ct1,j;
 	scanf("%d",&t);
 	for(j=1;j<=t;j++)
 	{
 		c=0;
 		ct=0;
 		scanf("%d",&n);
 		scanf("%s",a);
 		for(i=0;i<=n;i++)
 		{
 			if(i<c&&a[i]!='0')
 			{
 				c+=(a[i]-'0');
 			}
 			else if(a[i]!='0')
 			{
 				ct1=i-c;
 				ct+=ct1;
 				c+=ct1;
 				c+=(a[i]-'0');
 			}
 			
 			
 		}
 		printf("Case #%d: %d\n",j,ct);
 	}
 return 0;
 }

