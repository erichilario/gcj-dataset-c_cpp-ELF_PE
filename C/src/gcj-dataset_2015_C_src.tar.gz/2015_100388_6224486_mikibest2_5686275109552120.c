#include <stdio.h>
 #include <stdlib.h>
 
 int cost(int* diners, int num, int target) {
 	int i;
 	int res=0;
 	int splits, size;
 	int max = -1;
 	for (i=0; i<num; i++) {
 		splits = ((diners[i]+target-1)/target) - 1;
 		size = (splits == 0)? size = diners[i] : (diners[i]+splits)/(splits+1);
 		if (size > max)
 			max = size;
 		res += splits;
 	}
 
 	return res+max;
 }
 
 int main() {
 	FILE* in = fopen("B-large.in","r");
 	FILE* out = fopen("B_ans_large.in","w");
 
 	//FILE* in = fopen("B_ex.in","r");
 	//FILE* out = fopen("B_ans.in","w");
 
 	int T,D,C;
 	int* diners = (int*) malloc(sizeof(int));
 	int i,j,k, temp;
 	int max;
 
 	fscanf(in, "%d", &T);
 
 	for (i=0; i<T; i++) {
 		if (i==35)
 			i=35;
 
 		max = -1;
 		C = 9999999;
 		fscanf(in, "%d", &D);
 		diners = (int*) realloc(diners, D*sizeof(int));
 		for (j=0; j<D; j++) {
 			fscanf(in, "%d", diners+j);
 			if (diners[j] > max)
 				max = diners[j];
 		}
 
 		for (k=1; k<=max; k++) {
 			temp = cost(diners, D, k);
 			if (temp < C)
 				C = temp;
 		}
 
 		fprintf(out,"Case #%d: %d", i+1, C);
 
 		if (i != T-1)
 			fprintf(out,"\n");
 	}
 
 	free(diners);
 
 	return 0;
 }
