#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 main()
 {
 	char str[10001],ch[10001],lkp[4][4],ni=0;
   	int co=0,ct=0,cth=0,t,temp,L,X,k=0,i,j,mincount=0,res=1,nu=0,ran;
   	char by[3];
   	
          lkp[0][0]=1;
          lkp[0][1]='i';
 	     lkp[0][2]='j';
          lkp[0][3]='k';
          lkp[1][0]='i';
          lkp[1][1]=-1;
          lkp[1][2]='k';
          lkp[1][3]=-'j';
 		 lkp[2][0]='j';
          lkp[2][1]=-'k';
 		 lkp[2][2]=-1;
          lkp[2][3]='i';
 		 lkp[3][0]='k';
          lkp[3][1]='j';
 		 lkp[3][2]=-'i';
          lkp[3][3]=-1;
 /*	for(i=0;i<4;i++)
 	{
 	
 		for(j=0;j<4;j++)
 		{
 		printf("%d  ",lkp[i][j]);
 	}
 	printf("\n");
 }*/
 
 	
 	
 	scanf("%d",&t);
 	
 	for(temp=0;temp<t;temp++)
 	{
 		
 		mincount =0;
 		co=0; ct=0;cth=0;res=1;
 		scanf("%d%d",&L,&X);
 		k=0;
 		nu=0;
 		scanf("%s",ch);
 		if (L*X<2)
 		{
 			printf("Case #%d: NO\n");continue;
 		}
 		// string generation for x number of time.
 		for(i=0;i<X;i++)
 		for(j=0;j<L;j++)
 		{
 			str[k++]=ch[j];
 			
 		}
 		//printf("hello res=%d str=%c",res,str[0]);
 		for(k=0;k<(L*X);k++)
 		{
 			//printf("res=%d",res);
 			res=res%103;
 			ran=((int)str[k]%103)-1;
 		//	printf("res = %d Ran=%d",res,ran);
 			res=lkp[res-1][ran];
 		//	printf("hello res=%d",res);
 		//	getch();
 			if (res==-'i' || res==-'j' || res==-'k' || res==-1 )
 				mincount++;
 			//printf("hasf");
 			//getch();
 			if(abs(res)!='i' && co==0) {	res=abs(res);		continue; }
 			if((res=='i' || res==-'i' ) && co==0)
 			{
 				
 				by[nu++]='i';
 				co++;
 				//printf("i am here");getch();
 				res=1;
 				continue;
 				
 			}
 			if(abs(res)!='j' && ct==0){res=abs(res);
 			 continue;}
 		    if ((res=='j' || res==-'j' )&& ct==0)
 			{
 				by[nu++]='j';
 				ct++;
 				res=1;
 				//printf("i am in jhere");
 				
 			}
 			
 			res=abs(res);
 			}//end for loop....
 			
 			by[nu]=res;
 		//	printf("by=%s %d",by,mincount%2);
 			if (!strcmp(by,"ijk") && mincount%2==0)
 			printf("Case #%d: YES\n",temp+1);
 			else 
 			printf("Case #%d: NO\n",temp+1);
 		
 		
 		
 	
 	}
 	
 	return 0;
 }

