#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #define MAX_SIZE 1100
 #define SIZE 100
 
 int friends(char str[MAX_SIZE],int Smax);
 
 int main()
 {
 	int T,Smax,index,output[SIZE];
 	char string[MAX_SIZE];
 	scanf("%d",&T);
 	for (index=0;index<T;index++)
 	{
 		scanf("%d",&Smax);
 		scanf("%s",string);
 		output[index]=friends(string,Smax);
 	}
 	for (index=0;index<T;index++)
 		printf("Case #%d: %d\n",index+1,output[index]);
 
 	return 0;
 }
 
 int friends(char str[MAX_SIZE],int Smax)
 {
 	int index=0,count=0,frnd=0;
 	for(index=0;index<Smax+1;index++)
 	{
 		count+=(str[index]-48);
 		if(str[index]==48 && count<index+1)
 		{
 			frnd++;
 			count++;
 		}
 		if(count>=Smax)
 			return frnd;
 	}
 }

