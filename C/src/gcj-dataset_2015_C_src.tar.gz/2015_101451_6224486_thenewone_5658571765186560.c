#include<stdio.h>
 int main(){
 	int t,T,x,r,c,i,j;
 	scanf("%d",&T);
 	for(t=1;t<=T;t++){
 		scanf("%d%d%d",&x,&r,&c);
 		if( r*c % x != 0 )
 		{
 			printf("Case #%d: RICHARD\n",t);
 			continue;
 		}
 		if( x <= 2 )
 		{
 			printf("Case #%d: GABRIEL\n",t);
 			continue;
 		}
 		if( x <= 6 )
 		{
 			if( r >= x-1 && c >= x-1 )
 				printf("Case #%d: GABRIEL\n",t);
 			else
 				printf("Case #%d: RICHARD\n",t);
 			continue;
 		}
 		else
 			printf("Case #%d: RICHARD\n",t);
 	}
 	return 0;
 }
 
 
 

