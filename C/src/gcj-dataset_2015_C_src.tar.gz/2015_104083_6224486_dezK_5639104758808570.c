#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int people[1000];
 int count;
 
 void store(int n, int maxShy)
 {
 	while (maxShy >= 0)
 	{
 		people[maxShy] = n%10;
 		n = n/10;
 		--maxShy;
 	}
 }
 
 int do_stuff()
 {
 	printf("Case #%d: ", ++count);
 	int standPeople = 0;
 	int friends = 0;
 
 	int i;
 	int maxShy;
 	int numberOfPeople;
 	int turnedPeople;
 
 	scanf("%d", &maxShy);
 	scanf("%d", &numberOfPeople);
 
 	store(numberOfPeople, maxShy);
 
 	for (i = 0; i <= maxShy; ++i)
 	{
 		if(standPeople + friends < i)
 			friends = friends + (i - standPeople - friends);
 		standPeople += people[i];
 	}
 
 	printf("%d\n", friends);
 	return 0;
 }
 
 int main()
 {
 	count = 0;
 	int t; scanf("%d", &t);
 	while(t--)
 		do_stuff();
 
 	return 0;
 }
