#include<stdio.h>
 #include<string.h>
 
 char sub[50000];
 char fin[50000] = "";
 
 int mul[4][4] = 
 {{0, 0, 0, 0},
  {0,-1, 3,-2},
  {0,-3,-1, 1},
  {0, 2,-1,-1},
 };
 
 char ntc(int n) {
     if(abs(n) == 1)
         return 'i';
     if(abs(n) == 2)
         return 'j';
     if(abs(n) == 3)
         return 'k';
 }
 
 int ctn(char n) {
     if(n == 'i')
         return 1;
     if(n == 'j')
         return 2;
     if(n == 'k')
         return 3;
 }
 
 int summ(int a, int b) {
     int ans, prev, i, j;
     ans = ctn(fin[a]);
     for(i = a + 1; i <= b; i++) {
         prev = ans;
         ans = mul[abs(prev)][ctn(fin[i])];
         if(prev < 0)
            ans *= -1;
     }
     return ans;
 }
 
 int main() {
     int t, cases = 1;
     scanf("%d", &t);
     while(t--) {
         int  subtotal;
         int  s[50000], p[50000];
         int l, x, i, j, k, found = 0;
         scanf("%d%d", &l, &x);
         scanf("%s", sub);
         strcpy(fin, "");
         for(i = 0; i < x; i++) {
             strcat(fin, sub);
         }
         s[0] = ctn(fin[0]);
         for(i = 1; i < l * x; i++) {
             s[i] = mul[abs(s[i-1])][ctn(fin[i])];
             if(s[i-1] < 0)
                 s[i] *= -1;
         }
         subtotal = s[l*x-1];
         if(subtotal == -1)
             printf("Case #%d: YES\n", cases++);
         else
             printf("Case #%d: NO\n", cases++);
     }
 }

