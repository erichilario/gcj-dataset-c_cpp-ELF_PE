#include<stdio.h>
 int main()
 {
     int t,i,n,a,j,c;
     long long int sn;
     scanf("%d",&t);
     i=1;
     while(t--)
     {
         scanf("%d",&n);
         char a[n+1];
         j=0;
         sn=0;
         c=0;
         scanf("%s",a);
         while(j<=n)
         {
             if(j>sn)
                 c+=j-sn,sn+=j-sn;
             //scanf("%c",&a[j]);
             sn+=a[j]-48;
             j++;
         }
         printf("Case #%d: %d\n",i++,c);
     }
     return 0;
 }

