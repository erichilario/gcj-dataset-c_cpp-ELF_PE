#include <stdio.h>
 
 int main()
 {
 	int T = 0, k = 0, j, total_people;
 	long long int solution;
 	int s_max;
 	char temp;
 	scanf("%d",&T);
 
 	while(k++ < T)
 	{
 		solution = 0;
 		j = 0, total_people = 0;
 		scanf("%d ", &s_max);
 		while(j <= s_max)
 		{
 			scanf("%c", &temp);
 			if (temp != '0' && total_people - j < 0)
 			{
 				solution += j - total_people;
 				total_people += j - total_people;
 			}
 			total_people += temp - '0';	
 			j++;
 		}
 		scanf("%c", &temp);
 		printf("Case #%d: %lld\n", k, solution);
 	}
 	return 0;
 }

