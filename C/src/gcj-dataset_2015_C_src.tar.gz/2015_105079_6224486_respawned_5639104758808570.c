#include <stdio.h>
 
 int audience[1001];
 int accum[1001];
 char buf[1002];
 
 int main() {
     int t, s_max, count, iter;
     scanf("%d", &t);
 //    printf("Test cases: %d", t);
     iter = 1;
     while(t-- != 0) {
         count = 0;
         accum[0] = 0;
         scanf("%d %s", &s_max, buf);
         for (int i = 0; i <= s_max; i++) {
             audience[i] = buf[i] - '0';
             //printf("Num: %d", audience[i]);
         }
         accum[0] = audience[0];
         for (int i = 1; i <= s_max; i++) {
             if (accum[i-1] < i) {
                 count += i - accum[i - 1];
                 accum[i - 1] = i; 
             } 
             accum[i] = accum[i-1] + audience[i];
         }
         printf("Case #%d: %d\n", iter, count);
         iter++;
     }
     return 0;
 }

