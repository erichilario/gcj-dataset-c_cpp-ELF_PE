#include <stdio.h>
 #include <stdlib.h>
 
 unsigned char field[4][4];
 FILE * fin, *fout;
 int cases;
 
 unsigned int plus;
 unsigned int sum;
 int num;
 int act;
 char buf[2000];
 
 int main(){
 	int i,j;
 	fin=fopen("in2.txt","r");
 	fout=fopen("out2.txt","w");
 	if(fin == NULL){
 		printf("AAAA \n");
 		return(1);
 	}
 	/*while(fgets(buf,255,fin)){
 		printf("%s\n",buf);
 	}*/
 	fscanf(fin,"%d\n", &cases);
 	//fscanf(fin,"%s",buf);
 	//printf("ok? :%s\n",buf);
 	printf("cases: %d\n",cases);
 	for(i=1;i<=cases;i++){
 		memset(buf,0,sizeof(buf));
 		printf("Case #%d\n",i);
 		fscanf(fin,"%s\n",buf);
 		num=buf[0]-'0';
 		printf("num: %d, buf[0]: %c, buf:%s\n",num,buf[0],buf);
 		fscanf(fin,"%s\n",buf);
 		fprintf(fout,"Case #%d: ",i);
 		sum=0;
 		plus=0;
 		for(j=0;j<=num;j++)
 		{
 			act=buf[j]-'0';
 			if(sum<j)
 			{
 				plus+=j-sum;
 				sum=j;
 			}	
 			sum+=act;
 		}
 		printf("plus: %d\n", plus);
 		fprintf(fout,"%d\n",plus);
 		
 	}
 	return(0);		
 } 

