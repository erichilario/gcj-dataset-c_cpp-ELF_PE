#include "stdio.h"
 int f[1000];
 int main(){
 	int T,D,x;
 	freopen("b1.in","r",stdin);
 	freopen("b1.out","w",stdout);
 	scanf("%d",&T);
 	for(int i=1;i<=T;i++){
 		int Ans = 1000;
 		scanf("%d",&D);
 		for(int j=0;j<D;j++)
 			scanf("%d",&f[j]);
 		for(int k=1;k<=1000;k++){
 			int Temp = 0;
 			for(int j=0;j<D;j++)
 				if (f[j]>k) Temp += ((f[j]-1) / k);
 			Temp += k;
 			if (Ans > Temp) Ans = Temp;
 		}
 		printf("Case #%d: %d\n",i,Ans);
 	}
 	fclose(stdin);
 	fclose(stdout);
 	return 0;
 }
