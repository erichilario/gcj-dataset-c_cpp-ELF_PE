#include<stdio.h>
 int main()
 {
 	int t,temp,ans,i,sum,a,k;
 	char s[1001];
 	scanf("%d",&t);
 	for(k=1;k<=t;k++)
 	{
 		scanf("%d",&a);
 		scanf("%s",s);
 		sum=s[0]-48;
 		ans=temp=0;
 		for(i=1;i<=a;i++)
 		{
 			
 			if((s[i]-48)>0)
 			{
 			if(i>sum)
 			{
 			temp=i-sum;
 			ans+=temp;
 			}//printf("temp=%d",temp);
 			sum+=temp+s[i]-48;
 			temp=0;
 			}
 			
 		}
 		printf("Case #%d: %d\n",k,ans);
 	}
 	return 0;
 }

