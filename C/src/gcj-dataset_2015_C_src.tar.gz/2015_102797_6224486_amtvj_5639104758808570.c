#include <stdio.h>
 
 int main()
 {
 	int t,n,i,j;
 	scanf("%d",&t);
 	for(j=1;j<=t;j++)
 	{
 		char str[1010];
 		scanf("%d",&n);
 		scanf("%s",str);
 		int a[n+1];
 		for(i=0;i<n+1;i++){
 			a[i]=str[i]-48;
 		}
 		long sum=0;
 		long count2=0;
 		for(i=0;i<n+1;i++){
 			if(count2 < i){
 				sum+=i-count2;
 				a[i]+=i-count2;
 
 			}
 			count2+=a[i];
 		}
 		printf("Case #%d: %ld\n",j,sum);
 	}
 	return 0;
 }

