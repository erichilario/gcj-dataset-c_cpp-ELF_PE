#include <stdio.h>
 #define DEF
 #define P_LIM 9
 
 int main (void){
 	#ifdef DEF
 	freopen("B-small-attempt5.in", "r", stdin);
 	#endif
 	
 	#ifdef DEF
 	freopen("B-small-attempt5.out", "w", stdout);
 	#endif
 	
 	int t,i,d,j,p,time, max,max2;
 	int a[P_LIM]; //a[k-1] = the number of plates that have k pancakes
 	//max - p max after all special minutes, if any (1, 2, or 3)
 	
 	scanf("%d",&t);
 	for (i = 0; i < t; i++){
 		scanf("%d", &d);
 		
 		time = 0;
 		max = 1;
 		
 		for (j = 0; j < P_LIM; j++) a[j] = 0;
 		
 		for (j = 0; j < d; j++){
 			scanf("%d",&p);
 			a[p-1]++;
 			
 			if (p > max) max = p;
 		}
 		
 		max2 = max - 1;
 		while (max2 >= 1 && a[max2 - 1] == 0) max2--;
 		if ((max + 1)/2 > max2) max2 = (max + 1)/2;
 		
 		while (max > a[max - 1] + max2){
 			if (max %2 == 0) a[max/2 - 1] += 2*a[max - 1];
 			else{
 				a[max/2] += a[max - 1];
 				a[max/2 - 1] += a[max - 1];
 			}
 			time += a[max - 1];
 			a[max - 1] = 0;
 			
 			//while (a[max - 1] == 0) max--;
 			max = max2;
 			
 			max2 = max - 1;
 			while (max2 >= 1 && a[max2 - 1] == 0) max2--;
 			if ((max + 1)/2 > max2) max2 = (max + 1)/2;
 		}
 		
 		time += max;
 		
 		printf("Case #%d: %d\n",i+1,time);
 	}
 	
 	return 0;
 }

