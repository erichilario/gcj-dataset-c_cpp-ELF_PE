#include<stdio.h>
 
 
 int main()
 {
    int T,x,r,c;
    int i;
    scanf("%d",&T);
    for( i=1;i<=T;i++)
    {
        scanf("%d%d%d",&x,&r,&c);
 
        if(x>=7)
        {
            printf("Case #%d: RICHARD\n",i);
        }
        else if(x==1)
        {
            printf("Case #%d: GABRIEL\n",i);
        }
        else if((r*c)%x==0)
        {
            switch(x)
            {
 
                case 3: if((r*c)<=x)
                            printf("Case #%d: RICHARD\n",i);
                        else
                            printf("Case #%d: GABRIEL\n",i);
                         break;
               case 4: if((r*c)<=x*2)
                            printf("Case #%d: RICHARD\n",i);
                        else
                            printf("Case #%d: GABRIEL\n",i);
                        break;
               case 5: if((r*c)<=x*3)
                            printf("Case #%d: RICHARD\n",i);
                        else
                            printf("Case #%d: GABRIEL\n",i);
                        break;
               case 6: if((r*c)<=x*3)
                            printf("Case #%d: RICHARD\n",i);
                        else
                            printf("Case #%d: GABRIEL\n",i);
                         break;
               default: printf("Case #%d: GABRIEL\n",i);
            }
 
        }
       // else
        {
            printf("Case #%d: RICHARD\n",i);
        }
 	}
 	return 0;
 }
 

