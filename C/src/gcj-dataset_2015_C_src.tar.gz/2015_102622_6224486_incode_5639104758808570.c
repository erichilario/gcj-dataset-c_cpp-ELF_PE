 #include<stdio.h>
 int main()
 {
 	int t,j,i,n,std,smax;
 	char s[1001];
 	scanf("%d",&t);
 	for(j=0;j<t;)
 	{
 		scanf("%d",&smax);
 		scanf("%s",s);
 		n=0;
 		std=0;                           
 		for(i=0; i<=smax ;i++)
 		{
 			if( s[i]=='0' && i==0 )
 			{
 					n=1;
 					std=1;
 			}
 			else {
 				if( std < i )
 				{
 					n++;
 					std++;
 				}
 				std+=(s[i]-'0');
 			}
 		}
 		printf("Case #%d: %d\n",++j,n);
 		}
 		return 0;
 }

