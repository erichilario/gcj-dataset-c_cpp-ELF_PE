#include<stdio.h>
 char s[10001];
 char r[10001];
 int main()
 {
 	int t,l,x,i,j,k,flag,flag1,m;
 	FILE *p,*o;
 	p=fopen("C-small-attempt1.in","r");
 	o=fopen("out.out","w");
 	fscanf(p,"%d",&t);
 	for(j=1;j<=t;j++)
 	{
 		k=0;
 		fscanf(p,"%d%d",&l,&x);
 		fscanf(p,"%s",s);
 		
 		for(i=0;i<x*l;i++)
 		r[i]=s[k++%l];
 		
 		flag1=0;flag=0;m=0;
 		for(i=0;i<x*l;i++)
 		{
 			if(r[i]=='i' && flag==0)
 			{
 				s[m++]='i';
 				flag=1;
 			//	printf("i is inserted\n");
 			}
 			else if(r[i]=='j' && flag==1)
 			{
 				s[m++]='j';
 				flag=2;
 			//	printf("j is inserted\n");
 			}
 			else if(r[i]=='k' && flag==2)
 			{
 				s[m++]='k';
 				flag=0;
 				if(i==x*l-1)
 				flag1=1;
 			//	printf("k is inserted\n %d",flag1);
 			}
 			else if(r[i]=='i')
 			{
 				if(r[i+1]=='i')
 				r[i+1]='-';
 				else if(r[i+1]=='j')
 				r[i+1]='k';
 				else if(r[i+1]=='k')
 				r[i+1]='b';
 			}
 			else if(r[i]=='j')
 			{
 				if(r[i+1]=='i')
 				r[i+1]='c';
 				else if(r[i+1]=='j')
 				r[i+1]='-';
 				else if(r[i+1]=='k')
 				r[i+1]='i';
 			}
 			else if(r[i]=='k')
 			{
 				if(r[i+1]=='i')
 				r[i+1]='j';
 				else if(r[i+1]=='j')
 				r[i+1]='a';
 				else if(r[i+1]=='k')
 				r[i+1]='-';
 			}
 			else if(r[i]=='a')
 			{
 				if(r[i+1]=='i')
 				r[i+1]='1';
 				else if(r[i+1]=='j')
 				r[i+1]='c';
 				else if(r[i+1]=='k')
 				r[i+1]='j';
 			}
 			else if(r[i]=='b')
 			{
 				if(r[i+1]=='i')
 				r[i+1]='k';
 				else if(r[i+1]=='j')
 				r[i+1]='1';
 				else if(r[i+1]=='k')
 				r[i+1]='a';
 			}
 			else if(r[i]=='c')
 			{
 				if(r[i+1]=='i')
 				r[i+1]='b';
 				else if(r[i+1]=='j')
 				r[i+1]='i';
 				else if(r[i+1]=='k')
 				r[i+1]='1';
 			}
 			else if(r[i]=='-')
 			{
 				if(r[i+1]=='i')
 				r[i+1]='a';
 				else if(r[i+1]=='j')
 				r[i+1]='b';
 				else if(r[i+1]=='k')
 				r[i+1]='c';
 			}
 			else if(r[i]=='1')
 			{
 				if(r[i+1]=='i')
 				r[i+1]='i';
 				else if(r[i+1]=='j')
 				r[i+1]='j';
 				else if(r[i+1]=='k')
 				r[i+1]='k';
 			}
 		}
 		if(s[0]=='i' && s[1]=='j' && s[2]=='k' && flag1==1)
 		fprintf(o,"Case #%d: YES\n",j);
 		else
 		fprintf(o,"Case #%d: NO\n",j);
 		
 		
 	}
 	
 }

