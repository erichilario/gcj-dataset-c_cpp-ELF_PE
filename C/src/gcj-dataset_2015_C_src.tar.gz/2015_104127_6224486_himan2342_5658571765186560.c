#include<stdio.h>
 #include<stdlib.h>
 void one_omin(int X,int R,int C);
 void two_omin(int X,int R,int C);
 void three_omin(int X,int R,int C);
 void four_omin(int X,int R,int C);
 void five_above(int X,int R,int C);
 int case1;
 int main()
 {
 	int X,R,C; 	
 	int t;
 	FILE *fp;
 	if((fp=fopen("D-small-attempt0.in","r"))==NULL)
 	{
 		fprintf(stderr,"can't open your file\n");
 		exit(1);
 	}
 	else
 	{		
 		if(fscanf(fp,"%d",&t)==1)
 		{
 			while((fscanf(fp,"%d %d %d",&X,&R,&C))==3)
 			{
 				case1++;
 				switch(X)
 				{
 					case 1:one_omin(X,R,C);break; 
 					case 2:two_omin(X,R,C);break;
 					case 3:three_omin(X,R,C);break;
 					case 4:four_omin(X,R,C); break;
 					default :five_above(X,R,C);break;
 
 				}
 		
 			}
 
 		}
 
 	}
 	fclose(fp);
 }
 void one_omin(int X,int R,int C)
 {
 	printf("Case #%d: GABRIEL\n",case1);
 }
 void two_omin(int X,int R,int C)
 {
 	if ((R*C)%2==0)
 	{
 		printf("Case #%d: GABRIEL\n",case1);		
 	}
 	else
 	{
 		printf("Case #%d: RICHARD\n",case1);
 
 	}
 
 }
 void three_omin(int X,int R,int C)
 {
 	if((R==2 && C==3)||(R==3 && C==2))
 		printf("Case #%d: GABRIEL\n",case1);
 
 	else if((R==3 && C==4)||(R==4 && C==3))
 		printf("Case #%d: GABRIEL\n",case1);
 
 	else if(R==3 && C==3)
 		printf("Case #%d: GABRIEL\n",case1);
 	else
 		printf("Case #%d: RICHARD\n",case1);
 }
 void four_omin(int X,int R,int C)
 {
 	if((R==3 && C==4)||(R==4 && C==3))
 		printf("Case #%d: GABRIEL\n",case1);
 
 
 	else if(R==4 && C==4)
 		printf("Case #%d: GABRIEL\n",case1);
 	else
 		printf("Case #%d: RICHARD\n",case1);
 }	
 
 
 void five_above(int X,int R,int C)
 {
 
 		printf("Case #%d: RICHARD\n",case1);
 
 }

