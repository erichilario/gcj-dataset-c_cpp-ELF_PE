#include <stdio.h>
 
 int main(void) 
 {
 	int t,smax,i,temp,len,sum=0,ans=0;
 	char s[10001];
 	scanf("%d",&t);
 	int sw=1;
 	while(t--)
 	{
 		
 		ans=0;
 		sum=0;
 		scanf("%d",&smax);
 		scanf("%s",s);
 		len=smax+1;
 		sum=s[0]-'0';
 		for(i=1;i<=smax;i++)
 		{
 			temp=s[i]-'0';
 			if(sum<i&&(temp!=0))
 			{
 				ans=ans+(i-sum);
 				sum=sum+(i-sum);
 			}
 			sum=sum+temp;
 		}
 		printf("Case #%d: %d\n",sw++,ans);
 		
 	}
 	// your code goes here
 	return 0;
 }
 

