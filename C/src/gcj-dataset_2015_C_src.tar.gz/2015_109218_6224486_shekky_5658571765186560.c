#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 void one_omino(int x,int r,int c);
 void two_omino(int x,int r,int c);
 void three_omino(int x,int r,int c);
 void four_omino(int x,int r,int c);
 void five_above(int x,int r,int c);
 int case1;
 
 int main()
 {
 	int x,r,c; 	
 	int T;
 	FILE *fv;
 	if((fv=fopen("D-small-attempt2.in","r"))==NULL)
 	{
 		fprintf(stderr,"can't open file");
 		exit(1);
 	}
 	else
 	{		
 		if(fscanf(fv,"%d",&T)==1)
 		{
 			while(fscanf(fv,"%d %d %d",&x,&r,&c)==3)
 			{
 				case1++;
 				switch(x)
 				{
 					case 1:one_omino(x,r,c);break; 
 					case 2:two_omino(x,r,c);break;
 					case 3:three_omino(x,r,c);break;
 					case 4:four_omino(x,r,c); break;
 					default :five_above(x,r,c);break;
 
 				}
 		
 			}
 
 		}
 
 	}
 	
 	fclose(fv);
 }
 
 void one_omino(int x,int r,int c)
 {
 	
 	printf("Case #%d: GABRIEL\n",case1);
 
 }
 void two_omino(int x,int r,int c)
 {
 	if ((r*c)%2==0)
 	{
 		printf("Case #%d: GABRIEL\n",case1);		
 	}
 	else
 	{
 		printf("Case #%d: RICHARD\n",case1);
 
 	}
 
 }
 void three_omino(int x,int r,int c)
 {
 	if((r==2 && c==3)||(r==3 && c==2))
 		printf("Case #%d: GABRIEL\n",case1);
 
 	else if((r==3 && c==4)||(r==4 && c==3))
 		printf("Case #%d: GABRIEL\n",case1);
 
 	else if(r==3 && c==3)
 		printf("Case #%d: GABRIEL\n",case1);
 	else
 		printf("Case #%d: RICHARD\n",case1);
 }
 void four_omino(int x,int r,int c)
 {
 	if((r==3 && c==4)||(r==4 && c==3))
 		printf("Case #%d: GABRIEL\n",case1);
 
 
 	else if(r==4 && c==4)
 		printf("Case #%d: GABRIEL\n",case1);
 	else
 		printf("Case #%d: RICHARD\n",case1);
 }	
 
 
 void five_above(int x,int r,int c)
 {
 
 		printf("Case #%d: RICHARD\n",case1);
 
 }

