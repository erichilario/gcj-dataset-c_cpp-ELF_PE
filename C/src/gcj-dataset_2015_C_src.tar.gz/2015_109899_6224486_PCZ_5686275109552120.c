#include <stdio.h>
 
 #define MAXP 1000
 
 int n,t,ans,spet,et,maxpp;
 int sum[MAXP+10];
 
 int main()
 {
     int tt,i,j,k;
     freopen("data.in","r",stdin);
     freopen("data.out","w",stdout);
     scanf("%d",&t);
     for(tt=1;tt<=t;tt++)
     {
         for(i=0;i<MAXP;i++) sum[i]=0;
         scanf("%d",&n);
         maxpp=1;
         for(i=1;i<=n;i++)
         {
             scanf("%d",&j);
             sum[j]++;
             if(j>maxpp) maxpp=j;
         }
         ans=maxpp;
         for(et=1;et<=maxpp;et++)
         {
             spet=0;
             for(i=et+1;i<=maxpp;i++)
             {
                 spet+=((i-1)/et)*sum[i];
             }
             spet+=et;
             if(spet<ans) ans=spet;
         }
         printf("Case #%d: %d\n",tt,ans);
     }
 
     return 0;
 }

