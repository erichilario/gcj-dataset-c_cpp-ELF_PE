#include <stdio.h>
 #include <stdlib.h>
 
 int main(){
 	long long T;
 	//scanf("%lld", &T);
 	long long s;
 	char str[10000000];
 	long long i=1, cas = 1, count;
 	FILE *ptrIn = fopen("A-large.in", "r");
 	FILE *ptrOut = fopen("output.txt", "w");
 	fscanf(ptrIn, "%lld", &T);
 	while(T-->0){
 		count = 0;
 		
 		//scanf("%lld %s", &s, str);
 		fscanf(ptrIn, "%lld %s", &s, str);
 		//prlong longf("%s", str);
 		i=1;
 		long long stood= str[0] - 48, required=0;
 		while(str[i] != '\0'){
 			required = (i-stood)>0?(i-stood):0;
 			stood += (str[i]-48);
 			stood += required;
 			i++;
 			count += required;
 		}
 		//prlong longf("Case #%lld: %lld\n", cas, count);
 		fprintf(ptrOut, "Case #%lld: %lld\n",  cas, count);
 		cas++;
 	}
 	fclose(ptrIn);
 	fclose(ptrOut);
 	return 0;
 }
