#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 void main()
 {
     int test,i,j,index,c,temp;
     char people[8];
     FILE *fp,*fp1;
     fp=fopen("a.in","r");
     fp1=fopen("b.out","w");
     while(!feof(fp)){
     fscanf(fp,"%d",&test);
     for(i=1;i<=test;i++)
     {
         fscanf(fp,"%d %s",&index,people);
         c=0;
         temp=0;
         for(j=0;j<=index;j++)
         {
              temp=temp+(int)people[j]-48;
             if(temp<j+1)
             {
             temp=temp+1;
             c=c+1;
             }
         }
         fprintf(fp1,"Case #%d: %d\n",i,c);
     }
 
     }
 fclose(fp);
 fclose(fp1);
 }
 

