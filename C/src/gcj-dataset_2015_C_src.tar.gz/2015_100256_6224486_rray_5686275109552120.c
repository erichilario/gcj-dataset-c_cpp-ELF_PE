#include <iostream>
 #include <map>
 
 using namespace std;
 
 void insert_diner(map<int, int> &diners, int pancakes) {
   if(diners.find(pancakes) == diners.end()) {
     diners[pancakes] = 0;
   }
   diners[pancakes]++;
 }
 
 void remove_diner(map<int, int> &diners, int pancakes) {
   if(diners[pancakes] > 1) 
     diners[pancakes]--;
   else
     diners.erase(pancakes);
 }
 
 void iterate(map<int, int> &diners) {
   map<int, int>::iterator mit, men = diners.end();
   for(mit = diners.begin(); mit != men; ++mit) {
     cout << mit->first << " : " << mit->second << "\t";
   }
   cout << endl;
 }
 
 int min_mins(map<int, int> &diners) {
   map<int, int>::iterator r = diners.begin();
   int c = 0, d = 0;
   while(r->first - c < 0) {
     //iterate(diners);
     if(r->first - c < -3 && c - r->first > r->second) {
       remove_diner(diners, r->first);
       insert_diner(diners, (r->first+c)/2);
       insert_diner(diners, r->first - (r->first+c)/2);
       r = diners.begin();
     }
     else
       c--;
     d++;
   }
   return d;
 }
 
 int main() { 
   int t, i;
   int d, p;
   cin >> t;
   for(i = 0; i < t; ++i) {
     map<int, int> diners;
     cin >> d;
     while(d--) {
       cin >> p;
       insert_diner(diners, -p); 
     }
     //iterate(diners);
     cout << "Case #" << i + 1 << ": " << min_mins(diners) << endl;
   }
   return 0;
 }

