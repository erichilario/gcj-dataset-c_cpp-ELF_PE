#include <stdio.h>
 #include <string.h>
 int main()
 {
 	int t, T;
 	int X, R, C;
 	scanf("%d", &T);
 	for (t = 1; t <= T; ++t)
 	{
 		scanf("%d%d%d", &X, &R, &C);
 		if (X == 1)
 		{
 			printf("Case #%d: GABRIEL\n", t);
 		}
 		else if (X == 2)
 		{
 			if ((R * C) % 2 == 1)
 			{
 				printf("Case #%d: RICHARD\n", t);
 			}
 			else
 			{
 				printf("Case #%d: GABRIEL\n", t);
 			}
 		}
 		else if (X == 3)
 		{
 			if (R % 3 != 0 && C % 3 != 0)
 			{
 				printf("Case #%d: RICHARD\n", t);
 			} 
 			else if (R == 1 || C == 1)
 			{
 				printf("Case #%d: RICHARD\n", t);
 			}
 			else
 			{
 				printf("Case #%d: GABRIEL\n", t);
 			}
 		}
 		else if (X == 4)
 		{
 			if (R < 4 && C < 4)
 			{
 				printf("Case #%d: RICHARD\n", t);
 			}
 			else if (R <= 2 || C <= 2)
 			{
 				printf("Case #%d: RICHARD\n", t);
 			}
 			else
 			{
 				printf("Case #%d: GABRIEL\n", t);	
 			}
 		}
 	}
 }

