#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
 	FILE *fin, *fout;
 	int T;
 	int Richard, Gabriel;
 	int X, R, C, count = 1;
 	char fileName[50];
 
 	printf("Enter the file name:");
 	scanf("%s", fileName);
 
 
 	fin = fopen(fileName, "r");
 	fout = fopen("ans", "w");
 
 	fscanf(fin, "%d", &T);
 
 	while(T > 0)
 	{	
 		fscanf(fin, "%d %d %d", &X, &R, &C);
 	
 		if ((R * C) % (X) == 0)
 		{
 			if(((R * C) == X) && (X > 3))
 			{		
 				Richard = 1;
 				Gabriel = 0;
 			}
 			else
 			{
 				Gabriel = 1;
 				Richard = 0;	
 			}
 		}
 		else
 		{
 			Richard = 1;
 			Gabriel = 0;
 		}
 
 		if(Richard == 1)
 		{
 			fprintf(fout, "Case #%d: %s\n", count, "RICHARD");
 		}
 		else
 		{
 			fprintf(fout, "Case #%d: %s\n", count, "GABRIEL");
 		}
 		
 		count++;
 		T--;
 	}
 
 	fclose(fout);
 
 	return 0;
 }

