#include <stdio.h>
 
 #define sgn(a) ((a) > 0 ? 1 : -1)
 #define yes(n) printf("Case #%d: YES\n", (n))
 #define no(n) printf("Case #%d: NO\n", (n))
 
 int multiply(int mt[4][4], int a, int b)
 {
     int sgna = sgn(a);
     int sgnb = sgn(b);
     return sgna * sgnb * mt[a*sgna-1][b*sgnb-1];
 }
 
 int iseven(int a)
 {
     return a/2*2 == a;
 }
 
 int main(int argc, char **argv)
 {
     int mt[4][4] = {
             {1,  2,  3,  4},
             {2, -1,  4, -3},
             {3, -4, -1,  2},
             {4,  3, -2, -1}
     };
     int T,cs,c,m,i,j,k,l,calr,result;
     int mi,mk,donei,donek;
     char s[10000];
     scanf("%d", &T);
     for (i=0; i<T; i++) {
         scanf("%d %d", &cs, &m);
         getchar();
         calr = 1;
         for (j=0; j<cs; j++) {
             c = getchar();
             s[j] = c-'i'+2;
             calr = multiply(mt, calr, s[j]);
         }
         if (calr == -1) {
             if (iseven(m)) {
                 no(i+1);
                 continue;
             }
         } else if (calr == 1) {
             no(i+1);
             continue;
         } else {
             if (!iseven(m)) {
                 no(i+1);
                 continue;
             } else if (iseven(m/2)) {
                 no(i+1);
                 continue;
             }
         }
         mi=1;
         donei=0;
         for (j=0; j<cs*m-2; j++) {
             mi = multiply(mt, mi, s[j%cs]);
             if (mi == 2) {
                 donei=1;
                 break;
             }
         }
         mk=1;
         donek=0;
         for (k=cs*m-1; donei && k>j+1; k--) {
             mk = multiply(mt, s[k%cs], mk);
             if (mk == 4) {
                 donek=1;
                 yes(i+1);
                 break;
             }
         }
         if (!donei || !donek)
             no(i+1);
     }
     return 0;
 }

