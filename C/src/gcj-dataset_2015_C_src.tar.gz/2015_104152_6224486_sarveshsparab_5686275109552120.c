#include<stdio.h>
 void reduce(int p[],int d_new);
 void split(int p[],int d_new,int max_index);
 int getmax(int p[],int d_new);
 int getmaxcnt(int p[],int d,int max);
 int main(){
     int t,d,p[1005],max,max_index,max_cnt,i,spl,norm,d_new,caseno=1;
     scanf("%d",&t);
     while(t--){
        scanf("%d",&d);
        d_new=d;
        for(i=0;i<1005;i++){
             p[i]=0;
        }
        max=spl=norm=max_cnt=0;
        max_index=-1;
        for(i=0;i<d;i++){
             scanf("%d",&p[i]);
             if(p[i]>max){
                 max=p[i];
                 max_index=i;
             }
        }
        while(max){
             //printf("\n**max:  %d**\n",max);
             if(max%2!=0){
                 norm++;
                 reduce(p,d_new);
                 max--;
             }else{
                 max_cnt=getmaxcnt(p,d_new,max);
                 if(max_cnt<max/2){
                     spl++;
                     split(p,d_new,max_index);
                     d_new++;
                     max_index=getmax(p,d_new);
                     max=p[max_index];
                 }else{
                     norm++;
                     reduce(p,d_new);
                     max--;
                 }
             }
        }
        printf("Case #%d: %d\n",caseno++,spl+norm);
     }
     return 0;
 }
 int getmax(int p[],int d_new){
     int new_max_index=-1,i,m=0;
     for(i=0;i<d_new;i++){
         if(p[i]>m){
             m=p[i];
             new_max_index=i;
         }
     }
     return new_max_index;
 }
 int getmaxcnt(int p[],int d,int max){
     int i,cnt=0;
     for(i=0;i<d;i++){
         if(p[i]==max){
             cnt++;
         }
     }
     return cnt;
 }
 void split(int p[],int d_new,int max_index){
     p[max_index]=p[max_index]/2;
     p[d_new]=p[max_index];
 }
 
 void reduce(int p[],int d_new){
     int i;
     for(i=0;i<d_new;i++){
         if(p[i]!=0){
             p[i]--;
         }
     }
 }

