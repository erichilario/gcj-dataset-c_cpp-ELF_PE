# include<stdio.h>
 int main()
 {
     int test,xxx,r,c,j,prod;
     scanf("%d",&test);
     for(j=1;j<=test;j++)
     {
         scanf("%d%d%d",&xxx,&r,&c);
         prod=r*c;
         if( xxx==1 )
         {
                printf("Case #%d: GABRIEL\n",j); 
         }
         else if ( xxx==2 )
         {
             if( prod%2==0 )
               printf("Case #%d: GABRIEL\n",j);
             else
               printf("Case #%d: RICHARD\n",j);
         }
         else if ( xxx==3 )
         {
             if(prod>4 && prod!=8 && prod!=16)
               printf("Case #%d: GABRIEL\n",j);
             else
             printf("Case #%d: RICHARD\n",j);  
         }
         else if ( xxx==4 )
         {
              if( prod==12 || prod==16)
                printf("Case #%d: GABRIEL\n",j);
              else 
              	printf("Case #%d: RICHARD\n",j);
         }
     } 
 return 0;
 }

