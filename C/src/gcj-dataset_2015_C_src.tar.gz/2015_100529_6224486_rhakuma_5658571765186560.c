#include <stdio.h>
 
 #define MAX_LINE_BUFFER 1024
 
 int main(int argc, char* argv[]) {
     FILE *ifile;
     FILE *ofile;
     char* filename = NULL;
     char* outfile = "output.txt";
 
     int count, i;
     int x, r, c;
     int gabriel_win;
     
     if (argc != 2) {
         printf("usage: %s input.txt\n", argv[0]);
         return 1;
     }
 
     filename = argv[1];
     printf("filename: %s\n", filename);
 
     ifile = (FILE *) fopen(filename, "r");
     ofile = (FILE *) fopen(outfile, "w");
 
     fscanf(ifile, "%d", &count);
     for (i=0; i<count; i++) {
         fscanf(ifile, "%d %d %d", &x, &r, &c);
 
         gabriel_win = 0;
         if ((r*c - x) >= x)
             gabriel_win = 1;
 
         fprintf(ofile, "Case #%d: %s\n",
             (i+1),
             (gabriel_win == 1) ? "GABRIEL" : "RICHARD");
     }
 
     fclose(ifile);
     fclose(ofile);
 
     return 0;
 }
 

