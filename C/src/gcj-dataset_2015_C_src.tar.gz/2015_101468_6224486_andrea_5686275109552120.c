#include <stdio.h>
 #define MAX_D 6
 #define MAX_P 9
 
 int d, piatti[MAX_D];
 
 int min(int, int);
 int analizza();
 
 int main(int argc, char **argv)
 {
 	int t, tc;
 	int i, time;
 	FILE *in, *out;
 	in = fopen("B-small-attempt0.in", "r");
 	out = fopen("result-B.out", "w");
 	
 	fscanf(in, "%d", &tc);
 	for(t=1; t<=tc; t++) {
 		fscanf(in, "%d", &d);
 		for(i=0; i<d; i++)
 			fscanf(in, "%d", &piatti[i]);
 		
 		time = analizza();
 		fprintf(out, "Case #%d: %d\n", t, time);
 	}
 	
 	fclose(in);
 	fclose(out);
 	return 0;
 }
 
 int analizza() {
 	int max = piatti[0], max2=-1, i, pezzetto, n_mag_pezzetto, tempo=0, tempo2=0;
 	for(i=1; i<d; i++)
 		if(max<piatti[i])
 			max = piatti[i];
 
 	pezzetto = (max / 2) + (max % 2);
 	for(i=0, n_mag_pezzetto=0; i<d; i++)
 		if(piatti[i] > pezzetto && piatti[i] != max) {
 			n_mag_pezzetto++;
 			if(max2==-1)
 				max2 = piatti[i];
 			if(max2 < piatti[i])
 				max2 = piatti[i];
 		}
 	tempo = 1 + pezzetto + n_mag_pezzetto;
 	tempo2 = 1 + max2;
 	if(tempo2==0)
 		return min(max, tempo);
 	return min(max, min(tempo, tempo2));
 }
 
 int min(int a, int b) {
 	return ((a<b) ? a : b);
 }

