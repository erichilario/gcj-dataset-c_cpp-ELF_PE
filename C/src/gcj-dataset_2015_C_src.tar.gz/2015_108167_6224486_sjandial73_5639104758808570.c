#include<stdio.h>
 #include<stdlib.h>
 
 void main()
 {
     int t,s_max,i,j,c,sum;
     char s[1002];
     scanf("%d",&t);
     j=0;
     while(t--)
     {
         scanf("%d",&s_max);
         scanf("%s",s);
         sum=0,c=0;
         for(i=0;s[i]!='\0';i++)
         {
             if(s[i]=='0')
                 continue;
             else{
                 if(sum>=i)
                     sum+=(int)(s[i]-48);
                 else
                 {
                     c=c+(i-sum);
                     sum=sum+c+(int)(s[i]-48);
                 }
             }
             }++j;
             printf("\nCase #%d: %d",j,c);
     }
 }

