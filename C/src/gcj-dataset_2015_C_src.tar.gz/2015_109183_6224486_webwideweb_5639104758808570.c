#include <stdio.h>
 
 int main(int argc, char* argv[]) {
   FILE *in, *out;
   int caseNo;
 
   // command line params
   if(argc != 3){
     printf("usage:%s inFile outFile\n",argv[0]);
     return -1;
   }
   in = fopen(argv[1],"r");
   if(!in) {
     printf("open input file %s failed\n",argv[1]);
     return -1;
   }
   out = fopen(argv[2],"w");
   if(!out) {
     printf("create output file %s failed\n",argv[2]);
     fclose(in);
     return -1;
   }
 
   fscanf(in, "%d", &caseNo);
 
   for (int i=1; i<=caseNo; i++) {
     int sMax;
     char level[1001];
     int inviteNo = 0;
     int curStand = 0;
     fscanf(in, "%d%s", &sMax, level);
     for (int j=0; j<=sMax; j++) {
       int s = level[j]-'0';
       if (s > 0) {
         int addedNo = 0;        
         if (j>curStand) {
           addedNo = j - curStand;
           inviteNo = inviteNo + addedNo;
         }
         curStand = curStand + s + addedNo;        
       }   
     }
     fprintf(out, "Case #%d: %d\n",i,inviteNo);
   }
 
   fclose(in);
   fclose(out);
   return 0;
 }
 

