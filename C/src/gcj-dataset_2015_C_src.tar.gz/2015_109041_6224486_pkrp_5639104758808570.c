#include<stdio.h>
 int main()
 {
 	FILE *fp1,*fp2;
 	int t,smax,i,c=1;
 	char s[1005];
 	fp1=fopen("A-large.in","r");
 	fp2=fopen("res2.txt","w");
 	fscanf(fp1,"%d",&t);
 	while(t--)
 	{
 		long cnt=0,ans=0;
 		fscanf(fp1,"%d %s",&smax,s);
 		cnt+=s[0]-'0';
 		for(i=1;i<=smax;++i)
 		{
 			if(cnt<i)
 			{
 				ans+=i-cnt;
 				cnt+=i-cnt+(s[i]-'0');
 			}
 			else cnt+=(s[i]-'0');
 		}
 		fprintf(fp2,"Case #%d: %ld\n",c++,ans);
 	}
 	
 	fclose(fp1);
 	fclose(fp2);
 	return 0;
 }

