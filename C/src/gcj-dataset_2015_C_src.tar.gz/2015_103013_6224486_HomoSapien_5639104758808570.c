#include<stdlib.h>
 #include<stdio.h>
 
 int nfriends(int k, int people)
 {
     if (k<=people)
     {
          return 0;
     }
     else
     {
         return (k-people);
     }
 }
 
 int main()
 {
     FILE* inputFile = fopen("input2.txt", "r");
     if(inputFile == NULL)
     {
         printf("Cannot open file!\n");
         exit(1);
     }
 
 	int c;
 	int i;
 	int j;
 	int people = 0;
 
 	int temp;
 	int temp2;
 	int k;
     char ch;
 	int friends = 0;
 
 	fscanf(inputFile, "%d", &c);
 
 	fseek(inputFile, 2, SEEK_CUR);
 
 	FILE* outputFile = fopen("output.txt", "w");
     if(outputFile == NULL)
     {
         printf("Cannot open file!\n");
         exit(1);
     }
 
 	for(i = 0; i<c; i++)
     {
         int max;
 
         fscanf(inputFile, "%d", &max);
 
         printf("max: %d\n", max);
 
         fseek(inputFile, 1, SEEK_CUR);
 
  //       ch = getc(inputFile);
 
         people = 0; k = 0; j = 0;
 
         friends = 0;
 
         for(j=0; j<=max; j++)
         {
             fscanf(inputFile, "%1d", &temp);
 
 //            if (j==0)
 //            {
 //                people += temp;
 //
 //                printf("temp2: %d\n", temp);
 //            }
 
  //           fscanf(inputFile, "%1d", &temp);
 
             printf("temp %d\n", temp);
 
             for(k=0; k<temp; k++)
             {
                 temp2 = nfriends(j, people);
 
                 friends += temp2;
 
                 people += (temp2+1);
 
                 printf("people: %d\n", people);
             }
         }
 
 //        outputFile << "Case #" << i << ": " << people << endl;
 
         fprintf(outputFile, "%s %c%d%c %d\n", "Case", '#', i+1, ':', friends);
 
 //      ch = getc(inputFile);
 
         fseek(inputFile, 2, SEEK_CUR);
 
 	}
 
 	fclose(inputFile);
 	fclose(outputFile);
 
 return 0;
 }

