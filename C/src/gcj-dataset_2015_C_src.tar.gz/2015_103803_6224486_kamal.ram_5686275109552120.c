#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <malloc.h>
 #define MAXLENGTH (1010)
 FILE *inputfp = NULL;
 FILE *outputfp = NULL;
 char *readInput();
 int findmax(char *);
 int main()
 {
     int t, d, n, i , a, count, done, max;
     char *p = NULL;
     inputfp = fopen("input.in", "r");
     outputfp = fopen("output.out", "w");
     if(inputfp)
     {
         t = atoi(readInput());
         n = 1;
         while (n <= t)
         {
             if(p != NULL)
             {
                 free(p);
                 p=NULL;
             }
             d = atoi(readInput());
             p = readInput();
             done = 0;
             count = 0;
             while(done == 0)
             {
                 max = findmax(p);
                 if(max>1)
                 {
                     i=0;
                     while(p[i] != 0)
                     {
                         if((p[i]-48) == max)
                         {
                             a = p[i] - 48;
                             a = (a + 1)/2;
                             p[i] = a + 48;
                         }
                         i++;
                     }
                     count++;
                 }
                 else if(max == 1)
                 {
                     count++;
                     done = 1;
                 }
                 else
                 {
                     done = 1;
                 }
             }
             fprintf(outputfp, "%s%d%s%d%s", "Case #", n, ": ", count, "\n");
             n++;
         }
 
     }
     return 0;
 }
 char *readInput()
 {
     int   inputChar;              /* Input Character */
     int   index;                  /* To update array */
     char *str;
     /* Initialise */
     str = (char *) malloc(MAXLENGTH);
     index = 0;
     /* Read Line */
     while ( ((inputChar = fgetc(inputfp)) != EOF) && (inputChar != '\n'))
     {
         /* Update Array */
         if (inputChar != ' ') { str[index] = inputChar; index++;}
     }
     str[index] = 0;
     /* Store Line */
 
     return(str);
 }
 int findmax(char *str)
 {
     int i, max=(str[0] - 48);
     for(i=0; str[i]!=0; i++)
     {
         if((str[i]-48)>max)
         {
             max = str[i]-48;
         }
     }
     return max;
 }

