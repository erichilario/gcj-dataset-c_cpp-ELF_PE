#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, char** argv)
 {
   FILE* file = fopen(argv[1], "r");
   int i;
   int T, X, R, C;
 
   fscanf(file, "%d\n", &T);
 
   for(i=0; i<T; i++){
     printf("Case #%d: ", i+1);
     fscanf(file, "%d %d %d\n", &X, &R, &C);
     if(((R*C)%X != 0) || 
        (!(R>=X && C>=X-1) && !(C>=X && R>=X-1)) ||
        (R >= 7))
       printf("RICHARD\n");
     else
       printf("GABRIEL\n");
   }
 
   fclose(file);
 
   return EXIT_SUCCESS;
 }

