#include <stdio.h>
 #include <stdlib.h>
 
 int main ( int argc, char * argv[])
 {
 	FILE *file;
     file = fopen(argv[1], "r" );
 
     FILE *output;
     output = fopen("output.txt", "w" );
 
     int casos = 0;
 
 
     fscanf(file, "%d\n", &casos);
 
     for(int i = 0; i < casos; i++)
     {
     	int total_pessoas = 0;
     	int pessoas_empe = 0;
     	int amigos = 0;
 
     	fscanf(file, "%d ", &total_pessoas);
     	total_pessoas += 1;
 
     	char empe[total_pessoas];
 
     	fscanf(file, "%s", empe);
 
     	for(int j = 0; j < total_pessoas; j++)
     	{//shyness = j pessoas = soma dos valores de empe
            // printf("%d\n", empe[j] - '0');
             pessoas_empe += empe[j] - '0';
     		
     		if(pessoas_empe <= j)
             {
                 amigos++;
                 pessoas_empe++;
             } 
     	}	
         fprintf (output, "Case #%d: %d\n", i+1, amigos);
     }
 
 }
 
 /* 
 
 4
 4 11111
 1 09
 5 110011
 0 1
 4 30201 #0
 
 */
