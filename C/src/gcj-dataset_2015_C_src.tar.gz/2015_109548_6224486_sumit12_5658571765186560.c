#include<stdio.h>
 int main(){
 	int T,X,R,C,i;
 	scanf("%d",&T);
 	for(i=1;i<=T;i++){
 		scanf("%d%d%d",&X,&R,&C);
 		if(X==1){
 		    printf("Case #%d: GABRIEL\n",i);
 	    }
 	    else if(X==2){
 		    if(min(R,C)>=1 && max(R,C)>=2 && (R*C%X)==0){
 		    	printf("Case #%d: GABRIEL\n",i);
 		    }else{
 		    	printf("Case #%d: RICHARD\n",i);
 		    }
 	    }
 	    else if(X==3){
 		    if(min(R,C)>=2 && max(R,C)>=3 && (R*C%X)==0){
 		    	printf("Case #%d: GABRIEL\n",i);
 		    }else{
 		    	printf("Case #%d: RICHARD\n",i);
 		    }
 	    }
 	    else if(X==4){
 		    if(min(R,C)>=3 && max(R,C)>=4 && (R*C%X)==0){
 		    	printf("Case #%d: GABRIEL\n",i);
 		    }else{
 		    	printf("Case #%d: RICHARD\n",i);
 		    }
 	    }
     }	
 }
 
 int min(int a,int b){
 	if(a<=b){
 		return a;
 	}else{
 		return b;
 	}
 }
 
 int max(int a,int b){
 	if(a>=b){
 		return a;
 	}else{
 		return b;
 	}
 }

