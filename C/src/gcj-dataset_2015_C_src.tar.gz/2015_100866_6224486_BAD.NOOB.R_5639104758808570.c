#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
     FILE *f=fopen("A-small-attempt3.in","r");
     FILE *g=fopen("A-small-attempt3.out","w");
     int t,s,i,j,p=0,n=0;
     char sh[100];
     fscanf(f,"%d\n",&t);
     n=t;
     while(t--)
     {
     n=0;p=0;
     fscanf(f,"%d %s\n",&s,sh);
     p=sh[0]-'0';
     for(i=1;i<=s;i++)
     {
         if(sh[i]-'0'>0)
         if(i>p)
         {
         n+=i-p;
         p+=i-p;
         }
 
         p+=sh[i]-'0';
     }
     fprintf(g,"Case #%d: %d\n",100-t,n);
     }
 }

