#include <stdio.h>
 #include <stdlib.h>
 #define MIN 0
 #define MAX 1
 
 int getMinMaxIndexFrom(int *array, int ub, int what) {
 	int i, subject=array[0], subjectIndex=0;
 	for(i=1 ; i<ub ; i++) {
 		if((what==MIN && array[i]<subject) || (what==MAX && array[i]>subject)) {
 			subject = array[i];
 			subjectIndex = i;
 		}
 	}
 	return subjectIndex;
 }
 
 int getMinimumTimeFor(int *p, int d, int divisionsAllowed) {
 	int *array, i, largestIndex, time=0;
 	array = (int*) malloc(sizeof(int)*d);
 	for(i=0 ; i<d ; i++) {
 		array[i] = p[i];
 	}
 	while(divisionsAllowed--) {
 		largestIndex = getMinMaxIndexFrom(array, d, MAX);
 		d++;
 		array = realloc(array, sizeof(int)*d);
 		array[d-1] = array[largestIndex] - (array[largestIndex]/2);
 		array[largestIndex] /= 2;
 		time++;
 	}
 	time += array[getMinMaxIndexFrom(array, d, MAX)];
 	free(array);
 	return time;
 }
 
 int getMinimumTime(int *p, int d) {
 	int *result, top=-1, divisionsAllowed=-1, maxTime=getMinMaxIndexFrom(p, d, MAX), minTime;
 	result = (int*) malloc(sizeof(int)*(p[maxTime]+1));
 	while(divisionsAllowed++ < p[maxTime]) {
 		result[++top] = getMinimumTimeFor(p, d, divisionsAllowed);
 	}
 	minTime = result[getMinMaxIndexFrom(result, top+1, MIN)];
 	free(result);
 	return minTime;
 }
 
 int main(void) {
 	int t=0, T, d, *p, i;
 	scanf("%d", &T);
 	while(t++ < T) {
 		scanf("%d", &d);
 		p = (int*) malloc(sizeof(int)*d);
 		for(i=0 ; i<d ; i++) {
 			scanf("%d", &p[i]);
 		}
 		printf("Case #%d: %d\n", t, getMinimumTime(p, d));
 		free(p);
 	}
 	return 0;
 }

