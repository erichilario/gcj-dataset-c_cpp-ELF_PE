#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int helper(const int arr[], int S);
 
 int main(void) {
 
     FILE *fin = fopen("in.txt", "r");
     FILE *fout = fopen("out.txt", "w");
 
     int i, T;
 
     fscanf(fin, " %d", &T);
 
     for (i = 0; i < T; i++) {
         char ch;
         int j, S, arr[7];
 
         fscanf(fin, " %d", &S);
         for (j = 0; j <= S; j++) {
             fscanf(fin, " %c", &ch);
             arr[j] = ch - '0';
         }
 
         fprintf(fout, "Case #%d: %d\n", i + 1, helper(arr, S));
     }
     fclose(fin);
     fclose(fout);
 
     return 0;
 }
 
 int helper(const int arr[], int S) {
     int i, sum = 0, additional = 0;
 
     for (i = 0; i <= S; i++) {
         if (arr[i] > 0 && sum < i) {
             additional += i - sum;
             sum = i;
         }
         sum += arr[i];
     }
     return additional;
 }

