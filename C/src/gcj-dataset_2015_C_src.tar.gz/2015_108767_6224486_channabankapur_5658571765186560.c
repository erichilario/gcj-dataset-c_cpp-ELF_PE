#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     int t, tcount = 1;
 	int x, r, c, flag;
     scanf("%d", &t);
     while(t--)
     {
         scanf("%d", &x);
         scanf("%d", &r);
         scanf("%d", &c);
 		flag = 0;
         switch(x)
         {
 			case 1: 
 				flag = 1;
 				break;         
 
 			case 2:
 				if((r==2) || (c==2) || (r==4) || (c==4)) 
 					flag = 1;
 				break;         
 
 			case 3: 
 				if( ((r==3) && (c!=1)) ||
 					((r!=1) && (c==3)) )
 						flag = 1;
 				break;         
 
 			case 4: 
 				if( ((r==3) && (c==4)) ||
 					((r==4) && (c==4)) ||
 					((r==4) && (c==3)) )
 						flag = 1;
 				break;
 			
 			default: printf("ERR\n"); break;
         }
         printf("Case #%d: %s\n", tcount++, flag ? "GABRIEL" : "RICHARD");
     }
     return 0;
 }

