#include<stdio.h>
 #define MAX 1000
 int main(int argc,char **argv)
 {
 	long int i,j,T,n,count1=0,sum1=0,x,y,z,minus=0,result=0;
 	char s[MAX];
 	scanf("%ld",&T);
 	for(i=1;i<=T;i++)
 	{	
 		sum1=0;
 		scanf("%ld",&n);
 		scanf("%s",s);
 		for(j=0;j<n+1;j++)
 		{
 			minus+=s[j]-48;
 		}
 		for(j=0;s[j]!='\0';j++)
 		{
 			if(j==0 && s[j]=='0')
 			{
 				count1=j-sum1;
 				sum1+=(s[j]-48)+count1;
 				continue;
 			}
 			if(s[j]!='0' && j>=sum1)
 			{
 				count1=j-sum1;
 				sum1+=(s[j]-48)+count1;
 			}
 			else
 			{
 				sum1+=s[j]-48;
 			}
 		}
 		result=sum1-minus;
 		printf("Case #%ld: %ld\n",i,result);
 		count1=0;
 		minus=0;
 	}
 	return 0;
 }

