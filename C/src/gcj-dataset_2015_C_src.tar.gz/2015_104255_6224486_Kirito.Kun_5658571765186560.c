#include <stdio.h>
 #include <stdlib.h>
 #include <conio.h>
 
 int main()
 {
     FILE* Input = NULL;
     FILE* Output = NULL;
     Input = fopen("Input.txt","r");
     Output = fopen("Output.txt","w");
     int T,X,R,C;
     int i;
     fscanf(Input,"%d",&T);
     for(i=0;i<T;i++)
     {
         fscanf(Input,"%d",&X);
         fscanf(Input,"%d",&R);
         fscanf(Input,"%d",&C);
         /*
         Every case is verified. X>7 for holes. the other conditions are mathematicly verified, they englobe every case.
         */
         if(X>6 || R*C%X != 0 || (R<X && C<X))
         {
             fprintf(Output,"Case #%d: RICHARD\n",i+1);
         }
         else if(X == 3 && (R<2 || C<2))
         {
             fprintf(Output,"Case #%d: RICHARD\n",i+1);
         }
         else if(X == 4 && (R<3 || C<3))
         {
             fprintf(Output,"Case #%d: RICHARD\n",i+1);
         }
         else if((X == 5 && (R<4 || C<4)))
         {
             fprintf(Output,"Case #%d: RICHARD\n",i+1);
         }
         else if((X == 6 && (R<4 || C<4)))
         {
             fprintf(Output,"Case #%d: RICHARD\n",i+1);
         }
         else
         {
             fprintf(Output,"Case #%d: GABRIEL\n",i+1);
         }
     }
     printf("\nDone !");
     getch();
     return 0;
 }

