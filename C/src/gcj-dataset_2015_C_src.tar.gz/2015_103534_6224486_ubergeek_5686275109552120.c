#include <vector>
 #include <queue>
 #include <climits>
 #include <list>
 #include <map>
 #include <set>
 #include <deque>
 #include <stack>
 #include <bitset>
 #include <algorithm>
 #include <functional>
 #include <numeric>
 #include <utility>
 #include <sstream>
 #include <iostream>
 #include <iomanip>
 #include <cstdio>
 #include <cmath>
 #include <cstdlib>
 #include <ctime>
 #include <cstring>
  
 using namespace std;
 
 #define FOR(i,a,b) for(int i=a;i<b;++i)
 #define REP(i,n) FOR(i,0,n)
 #define RREP(i,n) for(int i=n-1;i>=0;--i)
 #define EACH(it,v) for(typeof(v.begin()) it=v.begin();it!=v.end();++it)
 #define pb push_back
 #define all(x) (x).begin(),(x).end()
 #define CLEAR(x,with) memset(x,with,sizeof(x))
 #define sz size()
 #define mkp make_pair
 typedef long long LL;
 typedef vector <int> VI;
 typedef vector <VI> VVI;
 typedef pair <int, int> PI;
 typedef vector <PI> VPI;
 
 int go(VI cur, int costsofar)
 {
 	int ans = INT_MAX;
 
 	//cout << "Printing current state : \n";
 	//REP(i, cur.sz)
 	//cout << cur[i] << " ";
 	//cout << "\n";
 
 	bool alldone = true;
 	REP(i, cur.sz) alldone = (alldone && (cur[i] == 1));
 
 	if(alldone)
 	return costsofar + 1;
 
 	if(cur.sz == 0)
 	return costsofar;
 
 	sort(all(cur));
 	VI send1;
 	REP(i, cur.sz)
 	if(cur[i] > 0) send1.pb(cur[i] - 1);
 
 	if(cur[cur.sz-1] == 1)
 	return costsofar + 1;
 
 	VI send2;
 
 	int maxelem = cur[cur.sz-1];
 
 	int last = (cur[cur.sz-1] & 1) ? (cur[cur.sz-1] >> 1) + 1 : (cur[cur.sz-1] >> 1);
 	cur[cur.sz-1] >>= 1;
 	send2 = cur; send2.pb(last); sort(all(send2));
 
 	ans = min(go(send2, costsofar+1), go(send1, costsofar+1));
 	
 	if(maxelem == 9)
 	{
 		VI send3;
 		send3 = send2;
 		send3[send3.sz-1]++;
 		send3[send3.sz-2]--;
 		ans = min(go(send3, costsofar+1), ans);
 	}
 
 	ans = min(ans, go(send1, costsofar+1));
 
 	return ans;
 }
 
 int main()
 {
 	int T; cin >> T;
 	FOR(kase, 1, T+1)
 	{
 		int D; cin >> D;
 		VI P(D);
 		REP(i, D) cin >> P[i];
 
 		cout << "Case #" << kase << ": ";
 		cout << go(P, 0) << "\n";;
 	}
 
 	return 0;
 }

