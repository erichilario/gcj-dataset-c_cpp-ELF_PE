#include <stdio.h>
 int main(void) 
 {
       int a,x;
       scanf("%d",&a);
       for(x=1;x<=a;x++)
       {
       	int b,c,d,e=0,f=0,m=0;
       	scanf("%d",&b);
       char num[b+1];
       		scanf("%s",num);
         for(d=0;d<b+1;d++)
         {   e+=num[d]-48;
         	if(e<=d)
         	{
         		f=e-d+1;
         		e+=f;
         		m+=f;
              }
              }
              printf("Case #%d: %d\n",x,m);
       }
 	return 0;
 }

