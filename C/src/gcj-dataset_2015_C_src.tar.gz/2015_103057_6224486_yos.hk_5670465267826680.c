#include <stdio.h>
 #include <math.h>
 #include <stdlib.h>
 
 int a[11000];
 int re[110000][11000];
 int map[10][10];
 
 int get_char(int L, int X, int n)
 {
 	int i;
 	i = n % L;
 	return a[i];
 }
 	
 
 int main()
 {
 	int i,j,k,m,n,r,s;
 	int X,L,T,t;
 	int head, tail, first, last, mid, win;
 	char out[2][10] = {"NO", "YES"};
 	char str[11000];
 	int max;
 	
 	
 	map[1][1] = 1; 	map[1][2] = 2;  map[1][3] = 3;  map[1][5] = 5;
 	map[2][1] = 2; 	map[2][2] = -1; map[2][3] = 5;  map[2][5] = -3;
 	map[3][1] = 3; 	map[3][2] = -5; map[3][3] = -1; map[3][5] = 2;
 	map[5][1] = 5; 	map[5][2] = 3;  map[5][3] = -2; map[5][5] = -1;
 	
 	fscanf(stdin, "%d", &T);
 	for(t=1;t<=T;t++)
 	{  
 		fscanf(stdin, "%d%d", &L, &X);
 		fscanf(stdin, "%s", str);
 		for(i=0;i<L;i++)
 		{
 			if(str[i]=='i') a[i]=2;
 			if(str[i]=='j') a[i]=3;
 			if(str[i]=='k') a[i]=5;
 		}
 		
 		max=X*L;
 		
 		
 		for(j=0;j<max;j++)
 		{
 			first=1;
 			for(i=j;i<max;i++)
 			{
 				if(first<0) s=-1; else s=1;
 				r = map[abs(first)][get_char(L,X,i)];
 				first = r*s;
 				re[j][i]=first;
 			}
 		}
 		
 		win=0;
 		for(i=0;i<max-2;i++)
 		{
 			for(k=max-1;k>i+1;k--)
 			{
 				if(re[0][i]==2 && re[i+1][k-1]==3 && re[k][max-1]==5) win=1;
 				if(win) break;
 			}
 			if(win) break;
 		}
 		
 		//printf("Case #%d: (%d %d %d) %s\n", t, i,j,k,out[win]);
 		printf("Case #%d: %s\n", t, out[win]);
 		
 	}
 
 
 }
