#include <stdio.h>
 #define SHYNESS_MAX 6
 
 int process(int max_shyness, int shyness_level) {
 	
 //	int max_shyness;
 //	int shyness_level;
 
 //	printf("please input");
 
 //	scanf("%d", &max_shyness);
 //	scanf("%d", &shyness_level);
 
 	int i, j;
 	int shyness[SHYNESS_MAX+1];
 
 	for (i = max_shyness; i >= 0; i--) {
 		shyness[i] = shyness_level % 10;
 		shyness_level /= 10;
 	}
 	
 //	printf("input finished\n");
 	
 	int stand_people = shyness[0];
 	int now_level = 0;
 	int invite_people = 0;
 	
 	while (1) {
 //		printf("%d %d %d\n", now_level, stand_people, invite_people);
 	
 		if (stand_people > now_level) {
 //			now_level++;
 //			for(; now_level <= stand_people; now_level++) {
 //				stand_people += shyness[now_level];
 //			}
 			while (now_level < stand_people) {
 				now_level++;
 				stand_people += shyness[now_level];
 			}
 		}
 		
 		if (now_level >= max_shyness) {
 			break;
 		} else {
 			for (j = now_level; shyness[j] == 0; j++) {
 				
 			}
 			int now_invite;
 			now_invite = j - stand_people;
 			invite_people += now_invite;
 			stand_people += now_invite;
 		}
 	}
 
 //	printf("%d\n", invite_people);
 	return invite_people;
 }
 
 
 int main(int argc, const char * argv[]) {
 	int T;
 	scanf("%d", &T);
 	
 	int i;
 	int max_shyness;
 	int shyness_level;
 	for (i = 1; i <= T; i++) {
 		scanf("%d %d", &max_shyness, &shyness_level);
 		printf("Case #%d: %d\n", i, process(max_shyness, shyness_level));
 	}
 
     return 0;
 }

