#include <stdio.h>
 int main()
 {
 	int a,b,c,d,e,g,n,f,i,j,k;
 	char p[10001];
 	int test;
 	scanf("%d",&test);
 	int tc;
 	for(tc=1;tc<=test;tc++)
 	{
 		scanf("%d",&n);
 		f=getchar();
 		for(i=0;i<=n;i++)
 		{
 			scanf("%c",&p[i]);
 		}
 		f=getchar();
 		a=0;
 		b=0;
 		c=0;
 		for(i=0;i<=n;i++)
 		{
 			d=p[i]-'0';
 			if(a<i && p[i]!='0')
 			{
 				c=b;
 				b+=(i-a);
 				a+=(b-c);
 			}
 			a+=d;
 		}
 		printf("Case #%d: %d\n",tc,b);
 	}
 	return 0;
 }				

