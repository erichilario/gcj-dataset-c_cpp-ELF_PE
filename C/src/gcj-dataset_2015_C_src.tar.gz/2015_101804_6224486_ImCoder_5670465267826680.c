#include<stdio.h>
 int main()
 {
     long long int test,l,j,k,c,sign;
     long long int x,i;
     char s[10001],ch;
     #ifndef ONLINE_JUDGE
     freopen("input.txt","r",stdin);
     freopen("output.txt","w",stdout);
     #endif
     scanf("%lld",&test);
     for(j=0;j<test;j++)
     {
         c=0;
         ch='1';
         sign=1;
         scanf("%lld%lld",&l,&x);
         scanf("%s",s);
         for(i=0;i<x;i++)
         {
             for(k=0;k<l;k++)
             {
                 if(ch=='1')
                 {
                     if((s[k]=='i' && c==0) || (s[k]=='j' && c==1) || (s[k]=='k' && c==2))
                         c++;
                     else
                         ch=s[k];
                 }
                 else if(ch=='i' && s[k]=='j')
                 {
                     if(c==2)
                     {
                         c++;
                         ch='1';
                     }
                     else
                         ch='k';
                 }
                 else if(ch=='j' && s[k]=='k')
                 {
                     if(c==0)
                     {
                         c++;
                         ch='1';
                     }
                     else
                         ch='i';
                 }
                 else if(ch=='k' && s[k]=='i')
                 {
                     if(c==1)
                     {
                         c++;
                         ch='1';
                     }
                     else
                         ch='j';
                 }
                 else if(ch=='i' && s[k]=='k')
                 {
                     if(c==1)
                     {
                         c++;
                         ch='1';
                     }
                     else
                         ch='j';
                     sign=sign*-1;
                 }
                 else if(ch=='j' && s[k]=='i')
                 {
                     if(c==2)
                     {
                         c++;
                         ch='1';
                     }
                     else
                         ch='k';
                     sign=sign*-1;
                 }
                 else if(ch=='k' && s[k]=='j')
                 {
                     if(c==0)
                     {
                         c++;
                         ch='1';
                     }
                     else
                         ch='i';
                     sign=sign*-1;
                 }
                 else
                 {
                     ch='1';
                     sign=sign*-1;
                 }
             }
         }
         if(c==3 && ch=='1' && sign==1)
             printf("Case #%d: YES\n",j+1);
         else
             printf("Case #%d: NO\n",j+1);
     }
     return 0;
 }

