#include <stdio.h>
 
 int main(void) {
 int	t,l=1;
 scanf("%d",&t);
 while(t--)
 {
 	int i;
 	char u[100];
     int s[100];
     int j,k=0,tcount=0;
 	scanf("%d",&i);
 	gets(u);
 	for(j=0;j<=i;j++)
 	s[j]=u[j+1]-48;
 		for(j=1;j<=i;j++)
 	{
 		int sum=0,count=0;
 		for(k=0;k<j;k++)
 		{
 			sum=sum+s[k];
 		}
 				if(sum<j)
 		{
 			count=j-sum;
 			s[j-1]=s[j-1]+count;
 		}
 		tcount=tcount+count;
 	}
 	printf("Case #%d: %d\n",l,tcount);
 	l++;
 }
 	return 0;
 }

