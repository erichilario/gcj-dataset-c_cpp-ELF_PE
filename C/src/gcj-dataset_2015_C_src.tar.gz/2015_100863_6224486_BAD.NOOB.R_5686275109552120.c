#include<stdio.h>
 #include<stdlib.h>
 int maxi(int *t,int d)
 {
     int i,max=t[0];
     for(i=1;i<d;i++)
     if(t[i]>max)
     max = t[i];
     return max;
 }
 int mini(int *t,int d)
 {
     int i,min=t[0];
     for(i=1;i<d;i++)
     if(t[i]<min)
     min = t[i];
     return min;
 }
 int main()
 {
     FILE *f=fopen("B-small-attempt10.in","r");
     FILE *g=fopen("B-small-attempt10.out","w");
     int t,s,i,j,n=0,left=0,max,max1,min1,min2,min,max2;
     int p[10],d;
     fscanf(f,"%d",&t);
     while(t--)
     {
        min=0;
        min1=0;min2=0;
        fscanf(f,"%d",&d);
        for(i=0;i<d;i++)
        fscanf(f,"%d",&p[i]);
        min1=maxi(p,d);
        max2=3;
        while(maxi(p,d)>3)
        {
        max=maxi(p,d);
        max1=(max%2==0)?max/2:(max+1)/2;
        if(max%2!=0)
        {
        for(i=0;i<d;i++)
        p[i]=p[i]-1>0?p[i]-1:0;
        min++;
        }
        else
        for(i=0;i<d;i++)
        if(p[i]==max)
        {
            p[i]=max/2;min2++;
            break;
        }
        min1=(min1<(min2+maxi(p,d)))?min1:min2+maxi(p,d);
        }
        min+=(min2+maxi(p,d))<min1?min2+maxi(p,d):min1;
        fprintf(g,"Case #%d: %d\n",100-t,min);
     }
 
 }

