#include <stdio.h>
 
 int main(void) {
 	// your code goes here
 	freopen("gcjbin2.in","r",stdin);
 	freopen("outputgcjb.txt","w",stdout);
 	int t,d,p[1005],i,j,max,tmp1,tmp2,tmp,x,hash[10],ans;
 	scanf("%d",&t);
 	for(i=1;i<=t;i++)
 	{
 		for(j=0;j<10;j++)
 		hash[j]=0;
 		scanf("%d",&d);
 		for(j=0;j<d;j++)
 		scanf("%d",&p[j]);
 		for(j=0;j<d;j++)
 		hash[p[j]]++;
 		tmp=0;
 		for(j=3;j<=9;j++)
 		{
 			if(j==4)
 			continue;
 			else
 			tmp+=hash[j];
 		}
 		x=0;
 		for(j=0;j<d;j++)
 		{
 			if(p[j]>x)
 			x=p[j];
 		}
 		if(x==1)
 		printf("Case #%d: 1\n",i);
 		else if(x==2)
 		printf("Case #%d: 2\n",i);
 		else if(x==3)
 		printf("Case #%d: 3\n",i);
 		else if(x==4&&hash[3]==0)
 		{
 			ans=hash[4]+2;
 			if(ans<4)
 			printf("Case #%d: %d\n",i,ans);
 			else
             printf("Case #%d: 4\n",i);
 		}
 		else
 		{
 
 			max=0;
 			for(j=0;j<d;j++)
 			{
 				tmp1=p[j]/3;
 				tmp2=p[j]%3;
 				if(tmp2==0)
 				max+=tmp1-1;
 				else
 				max+=tmp1;
 			}
 			max+=3;
 			if(max<x)
 			printf("Case #%d: %d\n",i,max);
 			else
             printf("Case #%d: %d\n",i,x);
 		}
 	}
 	return 0;
 }

