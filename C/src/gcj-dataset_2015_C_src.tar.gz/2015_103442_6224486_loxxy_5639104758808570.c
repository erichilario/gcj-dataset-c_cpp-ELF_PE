#include<stdio.h>
 
 int main() {
    char str[1024];
    int n, m, i, j;
    
    char p;
    int d, req, clap;
 
    scanf("%d", &n);
 
    for(i=0; i<n; i++) {
       req = 0;
       scanf("%d %s", &m, str);
       clap = p = str[0] - '0';
       for(j=1; j<=m; j++) {       
         p = str[j] - '0';
         d = j - clap;
 	if(p>0 && d>0) { 
 	    req+=d; 
 	    clap+=d; 
 	}    
         clap+=p;
         //printf("%d", p);
       }
       //printf("\t");
       printf("Case #%d: %d \n",i+1,req);
    }
    return 0;
 }

