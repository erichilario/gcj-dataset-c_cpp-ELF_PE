#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 
 main(){
     FILE *fptr=fopen("A-large.in","r");
     FILE *f_out=fopen("output_small.txt","w");
     if (fptr==NULL){
        printf("Error! opening file");
        exit(1);         /* Program exits if file pointer returns NULL. */
    }
    char line [1000];
    int test,i=0,s_max;
    char input[1002];
 
   // fgets(line,sizeof(line),fptr);
    fscanf(fptr,"%d",&test);
    //printf("%d\n",test);
 
     while(i<test) /* read a line from a file */ {
         fscanf(fptr,"%d %s",&s_max,input);
         //printf("%d\t%s\n",s_max,input);
 
         int no_st=0;
         int index,extra=0;
         for(index=0;index<=s_max;index++){
             //printf("%d\n%c\n",input[index]);
             if(input[index]>48){
                 if(no_st>=index){
                     no_st+=(input[index]-48);
                 //printf("%d\n",no_st);
                 //printf("%c\n",input[index]-'0');
                 }
                 else{
                     extra+=(index-no_st);
                     //printf("%d\n",extra);
                     no_st+=((input[index]-48)+extra);
                 }
             }
         }
          fprintf(f_out,"Case #%d: %d\n",i+1,extra);
         i++;
         //fprintf(stdout,"%s",line); //print the file contents on stdout.
     }
    fclose(fptr);
    fclose(f_out);
 }

