#include <stdio.h>
 #include <stdlib.h>
 
 #define MAX_SIZE (1010)
 
 char buffer[MAX_SIZE] = {0};
 
 int countGuests(int Smax, int* S)
 {
     int count = 0;
     int total = 0;
     int diff;
 
     int i;
 
     for(i = 0; i <=Smax; i++)
     {
         diff = i - total;
         total += S[i];
         if( diff > 0){
         count += diff;
         total += diff;
         }
     }
 
     return count;
 }
 
 void readCase(int *Smax, int **S)
 {
     int i=0;
     int c=0;
     fgets(buffer, 1010, stdin);
 
     *Smax = atoi(buffer);
     *S = malloc((*Smax+1) * sizeof(int));
 
     while(buffer[c++] != ' ');
 
     while(buffer[c+i] != '\n' && buffer[c+i] != '\0')
     {
         (*S)[i] = (int)buffer[c+i] - (int)'0';
         i++;
     }
 }
 
 int main(int argc, char *argv[])
 {
     int T=0;
     int i=0;
     int Smax;
     int *S;
     int Count;
 
     scanf("%d ", &T);
 
     for(; i < T; i++)
     {
         if( i > 0) printf("\n");
         readCase(&Smax, &S);
         Count = countGuests(Smax, S);
         printf("Case #%d: %d", i+1, Count);
         free(S);
     }
     return 0;
 }

