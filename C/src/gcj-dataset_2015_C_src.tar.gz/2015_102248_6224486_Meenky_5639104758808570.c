#include <errno.h>
 #include <stdio.h>
 #include <stdint.h>
 #include <stdlib.h>
 
 
 int main(int argc, char **argv) {
   char buffer[BUFSIZ];
   uint32_t records, i;
   FILE *src = stdin, *dst = stdout;
 
   if(argc >= 2) {
     src = fopen(argv[1], "rb");
   }
 
   if(argc >= 3) {
     dst = fopen(argv[2], "wb");
   }
 
   if(!fgets(&buffer[0], sizeof(buffer), src)) {
     return 1;
   }
 
   if(sscanf(&buffer[0], "%u", &records) != 1) {
      return 2;
   }
 
   for(i = 0; i < records; i++) {
     char *ptr = &buffer[0], *end;
     uint32_t max, j, count, current, invite;
 
     if(!fgets(ptr, sizeof(buffer), src)) {
       return 3;
     }
 
     max = strtoul(ptr, &end, 10);
     if(*end != ' ') {
        return 4;
     }
 
     ptr = end;
     for(invite = current = j = 0; j <= max; j++) {
       count = *++ptr - '0';
       if(current < j) {
         invite += j - current;
         current = j;
       }
       current += count;
     }
 
     fprintf(dst, "Case #%u: %u\n", i + 1, invite);
   }
 }
 

