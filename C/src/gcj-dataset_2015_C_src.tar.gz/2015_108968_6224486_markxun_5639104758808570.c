#include "stdio.h"
 int main(){
 	int Smax,T;
 	char ch;
 	freopen("a1.in","r",stdin);
 	freopen("a1.out","w",stdout);
 	scanf("%d",&T);
 	for(int i=1;i<=T;i++){
 		scanf("%d",&Smax);
 		int Sum = 0;
 		int Ans = 0;
 		scanf("%c",&ch);
 		for(int k=0;k<=Smax;k++){
 			scanf("%c",&ch);
 			int Level = ch - '0';
 			if(k > Sum){
 				Ans += k-Sum;
 				Sum = k;
 			}
 			Sum = Sum + Level;
 		}
 		printf("Case #%d: %d\n",i,Ans);
 	}
 	fclose(stdin);
 	fclose(stdout);
 }
