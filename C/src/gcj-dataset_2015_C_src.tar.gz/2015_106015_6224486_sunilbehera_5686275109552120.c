#include<stdio.h>
 #include<stdlib.h>
 int max_array(int a[], int num_elements)
 {
    int i,max=0;
    for (i=0; i<num_elements; i++)
    {
 	 if (a[i]>max)
 	 {
 	    max=a[i];
 	 }
    }
    return(max);
 }
 int ceil(int n)
 {
     if(n%2==0)
         return n/2;
     else
         return (n+1)/2;
 }
 void main()
 {
     FILE * infile;
     FILE * outfile;
     int p=0,t=0,i=0,j=0,m=0,tm=0,z=0,flag=0,x=0,k=0,counter=0;
     infile=fopen("in.in","r");
     outfile=fopen("out.out","w");
     fscanf(infile,"%d",&t);
     for(i=0;i<t;i++)
     {
         flag=0;
         m=0;
         counter=0;
         fscanf(infile,"%d",&p);
         int* pl=(int*)malloc(sizeof(int)*1000);
         for(j=0;j<1000;j++)
             pl[j]==0;
         for(j=0;j<p;j++)
         {
             fscanf(infile,"%d",&pl[j]);
         }
         m=max_array(pl,p);
         for(z=0;z<p;z++)
         {
             if(pl[z] == m)
             {
                 flag=flag+1;
             }
         }
         tm=m;
         while(flag * (ceil(m)+1) < m)
         {
             for(x=0;x<p;x++)
             {
                 if(pl[x]==m)
                     {
                         pl[x]=0;
                     }
             }
             if(m%2==0)
             {
                 counter=1;
                 for(k=0;k<flag;k++)
                 {
                     pl[p++]=m/2;
                     pl[p++]=m/2;
                 }
             }
             else
             {
                 for(k=0;k<flag;k++)
                 {
                     pl[p++]=(m+1)/2;
                     pl[p++]=(m-1)/2;
                 }
             }
             m=max_array(pl,p);
             for(z=0;z<p;z++)
             {
                 if(pl[z]==m)
                 flag++;
             }
             if(m<tm)
                 tm=m;
             if(counter==1)
                 tm++;
         }
         fprintf(outfile,"Case #%d: %d\n",i+1,tm);
         for(x=0;x<p;x++)
         {
            //fprintf(outfile,"%d\t",pl[x]);
         }
         //fprintf(outfile,"\n %d\t%d \n",m,flag);
     }
 }

