#include <stdio.h>
 #include <errno.h>
 
 int chartoint(char c) {
     int r;
     
     switch(c){
         case '0':
             r = 0;
             break;
         case '1':
             r = 1;
             break;
         case '2':
             r = 2;
             break;
         case '3':
             r = 3;
             break;
         case '4':
             r = 4;
             break;
         case '5':
             r = 5;
             break;
         case '6':
             r = 6;
             break;
         case '7':
             r = 7;
             break;
         case '8':
             r = 8;
             break;
         case '9':
             r = 9;
             break;
     }
 
     return r;
 }
 
 int main()
 {
     int numberOfTestCases = 0;
     errno = 0; 
     FILE *ifp = fopen("A-large.in", "r");
     FILE *ofp = fopen("A-large.out", "w");
     int n = fscanf(ifp, "%d", &numberOfTestCases);
 
     if (n == 1) {
         if (numberOfTestCases >= 1 && numberOfTestCases <= 100){
             for (int caseNumber = 1; caseNumber <= numberOfTestCases; caseNumber++) {
                 int sMax = 0;
                 char *string;
                 n = fscanf(ifp, "%d%s", &sMax, string);
                 
                 if (n == 1 || n == 2) {
                     if (sMax >= 0 && sMax <= 1000){
                         int numberOfPeople = 0;
                         int totalNumberOfPeople = 0;
                         int peopleNeeded = 0;
                         
                         for (int i = 0; i <= sMax; i++){  
                             numberOfPeople = chartoint(string[i]); 
                             if (i > totalNumberOfPeople && numberOfPeople != 0){
                                 peopleNeeded += i - totalNumberOfPeople;
                                 totalNumberOfPeople += i - totalNumberOfPeople;
                             }
                             totalNumberOfPeople += numberOfPeople;
                         
                             //printf("shyness level: %d, numberOfPeople: %d, totalNumberOfPeople: %d, peopleNeeded, %d\n", i, numberOfPeople, totalNumberOfPeople, peopleNeeded);
                         } 
 
                         printf("Case #%d: %d\n", caseNumber, peopleNeeded);
                         fprintf(ofp, "Case #%d: %d\n", caseNumber, peopleNeeded);
                     } else 
                         printf("sMax is too large or small\n");
                 } else if (errno != 0) {
                     perror("scanf");
                 } else {
                     fprintf(stderr, "Error entering max and string\n");
                 }
             }
         }
         else {
             printf("Test cases too small or large\n");
         }
     } else if (errno != 0) {
         perror("scanf");
     } else {
         fprintf(stderr, "Error entering number of test cases\n");
     }
     
     fclose(ofp);
     fclose(ifp);
 
     return 0;
 }

