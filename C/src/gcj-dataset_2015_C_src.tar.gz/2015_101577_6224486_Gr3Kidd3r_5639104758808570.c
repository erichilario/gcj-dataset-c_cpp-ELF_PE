#include <stdio.h>
 #include <string.h>
 main()
 {
 	FILE *in = fopen("input.in", "r"), *o = fopen("A-small-attempt0.txt", "w");
 	int t, d, i = 1;
 	char s[10001] = {0};
 	fscanf(in, "%d", &t);
 	while(t--)
 	{
 		fscanf(in, "%d %s", &d, s);
 		printf("%d %s\n", d, s);
 		int res = 0, j = 1, counter = s[0] - '0';
 		while(j <= d)
 		{
 			if(j > counter && s[j] > '0')
 			{
 				res += j - counter;
 				counter += j - counter;
 			}
 			counter += s[j] - '0';
 			++j;
 		}
 		fprintf(o, "Case #%d: %d\n", i++, res);
 		printf("Case #%d: %d\n", i - 1, res);
 	}
 	return 0;
 }
