#include <stdio.h>
 
 unsigned Sm;
 char Si[1000+2];
 
 //#define TST_DEBUG
 
 #ifdef TST_DEBUG
 #define dprintf(...) printf(__VA_ARGS__)
 #else
 #define dprintf(...) ((void)0)
 #endif
 
 int main(void) {
   unsigned casen=1,t,i,m, N;
     int rc;
  
     // get case num
     scanf("%u\n",&t);
  
     while(t--) {    
         printf("Case #%u: ", casen++);
         
         rc = scanf("%u %s\n",&Sm, Si);
         if ((rc == 0) || (rc == EOF)) {
           printf("scanf failed\n");
           return 1;
         }
 
         dprintf("Sm=%u Si=%s\n", Sm, Si);
         
         m = 0;
         N = (Si[0] - '0');
         
         for(i=1; i<=Sm; i++) {
           unsigned Sic = (Si[i] - '0');
           dprintf("Sic=%d ", Sic);
           if (i > N) {
             m += i-N;
             N += i-N;
           }
           N += Sic;
         }
 
         dprintf("N=%u\n", N);
 
         printf("%u\n", m);
     }
     return 0;
 }

