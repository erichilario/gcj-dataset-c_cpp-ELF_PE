#include<stdio.h>
 #include<malloc.h>
 int decide(int *data,int d)
 {
 	int i,*data2,max=0,flag=0,mins=1,ming=1;
 	data2=(int *)malloc(sizeof(int)*d);
 	for(i=0;i<d;i++)
 	{
 		data2[i]=(data[i]>0)?data[i]-1:data[i];
 		flag=(data2[i]>0)?1:flag;
 	}
 	if(!flag) 
 	{
 		free(data2);
 		return(ming);
 	}
 	ming+=decide(data2,d);
 	data2=(int *)realloc(data2,sizeof(int)*(d+1));
 	for(i=0;i<d;i++)
 	{
 		data2[i]=data[i];
 		max=(data2[max]<data2[i])?i:max;
 	}
 	data2[d]=data2[max]/2;
 	data2[max]-=data2[max]/2;
 	mins+=decide(data2,d+1);
 	free(data2);
 	return((ming<mins)?ming:mins);
 }
 
 main()
 {
 	int i,t,tcount=1,d,*data;
 	scanf("%d\n",&t);
 	while(tcount<=t)
 	{
 		scanf("%d\n",&d);
 		data=(int *)malloc(sizeof(int)*d);
 		for(i=0;i<d;i++)
 		{
 			scanf("%d",&data[i]);
 		}
 		printf("Case #%d: %d\n",tcount,decide(data,d));
 		free(data);
 		tcount++;
 	}
 	return(0);
 }

