#include<stdio.h>
 int main()
 {
 	int test,shy,i,j,count,sum,temp;
 	char s[1001];
 	scanf("%d",&test);
 	for(j=1;j<=test;j++)
 	{
 		scanf("%d",&shy);
 		scanf("%s",s);
 		sum=0;temp=0;count=0;
 		for(i=0;s[i]!='\0';i++)
 		{
 			if(i>sum&&s[i]!='0')
 			{
 				temp=i-sum;
 				sum+=temp;
 				count+=temp;
 			}
 			sum+=s[i]-48;
 		}
 		printf("Case #%d: %d\n",j,count);
 	}
 	return 0;
 }

