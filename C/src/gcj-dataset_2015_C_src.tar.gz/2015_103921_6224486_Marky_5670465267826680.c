#include<stdio.h>
 #include<string.h>
 
 unsigned char table[256][256];
 unsigned char q[8]={'1','i','j','k', 128|'1', 128|'i', 128|'j', 128|'k'};
 
 int Ans(char s[], int x, int len){
 	int i;
 	int stop = (x<4?x:4)*len;
 	unsigned char left, rite, mid;
 	if(x > 12) x = x%4 + 12;
 	for(i=0; i<x; i++){
 		memcpy(
 			s + (i+1)*len,
 			s + i*len,
 			len
 		);
 	}
 	s[x*len] = 0;
 	left = '1';
 	for(i=0; i < stop; i++){
 		int j;
 		left = table[left][s[i]];
 		if(left != 'i') continue;
 		mid = rite = '1';
 		for(j = i+1; s[j]; j++)
 			rite = table[rite][s[j]];
 		for(j = i+1; s[j] && j < i+1 + stop; j++){
 			int k;
 			for(k=0; k<8; k++)
 				if(table[s[j]][q[k]] == rite){
 					rite = q[k];
 					break;
 				}
 			mid = table[mid][s[j]];
 			if(mid != 'j') continue;
 			if(rite == 'k') return 1;
 		}
 	}
 	return 0;
 }
 int main(){
 	int t, i,j,a,b;
 
 	table['1']['1'] = '1';
 	table['1']['i'] = 'i';
 	table['1']['j'] = 'j';
 	table['1']['k'] = 'k';
 
 	table['i']['1'] = 'i';
 	table['j']['1'] = 'j';
 	table['k']['1'] = 'k';
 
 	table['i']['i'] = '1'|128;
 	table['j']['j'] = '1'|128;
 	table['k']['k'] = '1'|128;
 
 	table['i']['j'] = 'k';
 	table['i']['k'] = 'j'|128;
 	table['j']['k'] = 'i';
 
 	table['j']['i'] = 128^table['i']['j'];
 	table['k']['i'] = 128^table['i']['k'];;
 	table['k']['j'] = 128^table['j']['k'];
 
 	for(i=0; i <= 1; i++)
 		for(j=0; j <= 1; j++)
 			for(a=0; a<4; a++)
 				for(b=0; b<4; b++)
 					table[q[a]|(i*128)][q[b]|(j*128)] = ((j^i)*128)^table[q[a]][q[b]];
 
 	/*for(i=0; i<8; i++)
 		printf("\t%s%c", q[i] < 128 ? " " : "-", q[i]&127);
 	puts("");
 	for(i=0; i<8; i++){
 		printf("%s%c", q[i] < 128 ? " " : "-", q[i]&127);
 		for(j=0; j<8; j++)
 			printf("\t%s%c", table[q[i]][q[j]] < 128 ? " " : "-", table[q[i]][q[j]]&127);
 		puts("");
 	}*/
 
 	scanf("%i",&t);
 	for(i=1; i <= t; i++){
 		int L, X;
 		char s[10000*12];
 		scanf("%i%i%s",&L,&X,s);
 		printf("Case #%i: %s\n", i, Ans(s,X,L) ? "YES" : "NO");
 	}
 }
