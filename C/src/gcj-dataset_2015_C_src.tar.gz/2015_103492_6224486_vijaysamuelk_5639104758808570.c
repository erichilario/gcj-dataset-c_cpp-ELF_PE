/* Problem A. Standing Ovation */
 #include<stdio.h>
 #define MAX 1000
 int TC,shyest;
 char str[MAX];
 int main(int argc, char argv[])
 {
 	int i,j,count=0,sum=0,x,y,z,total=0,result=0;
 	scanf("%d",&TC);
 	for(i=1;i<=TC;i++)
 	{	
 		sum=0;
 		scanf("%d",&shyest);
 		scanf("%s",str);
 		for(j=0;j<shyest+1;j++)
 		{
 			total+=str[j]-48;
 		}
 		for(j=0;str[j]!='\0';j++)
 		{
 			if(j==0 && str[j]=='0')
 			{
 				count=j-sum;
 				sum+=(str[j]-48)+count;
 				continue;
 			}
 			if(str[j]!='0' && j>=sum)
 			{
 				count=j-sum;
 				sum+=(str[j]-48)+count;
 			}
 			else
 			{
 				sum+=str[j]-48;
 			}
 		}
 		result=sum-total;
 		printf("Case #%d: %d\n",i,result);
 		count=0;
 		total=0;
 	}
 	return 0;
 }

