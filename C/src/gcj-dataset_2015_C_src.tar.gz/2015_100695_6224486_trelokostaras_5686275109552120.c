#include<stdio.h>
 
 main(){
 	int cases;
 	scanf("%d",&cases);
 //j				printf("cases = %d\n",cases);
 	for(int cas=1;cas<=cases;cas++){
 		int diners;
 		scanf("%d",&diners);
 		int P[10000];
 		for(int diner=0;diner<diners;diner++){
 			scanf("%d",P+diner);
 		}
 //		printf("diners = %d\n",diners);
 //		for(int diner=0;diner<diners;diner++){
 //			printf("%d ",P[diner]);
 //		}
 //		printf("\n");
 		//scanf("\n");
 		for(int minutes=0;;minutes++){
 			int still = 0;
 			int cont = 0;
 			for(int diner=0;diner<diners;diner++){
 				if(P[diner] > 3){
 					P[diners] = P[diner]/2;
 					P[diner] = P[diner]-P[diners];
 					printf("%d,%d\n",P[diners],P[diner]);
 					diners++;
 					cont = 1;
 					break;
 				}
 			}
 			if(cont == 1){
 				continue;
 			}
 			else{
 				for(int diner=0;diner<diners;diner++){
 					if(P[diner]!=0){
 						P[diner]--;
 						still = 1;
 					}
 				}
 				if(still == 0){
 					printf("Case #%d: %d\n",cas,minutes);
 					break;
 				}
 			}
 		}
 	}
 }

