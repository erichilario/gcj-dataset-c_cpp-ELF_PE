#include <stdio.h>
 #include <stdlib.h>
 
 #define PATH        "test.txt"
 #define MAX_SIZE    1003
 
 
 int get_nb_friends(int smax, int si[])
 {
     int nbfriends = 0;
     int nbclaps = 0;
     int i = 0;
 
     while (i <= smax)
     {
         if (nbclaps >= i || si[i] == 0)
             nbclaps += si[i];
         else
         {
             nbfriends += 1;
             nbclaps += 1;
             continue;
         }
 
         i += 1;
     }
 
     return nbfriends;
 }
 
 void parse_file(void)
 {
     FILE *fin = fopen(PATH, "r");
     FILE *fout = fopen("output.txt", "w+");
 
     int nbcase = 0;
     int smax, *si;
     int i;
 
     char *buf = calloc(MAX_SIZE, sizeof(char));
 
     while (fscanf(fin, "%d %s\n", &smax, buf) != EOF)
     {
         nbcase += 1;
         i = 0;
         si = malloc(sizeof(int) * (smax + 1));
 
         for(; i < MAX_SIZE && buf[i] != '\0'; ++i)
             si[i] = buf[i] - '0';
 
         fprintf(fout, "Case #%d: %d\n", nbcase, get_nb_friends(smax, si));
         //fprintf(fout, "Smax = %d\n", smax);
 
         free(buf);
         free(si);
 
         buf = calloc(MAX_SIZE, sizeof(char));
     }
 
     fclose(fin);
     fclose(fout);
 }
 
 int main()
 {
     parse_file();
 
     return 0;
 }

