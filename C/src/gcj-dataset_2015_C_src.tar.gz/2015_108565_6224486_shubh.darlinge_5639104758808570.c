#include <stdio.h>
 #include <stdlib.h>
 
 int main(void) {
 	int t=0, T, sMax, required, stoodUp, i;
 	char *shyness;
 	scanf("%d", &T);
 	while(t++ < T) {
 		required = 0;
 		stoodUp = 0;
 		scanf("%d", &sMax);
 		shyness = (char*) malloc(sizeof(char)*(sMax+2));
 		scanf("%s", shyness);
 		for(i=0 ; shyness[i] ; i++) {
 			if(i > stoodUp) {
 				required += i-stoodUp;
 				stoodUp += i-stoodUp;
 			}
 			stoodUp += shyness[i]-'0';
 		}
 		printf("Case #%d: %d\n", t, required);
 		free(shyness);
 	}
 	return 0;
 }

