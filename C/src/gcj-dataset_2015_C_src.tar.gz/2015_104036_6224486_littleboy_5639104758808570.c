#include <stdio.h>
 
 int main() {
     int T;
     int shy[200];
 
     scanf("%d", &T);
     for (int Case = 1; Case <= T; Case++) {
         int max;
         scanf("%d", &max);
 
         for (int i = 0; i <= max; i++) {
             char ch;
             scanf(" %c", &ch);
             shy[i] = ch - '0';
         }
 
         int cumsum = 0;
         int invite = 0;
 
         for (int i = 0; i <= max; i++) {
             if (cumsum < i) {
                 int amtAdded = i - cumsum;
                 invite += amtAdded;
                 cumsum += amtAdded;
             }
 
             cumsum += shy[i];
         }
 
         printf("Case #%d: %d\n", Case, invite);
     }
     return 0;
 }

