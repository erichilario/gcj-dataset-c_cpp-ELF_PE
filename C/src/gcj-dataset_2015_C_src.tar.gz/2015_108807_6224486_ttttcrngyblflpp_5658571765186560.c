#include<stdio.h>
 int space;
 int main(void){
 	int jam;
 	int bam[3];
 	scanf("%d",&space);
 	for(jam=0;jam!=space;++jam){
 		scanf("%d %d %d",bam,bam+1,bam+2);
 		printf("Case #%d: ",jam+1);
 		switch(bam[0]){
 			case 1:
 				puts("GABRIEL");
 				break;
 			case 2:
 				if(bam[1]*bam[2]%2)puts("RICHARD");
 				else puts("GABRIEL");
 				break;
 			case 3:
 				if(bam[1]*bam[2]%3)puts("RICHARD");
 				else if(bam[1]==1||bam[2]==1)puts("RICHARD");
 				else puts("GABRIEL");
 				break;
 			case 4:
 				if(bam[1]*bam[2]%4)puts("RICHARD");
 				else if(bam[1]<=2||bam[2]<=2)puts("RICHARD");
 				else puts("GABRIEL");
 				break;
 		}
 	}
 	return 0;
 }

