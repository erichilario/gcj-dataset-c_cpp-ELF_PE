#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, const char * argv[]) {
 
     int test_cases=0;
     scanf("%d",&test_cases);
     int i,position,data,people_avail,requirement,data_current,j,*data_arr;
     int n,*output, *req;
     output = calloc(test_cases,sizeof(int));
     req =calloc(test_cases,sizeof(int));
     for(i=0;i<test_cases;i++){
         scanf("%d",&n);
         scanf("%d",&data);
         
         data_arr = calloc(n, sizeof(int));
         
 //        split data into array
         for(j=n;j>=0;j--){
             data_arr[j] = data%10;
             data = data/10;
         }
         
         people_avail = 0;
         requirement = 0;
         //add guy at position 0 by default
         people_avail = data_arr[0];
 
         //adding subsequent people
         for(position = 1;position<=n;position++){
             data_current =data_arr[position];
 
             if(data_current>0){
 
                 if((people_avail+requirement)>=position){
                     people_avail+=data_current;
 
                 }else{
                     requirement+=position-(people_avail+requirement);
                     people_avail+=data_current;
                 }
             }
         }
         req[i]=requirement;
         //printf("Case #%d: %d\n",i+1,requirement);
         //fflush(stdout);
     }
     
     for(i=0;i<=test_cases;i++){
         printf("Case #%d: %d\n",i+1,req[i]);
         fflush(stdout);
     }
     return 0;
 }

