#include <stdio.h>
 #include <string.h>
 main()
 {
 	FILE *in = fopen("D-small-attempt0.in", "r"), *o = fopen("D-small-attempt0.txt", "w");
 	int t, i = 1;
 	fscanf(in, "%d", &t);
 	while(t--)
 	{
 		int x, r, c;
 		fprintf(o, "Case #%d: ", i++);
 		fscanf(in, "%d %d %d", &x, &r, &c);
 		if(x == 1)
 			fprintf(o, "%s", "GABRIEL");
 		else if(x == 2)
 		{
 			if((r * c) % 2)
 				fprintf(o, "%s", "RICHARD");
 			else
 				fprintf(o, "%s", "GABRIEL");
 		}
 		else if(x == 3)
 		{
 			if(r + c <= 4 || r * c == 8 || r * c == 4 || r * c == 16)
 				fprintf(o, "%s", "RICHARD");
 			else if(r * c == 6 || r * c == 12 || r * c == 9)
 				fprintf(o, "%s", "GABRIEL");
 		}
 		else
 		{
 			if(r * c == 16 || r * c == 12)
 				fprintf(o, "%s", "GABRIEL");
 			else
 				fprintf(o, "%s", "RICHARD");
 		}
 		fprintf(o, "\n");
 	}
 	return 0;
 }
