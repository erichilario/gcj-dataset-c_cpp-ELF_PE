#include<stdio.h>
 #include<limits.h>
 int pan[1001];
 main()
 {
     int t;
     scanf("%d",&t);
     int res[t];
     int n=t;
     while(t)
     {
         int d,i;
         scanf("%d",&d);
         int rind=0;
         for(i=0;i<d;i++)
         {
             int k;
             scanf("%d",&k);
             if(rind<k)rind=k;
             pan[k]++;
         }
         int xyz=rind;
         int min=INT_MAX;
         int cnt=1,point=0;
         while(cnt)
         {
             int al=rind;
             if(min>(rind+point))min=rind+point;
             pan[rind]--;
             int p1=rind/2;
             int p2=rind-p1;
             pan[p1]++;
             pan[p2]++;
             point++;
             for(i=rind;i>=0;i--)
                 if(pan[i]!=0)break;
                 if(i==1)break;
                 else rind=i;
         }
 
 
     res[n-t]=min;
         t--;
     }
     for(t=0;t<n;t++)
     {
         printf("Case #%d: %d\n",t+1,res[t]);
     }
 
 }

