#include<stdio.h>
 int main()
 {
 	int t,tot,sm;char np[1001];
 	int i,smax,l,s,p,m;
 	scanf("%d",&t);
 	m=t;
 	while(t--)
 	{
 		tot=0;
 		scanf("%d",&smax);
 		scanf("%s",np);
 		l=smax+1;
 		s=np[0]-'0';
 		for(i=1;i<l;i++)
 		{
 			if(s<=i)
 			{
 			p=i-s;
 			tot=tot+p;
 			s=s+p;
 			}
  			s=s+np[i]-'0';
 		}
 		printf("Case #%d: %d\n",m-t,tot);
 	}
 	return 0;
 }
