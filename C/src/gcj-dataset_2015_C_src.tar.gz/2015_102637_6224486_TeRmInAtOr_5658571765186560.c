#include <stdio.h>
 
 int main()
 {
 	int tc, i, j, k, X, R, C, matrix[4][4];
 	char *winner;
 	char name1[] = "GABRIEL", name2[] = "RICHARD";
 
 
 	scanf ("%d",&tc);
 	for (i=1; i<=tc; i++) {
 		scanf("%d %d %d", &X, &R, &C);
 		if (X == 1) {
 			winner = name1;	
 		} else if (X == 2) {
 			if ((R*C)%2 == 0) {
 				winner = name1;
 			} else {
 				winner = name2;
 			}
 		} else if (X == 3) {
 			if ((R*C)==6||(R*C)==9||(R*C)==12) {
 				winner = name1;
 			} else {
 				winner = name2;
 			}	
 		} else {
 			if ((R*C)==12||(R*C)==16) {
 				winner = name1;
 			} else {
 				winner = name2;
 			}
 		}
 		
 		printf ("Case #%d: %s\n", i, winner);
 	}
 
 	return 0;
 }

