#include <stdio.h>
 
 unsigned Pi[10000];
 
 //#define TST_DEBUG
 
 #ifdef TST_DEBUG
 #define dprintf(...) printf(__VA_ARGS__)
 #else
 #define dprintf(...) ((void)0)
 #endif
 
 unsigned consume(unsigned n, unsigned *p)
 {
   unsigned i, c = 0;
 
   for (i=0; i<n; i++) {
     if (p[i]) p[i]--;
     if (p[i]) {
       p[c++] = p[i];
     }
   }
   return c;
 }
 
 unsigned maxpi(unsigned n, unsigned *p, unsigned *index)
 {
   unsigned i;
   unsigned m = 0;
 
   *index = 0;
 
   for (i=0; i<n; i++) {
     if (p[i] > m) {
       m = p[i];
       *index = i;
     }
   }
   return m;
 }
 
 int main(void) {
     unsigned casen=1,t,i,D, m;
     int rc;
  
     // get case num
     scanf("%u\n",&t);
  
     while(t--) {    
         printf("Case #%u: ", casen++);
 
         rc = scanf("%u\n",&D);
         if ((rc == 0) || (rc == EOF)) {
           printf("scanf failed\n");
           return 1;
         }
         
         for(i=0; i < D; i++) {
           rc=scanf("%u", &Pi[i]);
           if ((rc == 0) || (rc == EOF)) {
             printf("scanf failed\n");
             return 1;
           }
         }
 
         dprintf("D=%u\n", D);
         for(i=0; i < D; i++) {
           dprintf("P[%u]=%u ", i, Pi[i]); 
         }
         dprintf("\n");
 
         m = 0;
         while(D)
         {
           unsigned idx, mpi;
 
           mpi = maxpi(D, Pi, &idx);
 
           // take special minute, add one more worker taking half the max
           if (mpi > D) 
           {
             Pi[D] = Pi[idx]/2;
             Pi[idx] -= Pi[D];
             D++;
           }
           else
           {
             D = consume(D, Pi);
           }
           m++;
         }
 
         printf("%u\n", m);
     }
     return 0;
 }

