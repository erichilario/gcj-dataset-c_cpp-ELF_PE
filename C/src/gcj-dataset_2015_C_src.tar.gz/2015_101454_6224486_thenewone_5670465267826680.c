#include<stdio.h>
 int main(){
 	int t,T,n,l,x,minus,flag;
 	char c[10001];
 	int s[10001],m1,m2,i;
 	scanf("%d",&T);
 	int m[4][4];
 	m[0][0]=1;
 	m[0][1]=2;
 	m[0][2]=3;
 	m[0][3]=4;
 
 	m[1][0]=2;
 	m[1][1]=-1;
 	m[1][2]=4;
 	m[1][3]=-3;
 
 	m[2][0]=3;
 	m[2][1]=-4;
 	m[2][2]=-1;
 	m[2][3]=2;
 	
 	m[3][0]=4;
 	m[3][1]=3;
 	m[3][2]=-2;
 	m[3][3]=-1;
 	for(t=1;t<=T;t++){
 		scanf("%d%d",&l,&x);
 		scanf("%s",c);
 		if( l == 1 )
 		{
 			printf("Case #%d: NO\n",t);
 			continue;
 		}
 		for( i=0; i<l; i++)
 		{
 			if( c[i] == 'i' )
 				s[i]=1;
 			else if( c[i] == 'j')
 				s[i]=2;
 			else
 				s[i]=3;
 		}
 		minus=0;
 		flag=0;
 		m1=1;
 		while( x--){
 			i=0;
 			while( i < l ){
 				m2=s[i];
 				m1 = m[m1-1][m2];
 				if( m1 < 0 )
 				{
 					if( minus )
 						minus = 0;
 					else minus=1;
 					m1 *= -1;
 				}
 				if( flag == 0 &&  m1 == 2 && minus == 0 )
 				{
 						flag=1;
 						m1=1;					
 				}
 				else if(flag == 1 && m1 == 3 && minus == 0 )
 				{
 					flag =2 ;
 					m1=1;
 				}
 				i++;
 			}
 		}
 		if( m1 == 4 && minus == 0 && flag == 2 )
 			printf("Case #%d: YES\n",t);
 		else
 			printf("Case #%d: NO\n",t);
 	}
 	return 0;
 }

