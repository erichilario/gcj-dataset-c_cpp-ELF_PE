#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, const char * argv[]) {
     
     int test_cases,diners,max,previous_max;
     scanf("%d",&test_cases);
     
     int i,j,*pancakes,*time;
     
     time = calloc(test_cases,sizeof(int));
     
     //O(n)
     for (i=0;i<test_cases;i++) {
         scanf("%d",&diners);
         pancakes = malloc(diners*sizeof(int));
         
         //O(n)
         for(j=0;j<diners;j++){
             scanf("%d",&pancakes[j]);
         }
         
         max=0;
         previous_max = 0;
         
         //O(n)
         for(j=0;j<diners;j++){
             if(pancakes[j]>max){
                 previous_max=max;
                 max=pancakes[j];
             }
         }
         
         for(;max>=0;){
             
             //In case of only one or two pancakes - simply assign max to the time required
             if(max<3 && max>0){
                 time[i]+=max;
                 max=0;
                 break;
             }
             
             //If a single big tower exists - then divide the tower into two and continue
             if(previous_max==0 && max>2){
                 
                 max = max/2;
                 
                 if((max%2)==1)
                     max++;
                 
                 time[i]++;
             }
             
             //If there is not much difference between the two maxes then no sense in doing a shift operation
             if(previous_max!=0){
                 if(max-previous_max==1){
                     //do nothing - just take the time as max time and break the loop;
                     time[i]+=max;
                     break;
                 }
                 else {
                     max = max - previous_max;
                     time[i]++;
                 }
             }
         }
     }
     
     for(i=0;i<test_cases;i++){
         printf("Case #%d: %d\n",i+1,time[i]);
     }
     
     return 0;
 }

