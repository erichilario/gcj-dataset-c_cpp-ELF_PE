#include <stdio.h>
 #include <stdlib.h>
 
 int circ_rect_area[4] = {1, 2, 4, 6};
 
 int main(int argc, char** argv)
 {
   FILE* file = fopen(argv[1], "r");
   int i;
   int T, X, R, C;
 
   fscanf(file, "%d\n", &T);
 
   for(i=0; i<T; i++){
     printf("Case #%d: ", i+1);
     fscanf(file, "%d %d %d\n", &X, &R, &C);
     if(((R*C)%X != 0) || 
        (circ_rect_area[X-1] > R*C) || 
        (R*C == 8 && X == 4))
       printf("RICHARD\n");
     else
       printf("GABRIEL\n");
   }
 
   fclose(file);
 
   return EXIT_SUCCESS;
 }

