#include <stdio.h>
 #include <stdlib.h>
 
 
 int main(){
     FILE* entrada = fopen("entrada.in","r");
     FILE* salida = fopen("salida.txt","w");
     int casos,caso,sMax,numero,i,grupo,acumulado,amigos,personas;
     char secuencia[1010];
     char cadena[1000];
     
     fscanf(entrada,"%d\n",&casos);
     for(caso = 1;caso<=casos;caso++){
              fgets(secuencia,1010,entrada);
              sscanf(secuencia,"%d %s\n",&sMax,cadena);
              i=0;
              acumulado = 0;
              amigos = 0;
              while(i<=sMax){
                    personas = cadena[i] - '0';
                    if(personas){
                         if(i>acumulado){
                                amigos += i - acumulado;
                                acumulado += amigos;
                         }
                         acumulado += personas;
                    }
                    i++;
              }
              fprintf(salida,"Case #%d: %d\n",caso,amigos);
     }
     
     fclose(salida);
     fclose(entrada);
     return 0;
 }

