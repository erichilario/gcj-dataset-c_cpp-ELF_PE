#include<stdio.h>
 int main()
 {
 	int t,i,a,b,c,p;
 	scanf("%d",&t);
 	for(i=1;i<=t;i++)
 	{
 		scanf("%d%d%d",&a,&b,&c);
 		p=b*c;
 		if(a==1)
 		{
 			printf("Case #%d: GABRIEL\n",i);
 		}
 
 		else
 		{
 			if(p%a==0)
 			{
 				if(b<=a-2||c<=a-2)
 				{
 					printf("Case #%d: RICHARD\n",i);
 				}
 				else
 				{
 					printf("Case #%d: GABRIEL\n",i);
 				}
 			}
 			else
 			{
 				printf("Case #%d: RICHARD\n",i);
 			}
 		}
 	}
 	return 0;
 }

