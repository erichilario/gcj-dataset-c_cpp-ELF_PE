#include <stdio.h>
 #include <stdlib.h>
 
 #define READ_BUF_SIZE 1024
 
 int inviteNum(FILE *fp)
 {
     char readBuf[8];
     int shinessLevel = 0;
     int happyAudience = 0 ;
     int invitation = 0;
     char ch;
     int i;
     int val;
 
     //1. find shinessLevel
     do{
         ch = fgetc(fp);
         if( ch == ' ' || ch == EOF)
             break;
         shinessLevel = shinessLevel * 10 + (ch - '0');
     }while(1);
 
     //printf("level %d\n", shinessLevel);
 
     //2. process the data
     for( i = 0; i <= shinessLevel; i++)
     {
         val = fgetc(fp) - '0';
         //printf(" %c ", ch);
         if( val == 0 )
         {
             happyAudience == 0 ? invitation++ : happyAudience--;
         }
         else if( val > 1)
         {
             happyAudience += val - 1;
         }
 
     }
 
     fgets(readBuf, sizeof(readBuf), fp);
 
     return invitation;
 }
 
 
 int main(int argc, char **argv)
 {
     FILE *fp;
     int numCase;
     char readBuf[128];
     int i;
 
     if(argc != 2)
         return -1;
 
     fp = fopen(argv[1], "r");
 
     //read number of case 
     //fscanf(fp, "%d", &numCase);
 
     if(fgets(readBuf, sizeof(readBuf), fp ) != NULL)
     {
         numCase = atoi(readBuf);
     }
     else
     {
         printf("Can not read file\n");
         return 0;
     }
 
     for( i = 1; i <= numCase; i++)
     {
         printf("Case #%d: %d\n", i,
         inviteNum(fp));
     }
 
 
     fclose(fp);
     return 0;
 }
 
 

