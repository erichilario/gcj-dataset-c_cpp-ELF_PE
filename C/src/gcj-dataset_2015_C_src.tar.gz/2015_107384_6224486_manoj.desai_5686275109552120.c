#include <stdio.h>
 #include <string.h>
 #include <math.h>
 #include <stdlib.h>
 
 int main() {
     long long int t,z;
     scanf("%lld",&t);
     for(z=1;z<=t;z++){
         long long int n,j,i,f,m,l,max=0,nmax=0,tr=0;
         scanf("%lld",&n);
         l=n;
         long long int a[100000]={};
         for(i=0;i<n;i++)
             scanf("%lld",&a[i]);
          for(i=0;i<l;i++){
                 if(max<a[i])
                     max=a[i];
             }
         f=max;
             for(i=0;i<l;i++){
                 if(a[i]==max)
                     nmax++;
             }
         while(nmax<(max/2)){
             
             //  l=sizeof(a);
            
             if(max%2!=0){
                 tr++;
                 for(i=0;i<l;i++){
                     if(a[i]!=0)
                     a[i]--;
                 }
             }
             else{
                 for(i=0;i<l;i++){
                     if(a[i]==max)
                         a[i]=max/2;
                 }
                 for(i=n;i<n+nmax;i++){
                         a[i]=max/2;
                     }
                 tr+=nmax;
                 l+=nmax;
             }
             max=0;
             nmax=0;
              for(i=0;i<l;i++){
                 if(max<a[i])
                     max=a[i];
             }
             for(i=0;i<l;i++){
                 if(a[i]==max)
                     nmax++;
             }
         }
         if(nmax>=(max/2)){
             tr+=max;
         }
         if(tr>f)
             tr=f;
         printf("Case #%lld: %lld\n",z,tr);
     }
         return 0;
 }
 
 
 

