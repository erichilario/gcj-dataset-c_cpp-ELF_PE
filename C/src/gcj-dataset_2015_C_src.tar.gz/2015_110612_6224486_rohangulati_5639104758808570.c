//
 //  main.c
 //  codejam
 //
 //  Created by Rohan on 4/11/15.
 //  Copyright (c) 2015 rohan. All rights reserved.
 //
 
 #include <stdio.h>
 #include <string.h>
 
 #define IN_FILE "A-large.in"
 #define OUT_FILE "output-large.txt"
 
 #define FILE_READ 1
 #define FILE_WRITE 1
 
 FILE *in, *out;
 
 FILE * getReadStream() {
     if (FILE_READ) {
         if (in == NULL) {
             in = fopen(IN_FILE, "r");
         }
         return in;
     }
     return stdin;
 }
 
 FILE * getWriteStream() {
     if (FILE_WRITE) {
         if (out == NULL) {
             out = fopen(OUT_FILE, "w");
         }
         return out;
     }
     return stdout;
 }
 
 void standingOvation(int t, char * count, int n) {
     int ans = 0;
     int shy, sum = 0;
     
     for (shy = 0 ; shy<n;  shy++) {
         if (count[shy] - '0' == 0) {
             continue;
         }
         if (sum < shy) {
             ans += (shy - sum);
             sum = shy;
         }
         sum += (count[shy] - '0');
         
     }
 
     fprintf(getWriteStream(), "Case #%d: %d\n", t, ans);
 }
 
 int main(int argc, const char * argv[])
 {
     int t, n, test;
     char s[1010];
     fscanf(getReadStream(), "%d", &t);
     for (test = 1; test<=t; test++) {
         fscanf(getReadStream(), "%d %s" ,&n, s);
         standingOvation(test, s, n+1);
     }
     printf("Done\n");
     return 0;
 }
 

