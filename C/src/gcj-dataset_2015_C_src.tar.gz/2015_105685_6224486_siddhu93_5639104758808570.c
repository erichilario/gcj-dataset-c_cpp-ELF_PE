#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int main()
 {
 	long long int T, size, i, counter;
 	long long int sum, number, requirement, totRequirement;
 	char fileName[20];
 	char input[10000];
 	FILE *fp, *fo;
 
 	printf("Enter the filename:");
 	scanf("%s", fileName);
 
 	printf("Entered here");
 
 	fp = fopen(fileName, "r");
 	fo = fopen("ans", "w");	
 
 
 	fscanf(fp, "%lld", &T);
 
 	counter = 1;
 
 	while(T > 0)
 	{
 		sum = 0;
 		requirement = 0;
 		totRequirement = 0;
 		fscanf(fp, "%lld %s", &size, input);
 		
 		printf("Size is: %lld\n", size);
 		printf("Input is: %s\n", input);  
 		
 		for(i = 0; i < strlen(input); i++)
 		{
 			number = input[i] - 48;
 
 			printf("Processing number %lld\n", number);
 			if(number > 0 && sum >= i)
 			{
 				sum = sum + number;
 			}
 			else if (number > 0)
 			{
 				
 				requirement = i - sum;
 				totRequirement = totRequirement + requirement;
 				sum = sum + requirement + number;
 				
 			}
 			else
 			{
 
 			}
 
 			printf("Sum is %lld\n", sum);
 			printf("Requirement is %lld\n", requirement);
 		}
 
 		fprintf(fo, "Case #%lld:", counter);
 		fprintf(fo, " %lld\n", totRequirement);		
 		
 		counter++;
 		T--;
 	}  
 
 	fclose(fo);
 	return 0;
 }

