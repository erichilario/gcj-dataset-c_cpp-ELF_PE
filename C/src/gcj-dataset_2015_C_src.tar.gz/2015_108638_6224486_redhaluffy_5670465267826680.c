#include <stdio.h>
 #include <stdlib.h>
 #include <sys/types.h>
 #include <sys/stat.h>
 #include <fcntl.h>
 
 
 #include "dijkstra.h"
 
 
 int char_to_enum(char c)
 {
   switch(c){
   case 'i':
     return I;
   case 'j':
     return J;
   case 'k':
     return K;
   }
   return -1;
 }
 
 int mult(int a, int b)
 {
   int res;
 
   if(a > NUN)
     if(b <= NUN){
       res = corr[a-NUN][b];
       if(res >= NUN)
 	res -= NUN;
       else
 	res += NUN;
     }
     else
       res = corr[a-NUN][b-NUN];
   else
     if(b > NUN){
       res = corr[a][b-NUN];
       if(res >= NUN)
 	res -= NUN;
       else
 	res += NUN;
     }
     else
       res = corr[a][b];
   
   //fprintf(stderr, "%d*%d=%d\n", a, b, res);
   return res;
 }
 
 int main(int argc, char** argv)
 {
   int x, l;
   int i, j, k, y;
   int char_val;
   int prod = UN;//, prod_j=UN;
   int got_i=0, got_j=0;
   char* string;
 
   FILE* file = fopen(argv[1], "r");
   fscanf(file, "%d\n", &nbtests);
 
   for(i=0; i<nbtests; i++){
     got_i=0;
     got_j=0;
     prod = UN;
 
     printf("Case #%d: ", i+1);
 
     fscanf(file, "%d %d\n", &l, &x);
     string = malloc((l+1)*sizeof(char));
     fgets(string, (l+1)*sizeof(char), file);
 
     for(j=0; j<x; j++){
       for(k=0; k<l; k++){
 	char_val = char_to_enum(string[k]);
 	//printf("c=%d; prod=%d| ", char_val, prod);
 	if(!got_i){
 	  prod = mult(prod, char_val);
 	  //printf("%d", char_val);
 	  fflush(stdout);
 	  if(prod == I){
 	    got_i = 1;
 	    //printf(" gotI@%d", j*l+k);
 	    prod = UN;
 	  }
 	}
 	else if(!got_j){
 	  prod = mult(prod, char_val);
 	  if(prod == J){
 	    got_j = 1;
 	    //printf(" gotJ@%d", j*l+k);
 	    prod = mult(I, J);
 	  }
 	}
 	else{
 	  prod = mult(prod, char_val);
 	}
       }
     }
     if(got_i && got_j && prod == NUN)
       printf("YES\n");
     else
       printf("NO\n");
     free(string);
   }
 
   fclose(file);
 
   return EXIT_SUCCESS;
 }

