#include<stdio.h>
 main()
 {
     int t;
     scanf("%d",&t);
     int res[t];
     int n=t;
     while(t)
     {
         int smax;
         scanf("%d",&smax);
         char a[smax+10];
         int i;
         int count=0,frnd=0;
         scanf("%s",a);
         for(i=0;i<=smax;i++)
         {
             if(a[i]!=48)
             {
             if(count>=i)count+=(a[i]-48);
             else {int rfrnd=(i-count);count+=(a[i]-48);count+=rfrnd;frnd+=rfrnd;}
             }
         }
         res[n-t]=frnd;
         t--;
     }
     for(t=0;t<n;t++)
     {
         printf("Case #%d: %d\n",t+1,res[t]);
     }
 }

