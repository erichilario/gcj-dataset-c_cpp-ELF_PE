#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 #define lld long long int
 #define llu long long unsigned int
 int compare(const void * a, const void * b){return *(lld *)a-*(lld *)b;}
 //long long int readlint() {long long int n=0,count=0,counti=0; char c;while(1){c=getchar_unlocked();if(c=='-')count=1;else if((c==' '||c=='\n'||c==EOF) && counti==1)break;else if(c>='0' && c<='9'){counti=1;n=(n<<3)+(n<<1)+c-'0';}}if(count==0)return n;else return -n;}
 //int readint() {int n=0,count=0,counti=0; char c;while(1){c=getchar_unlocked();if(c=='-')count=1;else if((c==' '||c=='\n'||c==EOF) && counti==1)break;else if(c>='0' && c<='9'){counti=1;n=(n<<3)+(n<<1)+c-'0';}}if(count==0)return n;else return -n;}
 #define min(a,b)((a)>(b)?(b):(a))
 #define max(a,b)((a)<(b)?(b):(a))
 #define sort(arr,n) qsort(arr,n,sizeof(arr[0]),compare)
 #define sd(n) scanf("%d",&n)
 #define sl(n) scanf("%lld",&n)
 #define su(n) scanf("%llu",&n)
 #define ss(n) scanf("%s",n)
 #define FOR(i,start,end) for(i=start; i<end; i++)
 #define pdn(n) printf("%d\n",n)
 #define pln(n) printf("%lld\n",n)
 #define pun(n) printf("%llu\n",n)
 #define pd(n) printf("%d",n)
 #define pl(n) printf("%lld",n)
 #define pu(n) printf("%llu",n)
 #define pn puts("")
 #define ps putchar_unlocked(' ')
 void swap(int *x,int *y)
 {
 	*x=*x^*y;
 	*y=*x^*y;
 	*x=*x^*y;
 }
 int main()
 {
 	int i,j,k,n,t;
     sd(t);
     char s[100000];
     int smax;
     int aabhas=t;
     while(t--)
     {
         sd(smax);
         scanf("%s",s);
         long long now=s[0]-'0';
         long long ans=0;
         for(i=1;s[i]!='\0';i++)
         {
           //  printf("%d %Ld %c %Ld\n",i,now,s[i],ans);
             if(now< i && s[i]!='0')
             {
                 ans+=i-now;
                 now=i+s[i]-'0';
             }
             else
                 now=now+s[i]-'0';
             //printf("%d %Ld %c %Ld\n",i,now,s[i],ans);
         }
         printf("Case #%d: %Ld\n",aabhas-t,ans);
     }
 	return 0;
 }
 

