#include<stdio.h>
 int main(void)
 {
 	FILE *input=fopen("abc.txt","r");
 	FILE *output=fopen("abcd.txt","w");
 	long t,num,temp,i,j,k,l,count=0;
 	scanf("%ld",&t);
 	for(i=0;i<t;i++)
 	{
 		fscanf(input,"%ld",&j);
 		fscanf(input,"%ld",&num);
 		int arr[j+1],arr2[j+1];
 			temp=j+1;
 		for(j;j>-1;j--,num/=10)
 			arr[j]=num%10;
 			arr2[0]=arr[0];
 		for(j=1;j<temp;j++)
 			arr2[j]=arr[j]+arr2[j-1];
 			if(arr2[0]==0)
 			{count++;for(k=0;k<temp;k++)
 					arr2[k]++;}
 		for(j=1;j<temp;j++)
 		{	if(arr2[j]<=j) 
 			{
 				count++;
 				for(k=j;k<temp;k++)
 					arr2[k]++;
 			}
 			//for(l=0;l<temp;l++)
 			//printf("%ld ",arr2[l]);
 			//printf("%ld\n",count);
 			
 		}
 		fprintf(output,"Case #%ld: %ld\n",i+1,count);
 		count=0;
 	}
 }
