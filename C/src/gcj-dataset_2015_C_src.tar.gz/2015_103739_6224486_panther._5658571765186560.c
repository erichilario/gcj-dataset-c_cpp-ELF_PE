#include <stdio.h>
 
 int main()
 {
     FILE *fi;
     FILE *fout;
 
     fi = fopen("in.txt","r");
     fout = fopen("out.txt","w");
 
     int t,i,j,n2,temp, lastresult;      // d = no. of non empty plates, p = no. of pan cakes on the plate
     float n1,x,r,c;                // n1 and n2 are to check that the equation 1 gives int or not
 
     fscanf(fi,"%i",&t);
 
     for(i=0;i<t;i++)
     {
         fscanf(fi, "%f", &x);
         fscanf(fi, "%f", &r);
         fscanf(fi, "%f", &c);
 
                  // ......... 1
         n2=(r*c)/x;
 
         n1=(r*c)/x;
 
 
 
         if(n1!=n2)
         {
             fprintf(fout,"Case #%i: RICHARD\n",i+1);
             continue;
         }
         else
         {
             n1 = (x+1)/2;
             n2 = x+1-n1;
 
             if(n1<n2)               // So than n1 will always greater than n2
             {
                 temp = n1;
                 n2 = n1;
                 n1 = temp;
             }
 
             if(r<c)
                 temp = r;
             else
                 temp = c;
 
             lastresult=0;
 
             while(n1<=x)
             {
                 if((n1>temp)&&(n2>temp))
                 {
                     lastresult=1;
                     break;
                 }
                 n1++;
                 n2--;
             }
 
             if(lastresult==1)
             {   fprintf(fout,"Case #%i: RICHARD\n",i+1);  }
             else
             {   fprintf(fout,"Case #%i: GABRIEL\n",i+1);  }
         }
     }
 
     fclose(fi);
     fclose(fout);
 
     return 0;
 }

