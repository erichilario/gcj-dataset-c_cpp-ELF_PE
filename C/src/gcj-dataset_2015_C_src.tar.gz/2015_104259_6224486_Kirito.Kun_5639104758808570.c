#include <stdio.h>
 #include <stdlib.h>
 #include <conio.h>
 
 int main()
 {
     FILE* Input = NULL;
     FILE* Output = NULL;
     Input = fopen("Input.txt","r");
     Output = fopen("Output.txt","w");
     int T,N,S = 0,y;
     char c;
     char* String = NULL;
     String = (char*)malloc(1010*sizeof(char));
     int i,j;
     fscanf(Input,"%d",&T);
     for(i=0;i<T;i++)
     {
         y = 0;
         S = 0;
         fscanf(Input,"%d",&N);
         c = fgetc(Input);
         fgets(String,N+2,Input);
         fgetc(Input);
         S += String[0]%'0';
         for(j=1;j<N+1;j++)
         {
             if(j > S && String[j] != '0')
             {
                 y += j-S;
                 S += y;
             }
             S += String[j]%'0';
         }
         fprintf(Output,"Case #%d: %d\n",i+1,y);
     }
     printf("\nDone !");
     getch();
     return 0;
 }

