#include <stdio.h>
 
 int main ()
 {
 	int tc;
 	int max;
 	int i, j, D, num, ans;
 	scanf ("%d",&tc);
 
 	for (i=1; i<=tc; i++) {
 
 		scanf ("%d", &D);
 		max = 1;
 		ans = 0;
 
 		for (j=0; j<D; j++) {
 			scanf ("%d", &num);
 
 			switch (num) {
 
 				case 2:
 					max=2;
 					break;
 
 				case 3:
 				case 4:
 					max=2;
 					ans += 1;
 					break;
 
 				case 5:
 				case 6:
 				case 7:
 				case 8:
 					max=2;
 					ans += 2;
 					break;
 
 				case 9:
 					max=2;
 					ans += 3;
 					break;
 			}
 		}
 		ans += max;
 		printf ("Case #%d: %d\n", i, ans);
 
 	}
 
 	return 0;
 }

