#include <errno.h>
 #include <stdio.h>
 #include <stdint.h>
 #include <stdlib.h>
 #include <string.h>
 
 
 int main(int argc, char **argv) {
   char buffer[BUFSIZ];
   uint32_t records, i;
   FILE *src = stdin, *dst = stdout;
 
   if(argc >= 2) {
     src = fopen(argv[1], "rb");
   }
 
   if(argc >= 3) {
     dst = fopen(argv[2], "wb");
   }
 
   if(!fgets(&buffer[0], sizeof(buffer), src)) {
     return 1;
   }
 
   if(sscanf(&buffer[0], "%u", &records) != 1) {
      return 2;
   }
 
   for(i = 0; i < records; i++) {
     char *ptr = &buffer[0], *end;
     uint32_t count, j, minutes, max, eaten;
     uint16_t diners[1000];
 
     if(!fgets(ptr, sizeof(buffer), src)) {
       return 3;
     }
 
     if(sscanf(ptr, "%u", &count) != 1) {
        return 4;
     }
 
     if(!fgets(ptr, sizeof(buffer), src)) {
       return 3;
     }
 
     memset(&diners[0], 0, sizeof(diners));
 
     for(max = j = 0; j < count; j++) {
       uint32_t stack = strtoul(ptr, &end, 10);
 
       if(*end && *end != ' ' && *end != '\n') {
         return 5;
       }
 
       if(stack > max) {
         max = stack;
       }
  
       diners[stack]++;
       ptr = end + 1;
     }
 
     for(eaten = minutes = 0; eaten < max; minutes++) {
       uint32_t count, run = max - (max - eaten + 1) / 2;
 
       for(count = 0; run++ < max;) {
         count += diners[run];
       }
 
       if((max - eaten) >= 4 && count <= ((max - eaten) / 2)) {
         if(max % 2) {
           diners[max / 2]++;
           diners[max / 2 + 1]++;
         }
         else {
           diners[max / 2] += 2;
         }
         if(!--diners[max]) {
           do {
            max--;
           } while(!diners[max]);
         }
       }
       else {
         eaten++;
       }
     }
      
     fprintf(dst, "Case #%u: %u\n", i + 1, minutes);
   }
 }
 

