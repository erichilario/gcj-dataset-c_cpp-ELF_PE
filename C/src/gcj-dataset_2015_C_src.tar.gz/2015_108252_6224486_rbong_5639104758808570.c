#include <stdio.h>
 int main (int argc, const char *argv[])
 {
     int i, j;
     int cases, len, standing, memb, min, friends;
     char audience [1001], temp [1001];
     FILE *fp = fopen (argv [1], "r");
     fscanf (fp, "%d", &cases);
     for (i = 0; i < cases; i++)
     {
         fscanf (fp, "%d %s", &len, audience);
         friends = 0;
         do
         {
             min = -1;
             standing = friends;
             for (j = 0; j <= len; j++)
             {
                 memb = audience [j] - '0';
                 if (standing >= j)
                     standing += memb;
                 else if (memb != 0)
                 {
                     min = j;
                     break;
                 }
             }
             if (min == -1)
                 break;
             else
                 friends = min - standing + friends;
         } while (1);
         printf ("Case #%d: %d\n", i + 1, friends);
     }
     return 0;
 }

