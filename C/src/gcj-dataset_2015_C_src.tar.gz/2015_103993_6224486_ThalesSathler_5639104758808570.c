#include <stdio.h>
 
 int main(){
 	FILE *input, *output;
 	int i, n, c=0;
 	int pessoa[7];
 	int totalpessoas=0;
 	int tc;	//test cases 1<t<100	
 	int smax; //shyness level 1<smax<6
 	int resultado=0;
 
 	input=fopen("A-small-attempt5.in","r");
 	output=fopen("output.in","w");
 	fscanf(input,"%d", &tc);
 
 	n=1;
 	while(c < tc){
 		totalpessoas = 0; 
 		resultado = 0;
 		fscanf(input,"%d", &smax);
 		for(i = 0; i<smax+1; i++){
 				fscanf(input, "%1d" , &pessoa[i]);
 		}
 		n=0;
 		while(n<=smax)
 		{
 			if(n>totalpessoas){
 				resultado+=1;
 				totalpessoas+=1;
 			}
 			totalpessoas+=pessoa[n];
 			n++;
 		}
 		n=0;
 		fprintf(output,"Case #%d:", c+1);
 		fprintf(output," %d\n",resultado );
 		c++;
 	}
 	
 	fclose(input);
 	fclose(output);
 
 	return 0;
 }
