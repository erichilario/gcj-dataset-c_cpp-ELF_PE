#include<stdio.h>
 #include<stdlib.h>
 int a[1010];
 int Cmpa(const int*i,const int*j);
 int main(void)
 {
 	int i,j,n,pi,qi,sump,min,max;
 	freopen("B-large.in","r",stdin);
 	freopen("B-large.out","w",stdout);
 	scanf("%d",&pi);
 	for(qi=1;qi<=pi;qi++)
 	{
 		scanf("%d",&n);
 		max=0;
 		for(i=1;i<=n;i++)
 		{
 			scanf("%d",&a[i]);
 			max=a[i]>max?a[i]:max;
 		}
 		qsort(a+1,n,sizeof(a[1]),Cmpa);
 		min=(1<<30);
 		for(i=max;i>=1;i--)
 		{
 			sump=i;
 			for(j=1;j<=n;j++)
 			{
 				if(a[j]<=i)
 				{
 					break;
 				}
 				sump=sump+(a[j]-1)/i;
 			}
 			min=sump>min?min:sump;
 		}
 		printf("Case #%d: %d\n",qi,min);
 	}
 	return 0;
 }
 int Cmpa(const int*i,const int*j)
 {
 	return *j-*i;
 }
