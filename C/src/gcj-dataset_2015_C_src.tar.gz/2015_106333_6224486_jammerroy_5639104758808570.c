#include<stdio.h>
 #include<string.h>
 
 int main()
 {
 int friends,i,standing,l;
 char shy[1000];
 int totalf=0;
 int shyness;
 int j=1;
 int test;
 scanf("%d",&test);
 
 while(test>=0)
 {
 scanf("%d",&shyness);
 scanf("%s",shy);
 l=strlen(shy);
 friends=0;
 totalf=0;
 standing=(shy[0]-48);
 for(i=1;i<l;i++)
 	{if((shy[i]-48)==0)
 		continue;
 	if((shy[i]-48)>0)
 		{if(standing>=i)	
 			standing=standing+(shy[i]-48);
 		else
 			{friends=(i-standing);
   			 standing=standing+friends+(shy[i]-48);
    			totalf=friends+totalf;
 			}
  		}
 	}
 
 printf("Case #%d: %d",j,totalf);
 printf("\n");
 test--;
 j++;
 }
 return 0;
 }
 

