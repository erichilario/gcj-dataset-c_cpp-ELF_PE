#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, char **argv)
 {
 	int iTst, i,j, *sl, *istr, flg;
 	long int sSum, nSum;
 	char **str, line[1024], *tmp;
 	scanf("%d", &iTst);
 	if(1>iTst || iTst >100){
 		printf("Invalid test cases!.");
 		return 0;
 	}
 	sl=(int *)calloc(sizeof(int), iTst);
 	str=(char **)calloc(sizeof(char*), iTst);
 	for(i=0;i<iTst;i++){
 		//fflush(stdin);
 		scanf("%d",&sl[i]);
 		//fflush(stdin);
 		tmp=fgets(line, sl[i]+3, stdin);		
 		//sl[i]=line[0]-'0';
 		line[sl[i]+2]='\0';
 		//printf("%d\n",sl[i]);
 		str[i]=(char *)calloc(sizeof(char), sl[i]+4);
 		strcpy(str[i], line);		
 	}
 	
 	for(i=0;i<iTst;i++){
 		//printf("%d %s\n",sl[i], str[i]);
 		if(sl[i]<0||sl[i]>1000){
 			printf("%d\n", -1);
 		}else if(str[i][sl[i]+1]=='0'){
 			printf("%d\n", -1);
 		}else{
 			j=1;
 			sSum=nSum=0;flg=0;
 			while((str[i][j]!='\0') && (flg!=-1)){
 				if(str[i][j]>='0' && str[i][j]<='9'){
 					if((str[i][j]=='0') && (flg==0)){
 						flg=1;
 					}else if(str[i][j]!='0'){
 						if(flg){
 							if((j-1)>sSum)
 								nSum+=((j-1)>sSum)?((j-1)-sSum):(sSum-(j-1));
 								sSum+=nSum;
 							flg=0;
 						}
 						sSum+=str[i][j]-'0';						
 					}
 				}else{
 					flg=nSum=-1;
 				}
 				j++;
 			}
 			printf("Case #%d: %ld\n",i+1, nSum);
 		}
 	}
 	free(sl);
 	free(str);
 	return 0;
 }

