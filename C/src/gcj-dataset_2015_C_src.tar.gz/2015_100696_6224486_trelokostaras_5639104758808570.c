#include<stdio.h>
 
 main(){
 int cases;
 scanf("%d\n",&cases);
 char S[5000];
 	for(int cas=1;cas<=cases;cas++){
 		int max;
 		scanf("%d %s\n",&max,S);
 		for(int i=0;S[i]!='\0';i++){
 			S[i] -= '0';
 		}
 		int brave = 0;
 		int friends = 0;
 		for(int i=0;i<=max;i++){
 			if(brave + friends < i)
 				friends = i-brave;
 			brave += S[i];
 		}
 		
 		printf("Case #%d: %d\n",cas,friends);
 
 	}
 }

