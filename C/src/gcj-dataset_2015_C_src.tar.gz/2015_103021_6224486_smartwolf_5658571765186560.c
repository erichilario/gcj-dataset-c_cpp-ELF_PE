#include<stdio.h>
 int main()
 {
     int X,R,C,T,i;
     scanf("%d",&T);
     for(i=0;i<T;i++)
     {
         scanf("%d",&X);
         scanf("%d",&R);
         scanf("%d",&C);
         if(((R*C)<(2*X)) || ((R*C)>(2*X)))
         {
             printf("Case #%d: RICHARD\n",i+1);
         }
         else
         {
             if(X==1 || X==2)
                 printf("Case #%d: GABRIEL\n",i+1);
                 else
                 if (X==4)
                 {
                     if (R==1 || R==8)
                         printf("Case #%d: GABRIEL\n",i+1);
                     else
                         printf("Case #%d: RICHARD\n",i+1);
                 }
                 if (X==3)
                 {
                     if (R==1 || R==6)
                         printf("Case #%d: GABRIEL\n",i+1);
                     else
                         printf("Case #%d: RICHARD\n",i+1);
                 }
         }
     }
     return 0;
 }

