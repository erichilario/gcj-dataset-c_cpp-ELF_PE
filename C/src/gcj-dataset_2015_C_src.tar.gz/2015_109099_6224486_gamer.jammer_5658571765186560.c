#include <stdio.h>
 
 int main()
 {
     int t, x, r, c, i;
 
     scanf("%d", &t);
     for(i = 0; i < t; i++)
     {
         scanf("%d %d %d", &x, &r, &c);
         if(x < 7)
         {
             if(r >= x - 1 && c >= x - 1 && (r * c) % x == 0)
                 printf("Case #%d: GABRIEL\n", i + 1);
             else
                 printf("Case #%d: RICHARD\n", i + 1);
         }
         else
             printf("Case #%d: RICHARD\n", i + 1);
 
     }
     return 0;
 }

