#include<stdio.h>
 int main()
 {
         int t,numStanding,friendsReq,i,caseNo,reqStanding;
         char c;
         scanf("%d",&t);
         caseNo=1;
         while(t>0)
         {
                 t--;
                 friendsReq=0;
                 scanf("%d",&i);
                 scanf("%c",&c);   // Skipping a space 
                 scanf("%c",&c);   // No.of people with shyness level 0 
                 numStanding=c-48; // People with shyness level 0 will all stand up immediately
                 for(reqStanding=1;reqStanding<=i;reqStanding++)
                 {       
                         scanf("%c",&c);
 			if(c>48)
 			{
                        	 	if(reqStanding>numStanding)  // if no of people required standing is less than no of people actually standing, then we need to call as many friends as the diff
                        	 	{
                        	         	friendsReq+=reqStanding-numStanding;
 					numStanding+=reqStanding-numStanding;
                        		}
                         	numStanding+=c-48;
 			}
                 }
                 printf("Case #%d: %d\n",caseNo,friendsReq);
 		caseNo++;
         }       
         return 0;
 }

