#include <stdio.h>
 
 int main()
 {
 	int t, i, j, smax;
 	char str[10005];
 	long count, sum;
 
 	scanf("%d", &t);
 	for(i = 0; i < t; i++)
 	{
 		count = sum = 0;
 		scanf("%d", &smax);
 
 		scanf("%s", str);
 
 		sum += (str[0] -'0');
 
 		for(j = 1; str[j] != '\0'; j++)
 		{
 			if(str[j] != '0' && sum < j)
 			{
 				count += j - sum;
 				sum += count;
 			}
 
 			sum += (str[j] -'0');
 		}
 		printf("Case #%d: %ld\n", i + 1, count);
 	}
 	return 0;
 }
