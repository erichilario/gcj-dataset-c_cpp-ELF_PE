#include<stdio.h>
 int main(){
 	int t,T,i, n,r,k;
 	scanf("%d",&T);
 	char s[1001];
 	for(t=1;t<=T;t++){
 		scanf("%d%s",&k,s);
 		n=0;r=0;
 		n=s[0]-'0';
 		for(i=1;i<=k;i++){
 			if( i > n )
 			{
 				r += i-n;
 				n += i-n;
 			}
 			n += s[i]-'0';
 		}
 		printf("Case #%d: %d\n",t,r);
 	}
 	return 0;
 
 }
 
 
 
 

