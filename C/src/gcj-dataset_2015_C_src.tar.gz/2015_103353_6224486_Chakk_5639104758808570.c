#include<stdio.h>
 #include<string.h>
 #define gc getchar
 
 char str[10002];
 
 inline int scan()
 {
    	int n = 0;
    	int ch = gc();
    	int sign = 1;
    	while(ch < '0' || ch > '9')
 	{
 		if(ch == '-')
 			sign = -1;
    		ch = gc();
 	}
    	while(ch >= '0' && ch <= '9')
 		n = (n << 3) + (n << 1) + ch - '0', ch = gc();
    n = n * sign;
    return n;
 }
 
 int main()
 {
 	int smax, i, j, cnt1 = 0, t, add, len, k = 1;
 	t = scan();
 	//getchar();
 	while(t--)
 	{
 		smax = scan();
 		//getchar();
 		scanf("%s", str);
 		//printf("\n%s\n", str);
 		len = smax+1;
 		cnt1 = 0;
 		add = 0;
 		for(i = 1; i < len; i++)
 		{
 			add += (str[i-1]-48);
 			//printf("add=%i\n", add);
 			//printf("i=%i\n", i);
 			if(str[i] != '0')
 			{
 				if(add < i)
 				{
 					cnt1 += (i - add);
 					add += (i-add);
 					//printf("%i\n", i-add);
 				}
 			}
 		}
 		printf("Case #%i: %i\n", k++, cnt1);
 	}
 	return 0;
 }

