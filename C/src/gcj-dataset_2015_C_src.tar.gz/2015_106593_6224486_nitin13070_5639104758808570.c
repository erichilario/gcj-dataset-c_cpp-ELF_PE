#include <stdio.h>
 #include <stdlib.h>
 
 int main(){
 	int T,S,i,k,val;
 	long long int count,fcount;
 	char str[2000];
 	FILE *ifp,*ofp;
 	ifp = fopen("practice.in","r");
 	ofp = fopen("output.in","w");
 
 	fscanf(ifp,"%d",&T);
 	for(i=0;i<T;i++){
 		count = 0;fcount=0;
 
 		fscanf(ifp,"%d %s",&S,str);
 		for(k=0;k<S+1;k++){
 			val = str[k] - '0';
 			count += val;
 			if(count <= k){
 				fcount += (k+1)-count;
 				count += (k+1)-count;
 			}
 		}
 		printf("CASE #%d: %lld\n",i+1,fcount);
 		fprintf(ofp,"CASE #%d: %lld\n",i+1,fcount);
 
 	}
 	return 0;
 }
