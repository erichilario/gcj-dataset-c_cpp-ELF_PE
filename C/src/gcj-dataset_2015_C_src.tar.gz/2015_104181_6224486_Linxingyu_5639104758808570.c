#include <stdio.h>
 #include <string.h>
 
 int test,n,sum,ans;
 char s[1000];
 
 int main()
 {
     freopen("x.in","r",stdin);
     freopen("x.out","w",stdout);
     scanf("%d",&test);
     for (int i = 0; i < test; ++i)
     {
         scanf("%d",&n);
         scanf("%s",s);
         sum= s[0] - '0';
         ans= 0;
         for (int j=1; j<=n; ++j)
         {
             int c=s[j]-'0';
             if (sum<j)
             {
                 ans+=j-sum;
                 sum+=j-sum+c;
             } else sum+=c;
         }
         printf("Case #%d: %d\n",i+1,ans);
     }
 }
