/* gcc -o pb1 pb1.c  */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 #define TRUE 1
 #define FALSE 0
 
 
 static void solve (void);
 
 int main () 
 {
     freopen ("in.txt", "r", stdin);
     freopen ("out.txt", "w", stdout);
     int t,i;
     scanf ("%d", &t);
     for (i = 0; i < t; i++) {
         printf ("Case #%d: ", i + 1);
         solve ();
     }
     return 0;
 }
 
 
 void solve (void) 
 {
     int i;
     int total = 0;
     int res = 0;
     int a;
     static char s[1000];
 
     scanf("%d %s", &a, &s);
 
     total = s[0] - '0';
 
     for(i = 1; i <= a; i++){
         s[i] -= '0';
         if(total < i){
             res += (i-total);
             total += (i-total);
         }
         total += s[i];
     }
     printf("%d\n",res);
 }
 
 

