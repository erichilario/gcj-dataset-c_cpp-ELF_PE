#include <stdio.h>
 #include <stdlib.h>
 
 static int solveTestCase();
 static void sortArray(int *, int len);
 static void printArray(int *, int len);
 
 int
 main(int argc, char ** argv) {
 	int testCaseCnt = 0;
 	int i = 0;
 
 	scanf("%d", &testCaseCnt);
 
 	for(i=1; i <= testCaseCnt; i++) {
 		printf("Case #%d: %d\n", i, solveTestCase());
 	}
 
 	return 0;
 }
 
 static int
 solveTestCase()
 {
 	int numPpl = 0;
 	int i = 0;
 	int time = 0;
 	int arr[100] = {0};
 
 	scanf("%d", &numPpl);
 	for(i = 0; i < numPpl; i++) {
 		scanf("%d", &arr[i]);
 	}
 
 	// Sort the array
 	sortArray(arr, numPpl);
 
 	while(arr[0] > 0) {
 		// Increment the time counter
 		time++;
 
 		if((arr[0] % 2 == 0) && (arr[0] > 2)) {
 			int half = arr[0] / 2;
 
 			// It is the special time
 			if(arr[numPpl - 1] == 0) {
 				arr[numPpl - 1] = half;
 			}
 			else {
 				arr[numPpl] = half;
 				numPpl += 1;
 			}
 
 			arr[0] = half;
 			sortArray(arr, numPpl);
 		}
 		else {
 			// Reduce every element by 1. This symbolizes
 			// one pie eaten by all people who have pie on
 			// their plate
 			for(i = 0; i < numPpl; i++) {
 				arr[i] -= 1;
 			}
 		}
 	}
 
 	return time;
 }
 
 static void
 printArray(int * arr, int len) {
 	int i = 0;
 
 	fprintf(stderr, "\n------\n");
 	for(i = 0; i < len; i++) {
 		fprintf(stderr, "%d ", arr[i]);
 	}
 	fprintf(stderr, "\n------\n");
 }
 
 static void
 sortArray(int * arr, int len) {
 	int i = 0;
 	int j = 0;
 	int temp = 0;
 
 	for(i=0; i < len; i++) {
 		for(j = i + 1; j < len; j++) {
 			if(arr[i] < arr[j]) {
 				temp = arr[i];
 				arr[i] = arr[j];
 				arr[j] = temp;
 			}
 		}
 	}
 }

