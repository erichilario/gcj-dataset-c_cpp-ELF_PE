#include<stdio.h>
 int map[4][4] = {{1,2,3,4},{2,-1,4,-3},{3,-4,-1,2},{4,3,-2,-1}};
 int get_int(){
 	char c;
 	while (c=getchar(),c<'0'||c>'9'){}
 	int result = 0;
 	while (c>='0'&&c<='9'){
 		result = result*10+c-'0';
 		c = getchar();
 	}
 	return result;
 }
 int get_longlong(){
 	char c;
 	while (c=getchar(),c<'0'||c>'9'){}
 	long long result = 0;
 	while (c>='0'&&c<='9'){
 		result = result*10+c-'0';
 		c = getchar();
 	}
 	return result;
 }
 int m(int x,int y){
 	if (x>0&&y>0) {return map[x-1][y-1];}
 	if (x>0&&y<0) {return (-1)*map[x-1][(-1)*y-1];}
 	if (x<0&&y>0) {return (-1)*map[(-1)*x-1][y-1];}
 	if (x<0&&y<0) {return map[(-1)*x-1][(-1)*y-1];}
 }
 int main(){
 	freopen("C.in","r",stdin);
 	freopen("C.out","w",stdout);
 	int i,j,t,T,L,l[10000],ans,left[10000],right[10000];
 	long long X,len,ans_left,ans_right,ans_mid;
 	T = get_int();
 	for (t=1;t<=T;t++){
 		L = get_int();
 		X = get_longlong();
 		len = X*L;
 		for (i=0;i<L;i++){
 			l[i] = getchar()-'i'+2;
 			if (i==0) {
 				left[i] = m(1,l[i]);
 			} else {
 				left[i] = m(left[i-1],l[i]);
 			}
 		}
 		for (i=L-1;i>=0;i--) {
 			if (i==L-1) {
 				right[i] = m(l[i],1);
 			} else {
 				right[i] = m(l[i],right[i+1]);
 			}
 		}
 		ans = 0;
 		if (len>=3) {
 			ans_left = len;
 			for (i=0;i<L;i++){
 				if (left[i]==2) {if (i<ans_left) ans_left = i;}
 				if (m(left[L-1],left[i])==2) {if (i+L<ans_left) ans_left = i+L;}
 				if (left[i]==-2) {if (i+2*L<ans_left) ans_left = i+2*L;}
 				if (m(left[L-1],left[i])==-2) {if (i+3*L<ans_left) ans_left = i+3*L;}
 			}
 			//printf("ans_left:%d\n",ans_left);
 			if (ans_left < len) {
 				ans_right = -1;
 				for (i=L-1;i>=0;i--) {
 					if (right[i]==4) {if (len-L+i>ans_right) ans_right = len-L+i;}
 					if (m(right[i],left[L-1])==4) {if (len-2*L+i>ans_right) ans_right = len-2*L+i;}
 					if (right[i]==-4) {if (len-3*L+i>ans_right) ans_right = len-3*L+i;}
 					if (m(right[i],left[L-1])==-4) {if (len-4*L+i>ans_right) ans_right = len-4*L+i;}
 				}
 				//printf("ans_right:%lld\n",ans_right);
 				if (ans_right >=0) {
 					if (ans_right-ans_left>2*L){
 						ans_mid = 1;
 						while (ans_right-ans_left>=2*L){
 							ans_mid = m(ans_mid,left[L-1]);
 							ans_left+=L;
 						}
 						if (ans_left%L>ans_right%L &&ans_right-ans_left>=L) {
 							ans_mid = m(ans_mid,left[L-1]);
 							ans_left+=L;
 						}
 						//printf("ans_left:%lld,ans_mid:%d,ans_right:%lld\n",ans_left,ans_mid,ans_right);
 						while (ans_left>=L) ans_left-=L;
 						while (ans_right>=L) ans_right-=L;
 						//printf("ans_left:%lld,ans_mid:%d,ans_right:%lld\n",ans_left,ans_mid,ans_right);
 						if (ans_left<L-1) ans_mid = m(right[ans_left+1],ans_mid);
 						//printf("ans_mid:%d\n",ans_mid);
 						if (ans_right>0) ans_mid = m(ans_mid,left[ans_right-1]);
 						//printf("ans_mid:%d\n",ans_mid);
 						if (ans_mid == 3) {
 							ans = 1;
 						}
 					} else if (ans_right-ans_left>1){
 						ans_mid = 1;
 						while (ans_left+1<=ans_right-1) {
 							ans_mid = m(ans_mid,l[(ans_left+1)%L]);
 							ans_left++;
 						}
 						if (ans_mid == 3) {
 							ans = 1;
 						}
 					}
 				}
 			}
 		} else {
 			ans = 0;
 		}
 		if (ans) printf("Case #%d: YES\n",t);
 		else printf("Case #%d: NO\n",t);
 	}
 }
