#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
     long int test,n,count,need,stand,i,x;
     char s[2000];
     scanf("%ld",&test);
     for(count=1;count<=test;count++)
     {
         need=0;
         stand=0;
         scanf("%ld",&n);
         scanf("%s",s);
         for(i=0;s[i]!='\0';i++)
         {
             if(stand<=i && s[i]=='0')
             {
                 need++;
                 stand++;
             }
             else
             {
                 x=s[i]-'0';
                 stand=stand+x;
             }
            
         }
         printf("Case #%ld: %ld\n",count,need);
     }
     return 0;
 }
