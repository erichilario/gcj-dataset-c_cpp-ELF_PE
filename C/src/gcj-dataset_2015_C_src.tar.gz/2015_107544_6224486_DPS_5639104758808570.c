#include<stdio.h>
 int main()
 {
      int t,c=0,p,n,i,f=0;
     char s[1001];
     FILE *fp;
     fp=fopen("output1.txt","w+");
     freopen("A-large.in","r",stdin);
     scanf("%d",&t);
     p=1;
     while(t--)
     {
         scanf("%d %s",&n,s);
         c=0;
         f=0;
         for( i=0;s[i]!='\0';i++)
         {
             if(s[i]!='0')
             {
             	f+=s[i]-49;
             }
             else
             {
             	if(f==0)
             		  c++;
             	else
 						f--;
             		
 			}
             
         }
         fprintf(fp,"Case #%d: %d\n",p++,c);
         
     }
     fclose(fp);
     return 0;
 }

