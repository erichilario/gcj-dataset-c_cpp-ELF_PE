#include <stdio.h>
 
 int m[4][4][4] = {
 	{{0, 1, 1, 1}, {0, 0, 1, 1}, {0, 1, 1, 1}, {0, 0, 1, 1}},
 	{{0, 0, 1, 1}, {0, 0, 1, 1}, {0, 0, 0, 1}, {0, 0, 1, 1}},
 	{{0, 1, 1, 1}, {0, 0, 0, 1}, {0, 1, 0, 1}, {0, 0, 0, 0}},
 	{{0, 0, 1, 1}, {0, 0, 1, 1}, {0, 0, 0, 0}, {0, 0, 1, 0}},
 	};
 
 
 int main(){
 	int T, X, R, C, case1 = 1;
 	scanf("%d", &T);
 	while(T--){
 		scanf("%d %d %d", &X, &R, &C);
 		if(m[C - 1][R - 1][X - 1])
 			printf("Case #%d: RICHARD\n", case1);
 		else
 			printf("Case #%d: GABRIEL\n", case1);
 		case1++;
 	}
 	return 0;
 }
