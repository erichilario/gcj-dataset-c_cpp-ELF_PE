#include <stdio.h>
 #include <stdlib.h>
 
 
 int comparar(const void * a, const void * b)
 {
   int fa = *(const int*) a;
   int fb = *(const int*) b;
   return (fa < fb)-(fa > fb);
 }
 
 void calcularMaximos(int* platos,int cantidadPlatos,int* maximo,int* cantidadMaximos,int* segundoMaximo){
      int j=0;
      *maximo = platos[0];
      *segundoMaximo = 0;
      *cantidadMaximos = cantidadPlatos;
      while(j<cantidadPlatos){
           if(platos[j]!=(*maximo)){
                *segundoMaximo = platos[j];
                *cantidadMaximos = j;
                break;
           }
           j++;
      }
 } 
 
 int mitad(int numero){
     int respuesta = numero/2;
     if(numero%2){
                  respuesta++;
     }
     return respuesta;
 }
 
 void truncar(int* platos,int* cantidadPlatos,int* minutos){
      (*minutos)++;
      int laMitad = mitad(platos[0]);
      platos[*cantidadPlatos] = platos[0] - laMitad;
      platos[0] = laMitad;
      (*cantidadPlatos)++;
      qsort(platos,*cantidadPlatos,sizeof(int),comparar);
 }
 
 void comer(int* platos,int* cantidadPlatos,int* minutos){
      (*minutos)++;
      int j,ultimo = 0;
      for(j=0;j<(*cantidadPlatos);j++){
           if(--platos[j]){
                           if(j!=ultimo){
                                         platos[ultimo] = platos[j];
                           }
                ultimo++;
           }
           else{
                *cantidadPlatos = j;
                return;
           }
      }
      (*cantidadPlatos) = ultimo;
 }
 
 int main(){
     FILE* entrada = fopen("entrada.in","r");
     FILE* salida = fopen("salida.txt","w");
     int casos,caso,cantidadPlatos,i,k,maximo,cantidadMaximos,segundoMaximo,minutos; 
     int platos[2000];
     
     fscanf(entrada,"%d\n",&casos);
     for(caso = 1;caso<=casos;caso++){
              fscanf(entrada,"%d\n",&cantidadPlatos);
              for(i=0;i<cantidadPlatos;i++){
                    fscanf(entrada,"%d",&platos[i]);
              }
              minutos = 0;
              qsort(platos,cantidadPlatos,sizeof(int),comparar);
              while(cantidadPlatos!=0){
                              calcularMaximos(platos,cantidadPlatos,&maximo,&cantidadMaximos,&segundoMaximo);
 
                              if(mitad(maximo) < segundoMaximo){
                                        if(cantidadMaximos<(maximo-mitad(maximo))){
                                                 for(k=0;k<cantidadMaximos;k++){
                                                     truncar(platos,&cantidadPlatos,&minutos);
                                                 }
                                        }
                                        else{
                                                  comer(platos,&cantidadPlatos,&minutos);
                                        }       
                              }
                              else{
                                        if(cantidadMaximos<(maximo-mitad(maximo))){
                                             for(k=0;k<cantidadMaximos;k++){
                                                     truncar(platos,&cantidadPlatos,&minutos);
                                             }
                                        }
                                        else{
                                             comer(platos,&cantidadPlatos,&minutos);
                                        }
                              }
              }
              fprintf(salida,"Case #%d: %d\n",caso,minutos);
     }
 
     fclose(salida);
     fclose(entrada);
     return 0;
 }

