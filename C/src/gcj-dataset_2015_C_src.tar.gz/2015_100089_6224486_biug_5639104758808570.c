#include <stdio.h>
 #include <string.h>
 int main()
 {
 	int ti, T, s_max, i, s, c, t;
 	char ss[1111];
 	scanf("%d", &T);
 	for (ti = 1; ti <= T; ++ti)
 	{
 		c = 0;
 		t = 0;
 		scanf("%d%s", &s_max, ss);
 		for (i = 0; i <= s_max; ++i)
 		{
 			s = ss[i] - '0';	
 			if (t < i)
 			{
 				c += (i - t);
 				t = i;
 			}
 			t += s;
 		}
 		printf("Case #%d: %d\n", ti, c);
 	}
 }

