#include <stdio.h>
 #include <string.h>
 
 int main() {
 	int i, j;
 	char tmp[2000];
 	int T, sMax;
 	char * audience;
 	char * endPtr;
 	int numClapping, numFriends;
 
 	FILE *fin;
 	FILE *fout;
 	fin = fopen("input.in", "r");
 	fout = fopen("output.txt", "w");
 	
 
 	fgets(tmp, 100, fin);
 	T = strtol(tmp, &endPtr, 10);
 	for(i=0; i<T; i++) {
 		fgets(tmp, 2000, fin);
 
 		sMax = strtol(tmp, &endPtr, 10);
 		audience = endPtr+1;
 		printf("smax: %d, audience: %s\n",sMax, audience);
 		numClapping = 0;
 		numFriends = 0;
 
 		for(j=0; j<sMax+1; j++) {
 			if(numClapping >= j) {
 				numClapping += audience[j] - '0';
 			} else if (audience[j] != '0'){
 				numFriends += j-numClapping;
 				numClapping += j-numClapping + (audience[j] - '0');
 			}
 		}
 
 		fprintf(fout, "Case #%d: %d\n", i+1, numFriends);
 
 	}
 
 	fclose(fin);
 	fclose(fout);
 }
