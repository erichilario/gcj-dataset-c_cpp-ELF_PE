#include<stdio.h>
 int main(){
 	int T,Smax,si[1010],sum,i,j,count,temp_count;
 	char sc[1010];
 	scanf("%d",&T);
 	for(i=1;i<=T;i++){
 		sum=0;count=0;
 		scanf("%d",&Smax);
         scanf("%s",sc);
 		for(j=0;j<=Smax;j++){
 		si[j]=sc[j]-'0';
 		}
 		for(j=0;j<=Smax;j++){
 			if(sum<j){
 				temp_count=j-sum;
 				count=count+temp_count;
 				sum=sum+temp_count+si[j];
 			}
 			else{
 				sum=sum+si[j];
 			}
 		}
 		printf("Case #%d: %d\n",i,count);
 	}
 }

