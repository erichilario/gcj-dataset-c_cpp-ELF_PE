#include <stdio.h>
 
 int solve(void)
 {
 	// 0 Richard wins
 	// 1 Gabriel wins
 	int X, R, C;
 	scanf("%d %d %d", &X, &R, &C);
 	if (X == 1)
 		return 1;
 	if (X > 6)
 		return 0;
 	if ((R*C) % X)
 		return 0;
 	if (X == 2)
 		return 1;
 	if (R == 1 || C == 1)
 		return 0;
 	if (X == 3)
 		return 1;
 	if (X == 6)
 	{
 		if (R < 5 || C < 5)
 			return 0;
 		return 1;
 	}
 	if (R < 3 || C < 3)
 		return 0;
 	return 1;
 }
 
 void print(int tCount, int result)
 {
 	if (result == 0)
 		printf("Case #%d: RICHARD\n", tCount);
 	else
 		printf("Case #%d: GABRIEL\n", tCount);
 }
 
 int main(void)
 {
 	int T, i;
 	scanf("%d", &T);
 	for (i=1; i<=T; i++)
 	{
 		print(i, solve());
 	}
 	return 0;
 }
