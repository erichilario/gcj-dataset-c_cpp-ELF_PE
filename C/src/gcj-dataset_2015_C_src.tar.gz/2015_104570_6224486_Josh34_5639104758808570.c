#include <stdio.h>
 
 int T, case1, smax, i, count, needed;
 char s[1001];
 
 int main(){
 	case1 = 1;
 	scanf("%d", &T);
 	while(T--){
 		scanf("%d %s", &smax, s);
 		count = 0;
 		needed = 0;
 		for(i = 0; i <= smax; i++){
 			if((s[i] - 48) && i > count){
 				needed += (i - count);
 				count += needed;
 			}
 			count += (s[i] - 48);
 		}
 		printf("Case #%d: %d\n", case1, needed);
 		case1++;
 	}
 	return 0;
 }
