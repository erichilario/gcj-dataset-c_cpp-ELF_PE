#include <stdio.h>
 #include <string.h>
 #include <math.h>
 #include <stdlib.h>
 
 int main() {
     long long int t,l;
     scanf("%lld",&t);
     for(l=1;l<=t;l++){
         long long int n,i,k=0,c=0;
         int j;
         scanf("%lld",&n);
         for(i=0;i<n;i++){
             scanf("%1d",&j);
             k=k+j;
             if(k<(i+1)){
                 c=c+i+1-k;
                 k=k+i+1-k;
             }
                 
         }
         scanf("%lld",&i);
         printf("Case #%lld: %lld\n",l,c);
     }
         return 0;
 }
  
 

