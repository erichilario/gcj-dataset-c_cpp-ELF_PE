#include <stdio.h>
 
 
 int main(void)
 {
     int t, T, n, i, sum, in, need;
 
     scanf("%d", &T);
     getchar();
 
     for (t = 1; t <= T; t++){
         scanf("%d", &n);
         getchar();
 
         sum = 0;
         need = 0;
 
         if (n > 0){
             for (i = 0; i <= n; i++){
                 in = getchar() - 48;
                 if (in > 0){
                     while (sum < i) {
                         sum++;
                         need++;
                     }
                     sum += in;
                 }
             }
         }
         getchar();
 
 
         printf("Case #%d: ", t);
         printf("%d\n", need);
     }
 
 
     return 0;
 }

