#include <stdio.h>
 
 int main()
 {
   int t, tt, i;
   int smax;
   int level;
   int friends;
   char audience[2000];
 
   scanf("%d", &t);
   tt = 0;
   while(tt < t)
   {
     printf("Case #%d: ", tt+1);
     scanf("%d", &smax);
     scanf("%s", audience);
     level = audience[0]-'0';
     friends = 0;
     for(i=1;i<=smax;i++)
     {
       if(level < i)
       {
         friends += i-level;
         level = i;
       }
       level += audience[i] - '0';
     }
     printf("%d\n", friends);
 
     tt++;
   }
 
   return 0;
 }

