#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <conio.h>
 #include <math.h>
 
 char* multiply(char a, char b)
 {
     if(a == '1' && b == '1')
         return "1";
     else if((a == '1' && b == 'i')||(a == 'j' && b == 'k')||(a == 'i' && b == '1'))
         return "i";
     else if((a == '1' && b == 'j')||(a == 'j' && b == '1')||(a == 'k' && b == 'i'))
         return "j";
     else if((a == '1' && b == 'k')||(a == 'i' && b == 'j')||(a == 'k' && b == '1'))
         return "k";
     else if((a == 'i' && b == 'i')||(a == 'j' && b == 'j')||(a == 'k' && b == 'k'))
         return "-1";
     else if(a == 'i' && b == 'k')
         return "-j";
     else if(a == 'j' && b == 'i')
         return "-k";
     else if(a == 'k' && b == 'j')
         return "-i";
     return 0;
 }
 
 
 int main()
 {
     FILE* Input = NULL;
     FILE* Output = NULL;
     Input = fopen("Input.txt","r");
     Output = fopen("Output.txt","w");
     int T,L;
     fscanf(Input,"%d",&T);
     int i,k;
     char* Chaine = NULL;
     char* InChaine = NULL;
     Chaine = (char*)malloc(20020*sizeof(char));
     InChaine = (char*)malloc(20020*sizeof(char));
     char* MultC = NULL;
     MultC = (char*)malloc(2*sizeof(char));
     int Negatif = 0;
     double Iteration = 0;
     double Length,X;
     int impaire = 0;
     double j;
     int Cursor;
 
 
 
 
     for(i=0;i<T;i++)
     {
         printf("\n--%d--",i+1);
         fscanf(Input,"%d",&L);
         fscanf(Input,"%lf",&X);
         fgetc(Input);
         fgets(InChaine,L+1,Input);
         if(i == 9)
         {
             printf(" %s",InChaine);
         }
         printf("\n%d  %.0lf",L,X);
         Length = X*L;
         Iteration = 1;
         impaire = 0;
         //free(Chaine);
         Chaine = (char*)malloc(20020*sizeof(char));
 
         Negatif = 0;
         Cursor = 0;
 
         if(strlen(InChaine) == 2 && X > 1)
         {
             if(fmod(X,2) == 0)
             {
                 X/= 2;
                 strcat(InChaine,InChaine);
             }
             else
             {
                 X = (X-1)/2;
                 strcat(InChaine,InChaine);
                 impaire = 1;
             }
         }
         strcpy(Chaine,InChaine);
         if(strlen(InChaine)<3)
         {
             fprintf(Output,"Case #%d: NO\n",i+1);
         }
         else if(strlen(InChaine) == 3 && X == 1)
         {
             if(strcmp(InChaine,"ijk") == 0)
             {
                 fprintf(Output,"Case #%d: YES\n",i+1);
             }
             else
             {
                 fprintf(Output,"Case #%d: NO\n",i+1);
             }
         }
         else
         {
             Iteration = 1;
             if(impaire == 1)
             {
                 strcat(Chaine,InChaine);
                 impaire =0;
             }
             Negatif = 0;
 
             for(j=0;j<Length-1;j++)
             {
                 if(Chaine[Cursor] == 'i' && Cursor == 0)
                 {
                     j++;
                     Cursor++;
                 }
                 if(Chaine[Cursor] == 'j' && Cursor == 1)
                 {
                     j++;
                     Cursor++;
                 }
                 MultC = multiply(Chaine[Cursor],Chaine[Cursor+1]);
                 if(MultC[0] == '-')
                 {
                     Negatif = (Negatif+1)%2;
                     Chaine[Cursor+1] = MultC[1];
                 }
                 else
                 {
                     Chaine[Cursor+1] = MultC[0];
                 }
                 for(k=Cursor;k>0;k--)
                 {
                     Chaine[k] = Chaine[k-1];
                 }
                 Chaine = Chaine+1;
                 if(strlen(Chaine)<4 && Iteration < X)
                 {
                     Iteration++;
                     strcat(Chaine,InChaine);
                 }
                 if(Chaine[Cursor] == 'i' && Cursor == 0)
                 {
                     j++;
                     Cursor++;
                 }
                 if(Chaine[Cursor] == 'j' && Cursor == 1)
                 {
                     j++;
                     Cursor++;
                 }
             }
             if(strlen(Chaine)<3 || (strlen(Chaine) == 3 && Chaine[2] != 'k'))
             {
                 fprintf(Output,"Case #%d: NO\n",i+1);
             }
             else if(Negatif == 0)
             {
                 fprintf(Output,"Case #%d: YES\n",i+1);
             }
             else if(Negatif == 1)
             {
                 fprintf(Output,"Case #%d: NO\n",i+1);
             }
         }
     }
     printf("\n\nDone !");
     getch();
     return 0;
 }

