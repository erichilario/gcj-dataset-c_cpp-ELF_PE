#include <stdio.h>
 #include <stdlib.h>
 
 int cmp(void* a, void* b) {
   return *(int*)a - *(int*)b;
 }
 
 int main() {
   int t,c,m,i,r,d;
   char s[1005];
   scanf("%d", &t);
   for (c = 1; c <= t; c++) {
     scanf("%d%s", &m, s);
     r = 0;
     d = 0;
     for (i = 0; i <= m; i++) {
       s[i] -= '0';
       if (i > d) {
 	r += i - d;
 	d = i + s[i];
       }
       else {
 	d += s[i];
       }
     }
     printf("Case #%d: %d\n", c, r);
   }
   return 0;
 }

