#include<stdio.h>
 int main()
 {
 	int T,i;
 	scanf("%d",&T);
 	for(i=1;i<=T;i++)
 	{
 		int X,R,C,Prod;
 		scanf("%d",&X);
 		scanf("%d",&R);
 		scanf("%d",&C);
 		Prod = R*C;
 		if(X==1)
 			printf("Case #%d: GABRIEL\n",i);
 		if(X==2)
 		{
 			if(Prod%X == 0)
 				printf("Case #%d: GABRIEL\n",i);
 			else
 				printf("Case #%d: RICHARD\n",i);
 		}
 		if(X==3)
 		{
 			if(Prod%X == 0 && Prod > 3)
 				printf("Case #%d: GABRIEL\n",i);
 			else
 				printf("Case #%d: RICHARD\n",i);
 		}
 		if(X==4)
 		{
 			if(Prod==16 || Prod == 12)
 				printf("Case #%d: GABRIEL\n",i);
 			else
 				printf("Case #%d: RICHARD\n",i);
 		}
 	}
 	return 0;
 }
 

