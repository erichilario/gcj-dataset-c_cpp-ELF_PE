#include<stdio.h>
 #define max(a,b) a>b?a:b
 int main()
 {
     int test,array[1002],pro,num,j,i,maxx,left,k;
     scanf("%d",&test);
     for(k=1;k<=test;k++)
     {
         scanf("%d",&num);
         for(i=0;i<num;i++)
            scanf("%d",&array[i]);
 		maxx=array[0];
         for(i=1;i<num;i++)
 			maxx=max(maxx,array[i]);
         left=maxx; 
         for(i=1;i<=maxx;i++)
         {
             pro=i;
             for(j=0;j<num;j++)
             {
                 if( array[j]>i && array[j]%i==0)
                    pro+=array[j]/i-1;
                 else if(array[j]>i)
                    pro+=array[j]/i;         
             }
             if( left>pro)
               left=pro;   
         }
         printf("Case #%d: %d\n",k,left);
     }                                 
     return 0;
 }

