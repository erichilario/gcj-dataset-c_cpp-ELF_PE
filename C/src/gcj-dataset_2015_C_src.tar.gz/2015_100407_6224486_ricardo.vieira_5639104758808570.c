#include <stdio.h>
 
 int main(int argc, char const *argv[])
 {
 	int cases, i, smax, friends = 0, si, standing, k;
 	char audience[1001];
 
 	scanf("%d\n", &cases);
 
 	for (i = 0; i < cases; ++i)
 	{
 		standing = 0;
 		friends = 0;
 		scanf("%d %s\n", &smax, audience);
 		for (k = 0; k <= smax; ++k)
 		{
 			if (k > standing){
 				friends += k - standing;
 				standing += k - standing;
 			}
 			standing += audience[k] - '0';
 		}
 		printf("Case #%d: %d\n", i+1, friends);
 	}
 	return 0;
 }
