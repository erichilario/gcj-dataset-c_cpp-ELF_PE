#include<stdio.h>
 #include<string.h>
 #include<math.h>
 
 int resolverProblema(int* quecas, int n){
   int max=0, aMax=0, i, j, m1=1000, m2=1000, valor;
   int q1[n+1], q2[n];
   memset(q1, 0, sizeof q1);
   memset(q2, 0, sizeof q2);
   for(i=0; i<n; i++)
     if(quecas[i]>max){
       max=quecas[i];
       aMax=i;
     }
   if(max==0)
     return 0;
   else{
     for(i=0; i<n; i++){
       q1[i]=quecas[i];
       q2[i]=quecas[i];
       if(q2[i]>0)
 	q2[i]--;
     }
     if(max>2){
       valor=floor(quecas[aMax]/2);
       q1[aMax]=valor;
       q1[n]=quecas[aMax]-valor;
       m1=resolverProblema(q1, n+1)+1;
     }
     m2=resolverProblema(q2, n)+1;
     if(m1<m2)
       return m1;
     else
       return m2;
   }
 }
 
 int main(void){
   int T, i, j, quecas[6], D, m;
   scanf("%d", &T);
   for(i=1; i<=T; i++){
     scanf("%d", &D);
     for(j=0; j<D; j++)
       scanf("%d", &quecas[j]);
     m=resolverProblema(quecas, D);
     printf("Case #%d: %d\n", i, m);
   }
 }

