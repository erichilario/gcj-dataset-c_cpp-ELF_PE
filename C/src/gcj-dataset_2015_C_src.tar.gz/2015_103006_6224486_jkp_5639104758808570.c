#include <stdio.h>
 #define DEF
 
 int main (void){
 	#ifdef DEF
 	freopen("A-large.in", "r", stdin);
 	#endif
 	
 	#ifdef DEF
 	freopen("A-large.out", "w", stdout);
 	#endif
 	
 	int t,i,s,j,ak,add,sum;
 	char ch;
 	
 	scanf("%d",&t);
 	for (i = 0; i < t; i++){
 		add = 0;
 		sum = 0;
 		
 		scanf("%d", &s);
 		scanf("%c",&ch);
 		for (j = 0; j <= s; j++){
 			scanf("%c",&ch);
 			ak = ch - 48;
 			
 			if (sum == j && ak == 0){
 				sum++;
 				add++;
 			}
 			
 			sum += ak;
 		}
 		printf("Case #%d: %d\n",i+1,add);
 	}
 	
 	
 	return 0;
 }

