#include<stdio.h>
 #include<stdlib.h>
 typedef struct
 {
 	int sig;
 	int val;
 }Ele;
 Ele op[10][10];
 char a[10010];
 int b[10010];
 int c[10010][2][5];
 int main(void)
 {
 	int i,j,p,n,m,pi,qi,sum,si,top,tsum,OK;
 	freopen("C-small-attempt0.in","r",stdin);
 	freopen("C-small-attempt0.out","w",stdout);
 	for(i=1;i<=4;i++)
 	{
 		op[i][1].sig=op[1][i].sig=1;
 		op[i][1].val=op[1][i].val=i;
 	}
 	for(i=2;i<=4;i++)
 	{
 		op[i][i].sig=-1;
 		op[i][i].val=1;
 	}
 	op[2][3].sig=1;
 	op[3][2].sig=-1;
 	op[2][3].val=op[3][2].val=4;
 	op[2][4].sig=-1;
 	op[4][2].sig=1;
 	op[2][4].val=op[4][2].val=3;
 	op[3][4].sig=1;
 	op[4][3].sig=-1;
 	op[3][4].val=op[4][3].val=2;
 	scanf("%d",&pi);
 	for(qi=1;qi<=pi;qi++)
 	{
 		scanf("%d%d%s",&n,&m,a+1);
 		top=0;
 		sum=1;
 		si=1;
 		for(i=1;i<=m;i++)
 		{
 			for(j=1;j<=n;j++)
 			{
 				top++;
 				if(a[j]=='i')
 				{
 					b[top]=2;
 				}
 				else if(a[j]=='j')
 				{
 					b[top]=3;
 				}
 				else
 				{
 					b[top]=4;
 				}
 				tsum=op[sum][b[top]].val;
 				si=si*op[sum][b[top]].sig;
 				sum=tsum;
 			}
 		}
 		if((sum!=1)||(si!=-1))
 		{
 			printf("Case #%d: NO\n",qi);
 		}
 		else
 		{
 			p=m*n;
 			c[p][1][b[p]]=qi;
 			sum=b[p];
 			si=1;
 			for(i=p-1;i>=1;i--)
 			{
 				for(j=1;j<=4;j++)
 				{
 					c[i][0][j]=c[i+1][0][j];
 					c[i][1][j]=c[i+1][1][j];
 				}
 				tsum=op[b[i]][sum].val;
 				si=si*op[b[i]][sum].sig;
 				sum=tsum;
 				if(si==1)
 				{
 					c[i][1][sum]=qi;
 				}
 				else
 				{
 					c[i][0][sum]=qi;
 				}
 			}
 			si=1;
 			sum=1;
 			OK=0;
 			for(i=1;i<=p;i++)
 			{
 				tsum=op[sum][b[i]].val;
 				si=si*op[sum][b[i]].sig;
 				sum=tsum;
 				if((sum==2)&&(si==1))
 				{
 					if((i+2<=p)&&(c[i+2][1][4]==qi))
 					{
 						OK=1;
 						break;
 					}
 				}
 			}
 			printf("Case #%d: %s\n",qi,OK==1?"YES":"NO");
 		}
 	}
 	return 0;
 }
