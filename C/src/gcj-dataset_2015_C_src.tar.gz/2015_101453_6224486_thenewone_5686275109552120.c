#include<stdio.h>
 int main(){
 	int T,t,d,i,k,j,mtime,time;
 	scanf("%d",&T);
 	for(t=1;t<=T;t++){
 		scanf("%d",&d);
 		int p[1002]={0};
 		time=0;
 		mtime=0;
 		for(i=0;i<d;i++){
 			scanf("%d",&k);
 			p[k]++;
 			if( mtime < k ) 
 				mtime=k;
 		}
 		for(i=mtime;i>0;i--){
 			if( p[i] == 0 )
 				continue;			
 			mtime = i;
 			if( i > p[i] + i/2 + i%2 )
 			{
 				p[i/2] += p[i];
 				p[i/2 + i%2] += p[i];
 				time+=p[i];
 			}
 			else
 				break;
 		}
 		printf("Case #%d: %d\n",t,mtime+time);
 	}
 	return 0;
 }
 
 
 
 

