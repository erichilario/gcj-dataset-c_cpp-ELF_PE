#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 int main(int argc, char **argv)
 {
 	FILE *fp = NULL;
 	char line[256];
 	int num_testcases, linenum = 0;
 	int s_max;
 	int *result = NULL;
 	
 	/*
 	if(argc != 2)
 	{	
 		printf("Error: Not enough number of arguments !\n");
 		return 1;
 	}
 	*/
 
 	fp = stdin;
 
 	if (!fp)
 	{
 		printf("Error: No such file exists !\n");
 		return 1;
 	}
 
 	if(fgets(line, sizeof(line), fp))
 	{
 		sscanf(line, "%d", &num_testcases);
 		//printf("No. of Test Cases: %d\n", num_testcases);
 			
 		result = calloc(num_testcases, sizeof(int));
 	}
 	else
 	{
 		printf("Error: Number of test cases not mentioned in 1st line of input file !\n");
 		return 1;
 	}
 
 	//process each test case line
 	for(linenum = 1; linenum <= num_testcases; linenum++)
 	{
 		int s_level = 0;
 		int *s_level_people = NULL;
 		char str_s_max[5];
 		int standing = 0;
 
 
 		if(fgets(line, sizeof(line), fp))
 		{
 			sscanf(line, "%d", &s_max);
 			//printf("s_max: %d\n", s_max);
 			
 			snprintf(str_s_max, sizeof(str_s_max), "%d", s_max);
 			//printf("len of str_s_max: %ld\n", strlen(str_s_max));
 
 			s_level_people = malloc(sizeof(int)*s_max+1);
 		
 			//Read number of people in each shyness level
 			for(s_level = 0; s_level <= s_max; s_level++)
 			{
 				if( (line[strlen(str_s_max)+1+s_level] - '0') < 0 || (line[strlen(str_s_max)+1+s_level] - '0') > 9 )
 				{
 					break;
 				}
 				else
 				{
 					//sscanf(line+strlen(str_s_max), "%d", &s_level_arr[s_level]);
 					s_level_people[s_level] = line[strlen(str_s_max)+1+s_level] - '0';
 					//printf("People with Shyness level: %d = %d\n", s_level, s_level_people[s_level]);
 	
 					//If shyness level != 0 & There is somebody with that shyness level,
 					//& number standing is less than this shyness level...
 					//Then add difference between standing and s_level to result for this
 					//line and also increment standing by this difference and the number of people
 					//already in this shyness level. 
 					if (s_level !=0 && s_level_people[s_level] != 0 && standing < s_level)
 					{
 						//printf("linenum: %d, s_level: %d, Standing: %d\n", linenum, s_level, standing);				
 						result[linenum] += (s_level - standing);
 						standing += s_level - standing;
 					}
 					
 					standing += s_level_people[s_level];			
 				}
 			}
 
 		}
 		else
 		{
 			printf("Error: Number of test cases not matching with what is given in first line: %d !\n", num_testcases);
 			return 1;
 		}
 	
 	}
 
 	for(linenum = 1; linenum <= num_testcases; linenum++)
 	{
 		printf("Case #%d: %d\n", linenum, result[linenum]);
 	}	
 	
 	fclose(fp);
 	return 0;
 }

