#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <strings.h>
 
 int main()
 {
     int L,D,N;
     char** words = NULL;
     char** charlist = NULL;
     char string[500];
     int* counter;
     int i,j,k,l;
     while (scanf("%d %d %d",&L,&D,&N)==3){
 	
 	/* gettin the D words */
 	words = calloc(D,sizeof(char*));
 	counter = calloc(D,sizeof(int));
 	
 	for ( i = 0 ; i < N ; i++)
 		counter[i] = 0;
 
 	for (i = 0 ; i < D ; i++) {
 		words[i] = calloc(L+1,sizeof(char));
 		scanf("%s",words[i]);
 	}
 	
 	charlist = calloc(L,sizeof(char*));
 	for (i = 0 ; i < L; i++){
 		charlist[i] = malloc(27); 
         memset((void*)charlist[i], '\0' , 27);  
 	}
 
 	
 	for (i = 0 ; i < N ; i++){
 		scanf("%s",&string);		
 	j=0;
 	for (l = 0 ; l < strlen(string); l++) {
 	if (string[l] == '('){
 		++l;
 		while(string[l] != ')'){
 			strncat(charlist[j],&string[l],1);
 			++l;
 		}
 	}
 	else
 		strncat(charlist[j],&string[l],1);
 	j++;
 	}
 
 	/*begin processing */
 	for (k = 0 ; k < D ; k++ ) {
 		for (j = 0 ; j < L ; j++){
 			if (index(charlist[j],*(words[k]+j)) == NULL)
 				break;
 			if (j == (L-1))
 				counter[i] = counter[i] + 1; 
 		}
 	}
 	
 	for (j = 0 ; j < L; j++)
 	        memset((void*)charlist[j], '\0' , 27);
 
 	}
 
 
 	for (k = 0 ; k < N ; k++ ) 
 		printf("Case #%d: %d\n",(k+1),counter[k]); 
 	
 	fflush(NULL);
 	/* cleaning */
 	for (i = 0 ; i < D ; i++) 
                free(words[i]);
 	free(words);
 	for (j = 0 ; j < L; j++)
 	        free(charlist[j]);
 	free(counter);
 	free(charlist);
     }
  
     return 0;
 }

