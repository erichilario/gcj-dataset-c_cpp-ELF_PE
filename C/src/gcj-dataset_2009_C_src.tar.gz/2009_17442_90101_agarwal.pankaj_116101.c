#include<stdio.h>
 int main()
 {
 	int cnt,l,d,n,i,j,k,ck,t;
 	char p[2000],s[5050][60];
 	
 	freopen("A-small-attempt0.in","r",stdin);
 	freopen("out.txt","w",stdout);
 	scanf("%d%d%d",&l,&d,&n);
 	for(i=1;i<=d;i++)
 	scanf("%s",&s[i]);
 	
 	for(i=1;i<=n;i++)
 	{
 		scanf("%s",p);
 		
 		cnt=0;
 		for(j=1;j<=d;j++)
 		{
 			k=0;
 			t=0;	
 			while(s[j][k]!='\0')
 			{
 				ck=0;
 				
 					if(s[j][k]==p[t] && p[t]!='\0')
 					{
 						t++;
 						k++;
 						ck=1;
 					}
 					else
 					{
 						if(p[t]=='(')
 						{
 							t++;
 							while(p[t]!=')')
 							{
 								if(p[t]==s[j][k] && ck==0)
 								{
 									k++;
 									ck=1;
 								}
 								t++;
 							}
 							t++;
 						}
 					}
 					
 					if(ck==0)
 					break;
 			}
 			if(ck==1)
 			cnt++;
 		}
 		
 		printf("Case #%d: %d\n",i,cnt);
 	}
 	
 return 0;
 }

