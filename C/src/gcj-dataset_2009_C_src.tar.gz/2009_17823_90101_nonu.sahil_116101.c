//remove all b tree related data
 //simply convert fin to fscanf
 //syntax is like cin to scanf same
 //new to malloc
 //change variable names
 //thats enough
 #include<stdio.h>
 #include<conio.h>
 #include<malloc.h>
 #include<string.h>
 
 int gf=0,len,num,i1,istar;
 char *str1,*str2;
 char **st;
 int *ar,top;
 int** ar1;
 
 void call1(int);
 int main()
 {
 	int L,N,D,ff,t;
     int zz=0,mm=20;
 	int n,i,j,k;
 	char **s;
 	char *str;
     FILE *fp,*fp2;
     fp=fopen("A-small-attempt1.in","r");
     fp2=fopen("output.txt","w");
 	//ifstream fin("A-large.in");
 	//ofstream fout("output.txt");
 	str=(char*)malloc(100);
 
 
 	//root1=(struct node*)malloc(sizeof(struct node)*1);
     fscanf(fp,"%d%d%d",&L,&D,&N);
 	//fin>>L>>D>>N;
 //	scanf("%d",&n);
 
 	str=(char*)malloc(sizeof(char)*20);
 	s=(char**)malloc(sizeof(char*)*D);
 	for(i=0;i<D;i++)
 	{
 	  	fscanf(fp,"%s",str);
 		 //fin>>str;
 		s[i]=(char*)malloc((sizeof(char))*(strlen(str)+1));
 		strcpy(s[i],str);
 	}
 	// root1=binary_search_tree(s,D);
 //	ar1=new int*[L];
 	ar1=(int**)malloc(sizeof(int*)*L);
     for(i=0;i<L;i++)
 		ar1[i]=(int*)malloc(sizeof(int)*26);
 	i1=1;
     for(zz=0;zz<mm;zz++)
     {
                         }
 	free(str);
 	 str1=(char*)malloc(600);
 	 str2=(char*)malloc(20);
 	 
 	 st=(char**)malloc(2*30);
 	 ar=(int*)malloc(70);
 	 for(i=0;i<30;i++)	st[i]=(char*)malloc(30);
 
 	while(i1<=N)
 	{
 		fscanf(fp,"%s",str1);
         //fin>>str1;
 		top=-1;ff=0;
 		len=strlen(str1);
 		for(i=0,j=0;i<len;i++)
 		{
 			if(ff==0)
 			{
 				if(str1[i]!='(')
 				{
 
 					str2[j]=str1[i];
 				}
 				else
 				{
 					ff=1;t=-1;top++;ar[top]=j;str2[j]='-';
 					for(k=0;k<26;k++)
 						ar1[j][k]=0;
 				}
 				j++;
 			}
 			else
 			{
 				if(str1[i]!=')')
 				{
 					st[top][++t]=str1[i];
 					ar1[j-1][str1[i]-97]=1;
 				}
 				else
 				{
 					st[top][++t]='\0';
 					ff=0;
 				}
 			}
 		 }
 		 str2[j]='\0';
 		 for(i=0,num=0;i<D;i++)
 		 {
 			 for(j=0;j<L;j++)
 			 {
 				 if(s[i][j]==str2[j])
 					 continue;
 				 else if(str2[j]=='-')
 				 {
 					 if(ar1[j][ s[i][j]-97]==0)
 						 break;
 				 }
 				 else
 					 break;			
 			 }
 			 if(j==L)	num++;
 		 }
 		 //fout<<"Case #"<<i1<<": "<<num<<endl;
 		 fprintf(fp2,"Case #%d: ",i1);
 		 fprintf(fp2,"%d\n",num);
          i1++;
 	}
    //fin.close();
     //fout.close();
     return 0;
 }
 
 
 
 

