#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 
 void getWeight(char* str,char ch1,char ch2, long prevWt[], long currWt[]);
 
 int main(){
 
     FILE* fp;
 
     long N;
 
 
 
     fp = fopen("C-small-attempt0.in","r");
 
     if( fp == NULL){
         printf("could not open file");
     }
 
     char* s = NULL;
     while(1){
 
         char c = fgetc(fp);
 
         if(c == '\n'){
             N = atol(s);
             break;
         }
         if(s == NULL){
             s = (char*)malloc(1);
             s[0] = c;
             s[1] = '\0';
         }
         else{
             long len = strlen(s);
             char* temp = (char*)malloc(len+1);
             strcpy(temp,s);
             temp[len] = c;
             temp[len+1] = '\0';
 
             s = temp;
         }
     }
 
     s = NULL;
     char* testCases[N];
 
     long n = 0;
     char c;
     while(1){
          c = fgetc(fp);
          if(c == EOF){
              testCases[n] = s;
              s = NULL;
              break;
          }
          else if(c == '\n'){
              testCases[n] = s;
              s = NULL;
              n++;
              continue;
          }
          else if(c == ' '){
              c = '*';
          }
 
          if(s == NULL){
             s = (char*)malloc(1);
             s[0] = c;
             s[1] = '\0';
         }
         else{
             char* temp;
             long len = strlen(s);
             temp = (char*)malloc(len+2);
             strcpy(temp,s);
             temp[len] = c;
 
             temp[len+1] = '\0';
             s = temp;
         }
 
     }
 
 
     int output[N];
 
     for(int i = 0; i < N; i++){
         char* str = testCases[i];
 
         int len = strlen(str);
 
         long prevIndex;
         long currIndex;
         long weight;
         long prevWt[len];
         long currWt[len];
 
 
 
         weight = 0;
         prevIndex = 0;
         currIndex = 0;
 
         for(int k = 0; k < len; k++){
             char ch = str[k];
             switch(ch){
                 case 'w':
                     prevWt[prevIndex] = 1;
                     weight += prevWt[prevIndex];
                     prevIndex++;
                 break;
                 case 'e':
                     currWt[currIndex] = weight;
                     currIndex++;
                 break;
             }
         }
 
         for(int k = 0; k < currIndex; k++){
             prevWt[k] = currWt[k];
         }
 
 
         getWeight(str,'e','l',prevWt,currWt);
         getWeight(str,'l','c',prevWt,currWt);
         getWeight(str,'c','o',prevWt,currWt);
         getWeight(str,'o','m',prevWt,currWt);
         getWeight(str,'m','e',prevWt,currWt);
         getWeight(str,'e','*',prevWt,currWt);
         getWeight(str,'*','t',prevWt,currWt);
         getWeight(str,'t','o',prevWt,currWt);
         getWeight(str,'o','*',prevWt,currWt);
         getWeight(str,'*','c',prevWt,currWt);
         getWeight(str,'c','o',prevWt,currWt);
         getWeight(str,'o','d',prevWt,currWt);
         getWeight(str,'d','e',prevWt,currWt);
         getWeight(str,'e','*',prevWt,currWt);
         getWeight(str,'*','j',prevWt,currWt);
         getWeight(str,'j','a',prevWt,currWt);
         getWeight(str,'a','m',prevWt,currWt);
 
 
         weight = 0;
         prevIndex = 0;
 
         for(int k = 0; k < len; k++){
             char ch = str[k];
             switch(ch){
                 case 'm':
                     weight += prevWt[prevIndex];
                     prevIndex++;
                 break;
             }
         }
         if(weight > 9999){
             weight = weight%10000;
         }
         output[i] = weight;
     }
 
     fp = fopen("C-small.out","w");
     if(fp == NULL){
         printf("could not open file");
     }
 
 
 
     for( long n1 = 0; n1 < N; n1++){
 
 
         char answer[] = "0000";
         char s1[5];
         itoa(output[n1],s1,10);
 
         if(output[n1] <10){
             answer[3] = s1[0];
         }
         else if(output[n1] <100){
             answer[2] = s1[0];
             answer[3] = s1[1];
         }
         else if(output[n1] <1000){
             answer[1] = s1[0];
             answer[2] = s1[1];
             answer[3] = s1[2];
         }
         else{
             answer[0] = s1[0];
             answer[1] = s1[1];
             answer[2] = s1[2];
             answer[3] = s1[3];
         }
 
         fprintf(fp,"Case #%d: %s \n",n1+1,answer);
     }
     fclose(fp);
 
     return 0;
 }
 
 void getWeight(char* str,char ch1,char ch2, long prevWt[], long currWt[]){
 
     long prevIndex;
     long currIndex;
     long weight;
 
     int len = strlen(str);
 
     weight = 0;
     prevIndex = 0;
     currIndex = 0;
 
     for(int k = 0; k < len; k++){
         char ch = str[k];
         if(ch == ch1){
             weight += prevWt[prevIndex];
             prevIndex++;
 
             if(weight > 9999){
                 weight = weight%10000;
             }
         }
         else if(ch == ch2){
             currWt[currIndex] = weight;
             currIndex++;
         }
     }
 
      for(int k = 0; k < currIndex; k++){
          prevWt[k] = currWt[k];
      }
 }

