#include <stdio.h>
 
 int main(void)
 {
 	char drain_map[100][100],label,flag;
 	int i,j,k,l,r,c,m,r_index,c_index,path_index,min,map_altitudes[100][100],path[10000],H,W,T;
 	FILE *fp,*wp;
 	fp = fopen("B-large.txt","r");
 	wp = fopen("B-large.out","w");
 	fscanf(fp,"%d",&T);
 	for(i=0;i<T;++i)
 	{
 		fscanf(fp,"%d %d",&H,&W);
 		for(r=0;r<H;++r)
 			for(c=0;c<W;++c)
 				fscanf(fp,"%d",&map_altitudes[r][c]);
 		for(r=0;r<H;++r)
 			for(c=0;c<W;++c)
 				drain_map[r][c] = 0;
 		label = 97;
 		drain_map[0][0] = label;
 		r = 0;c=0;
 		min = map_altitudes[0][0];
 		r_index = r; 
 		c_index = c;
 		while(r<H && r>=0 && c<W && c>=0)
 		{
 			if((r-1)>=0)
 			{
 				if(map_altitudes[r-1][c] < min)
 				{
 					r_index = r-1; c_index = c;
 					min = map_altitudes[r_index][c_index];	
 				}
 			}
 			if((c-1) >= 0)
 			{
 				if(map_altitudes[r][c-1] < min)
 				{
 					r_index = r; c_index = c-1;
 					min = map_altitudes[r_index][c_index];	
 				}
 			}
 			if((c+1) < W)
 			{
 				if(map_altitudes[r][c+1] < min)
 				{
 					r_index = r; c_index = c+1;
 					min = map_altitudes[r_index][c_index];	
 				}
 			}
 			if((r+1)< H)
 			{
 				if(map_altitudes[r+1][c] < min)
 				{
 					r_index = r+1; c_index = c;
 					min = map_altitudes[r_index][c_index];	
 				}
 			}
 			if(r==r_index && c==c_index)
 				break;
 			drain_map[r_index][c_index] = label;
 			r = r_index; 
 			c = c_index;	
 		}
 		for(k=0;k<H;++k)
 			for(l=0;l<W;++l)
 			{
 				
 				flag = 0;
 				path_index = 0;
 				if(!drain_map[k][l])
 				{
 					min = map_altitudes[k][l];
 					r_index = r=k; 
 					c_index = c=l;
 					path[path_index] = r_index*W + c_index;
 					while(1)
 					{
 						if((r-1)>=0)
 						{
 							if(map_altitudes[r-1][c] < min)
 							{
 								r_index = r-1; c_index = c;
 								min = map_altitudes[r_index][c_index];	
 							}
 						}
 						if((c-1) >= 0)
 						{
 							if(map_altitudes[r][c-1] < min)
 							{
 								r_index = r; c_index = c-1;
 								min = map_altitudes[r_index][c_index];	
 							}
 						}
 						if((c+1) < W)
 						{
 							if(map_altitudes[r][c+1] < min)
 							{
 								r_index = r; c_index = c+1;
 								min = map_altitudes[r_index][c_index];	
 							}
 						}
 						if((r+1)< H)
 						{
 							if(map_altitudes[r+1][c] < min)
 							{
 								r_index = r+1; c_index = c;
 								min = map_altitudes[r_index][c_index];	
 							}
 						}
 						
 						if(r==r_index && c==c_index)
 						{
 							break;
 						}
 						r = r_index; 
 						c = c_index;
 						
 						path[++path_index] = r_index*W + c_index;
 						
 						if(drain_map[r][c])
 						{
 							flag = 1;
 							break;
 						}
 					}
 					if(flag)
 					{
 						for(m=0;m<=path_index;++m)
 						{
 							r = path[m]/W;
 							c = path[m]%W;
 							drain_map[r][c] = drain_map[r_index][c_index];
 							
 						}
 					}
 					else
 					{
 						++label;
 						for(m=0;m<=path_index;++m)
 						{
 							r = path[m]/W;
 							c = path[m]%W;
 							drain_map[r][c] = label;
 						
 						}	
 					}
 				}
 		}
 		fprintf(wp,"Case #%d:\n",i+1);
 		for(k=0;k<H;++k)
 		{
 			for(l=0;l<W;++l)
 			{
 				fprintf(wp,"%c ",drain_map[k][l]);
 			}
 			fprintf(wp,"%c\n",' ');
 		}
 	}
 	fclose(fp);
 	fclose(wp);
 	return 0;
 }

