#include<stdio.h>
 
 char goal[20] = "welcome to code jam";
 char line[1000];
 
 int dp[1000][20];
 
 int main() {
 	int t,T,l,i,j;
 	scanf("%d\n",&T);
 	for(t=1;t<=T;t++) {
 		l=0;
 		while(1) {
 			scanf("%c",line+l);
 			if(line[l]=='\n') break;
 			l++;
 		}
 		line[l] = 0;
 		dp[0][0]=1;
 		for(i=1;i<=l;i++) {
 			for(j=0;j<20;j++) {
 				dp[i][j] = dp[i-1][j];
 				if(i>0 && j>0 && line[i-1]==goal[j-1]) dp[i][j] += dp[i-1][j-1];
 				dp[i][j]%=10000;
 			}
 		}
 		printf("Case #%d: %04d\n",t,dp[l][19]);
 	}
 	return 0;
 }

