#include "stdio.h"
 #include "stdlib.h"
 
 static int **input;
 static int **output;
 static int NbMaps;
 static int Width,Height;
 static int OutputCount = 97;
 static FILE *fin,*fout;
 
 #define MAX_ALTITUDE 30000
 
 void AcquireInputs ();
 void PrintOutput (int casenum);
 void CheckInputnAssign (int i, int j);
 void InitialSetup();
 int CheckHighAssign(int i , int j,int HighNeighbour);
 
 int main ()
 {
   int LoopCounter = 1;
   int i,j;
   char Count[10];
 
   fin = fopen("B-small-attempt4.in", "rb");
   fout = fopen("B-small-attempt4.out","wb");
 
   fgets(Count , 10, fin);
 
   NbMaps = atoi(Count);
 
   while(LoopCounter <= NbMaps)
   {
     OutputCount = 97;
     AcquireInputs();
     InitialSetup();
     for(i =0; i< Height; i++)
     {
       for (j = 0; j< Width ; j++)
       {
         CheckInputnAssign(i,j);
       }
     }
 
     PrintOutput(LoopCounter);
     LoopCounter++;
     free(input);
     free(output);
   }
   fclose(fin);
   fclose(fout);
 }
 
 void AcquireInputs ()
 {
   char LINE[101];
   char* Substr[1];
   int i,j;
 
   fgets(LINE , 100, fin);
   Substr[0] = strtok(LINE," ");
   Height = atoi(Substr[0]);
   Substr[0] = strtok(NULL," ");
   Width = atoi(Substr[0]);
 
   input = (int **) malloc (Height * sizeof(int **));
   for (i = 0 ; i< Height; i++)
     input[i] = (int*) malloc (Width * sizeof(int*));
 
   output = (int **) malloc (Height * sizeof(int **));
   for (i = 0 ; i< Height; i++)
     output[i] = (int*) malloc (Width * sizeof(int*));
 
   for (i = 0 ; i< Height; i++)
   {
     for (j = 0 ; j< Width; j++)
       output[i][j] = '\0';
   }
 
   for (i = 0 ; i< Height; i++)
   {
     fgets(LINE , 100, fin);
     Substr[0] = strtok(LINE," ");
     for (j = 0 ; j< Width; j++)
     {
       input[i][j] = atoi(Substr[0]);
       Substr[0] = strtok(NULL," ");
     }
   }
 }
 
 void PrintOutput (int casenum)
 {
   int i,j;
   fprintf(fout,"Case #%d:\n",casenum);
   for (i = 0; i <Height ; i ++)
   {
     for (j=0 ; j<Width ; j++)
     {
       fprintf(fout,"%c ",output[i][j]);
     }
     fprintf(fout,"\n");
   }
 }
 
 void CheckInputnAssign (int i, int j)
 {
   int InCellValue ;
   long int LeastNeighbour = MAX_ALTITUDE;
   long int HighNeighbour = -1;
   int Assigned = 0;
   int isHigh = 1;
   int bFillMe = 0;
   int fillrow,fillcolm;
 
   if(i!=0)
     InCellValue = input[i-1][j];
   else
   {
     if(j!=0)
       InCellValue = input[i][j-1];
     else
       InCellValue = input[i][j];
   }
 
   if ((i != 0) && (input[i-1][j] <= InCellValue) && (input[i-1][j] < LeastNeighbour))
   {
     LeastNeighbour = input[i-1][j];
   }
   if ((j!=0) && (input[i][j-1] <= InCellValue) && (input[i][j-1] < LeastNeighbour))
   {
     LeastNeighbour = input[i][j-1];
   }
   if ((j<(Width-1)) && (input[i][j+1] < InCellValue) && (input[i][j+1] < LeastNeighbour))
   {
     LeastNeighbour = input[i][j+1];
   }
   if ((i<(Height-1)) && (input[i+1][j] < InCellValue) && (input[i+1][j] < LeastNeighbour))
   {
     LeastNeighbour = input[i+1][j];
   }
 
 
   if ((i != 0) && (input[i-1][j] >= InCellValue) && (input[i-1][j] > HighNeighbour))
   {
     HighNeighbour = input[i-1][j];
   }
   if ((j!=0) && (input[i][j-1] >= InCellValue) && (input[i][j-1] > HighNeighbour))
   {
     HighNeighbour = input[i][j-1];
   }
   if ((j<(Width-1)) && (input[i][j+1] > InCellValue) && (input[i][j+1] > HighNeighbour))
   {
     HighNeighbour = input[i][j+1];
   }
   if ((i<(Height-1)) && (input[i+1][j] > InCellValue) && (input[i+1][j] > HighNeighbour))
   {
     HighNeighbour = input[i+1][j];
   }
 
   if(output[i][j] == '\0')
   {
     if(LeastNeighbour < input[i][j])
     {
       if ((i != 0) &&  (input[i-1][j] == LeastNeighbour))
       {
         if(output[i-1][j] == '\0')
         {
           Assigned = CheckHighAssign(i , j,HighNeighbour);
           if(Assigned == 0)
           {
             Assigned = 1;
             output[i-1][j] = output[i][j] = OutputCount;
             OutputCount++;
           }
         }
         else
         {
           Assigned = 1;
           output[i][j] = output[i-1][j];
         }
 
       }
       if ((j!=0) &&(input[i][j-1]  ==  LeastNeighbour) && (Assigned == 0))
       {
         if(output[i][j-1] == '\0')
         {
           Assigned = CheckHighAssign(i , j,HighNeighbour);
           if(!Assigned)
           {
             Assigned = 1;
             output[i][j-1] = output[i][j] = OutputCount;
             OutputCount++;
           }
         }
         else
         {
           Assigned = 1;
           output[i][j] = output[i][j-1];
         }
 
       }
       if ((j<(Width-1)) &&  (input[i][j+1] == LeastNeighbour)  && (Assigned == 0))
       {
               if(output[i][j+1] == '\0')
               {
                 Assigned = CheckHighAssign(i , j,HighNeighbour);
                 if(!Assigned)
                 {
                   Assigned = 1;
                   output[i][j+1] = output[i][j] = OutputCount;
                   OutputCount++;
                 }
               }
               else
               {
                 Assigned = 1;
                 output[i][j] = output[i][j+1];
 
               }
       }
       if ((i<(Height-1)) &&  (input[i+1][j] == LeastNeighbour) && (Assigned == 0))
       {
               if(output[i+1][j] == '\0')
               {
                 Assigned = CheckHighAssign(i , j,HighNeighbour);
                 if(!Assigned)
                 {
                   Assigned = 1;
                   output[i+1][j] = output[i][j] = OutputCount;
                   OutputCount++;
                 }
               }
               else
               {
                 Assigned = 1;
                 output[i][j] = output[i+1][j];
               }
 
       }
     }/* LeastNeigh is least*/
 
     if (Assigned == 0)
     {
 Assigned = CheckHighAssign(i , j,HighNeighbour);
       if(!Assigned)
       {
         output[i][j] = OutputCount;
         if(bFillMe == 1)
         {
           bFillMe = 0;
           output[fillrow][fillcolm] = OutputCount;
         }
         OutputCount++;
       }
     }
   }/* == \0*/
 
 }
 
 int CheckHighAssign(int i , int j, int HighNeighbour)
 {
   int Assigned = 0;
 
       if((HighNeighbour > input[i][j]))
       {
         if ((i != 0) &&  (input[i-1][j] == HighNeighbour))
         {
           if(output[i-1][j] != '\0')
           {
             Assigned = 1;
             output[i][j] = output[i-1][j];
           }
 
         }
         if ((j!=0) &&(input[i][j-1]  ==  HighNeighbour) && (Assigned == 0))
         {
           if(output[i][j-1] != '\0')
           {
             Assigned = 1;
             output[i][j] = output[i][j-1];
           }
 
         }
         if ((j<(Width-1)) &&  (input[i][j+1] == HighNeighbour)  && (Assigned == 0))
         {
                 if(output[i][j+1] != '\0')
                 {
                   Assigned = 1;
                   output[i][j] = output[i][j+1];
 
                 }
         }
         if ((i<(Height-1)) &&  (input[i+1][j] == HighNeighbour) && (Assigned == 0))
         {
                 if(output[i+1][j] != '\0')
                 {
                   Assigned = 1;
                   output[i][j] = output[i+1][j];
                 }
 
         }
       }
       return Assigned;
 
 }
 
 void InitialSetup()
 {
   int i=0,j=0,Least = 0;
   int CurrCell = 1;
   int Done = 0;
   output[0][0] = OutputCount++;
   while ((Least < CurrCell) && (Least != CurrCell))
   {
       CurrCell = Least = input[i][j];
       Done = 0;
       if ((i != 0) &&  (input[i-1][j] < Least))
         Least = input[i-1][j];
       if ((j!=0) &&(input[i][j-1] < Least))
         Least = input[i][j-1];
       if ((j<(Width-1)) &&  (input[i][j+1] < Least))
         Least = input[i][j+1];
       if ((i<(Height-1)) &&  (input[i+1][j] < Least))
         Least = input[i+1][j];
      // if(input[i][j] <= Least)
       {
         //break;
       }
       if(input[i][j] > Least)
       {
         if ((i != 0) &&  (input[i-1][j] == Least) && (Done == 0))
         {
           output[i-1][j] = output[i][j];
           i = i-1;
           Done = 1;
         }
         if ((j!=0) &&(input[i][j-1] == Least)&& (Done == 0))
         {
           output[i][j-1] = output[i][j];
           j = j -1;
           Done = 1;
         }
         if ((j<(Width-1)) &&  (input[i][j+1] == Least)&& (Done == 0))
         {
           output[i][j+1] = output[i][j];
           j = j+1;
           Done = 1;
         }
         if ((i<(Height-1)) &&  (input[i+1][j] == Least)&& (Done == 0))
         {
           output[i+1][j] = output[i][j];
           i = i+1;
           Done = 1;
         }
       }
   }
 }
 

