/*
  * File: main.c
  * Author: Corey Beres (corey.beres@gmail.com)
  * Description: solution to Code Jam problem A
  */
 
 #include <sys/types.h>
 #include <regex.h>
 #include <stdlib.h>
 #include <stdio.h>
 
 /**
  * main
  * Reads in the input file and output file and does all work
  */
 int main(int argc, char* argv[]) {
 	int i, j, L, D, N, matches;
 	FILE* f;
 	FILE* o;
 	regex_t r;
 
 	// open file, get constants
 	f = fopen(argv[1], "r");
 	fscanf(f, "%d %d %d\n", &L, &D, &N);
 
 	// open output file
 	o = fopen(argv[2], "w");
 
 	char dict[D][L+1];
 
 	// read in dictionary
 	for (i = 0; i < D; ++i) {
 		fscanf(f, "%s\n", dict[i]);
 	}
 
 	char test[1024];
 
 	// read in test cases
 	for (i = 0; i < N; ++i) {
 		matches = 0;
 	
 		// read in test case
 		fscanf(f, "%s\n", test);
 
 		// replace () with []
 		for (j = 0; j < 1024; ++j) {
 			if (test[j] == '(')
 				test[j] = '[';
 			else if (test[j] == ')')
 				test[j] = ']';
 		}
 
 		// compile regex
 		regcomp(&r, test, 0);
 
 		// check for matches
 		for (j = 0; j < D; ++j) {
 			// compile regex
 			regcomp(&r, test, 0);
 
 			// perform a check
 			if (regexec(&r, dict[j], 0, NULL, 0) != REG_NOMATCH)
 				++matches;
 
 			// free memory
 			regfree(&r);
 		}
 
 		fprintf(o, "Case #%d: %d\n", i+1, matches);
 	}
 
 	fclose(f);
 	fclose(o);
 
 	return 0;
 }

