#include <stdio.h>
 #include <string.h>
 int main() {
     int n;
     int k;
     long long unsigned int p[30];
     int input;
     long long unsigned int r;
     scanf("%d\n",&n);
     for (k = 0; k < n; k++) {
         memset(p,0, 30 * sizeof(long long unsigned int));
         input = getchar();
         while(input != '\n' && input != '\0' && input != -1) {
                    //welcome to code jam
                    //0123456789012345678
             switch(input) {
                 case 'w':
                     p[0]++;
                     break;
                 case 'e':
                     p[1] += p[0];
                     p[6] += p[5];
                     p[14] += p[13];
                     break;
                 case 'l':
                     p[2] += p[1];
                     break;
                 case 'c':
                     p[3] += p[2];
                     p[11] += p[10];
                     break;
                 case 'o':
                     p[4] += p[3];
                     p[9] += p[8];
                     p[12] += p[11];
                     break;
                 case 'm':
                     p[5] += p[4];
                     p[18] += p[17];
                     break;
                 case ' ':
                     p[7] += p[6];
                     p[10] += p[9];
                     p[15] += p[14];
                     break;
                 case 't':
                     p[8] += p[7];
                     break;
                 case 'd':
                     p[13] += p[12];
                     break;
                 case 'j':
                     p[16] += p[15];
                     break;
                 case 'a':
                     p[17] += p[16];
                     break;
                 default:
                     break;
             }
             input = getchar();
         }
         r = p[18];
         printf("Case #%d: ",k+1);
         r = r % 10000;
         if (r < 10) {
             printf("000%d\n",r);
         } else if (r < 100) {
             printf("00%d\n",r);
         } else if (r < 1000 ) {
             printf("0%d\n",r);
         } else {
             printf("%d\n",r);
         }
     }
 }

