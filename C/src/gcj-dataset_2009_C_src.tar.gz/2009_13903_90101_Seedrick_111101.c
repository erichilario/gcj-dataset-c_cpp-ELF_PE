#include<stdio.h>
 #include<conio.h>
 #include<string.h>
 
 int main() {
 
     //FILE *fp=fopen("C:\\land.in","r");
     //FILE *fp2=fopen("C:\\land_res.in","w");
     int no_matrix;
     int height, width;
     int i, j, k;
 
     scanf("%d", &no_matrix);
     int matrix = no_matrix;
     //no of matrices
     //int** results = (int**) malloc(no_matrix * sizeof (int*));
     while (no_matrix--) {
         scanf("%d %d", &height, &width);
         //int* mat = (int*) malloc(height * width * sizeof (int));
 
         /*  int **mat = (int **) malloc(height * sizeof (int *));
           mat[0] = malloc(height * width * sizeof (int));
           for (i = 1; i < height; i++)
               mat[i] = mat[0] + (i * width);
          */
         int **mat = (int **) malloc(height * sizeof (int *));
         for (i = 0; i < height; i++) {
             mat[i] = malloc(width * sizeof (int));
         }
         // Access elements as myarray[i][j]
 
         for (i = 0; i < height; i++) {
             for (j = 0; j < width; j++) {
                 scanf("%d", &mat[i][j]);
             }
         }
         //the input is now stored
         //let the actual computations start
 
         /* char **res = (char **) malloc(height * sizeof (char *));
                res[0] = malloc(height * width * sizeof (char));
                for (i = 1; i < height; i++)
                    res[i] = res[0] + (i * width);
          */
         int **res = (int **) malloc(height * sizeof (int *));
         for (i = 0; i < height; i++) {
             res[i] = malloc(width * sizeof (int));
         }
 
         //the resultant matrix
         for (i = 0; i < height; i++) {
             for (j = 0; j < width; j++) {
                 res[i][j] = ' ';
             }
         }
 
         char alpha = 'a';
 
         for (i = 0; i < height; i++) {
             for (j = 0; j < width; j++) {
                 int _u = (i == 0) ? 10001 : mat[i - 1][j];
                 int _r = (j == (width - 1)) ? 10001 : mat[i][j + 1];
                 int _d = (i == (height - 1)) ? 10001 : mat[i + 1][j];
                 int _l = (j == 0) ? 10001 : mat[i][j - 1];
                 if ((mat[i][j] < _u) && (mat[i][j] < _r) && (mat[i][j] < _d) && (mat[i][j] < _l)) {
                     res[i][j] = alpha;
                     alpha++;
                 }
             }
         }
 
         for (i = 0; i < height; i++) {
             for (j = 0; j < width; j++) {
                 int _u = (i == 0) ? 10001 : mat[i - 1][j];
                 int _r = (j == (width - 1)) ? 10001 : mat[i][j + 1];
                 int _d = (i == (height - 1)) ? 10001 : mat[i + 1][j];
                 int _l = (j == 0) ? 10001 : mat[i][j - 1];
 
                 int min = _u;
                 if (_l < min)min = _l;
                 if (_r < min)min = _r;
                 if (_d < min)min = _d;
 
                 if (min == _u && min < mat[i][j]) {
                     if ((res[i - 1][j] != ' ') && (res[i - 1][j] != 'U') && (res[i - 1][j] != 'L') && (res[i - 1][j] != 'R') && (res[i - 1][j] != 'D')) {
                         res[i][j] = res[i - 1][j];
                     } else {
                         res[i][j] = 'U';
                     }
                 } else if (min == _l && min < mat[i][j]) {
                     if ((res[i][j - 1] != ' ') && (res[i][j - 1] != 'U') && (res[i][j - 1] != 'L') && (res[i][j - 1] != 'R') && (res[i][j - 1] != 'D')) {
                         res[i][j] = res[i][j - 1];
                     } else {
                         res[i][j] = 'L';
                     }
                 } else if (min == _r && min < mat[i][j]) {
                     if ((res[i][j + 1] != ' ') && (res[i][j + 1] != 'U') && (res[i][j + 1] != 'L') && (res[i][j + 1] != 'R') && (res[i][j + 1] != 'D')) {
                         res[i][j] = res[i][j + 1];
                     } else {
                         res[i][j] = 'R';
                     }
                 } else if (min == _d && min < mat[i][j]) {
                     if ((res[i + 1][j] != ' ') && (res[i + 1][j] != 'U') && (res[i + 1][j] != 'L') && (res[i + 1][j] != 'R') && (res[i + 1][j] != 'D')) {
                         res[i][j] = res[i + 1][j];
                     } else {
                         res[i][j] = 'D';
                     }
                 }
             }
         }
         
         for (i = 0; i < height; i++) {
             for (j = 0; j < width; j++) {
                 if (res[i][j] == ' ') {
                     res[i][j] = alpha;
                     alpha++;
                 }
             }
         }
         for (k = 0; k < (height * width); k++) {
             int track = 0;
             for (i = 0; i < height; i++) {
                 for (j = 0; j < width; j++) {
                     if ((res[i][j] == 'U') && (res[i - 1][j] != 'U') && (res[i - 1][j] != 'L') && (res[i - 1][j] != 'R') && (res[i - 1][j] != 'D')) {
                         res[i][j] = res[i - 1][j];
                         track = 1;
                     }
                     if ((res[i][j] == 'L') && (res[i][j - 1] != 'U') && (res[i][j - 1] != 'L') && (res[i][j - 1] != 'R') && (res[i][j - 1] != 'D')) {
                         res[i][j] = res[i][j - 1];
                         track = 1;
                     }
                     if ((res[i][j] == 'R') && (res[i][j + 1] != 'U') && (res[i][j + 1] != 'L') && (res[i][j + 1] != 'R') && (res[i][j + 1] != 'D')) {
                         res[i][j] = res[i][j + 1];
                         track = 1;
                     }
                     if ((res[i][j] == 'D') && (res[i + 1][j] != 'U') && (res[i + 1][j] != 'L') && (res[i + 1][j] != 'R') && (res[i + 1][j] != 'D')) {
                         res[i][j] = res[i + 1][j];
                         track = 1;
                     }
                 }
             }
             if (track == 0)break;
         }
         if (res[0][0] != 'a') {
             char t = res[0][0];
             for (i = 0; i < height; i++) {
                 for (j = 0; j < width; j++) {
                     if (res[i][j] == 'a')res[i][j] = t;
                     else if (res[i][j] == t)res[i][j] = 'a';
                 }
             }
         }
         for (k = 0; k < (height * width); k++) {
             char test = 'a';
             char t, u;
             int mission = 0;
             for (i = 0; i < height; i++) {
                 for (j = 0; j < width; j++) {
                     if (res[i][j] > test) {
                         t = res[i][j];
                         mission = 1;
                         break;
                     }
                     if (res[i][j] == test)test++;
                 }
                 if (mission == 1)break;
             }
             for (i = 0; i < height; i++) {
                 for (j = 0; j < width; j++) {
                     if (res[i][j] == test)res[i][j] = t;
                     else if (res[i][j] == t)res[i][j] = test;
                 }
             }
         }
         //now what remains is to iterate and propagate all the collected info
         printf("Case #%d:", matrix - no_matrix);
         for (i = 0; i < height; i++) {
             printf("\n");
             for (j = 0; j < width; j++) {
                 printf("%c ", res[i][j]);
             }
         }
         printf("\n");
     }
     //fclose(fp);
     //fclose(fp2);
     //getch();
 }
 

