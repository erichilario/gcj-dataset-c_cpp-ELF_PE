#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 
 void chomp(char *s) {
   while(strlen(s) > 0 && strchr("\r\n",s[strlen(s)-1])!=NULL)
     s[strlen(s)-1] = 0;
 }
 
 int64_t solve(char *t, char *m) {
 
   char *i1;
 
   if (*m==0) return 1;
   if (*t==0) return 0;
   
   i1 = t;
 
   while(*i1 != *m && *i1 != 0) i1++;
   if (*i1 == 0) return 0;
   return(solve(i1+1,m+1) + solve(i1+1, m));
 }
 
 int main() {
   char t[1024];
   int i,N;
   char *M = "welcome to code jam";
   int64_t c;
   int ic;
 
   fgets(t,1024,stdin);
   chomp(t);
   N = atoi(t);
 
   for(i=0;i<N;i++) {
     fgets(t,1024,stdin);
     chomp(t);
     c = solve(t,M);
     ic = (int) (c % 1000);
     printf("Case #%d: %.4d\n", i+1, ic);
   }
 
   return 0;
 }

