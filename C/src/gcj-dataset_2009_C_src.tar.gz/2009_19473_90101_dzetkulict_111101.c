#include <stdio.h>
 
 int m[104][104];
 int p[104*104];
 int nn[30];
 
 int pa(int x)
 {
   if (p[x]==x) return x;
   return p[x]=pa(p[x]);
 }
 
 int main()
 {
   int t,i,j,k,h,w,c,s1,s2,n;
   scanf("%d",&t);
   for (i=0;i<t;++i)
   {
     printf("Case #%d:\n",i+1);
     scanf("%d %d\n",&h,&w);
     for (j=0;j<h+2;++j) m[j][0]=m[j][w+1]=1<<30;
     for (j=0;j<w+2;++j) m[0][j]=m[h+1][j]=1<<30;
     for (j=0;j<h;++j) for (k=0;k<w;++k) 
     {
       scanf("%d",m[j+1]+k+1);
       p[j*w+k]=j*w+k;
     }
     for (j=0;j<h;++j) for (k=0;k<w;++k) 
     {
       c=m[j+1][k+1];
       if (m[j][k+1]<c) { s1=j; s2=k+1; c=m[s1][s2]; }
       if (m[j+1][k]<c) { s1=j+1; s2=k; c=m[s1][s2]; }
       if (m[j+1][k+2]<c) { s1=j+1; s2=k+2; c=m[s1][s2]; }
       if (m[j+2][k+1]<c) { s1=j+2; s2=k+1; c=m[s1][s2]; }
 /*      printf(">> %d %d %d\n",c,s1,s2);
       for (n=0;n<w*h;++n) printf("%d ",p[n]); printf("\n");*/
       if (c<m[j+1][k+1])
       {
         p[j*w+k]=pa((s1-1)*w+(s2-1));
       }
     }
     n=0;
     for (j=0;j<h;++j) 
     {
       for (k=0;k<w;++k)
       {
         for (c=0;c<n;++c) if (nn[c]==pa(j*w+k)) break;
         if (c==n)
         {
           nn[n++]=pa(j*w+k);
         }
         printf("%c ",c+'a');
       }
       printf("\n");
     }
   }
   return 0;
 }

