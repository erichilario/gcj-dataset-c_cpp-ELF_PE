#include<stdio.h>
 #include<string.h>
 int get(int length,int pos,char pattern[][15],char tmp[][26],int pLenth);
 main()
 {
 	int L,D,N,i,j,k,m;
 	char pattern[6000][16];
 	char s[1000];
 	char tmp[150][260];
 	int flag=0;
 	FILE *in,*out;
 	in=fopen("in.in","r");
 	out=fopen("out.out","w");
 
 
 	fscanf(in,"%d%d%d",&L,&D,&N);
 	for(i=0;i<D;i++)
 		fscanf(in,"%s",pattern[i]);
 	for(i=0;i<N;i++)
 	{
 		fscanf(in,"%s",s);
 		k=0;m=0;
 		for(j=0;j<strlen(s);j++)
 		{
 			if(s[j]=='(')
 				flag=1;
 			else if(s[j]==')')
 			{
 				tmp[k][m]=0;
 				flag=0;
 				k++;
 				m=0;
 			}
 			else if(flag==1) 
 			{
 				tmp[k][m++]=s[j];
 			}
 			else
 			{
 				tmp[k][m]=s[j];
 				tmp[k][1]=0;
 				k++;
 			}
 
 
 
 		}
 		fprintf(out,"Case #%d: %d\n",i+1,get(L,0,pattern,tmp,D));
 	}
 	
 	fclose(in);
 	fclose(out);
 }
 
 int get(int length,int pos,char pattern[][15],char tmp[][26],int pLenth)
 {
 
 	int i,j,k,flag=1,total=0;
 	for(i=0;i<pLenth;i++)
 	{
 		flag=1;
 		for(j=0;j<length;j++)
 		{
 			if(flag==0)
 				break;
 			for(k=0;k<strlen(tmp[j]);k++)
 			{
 				if(tmp[j][k]==pattern[i][j])
 					break;
 			}
 			if(k<strlen(tmp[j]))
 				;
 			else
 			{
 				flag=0;
 				break;
 			}
 
 
 		}
 		if(flag==1)
 			total++;
 		
 
 	}
 	return total;
 }
