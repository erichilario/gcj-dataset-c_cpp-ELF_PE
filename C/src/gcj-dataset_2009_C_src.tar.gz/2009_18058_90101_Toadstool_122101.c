/*
  * Copyright © 2009 Jérémie Corbier <jeremie@famille-corbier.net>
  *
  * Permission is hereby granted, free of charge, to any person obtaining a copy
  * of this software and associated documentation files (the "Software"), to deal
  * in the Software without restriction, including without limitation the rights
  * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  * copies of the Software, and to permit persons to whom the Software is
  * furnished to do so, subject to the following conditions:
  *
  * The above copyright notice and this permission notice shall be included in
  * all copies or substantial portions of the Software.
  *
  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  * SOFTWARE.
  */
 
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 #define STRLEN 19
 static const char const *str = "welcome to code jam";
 
 static char **tests = NULL;
 
 static unsigned long long welcome(int pos, char *buf)
 {
     unsigned long long count = 0;
 
     if(pos == STRLEN)
         return 1;
     if(*buf == '\0')
         return 0;
 
     if(*buf == str[pos])
         count = welcome(pos + 1, buf + 1);
 
     return count + welcome(pos, buf + 1);
 }
 
 int main(int argc, char *argv[])
 {
     int N, i, curline = 0, ret = 1;
     char buf[1024];
 
     while(1)
     {
         if(fgets(buf, 1024, stdin) == NULL)
             break;
         curline++;
 
         if(curline == 1)
         {
             char *endptr;
             N = strtol(buf, &endptr, 0);
 
             if((endptr == buf) || (N == 0))
                 goto end;
 
             /* Allocate tests table */
             tests = malloc(N * sizeof(char *));
             if(tests == NULL)
                 goto end;
 
             continue;
         }
 
         if(curline > N + 1)
             break;
 
         tests[curline - 2] = strdup(buf);
         if(tests[curline - 2] == NULL)
             goto end;
     }
 
     for(i = 0; i < N; i++)
     {
         unsigned long long count;
 
         count = welcome(0, tests[i]);
 
         printf("Case #%d: %04d\n", i + 1, (int)(count % 10000));
     }
 
     ret = 0;
 
 end:
     if(tests)
     {
         for(i = 0; i < N; i++)
             if(tests[i])
                 free(tests[i]);
         free(tests);
     }
 
     return ret;
 }

