#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct _node {
   struct _node* le;
   struct _node* eq;
   struct _node* gt;
   char c;
 } node;
 
 node*
 trie_add(node* n, char* s) {
   if(n == 0) {
     n = (node*)malloc(sizeof(node));
     n->c = *s;
     n->le = 0;
     n->eq = 0;
     n->gt = 0;
   }
 
   if(*s == n->c) {
     if(*s != 0) {
       n->eq = trie_add(n->eq, s+1);
     }
   } else if(*s > n->c) {
     n->gt = trie_add(n->gt, s);
   } else {
     n->le = trie_add(n->le, s);
   }
 
   return n;
 }
 
 void
 trie_delete(node* n) {
   if(n != 0) {
     trie_delete(n->le);
     trie_delete(n->eq);
     trie_delete(n->gt);
 
     free(n);
   }
 }
 
 int
 trie_find(node* n, char* s) {
   int result = 0;
 
   if(n != 0) {
     if(*s == n->c) {
       if(*s != 0) {
         result = trie_find(n->eq, ++s);
       } else {
         result = 1;
       }
     } else if(*s > n->c) {
       result = trie_find(n->gt, s);
     } else {
       result = trie_find(n->le, s);
     }
   }
 
   return result;
 }
 
 int
 trie_match(node* n, char* s) {
   int result = 0;
 
   if(n != 0) {
     if(*s == '(') {
       char* c = s;
 
       while(*++c != ')') {
         if(*c == n->c) {
           if(*s != 0) {
             char* s2 = s;
             while(*s2++ != ')');
 
             result += trie_match(n->eq, s2);
           } else {
             result = 1;
           }
         }
       }
       result += trie_match(n->gt, s);
       result += trie_match(n->le, s);
     } else {
       if(*s == n->c) {
         if(*s != 0) {
           result += trie_match(n->eq, ++s);
         } else {
           result = 1;
         }
       } else if(*s > n->c) {
         result += trie_match(n->gt, s);
       } else {
         result += trie_match(n->le, s);
       }
     }
   }
 
   return result;
 }
 
 int 
 main() {
   int l;
   int d;
   int n;
   int i;
   node* root = 0;
 
   scanf("%d %d %d\n", &l, &d, &n);
 
   for(i = 0; i < d; i++) {
     char word[20];
 
     gets(word);
     root = trie_add(root, word);
   }
 
   for(i = 0; i < n; i++) {
     char pattern[1024];
 
     gets(pattern);
 
     printf("Case #%d: %d\n", i+1, trie_match(root, pattern));
   }
 
   trie_delete(root);
 
   return 0;
 }

