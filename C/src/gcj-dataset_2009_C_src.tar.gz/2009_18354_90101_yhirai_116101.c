#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int bit_for(char n) {
   return 1 << (n - 'a');
 }
 
 int has_bit(int bits, char n) {
   return (bits & bit_for(n));
 }
 
 int test_pass(char* testee, int* test, int L) {
   int i;
   for(i = 0; i < L; i++) {
     if (!(bit_for(testee[i]) & test[i]))
       return 0;
   }
   return 1;
 }
 
 void main(void) {
   int L, D, N;
   char** strings;
   int i;
   int* test;
   char* test_string;
 
   scanf("%d %d %d\n", &L, &D, &N);
 
   /* read testee */
   strings = calloc(sizeof(char*), D);
 
   for (i = 0; i < D; i++) {
     char* str = (char *) calloc(L+1, 1);
     scanf("%s\n", str);
     *(strings + i) = str;
   }
 
   /* read and execute tester */
   test = malloc(sizeof(int) * L);
   test_string = (char*) malloc((2+26) * L + 1);
 
   for (i = 0; i < N; i++) {
     int j;
     int pass_num = 0;
     char* c = test_string;
     memset(test, 0, sizeof(int) * L);
     scanf("%s\n", test_string);
 
     for (j = 0; j < L; j++) {
       char ch;
       int in_kakko = 0;
       while(ch = *(c++)) {
 	switch(ch) {
 	case ')':
 	  in_kakko = 0;
 	  goto next_char;
 	case '(':
 	  in_kakko = 1;
 	  break;
 	default:
 	  test[j] |= bit_for(ch);
 	  if (!in_kakko)
 	    goto next_char;
 	  break;
 	}
       }
     next_char:;
     }
     /* execute test */
     for (j = 0; j < D; j++) {
       if(test_pass(strings[j], test, L))
 	pass_num ++;
     }
     printf("Case #%d: %d\n", i+1, pass_num);
   }
 
 }

