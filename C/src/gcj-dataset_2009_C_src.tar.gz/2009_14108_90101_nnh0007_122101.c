#include <stdio.h>
 char buf[502],wel[20]=" welcome to code jam";
 int wiela[21];
 
 int main()
 {
     unsigned int N;
     scanf("%d\n",&N);
     for(unsigned int i=1;i<=N;i++){
         for(unsigned int j=1;j<21;j++)wiela[j]=0;
         unsigned int l=0;
         gets(buf);
         unsigned int L=strlen(buf);
         wiela[0]=1;
         for(;l<L;++l){
             for(signed int j=19;j>=1;j--){
                 if(buf[l]==wel[j]){
 //printf("%d %c   ",l,wel[j]);
                    wiela[j]+=wiela[j-1];
 //printf("%d:%d ",j,wiela[j]);
                 }
             }
 //printf("\n");
         }
         printf("Case #%d: %04d\n",i,wiela[19]);
     }
     return 0;
 }
 

