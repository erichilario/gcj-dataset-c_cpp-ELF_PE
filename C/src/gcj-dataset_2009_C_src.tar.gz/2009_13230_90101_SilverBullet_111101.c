#include<stdio.h>
 #include<stdlib.h>
 int findMin(int,int);
 char traceSource(int,int);
 int Matrix[100][100];
 char Label[100][100];
 char currentLabel='a';
 char tempLabel='A';
 char updateVar[26];
 int H,W;
 int main(){
 	int T;
 	int i,j,k;
 	FILE *fin = fopen("C:\\Rajatj\\TempFiles4\\temp.txt","r");
 	FILE *fout = fopen("C:\\Rajatj\\TempFiles4\\temp.out","w");
 	fscanf(fin,"%d",&T);
 	for(i=0;i<T;i++){
 		//Cases start here
 //		int now;
 		fscanf(fin,"%d%d",&H,&W);
 		for(j=0;j<H;j++){
 			for(k=0;k<W;k++){
 				fscanf(fin,"%d",&Matrix[j][k]);
 				Label[j][k]='X';
 			}
 		}
 		currentLabel='a';
 		for(j=0;j<H;j++){
 			for(k=0;k<W;k++){
 				Label[j][k]=traceSource(j,k);
 			}
 		}
 		fprintf(fout,"Case #%d:\n",i+1);
 		for(j=0;j<H;j++){
 			for(k=0;k<W;k++){
 				fprintf(fout,"%c",Label[j][k]);
 			}
 			fprintf(fout,"\n");
 		}
 		//Cases end here
 	}
 	fclose(fin);
 	fclose(fout);
 	return 0;
 }
 char traceSource(int m,int n){
 	char ch=Label[m][n];
 	if(Label[m][n]!='X'){
 		return Label[m][n];
 	}
 	int min =findMin(m,n);
 	if(min==0){
 		Label[m][n]=currentLabel++;
 		return Label[m][n];
 	}else if(min==1){
 		ch=traceSource(m-1,n);
 	}else if(min==2){
 		ch=traceSource(m,n-1);
 	}else if(min==3){
 		ch=traceSource(m,n+1);
 	}else if(min==4){
 		ch=traceSource(m+1,n);
 	}else {
 	}
 	Label[m][n]=ch;
 	return ch;
 }
 int findMin(int m, int n){
 	int num[6]={10001,10001,10001,10001,10001,-1};
 	num[0]=Matrix[m][n];
 	if(m>=1)
 		num[1]=Matrix[m-1][n];
 	if(n>=1)
 		num[2]=Matrix[m][n-1];
 	if(n<W-1)
 		num[3]=Matrix[m][n+1];
 	if(m<H-1)
 		num[4]=Matrix[m+1][n];
 	int i;
 	int min=0;
 	for(i=0;num[i]!=-1;i++){
 		if(num[i]<num[min])
 			min=i;
 	}
 	return min;
 }

