#include<stdio.h>
 #include<stdlib.h>
 
 struct cell {
     int height;
     char visited;
     char label;
 };
 int H = 0;
 int W = 0;
 struct cell land[100][100];
 
 int whereToFlow(int i, int j)
 {
     int ch = land[i][j].height;
     int retVal = 0;
     int igNorth, igWest, igEast, igSouth;
     
     igNorth = igWest = igEast = igSouth = 1;
     
     if(i-1 < 0) igNorth = 0;
     if(i+1 >= H) igSouth = 0;
     if(j-1 < 0) igWest = 0;
     if(j+1 >= W) igEast = 0;
 
     if ( (land[i-1][j].height < ch) && igNorth )
        { retVal = 1; ch = land[i-1][j].height; }
     if ( (land[i][j-1].height < ch) && igWest )
        { retVal = 2; ch = land[i][j-1].height; }
     if ( (land[i][j+1].height < ch) && igEast )
        { retVal = 3; ch = land[i][j+1].height; }
     if ( (land[i+1][j].height < ch) && igSouth )
        { retVal = 4; ch = land[i+1][j].height; } 
        
     return retVal;
 }
 
 int main() {
     int i,j, k, x,y,n;
     int dir = 0;
     char nextLabel;
     int N, HH,WW;
  
     scanf("%d", &N);
  
  for(n=0; n < N; n++) {
     scanf("%d %d", &HH, &WW);
     H = HH, W = WW;
     
     for(i=0;i<H;i++)
         for(j=0;j<W;j++) {
             scanf("%d ", &k);
             land[i][j].height = k;
             land[i][j].visited = 0;
             land[i][j].label = ' ';
         }
     
     nextLabel = 'a';        
     land[0][0].visited = 1;
     land[0][0].label = 'a';
     nextLabel++;
     
     for(i=0;i<H;i++) {
         for(j=0;j<W;j++) {
             x = i; y = j;
             dir = whereToFlow(i,j);
             switch(dir) {
                 case 1: x--; 
                      break;
                 case 2: y--; 
                      break;
                 case 3: y++; 
                      break;
                 case 4: x++; 
                      break;
             }
             
             if( land[i][j].visited == 1 && land[x][y].visited != 1) {
                  land[x][y].visited = 1;
                  land[x][y].label = land[i][j].label;                
             } else if( land[i][j].visited != 1 && land[x][y].visited == 1) {
                  land[i][j].visited = 1;
                  land[i][j].label = land[x][y].label;
             } else if ( land[i][j].visited != 1 && land[x][y].visited != 1) {
                  land[i][j].visited = land[x][y].visited = 1;
                  land[i][j].label = land[x][y].label = nextLabel++;               
             }            
         }
     }
     
     printf("Case #%d:\n",n+1);
     for(i=0;i<H;i++) {
         for(j=0;j<W;) {
             printf("%c", land[i][j].label);
             j++;
             if(j<W)
             printf(" ");
         }
         printf("\n");
     }
 }
 }

