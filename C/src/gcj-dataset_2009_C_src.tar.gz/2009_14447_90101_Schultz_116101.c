#include <stdio.h>
 #include <string.h>
 #include <stdbool.h>
 
 #define NMAX 15
 #define MMAX 5000
 #define SMAX (28*NMAX)
 
 static char words [MMAX][NMAX+1];
 static char str   [SMAX+1];
 static bool ok    [NMAX][26];
 
 int main(void) {
 	int   n, m, tc, cs, i, j, c;
 	char* p;
 
 	scanf("%d%d%d", &n, &m, &tc);
 
 	for (i = 0; i != m; ++i)
 		scanf("%s", words[i]);
 
 	for (cs = 0; cs != tc; ++cs) {
 		scanf("%s", str);
 		for (i = 0, p = str; *p != '\0'; ++i, ++p) {
 			memset(ok[i], 0, 26*sizeof(ok[i][0]));
 			if (*p != '(')
 				ok[i][*p-'a'] = true;
 			else
 				for (++p; *p != ')'; ++p)
 					ok[i][*p-'a'] = true;
 		}
 
 		c = 0;
 		for (i = 0; i != m; ++i) {
 			for (j = 0; j != n; ++j)
 				if (!ok[j][words[i][j]-'a'])
 					break;
 			if (j == n)
 				++c;
 		}
 
 		printf("Case #%d: %d\n", cs+1, c);
 	}
 
 	return 0;
 }
 
 

