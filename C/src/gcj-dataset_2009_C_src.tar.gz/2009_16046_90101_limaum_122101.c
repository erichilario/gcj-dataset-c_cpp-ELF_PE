#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 #include <math.h>
 
 char search[] = "welcome to code jam";
 
 int count(char text[600], char *str, char temp, char next, int pos){
     
     if(strcmp(search, str) == 0){
                       return 1;
     } else {
            int size = strlen(text);
            int i = pos;
            int ret = 0;
                       
            while(i < size){
                    
                    if(temp == ' ' && next == 'w' && text[i] == 'w'){
                        char temp[100];
                        strcpy(temp, str);
                        strcpy(temp, "w");   
 
                        ret += count(text, temp, 'w', 'e', i);    
                    }
                    if(temp == 'w' && next == 'e' && text[i] == 'e'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "e");   
                        ret += count(text, temp, 'e', 'l', i);    
                    }
                    if(temp == 'e' && next == 'l' && text[i] == 'l'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "l");   
                        ret += count(text, temp, 'l', 'c', i);    
                    }
                    if(temp == 'l' && next == 'c' && text[i] == 'c'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "c");   
                        ret += count(text, temp, 'c', 'o', i);    
                    }
                    if(temp == 'c' && next == 'o' && text[i] == 'o'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "o");   
                        ret += count(text, temp, 'o', 'm', i);    
                    }
                    if(temp == 'o' && next == 'm' && text[i] == 'm'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "m");   
                        ret += count(text, temp, 'm', 'e', i);    
                    }
                    if(temp == 'm' && next == 'e' && text[i] == 'e'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "e");   
                        ret += count(text, temp, 'e', ' ', i);    
                    }        
                    if(temp == 'e' && next == ' ' && text[i] == ' '){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, " ");   
                        ret += count(text, temp, ' ', 't', i);    
                    }
                    if(temp == ' ' && next == 't' && text[i] == 't'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "t");   
                        ret += count(text, temp, 't', 'o', i);    
                    }
                    if(temp == 't' && next == 'o' && text[i] == 'o'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "o");   
                        ret += count(text, temp, 'o', ' ', i);    
                    }
                    if(temp == 'o' && next == ' ' && text[i] == ' '){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, " ");   
                        ret += count(text, temp, ' ', 'c', i);    
                    }
                    if(temp == ' ' && next == 'c' && text[i] == 'c'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "c");   
                        ret += count(text, temp, 'c', 'o', i);    
                    }
                    if(temp == 'c' && next == 'o' && text[i] == 'o'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "o");   
                        ret += count(text, temp, 'o', 'd', i);    
                    }
                    if(temp == 'o' && next == 'd' && text[i] == 'd'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "d");   
                        ret += count(text, temp, 'd', 'e', i);    
                    }
                    if(temp == 'd' && next == 'e' && text[i] == 'e'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "e");   
                        ret += count(text, temp, 'e', ' ', i);    
                    }
                    if(temp == 'e' && next == ' ' && text[i] == ' '){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, " ");   
                        ret += count(text, temp, ' ', 'j', i);    
                    }
                    if(temp == ' ' && next == 'j' && text[i] == 'j'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "j");   
                        ret += count(text, temp, 'j', 'a', i);    
                    }
                    if(temp == 'j' && next == 'a' && text[i] == 'a'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "a");   
                        ret += count(text, temp, 'a', 'm', i);    
                    }
                    if(temp == 'a' && next == 'm' && text[i] == 'm'){
                        char temp[100];
                        strcpy(temp, str);
                        strcat(temp, "m");   
                        ret += count(text, temp, ' ', ' ', i);    
                    }
                    i++;
            }
            return ret;                  
     }
 }
 
 int main(){
 
         FILE *in;
         FILE *out;
         in = fopen("C-small.in", "r");
         out = fopen("C-small.out", "w");
         int N;
         fscanf(in,"%d\n", &N);
         
         int nextLabel = 0;
         int cas = 1;
         char text[600];
         char result[100];
         char resFinal[5];
 	 	while(N > 0){
     	        fgets(text, 600, in);
     	        itoa(count(text, "", ' ', 'w',0), result, 10);
     	        int s = strlen(result);
     	        
     	        if(s > 4){
                        resFinal[0] = result[s-4];
                        resFinal[1] = result[s-3];
                        resFinal[2] = result[s-2];
                        resFinal[3] = result[s-1];
                        resFinal[4] = '\0';           
                 } else if(s == 1){
                        resFinal[0] = '0';
                        resFinal[1] = '0';
                        resFinal[2] = '0';
                        resFinal[3] = result[s-1];
                        resFinal[4] = '\0';           
                 } else if(s == 2){
                        resFinal[0] = '0';
                        resFinal[1] = '0';
                        resFinal[2] = result[s-2];
                        resFinal[3] = result[s-1];
                        resFinal[4] = '\0';
                 } else if(s == 3){
                        resFinal[0] = '0';
                        resFinal[1] = result[s-3];
                        resFinal[2] = result[s-2];
                        resFinal[3] = result[s-1];
                        resFinal[4] = '\0';
                 }
     	        
                 fprintf(out, "Case #%d: %s\n", cas, resFinal);
                 N--;
                 cas++;
                 
 	    }
                   
         fclose(in);
         fclose(out);
         return 0;
 }

