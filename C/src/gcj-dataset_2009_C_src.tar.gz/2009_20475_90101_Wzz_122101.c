#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <malloc.h>
 #include <ctype.h>
 
 #define Max_size 1000
 
 int getline(FILE *fp,char *buf)
 {
 	int i = 0;
 	char ch = '\0';
 	ch = fgetc(fp);
 	while (ch != '\n')
 	{
 		buf[i] = ch;
 		i++;
 		ch = fgetc(fp);
 	}
 	buf[i] = '\0';
 	return 1;
 }
 
 
 void input()
 {
 	FILE *fp_in;
 	FILE *fp_out;
 
 	int i=0,j=0,z=0;
 	int total=1,kk=0;
 	int N;
 	char ch;
 	char buf[Max_size];
 	char temp[Max_size];
 	int len;
 	int temp_len;
 	char temp_total[10];
 	char one[20] = "000";
 	char two[20] = "00";
 	char three[20] = "0";
 	char *words = "welcome to code jam";
 	int point[20];
 	for(kk = 0;kk < 20;kk++)
 	{
 		point[kk] = 0;;
 	}
 	
 
 	fp_out = fopen("D:\\C-small-attempt5.out","w+");
 	if ((fp_in = fopen("D:\\C-small-attempt5.in","r+")) == NULL)
 	{
 		printf("open A-small-practice.in error!\n");
 		exit(1);
 	}
 	else
 	{
 		getline(fp_in,buf);
 		len = strlen(buf);
 		buf[len] = '\0';
 		N = atoi(buf);
 		strcpy(buf,"\0");
 
 		for(i = 0;i<N;i++)
 		{
 			getline(fp_in,buf);
 			strcpy(temp,buf);
 			temp_len = strlen(temp);
 			len = strlen(words);
 			z = 0;
 			for(j=0;j<len;j++)
 			{
 				if (z >= temp_len)
 				{
 					break;
 				}
 				ch = words[j];
 				while(z < temp_len)
 				{
 					if(temp[z] == words[j])
 					{
 						while(z < temp_len && temp[z] != words[j+1])
 						{
 							if (temp[z] == words[j])
 							{
 								point[j]++;
 							}
 							z++;
 						}
 						break;
 					}
 				z++;
 				}
 			}
 			for(kk = 0;kk < 18;kk++)
 			{
 				total = point[kk]*total;
 			}
 			printf("Case #%d: %d\n",(i+1),total);
 			total = total % 10000;
 			strcpy(one, "000");
 			strcpy(two,"00");
 		    strcpy(three,"0");
 			if(total < 10)
 			{
 				itoa(total,temp_total,10);
 				strcat(one,temp_total);
 				strcpy(temp_total,"\0");
 				strcpy(temp_total,one);
 			}
 			if (10 <= total && total < 100)
 			{
 				itoa(total,temp_total,10);
 				strcat(two,temp_total);
 				strcpy(temp_total,"\0");
 				strcpy(temp_total,two);
 			}
 			if (100 <= total && total <1000)
 			{
 				itoa(total,temp_total,10);
 				strcat(three,temp_total);
 				strcpy(temp_total,"\0");
 				strcpy(temp_total,three);
 			}
 			fprintf(fp_out,"Case #%d: %s\n",(i+1),temp_total);
 			printf("Case #%d: %d\n",(i+1),total);
 			strcpy(temp_total,"\0");
 
 			total = 1;
 			for(kk = 0;kk < 20;kk++)
 			{
 				point[kk] = 0;;
 			}
 
 		}		
 		
 	}
 
 	fclose(fp_out);
 	fclose(fp_in);
 }
 
 
 int main(int argc,char **argv)
 {
 	input();
 	return 0;
 }
