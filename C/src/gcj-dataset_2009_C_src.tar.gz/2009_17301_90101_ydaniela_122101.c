#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main() {
 	int i, j, k, l, m, n, o, p, q, r, s, t;
 	char str1[505], str2[505];
 	int total[505];
 	
 	scanf(" %d ", &t);
 	for (o = 1; o <= t; o++) {
 		fgets(str1, 505, stdin);
 		s = strlen(str1);
 		if (str1[s-1] == '\n') {
 			str1[s-1] = '\0';
 			s--;	
 		}
 		
 		j = 0;
 		for (i = 0; i < s; i++) {
 			if (str1[i] == 'w' || str1[i] == 'e' || str1[i] == 'l' || str1[i] == 'c' || str1[i] == 'o'
 			|| str1[i] == 'm' || str1[i] == ' ' || str1[i] == 't' || str1[i] == 'd' || str1[i] == 'j'
 			|| str1[i] == 'a') {
 				str2[j++] = str1[i];	
 			}
 		}
 		str2[j] = '\0';
 		i = 0;
 		k = 0;
 		while (i < j && str2[i] != 'w') {
 			i++;
 		}
 		while (i < j && str2[i] != 'e') {
 			if (str2[i] == 'w') {
 				str1[k++] = 'w';	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'l') {
 			if (str2[i] == 'w' || str2[i] == 'e') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'c') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'o') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'm') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'e') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != ' ') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 't') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'o') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != ' ') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'c') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'o') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'd') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'e') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't' || str2[i] == 'd') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != ' ') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't' || str2[i] == 'd') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'j') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't' || str2[i] == 'd') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j && str2[i] != 'a') {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't' || str2[i] == 'd' || str2[i] == 'j') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		while (i < j) {
 			if (str2[i] == 'w' || str2[i] == 'e' || str2[i] == 'l' || str2[i] == 'c' || str2[i] == 'o' || str2[i] == 'm'
 			|| str2[i] == ' ' || str2[i] == 't' || str2[i] == 'd' || str2[i] == 'j' || str2[i] == 'a') {
 				str1[k++] = str2[i];	
 			}
 			i++;
 		}
 		str1[k] = '\0';
 		
 		for (i = 0; i < k; i++) {
 			total[i] = 0;	
 		}
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'm') {
 				total[i] = 1;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'm') {
 				r = r + total[i];	
 				r = r%10000;
 			} else if (str1[i] == 'a') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'a') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'j') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'j') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == ' ') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == ' ') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'e') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'e') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'd') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'd') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'o') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'o') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'c') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'c') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == ' ') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == ' ') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'o') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'o') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 't') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 't') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == ' ') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == ' ') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'e') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'e') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'm') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'm') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'o') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'o') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'c') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'c') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'l') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'l') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'e') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'e') {
 				r = r + total[i];
 				r = r%10000;	
 			} else if (str1[i] == 'w') {
 				total[i] = r;	
 			}	
 		}
 		r = 0;
 		for (i = k-1; i >= 0; i--) {
 			if (str1[i] == 'w') {
 				r = r + total[i];	
 				r = r%10000;
 			}	
 		}
 		if (r < 10) {
 			printf("Case #%d: 000%d\n", o, r);
 		} else if (r < 100) {
 			printf("Case #%d: 00%d\n", o, r);
 		} else if (r < 1000) {
 			printf("Case #%d: 0%d\n", o, r);
 		} else {
 			printf("Case #%d: %d\n", o, r);
 		}
 	}
 	return 0;	
 }

