//#define DBG
 
 #include<stdio.h>
 #include<string.h>
 
 //    0
 // 1    2
 //    3
 #define SINK -1
 #define NORTH 0
 #define WEST 1
 #define EAST 2
 #define SOUTH 3
 
 int dx[4] = {0, -1, 1, 0};
 int dy[4] = {-1, 0, 0, 1};
 
 int map[102][102];
 int basin[102][102];
 int current;
 
 int mark(int x, int y);
 
 int main()
 {
 int i, x, y, cases, xmax, ymax;
 
 scanf("%d", &cases);
 
 #ifdef DBG	//HarryDBG
 printf("%d cases.\n", cases);
 #endif		//HarryDBG
 
 //loop for each case i
 for(i = 0; i < cases; i++) {
 	
 	//input the size
 	scanf("%d %d", &ymax, &xmax);
 
 #ifdef DBG	//HarryDBG
 printf("Case #%d: %dx%d\n", i+1, xmax, ymax);
 #endif		//HarryDBG
 
 	//input the map
 	for(y = 1; y <= ymax; y++)
 		for(x = 1; x <= xmax; x++)
 			scanf("%d", &map[y][x]);
 
 #ifdef DBG	//HarryDBG
 printf("Map #%d:\n", i+1);
 for(y = 1; y <= ymax; y++) {
 	for(x = 1; x <= xmax; x++)
 		printf("%d ", map[y][x]);
 	printf("\n");
 }
 #endif		//HarryDBG
 
 	for(y = 0; y <= ymax; y++) {
 		map[y][0] = 10001;
 		map[y][xmax+1] = 10001;			
 	}
 
 	for(x = 0; x <= xmax; x++) {
 		map[0][x] = 10001;
 		map[ymax+1][x] = 10001;
 	}
 
 
 	//process
 	memset(basin, -1, sizeof(basin));
 	current = 0;
 	for(y = 1; y <= ymax; y++)
 		for(x = 1; x <= xmax; x++) {
 			mark(x, y);
 		}
 		
 	//output
 	printf("Case #%d:\n", i+1);
 	for(y = 1; y <= ymax; y++) {
 		for(x = 1; x <= xmax; x++)
 			printf("%c ", basin[y][x] + 'a');
 		printf("\n");
 	}
 }
 
 
 
 return 0;
 }
 
 
 int mark(int x, int y)
 {
 int direction, low, lowdir;
 
 low = map[y][x];
 lowdir = SINK;
 for(direction = NORTH; direction <= SOUTH; direction++) {
 	if(low > map[y+dy[direction]][x+dx[direction]]) {
 		low = map[y+dy[direction]][x+dx[direction]];
 		lowdir = direction;
 	}
 }
 
 if(lowdir != SINK) {
 	basin[y][x] = mark(x+dx[lowdir], y+dy[lowdir]);
 }
 else if(basin[y][x] == -1) {
 	basin[y][x] = current++;
 }
 
 return basin[y][x];
 }
 
 

