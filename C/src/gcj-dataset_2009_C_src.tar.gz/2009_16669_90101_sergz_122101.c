#include <stdio.h>
 #include <stdlib.h>
 
 int
 count(char* s, char* c) {
   int n = 0;
 
   if(*c != 0) {
     while(*s != 0) {
       if(*s == *c) {
         n += count(s+1, c+1);
       }
       s++;
     }
   } else {
     n = 1;
   }
 
   return n;
 }
 
 int
 present(char* a, char c) {
   int result = 0;
 
   while((result == 0) && (*a != 0)) {
     result = (c == *a);
     a++;
   }
 
   return result;
 }
 
 void
 compress(char* s, char* alphabet) {
   char* c = s;
 
   while(*s != 0) {
     if(present(alphabet, *s)) {
       *c = *s;
       c++;
     }
     s++;
   }
   *c = 0;
 }
 int
 main(int argc, char** argv) {
   int n = 0;
   char sub[] = "welcome to code jam";
   int i;
   char line[512];
 
   scanf("%d\n", &n);
 
   for(i = 0; i < n; i++) {
     gets(line);
 
     printf("Case #%d: %4.4d\n", i+1, count(line, sub));
   }
 
   return 0;
 }

