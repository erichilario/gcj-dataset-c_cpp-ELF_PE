#include <stdio.h>
 
 int markIt(int iMap[100][100], char iRes[100][100], int iMarked[100][100], int i, int j, int iH, int iW, int *usedSymb)
 {
 	int iMinX = i, iMinY = j;
 
         if (! iMarked[i][j])
         {
 	        if (i>0)
 	        if (iMap[i-1][j] < iMap[iMinX][iMinY])
         	        {iMinX = i-1; iMinY = j; }
 
 	        if (j>0)
         	if (iMap[i][j-1] < iMap[iMinX][iMinY])
                 	{iMinX = i; iMinY = j-1; }
 
 	        if (j+1<iW)
         	if (iMap[i][j+1] < iMap[iMinX][iMinY])
                 	{iMinX = i; iMinY = j+1; }
 
 	        if (i+1<iH)
         	if (iMap[i+1][j] < iMap[iMinX][iMinY])
                 	{iMinX = i+1; iMinY = j; }
 
                 if ((iMinX != i) || (iMinY != j))
                         markIt(iMap, iRes, iMarked, iMinX, iMinY, iH, iW, usedSymb);
 
 
 		if (iMarked[iMinX][iMinY])
 		{
 			iRes[i][j] = iRes[iMinX][iMinY];
 			iMarked[i][j] = 1;
 		}
 		else
 		{
 			iRes[i][j] = (char) ('a' + (*usedSymb));
 			iMarked[i][j] = 1;
 	
                         	(*usedSymb)++;
 		}
 		
 	}
 
 	return 0;
 }
 
 int doIt(int iMap[100][100], char iRes[100][100], int iH, int iW)
 {
 	int iMarked[100][100], i, j, iMinX, iMinY;
         for(i=0; i<iH; i++)
         for(j=0; j<iW; j++)
         	iMarked[i][j] = 0;
 
 	int usedSymb = 0;
 
 	for(i=0; i<iH; i++)
 	for(j=0; j<iW; j++)
 		markIt(iMap, iRes, iMarked, i, j, iH, iW, &usedSymb);
 
 	return 0;
 }
 
 
 int main()
 {
 	int iH, iW, iT, i, j, k;
 	int iMap[100][100];
 	char iRes[100][100];
 
 	scanf("%d", &iT);
 
 	for(i=0; i<iT; i++)
 	{
 		scanf("%d %d", &iH, &iW);
 
 		for(j=0; j<iH; j++)
 		for(k=0; k<iW; k++)
 			scanf("%d", &(iMap[j][k]));
 
 		doIt(iMap, iRes, iH, iW);
 
 		printf("Case #%d:\n", i+1);
 
                 for(j=0; j<iH; j++)
 		{
 	                for(k=0; k<iW; k++)
 				printf("%c ", iRes[j][k]);
 			printf("\n");
 		}
 	}
 
 	return 0;
 }
 

