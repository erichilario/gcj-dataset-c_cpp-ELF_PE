// GCJ Qualifications 2009, Problem A
 // Lucas Garron
 
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 //Possible improvements:
 // - start search at pointer for first 'w'
 // - Parse through the string and take out any characters not in jamstr
 
 #define MAX_LINE_LENGTH 1024
 #define MAX_L 20 //Includes \0
 #define MAX_D 5100
 #define MAX_N 510
 
 int is_word(char* str, char* form, int L)
 {
 //	printf("- %s %s %d\n", str, form, L);
 
 	int l, i=0;
 	for(l=0; l<=L; ++l)
 	{
 //		printf("%c", str[l]);
 		if(form[i]=='(')
 		{
 			int okay=0;
 			++i;
 			while(form[i]!=')')
 			{
 				if(form[i]==str[l])
 					okay=1;
 				++i;
 			}
 			if(okay==0)
 				return 0;
 		}			
 		else
 			if (form[i]!=str[l])
 				return 0;
 		++i;
 	}
 
 	return 1;
 }
 
 int main(int argc, char** argv)
 {
   printf("\nBeginning problem A, %s\n", argv[1]);
 
   FILE *file;
   FILE *fileout;
   char buffer[MAX_LINE_LENGTH];
   int L, l, D, d, N, n, count, line;
 
   file = fopen(argv[1], "r");
   fileout = fopen(argv[2], "w");
   if (file == NULL || fileout == NULL) {
     printf("Couldn't open file %s or %s\n", argv[1], argv[2]);
     return -1;
   }
 
   fscanf(file, "%d %d %d", &L, &D, &N);
   printf("L: %d, D: %d, N: %d\n", L, D, N);
   
 	char di[MAX_D][MAX_L];
 	char wo[MAX_LINE_LENGTH];
 
 	for(d=0; d<D; ++d)
 {
 printf("%s, ", di[d]);
 	  fscanf(file, "%s", di[d]);
 }
 
 	//for(d=0; d<D; ++d)
 	//  printf("%s, ", di[d]);
 
 	line=0;
 	for(n=0; n<N; ++n)
 	{
 	  fscanf(file, "%s", wo);
 		
 		count=0;
 		for(d=0; d<D; ++d)
 			count += is_word(di[d], wo, L);		
 
 		++line;
 		printf("Case #%d: %d\n", line, count);
 		fprintf(fileout, "Case #%d: %d\n", line, count);
 	}
 
   return 0;
 }
