#include <stdio.h>
 #include <stdlib.h>
 #include <assert.h>
 #include <string.h>
 #define BUF_SIZE 5000
 int permute(char input[], char test[], int start[],int end[],int current[], int wordLength);
 static int cmpr(const void *a, const void *b) { 
  return strcmp(*(char **)a, *(char **)b);
 }
 
 void sortstrarr(void *array, unsigned n) { 
  qsort(array, n, sizeof(char *), cmpr);
 }
 
 int main(void) {
    int dummy;
 
    FILE *fp;
    fp = fopen("input.txt", "r");
    int wordLength,dictionarySize,tests;
    assert(fscanf(fp, "%d %d %d", &wordLength, &dictionarySize, &tests)==3);
    
    int i;
    char *dictionary[dictionarySize];
    
    
    for (i=0;i<dictionarySize;i++) {
       dictionary[i] = malloc(sizeof(char)*(wordLength+1));
       dummy = fscanf(fp, "%s", dictionary[i]);
       dictionary[i][wordLength] = '\0';
    }
    
    int results[tests];
    for (i=0;i<tests;i++) {
       results[i] = 0;
    }
    
    
    /*sortstrarr(dictionary, dictionarySize);*/
 
    for (i=0;i<tests;i++) {
 
       char input[BUF_SIZE];
       int start[wordLength];
       int end[wordLength];
 
       dummy = fscanf(fp, "%s", input);
       //printf("%s\n",input);
       int j;
       int k =0;
       
       for(j=0;j<strlen(input); j++) {
          if(input[j] == '(') {
             start[k] = j+1;
             
             while(input[j]!=')') {
              j++;
             }
             end[k] = j-1;
             k++;
          } else if (input[j] != ')') {
             start[k] = j;
             end[k] = j;
             k++;
          }      
       }
       
       int p;
       for (p=0;p<dictionarySize;p++) {
          int j=0;
          while (j<wordLength) {
             int k=start[j];
             int continuek = 1;
             while(k<=end[j] && continuek) {
                if(dictionary[p][j] == input[k]) {
                   continuek = 0;
                }
                k++;
             }
             if (continuek == 1) {
                j = wordLength;
             } else {
                j ++;
                if(j==wordLength) {
                   results[i]++;
                }
             }
          }
       }
    }
    for (i=0;i<tests;i++) {
       printf("Case #%d: %d\n",i+1,results[i]);
    }
    return 0;
 }      /*
       for(j=0;j<wordLength; j++){
          current[j]=start[j];
          test[j] = input[current[j]];
       }
 
       test[wordLength] = '\0';
       do {
          printf("%s\n",test);
          if (bsearch(&test,dictionary,dictionarySize,sizeof(char *),cmpr) != NULL) {
             result++;
          }
       } while(permute(input,test,start,end,current,wordLength));
    
       free(test);
       
       
       printf("Case #%d: %d\n",cases,result);
       cases++;*/
 
 /*
 int permute(char input[],char test[],int start[],int end[],int current[], int wordLength) {
    current[0]++;
    int i;
    int returnVar = 1;
    
    for(i=0;i<wordLength;i++) {
       if(current[i]>end[i]) {
          if(i<wordLength-1) {
             current[i] = start[i];
             current[i+1]++;
          } else {
             returnVar = 0;
          }
       }
       test[i] = input[current[i]];
    }
    
    return returnVar;
 }*/

