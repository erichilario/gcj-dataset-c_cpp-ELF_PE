#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 void main(void) {
   int num_problems;
   int problem;
   char* welcome = "welcome to code jam";
   unsigned int ret[strlen(welcome)];
   const int wel_len = strlen(welcome);
 
   scanf("%d\n", &num_problems);
 
   for (problem = 1; problem <= num_problems; problem++) {
     int len;
     int i;
     char c;
     for (i = 0; i < wel_len; i ++)
       ret[i] = 0;
 
     printf("Case #%d: ", problem);
     while (c = getchar()) {
       int j;
 
       if (c == '\n') break;
       for (j = wel_len - 1; j >= 0 ; j --) {
 	if (welcome[j] == c) {
 	  int previous = (j == 0) ? 1 : ret[j-1];
 	  ret[j] += previous;
 	  ret[j] %= 10000;
 	}
       }
     }
     printf("%04d\n", ret[wel_len - 1]);
   }
 }

