#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int find_pattern(char *text,char str[],int pos,int beg){
 
 	int i;
 	int len,cnt;		
 	
 	len= strlen(text);
 	
 	if(pos==strlen(str))
 	 return(1);		
 
 	cnt=0;
 	for(i=beg;i<len;i++)
 		if(text[i]==str[pos])	
 			cnt+= find_pattern(text,str,pos+1,i+1);
 	
 	return(cnt);	
 }
 
 int main(){
 	
 	int N;
 	int i,j,k;
 	int *out;
 	char **input,ch;
 	char str[]= "welcome to code jam";	
 
 	scanf("%d ",&N);
 	out=(int *)malloc(sizeof(int)*N);
 	input= (char **)malloc(sizeof(char *)*N);
 		
 	for(i=0;i< N;i++){
 		input[i]= (char *)malloc(sizeof(char)*600);
 		j=0;
 				
 		ch=getchar();
 		while(ch!='\n'){	
 		 input[i][j++]= ch;	
 		 ch=getchar();
 		}
 		input[i][j++]= '\0';
 	 }	
 	
 	
 	for(i=0;i<N;i++)
 	  out[i]= find_pattern(input[i],str,0,0)%10000;
 	
 	for(i=0;i<N;i++){
 	  if(out[i]<10)	
 	   printf("Case #%d: 000%d\n",i+1,out[i]);
 	  else if(out[i]<100)
 	   printf("Case #%d: 00%d\n",i+1,out[i]);	
 	  else if(out[i]<1000)
 	   printf("Case #%d: 0%d\n",i+1,out[i]);
    	  else 	
 	   printf("Case #%d: %d\n",i+1,out[i]);		  
 	}
 
 	return 1;		
 }
 
 

