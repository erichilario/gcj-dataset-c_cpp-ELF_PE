#include <stdio.h>
 #include <string.h>
 
 int main()
 {
 	int n;
 	scanf("%d",&n);
 	int ni;
 	char str[501];
 	long long cnt[502][20];
 	int len;
 	int si;
 	gets(str);
 	for (ni=1;ni<=n;ni++)
 	{
 		gets(str);
 		len=strlen(str);
 		for (si=0;si<len;si++)
 			cnt[si][0]=0;
 		for (si=0;si<20;si++)
 			cnt[0][si]=0;
 		for (si=0;si<len;si++)
 		{
 			if (str[si]=='w')
 			{
 				cnt[si+1][1]=cnt[si][1]+1;
 			}
 			else
 			{
 				cnt[si+1][1]=cnt[si][1];
 			}
 			if (str[si]=='e')
 			{
 				cnt[si+1][2]=cnt[si][1]+cnt[si][2];
 				cnt[si+1][7]=cnt[si][6]+cnt[si][7];
 				cnt[si+1][15]=cnt[si][14]+cnt[si][15];
 			}
 			else
 			{
 				cnt[si+1][2]=cnt[si][2];
 				cnt[si+1][7]=cnt[si][7];
 				cnt[si+1][15]=cnt[si][15];
 			}
 			if (str[si]=='l')
 			{
 				cnt[si+1][3]=cnt[si][2]+cnt[si][3];
 			}
 			else
 			{
 				cnt[si+1][3]=cnt[si][3];
 			}
 			if (str[si]=='c')
 			{
 				cnt[si+1][4]=cnt[si][3]+cnt[si][4];
 				cnt[si+1][12]=cnt[si][11]+cnt[si][12];
 			}
 			else
 			{
 				cnt[si+1][4]=cnt[si][4];
 				cnt[si+1][12]=cnt[si][12];
 			}
 			if (str[si]=='o')
 			{
 				cnt[si+1][5]=cnt[si][4]+cnt[si][5];
 				cnt[si+1][10]=cnt[si][9]+cnt[si][10];
 				cnt[si+1][13]=cnt[si][12]+cnt[si][13];
 			}
 			else
 			{
 				cnt[si+1][5]=cnt[si][5];
 				cnt[si+1][10]=cnt[si][10];
 				cnt[si+1][13]=cnt[si][13];
 			}
 			if (str[si]=='m')
 			{
 				cnt[si+1][6]=cnt[si][5]+cnt[si][6];
 				cnt[si+1][19]=cnt[si][18]+cnt[si][19];
 			}
 			else
 			{
 				cnt[si+1][6]=cnt[si][6];
 				cnt[si+1][19]=cnt[si][19];
 			}
 			if (str[si]==' ')
 			{
 				cnt[si+1][8]=cnt[si][7]+cnt[si][8];
 				cnt[si+1][11]=cnt[si][10]+cnt[si][11];
 				cnt[si+1][16]=cnt[si][15]+cnt[si][16];
 			}
 			else
 			{
 				cnt[si+1][8]=cnt[si][8];
 				cnt[si+1][11]=cnt[si][11];
 				cnt[si+1][16]=cnt[si][16];
 			}
 			if (str[si]=='t')
 			{
 				cnt[si+1][9]=cnt[si][8]+cnt[si][9];
 			}
 			else
 			{
 				cnt[si+1][9]=cnt[si][9];
 			}
 			if (str[si]=='d')
 			{
 				cnt[si+1][14]=cnt[si][13]+cnt[si][14];
 			}
 			else
 			{
 				cnt[si+1][14]=cnt[si][14];
 			}
 			if (str[si]=='j')
 			{
 				cnt[si+1][17]=cnt[si][16]+cnt[si][17];
 			}
 			else
 			{
 				cnt[si+1][17]=cnt[si][17];
 			}
 			if (str[si]=='a')
 			{
 				cnt[si+1][18]=cnt[si][17]+cnt[si][18];
 			}
 			else
 			{
 				cnt[si+1][18]=cnt[si][18];
 			}
 		}
 		printf("Case #%d: %04ld\n",ni,cnt[len][19]%10000);
 	}
 }

