#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 char sink;
 
 char findSink(int i, int j, int h, int w, int * map, int *result) {
     char r;
     int dn,ds,de,dw,dp;
     if (result[i * w + j] != 0) {
         return result[i * w + j];
     }
     dn = (i != 0)        ? map[(i-1) * w + j] : 10000;
     ds = (i != h - 1)    ? map[(i+1) * w + j] : 10000;
     dw = (j != 0)        ? map[i * w + j - 1] : 10000;
     de = (j != w - 1)    ? map[i * w + j + 1] : 10000;
     dp =  map[i * w + j];
 
     if (dn < dp && dn <= dw && dn <= de && dn <= ds) {
         r = findSink(i - 1, j, h, w, map, result);
     } else if (dw < dp && dw < dn && dw <= de && dw <= ds) {
         r = findSink(i, j - 1, h, w, map, result);
     } else if (de < dp && de < dn && de < dw && de <= ds) {
         r = findSink(i, j + 1, h, w, map, result);
     } else if (ds < dp && ds < dn && ds < dw && ds < de) {
         r = findSink(i + 1, j, h, w, map, result);
     } else {
         r = sink++;
     }
     result[i * w + j] = r;
     return r;
 }
 
 int main() {
     int t, h, w;
     int k, i, j;
     int * map = malloc(100 * 100 * sizeof(int));
     int * result = malloc(100 * 100 * sizeof(int));
     scanf("%d\n", &t);
 
     for (k = 0; k < t; k++) {
         scanf("%d %d\n", &h, &w);
         for(i = 0; i < h; i++) {
             for(j = 0; j < w; j++) {
                 scanf("%d", map + i * w + j);
             }
         }
         /*
         for(i = 0; i < h; i++) {
             for(j = 0; j < w; j++) {
                 printf("%d", map[i * w + j]);
             }
             putchar('\n');
         }
         */
         memset(result, 0, h * w * sizeof(int));
         sink = 'a';
         for(i = 0; i < h; i++) {
             for(j = 0; j < w; j++) {
                 findSink(i, j, h, w, map, result);
             }
         }
         printf("Case #%d:\n",k+1);
         for(i = 0; i < h; i++) {
             for(j = 0; j < w; j++) {
                 putchar(result[i * w + j]);
                 if(j != w-1) {
                     putchar(' ');
                 }
             }
             putchar('\n');
         }
     }
 }

