#include <stdio.h>
 
 int main(void)
 {
 	char ch,words[25][10],pattern[500],bracket_indexes[10][1];
 	int i,j,k,l,len,index,match_count,L,D,N,Total_matches;
 	FILE *fp,*wp;
 	fp = fopen("A-small.txt","r");
 	wp = fopen("A-small.out","w");
 	fscanf(fp,"%d %d %d",&L,&D,&N);
 	
 	for(i=0;i<D;++i)
 		fscanf(fp,"%s",words[i]);
 	
 	for(i=0;i<N;++i)
 	{
 		fscanf(fp,"%s",pattern);
 		Total_matches = 0;
 		for(j=0;j<D;++j)
 		{
 			len = strlen(pattern);
 			index = 0;
 			match_count = 0;
 			for(k=0;k<L && index < len;++k)
 			{
 				if(pattern[index] == '(')
 				{
 					ch = pattern[++index];
 					while(ch!=')')
 					{
 						if(words[j][k]==ch)
 						{
 							++match_count;
 							while(ch!=')')
 								ch = pattern[++index];	
 							break;
 						}
 						ch = pattern[++index];
 					}
 				}
 				else if(words[j][k]==pattern[index])
 					++match_count;
 				++index;
 				if(match_count != k+1)	
 					break;
 			}
 			if(match_count == L)
 				++Total_matches;
 		}
 		fprintf(wp,"Case #%d: %d\n",i+1,Total_matches);
 	}
 	fclose(fp);
 	fclose(wp);
 	return 0;
 }

