#include <string.h>
 #include <stdio.h>
 #include <stdlib.h>
 
 char* keystring = "welcome to code jam";
 int count = 0;
 
 int findInBigString(char* bigstring, int ikey)
 {
 	printf("%c %d\n", *bigstring, ikey);
 	int tibig = 0;
 	int flag = 0;
 	char testchar = keystring[ikey];
 	while ((bigstring[tibig] != '\0') && (bigstring[tibig] != testchar)) tibig++;
 	if (bigstring[tibig] == '\0') return -1;
 	else
 	{
 		if (ikey == 18)
 		{
 			count++;
 			//return tibig;
 		}
 		else
 		{
 			flag = tibig;
 			while (flag != -1)
 			{
 				bigstring = bigstring + flag + 1;
 				flag = findInBigString(bigstring, ikey + 1);
 				//if (tibig == flag) flag = -1;
 			}
 		}
 		return tibig;
 	}
 }
 
 int main()
 {
 	char* bigstring = "welcome to code jam";
 	int drop = findInBigString(bigstring, 0);
 	while (drop != -1)
 	{
 		bigstring = bigstring + drop + 1;
 		drop = findInBigString(bigstring, 0);
 	} 
 	printf("%d", count);
 	return 0;
 }
 

