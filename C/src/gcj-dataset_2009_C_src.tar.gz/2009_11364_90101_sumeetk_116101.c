#include<stdio.h>
 #include<conio.h>
 
 
 int l,d,n;
 
 char words[5001][16];
 
 struct test
 {
        char word[(15*26) + (2*15)];
        int cnt;
 }tcase[500];
 
 int valid[5000];
 void main()
 {
      int i,j,k,lcnt,match,p;
      scanf("%d%d%d",&l,&d,&n);
      
      for(i=0; i<d; i++)
      {
           scanf("%s",words[i]);
      }
      
      for(i=0; i<n; i++)
      {
           scanf("%s",tcase[i].word);
           tcase[i].cnt = 0;
      }
 
      for(i=0; i<n; i++)
      {
              for(j=0; j<d; j++)
              {
                       valid[j]=1;
              }
              
              for(j=0, lcnt=0; j<l; j++, lcnt++)
              {
                       if(tcase[i].word[lcnt] == '(' )
                       {                         
                           for(k=0; k<d; k++) 
                           {
                               p = lcnt;
                               match = 0;
                               while(tcase[i].word[++p] != ')')
                               {
                                   if(words[k][j] == tcase[i].word[p])
                                   {
                                       match = 1;
                                       break;
                                   }                                  
                               }
                               if(!match)
                               {
                                   valid[k]=0;
                               }
                           }
                           
                           while(tcase[i].word[++lcnt] != ')');
                       }
                       else
                       {
                           for(k=0; k<d; k++)
                           {
                                    if(words[k][j]!=tcase[i].word[lcnt])
                                    {
                                        valid[k] = 0;
                                    }
                           }
                       }
              }
              
              for(k=0; k<d; k++)
              {
                       if(valid[k])
                       {
                           (tcase[i].cnt)++;
                       }
              }
              
              printf("Case #%d: %d\n", i+1, tcase[i].cnt);
      }   
      
      getch();
 }

