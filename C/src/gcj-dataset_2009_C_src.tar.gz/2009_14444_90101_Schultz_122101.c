#include <stdio.h>
 #include <string.h>
 
 #define NMAX 500
 #define LSZ  10000
 static char line [LSZ];
 static int  dp   [2][NMAX+1];
 
 #define GETS() fgets(line, sizeof(line)/sizeof(char), stdin), line[strlen(line)-1] = '\0'
 
 static const char pat[] = "welcome to code jam";
 
 int main(void) {
 	int tc, cs;
 	int m, n, i, j;
 	int *old, *new, *tmp;
 
 	GETS();
 	sscanf(line, "%d", &tc);
 	for (cs = 0; cs != tc; ++cs) {
 		GETS();
 		m = strlen(pat);
 		n = strlen(line);
 
 		old = dp[0];
 		new = dp[1];
 
 		for (i = 0; i <= n; ++i)
 			old[i] = 1;
 		for (i = m; i-- != 0;) {
 			new[n] = 0;
 			for (j = n; j-- != 0;) {
 				new[j] = new[j+1];
 				if (pat[i] == line[j])
 					new[j] = (new[j] + old[j+1])%10000;
 			}
 
 			tmp = new;
 			new = old;
 			old = tmp;
 		}
 
 		printf("Case #%d: %04d\n", cs+1, old[0]);
 	}
 
 	return 0;
 }
 
 

