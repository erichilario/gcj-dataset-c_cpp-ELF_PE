#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 #include <assert.h>
 
 /* Error checking is not being performed because the input file is assumed to be from
    a trusted source. */
 
 /* Use the limits for the large input, performance and resources are not important factors
    for this problem. */
 
 #define HW_LIMIT 100
 #define T_LIMIT 100
 
 enum
 {
 	NONE = 0,
 	NORTH = 1,
 	WEST = 2,
 	EAST = 3,
 	SOUTH = 4
 };
 
 typedef struct MAP
 {
 	int map[HW_LIMIT][HW_LIMIT];
 	int dir[HW_LIMIT][HW_LIMIT];
 	int H;
 	int W;
 } MAP;
 
 MAP maps[T_LIMIT];
 
 static void waterBuildMaps(FILE *file, int T);
 static void waterLabelBasins(FILE *file, int T);
 
 int main(int argc, char *argv[])
 {
 	FILE *file;
 	int rc;
 	int T = 0;
 
 #ifdef LOG
 	int m, h, w;
 #endif
 
         assert(argc == 2);
 
 	file = fopen(argv[1], "r");
 	assert(file != NULL);
 
         rc = fscanf(file, "%d", &T);
 	assert(rc == 1);
 
 #ifdef LOG
 	printf("T %d\n", T);
 #endif
 
 	waterBuildMaps(file, T);
 
 #ifdef LOG
 	for (m = 0; m < T; m++)
 	{
 		for (h = 0; h < maps[m].H; h++)
 		{
 			for (w = 0; w < maps[m].W; w++)
 			{
 				printf("map %d h %d w %d a %d\n", m, h, w, maps[m].map[h][w]);
 			}
 		}
 	}
 #endif
 
 	waterLabelBasins(file, T);
 
 	return(0);
 }
 
 static void waterBuildMaps(FILE *file, int T)
 {
 	int m, h, w;
 	int rc;
 
 	for (m = 0; m < T; m++)
 	{
 		rc = fscanf(file, "%d %d", &maps[m].H, &maps[m].W);
 		assert(rc == 2);
 
 		for (h = 0; h < maps[m].H; h++)
 		{
 			for (w = 0; w < maps[m].W; w++)
 			{
 				rc = fscanf(file, "%d", &maps[m].map[h][w]);
 				assert(rc == 1);
 			}
 		}
 	}
 }
 
 static void waterLabelBasins(FILE *file, int T)
 {
 	int m, h, w;
 	int more;
 	int min;
 	char label = 'a';
 	char basin[HW_LIMIT][HW_LIMIT];
 
 	for (m = 0; m < T; m++)
 	{
 		memset(basin, 0, sizeof(basin));
                 label = 'a';
 
 		for (h = 0; h < maps[m].H; h++)
 		{
 			for (w = 0; w < maps[m].W; w++)
 			{
 				maps[m].dir[h][w] = NONE;
 				min = maps[m].map[h][w];
 
 				if (h > 0 && maps[m].map[h - 1][w] < min)
 				{
 					maps[m].dir[h][w] = NORTH;
 					min = maps[m].map[h - 1][w];
 				}
 
 				if (w > 0 && maps[m].map[h][w - 1] < min)
 				{
 					maps[m].dir[h][w] = WEST;
 					min = maps[m].map[h][w - 1];
 				}
 
 				if (w != maps[m].W - 1 && maps[m].map[h][w + 1] < min)
 				{
 					maps[m].dir[h][w] = EAST;
 					min = maps[m].map[h][w + 1];
 				}
 
 				if (h != maps[m].H - 1 && maps[m].map[h + 1][w] < min)
 				{
 					maps[m].dir[h][w] = SOUTH;
 					min = maps[m].map[h + 1][w];
 				}
 			}
 		}
 
 		/* The top left is always labeled basin a, find the sink for this basin. */
 		h = 0;
 		w = 0;
 		basin[h][w] = label;
 
 		while (maps[m].dir[h][w] != NONE)
 		{
 			if (maps[m].dir[h][w] == NORTH)
 			{
 				h--;
 			}
 		       	else if (maps[m].dir[h][w] == WEST)
 			{
 				w--;
 			}
 		       	else if (maps[m].dir[h][w] == EAST)
 			{
 				w++;
 			}
 		       	else if (maps[m].dir[h][w] == SOUTH)
 			{
 				h++;
 			}
 
 			basin[h][w] = label;
 		}
 
 		label++;
 
 		/* Assign labels to the remaining sinks. */
 		for (h = 0; h < maps[m].H; h++)
 		{
 			for (w = 0; w < maps[m].W; w++)
 			{
 				if (maps[m].dir[h][w] == NONE && basin[h][w] == 0)
 				{
 					/* If we don't flow into anyone we're a new basin */
 					basin[h][w] = label++;
 				}
 			}
 		}
 
 		/* Let the water flow! */
 
 		more = 1;
 		while (more == 1)
 		{
 			more = 0;
 
 			for (h = 0; h < maps[m].H; h++)
 			{
 				for (w = 0; w < maps[m].W; w++)
 				{
 					/* Take the label of the neighbor we are flowing to if it has one. */
 
 					if (basin[h][w] != 0)
 					{
 						continue;
 					}
 
 					if (maps[m].dir[h][w] == NORTH && basin[h - 1][w] != 0)
 					{
 						basin[h][w] = basin[h - 1][w];
 					}
 					else if (maps[m].dir[h][w] == SOUTH && basin[h + 1][w] != 0)
 					{
 						basin[h][w] = basin[h + 1][w];
 					}
 					else if (maps[m].dir[h][w] == EAST && basin[h][w + 1] != 0)
 					{
 						basin[h][w] = basin[h][w + 1];
 					}
 					else if (maps[m].dir[h][w] == WEST && basin[h][w - 1] != 0)
 					{
 						basin[h][w] = basin[h][w - 1];
 					}
 					else
 					{
 						/* We flow into a pool that does not have a label yet. */
 						more = 1;
 					}
 				}
 			}
 		}
 
 		printf("Case #%d:\n", m + 1);
 
 		for (h = 0; h < maps[m].H; h++)
 		{
 			for (w = 0; w < maps[m].W; w++)
 			{
 				printf("%c", basin[h][w]);
 
 				if (w != maps[m].W - 1)
 				{
 					printf(" ");
 				}
 				else
 				{
 					printf("\n");
 				}
 			}
 		}
 	}
 }
 

