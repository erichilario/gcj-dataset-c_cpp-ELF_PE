#include <stdio.h>
 unsigned long L,D,N,dict[5000][15],pat[15];
 int main()
 {
         scanf("%d %d %d\n",&L,&D,&N);
         for(unsigned long i=0; i<D; i++){
                 for(unsigned long j=0; j<L; j++){
                         char c=getchar();
 //                      printf("%d\n",c-'a');
                         dict[i][j]=1<<(c-'a');
 //                      printf("%d ",dict[i][j]);
                 }
                 scanf("\n");
 //              printf("\n");
         }
         for(unsigned long i=0; i<N; i++){
                 for(unsigned long j=0; j<L; j++)
                 {
                         pat[j]=0;
                         char c = getchar();
                         if(c=='('){
                                 c=getchar();
                                 while(c!=')'){
                                         pat[j]|=1<<(c-'a');
                                         c=getchar();
                                 }
                         }else pat[j]=1<<(c-'a');
                 }
                 scanf("\n");
                 unsigned int licz=0;
                 for(unsigned long j=0; j<D; j++){
                         unsigned long match=1;
                         for(unsigned long k=0; k<L && match; k++)
                                 if(!(pat[k]&dict[j][k]))match=0;
                         licz+=match;
                 }
                 printf("Case #%d: %d\n",i+1,licz);
         }
 }
 

