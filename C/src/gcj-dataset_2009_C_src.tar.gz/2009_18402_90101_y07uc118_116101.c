#include<stdio.h>
 int main()
 {
 	int i,j,k,n,l,m,col,v,x,p,q;
 	char a[6000][20],b[10000];
 	freopen("a.in","r",stdin);
 	freopen("c.txt","w",stdout);
 	scanf("%d%d%d",&l,&n,&m);
 	for(i=1;i<=n;i++)
 		scanf("%s",&a[i]);
 	
 	for(j=1;j<=m;j++)
 	{	scanf("%s",b);
 	 	 q=1; v=0;
 	 	while(q<=n)
 	 	{	col=0;
 			for(k=0;b[k]!='\0';k++)
 			{
 				p=0;
 				if(b[k]=='(')
 				{
 					k++; 
 					while(b[k]!=')')
 					{
 						if(a[q][col]==b[k])
 							p=1;
 						k++;
 					}
 					col++;
 					
 				}
 				else
 				{
 					if(a[q][col]==b[k])
 						p=1;
 					col++;
 				}
 				if(p==0)
 					break;
 			}
 			if(b[k]=='\0' && p==1)
 				v++;
 		q++;
 	 	}
 	 	printf("Case #%d: %d\n",j,v);
 	}
 	
 	return 0;
 }

