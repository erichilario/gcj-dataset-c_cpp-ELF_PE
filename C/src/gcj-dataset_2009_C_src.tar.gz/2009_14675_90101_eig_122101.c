#include <stdio.h>
 #define W 0
 #define E1 1
 #define L 2
 #define C1 3
 #define O1 4
 #define M1 5
 #define E2 6
 #define UN1 7
 #define T 8
 #define O2 9
 #define UN2 10
 #define C2 11
 #define O3 12
 #define D 13
 #define E3 14
 #define UN3 15
 #define J 16
 #define A 17
 #define M2 18
 
 #define MAXSTR 500
 char str[MAXSTR];
 int count[MAXSTR][20];
 
 int main(){
     int i,j,k,N,len,sum;
     freopen("C-large.in","r",stdin);
     gets(str);
     sscanf(str,"%d",&N);    
     
     for(i=0;i<N;i++){
         gets(str);
         sum=0;
         len = strlen(str);
         for(j=0;j<MAXSTR;j++){
             for(k=0;k<20;k++)
                 count[j][k]=0;    
         }
         for(j=len-1;j>=0;j--){
             if(str[j]=='m'){
                 count[j][M2]=1;
                 for(k=j+1;k<len;k++){
                     count[j][M1] += count[k][M1+1]%10000;
                 }
             }
             else if(str[j]=='a'){
                 for(k=j+1;k<len;k++)
                     count[j][A] += count[k][A+1]%10000;
             }
             else if(str[j]=='j'){
                 for(k=j+1;k<len;k++)
                     count[j][J] += count[k][J+1]%10000;
             }
             else if(str[j]==' '){
                 for(k=j+1;k<len;k++){
                     count[j][UN3] += count[k][UN3+1]%10000;
                     count[j][UN2] += count[k][UN2+1]%10000;
                     count[j][UN1] += count[k][UN1+1]%10000;
                 }
             }
             else if(str[j]=='e'){
                 for(k=j+1;k<len;k++){
                     count[j][E3] += count[k][E3+1]%10000;
                     count[j][E2] += count[k][E2+1]%10000;
                     count[j][E1] += count[k][E1+1]%10000;
                 }
             }
             else if(str[j]=='d'){
                 for(k=j+1;k<len;k++)
                     count[j][D] += count[k][D+1]%10000;
             }
             else if(str[j]=='o'){
                 for(k=j+1;k<len;k++){
                     count[j][O3] += count[k][O3+1]%10000;
                     count[j][O2] += count[k][O2+1]%10000;
                     count[j][O1] += count[k][O1+1]%10000;
                 }
             }
             else if(str[j]=='c'){
                 for(k=j+1;k<len;k++){
                     count[j][C2] += count[k][C2+1]%10000;
                     count[j][C1] += count[k][C1+1]%10000;
                 }
             }
             else if(str[j]=='t'){
                 for(k=j+1;k<len;k++){
                     count[j][T] += count[k][T+1]%10000;
                 }
             }
             else if(str[j]=='l'){
                 for(k=j+1;k<len;k++){
                     count[j][L] += count[k][L+1]%10000;
                 }
             }
             else if(str[j]=='w'){
                 for(k=j+1;k<len;k++){
                     count[j][W] += count[k][W+1]%10000;
                 }
             }/**/
         }
         /*for(j=18;j>=0;j--){
             for(k=0;k<len;k++){
                 printf("%d ",count[k][j]);
             }printf("a\n");
         }*/
         for(j=0;j<len;j++){
             sum+=count[j][W];    
         }
         printf("Case #%d: %04d\n",i+1,sum%10000);
     }
 }

