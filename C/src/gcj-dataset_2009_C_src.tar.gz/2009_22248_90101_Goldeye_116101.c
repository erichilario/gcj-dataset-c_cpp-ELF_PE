#include <stdio.h>
 #include <sys/types.h>
 #include <regex.h>
 #include <stdlib.h>
 
 int work(char *start, char *check) {
 	int count = 0;
 	if(*check == 0)
 		return 1;
 	if(*start == 0)
 		return 0;
 	while(*start != 0) {
 		if(*start == *check)
 			count += work(start + 1, check + 1);
 		start++;
 		if(count >= 10000)
 			count %= 10000;
 	}
 	return count;
 	//while(
 }
 
 int main(int argc, char **argv) {
 	char line[28*20];
 	char regstr[28*17];
 	char words[5000][17];
 	int L,D,N;
 	int r = 1;
 
 	gets(line);
 	sscanf(line,"%d %d %d",&L,&D,&N);
 	for(r=1;r <= D; r++) {
 		gets(words[r]);
 	}
 	for(r=1;r <= N; r++) {
 		gets(&(line[1]));
 		int i = 0;
 
 		//printf("Got line: %s\n",&(line[1]));
 		line[0]='/';
 		for(i=1; line[i] != 0; i++) {
 			if(line[i] == '(')
 				line[i] = '[';
 			if(line[i] == ')')
 				line[i] = ']';
 		}
 		line[i] = 0;//'/';
 		line[i+1] = 0;
 		//printf("made regex: %s\n",&line[1]);
 		regex_t preg;
 		int ret = regcomp(&preg,&line[1],0);
 		if(ret != 0) {
 			regerror(ret, &preg, line, 28*20);
 			fprintf(stderr,"REGCOMP FAIL: Case %d: %s\n",r,ret);
 			exit(-1);
 		}
 		int count = 0;
 		for(i=1;i<=D;i++) {
 			ret = regexec(&preg,words[i],0,0,0) ;
 			if(ret == 0)
 				count++;
 			else if(ret != REG_NOMATCH)
 				printf("ERROR\n");
 			//			else if(ret == REG_NOMATCH)
 			//	printf("No match.
 			
 		}
 		printf("Case #%d: %d\n",r,count);
 
 	}
 
 	return 148145;
 }

