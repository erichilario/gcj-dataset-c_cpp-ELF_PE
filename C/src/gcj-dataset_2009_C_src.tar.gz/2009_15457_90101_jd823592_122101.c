#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 const char cPattern[]="welcome to code jam";
 
 void search (char* aMatrix, char* aPattern, int* aCount);
 
 void search (char* aMatrix, char* aPattern, int* aCount)
 {
   int i=0;
 
   if (strlen(aPattern)==0)
   {
     (*aCount)++;
     (*aCount)%=10000;
   } else {
     while (i<strlen(aMatrix))
     {
       if (aMatrix[i]==aPattern[0])
         search(aMatrix+(i+1)*sizeof(char), aPattern+sizeof(char), aCount);
       i++;
     }
   }
 }
 
 int main (int argc, char** argv)
 {
   int n;
   char lLine[512];
   int i;
   int lOutput;
 
   scanf("%i\n", &n);
 
   for (i=0; i<n; i++)
   {
     int j=0;
 
     scanf("%c", lLine);
 
     while (lLine[j]!=10)
     {
       j++;
       scanf("%c", &lLine[j]);
     }
 
     lLine[j]=0;
 
     lOutput=0;
 
     search(lLine, (char*)cPattern, &lOutput);
 
     printf("Case #%i: %04i\n", i+1, lOutput);
   }
 
   return 0;
 }

