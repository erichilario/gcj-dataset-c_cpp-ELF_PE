#include<stdio.h>
 
 int grid[100][100];
 int sink_x,sink_y;
 int sinks[2][26];
 int sinks_found = 0;
 
 int find_basin(int,int,int,int);
 
 int main()
 {
     FILE * pFile;
     FILE * outFile;
     char c;
     char tmp[10];
     int n = 0;
     int temp1,temp2;
     int set_indx;
     int num_sets;
     char sets[4];
     int x=0,y=0,i=0,j=0;
     int x_temp,y_temp;
     int sinki,sinkj;
     
     sinki=sinkj=0;
     
     int print_i,print_j;
     char temp[3];
     char temp_alt[5];
     int num_found = 0,next_row=0;
     int found_sink = 0;
     
     pFile=fopen("B-large.in","r");
     outFile=fopen("B-large.out","w");
     if (pFile==NULL) perror ("Error opening file");
     else
     {
            sets[x]=fgetc(pFile);
                                 
            while(sets[x]!='\n')
            {
             x++;
             sets[x]=fgetc(pFile);
            }
            
             sets[x] = '\0';
                             
            num_sets = atoi(&sets);
            x=0;
            
            while(x<num_sets)
            {              
                      sinks_found = 0;
                      while(1)
                      {
                              temp[y]=fgetc(pFile);
                              
                              if(temp[y] == ' ')
                              {
                                 temp[y] = '\0';
                                 i=atoi(&temp);
                                 num_found = 1;
                              }
                              
                              if(temp[y] == '\n')
                              {
                                  temp[y] = '\0';
                                  j=atoi(&temp);
                                  break;
                              }
                              
                              if (num_found == 1)
                              {
                                 y=0;
                                 num_found = 0;
                              }
                              else y++;
                              
                      }
                      y=0;
                      x_temp = y_temp = 0;
                      
                      for(x_temp=0;x_temp<i;x_temp++)
                      {
                             num_found = 0;
                             for(y_temp=0;y_temp<j;y_temp++)
                             {
                                  while(1)
                                  {
                                     temp_alt[y] = fgetc(pFile);
                                     if((temp_alt[y] == ' ')||(temp_alt[y] == '\n')||(temp_alt[y] == EOF))
                                     {
                                              temp_alt[y] = '\0';
                                              grid[x_temp][y_temp] = atoi(&temp_alt);
                                              y=0;
                                              break;
                                     }
                                     else y++;
                                  }
                             }
                      }
                     sprintf(tmp,"Case #%d:\n",x+1);
                     fputs(tmp,outFile);
                     for(print_i=0;print_i<i;print_i++)
                     {
                             for(print_j=0;print_j<j;print_j++)
                             {
                                                 
                                 temp2=find_basin(i,j,print_i,print_j);
                                 for(sinkj=0;sinkj<sinks_found;sinkj++)
                                 {
                                     if((sinks[0][sinkj] == sink_x) && (sinks[1][sinkj] == sink_y))
                                     {
                                      sprintf(tmp,"%c",97+(sinkj));
                                      fputs(tmp,outFile);
                                      if(print_j == (j-1))
                                      {
                                      fputc('\n',outFile);
                                      }
                                      else
                                      {
                                          fputc(' ',outFile);
                                      }
                                      found_sink = 1;
                                      }
                                 }
                             
                     
                                 if(found_sink != 1)
                                 {
                                   sinks[0][sinkj] = sink_x;
                                   sinks[1][sinkj] = sink_y;
                                   sprintf(tmp,"%c",97+(sinkj));
                                   fputs(tmp,outFile);
                                   if(print_j == (j-1))
                                   {
                                      fputc('\n',outFile);
                                   }
                                      else
                                      {
                                           fputc(' ',outFile);
                                      }
                                   sinks_found++;
                                 }
                                 else
                                 {
                                     found_sink=0;
                                 }
                              }
                     
                     }   
                     x++;
            }                         
                                     
                                         
 
            fclose(pFile);
            fclose(outFile);
     }
   return 0;
  
 }
 
 int find_basin(int i, int j, int x, int y)
 {
      int orig_x = x;
      int orig_y = y;
      int lowest;
      int lowest_x,lowest_y;
      lowest_x = x;
      lowest_y = y;
      lowest = grid[x][y];
      if(x!=0)
      {
              if(grid[x-1][y]<lowest)
              {
                    lowest = grid[x-1][y];
                    lowest_x = x-1;
                    lowest_y = y;
              }
      }
      
      if(y!=0)
      {
               if(grid[x][y-1]<lowest)
              {
                    lowest = grid[x][y-1];
                    lowest_x = x;
                    lowest_y = y-1;
              } 
      }
      
      if(y!=j-1)
      {
               if(grid[x][y+1]<lowest)
              {
                    lowest = grid[x][y+1];
                    lowest_x = x;
                    lowest_y = y+1;
              } 
      }
      
      if(x!=i-1)
      {
               if(grid[x+1][y]<lowest)
              {
                    lowest = grid[x+1][y];
                    lowest_x = x+1;
                    lowest_y = y;
              } 
      }
      
      
      
  
      if(orig_x == lowest_x && orig_y == lowest_y)
      {
                sink_x=orig_x;
                sink_y=orig_y;
                return 0;
      }
      else
      return find_basin(i,j,lowest_x,lowest_y);
  }
     
                         
      
      

