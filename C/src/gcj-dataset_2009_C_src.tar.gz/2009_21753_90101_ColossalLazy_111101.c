#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct _Map
 {
 	int height[100][100];
 	int x,y;
 	char basin [100][100];
 	char menordir[100][100];
 } Map ;
 
 int _percorre(Map *,int,int,int);
 
 int main (void)
 {
 	int t,h,w;
 	int menor,totn;
 	int i,j,k;
 	char highb;
 
 	Map *map;
 
 	scanf("%d",&t);
 	map = (Map *) malloc (t * sizeof (Map));
 
 	for(i=0;i<t;i++)
 	{
 		scanf("%d%d",&h,&w);
 		map[i].x = w;
 		map[i].y = h;
 		for(k=0;k<h;k++)
 		{
 			for(j=0;j<w;j++)
 			{
 				scanf("%d",&map[i].height[j][k]);
 				map[i].menordir[j][k] = 'o';
 				map[i].basin[j][k] = '0';
 			}
 		}
 	}
 
 	for (i=0;i<t;i++)
 	{
 		for(k=0;k<map[i].y;k++)
 		{
 			for(j=0;j<map[i].x;j++)
 			{
 				menor = 10000;
 				if(k>0)
 				{
 					if((map[i].height[j][k-1]<menor) && (map[i].height[j][k-1]<map[i].height[j][k]))
 					{
 						menor = map[i].height[j][k-1];
 						map[i].menordir[j][k] = 'n';
 					}
 				}
 				if(j>0)
 				{
 					if((map[i].height[j-1][k]<menor) && (map[i].height[j-1][k]<map[i].height[j][k]))
 					{
 						menor = map[i].height[j-1][k];
 						map[i].menordir[j][k] = 'w';
 					}
 				}
 				if (j<map[i].x-1)
 				{
 					if((map[i].height[j+1][k]<menor) && (map[i].height[j+1][k]<map[i].height[j][k]))
 					{
 						menor = map[i].height[j+1][k];
 						map[i].menordir[j][k] = 'e';
 					}
 				}
 				if (k<map[i].y-1)
 				{
 					if((map[i].height[j][k+1]<menor) && (map[i].height[j][k+1]<map[i].height[j][k]))
 					{
 						menor = map[i].height[j][k+1];
 						map[i].menordir[j][k] = 's';
 					}
 				}
 			}
 		}
 	}
 
 	for(i=0;i<t;i++)
 	{
 		highb = 'b';
 		totn = 0;
 		for(k=0;k<map[i].y;k++)
 		{
 			for(j=0;j<map[i].x;j++)
 			{
 				if (j==0 && k==0)
 				{
 					map[i].basin[j][k]='a';
 					totn += _percorre(map,i,j,k);
 				}
 				if(map[i].basin[j][k]=='0' && highb<='z')
 				{
 					map[i].basin[j][k]=highb;
 					highb++;
 					totn += _percorre(map,i,j,k);
 				}
 
 				if (totn==map[i].y*map[i].x)
 				{
 					break;
 				}
 			}
 			if (totn==map[i].y*map[i].x)
 			{
 				break;
 			}
 		}
 	}
 
 	for(i=0;i<t;i++)
 	{
 		printf("Case #%d:\n",i+1);
 		for(k=0;k<map[i].y;k++)
 		{
 			for(j=0;j<map[i].x;j++)
 			{
 				printf("%c ",map[i].basin[j][k]);
 			}
 			printf("\n");
 		}
 	}
 	free(map);
 }
 
 int _percorre(Map *map,int i,int j,int k)
 {
 	int cont = 0;
 
 	if (k>0 && map[i].menordir[j][k-1] == 's' && map[i].basin[j][k-1]=='0')
 	{
 		map[i].basin[j][k-1]=map[i].basin[j][k];
 		cont++;
 		cont += _percorre(map,i,j,k-1);
 	}
 	if (j>0 && map[i].menordir[j-1][k] == 'e' && map[i].basin[j-1][k]=='0')
 	{
 		map[i].basin[j-1][k]=map[i].basin[j][k];
 		cont++;
 		cont += _percorre(map,i,j-1,k);
 	}
 	if (j<map[i].x-1 && map[i].menordir[j+1][k] == 'w' && map[i].basin[j+1][k]=='0')
 	{
 		map[i].basin[j+1][k]=map[i].basin[j][k];
 		cont++;
 		cont += _percorre(map,i,j+1,k);
 	}
 	if (k<map[i].y-1 && map[i].menordir[j][k+1] == 'n' && map[i].basin[j][k+1]=='0')
 	{
 		map[i].basin[j][k+1]=map[i].basin[j][k];
 		cont++;
 		cont += _percorre(map,i,j,k+1);
 	}
 
 	if(map[i].menordir[j][k]=='n')
 	{
 		if (map[i].basin[j][k-1]=='0')
 		{
 			map[i].basin[j][k-1]=map[i].basin[j][k];
 			cont++;
 			cont += _percorre(map,i,j,k-1);
 		}
 	}
 	if(map[i].menordir[j][k]=='w')
 	{
 		if (map[i].basin[j-1][k]=='0')
 		{
 			map[i].basin[j-1][k]=map[i].basin[j][k];
 			cont++;
 			cont += _percorre(map,i,j-1,k);
 		}
 	}
 	if(map[i].menordir[j][k]=='e')
 	{
 		if (map[i].basin[j+1][k]=='0')
 		{
 			map[i].basin[j+1][k]=map[i].basin[j][k];
 			cont++;
 			cont += _percorre(map,i,j+1,k);
 		}
 	}
 	if(map[i].menordir[j][k]=='s')
 	{
 		if (map[i].basin[j][k+1]=='0')
 		{
 			map[i].basin[j][k+1]=map[i].basin[j][k];
 			cont++;
 			cont += _percorre(map,i,j,k+1);
 		}
 	}
 	return cont;
 }

