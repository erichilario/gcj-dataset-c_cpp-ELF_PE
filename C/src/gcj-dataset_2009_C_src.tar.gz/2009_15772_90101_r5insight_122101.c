#include<stdio.h>
 #include<string.h>
 
 int ans[20][505];
 char want[20]="welcome to code jam", ask[505];
 
 int main(){
 	int i,j,k,l,n;
 	scanf("%d\n",&n);
 	for(i=0;i<n;i++){
 		gets(ask);
 		l=strlen(ask);
 		for(j=0;j<20;j++)for(k=0;k<505;k++)ans[j][k]=0;
 		ans[0][0]=1;
 		for(k=1;k<=l;k++)for(j=0;j<=19;j++){
 			ans[j][k]=ans[j][k-1];
 			if(j>0&&ask[k-1]==want[j-1])
 				ans[j][k]=(ans[j][k]+ans[j-1][k-1])%1000;
 		}
 		printf("Case #%d: ",i+1);
 		if(ans[19][l]<1000)printf("0");
 		if(ans[19][l]<100)printf("0");
 		if(ans[19][l]<10)printf("0");
 		printf("%d\n",ans[19][l]);
 	}
 }

