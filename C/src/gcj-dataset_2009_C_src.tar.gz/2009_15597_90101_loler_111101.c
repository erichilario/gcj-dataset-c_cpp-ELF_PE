#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct {
 	int alti;
 	char symb;
 } data;
 
 data *** cell ;
 int id;
 int* val_h ;
 int* val_w ;
 
 char find_next (int i , int j, int k);
 
 int main () {
 	int id;
 	scanf ("%d\n", &id);
 	val_h = (int *)malloc (id * sizeof (int));
 	val_w = (int *)malloc (id * sizeof (int));
 
 	cell = (data ***)malloc (id * sizeof (data **));
 
 	int i,j,k,lk;
 
 	for (i=0; i<id; i++) {
 		scanf ("%d %d\n", &val_h[i], &val_w[i]);
 		cell[i] = (data **) malloc(val_h[i] * sizeof (data *));
 		for (j=0; j<val_h[i]; j++) {
 			cell[i][j] = (data *) malloc(val_w[i] * sizeof (data));
 			for (k=0; k<val_w[i]; k++) {
 				scanf ("%d",&(cell[i][j][k].alti));
 				cell[i][j][k] . symb = '#';
 			}
 		}
 		cell [i][0][0] . symb = 'a';
 	}
 	for (i=0; i<id; i++) {
 		char cur_symb = 'a';
 		find_next (i,0,0);
 		for (j=0; j<val_h[i]; j++) {
 			for (k=0; k<val_w[i]; k++) {
 				if (cell[i][j][k] . symb == '#') {
 					cell[i][j][k] . symb = ++cur_symb;
 	//				printf ("hai %c\n", cur_symb);
 					if (find_next (i, j, k) != '#')
 						cur_symb--;
 				}
 			}
 		}
 	}
 	for (i=0; i< id; i++) {
 		printf ("Case #%d:\n", i+1);
 		for (j=0; j<val_h[i]; j++) {
 			for (k=0; k<val_w[i]; k++)
 				printf ("%c ", cell[i][j][k].symb);
 			printf ("\n");
 		}
 	}
 
 }
 
 char find_next (int i , int j, int k) {
 	int fin_j = j;
 	int fin_k = k;
 	char c;
 	if (j > 0 && cell[i][fin_j][fin_k].alti > cell[i][j-1][k].alti) {
 		fin_j = j-1;
 		fin_k = k;
 	}
 	if (k > 0 && cell[i][fin_j][fin_k].alti > cell[i][j][k-1].alti) {
 		fin_j = j;
 		fin_k = k-1;
 	}
 	if (k < val_w[i]-1 && cell[i][fin_j][fin_k].alti > cell[i][j][k+1].alti) {
 		fin_j = j;
 		fin_k = k+1;
 	}
 	if (j < val_h[i]-1 && cell[i][fin_j][fin_k].alti > cell[i][j+1][k].alti) {
 		fin_j = j+1;
 		fin_k = k;
 	}
 	
 	if ( fin_j!=j || fin_k!=k ) {
 		if (cell[i][fin_j][fin_k] . symb == '#') {
 			cell[i][fin_j][fin_k] . symb = cell[i][j][k] . symb ;
 			if ((c=find_next (i,fin_j, fin_k)) == '#' )
 				return '#';
 			else {
 				cell[i][j][k] . symb = c;
 				return c;
 			}
 		}
 		else {
 			c = cell[i][fin_j][fin_k] . symb ;
 			cell[i][j][k] . symb = c;
 			return c;
 		}
 	}
 	else
 		return '#';
 }

