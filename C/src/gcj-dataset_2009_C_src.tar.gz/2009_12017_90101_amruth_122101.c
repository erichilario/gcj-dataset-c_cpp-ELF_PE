#include<stdio.h>
 //#include<conio.h>
 char *p="welcome to code jam";
 int count,n,d=0;
 void fun(char *ptr,FILE *fp,char c)
 {
   char ch=fgetc(fp);
   long l;
  
 if((*ptr)=='\0')
   {
    count++;
     return;
   }
   
 while(ch!=c){
 
     if(ch==(*ptr)){
     l=ftell(fp);
   
     fun(ptr+1,fp,c);
     fseek(fp,l,0);
 }
 ch=fgetc(fp);
 }
 }
 
 void main()
 {
   FILE *f1,*f2;
   int i,j,k;
   char op[5]={'0','0','0','0'};
       
  char *ptr,c;
  //clrscr();
 
 f1=fopen("C-small-attempt0.in","r");
   f2=fopen("output.in","w");
 fscanf(f1,"%d",&n);
 c=fgetc(f1);
 for(i=1;i<=n;i++)
 {
   if(i==n)
     c=EOF;
   else
     c='\n'; 
   ptr=p;
   fun(ptr,f1,c);
   for(j=0;j<4;j++)
   {
     k=count%10;
     op[3-j]=k+'0';
     count=count/10;
   }
   op[5]='\0';
   fprintf(f2,"Case #%d: %s\n",i,op);
   count=0;
 }
   fclose(f1);
 }

