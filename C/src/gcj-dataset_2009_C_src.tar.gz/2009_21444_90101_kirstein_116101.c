#include<stdio.h>
 #include<string.h>
 
 
 bool match(char *a,char *b,int L){
 	int length;
 	length = strlen(b);
 	int i,j;
 	i=0;j=0;
 	bool t;
 	while(i<L&&j<length){
 		if(a[i]==b[j]){
 			i++;
 			j++;
 		} 
 		else if(b[j]=='('){
 			t = false;
 			while(b[j]!=')'){
 				j++;
 				if(a[i]==b[j]){
 					t = true;
 					break;	
 				}
 			}
 			if(t == true){
 				while(b[j]!=')'){
 					j++;
 				}
 			}
 			else return false;
 			i++;
 			j++;
 		}
 		else return false;
 		
 	}
 	if(i==L&&j==length) return true;
 	else return false;
 }
 
 int main(){
 	int L,M,N,i,count,j;
 	char str[5003][20];
 	char pattern[100001];
 	while(scanf("%d%d%d",&L,&M,&N)==3){
 		for(i=0;i<M;i++){
 			scanf(" %s",str[i]);
 		}
 		for(i=0;i<N;i++){
 			count = 0;
 			scanf(" %s",pattern);
 			for(j=0;j<M;j++){
 				if(match(str[j],pattern,L)) count++;
 			}
 			printf("Case #%d: %d\n",i+1,count);
 		}
 	}
 	return 0;
 }

