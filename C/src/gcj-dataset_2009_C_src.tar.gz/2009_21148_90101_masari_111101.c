#include <stdio.h>
 #include <string.h>
 #include <limits.h>
 
 int mat[100][100], r[100][100];
 
 int m, n, basins;
 
 int p(int i, int j)
 {
 	int aux, i2=i, j2=i;
 	if(r[i][j] == 0){
 		aux = mat[i][j];
 		if(i<m-1) if (mat[i+1][j]   <= aux) {aux = mat[i+1][j]   ; i2 = i+1; j2=j;   }/*south*/
 		if(j<n-1) if (mat[i]  [j+1] <= aux) {aux = mat[i]  [j+1] ; i2 = i  ; j2=j+1; }/*east*/
 		if(j>0)   if (mat[i]  [j-1] <= aux) {aux = mat[i]  [j-1] ; i2 = i  ; j2=j-1; }/*west*/
 		if(i>0)   if (mat[i-1][j]   <= aux) {aux = mat[i-1][j]   ; i2 = i-1; j2=j;   }/*north*/
 		
 		if(aux == mat[i][j]){
 			r[i][j] = basins++;
 		}else{
 			r[i][j] = r[i2][j2] == 0 ? p(i2,j2) : r[i2][j2];
 		}
 	}
 	return r[i][j];	
 }
 
 
 int main(void)
 {
 	int casos, t, i, j;
 	
 	
 	scanf("%d ",&casos);
 	t = 1;
 	while(casos--){
 		scanf("%d %d",&m,&n);
 		for(i=0;i<m;i++){
 			for(j=0;j<n;j++){
 				scanf("%d", &mat[i][j]);
 			}
 		}
 		
 		basins = 1;
 		memset(r,0,sizeof(r));
 		for(i=0;i<m;i++){
 			for(j=0;j<n;j++){
 				p(i,j);
 			}
 		}		
 				
 		printf("Case #%d:\n",t++);
 		for(i=0;i<m;i++){
 			printf("%c", 'a'+r[i][0]-1);
 			for(j=1;j<n;j++){
 				printf(" %c", 'a'+r[i][j]-1);
 			}
 			printf("\n");
 		}
 	}
 
 	return 0;
 }

