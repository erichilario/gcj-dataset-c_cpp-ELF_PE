#include <stdio.h>
 #include <string.h>
 
 int L, D, N;
 char pattern[512], regex[32];;
 char dict[5001][16];
 int ok[5001];
 
 int main()
 {
     int i, j, k, pos;
     int sol;
 
     freopen("a.in", "r", stdin);
     freopen("a.out", "w", stdout);
 
     scanf("%d %d %d\n", &L, &D, &N);
     
     for (i = 0; i < D; ++i)
         gets(dict[i]);
 
     for (i = 1; i <= N; ++i)
     {
         gets(pattern);
         for (j = 0; j < D; ok[j] = 1, ++j);
         for (j = pos = 0; j < strlen(pattern); ++j, ++pos)
         {
             memset(regex, 0, sizeof(regex));
             if (pattern[j] == '(')
                 while (pattern[++j] != ')')
                     regex[pattern[j] - 'a'] = 1;
             else
                 regex[pattern[j] - 'a'] = 1;
             for (k = 0; k < D; ++k)
                 if (ok[k] && !regex[dict[k][pos] - 'a'])
                     ok[k] = 0;
         }
         for (j = sol = 0; j < D; ++j)
             sol += ok[j];
         printf("Case #%d: %d\n", i, sol);
     }
     return 0;
 }

