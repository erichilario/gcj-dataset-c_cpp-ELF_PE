#include<stdio.h>
 #include<stdlib.h>
 char possibilities[15][27];
 int indicator[5000];
 int L,D,N;
 char words[5000][15];
 char inputs[500][800];
 int outputs[500];
 int currentInput;
 int determine(int, char*);
 int main(){
 	int count=0;
 	FILE *fp = fopen ("C:\\Rajatj\\tempFiles\\A-small-attempt0.in","r");
 	FILE *fout;
 	if(fp == NULL){
 		printf("Null");
 		exit(0);
 	}
 	fscanf(fp,"%d%d%d",&L,&D,&N);
 	if(!(1<=L<=15&&1<=D<=5000&&1<=N<=500)){
 		printf("Error in input. Exiting");
 		exit(0);
 	}
 	for(count =0; count < D; count++){
 		fscanf(fp,"%s",words[count]);
 	}
 	for(count =0; count < N; count++){
 		fscanf(fp,"%s",inputs[count]);
 		currentInput =count;
 		determine(0,inputs[count]);
 	}
 	fclose(fp);
 	fout = fopen("C:\\Rajatj\\tempFiles\\A-small-attempt0.out","w");
 	for(count =0; count < N; count++){
 		fprintf(fout,"Case #%d: %d\n",count,outputs[count]);
 	}
 	fclose(fout);
 	return 0;
 }
 
 
 int determine(int pointCount, char input[800]){
 	int i;
 	if(pointCount>=L){
 		for(i=0;i<D;i++){
 			if(indicator[i]>=pointCount){
 				++outputs[currentInput];
 				indicator[i]=pointCount-1;
 			}
 		}
 		return 0;
 	}
 	char c;
 	int eligible[5000];
 	if(pointCount==0){
 		int k=0;
 		for(i=0;i<D;i++){
 			indicator[i]=0;
 			eligible[k++]=i;
 		}
 		eligible[k]=-1;
 	}else{
 		int k=0;
 		for(i=0;i<D;i++){
 			if(indicator[i]>=pointCount){
 				indicator[i]=pointCount;
 				eligible[k++]=i;
 			}
 		}
 		eligible[k]=-1;
 	}
 	if(input[0]=='('){
 		for(i=1;input[i]!=')';i++){
 			char flag=0;
 			c = input[i];
 			int k=0;
 			while(eligible[k]!=-1){
 				if(words[(int)eligible[k]][pointCount]==c){
 					indicator[(int)eligible[k]]=pointCount+1;
 					flag =1;
 				}
 				k++;
 			}
 			if(flag==0)continue;
 			int l=0;
 			while(input[l++]!=')');
 			determine(pointCount+1,input+l);
 		}
 	}else{
 		c = input[0];
 		int k=0;
 		while(eligible[k]!=-1){
 			if(words[(int)eligible[k]][pointCount]==c){
 				indicator[(int)eligible[k]]=pointCount+1;
 			}
 			k++;
 		}
 		determine(pointCount+1,input+1);
 	}
 	for(i=0;i<D;i++)
 		indicator[i]=pointCount-1;
 	return 0;
 }
 
 
 

