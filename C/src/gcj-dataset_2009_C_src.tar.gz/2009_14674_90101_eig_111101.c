#include <stdio.h>
 #define NORTH 0
 #define WEST 1
 #define EAST 2
 #define SOUTH 3
 #define NOTHING 4
 
 
 
 int table[100][100][2];
 int discover[100][100];
 char ans[100][100];
 int H,W;
 void color(int r,int c,char alp){
     //printf("%d %d %c\n",r,c,alp);
     ans[r][c]=alp;
     discover[r][c]=1;
     
     if(r!=0)
     if(discover[r-1][c]==0)
         if(table[r][c][1]==NORTH||table[r-1][c][1]==SOUTH)
             color(r-1,c,alp);
     if(r!=H-1)
     if(discover[r+1][c]==0)
         if(table[r][c][1]==SOUTH||table[r+1][c][1]==NORTH)
             color(r+1,c,alp);
     if(c!=W-1)
     if(discover[r][c+1]==0)
         if(table[r][c][1]==EAST||table[r][c+1][1]==WEST)
             color(r,c+1,alp);
     if(c!=0)
     if(discover[r][c-1]==0)
         if(table[r][c][1]==WEST||table[r][c-1][1]==EAST)
             color(r,c-1,alp);
 }
 
 int main(){
     int T,c,i,k,j,alphabet,min,mem;
     freopen("B-small-attempt0.in","r",stdin);
     scanf("%d",&T);
     for(c=0;c<T;c++){
         scanf("%d %d",&H,&W);
         for(i=0;i<H;i++){
             for(j=0;j<W;j++){
                 scanf("%d",&table[i][j][0]);
                 table[i][j][1]=0;
                 discover[i][j]=0;
             }
         }
         for(i=0;i<H;i++){
             for(j=0;j<W;j++){
                 min=table[i][j][0];
                 mem=NOTHING;
                 if(i!=0){
                     //printf("%d %d\n",min,table[i-1][j][0]);
                     mem=min>table[i-1][j][0]?NORTH:mem;
                     min=min>table[i-1][j][0]?table[i-1][j][0]:min;
                 }
                 if(j!=0){
                     //printf("%d %d\n",min,table[i][j-1][0]);
                     mem=min>table[i][j-1][0]?WEST:mem;
                     min=min>table[i][j-1][0]?table[i][j-1][0]:min;
                 }
                 if(j!=W-1){
                     ///printf("%d %d\n",min,table[i][j+1][0]);
                     mem=min>table[i][j+1][0]?EAST:mem;
                     min=min>table[i][j+1][0]?table[i][j+1][0]:min;
                 }
                 if(i!=H-1){
                     //printf("%d %d\n",min,table[i+1][j][0]);
                     mem=min>table[i+1][j][0]?SOUTH:mem;
                     min=min>table[i+1][j][0]?table[i+1][j][0]:min;
                 }
                 
                 table[i][j][1]=mem;
             }
         }
         
         
         alphabet='a';
         for(i=0;i<H;i++){
             for(j=0;j<W;j++){
                 if(discover[i][j]==0)
                 {
                     color(i,j,alphabet);
                     alphabet++;
                 }
             }
         }
         printf("Case #%d:\n",c+1);
         for(i=0;i<H;i++){
             for(j=0;j<W;j++){
                 printf("%c ",ans[i][j]);
             }
             printf("\n");
         }
         /*for(i=0;i<H;i++){
             for(j=0;j<W;j++){
                 printf("%d ",table[i][j][1]);
             }
             printf("\n");
         }*/
     }
 }

