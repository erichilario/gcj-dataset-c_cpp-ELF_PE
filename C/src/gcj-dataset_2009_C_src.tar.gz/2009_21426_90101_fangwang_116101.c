#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 int main()
 {
 	FILE *fp;
 	char **word;
 	char **pattern;
 	char c;
 	int L, D, N;
 	int i, j, k;
 	int *result;
 	int flag;
 
 	fp = fopen("A-large.in", "r");
 	fscanf(fp, "%d %d %d\n", &L, &D, &N);
 
 	word = malloc(sizeof(char *) * D);
 	for (i = 0; i < D; i++)
 	{
 		word[i] = malloc(L + 1);
 		fscanf(fp, "%s\n", word[i]);
 	}
 
 	result = malloc(sizeof(int) * N);
 	pattern = malloc(sizeof(char *) * (L + 1));
 	for (i = 0; i < N; i++)
 	{
 		flag = 0;
 		j = k = 0;
 		pattern[j] = malloc(27);
 		while ((c = fgetc(fp)) != '\n')
 		{
 			if (c == '(')
 			{
 				flag = 1;
 				continue;
 			}
 			else if (c == ')')
 			{
 				pattern[j][k] = '\0';
 				flag = 0;
 				k = 0;
 				pattern[++j] = malloc(27);
 				continue;
 			}
 			if (flag == 0)
 			{
 				pattern[j][k++] = c;
 				pattern[j][k] = '\0';
 				k = 0;
 				pattern[++j] = malloc(27);
 			}
 			else
 			{
 				pattern[j][k++] = c;
 			}
 		}
 		result[i] = 0;
 		for (j = 0; j < D; j++)
 		{
 			for (k = 0; k < L; k++)
 				if (NULL == strchr(pattern[k], word[j][k]))
 					break;
 			if (k == L)
 				result[i]++;
 		}
 	}
 	
 	for (i = 0; i < N; i++)
 		printf("Case #%d: %d\n", i + 1, result[i]);
 
 	return 0;
 }

