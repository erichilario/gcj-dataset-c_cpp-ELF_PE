#include <string.h>
 #include <stdio.h>
 #include <stdlib.h>
 #define MAX_LEN 520
 char* text = "welcome to code jam";
 int count;
 
 void strsearch(char* start, int c){
   char* result;
   result = (char*)memchr(start, text[c], strlen(start));
   while (result != NULL){
     if (c == 18){
       count++;
     }
     else{
       strsearch(result, c+1);
     }
     result = (char*)memchr((result+1), text[c], strlen(start));
   }
 }
 
 
 int main(int argc, char**argv){
   char * filename = argv[1];
   FILE * data = fopen(filename, "r");
   char * str_buf = (char *) malloc((MAX_LEN + 1) * sizeof(char));
   int N, i;
   fgets(str_buf, MAX_LEN, data);
   N = atoi(str_buf);
   for(i=0; i<N; i++){
     count = 0;
     printf("Case #%i: ", i+1);
     fgets(str_buf, MAX_LEN, data);
     strsearch(str_buf, 0);
     printf("%04i\n", count);
     memset(str_buf, 0, 520);
   }
   free(str_buf);
 }

