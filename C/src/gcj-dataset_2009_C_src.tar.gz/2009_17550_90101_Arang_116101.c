#include<stdio.h>
 
 
 int main()
 {
     int L = 3,D = 6,N = 1;
     int i,j,k, x,count;
     char *p; char **a;
     
     int n;
     char c, flag;
     scanf("%d %d %d ", &L, &D, &N);
     char pat[500];
 
     p = (char *) malloc(sizeof(char));
     a = (char **) malloc(sizeof(char*)*D);    
     for(i=0;i<D;i++)
         a[i] = (char *) malloc(L+1);
     
     for(i=0;i<D;i++)
         gets(a[i]); 
         
 for(x = 0; x< N; x++) {
     count = flag = n = 0;
     for(i=0;i<D;i++)
         p[i] = 0;
      
     gets(pat);
     for( j= 0;pat[j] != '\0'; j++ ) {
     c = pat[j];
     if(c >= 'a' && c <= 'z') {
          for(i=0;i<D;i++) {
              if(a[i][n] == c)
                  p[i]++;
          }
          if(flag == 0)
              n++;
     }
     else if(c == '(')
         flag = 1;
     else if( c == ')' ) {
         flag =  0; n++;
     }
     }
     
     for(i=0;i<D;i++)
         if(p[i] == L)
            count++;
     printf("Case #%d: %d\n",x+1,count);
 }
 
 }

