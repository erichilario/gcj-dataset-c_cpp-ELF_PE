#include<stdio.h>
 #include<string.h>
 
 int main(){
     int L,N,D;
     char matriz[5002][20];
     char marc[5002];
     char ativos[100];
     int top;
     int i,j,k,p;
     int ordem,ok;
     int cont;
     char s[50];
     char c;
 
     scanf("%d %d %d\n",&L,&D,&N);
     for(i=0;i<D;i++){
         gets(s);
         strcpy(matriz[i],s);
     }
     for(j=0;j<N;j++){
         for(i=0;i<D;i++) marc[i] = '1';
         ordem = 0;
 
         while(scanf("%c",&c) == 1 && c != '\n'){
             //printf("letra: %c ",c);
             if(c == '('){
                // printf("eh parentisis ");
                 top = 0;
                 while(scanf("%c",&c)==1 && c!=')'){
                     ativos[top] = c;
                     top++;
                 }
                 //printf("ordem %d ",ordem);
                 for(k=0;k<D;k++){
                     if(marc[k] == '1'){
                         ok = 0;
                         for(p=0;p<top;p++){
                             if(matriz[k][ordem] == ativos[p]) ok = 1;
                         }
                         if(ok == 0){
                             marc[k] = '0';
                             //printf("desmarcou %d ",k);
                         }
                     }
                 }
             }
             else{
                 //printf("nao eh parentisis ");
                 for(k=0;k<D;k++){
                     if(matriz[k][ordem] != c) marc[k] = '0';
                 }
             }
             ordem++;
 
         }
         cont = 0;
         for(k=0;k<D;k++) if(marc[k] == '1') cont++;
         printf("Case #%d: %d\n",j+1,cont);
     }
 }

