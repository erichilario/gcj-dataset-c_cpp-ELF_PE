#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 
 int groupcheck(char **ppCurTest, char Find)
 {
 	char * pCurTest = *ppCurTest;
 	int ret = -1;
 
 	pCurTest++; // skip '('
 
 	while ( *pCurTest )
 	{
 		if ( *pCurTest == ')' )
 		{
 			pCurTest++; // skip ')'
 			break;
 		}
 
 		if ( *pCurTest == '(' )
 		{
 			if ( groupcheck(&pCurTest, Find) == 0 )
 			ret = 0;
 		}
 		else if (*pCurTest == Find)
 		{
 			ret = 0;
 		}
 
 		pCurTest++;
 	}
 
 	*ppCurTest = pCurTest;
 
 	return ret;
 }
 
 int main()
 {
 
 	int L, D, N;
 	int i, j;
 	char Data[5000][20];
 	char Test[1024*4];
 	char *pCurTest, *pCurData;
 	int bFail;
 	int match;
 
 	scanf("%d %d %d", &L, &D, &N);
 
 	//read data
 	for ( i = 0; i < D; i++ )
 	{
 		scanf("%s", Data[i]);
 	}
 
 	for ( i = 0; i < N; i++ )
 	{
 		printf("Case #%d: ", i+1);
 		scanf("%s", Test);
 
 		match = 0;
 
 		for ( j = 0 ; j < D ; j++ )
 		{
 			pCurTest = Test;
 			pCurData = Data[j];
 			bFail = 0;
 			
 			while ( *pCurTest && *pCurData )
 			{
 				if ( *pCurTest == '(' )
 				{
 					if ( groupcheck(&pCurTest, *pCurData) != 0 )
 					{
 						bFail = 1;
 						break;
 					}
 					pCurTest--;
 				}
 				else if ( *pCurTest != *pCurData )
 				{
 					bFail = 1;
 					break;
 				}
 
 				pCurTest++;
 				pCurData++;
 			}
 
 			if ( bFail == 0 )
 				match++;
 		}
 
 		printf("%ld\n", match);
 
 	}
 	return 0;
 }

