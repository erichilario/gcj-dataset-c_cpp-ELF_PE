/* This is an trying of solve the alien language of Google Code Jam 2009*/
 
 #include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<regex.h>
 
 #define L 15
 #define D 5000
 #define N 500
 #define LINE 1000
 
 struct dictionary {
 	char word[L];
 };
 typedef struct dictionary dict;
 
 void main(int argc, char* argv[])
 {
 	unsigned int lenL = 0, lenD = 0, lenN = 0;
 	dict w[D];
 	unsigned int i, j, count;
 	char textline[LINE];
 	regex_t reg;
 
 	scanf("%u %u %u", &lenL, &lenD, &lenN);
 
 	//printf("L = %u, D = %u, N = %u\n", lenL, lenD, lenN);
 	
 	for(i = 0; i < lenD; i++) {
 		scanf("%s", w[i].word);
 		//printf("Word = %s\n\n", w[i].word);
 	}
 	for(i = 0; i < lenN; i++) {
 		count = 0;
 		scanf("%s", &textline);
 		//printf("Line = %s.\n", textline);
 
 		for(j = 0; j < LINE; j++) {
 			if(textline[j] == '(')
 				textline[j] = '[';
 			else if (textline[j] == ')')
 				textline[j] = ']';
 		}
 		//printf("Line = %s.\n", textline);
 			
 		if (regcomp(&reg , textline, REG_EXTENDED|REG_NOSUB) != 0) {
 			printf("Erro\n");
 		}
 		
 		for (j = 0; j < lenD; j++) {
 			if ((regexec(&reg, w[j].word, 0, (regmatch_t *)NULL, 0)) == 0)
 				count++;
 		}
 		
 		printf("Case #%d: %d\n", i+1, count);
 		
 	}
 	
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

