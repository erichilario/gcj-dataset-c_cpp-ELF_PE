# include<stdio.h>
 # include<malloc.h>
  
  
 int main(){
 
 	int n,l,d;
 	int i=0,j=0;
 	char c;
 	int count;
 	
 	
 	scanf("%d %d %d",&l,&d,&n);
 	
 	char ** dic;
 	dic=(char **)malloc(d*sizeof(char*));
 	for(i=0;i<d;i++) dic[i]=(char *)malloc(l*sizeof(char));
 	for(i=0;i<d;i++) scanf("%s",dic[i]);
 	
 	
 	char ** inp=(char**)malloc(n*sizeof(char*));
 	int flag=0;
 	int k=0;
 	for(k=0;k<n;k++) {
 		inp[k]=(char*)malloc(l*29*sizeof(char));
 		scanf("%s",inp[k]);
 		
 		}
 	int p=0;
 	for(k=0;k<n;k++){
 		count=0;
 	//	printf("%s\n",inp[k]);
 		for(j=0;j<d;j++){
 		
 			for(i=0;i<l;i++){
 //		if(k==1)			printf("%c",dic[j][i]);
 				flag=0;
 				if(inp[k][p]=='('){
 				//	printf("%d ",l);
 					p++;
 					while(inp[k][p]!=')'){
 						if(inp[k][p]==dic[j][i]){
 						// printf("hi %d %c",j,inp[k][p]);
 						 flag=1;
 						}
 						p++;
 					}
 					p++;
 				}else	if(dic[j][i]==inp[k][p]){
 					p++;
 					flag=1;
 					//if(k==1)printf("break1 : %c",dic[j][i]);
 					
 				}	
 				
 				if(flag==0){
 				 	//if(k==1)printf("break : %c",dic[j][i]);
 				 	//printf("%s \n",dic[j]);
 				 	break;
 				 }		
 			}
 			//printf("\n");
 			p=0;
 			
 		if(i==l) count++;
 	
 		}
 		printf("Case #%d: %d\n",k+1,count);
 	}
 
 }

