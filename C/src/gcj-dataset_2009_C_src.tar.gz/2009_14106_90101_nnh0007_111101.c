#include <stdio.h>
 unsigned int qx[11111],qy[11111],rec[102][102],map[102][102],T,H,W,beg,end;
 char tor[26],frr[26],sink[102][102],lycz;
 unsigned int UP=1,DOWN=2,LEFT=4,RIGHT=8;
 int main(){
     scanf("%d\n",&T);
     for(unsigned int i=1; i<=T; i++){
         scanf("%d %d\n",&H,&W);
         for(unsigned int x=0; x<W;x++)
             map[x+1][0]=map[x+1][H+1]=11111;
         for(unsigned int y=0; y<H;y++){
             map[0][y+1]=map[W+1][y+1]=11111;
             for(unsigned int x=0;x<W;x++){
                 scanf("%d",&map[x+1][y+1]);
                 rec[x+1][y+1]=0;   
             }
         }
         for(unsigned int y=0; y<H;y++)
             for(unsigned int x=0; x<W;x++)
             {
                 unsigned int sx=0,sy=1,dir;
                 if(map[x+1][y+1]>map[x+1][y] && map[x+1][y]<map[sx][sy]){sx=x+1;sy=y;dir=DOWN;}
                 if(map[x+1][y+1]>map[x][y+1] && map[x][y+1]<map[sx][sy]){sx=x;sy=y+1;dir=RIGHT;}
                 if(map[x+1][y+1]>map[x+2][y+1] && map[x+2][y+1]<map[sx][sy]){sx=x+2;sy=y+1;dir=LEFT;}
                 if(map[x+1][y+1]>map[x+1][y+2] && map[x+1][y+2]<map[sx][sy]){sx=x+1;sy=y+2;dir=UP;}
                 if(sx==0)sink[x+1][y+1]=1; else {sink[x+1][y+1]=0;rec[sx][sy]|=dir;}
             }
         lycz='a';
 
 
         for(unsigned int y=0; y<H;y++)
             for(unsigned int x=0; x<W;x++){
                 if(sink[x+1][y+1]==1){
                     qx[0]=x+1;qy[0]=y+1;
                     beg=0;end=1;
                     while(beg!=end){
                         sink[qx[beg]][qy[beg]]=lycz;
                         if(rec[qx[beg]][qy[beg]]&UP){qx[end]=qx[beg];qy[end]=qy[beg]-1;end++;}
                         if(rec[qx[beg]][qy[beg]]&DOWN){qx[end]=qx[beg];qy[end]=qy[beg]+1;end++;}
                         if(rec[qx[beg]][qy[beg]]&LEFT){qx[end]=qx[beg]-1;qy[end]=qy[beg];end++;}
                         if(rec[qx[beg]][qy[beg]]&RIGHT){qx[end]=qx[beg]+1;qy[end]=qy[beg];end++;}
                         beg++;
 //printf("%d ",end);
                     }
                     lycz++;
                 }
             }
 
 /*        for(unsigned int y=0; y<H+2;y++){
             for(unsigned int x=0; x<W+2;x++)
                 printf("%c ",sink[x][y]);
             printf("\n");
             fflush(stdout);
         }
 
 return;*/
 
         lycz='a';
         for(unsigned int y=0; y<26; y++)tor[y]=frr[y]=0;
         for(unsigned int y=0; y<H;y++)
             for(unsigned int x=0; x<W;x++){
                 if(tor[sink[x+1][y+1]-'a']==0){
                     tor[sink[x+1][y+1]-'a']=lycz++;
 //                    frr[lycz]=
                 }
                 sink[x+1][y+1]=tor[sink[x+1][y+1]-'a'];
 //                printf("%c ",sink[x+1][y+1]);
             }
         printf("Case #%d:\n",i);
         for(unsigned int y=0; y<H;y++){
             printf("%c",sink[1][y+1]);
             for(unsigned int x=1; x<W;x++){
                 printf(" %c",sink[x+1][y+1]);
             }
             printf("\n");
         }
     }
         
 }
 

