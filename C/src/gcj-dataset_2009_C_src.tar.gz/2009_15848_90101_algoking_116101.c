#include<stdio.h>
 #include<stdlib.h>
 
 typedef struct pat{
 	char **s;
 	}pat;
 
 
 int check(char c,char *s){
 		
 	int i=0;
 
 	while(s[i]!='\0'){
 	 if(c==s[i])
 	  return(1);	
 	
 	 i++;	
 	}		
 		
 	return 0;
 }	
 
 int return_token(char **dic,pat in,int D,int L){
 			
 	int i,j,count,match;
 		
 	count=0;
 	
 	for(i=0;i<D;i++){
 
 	  match=0;		
 	  for(j=0;j<L;j++)			
 		if(check(dic[i][j],in.s[j]))		
 			match++;
 		else
 			break;
 
 	  if(match==L)
 	   count++;			
 	}
 	
 	return count;		
 }
 
 
 int main(){
 
 	int i,j,k;
 	int L,D,N;
 	char **dic,ch;
 	int *out;		
 		
 	
 	scanf("%d %d %d",&L,&D,&N);	
 		
 	dic=(char **)malloc(sizeof(char *)*D);
 	for(i=0;i<D;i++){
 		dic[i]=(char *)malloc(sizeof(char)*L);			
 		scanf("%s ",dic[i]);		 					
 	}
 
 	out= (int *)malloc(sizeof(int)*N);
 
 	// patterns declaration
 	pat *in;
 	in= (pat *)malloc(sizeof(pat)*N);
 	for(i=0;i<N;i++){
 	  in[i].s = (char **)malloc(sizeof(char *)*L);	
 	  for(j=0;j<L;j++)
 		in[i].s[j]= (char *)malloc(sizeof(char)*L*D);			  
 	}
 		
 	for(i=0;i<N;i++){
 		
 		for(j=0;j<L;j++){
 			scanf(" %c",&ch);
 			if(ch=='('){
 			  k=0;
 			  scanf("%c",&ch);	
 			  while(ch!=')'){		
 			      in[i].s[j][k++]=ch;
 			      scanf("%c",&ch); 	 	
 			  }		
 			 in[i].s[j][k++]= '\0';
 			}
 			else{
 			  in[i].s[j][0]=ch;	
 			  in[i].s[j][1]='\0'; 			
 			}
 		}	
 	}
 	
 	for(i=0;i<N;i++)
 	   out[i]= return_token(dic,in[i],D,L);	
 	
 	for(i=0;i<N;i++)
 	   printf("Case #%d: %d\n",i+1,out[i]);			 	
 		
 	return 0;
 }
 
 
 

