#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 typedef struct
 {
   void** pChildren;
   char pValue;
 } node;
 
 node* node_new ();
 void node_set_value (node* aNode, char aValue);
 char node_get_value (node* aNode);
 node* node_put (node* aNode, char aValue);
 node* node_get (node* aNode, char aValue);
 void node_match (node* aNode, char* aWord, int* aCount);
 void node_destroy (node* aNode);
 
 node* node_new ()
 {
   node* lNode=(node*)malloc(sizeof(node));
   lNode->pChildren=malloc(sizeof(node*));
   lNode->pChildren[0]=0;
 
   lNode->pValue=0;
   return lNode;
 }
 
 void node_set_value (node* aNode, char aValue)
 {
   aNode->pValue=aValue;
 }
 
 char node_get_value (node* aNode)
 {
   return aNode->pValue;
 }
 
 node* node_put (node* aNode, char aValue)
 {
   node* lNode;
 
   lNode=node_new();
   node_set_value(lNode, aValue);
 
   int i=0;
 
   while (aNode->pChildren[i] && node_get_value(aNode->pChildren[i])!=aValue)
     i++;
 
   if (aNode->pChildren[i] && node_get_value(aNode->pChildren[i])==aValue)
     return aNode->pChildren[i];
 
   aNode->pChildren=realloc(aNode->pChildren, (i+2)*sizeof(node*));
   aNode->pChildren[i]=lNode;
   aNode->pChildren[i+1]=0;
 
   return lNode;
 }
 
 node* node_get (node* aNode, char aValue)
 {
   int i=0;
 
   while (aNode->pChildren[i] &&
          node_get_value(aNode->pChildren[i])!=aValue) i++;
   
   if (aNode->pChildren[i] && node_get_value(aNode->pChildren[i])==aValue)
     return aNode->pChildren[i];
   return 0;
 }
 
 void node_match (node* aNode, char* aWord, int* aCount)
 {
   node* lNode;
 
   if (strlen(aWord)==0) (*aCount)++;
 
   if (aWord[0]!='(' && aWord[0]!=')')
     if (lNode=node_get(aNode, aWord[0]))
       node_match(lNode, aWord+sizeof(char), aCount);
 
   if (aWord[0]=='(')
   {
     int i=1;
     int j=1;
 
     while (aWord[j]!=')') j++;
 
     while (aWord[i]!=')')
     {
       if (lNode=node_get(aNode, aWord[i]))
         node_match(lNode, aWord+(j+1)*sizeof(char), aCount);
 
       i++;
     }
   }
 }
 
 void node_destroy (node* aNode)
 {
   int i=0;
 
   while (aNode->pChildren[i])
   {
     node_destroy(aNode->pChildren[i]);
     i++;
   }
   free(aNode->pChildren);
   free(aNode);
 }
 
 int main (int argc, char** argv)
 {
   int l, d, n;
   int i, j;
 
   char lPool[512];
   node* lRoot;
   node* lNode;
 
   int lOutput;
 
   lRoot=node_new();
 
   scanf("%i %i %i", &l, &d, &n);
 
   for (i=0; i<d; i++)
   {
     lNode=lRoot;
 
     scanf("%s", lPool);
 
     for (j=0; j<l; j++)
     {
       lNode=node_put(lNode, lPool[j]);
     }
   }
 
   for (i=0; i<n; i++)
   {
     lOutput=0;
 
     scanf("%s", lPool);
 
     node_match(lRoot, lPool, &lOutput);
 
     printf("Case #%i: %i\n", i+1, lOutput);
   }
 
   node_destroy(lRoot);
 }

