#include <stdio.h>
 #include <stdlib.h>
 
 #define W_MAX	100
 
 #define MAP(yy,xx)	(map + (yy)*W + (xx))
 #define NEW(yy,xx)	(new_map + (yy)*W + (xx))
 
 #define BLKX	3
 #define BLKY	3
 
 int test_case(int case_num)
 {
 	int i, j, m, n;
 	int H, W;
 	int *map;
 	char *new_map;
 	char letra = 'a';
 	int try_again = 0;
 	scanf("%d %d", &H, &W);
 	
 	
 	//printf("H=%d\n", H);
 	//printf("W=%d\n", W);
 	
 	map = (int*) malloc(H*W*sizeof(int));
 	new_map = (char*) malloc(H*W*sizeof(char));
 	if (!map || !new_map) {
 		perror("malloc");
 		exit(1);
 	}
 	
 	// le o map
 	for (i = 0; i < H; i++) {
 		for (j = 0; j < W; j++) {
 			scanf("%d", MAP(i,j));
 			*NEW(i,j) = '0';
 		}
 	}
 	
 	
 	//processa o map
 	*NEW(0, 0) = letra;
 	try_again = 1;
 	while(try_again != 0) {
 	try_again = 0;
 	for (m = 0; m < H; m++) {
 		for (n = 0; n < W; n++) {
 			int sink = 0;
 			int value = *MAP(m,n);
 			int cur_lower_y = m;
 			int cur_lower_x = n;
 			int North_y, North_x, West_y, West_x, East_y, East_x, South_y, South_x;
 			int neigh_value;
 			
 			//if (!(*NEW(m, n) == letra && *NEW(m, n) == '0'))
 			//	continue;
 				
 			North_y = m-1;
 			North_x = n;
 			West_y = m;
 			West_x = n-1;
 			East_y = m;
 			East_x = n+1;
 			South_y = m+1;
 			South_x = n;
 					
 			// testa North
 			if (North_y >= 0) {
 				neigh_value = *MAP(North_y, North_x);
 				if (neigh_value < value && neigh_value < *MAP(cur_lower_y, cur_lower_x)) {
 						cur_lower_y = North_y;
 						cur_lower_x = North_x;
 				}
 			}
 			
 			// testa West
 			if (West_x >= 0) {
 				neigh_value = *MAP(West_y, West_x);
 				if (neigh_value < value && neigh_value < *MAP(cur_lower_y, cur_lower_x)) {
 						cur_lower_y = West_y;
 						cur_lower_x = West_x;
 				}
 			}
 			
 			// testa East
 			if (East_x < W) {
 				neigh_value = *MAP(East_y, East_x);
 				if (neigh_value < value && neigh_value < *MAP(cur_lower_y, cur_lower_x)) {
 						cur_lower_y = East_y;
 						cur_lower_x = East_x;
 				}
 			}
 			
 			// testa South
 			if (South_y < H) {
 				neigh_value = *MAP(South_y, South_x);
 				if (neigh_value < value && neigh_value < *MAP(cur_lower_y, cur_lower_x)) {
 						cur_lower_y = South_y;
 						cur_lower_x = South_x;
 				}
 			}
 			
 			//printf("* [%d,%d](menor=%d,%d)\n", m, n, cur_lower_y, cur_lower_x);
 			//printf("* (%d)\n", *NEW(cur_lower_y, cur_lower_x));
 			
 			//eh sink
 			if (cur_lower_y == m && cur_lower_x == n) {
 				sink = 1;
 			} else {
 				sink = 0;
 			}
 			
 			
 			if (sink == 1) {
 				if (*NEW(m, n) == '0') {
 					letra++;
 					*NEW(cur_lower_y, cur_lower_x) = letra;
 					*NEW(m, n) = *NEW(cur_lower_y, cur_lower_x);
 					//printf("caso 0\n");
 				}
 			} else {
 				if (*NEW(m, n) != '0' && *NEW(cur_lower_y, cur_lower_x) == '0') {
 					*NEW(cur_lower_y, cur_lower_x) = *NEW(m, n);
 					//printf("caso 1\n");
 				} else if (*NEW(m, n) == '0' && *NEW(cur_lower_y, cur_lower_x) != '0'){
 					*NEW(m, n) = *NEW(cur_lower_y, cur_lower_x);
 					//printf("caso 2\n");
 				} else if (*NEW(m, n) == '0' && *NEW(cur_lower_y, cur_lower_x) == '0') {
 					//printf("caso 3\n");
 					try_again = 1;
 				}
 			}
 			//if (m != cur_lower_y && n != cur_lower_x)
 			//*NEW(m, n) = *NEW(cur_lower_y, cur_lower_x);
 			//printf("%d ", *(MAP(i,j)));
 		}
 		//printf("\n");
 	}
 	
 	
 	}
 	// imprime saida
 	printf("Case #%d:\n", case_num);
 	for (i = 0; i < H; i++) {
 		for (j = 0; j < W; j++) {
 			printf("%c ", *NEW(i,j));
 		}
 		printf("\n");
 	}
 	
 	
 	return 0;
 }
 int main()
 {
 	int i;
 	int T;
 	
 	
 	scanf("%d", &T);
 	//printf("T=%d\n", T);
 	
 	for (i = 0; i < T; i++) {
 		test_case(i+1);
 	}
 	
 	return 0;
 }

