#include<stdio.h>
 #include<math.h>
 #include<string.h>
 
 char init[30];
 
 
 int main(){
 	char str[600],res[5];
 	int dp[600][30];
 	int N,length,l,count;
 	int r,i,j,k;
 	strcpy(init,"welcome to code jam");
 	length = strlen(init);
 	scanf("%d\n",&N);
 		for(i=0;i<N;i++){
 			gets(str);
 			l = strlen(str);
 			for(j=0;j<l;j++){
 				dp[j][0] = 0;
 			}
 			count = 0;
 			for(j=0;j<l;j++){
 				if(str[j]==init[0]) {
 					count++;
 				}
 				dp[j][0] = count;
 			}
 			for(k=1;k<length;k++){
 				for(j=1;j<l;j++){
 					if(str[j]!=init[k]) dp[j][k] = dp[j-1][k];
 					else dp[j][k] = (dp[j-1][k] + dp[j][k-1]) % 10000;
 				}
 			}
 			k = dp[l-1][length-1];
 			printf("Case #%d: %.4d\n",i+1,k);/*
 			for(j=3;j>=0;j--){
 				res[j] = k%10 + '0';
 				k /= 10;
 			}
 			res[4]='\0';
 			printf("Case #%d: %s\n",i+1,res);*/
 		}
 
 	return 0;
 }

