#include<stdio.h>
 int maps[100][100],w,h,num;
 char op[100][100],aop[100][100];
 char minn(int i,int j)
 {  
    char ch='0';
    int m;
    if(((maps[i-1][j]<=maps[i][j-1])||(j<=0))&&((maps[i-1][j]<=maps[i][j+1])||((j+1)>=h))&&((maps[i-1][j]<=maps[i+1][j])||((i+1)>=w))&&(i>0))
     {
        ch='n';
        m=maps[i-1][j];
     }
    if(((maps[i][j-1]<maps[i-1][j])||(i<=0))&&((maps[i][j-1]<=maps[i][j+1])||((j+1)>=h))&&((maps[i][j-1]<=maps[i+1][j])||((i+1)>=w))&&(j>0))
     {
       ch='w';
       m=maps[i][j-1];
      }
    if(((maps[i][j+1]<maps[i][j-1])||(j<=0))&&((maps[i][j+1]<maps[i-1][j])||(i<=0))&&((maps[i][j+1]<=maps[i+1][j])||((i+1)>=w))&&((j+1)<h))
      {
        ch='e';
        m=maps[i][j+1];
      }
    if(((maps[i+1][j]<maps[i][j-1])||(j<=0))&&((maps[i+1][j]<maps[i][j+1])||((j+1)>=h))&&((maps[i+1][j]<maps[i-1][j])||(i<=0))&&((i+1)<w))
       {
         ch='s';
         m=maps[i+1][j];
       }
     if(maps[i][j]<=m)
          return '0';
     else
          return ch;
 }
 void final()
 {
 int flag=1,i,j;  
 char ch='a';
 while(flag){
  flag=0;
  for(i=0;i<w;i++)
   for(j=0;j<h;j++)
   {if(aop[i][j]=='0'){
     if((op[i][j]=='s')&&(aop[i+1][j]!='0')&&((i+1)<w))
         aop[i][j]=aop[i+1][j];
     else
     if((op[i][j]=='n')&&(aop[i-1][j]!='0')&&(i>0))
         aop[i][j]=aop[i-1][j];
     else
    if((op[i][j]=='e')&&(aop[i][j+1]!='0')&&((j+1)<h))
         aop[i][j]=aop[i][j+1];
     else
     if((op[i][j]=='w')&&(aop[i][j-1]!='0')&&(j>0))
         aop[i][j]=aop[i][j-1];
     else
       if((op[i+1][j]=='n')&&(aop[i+1][j]!='0')&&((i+1)<w))
         aop[i][j]=aop[i+1][j];
     else
     if((op[i-1][j]=='s')&&(aop[i-1][j]!='0')&&(i>0))
         aop[i][j]=aop[i-1][j];
     else
    if((op[i][j+1]=='w')&&(aop[i][j+1]!='0')&&((j+1)<h))
         aop[i][j]=aop[i][j+1];
     else
     if((op[i][j-1]=='e')&&(aop[i][j-1]!='0')&&(j>0))
         aop[i][j]=aop[i][j-1];
     else
     if(((i==0)&&(j==0))||(op[i][j]=='0')){
         aop[i][j]=ch;
          ch=ch+1;
      }
    }
 if(aop[i][j]=='0')
 flag=1;
 }
 }
 }
 
 int main()
 {
    int i,j,k;
    char ch;
    FILE *f1,*f2;
 	f1=fopen("B-small-attempt2.in","r");
         f2=fopen("output.in","w");
    fscanf(f1,"%d",&num);
    for(k=1;k<=num;k++)
 {
    ch='a';
    fscanf(f1,"%d %d",&w,&h);
    for(i=0;i<w;i++)
    for(j=0;j<h;j++)
    {
      op[i][j]='0';
      aop[i][j]='0';
      fscanf(f1,"%d",&maps[i][j]);
    }
   for(i=0;i<w;i++)
   for(j=0;j<h;j++)
   {
       op[i][j]=minn(i,j);
   }
  
   final();    
      
 fprintf(f2,"Case #%d:\n",k); 
    for(i=0;i<w;i++){
    for(j=0;j<h;j++)
    {
      fprintf(f2,"%c  ",aop[i][j]);
     }
     fprintf(f2,"\n");
    }                      
 } 
   return 0;
 }

