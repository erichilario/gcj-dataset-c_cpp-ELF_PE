#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <string.h>
 #include <ctype.h>
 
 #define MAXH (100+1)
 #define MAXW (100+1)
 #define MAXT (100+1)
 
 #define MAXALT 10000
 
 int alts[MAXH][MAXW];
 int calc[MAXH][MAXW];
 int final[MAXH][MAXW];
 int H, W;
 
 typedef enum {NO, SO, EA, WE, NF} DIRE;
 
 int val(int r, int c)
 {
 	if (r < 0 || c < 0 || r >= H || c >= W)
 		return MAXALT;
 	return alts[r][c];
 }
 
 int min4(int a, int b, int c, int d)
 {
 	int f = (a < b ? a : b);
 	int s = (c < d ? c : d);
 	return (f < s ? f : s);
 }
 
 DIRE flow(int r, int c)
 {
 	int n, s, e, w;
 	int min;
 	if (r < 0 || c < 0 || r >= H || c >= W)
 		return NF;
 	n = val(r-1, c);
 	s = val(r+1, c);
 	e = val(r, c+1);
 	w = val(r, c-1);
 	min = min4(n, s, e, w);
 	if (val(r,c) <= min)
 		return NF;
 	if (min == n)
 		return NO;
 	if (min == w)
 		return WE;
 	if (min == e)
 		return EA;
 	return SO;
 }
 
 void recurse(int r, int c, char label)
 {
 //printf("Recurse at %d %d %c\n", r, c, label);
 	calc[r][c] = label;
 	if (flow(r-1, c) == SO) recurse(r-1, c, label);
 	if (flow(r+1, c) == NO) recurse(r+1, c, label);
 	if (flow(r, c-1) == EA) recurse(r, c-1, label);
 	if (flow(r, c+1) == WE) recurse(r, c+1, label);
 }
 
 void set(char lower, char upper)
 {
 	for (int a = 0; a < H; a++)
 	{
 		for (int b = 0; b < W; b++)
 		{
 			if (calc[a][b] == lower)
 			{
 				final[a][b] = upper;
 				calc[a][b] = upper;
 			}
 		}
 	}
 }
 
 void process(int caseno)
 {
 	int min;
 	int minr = -1;
 	int minc = -1;
 	char label = 'A';
 	while (true)
 	{
 		min = MAXALT;
 		for (int a = 0; a < H; a++)
 		{
 			for (int b = 0; b < W; b++)
 			{
 				if (calc[a][b] == '0' && alts[a][b] < min)
 				{
 					min = alts[a][b];
 					minr = a;
 					minc = b;
 				}
 			}
 		}
 		if (min == MAXALT)
 			break;
 		if (minr == -1 || minc == -1)
 			printf("Error!\n");
 //printf("start at %d %d\n", minr, minc);
 		recurse(minr, minc, label);
 		label++;
 	}
 
 	label = 'a';
 	for (int a = 0; a < H; a++)
 	{
 		for (int b = 0; b < W; b++)
 		{
 			if (isupper(calc[a][b]))
 			{
 				set(calc[a][b], label);
 				label++;
 			}
 		}
 	}
 
 	printf("Case #%d:\n", caseno+1);
 	for (int a = 0; a < H; a++)
 	{
 		for (int b = 0; b < W; b++)
 		{
 			printf("%c ", final[a][b]);
 		}
 		printf("\n");
 	}
 }
 
 /****************************************************************/
 /* The main program */
 
 int main(int argc, char *argv[])
 {
 	int T;
 
 	FILE *fp;
 
 	fp = fopen(argv[1], "r");
 	if (fp == NULL)
 	{
 		fprintf(stderr, "Fatal error: cannot open file '%s'\n", argv[1]);
 		exit(EXIT_FAILURE);
 	}
 
 	fscanf(fp, "%d\n", &T);
 
 	for (int i = 0; i < T; i++)
 	{
 		fscanf(fp, "%d %d\n", &H, &W);
 
 		for (int a = 0; a < MAXH; a++)
 			for (int b = 0; b < MAXW; b++)
 			{
 				alts[a][b] = 0;
 				calc[a][b] = '0';
 				final[a][b] = '0';
 			}
 
 		for (int j = 0; j < H; j++)
 		{
 			for (int k = 0; k < W; k++)
 			{
 				fscanf(fp, "%d", &alts[j][k]);
 			}
 		}
 
 /*
 		for (int a = 0; a < H; a++)
 		{
 			for (int b = 0; b < W; b++)
 			{
 				printf("%d ", alts[a][b]);
 			}
 			printf("\n");
 		}
 		printf("\n");
 */
 
 		process(i);
 
 	}
 
 	return 0;
 }

