#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 
 
 
 void compute(FILE* fin,FILE*fout);
 int get_low(int** map,int i,int j,int rows,int cols);
 
 int main(int c,char* argv[]){
 
 FILE* fin=fopen(argv[1],"r");
 FILE* fout=fopen(argv[2],"w");
 
 if(!fin || !fout){
 printf("unable to open files \n");
 return 0;
 }
 
 int num_t;
 fscanf(fin,"%d\n",&num_t);
 int this_case=1;
 
 for(this_case;this_case<=num_t;this_case++){
 	fprintf(fout,"Case #%d:\n",this_case);
 	compute(fin,fout);
 }
 
 return 0;
 }
 
 #define i_num(num,col) ((num)/(col))
 #define j_num(num,col) ((num)%(col)) 
 #define num_ij(col,i,j) ((i)*col + (j))
 
 #define alphabet(i) ("abcdefghijklmnopqrstuvwxyz"[i])
 
 void compute(FILE* fin,FILE*fout){
 int rows;
 int cols;
 fscanf(fin,"%d %d\n",&rows,&cols);
 int ** map=malloc(rows*sizeof(int*));
 int** aux=malloc(rows*sizeof(int*));
 int i=0;
 int j=0;
 for(i=0;i<rows;i++){
 map[i]=malloc(cols*sizeof(int));
 aux[i]=malloc(cols*sizeof(int));
 }
 for(i=0;i<rows;i++){
 	for(j=0;j<cols;j++)
 		fscanf(fin,"%d",&map[i][j]);
 	fscanf(fin,"\n");
 }
 int low=-1;
 for(i=0;i<rows;i++){
 	for(j=0;j<cols;j++){
 		low=get_low(map,i,j,rows,cols);
 		aux[i][j]=low;
 		}
 }
 for(i=0;i<rows;i++)
 	for(j=0;j<cols;j++)
 		map[i][j]=-1;
 
 int num_sinks=0;
 
 for(i=0;i<rows;i++){
 	for(j=0;j<cols;j++){
 		if(aux[i][j]==-1){ //its a sink
 			map[i][j]=num_sinks;//num_ij(cols,i,j);//alphabet(num_sinks);
 			num_sinks++;
 			continue;
 			}
 		
 		//if its not a sink
 		
 			/*int x=i_num(aux[i][j],cols);
 			int y=j_num(aux[i][j],cols);
 			if(map[x][y]!=-1)
 				map[i][j]=map[x][y];*/
 }
 }
 //for(i=(rows-1);i>=0;i--)
 //	for(j=(cols-1);j>=0;j--)
 for(i=0;i<rows;i++)
 		for(j=0;j<cols;j++){
 			if(map[i][j]==-1){//it has not been assigned
 				int m=i,n=j;
 				int j_flags=1;
 				while(1){
 					int x=i_num(aux[m][n],cols);
         		                int y=j_num(aux[m][n],cols);
 	                       		if(map[x][y]!=-1){
                                 		map[m][n]=map[x][y];
 						break;
 						}
 					else { if(j_flags){
 							j--;
 							j_flags=0;
 						}
 						m=x;
 						n=y;
 					}
 				}
 						
 			}
 	}
 
 
 int flag=0;
 char sink[26]={0,};
 for(i=0;i<rows;i++)
 	for(j=0;j<cols;j++){
 		if(sink[map[i][j]]==0){
 		sink[map[i][j]]=alphabet(flag);
 		flag++;
 		}
 	}
 for(i=0;i<rows;i++)
 for(j=0;j<cols;j++)
 	map[i][j]=sink[map[i][j]];
 
 
 
 
 /*		if(map[i][j]==-1)
 			map[i][j]=map[i_num(aux[i][j],cols)][j_num(aux[i][j],cols)];
 */
 for(i=0;i<rows;i++){
 	for(j=0;j<cols;j++){
 		fprintf(fout,"%c",map[i][j]);
 		if(j!=(cols-1))fprintf(fout," ");}
 	if(i!=(rows-1)||j!=(cols-1))
 	fprintf(fout,"\n");
 }
 			
 for(i=0;i<rows;i++){
 free(map[i]);
 free(aux[i]);
 }
 free(map);
 free(aux);
 }
 
 
 
 
 #define INF 100000
 int get_low(int** map,int i,int j,int rows,int cols){
 
 int a,b,c,d,e;
 a=map[i][j];
 if(i==0)
 	b=INF;
 else b=map[i-1][j];
 
 if(i==(rows-1))
 	d=INF;
 else d=map[i+1][j];
 
 if(j==0)
 	c=INF;
 else c=map[i][j-1];
 
 if(j==(cols-1))
 	e=INF;
 else e=map[i][j+1];
 
 if(a<=b&&a<=c&&a<=d&&a<=e)
 return -1;//a sink value
 if(b<=a&&b<=c&&b<=d&&b<=e)
 return num_ij(cols,i-1,j);
 if(c<=a&&c<=b&&c<=d&&c<=e)
 return num_ij(cols,i,j-1);
 if(d<=a&&d<=b&&d<=c&&d<=e)
 return num_ij(cols,i+1,j);
 if(e<=a&&e<=b&&e<=c&&e<=d)
 return num_ij(cols,i,j+1);
 
 printf("\n there must be some error");
 return -1;
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 

