#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <string.h>
 
 #define MAXL (15+1)
 #define MAXD (5000+1)
 #define MAXN (500+1)
 
 char *words[MAXD];
 char *cases[MAXN];
 bool rule[MAXN][MAXL][26];
 int counts[MAXN];
 
 int L, D, N;
 
 static void trimLine(char line[])
 {
 	int i = 0;
 
 	while(line[i] != '\0')
 	{
 		if(line[i] == '\r' || line[i] == '\n')
 		{
 			line[i] = '\0';
 			break;
 		}
 		i++;
 	}
 }
 
 static void readFile(char filename[])
 {
 	FILE *fp;
 	char line[BUFSIZ];
 	int lineno = 1;
 	int w = 0;
 	int c = 0;
 
 	fp = fopen(filename, "r");
 	if (fp == NULL)
 	{
 		fprintf(stderr, "Fatal error: cannot open file '%s'\n", filename);
 		exit(EXIT_FAILURE);
 	}
 
 	fscanf(fp, "%d %d %d\n", &L, &D, &N);
 	lineno++;
 
 	while(fgets(line, sizeof line, fp) != NULL)
 	{
 		trimLine(line);
 		if (lineno <= D+1)
 		{
 			words[w] = malloc(sizeof(char) * MAXL);
 			strcpy(words[w++], line);
 //			printf("Read word %s\n", words[w-1]);
 		}
 		else
 		{
 			cases[c] = malloc(sizeof(char) * MAXL*(MAXL+2)+1);
 			strcpy(cases[c++], line);
 //			printf("Read case %s\n", cases[c-1]);
 		}
 		lineno++;
 	}
 	fclose(fp);
 }
 
 /****************************************************************/
 /* The main program */
 
 int main(int argc, char *argv[])
 {
 	readFile(argv[1]);
 
 	for (int c = 0; c < N; c++)
 	{
 		int u = 0;
 		int i = 0;
 		bool inbrac = false;
 //		printf("Case is %s\n", cases[c]);
 		while (cases[c][i] != '\0')
 		{
 			if (cases[c][i] == '(')
 			{
 				inbrac = true;
 				i++;
 				continue;
 			}
 			if (cases[c][i] == ')')
 			{
 				inbrac = false;
 				u++;
 				i++;
 				continue;
 			}
 			rule[c][u][cases[c][i]-'a'] = true;
 			if (!inbrac)
 				u++;
 			i++;
 		}
 /*
 		{
 			printf("Index %d: ", l);
 			for (int i = 0; i < 26; i++)
 				printf("%c", (rule[c][l][i] ? 'T' : 'F'));
 			printf("\n");
 		}
 */
 	}
 
 	for (int w = 0; w < D; w++)
 	{
 		for (int c = 0; c < N; c++)
 		{
 			bool match = true;
 			for (int i = 0; i < L; i++)
 			{
 				match = match && rule[c][i][words[w][i]-'a'];
 			}
 			if (match)
 				counts[c]++;
 		}
 	}
 
 	for (int c = 0; c < N; c++)
 	{
 		printf("Case #%d: %d\n", c+1, counts[c]);
 	}
 
 	return 0;
 }

