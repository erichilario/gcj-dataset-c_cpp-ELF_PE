/*
  * main.c
  *
  *  Created on: 2009-9-3
  *      Author: will
  */
 
 #include "io.h"
 #include <stdio.h>
 
 int main(int argc,char *argv[])
 {
 	int mode, i, j, test_index;
 	char **std_words;
 	char **test;
 	int* output;
 	int num_of_letter, num_of_words, num_of_tests;
 	int words;
 	FILE *fp;
 
 	mode = 0;
 	read_input(&fp, mode, &std_words, &num_of_letter, &num_of_words, &num_of_tests);
 
 	test = malloc(num_of_letter*sizeof(char*));
 	for(i=0;i<num_of_letter;i++)
 	{
 		test[i] = malloc(27);
 	}
 	output = malloc(num_of_tests*sizeof(int));
 
 	for(test_index=0; test_index<num_of_tests; test_index++)
 	{
 		read_one_test(&fp, &test ,num_of_letter);
 
 		for(i=0;i<num_of_words;i++)
 		{
 			std_words[i][num_of_letter+1] = 'y';
 		}
 
 		strip_words_single(&std_words, test, num_of_letter, num_of_words );
 		strip_words_multi(&std_words, test, num_of_letter, num_of_words );
 		words = calculate_match(&std_words, num_of_letter, num_of_words);
 		output[test_index]=words;
 	}
 	fclose(fp);
 	write_output(mode, output, num_of_tests);
 
 
 }

