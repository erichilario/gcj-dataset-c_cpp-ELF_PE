#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <string.h>
 #include <ctype.h>
 
 #define MAXLEN (500+1)
 #define MAXN (100+1)
 
 char target[] = "welcome to code jam";
 #define TARLEN 19
 int cache[MAXLEN+1][TARLEN+1];
 
 static void trimLine(char line[])
 {
 	int i = 0;
 
 	while(line[i] != '\0')
 	{
 		if(line[i] == '\r' || line[i] == '\n')
 		{
 			line[i] = '\0';
 			break;
 		}
 		i++;
 	}
 }
 
 static void trimLast(char line[])
 {
 	int i = strlen(line)-1;
 
 	while (i != 0)
 	{
 		if (line[i] != 'm')
 			line[i] = '\0';
 		else
 			break;
 		i--;
 	}
 }
 
 int main(int argc, char *argv[])
 {
 	int N = -1;
 
 	FILE *fp;
 	char line[BUFSIZ];
 
 	fp = fopen(argv[1], "r");
 	if (fp == NULL)
 	{
 		fprintf(stderr, "Fatal error: cannot open file '%s'\n", argv[1]);
 		exit(EXIT_FAILURE);
 	}
 
 	fscanf(fp, "%d\n", &N);
 
 	for (int i = 0; i < N; i++)
 	{
 		fgets(line, sizeof line, fp);
 		trimLine(line);
 		trimLast(line);
 		int len = strlen(line);
 
 		for (int i = 0; i < MAXLEN+1; i++)
 		{
 			for (int j = 0; j < TARLEN+1; j++)
 			{
 				cache[i][j] = 0;
 			}
 		}
 
 		for (int i = 0; i < len+1; i++)
 		{
 			for (int j = 0; j < TARLEN+1; j++)
 			{
 				if (j > i)
 					cache[i][j] = 0;
 				else if (j == 0)
 					cache[i][j] = 1;
 				else if (i == 0)
 					cache[i][j] = 0;
 				else if (line[len-i] == target[TARLEN-j])
 					cache[i][j] = (cache[i-1][j-1] + cache[i-1][j]) % 10000 ;
 				else
 					cache[i][j] = cache[i-1][j];
 			}
 		}
 
 /*
 		for (int i = 0; i < len+1; i++)
 		{
 			for (int j = 0; j < TARLEN+1; j++)
 			{
 				printf("%5d", cache[i][j]);
 			}
 			printf("\n");
 		}
 */
 
 		printf("Case #%d: %04d\n", i+1, cache[len][TARLEN]);
 	}
 
 	return 0;
 }

