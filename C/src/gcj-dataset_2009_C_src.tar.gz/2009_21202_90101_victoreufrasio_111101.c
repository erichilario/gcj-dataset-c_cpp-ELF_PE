#include<stdio.h>
 #include<stdlib.h>
 
 
 int currentBasin;
 int marca[150][150];
 int T,H,W;
 int matriz[150][150];
 int caso=1;
 char traducao[30];
 
 int marcaBasin(int i,int j){
     //printf("MARCABASIN %d %d\n",i,j);
     int r;
 
     if(matriz[i-1][j]<=matriz[i][j+1] && matriz[i-1][j]<=matriz[i+1][j] && matriz[i-1][j]<=matriz[i][j-1]){
         if(matriz[i-1][j] < matriz[i][j]){
             marca[i][j] = marcaBasin(i-1,j);
         }
         else{
             if(marca[i][j] == -1) {marca[i][j]=currentBasin++; return marca[i][j];}
             else return marca[i][j];
         };
     }
     else if(matriz[i][j-1]<=matriz[i-1][j] && matriz[i][j-1]<=matriz[i][j+1] && matriz[i][j-1]<=matriz[i+1][j]){
         if(matriz[i][j-1] < matriz[i][j]){
             marca[i][j] = marcaBasin(i,j-1);
         }
         else{
             if(marca[i][j] == -1) {marca[i][j]=currentBasin++; return marca[i][j];}
             else return marca[i][j];
         };
 
     }
     else if(matriz[i][j+1]<=matriz[i-1][j] && matriz[i][j+1]<=matriz[i+1][j] && matriz[i][j+1]<=matriz[i][j-1]){
         if(matriz[i][j+1] < matriz[i][j]){
             marca[i][j] = marcaBasin(i,j+1);
         }
         else{
             if(marca[i][j] == -1) {marca[i][j]=currentBasin++; return marca[i][j];}
             else return marca[i][j];
         };
 
     }
     else{
         if(matriz[i+1][j] < matriz[i][j]){
             marca[i][j] = marcaBasin(i+1,j);
         }
         else{
             if(marca[i][j] == -1) {marca[i][j]=currentBasin++; return marca[i][j];}
             else return marca[i][j];
         };
     }
 
     return marca[i][j];
 }
 
 
 
 int main(){
 
 
     int i,j;
     scanf("%d",&T);
 
     while(T--){
         scanf("%d %d",&H,&W);
         for(i=1;i<=H;i++){
             for(j=1;j<=W;j++){
                 scanf("%d",&matriz[i][j]);
             }
         }
         for(i=0;i<=H+1;i++){
             matriz[i][0] = 11000;
             matriz[i][W+1]= 11000;
         }
         for(i=0;i<=W;i++){
             matriz[0][i] = 11000;
             matriz[H+1][i] = 11000;
         }
         currentBasin = 0;
         int max = 0;
 
         for(i=1;i<=H;i++){
             for(j=1;j<=W;j++){
                 marca[i][j] = -1;
             }
         }
 
         for(i=0;i<=H+1;i++){
             for(j=0;j<=W+1;j++){
                 //printf("%d ",matriz[i][j]);
             }
             //printf("\n");
         }
         for(i=0;i<=26;i++) traducao[i] = '.';
 
         int terminou = 0;
         int cont = 0;
         while(!terminou){
             terminou = 1;
             max = 0;
             for(i=1;i<=H;i++){
                 for(j=1;j<=W;j++){
                     if(matriz[i][j]>max && marca[i][j] == -1){
                         max = matriz[i][j];
                         terminou = 0;
                     }
 
                 }
             }
 
             //printf("max: %d\n",max);
             for(i=1;i<=H;i++){
                 for(j=1;j<=W;j++){
                     if(matriz[i][j] == max && marca[i][j] == -1){
                         //printf("marcabasin: \(%d %d\) %d\n",i,j,cont);
                         int u = marcaBasin(i,j);
                         //printf("U=%d\n",u);
                         marca[i][j] = u;
                         i = H+10;
                         break;
                     }
                 }
             }
 
         }
 
         char letra = 'a';
 
         for(i=1;i<=H;i++){
             for(j=1;j<=W;j++){
                 if(traducao[marca[i][j]] == '.') traducao[marca[i][j]] = letra++;
             }
         }
 
         printf("Case #%d:\n",caso++);
         for(i=1;i<=H;i++){
             for(j=1;j<=W;j++){
                 printf("%c ",traducao[marca[i][j]]);
             }
             printf("\n");
         }
 
     }
 }

