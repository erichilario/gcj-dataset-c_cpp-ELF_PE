#include<stdio.h>
 #include<string.h>
 void find(int,int,int);
 int ans=0,status[27][500],limit;
 char key[]="welcome to code jam";
 int main()
 		{
 		int dataset,i,length,j,k,temp,mast1,t;
 		scanf("%d",&dataset);
 		char mast[2],input[500];
 		for(i=0;i<27;i++)
 			for(j=0;j<500;j++)
 					status[i][j]=0;
 	//	for(i=0;i<27;i++)
 		//	for(j=0;j<500;j++)
 				//	qw[i][j]=0;
 		gets(mast);
 		for(i=0;i<dataset;i++)
 				{
 				gets(input);
 				ans=0;
 				mast1=0;
 				length=strlen(input);
 				for(j=0;j<length;j++)
 						{
 						if(input[j]!=' ')
  							k=(int)input[j]-97;
  						else
  							k=26;
  						status[k][j]=1;
 						}
 				for(k=0;k<length-18;k++)
 						{
 						
 						if(status[22][k]!=0)
 						find(1,k+1,length);
 						}
 				temp=ans;
 				while(temp!=0)
 						{
 					mast1++;
 					temp=temp/10;
 						}
 				printf("Case #%d: ",i+1);
 				for(k=0;(k<4-mast1)&&k<3;k++)
 				printf("0");
 				printf("%d\n",ans);
 				for(k=0;k<27;k++)
 					for(j=0;j<500;j++)
 						status[k][j]=0;
 					}
 }
 
 
 
 void find(int cha,int from,int length)
 {
 		int i,k;
 		for(i=from;i<length-18+cha;i++)
 		{
 				if(key[cha]==' ')
 						k=26;
 				else
 						k=(int)key[cha]-97;
 				if(status[k][i]==1)
 				{
 						if(cha!=18)
 							find(cha+1,i+1,length);
 						else
 							{
 									ans++;
 									ans=ans%10000;
 							}
 				}
 		}
 }

