#include <stdio.h>
 
 int go[100][100], num[100][100], alt[100][100], check[100][100];
 int q[10000], row, col;
 
 int cell(int x,int y){
 	if(x<0||y<0||x>=row||y>=col)return 10005;
 	return alt[x][y];
 }
 
 int valid(int x,int y){
 	if(x<0||y<0||x>=row||y>=col)return 0;
 	return 1;
 }
 
 int choose(int x,int y){
 	if((cell(x,y)<=cell(x-1,y))&&(cell(x,y)<=cell(x,y-1))&&(cell(x,y)<=cell(x,y+1))&&(cell(x,y)<=cell(x+1,y)))return -1;
 	if((cell(x-1,y)<=cell(x,y-1))&&(cell(x-1,y)<=cell(x,y+1))&&(cell(x-1,y)<=cell(x+1,y)))return 0;
 	if((cell(x,y-1)<=cell(x,y+1))&&(cell(x,y-1)<=cell(x+1,y)))return 1;
 	if((cell(x,y+1)<=cell(x+1,y)))return 2;
 	return 3;
 }
 
 int main(){
 	int t,f,r,count;
 	int i,j,k,l,x,y;
 	int dir[4][2]={{-1,0},{0,-1},{0,1},{1,0}};
 	scanf("%d",&t);
 	for(i=0;i<t;i++){
 		scanf("%d%d",&row,&col);
 		for(j=0;j<row;j++)for(k=0;k<col;k++)scanf("%d",&alt[j][k]);
 		for(j=0;j<row;j++)for(k=0;k<col;k++)go[j][k]=choose(j,k);
 		for(j=0;j<row;j++)for(k=0;k<col;k++){num[j][k]=0;check[j][k]=0;}
 		f=0;r=0;count=0;
 		for(j=0;j<row;j++)for(k=0;k<col;k++)if(!num[j][k]){
 			num[j][k]=++count;
 			q[r++]=j*100+k;
 			check[j][k]=1;
 			while(f<r){
 				x=q[f]/100;
 				y=q[f++]%100;
 				if(go[x][y]>=0&&!check[x+dir[go[x][y]][0]][y+dir[go[x][y]][1]]){
 					q[r++]=(x+dir[go[x][y]][0])*100+(y+dir[go[x][y]][1]);
 					check[x+dir[go[x][y]][0]][y+dir[go[x][y]][1]]=1;
 					num[x+dir[go[x][y]][0]][y+dir[go[x][y]][1]]=count;
 				}
 				for(l=0;l<4;l++)
 				if(valid(x-dir[l][0],y-dir[l][1])&&go[x-dir[l][0]][y-dir[l][1]]==l){
 					q[r++]=(x-dir[l][0])*100+(y-dir[l][1]);
 					check[x-dir[l][0]][y-dir[l][1]]=1;
 					num[x-dir[l][0]][y-dir[l][1]]=count;
 				}
 			}
 		}
 		printf("Case #%d:\n",i+1);
 		for(j=0;j<row;j++){
 			for(k=0;k<col;k++)
 				printf("%c ",num[j][k]-1+'a');
 			printf("\n");
 		}
 	}
 	return 0;
 }

