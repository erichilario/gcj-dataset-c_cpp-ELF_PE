#include<stdio.h>
 #include<string.h>
 int cnt(char* ,char ,int ,int,int );
 char p[50]="welcome to code jam";
 int k=18;
 
 int main()
 {
     int n,a,i;
     char s[1000],c;
 
     freopen("C-small-attempt0.in","r",stdin);
     freopen("out.txt","w",stdout);
     
     scanf("%d%c",&n,&c);
 
     
     for(i=1;i<=n;i++)
     {
         gets(s);
         a=cnt(s,p[0],0,0,0);
         if(a/10<=0)
         printf("Case #%d: 000%d\n",i,a);
         else
         if(a/100<=0)
         printf("Case #%d: 00%d\n",i,a);
         else
         if(a/1000<=0)
         printf("Case #%d: 0%d\n",i,a);
         else
         printf("Case #%d: %d\n",i,a);
     }
 return 0;
 }
 
 int cnt(char* s,char c,int l,int t,int s1)
 {
     int i,c1;
     i=l;
 
 	c1=s1;
     while(s[i]!='\0')
     {
         if(s[i]==c && t==k)
         {
 		  c1++;
         }
 
         else
         if(s[i]==c)
         {
 		  c1=c1+cnt(s,p[t+1],i+1,t+1,s1);
         }
 
         i++;
         
          if(c1/10000>0)
             c1=c1%10000;
     }
 
         if(c1/10000>0)
             c1=c1%10000;
 
 return c1;
 }

