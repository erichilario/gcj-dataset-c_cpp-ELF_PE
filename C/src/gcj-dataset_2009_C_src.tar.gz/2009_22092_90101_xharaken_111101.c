#include <stdio.h>
 #include <stdlib.h>
 
 int main(void)
 {
   int cell[20][20], color[20][20];
   int i, j, t, p, q, T, H, W, c;
   char chara;
   
   scanf(" %d", &T);
   for(t = 0; t < T; t++)
     {
       scanf(" %d %d", &H, &W);
       
       chara = 'a';
       for(i = 0; i < 20; i++)
         {
           for(j = 0; j < 20; j++)
             {
               cell[i][j] = 100;
             }
         }
       for(i = 1; i <= H; i++)
         {
           for(j = 1; j <= W; j++)
             {
               scanf(" %d", &cell[i][j]);
               color[i][j] = 0;
             }
         }
       for(i = 1; i <= H; i++)
         {
           for(j = 1; j <= W; j++)
             {
               p = i;
               q = j;
               while(1)
                 {
                   if(color[p][q] != 0)
                     {
                       c = color[p][q];
                       break;
                     }
                   if(cell[p - 1][q] < cell[p][q]
                      && cell[p - 1][q] <= cell[p + 1][q]
                      && cell[p - 1][q] <= cell[p][q - 1]
                      && cell[p - 1][q] <= cell[p][q + 1])
                     {
                       p = p - 1;
                     }
                   else if(cell[p][q - 1] < cell[p][q]
                           && cell[p][q - 1] <= cell[p + 1][q]
                           && cell[p][q - 1] <= cell[p - 1][q]
                           && cell[p][q - 1] <= cell[p][q + 1])
                     {
                       q = q - 1;
                     }
                   else if(cell[p][q + 1] < cell[p][q]
                           && cell[p][q + 1] <= cell[p + 1][q]
                           && cell[p][q + 1] <= cell[p - 1][q]
                           && cell[p][q + 1] <= cell[p][q - 1])
                     {
                       q = q + 1;
                     }
                   else if(cell[p + 1][q] < cell[p][q]
                           && cell[p + 1][q] <= cell[p][q + 1]
                           && cell[p + 1][q] <= cell[p - 1][q]
                           && cell[p + 1][q] <= cell[p][q - 1])
                     {
                       p = p + 1;
                     }
                   else
                     {
                       c = chara++;
                       break;
                     }
                 }
               p = i;
               q = j;
               while(1)
                 {
                   if(color[p][q] != 0)
                     {
                       break;
                     }
                   color[p][q] = c;
                   if(cell[p - 1][q] < cell[p][q]
                      && cell[p - 1][q] <= cell[p + 1][q]
                      && cell[p - 1][q] <= cell[p][q - 1]
                      && cell[p - 1][q] <= cell[p][q + 1])
                     {
                       p = p - 1;
                     }
                   else if(cell[p][q - 1] < cell[p][q]
                           && cell[p][q - 1] <= cell[p + 1][q]
                           && cell[p][q - 1] <= cell[p - 1][q]
                           && cell[p][q - 1] <= cell[p][q + 1])
                     {
                       q = q - 1;
                     }
                   else if(cell[p][q + 1] < cell[p][q]
                           && cell[p][q + 1] <= cell[p + 1][q]
                           && cell[p][q + 1] <= cell[p - 1][q]
                           && cell[p][q + 1] <= cell[p][q - 1])
                     {
                       q = q + 1;
                     }
                   else if(cell[p + 1][q] < cell[p][q]
                           && cell[p + 1][q] <= cell[p][q + 1]
                           && cell[p + 1][q] <= cell[p - 1][q]
                           && cell[p + 1][q] <= cell[p][q - 1])
                     {
                       p = p + 1;
                     }
                   else
                     {
                       break;
                     }
                 }
             }
         }
       printf("Case #%d:\n", t + 1);
       for(i = 1; i <= H; i++)
         {
           for(j = 1; j <= W; j++)
             {
               printf("%c", color[i][j]);
               if(j != W)
                 {
                   printf(" ");
                 }
             }
           printf("\n");
         }
     }
   return 0;
 }

