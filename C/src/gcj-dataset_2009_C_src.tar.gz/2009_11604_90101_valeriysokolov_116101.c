#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int L = 0;
 int D = 0;
 int N = 0;
 
 char **dic;
 
 char buffer[8192];
 char tokens[15][256];
 char word[256];
 
 static int
 str_cmp(const void *l, const void *r) {
   return strcmp(* (char * const *) l, * (char * const *) r);
 }
 
 void
 parse_tokens(const char *buffer) {
   int t = 0;
   int tp = 0;
   int inpr = 0;
   for(size_t i=0; i<strlen(buffer); ++i) {
     if(buffer[i] == '(') {
       inpr = 1;
     } else if(buffer[i] == ')') {
       tokens[t++][tp] = '\0';
       tp = 0;
       inpr = 0;
     } else if(inpr) {
       tokens[t][tp++] = buffer[i];
     } else {
       tokens[t][0] = buffer[i];
       tokens[t][1] = '\0';
       ++t;
     }
   }
 }
 
 void get_bounds(int l, int r, int d, char ch, int *nl, int *nr) {
   int c = 0;
   *nl = l;
   *nr = r;
   while(*nr - *nl > 1) {
     c = (*nr + *nl) / 2;
     if(dic[c][d] > ch)
       *nr = c;
     else
       *nl = c;
   }
 
   if(dic[*nl][d] != ch && dic[*nr][d] != ch) {
     *nl = 1;
     *nr = 0;
     return;
   }
 
   if(dic[*nr][d] == ch)
     *nl = *nr;
   else
     *nr = *nl;
 
   while(*nl > l && dic[*nl - 1][d] == ch)
     -- (*nl);
 
   while(*nr < r - 1 && dic[*nr + 1][d] == ch)
     ++ (*nr);
 }
 
 unsigned int
 total_between(int l, int r, int d) {
   if(d == L) {
     //    word[L] = '\0';
     //    printf("--> %s\n", word);
     return 1;
   }
 
   unsigned int result = 0;
   int nl, nr;
   for(size_t i=0; i<strlen(tokens[d]); ++i) {
     get_bounds(l, r, d, tokens[d][i], &nl, &nr);
     if(nl <= nr) {
       word[d] = tokens[d][i];
       result += total_between(nl, nr, d+1);
     }
   }
 
   return result;
 }
 
 
 int
 main() {
   scanf("%d %d %d\n", &L, &D, &N);
 
   dic = (char **) malloc(D * sizeof(char *));
   dic[0] = (char *) malloc(D * (L + 1) * sizeof(char));
   for(int i=1; i<D; ++i)
     dic[i] = dic[i-1] + L + 1;
   
   for(int i=0; i<D; ++i) {
     scanf("%s", dic[i]);
   }
 
   qsort(&dic[0], D, sizeof(char*), str_cmp);
 
   //  for(int i=0; i<D; ++i)
   //  printf("%s\n", dic[i]);
 
   for(int i=1; i<=N; ++i) {
     unsigned int total = 0;
     scanf("%s", buffer);
     parse_tokens(buffer);
     //    for(int j=0; j<L; ++j)
     //  printf("\t%s\n", tokens[j]);
 
     total = total_between(0, D-1, 0);
     printf("Case #%d: %u\n", i, total);
   }
 
   return 0;
 }

