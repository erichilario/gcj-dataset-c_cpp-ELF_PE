#include <stdio.h>
 // author kashyap
 //
 
 char cj[20] = "welcome to code jam";
 
 char s[32];
 
 long cases;
 
 void find(int ch,int pos)
 {
 	if( ch == 19) {
 		cases++;
 		return;
 	}
 
 	int flag=0;
 //	printf("ch:%d, curr pos:%d\n",ch,pos);
 
 	while( s[pos] != '\0')
 	{
 		if ( cj[ch] == s [pos] )
 		{
 			pos++;
 			flag = 1;
 			break;
 		}
 
 		pos++;
 
 	}
 
 
 	if( !flag)
 	{
 	//	printf("no matched ch:%d, next pos:%d\n",ch,pos);
 		return;
 	}
 	
 	//	printf("matched ch:%d, next pos:%d\n",ch,pos);
 	/*
 	if(ch != 18 )
 	{
 
 		find(ch+1,pos);
 		find(ch, pos);
 	}
 	else
 		cases++;
 		*/
 		find(ch+1,pos);
 		find(ch, pos);
 	
 	return;
 }
 
 	
 
 int main()
 {
 	int n,i,j=0,flag;
 	scanf("%d\n",&n);
 	char c;
 	for(i=0;i<n;i++)
 	{
 
 		gets(s);
 //		j=0;	
 //		flag=0;
 //		while( (c = getchar() ) != '\n')
 //		{
 //			if (c == ' ' && !flag)
 //			{
 //				s[j++] = c;
 //				flag=1;
 //			}
 //			else if ( c== ' ')
 //				flag = 1;
 //			else flag=0;
 //			if(flag)
 //				continue;
 //			s[j++] = c;
 //		}
 //			s[j] = '\0';
 //		printf("%s\n",s);
 
 		cases=0;
 		find(0,0);
 
 		printf("Case #%d: %d%d%d%d\n",i+1,((cases/1000)%10),((cases/100)%10),((cases/10)%10),(cases%10)  );
 	}
 
 	return 0;
 
 }

