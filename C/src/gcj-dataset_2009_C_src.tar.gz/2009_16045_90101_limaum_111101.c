#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 #include <math.h>
 
 typedef struct cell_t {
        int val;
        char label;
 } cell_t;
 
 char labels[26] = {'a','b','c','d','e','f','g','h','i','j','k','l'
         ,'m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
         
 
 int curLabel = 0;        
         
 int min(int a, int b, int c, int d, int cur){
     int m = 100000;
     int pos = -1;
    // printf("a = %d, b = %d, c = %d, d = %d, cur = %d\n", a,b,c,d,cur);
     if(a < cur && a != -1){
          m = a; 
          pos = 0;    
     }
          
     if(b < cur && b < m && b != -1){
          m = b;
          pos = 1;
     }
     
     if(c < cur && c < m && c != -1){
          m = c;
          pos = 2;
     }
     
     if(d < cur && d < m && d != -1){
          m = d;
          pos = 3;
     }
     
     return pos;   
 }
         
 char labelMap(int H, int W, cell_t map[H][W], int X, int Y){
      
     // printf("x = %d, y = %d\n", X,Y);
 
      if(map[X][Y].label == 'A'){
          if(H == 1 && W != 1){
              int p;
 
              if(X == 0 && Y == 0){
                   p = min(-1,-1, map[X][Y+1].val, -1, map[X][Y].val);
              } else if(X == 0 && Y == W-1){
                   p = min(-1,map[X][Y-1].val, -1, -1, map[X][Y].val);                  
              } else if(X == 0 && Y != 0){
                   p = min(-1,map[X][Y-1].val, map[X][Y+1].val, -1, map[X][Y].val);           
              }
             // printf("%d\n", p);
              if(p == -1){
                   map[X][Y].label = labels[curLabel];
                 //  printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                   curLabel++;      
                   return map[X][Y].label;           
              } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                    //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } 
              
          } else if(H != 1 && W == 1){
              int p;
 
              if(X == 0 && Y == 0){
                   p = min(-1,-1, -1, map[X+1][Y].val, map[X][Y].val);
              } else if(X == H-1 && Y == 0){
                   p = min(map[X-1][Y].val,-1, -1, -1, map[X][Y].val);                   
              } else if(X != 0 && Y == 0){
                   p = min(map[X-1][Y].val,-1, -1, map[X+1][Y].val, map[X][Y].val);           
              }
             // printf("%d\n", p);
              if(p == -1){
                   map[X][Y].label = labels[curLabel];
                 //  printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                   curLabel++;      
                   return map[X][Y].label;           
              } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                    //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              }
              
          } else if(X == H-1 && Y == 0){
              int p = min(map[X-1][Y].val,-1, map[X][Y+1].val, -1, map[X][Y].val);
              if(p == -1){
                   map[X][Y].label = labels[curLabel];
                 //  printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                   curLabel++;      
                   return map[X][Y].label;           
              } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } 
          } else if(X == 0 && Y == 0){
              int p = min(-1,-1, map[X][Y+1].val, map[X+1][Y].val, map[X][Y].val);
              if(p == -1){
                   map[X][Y].label = labels[curLabel];
                 //  printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                   curLabel++;      
                   return map[X][Y].label;     
              } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                      //    printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              }
          } else if(X == 0 && Y == W-1){
              int p = min(-1,map[X][Y-1].val, -1, map[X+1][Y].val, map[X][Y].val);
              if(p == -1){
                   map[X][Y].label = labels[curLabel];
                 //  printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                   curLabel++;      
                   return map[X][Y].label;          
              } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                      //    printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              }
            
          } else if(X == H-1 && Y == W-1){
              int p = min(map[X-1][Y].val,map[X][Y-1].val, -1, -1, map[X][Y].val);
              if(p == -1){
                   map[X][Y].label = labels[curLabel];
                //   printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                   curLabel++;      
                   return map[X][Y].label;           
              } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              }   
          } else {
              
              if(X == 0 && Y != 0){
                  int p = min(-1,map[X][Y-1].val, map[X][Y+1].val, map[X+1][Y].val, map[X][Y].val);
                  if(p == -1){
                       map[X][Y].label = labels[curLabel];
                   //    printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                       curLabel++;      
                       return map[X][Y].label;           
                  } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              }
              } else if(X != 0 && Y == 0){
                  int p = min(map[X-1][Y].val,-1, map[X][Y+1].val, map[X+1][Y].val, map[X][Y].val);
                  if(p == -1){
                         map[X][Y].label = labels[curLabel];
                     //    printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                         curLabel++;      
                         return map[X][Y].label;           
                  } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                      //    printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                      //    printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              }  
              } else if(X != 0 && Y == W-1){
                  int p = min(map[X-1][Y].val,map[X][Y-1].val, -1, map[X+1][Y].val, map[X][Y].val); 
                  if(p == -1){
                       map[X][Y].label = labels[curLabel];
                     //  printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                       curLabel++;      
                       return map[X][Y].label;           
                  } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                     //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              }
              } else if(X == H-1 && Y != 0){
                  int p = min(map[X-1][Y].val,map[X][Y-1].val, map[X][Y+1].val, -1, map[X][Y].val); 
                  if(p == -1){
                       map[X][Y].label = labels[curLabel];
                  //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                       curLabel++;      
                       return map[X][Y].label;           
                  } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                   //       printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                   //       printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                   //       printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              }                                    
              } else {
                  int p = min(map[X-1][Y].val,map[X][Y-1].val, map[X][Y+1].val, map[X+1][Y].val, map[X][Y].val); 
                  if(p == -1){
                        map[X][Y].label = labels[curLabel];
                   //     printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                        curLabel++;      
                        return map[X][Y].label;           
                  } else if(p == 0){
                          map[X][Y].label = labelMap(H,W, map, X-1, Y);            
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 1){
                          map[X][Y].label = labelMap(H,W, map, X, Y-1);              
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 2){
                          map[X][Y].label = labelMap(H,W, map, X, Y+1);                     
                    //      printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              } else if(p == 3){
                          map[X][Y].label = labelMap(H,W, map, X+1, Y);
                   //       printf("x = %d, y = %d, map = %d, label = %c\n", X,Y, map[X][Y].val, map[X][Y].label);
                          return map[X][Y].label; 
              }  
              }
          }
          
      } else {
             return map[X][Y].label;
      } 
 }
 
 int main(){
 
         FILE *in;
         FILE *out;
         in = fopen("B-small.in", "r");
         out = fopen("B-small.out", "w");
         int T, H, W;
         fscanf(in,"%d", &T);
         
         int nextLabel = 0;
         int cas = 1;
         
 	 	while(T > 0){
     	        fscanf(in,"%d %d", &H, &W);
                 cell_t map[H][W];
                 int i,j;
                 for(i = 0;i < H;i++){  
                       for(j = 0;j < W;j++){  
                             fscanf(in, "%d", &map[i][j].val);
                             map[i][j].label = 'A';
                       }
                 } 
                              
                 for(i = 0;i < H;i++){  
                       for(j = 0;j < W;j++){
                           labelMap(H,W,map, i,j);  
                       }
                       
                 }
                 fprintf(out, "Case #%d:\n", cas);
                 for(i = 0;i < H;i++){  
                       for(j = 0;j < W;j++){  
                             if(i == H-1 && j == W-1){
                                  fprintf(out,"%c", map[i][j].label);
                             } else {
                               fprintf(out,"%c ", map[i][j].label);
                             }
                       }
                       fprintf(out,"\n");
                 }
                 
                 //getchar();                 
             	curLabel = 0;
                 
                 T--;
                 cas++;
 	    }
 
         fclose(in);
         fclose(out);
         return 0;
 }

