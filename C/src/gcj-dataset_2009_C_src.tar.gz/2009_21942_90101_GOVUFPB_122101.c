#include <stdio.h>
 #include <string.h>
 
 long int acc;
 char palavra[ 5000];
 int p_size;
 
 char base[100];
 int base_size;
 
 
 void procura( int ind, int apartir )
 {
 	int i;
 
 	if( ind >= base_size )
 	{
 		acc = (acc + 1) % 10000;
 		return;
 	}
 
 	for( i=apartir; i<p_size; i++ )
 		if( palavra[i] == base[ind] )
 			procura( ind+1, i+1 );
 }
 
 int main( void )
 {
 	int n,caso;
 
 
 	strcpy( base, "welcome to code jam" );
 	base_size = strlen( base );
 
 	scanf("%d\n", &n);
 	for( caso = 1; caso <= n; caso++ )
 	{
 		acc=0;
 		gets( palavra);
 		p_size = strlen( palavra );
 
 		procura( 0, 0 );
 		printf("Case #%d: %4.4ld\n", caso, acc);
 	}
 
 	return 0;
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

