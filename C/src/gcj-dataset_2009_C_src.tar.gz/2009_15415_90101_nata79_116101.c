#include "alien.h"
 
 int comparaLetra(letra l1, char l2){
 	
 	letra i;
 	
 	for(i = l1; i; i = i->next)
 		if(i->l == l2)
 			return 1;
 	return 0;
 }
 
 int comparaPalavra(palavra p1, char * p2){
 	
 	palavra i;
 	int j;
 	
 	for(i = p1, j = 0; i && p2[j]; i = i->next, j++)
 		if(!comparaLetra(i->l, p2[j]))
 			return 0;
 	return 1;
 }
 
 letra insereLetra(letra l, char c){
 	
 	letra a, novo;
 	
 	novo = (letra)malloc(sizeof(struct Letra));
 	novo->l = c;
 	novo->next = NULL;
 	
 	if(!l)
 		return novo;
 	
 	for(a = l; a->next; a = a->next) ;
 	
 	a->next = novo;
 	
 	return l;
 }
 
 palavra inserePalavra(palavra l, letra c){
 	
 	palavra a, novo;
 	
 	novo = (palavra)malloc(sizeof(struct Palavra));
 	novo->l = c;
 	novo->next = NULL;
 	
 	if(!l)
 		return novo;
 	
 	for(a = l; a->next; a = a->next) ;
 	
 	a->next = novo;
 	
 	return l;
 }
 
 dict insereDict(dict l, palavra c){
 	
 	dict a, novo;
 	
 	novo = (dict)malloc(sizeof(struct Dict));
 	novo->p = c;
 	novo->next = NULL;
 	
 	if(!l)
 		return novo;
 	
 	for(a = l; a->next; a = a->next) ;
 	
 	a->next = novo;
 	
 	return l;
 }
 
 void leInput(int L, int D, int N, dict * teste, char * * ver){
 	
 	int i, j, k;
 	//int extra;
 	char linha[20]; //= (char *)malloc(sizeof(char) * (L + 2));
 	char c;
 	palavra p;
 	letra l;
 	
 	for(i = 0; i < D; i++){
 		scanf("%s", linha);
 		getchar();
 		//for(j = 0; j < L; j++)
 		//	ver[i][j] = linha[j];
 		//ver[i][j] = '\0';
 		ver[i] = strdup(linha);
 	}
 	
 	
 	for(i = 0; i < N; i++){
 		p = NULL;	
 		//scanf("%[^\n]\n", linha);
 		//getchar();
 		//extra = 0;
 		for(j = 0; j < L; j++){
 			l = NULL;
 			c = getchar();
 			if(c == '('){
 				for(k = 0; (c = getchar()) != ')'; k++)
 					l = insereLetra(l, c);
 				//extra += k;
 				//j += k;
 			}
 			else l = insereLetra(l, c);
 			p = inserePalavra(p, l);
 		}
 		*teste = insereDict(*teste, p);
 		getchar();
 	}
 	
 }
 
 void conta(dict teste, char * * ver, int D){
 	
 	int conta;
 	int i, j;
 	for(j = 1; teste; teste = teste->next, j++){
 		conta = 0;
 		for(i = 0; i < D; i++)
 			conta += comparaPalavra(teste->p, ver[i]);
 		printf("Case #%d: %d\n", j, conta);
 	}
 }
 
 int main(){
 	
 	int L, D, N;
 	//int i;
 	dict teste = NULL;
 	char * * ver;
 	
 	scanf(" %d %d %d", &L, &D, &N);
 	getchar();
 	
 	ver = (char * *)malloc(sizeof(char *) * D);
 	//for(i = 0; i < D; i++)
 	//	ver[i] = (char *)malloc(sizeof(char) * (L + 1));
 	
 	leInput(L, D, N, &teste, ver);
 	
 	conta(teste, ver, D);
 	
 	return 0;
 }

