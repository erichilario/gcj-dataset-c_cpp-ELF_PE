#include <stdio.h>
 #include <string.h>
 #include <ctype.h>
 #define lmax 20
 #define dmax 5010 
 
 int l, d, n;
 char dic[dmax][lmax], pattern[100*lmax];
 
 int match(char *w, char *p) 
 {
     char hash[26];
     int tok, i = 0;
     for (tok = 0; tok < l; tok++) {
 	memset(hash, 0, sizeof(hash));
 	if (p[i] == '(') {
 	    ++i;
 	    while (p[i] != ')')
 		hash[p[i++] - 'a'] = 1;
 	    ++i;
 	} else 
 	    hash[p[i++] - 'a'] = 1;
 	if (!hash[w[tok] - 'a'])
 	    return 0;
     }
     return 1;
 }
 
 int solve()
 {
     int ret = 0, i;
     for (i = 0; i < d; i++) {
 	if (match(dic[i], pattern))
 	    ++ret;
     }
     return ret;
 }
 
 int main(int argc, char *argv[])
 {
     int i, test;
     scanf("%d%d%d", &l, &d, &n);
     for (i = 0; i < d; i++)
 	scanf("%s", dic[i]);
 
     for (test = 1; test <= n; test++) {
 	scanf("%s", pattern);
 	printf("Case #%d: %d\n", test, solve());
     }
 
     return 0;
 }

