#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 #include <math.h>
 #include <regex.h>
 
 void changeChar(char testCase[500]){
 	int i;
 	for( i = 0;i < strlen(testCase);i++){
 		if(testCase[i] == '('){
 			testCase[i] = '[';
 		} else if(testCase[i] == ')'){
 				testCase[i] = ']';
 		}
 	}
 
 }
 
 int main(){
 
         FILE *in;
         FILE *out;
         in = fopen("A-small.in", "r");
         out = fopen("A-small.out", "w");
 	int L, D, N;
 
         fscanf(in,"%d %d %d", &L, &D, &N);
 	int loop = 0;
 	char alienWords[D][L+1];
         while(loop < D){
 		fscanf(in,"%s", alienWords[loop]);
 		loop++;
 	}
         int cas = 1;
 	char testCase[500];
 	regex_t *reg;
 	int i;
 	int ret;	
 
         while(N > 0){
                 reg = (regex_t*) malloc(sizeof(regex_t));
 		fscanf(in, "%s", testCase);
 		changeChar(testCase);
 		if (regcomp(reg, testCase,REG_EXTENDED | REG_NOSUB)!=0){
                 	printf("Error. Couldn't load regular expression\n");		
 		}
 		ret = 0;
 		for(i = 0;i < D;i++){
 			if (regexec(reg, alienWords[i], 0, NULL, 0)==0) {
                 		ret++;
 	        	}
 
 		}
 
                 fprintf(out, "Case #%d: %d\n", cas, ret);
                 N--;
                 cas++;
 		free(reg);
         }
 
         fclose(in);
         fclose(out);
         return 0;
 }
 

