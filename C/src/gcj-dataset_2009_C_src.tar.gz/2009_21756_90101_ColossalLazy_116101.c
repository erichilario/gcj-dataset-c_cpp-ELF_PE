#include <stdio.h>
 #include <stdlib.h>
 
 typedef struct _Word
 {
 	char *word;
 } Word ;
 
 typedef struct _Test
 {
 	char *test;
 } Test ;
 
 int main (void)
 {
 	int l,d,n,i,j,k,testn,testchar,par;
 	Word *vetor;
 	Test *vetor2;
 
 	scanf("%d%d%d",&l,&d,&n);
 
 	vetor = (Word *) malloc (d * sizeof (Word));
 	vetor2 = (Test *) malloc (n * sizeof (Test));
 
 	for(i=0;i<d;i++)
 	{
 		vetor[i].word = (char *) malloc (l * sizeof (char));
 		scanf ("%s",vetor[i].word);
 	}
 	for(i=0;i<n;i++)
 	{
 		vetor2[i].test = (char *) malloc (1000 * sizeof (char));
 		scanf ("%s",vetor2[i].test);
 	}
 
 	printf("\n");
 
 	for (i=0;i<n;i++)
 	{
 		testn = 0;
 		for (j=0;j<d;j++)
 		{
 			testchar = 0;
 			par = 0;
 			for (k=0;k<l;k++)
 			{
 				if (vetor2[i].test[k+par]=='(')
 				{
 					par++;
 					while(vetor2[i].test[k+par]!=')')
 					{
 						if(vetor2[i].test[k+par]==vetor[j].word[k])
 						{
 							testchar++;
 							par++;
 						}
 						else
 						{
 							par++;
 						}
 					}
 				}
 				else
 				{
 					if(vetor2[i].test[k+par]==vetor[j].word[k])
 					{
 						testchar++;
 					}
 					else
 					{
 						break;
 					}
 				}
 			}
 			if (testchar==l)
 			{
 				testn++;
 			}
 		}
 		printf("Case #%d: %d\n",i+1,testn);
 	}
 
 }
 

