#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 
 int N;
 int K;
 int L;
 int D;
 
 #define MAXL 15 
 #define MAXD 5000
 #define MAXN 500
 
 const int MAXL5 = 35*MAXL;
 const int MAXL2 = 20*MAXL;
 
 char str[MAXD][MAXL+ 1];
 char que[MAXN][35*MAXL + 1];
 char temp[MAXL][20*MAXL + 1];
 int found[MAXN]={0};
 int matchedA[MAXN]={0};
 
 
 int index1[MAXL] = {0};
 char broken[MAXN][MAXL][MAXL*35+1];
 int MAXLENGTH[MAXN][MAXL] = {0};
 
 
 struct stringA{
 	char st[MAXL][MAXL*20];
 };
 
 int incr(int ind[] , int brekup);
 int search(char st[]){
 	int i;
 	for(i=0 ; i<D ; i++){
 		if(strcmp(st,str[i]) == 0){
 			return 1;
 		}
 	}
 	return 0;
 }
 
 struct stringA part(char arg[MAXL5], char ret[MAXL][MAXL2]){
 	int wCount=0;
 	int k=0;
 	while(wCount < MAXL){
 		if( arg[k]=='(' ){
 			k++;
 			int l=0;
 			while(arg[k] != ')'){
 				ret[wCount][l] = arg[k];
 				l++;
 				k++;	
 			}	
 			k++;
 			ret[wCount][l] = '\0';
 			wCount ++;
 		}	
 		else{
 			ret[wCount][0] = arg[k];
 			ret[wCount][1] = '\0';
 			wCount ++;
 			k++;	
 		}	
 	}
 //	printf("\n");
 	struct stringA retA;
 	int i;
 	for( i=0 ; i<MAXL; i++){
 		strcpy(retA.st[i],ret[i]);
 //		printf("\t %s \t",ret[i]);
 	}
 	
 	return retA;
 }
 
 int main(int argc, char* argv[]){
 
 	if(argc != 2 ){
 		printf("\nUsage:filename inutfile\n");
 		return -1;
 	}
 	FILE * fp = fopen(argv[1],"r");
 	FILE * fout = fopen("out.txt","w");
 	if(fp == NULL || fout == NULL){
 		printf("\nCannot open a file\n");
 	}
 	fscanf(fp,"%d",&L);
 	fscanf(fp,"%d",&D);
 	fscanf(fp,"%d",&N);
 //	printf("\n%d %d %d\n",L, D, N);
 	int i;
 	for(i=0 ; i < D ; i++){
 		fscanf(fp,"%s",&str[i][0]);
 //		printf("%s\n",&str[i][0]);
 	}
 	int j=0;	
 	for(j=0; j<N ; j++){
 //		int k=0;
 //		do{
 //			fscanf(fp,"%c",&que[j][k]);
 //		}
 //		while(que[j][k] != '\n' || que[j][k] !/=);
 		fscanf(fp,"%s",&que[j][0]);
 //		printf("\n%s\n",que[j]);
 		
 		struct stringA strA = part(que[j],temp);	
 		int x;
 		for(x=0 ; x<L ; x++){
 			strcpy(broken[j][x],strA.st[x]);
 		}
 		
 		int iteration = 1;
 		for(i=0 ; i < L ; i++){
 			index1[i]=0;
 			MAXLENGTH[j][i] = strlen(strA.st[i]);	
 //			iteration *= MAXLENGTH[i];
 		}
 	/*
 		char word[MAXL+1];
 		int t=0;
 		int count=0;
 		for(t=0 ; t < iteration ; t++){
 			int s=0;
 			for( s=0 ; s< L ;s++){
 				word[s] = strA.st[s][index1[s]];
 			}
 			word[s] = '\0';
 			printf(".");
 			count += search(word);
 			incr(index1,L-1);
 		}
 		printf("Case #%d:%d\n",j+1,count);*/
 	}
 /*		int ii,jj,kk;
 		for(ii=0 ; ii < N ; ii++){
 			for(jj=0 ; jj < L ;jj++){
 				printf(" %s ",broken[ii][jj]);
 			}
 			printf("\n");
 		}
 */
 	int ij;
 		int g;
 	for(ij = 0 ; ij < D ; ij ++){
 		newSearch(str[ij],matchedA);
 //		printf("\n");
 	}
 	for(g=0 ; g<N ; g++){	
 		fprintf(fout,"Case #%d: %d\n",g+1, matchedA[g]);
 	}
 	fclose(fout);
 	fclose(fp);
 }
 
 /*int incr(int ind[] , int breakup){
 	if(breakup < 0 ){
 		return breakup;
 	}
 	int t = ++ind[breakup];
 	if(t >= MAXLENGTH[breakup][t]){
 		ind[breakup] = 0;
 		incr(ind, breakup-1);
 	}
 	else{
 		return breakup;
 	}
 }
 */
 
 
 int newSearch(char * arg, int matched[MAXN]){
 	int i=0;
 	int j=0;
 	int k=0;
 	int flag = 0;
 	for(j=0 ; j<N ; j++){
 		int found = 0;
 		for(i=0 ; i<L ; i++){
 			found = 0;
 			for(k=0 ; k < MAXLENGTH[j][i] ;k++){
 				if(arg[i] == broken[j][i][k]){
 					found =  1;	
 					break;
 				}
 			}
 			if(found == 0){
 				flag = 0;
 				break;
 			}else{
 				flag = 1;
 			}
 		}
 		if(flag == 1){
 			matched[j] += 1;
 		}
 		
 	}
 return;
 }
 
 

