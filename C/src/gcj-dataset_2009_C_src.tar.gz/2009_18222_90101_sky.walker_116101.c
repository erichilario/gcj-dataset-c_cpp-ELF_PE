#include<stdio.h>
 #include<string.h>
 
 char word[5000][16], test[500][256];
 int L=0,D=0,N=0,i=0,count=0;
 FILE *fdata,*fout;
 
 int main()
 {
 	
 	fout=fopen("out","w");
 	//fldn=fopen("LDN", "r");
 	fdata=fopen("data", "r");
 	//ftest=fopen("testcase", "r");
 	fscanf(fdata,"%d %d %d",&L,&D,&N);
 	for(i=0;i<D;i++)
 	{
 		fscanf(fdata,"%s",word[i]);
 	}
 	for(i=0;i<N;i++)
 	{
 		fscanf(fdata,"%s",test[i]);
 	}
 	
 	fclose(fdata);
 	//fclose(fldn);
 	//fclose(ftest);
 
 	
 	for(i=0;i<N;i++)
 	{
 		count = match_test(test[i]);
 		fprintf(fout,"Case #%d: %d\n",(i+1),count);
 	}
 	fclose(fout);
 return(0);
 }
 
 //-----------------------------------------------------------------------------------------------------------------------------------------------------//
 
 int match_test(char test1[256])
 {
 
 	int i=0,j=0,k=0,guard=1,len=0,max=0,count=0;
 	
 	for(i=0;i<D;i++,guard=1)
 	{
 		for(k=0,j=0;j<L && guard==1;j++,k++)
 		{
 			if(test1[k] == '(')
 			{
 				for(len=0;test1[k+len]!= ')';len++);
 				max=k+len;
 				for(;k<max;k++)
 				{
 					if(test1[k]==word[i][j])
 					{
 						guard=1;
 						k=max;
 						break;
 					}
 					else
 					{
 						guard=0;
 					}
 				}
 				if(guard==0)
 					break;
 				else;
 			}
 			else
 			{
 				if(test1[k]==word[i][j])
 					guard=1;
 			
 				else
 				{
 					guard=0;
 					break;
 				}
 			}
 		}
 		if(guard == 1)
 			count++;
 		else;
 	}
 return count;
 }
 //----------------------------------------------------------------------------------------------------------------------------------------------------//
 

