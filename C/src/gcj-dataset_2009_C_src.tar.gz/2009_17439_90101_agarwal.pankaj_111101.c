#include<stdio.h>
 int main()
 {
 	int i,n,h,w1,j,k,cnt,s,p,q,r,min,ck;
 	int w[200][200],a[100][100];
 	char ch,ch1,c[1000];
 	
 	freopen("B-small-attempt1.in","r",stdin);
 	freopen("out.txt","w",stdout);
     scanf("%d",&n);
     for(i=1;i<=n;i++)
     {
         scanf("%d%d",&h,&w1);
         
         for(j=1;j<200;j++)
         for(k=1;k<200;k++)
         {
             if(j==k)
             w[j][k]=1;
             else
             w[j][k]=0;
         }
         for(j=1;j<=h;j++)
         for(k=1;k<=w1;k++)
             scanf("%d",&a[j][k]);
             
             
         for(j=1;j<=h;j++)
         for(k=1;k<=w1;k++)
         {
             min=20000;
             p=q=r=s=-1;
             
             if(k+1<=w1)
             p=a[j][k+1];
             
             if(k-1>=1)
             q=a[j][k-1];
 
             if(j-1>=1)
             r=a[j-1][k];
             
             if(j+1<=h)
             s=a[j+1][k];
             
    			if(a[j][k]<min)
             min=a[j][k];
             
 			if(r<min && r!=-1)
             min=r;
 			
 			if(q<min && q!=-1)
             min=q;
 			            
             if(p<min && p!=-1)
             min=p;
 
             if(s<min && s!=-1)
             min=s;
 
             
             
             if(min==p && min!=a[j][k])
             w[(j-1)*w1+k][(j-1)*w1+k+1]=1;
             
             if(min==q && min!=a[j][k])
             w[(j-1)*w1+k][(j-1)*w1+k-1]=1;
             
             if(min==r && min!=a[j][k])
             w[(j-1)*w1+k][(j-1)*w1+k-w1]=1;
              
             if(min==s && min!=a[j][k])
             w[(j-1)*w1+k][(j-1)*w1+k+w1]=1;
             
             
         }
         
         for(j=1;j<=h*w1;j++)
         c[j]='0';
         
         
         	ck=1;
         	s=1;
         	c[1]='a';
 			while(ck==1)
             {
             	ck=0;
 			for(k=1;k<=h*w1;k++)
             {
 				if(w[s][k]==1 && s!=k)
 				{
 					c[k]='a';
 					ck=1;
 					s=k;
 					break;
 				}
 				
             }
             
             }
           
 	  	c[s]='a';
 			    
 		ch1='a';
 			
 		for(j=2;j<=h*w1;j++)
         {
         	
         	ck=1;
         	s=j;
         	cnt=0;
         	
         	
         	if(c[j]!='0')
         	{
         		ch=c[j];
         		cnt=1;
         	}
         	
 			while(ck==1)
             {
             	ck=0;
 			for(k=1;k<=h*w1;k++)
             {
 				if(w[s][k]==1 && s!=k)
 				{
 					if(c[k]!='0')
 					{
 						cnt=1;
 						ch=c[k];
 						break;
 					}
 					ck=1;
 					s=k;
 					break;
 				}
 				
             }
             }
             
             if(cnt!=1)
         	ch=++ch1;
 			
 					
 			
 			
 			ck=1;
         	s=j;
   			c[s]=ch;
 			while(ck==1)
             {
             	ck=0;
 			for(k=1;k<=h*w1;k++)
             {
 				if(w[s][k]==1 && s!=k)
 				{
 					c[k]=ch;
 					ck=1;
 					s=k;
 					break;
 				}
 				
             }
             
             }
    			         
         	
         }
    
 		   printf("Case #%d:\n",i);
         for(j=1;j<=w1*h;j++)
         {
         	if(j%w1!=0)
         	printf("%c ",c[j]);
         	else
         	printf("%c\n",c[j]);
         }
     }
 return 0;
 }
    
           		

