#include <stdio.h>
 #include <stdlib.h>
 
 char mat[105][105];
 int val[105][105];
 int h, w;
 
 char rec(int i, int j, char l) {
 	int lo, ii, jj;
 	char c;
 	lo = 100001;
 	if (i - 1 >= 0 && val[i-1][j] < val[i][j] && val[i-1][j] < lo) {
 		lo = val[i-1][j];
 		ii = i-1;
 		jj = j;
 	} 
 	if (j - 1 >= 0 && val[i][j-1] < val[i][j] && val[i][j-1] < lo) {
 		lo = val[i][j-1];
 		ii = i;
 		jj = j-1;
 	}
 	if (j + 1 < w && val[i][j+1] < val[i][j] && val[i][j+1] < lo) {
 		lo = val[i][j+1];
 		ii = i;
 		jj = j+1;
 	}
 	if (i + 1 < h && val[i+1][j] < val[i][j] && val[i+1][j] < lo) {
 		lo = val[i+1][j];
 		ii = i+1;
 		jj = j;
 	}
 	if (lo != 100001) {
 		c = rec(ii, jj, l);	
 		mat[i][j] = c;
 		return c;
 	} else {
 		if (mat[i][j] != 10 && l > mat[i][j]) {
 			return mat[i][j];	
 		} else {
 			mat[i][j] = l;
 			return l;	
 		}
 	}
 }
 
 int main () {
 	int i, j, k, l, m, n, o, p, q, r, s, t;
 	
 	scanf("%d", &t);
 	for (o = 1; o <= t; o++) {
 		scanf(" %d %d ", &h, &w);
 		
 		for (i = 0; i < h; i++) {
 			for (j = 0; j < w; j++) {
 				scanf("%d", &val[i][j]);
 				mat[i][j] = 10;	
 			}	
 		}	
 		
 		l = 'a';
 		for (i = 0; i < h; i++) {
 			for (j = 0; j < w; j++) {
 				if (mat[i][j] == 10) {
 					k = rec(i, j,l);
 					if (k == l) {
 						l++;	
 					} 
 				}
 			}	
 		}
 		
 		for (m = 0; m < 26; m++) {
 			l = 'a';
 			for (i = 0; i < h; i++) {
 				for (j = 0; j < w; j++) {
 					if (mat[i][j] >= l) {
 					k = rec(i, j,l);
 					if (k == l) {
 						l++;	
 					} else if (k < l) {
 						l = k + 1;	
 					}
 				}
 				}	
 			}
 		}
 		
 		printf("Case #%d:\n", o);
 		for (i = 0; i < h; i++) {
 			printf("%c", mat[i][0]);
 			for (j = 1; j < w; j++) {
 				printf(" %c", mat[i][j]);	
 			}	
 			printf("\n");
 		}
 	}	
 	return 0;	
 }

