/*
  * io.c
  *
  *  Created on: 2009-9-3
  *      Author: will
  */
 #include "io.h"
 
 void read_input(FILE **p, int mode, char ***std_words, int* num_of_letter, int* num_of_words, int* num_of_tests)
 {
 
 	char current;
 	int i, j;
 	if (mode == 0)
 		*p = fopen("A-small.in", "r");
 	else if (mode == 1)
 		*p = fopen("A-large.in", "r");
 
 	if (*p == NULL)
 	{
 		printf("Input file wrong\n");
 		return;
 	}
 
 	fscanf(*p, "%d %d %d\n", num_of_letter, num_of_words, num_of_tests );
 
 	(*std_words) = malloc(*num_of_words*sizeof(char*));
 	for(i=0;i<*num_of_words; i++)
 		(*std_words)[i] = malloc(*num_of_letter + 1);
 
 	for(i=0;i<*num_of_words; i++)
 	{
 		for(j=0;j<*num_of_letter; j++)
 		{
 			current = fgetc(*p);
 			(*std_words)[i][j] = current;
 		}
 		current = fgetc(*p);
 		if (current != '\n')
 		{
 			printf("Error format\n");
 			return;
 		}
 
 
 	}
 
 }
 
 void read_one_test(FILE **fp, char ***test, int num_of_letter)
 {
 	int i, j;
 	char current;
 	int multi = 0;
 	for(i=0;i<num_of_letter; i++)
 	{
 		multi = 0;
 		for(j=1;;)
 		{
 			current = fgetc(*fp);
 			if (current != '(' && current != ')')
 			{
 				(*test)[i][j] = current;
 				j++;
 				if (multi == 0)
 				{
 					(*test)[i][0] = 1;
 					break;
 				}
 			}
 			else if (current == '(')
 			{
 				multi = 1;
 			}
 			else /*')'*/
 			{
 				(*test)[i][0] = j-1;
 				break;
 			}
 		}
 
 	}
 	current = fgetc(*fp);
 	if (current != '\n')
 	{
 		printf("Error format in test\n");
 		return;
 	}
 
 }
 
 void strip_words_single(char ***std_words, char ** test, int num_of_letter, int num_of_words )
 {
 	int i, j;
 	for (i=0;i<num_of_letter;i++)
 	{
 		if (test[i][0] == 1)
 		{
 			for (j=0;j<num_of_words;j++)
 			{
 				if ((*std_words)[j][i] != test[i][1])
 					(*std_words)[j][num_of_letter+1] = 'n';
 			}
 		}
 	}
 
 }
 
 void strip_words_multi(char ***std_words, char ** test, int num_of_letter, int num_of_words )
 {
 	int i, j, k;
 	char current;
 	int match;
 	for (i=0;i<num_of_words;i++)
 	{
 		match = 0;
 		if ((*std_words)[i][num_of_letter+1] == 'y')
 		{
 			for (j=0;j<num_of_letter;j++)
 			{
 				current = (*std_words)[i][j];
 				for (k=1;k<test[j][0]+1;k++)
 				{
 					if (current == test[j][k])
 					{
 						match++;
 						break;
 					}
 
 				}
 
 			}
 			if (match != num_of_letter)
 				(*std_words)[i][num_of_letter+1] = 'n';
 		}
 	}
 
 }
 
 int calculate_match(char ***std_words, int num_of_letter, int num_of_words )
 {
 	int i;
 	int words = 0;
 	for (i=0;i<num_of_words;i++)
 	{
 		if ((*std_words)[i][num_of_letter+1] == 'y')
 			words++;
 	}
 	return words;
 
 }
 
 void write_output(int mode, int* output, int num_of_tests)
 {
 	FILE *fp;
 	int i;
 	if (mode == 0)
 		fp = fopen("A-small.out", "w");
 	else if (mode == 1)
 		fp = fopen("A-large.out", "w");
 	if (fp == NULL)
 	{
 		printf("Output file wrong\n");
 		return;
 	}
 	for (i=0;i<num_of_tests;i++)
 	{
 		fprintf(fp, "Case #%d: %d\n", i+1, output[i]);
 	}
 	fclose(fp);
 }
 
 

