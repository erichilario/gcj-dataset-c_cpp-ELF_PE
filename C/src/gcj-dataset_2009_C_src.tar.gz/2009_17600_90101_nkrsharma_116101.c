#include <stdio.h>
 
 int main()
 {
     char dict[5001][16];
     char hash[5001], c;
     int L,D,N, i, j, k, flag, count;
     scanf("%d %d %d", &L, &D, &N);
     getchar();
 
     for(i=0;i<D;i++)
         gets(dict[i]);
 
     for(i=0;i<N;i++){
         for(j=0;j<D;j++) hash[j]=0;
         count = 0;
         j = 0; flag = 0;
         while((c=getchar())!='\n'){
             if(c>='a' && c<='z'){
                 for(k=0;k<D;k++){
                     if(dict[k][j]==c && hash[k]==0)
                         hash[k]=1;
                 }
             }
             else if(c=='(') flag = 1;
             else flag = 0;
 
             if(flag==0){
                 for(k=0;k<D;k++) hash[k]--;
                 j++;
             }
         }
         for(j=0;j<D;j++)
             if(hash[j]==0) count++;
         printf("Case #%d: %d\n",i+1,count);
     }
     return 0;
 }

