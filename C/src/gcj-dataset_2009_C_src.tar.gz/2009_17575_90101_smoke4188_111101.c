#include<stdio.h>
 #include<limits.h>
 
 FILE *inf,*outf;		//file pointer
 
 int max(int a,int b)	//max of a and b	
 {	if(a>b)	return a;
 	else    return b;
 } 	
 
 int min(int a,int b)	//min of a and b
 {	if(a<b)	return a;
 	else    return b;
 }
 
 int getint(FILE *ptr)	//convert char to number
 {	int num=0;
 	char c;
 	while((c=getc(ptr))!='\n'&&c!=' '&&c!='\0'&&c!=EOF)
         num=num*10+(c-48);
     return num;
 }
 
 char alpha='a';			//global labelling variable
 
 int sink(int **map,char **res,int *m,int *n)		//test if the point is a sink or not
 {	int flow=0,min=map[*m][*n];
 	if(map[*m-1][*n]<min)	flow=1,min=map[*m-1][*n];
 	if(map[*m][*n-1]<min)	flow=2,min=map[*m][*n-1];
 	if(map[*m][*n+1]<min)	flow=3,min=map[*m][*n+1];
 	if(map[*m+1][*n]<min)	flow=4,min=map[*m+1][*n];
 	return flow;
 }
 
 char trace(int **map,char **res,int m,int n)		//trace the path to a sink
 {	int dir=sink(map,res,&m,&n);
 	switch(dir)
 	{	case 0:
 			 if(res[m-1][n-1]=='.')	
 				 res[m-1][n-1]=alpha++;
 	   		 break;
 	    case 1:
 			 res[m-1][n-1]=trace(map,res,m-1,n);
 			 break;
 		case 2:
 			 res[m-1][n-1]=trace(map,res,m,n-1);
 			 break;
 		case 3:
 			 res[m-1][n-1]=trace(map,res,m,n+1);
 			 break;
 		case 4:
 			 res[m-1][n-1]=trace(map,res,m+1,n);
 			 break;
 	 }
 	 return res[m-1][n-1];
 }	 
 
 char **basin(int **map,int x,int y)			//fill the result map with basin labels
 {	char **res;
 	int i,j;
 	//allocate
 	res=(char**)malloc(sizeof(char *)*(y));
 	for(i=0;i<y;i++)
 	    res[i]=(char*)malloc(sizeof(char)*(x));
 	//init
 	for(i=0;i<y;i++)
  	    for(j=0;j<x;j++)
      		res[i][j]='.';
 	//fill
 	for(i=0;i<y;i++)
 		for(j=0;j<x;j++)
 			if(res[i][j]=='.')
 				trace(map,res,i+1,j+1);	
 	return res;	
 }
 
 void watershed(FILE *inf,FILE *outf)			
 {	char **res;
 	char s='a';
 	int totaltest,test=1,i,j,k,x,y,**map,z;
 	totaltest=getint(inf);
 	for(z=0;z<totaltest;z++)
 	{	y=getint(inf);
 		x=getint(inf);
 		alpha='a';
 		//print to file
 		fprintf(outf,"Case #%d:\n",z+1);
 		//map allocation
 		map=(int**)malloc(sizeof(int *)*(y+2));
 		for(i=0;i<=y+1;i++)
 		    map[i]=(int*)malloc(sizeof(int)*(x+2));
 		//result allocation
 		res=(char**)malloc(sizeof(char *)*(y));
 		for(i=0;i<y;i++)
 		    res[i]=(char*)malloc(sizeof(char)*(x));
   		{	//boundary
 	   		for(k=0;k<x+1;k++)	map[0][k]=INT_MAX;
 		 	for(k=0;k<y+1;k++)	map[k][x+1]=INT_MAX;
 			for(k=x+1;k>0;k--)	map[y+1][k]=INT_MAX;
 			for(k=y+1;k>0;k--)	map[k][0]=INT_MAX;
 		}	
 		{	//fill map
 			for(i=1;i<=y;i++)
 	            for(j=1;j<=x;j++)
      		        map[i][j]=getint(inf);
 		}
 		//labeling
 		res=basin(map,x,y);
 		//print to file
 		for(i=0;i<y;i++)
 		{   for(j=0;j<x;j++)
      		    fprintf(outf,"%c ",res[i][j]);
 			fseek(outf,-1,SEEK_CUR);		  
 			fprintf(outf,"\n");	
 		} 
     }
 }
 
 int main()
 {	FILE *inf,*outf;
 	char *filename;
 	printf("Enter the input file name : ");
 	scanf("%s",filename);
 	inf=fopen(filename,"r");
 	outf=fopen("output.in","w");
 	watershed(inf,outf);
 	fclose(inf);	
 	fclose(outf);
 	printf("Output file name : output.in\n");
 	getch();
 	return 0;
 }
 
 /*	Soumya Ranjan Maharana
 	soumya.r.maharana@gmail.com  */
 
 /*	Dev C++ portable    version 4.9.9.2
 	http://www.bloodshed.net/
 	Copyright (C) Bloodshed software 		*/

