#include <stdio.h>
 #include <string.h>
 
 //#define PRINT_DEBUG(_X_) printf _X_
 #define PRINT_DEBUG(_X_)
 
 char inputStr[510];
 char str2Search[]="welcome to code jam";
 int  i32Occurence = 0;
 
 int formStrSequence ( int i32searchStringIndex, int i32inputStringIndex );
 
 int main( void )
 {
 
 	FILE *inputfp = fopen ("C-small-attempt0.in", "rb");
 	FILE *outputfp = fopen ("output.txt", "w");	
 
 	if ( !inputfp || ! outputfp )
 	{
 		PRINT_DEBUG (("Error in opening file\n"));
 
 		return 0;
 	}
 
 	int i32Line,i32NoOfLines;
 	fscanf ( inputfp,"%d", &i32NoOfLines);
 
 	// read the new line char in the first line
 	char temp[4];
 	fgets ( temp, 4, inputfp );
 
 	for ( i32Line = 1; i32Line<=i32NoOfLines; ++i32Line )
 	{
 		memset ( inputStr, 0, sizeof(inputStr) );
 		i32Occurence = 0;
 		fgets ( inputStr, 500, inputfp );
 
 		PRINT_DEBUG (("********%s********",inputStr));
 
 		PRINT_DEBUG (("\nString length=%d\n",strlen(inputStr)));		
 
 		PRINT_DEBUG (("Last-1[%d] last[%d]\n",inputStr[strlen(inputStr)-2],inputStr[strlen(inputStr)-1] ));
 
 		if ( strlen(inputStr) > 2 )
 		{
 			if ( inputStr[ strlen(inputStr) - 2 ] == 13 && inputStr[ strlen(inputStr) - 1 ] == 10 )
 			{
 				inputStr[ strlen(inputStr) - 2 ] = 0;
 				PRINT_DEBUG (("Removing dos endline\n"));
 			}
 			else if ( inputStr[ strlen(inputStr) - 1 ] == 10 )
 			{
 				inputStr[ strlen(inputStr) - 1 ] = 0;
 				PRINT_DEBUG (("Removing unix endline\n"));
 			}
 		}
 		
 		PRINT_DEBUG (("------%s--------",inputStr));
 
 		PRINT_DEBUG (("\nString length=%d\n",strlen(inputStr)));
 
 //		PRINT_DEBUG (("\nCode jam length=%d\n",strlen(str2Search)));		
 
 		formStrSequence ( 0, 0 );
 
 		PRINT_DEBUG (("Occurence=%d\n",i32Occurence));		
 
 		fprintf (outputfp,"Case #%d: %04d\n",i32Line,i32Occurence);
 		PRINT_DEBUG (("Case #%d: %04d\n",i32Line,i32Occurence));
 
 		if ( feof (inputfp) )
 		{
 			PRINT_DEBUG (("EOF reached\n"));
 
 			break;
 		}
 	}
 
 	if ( inputfp )
 	{
 		fclose ( inputfp );
 		inputfp = NULL;
 	}
 
 	if ( outputfp )
 	{
 		fclose ( outputfp );
 		outputfp = NULL;
 	}
 
 	return 0;
 }
 
 int formStrSequence ( int i32searchStringIndex, int i32inputStringIndex )
 {
 	int i;
 	char cfound=0;
 
 //	PRINT_DEBUG (("Search char[%c] from [%d]\n",str2Search[i32searchStringIndex],i32inputStringIndex));	
 
 	for ( i =  i32inputStringIndex; i < strlen(inputStr); ++i )
 	{
 		if ( inputStr[i] == str2Search[i32searchStringIndex] )
 		{
 			cfound = 1;
 
 			if ( i32searchStringIndex == (strlen(str2Search) - 1) )
 			{
 //				PRINT_DEBUG (("!!!!Found\n"));
 				++i32Occurence;
 				i32Occurence = i32Occurence % 10000;
 			}
 			else
 			{
 				if ( -1 == formStrSequence ( i32searchStringIndex + 1, i + 1 ) )
 				{
 					break;
 				}
 			}
 		}
 	}
 
 	if ( cfound == 0 )
 	{
 		return -1;
 	}
 
 	return 0;
 }
 

