/* Google Code Jam 2009
  * Qualification Round
  * Problem B: Watersheds
  */
 
 #include <stdio.h>
 
 int stack[100 * 100 * 2 + 10];
 int stacktop;
 #define push(X,Y)      (stack[stacktop++] = X, stack[stacktop++] = Y)
 #define pop(X,Y)       (Y = stack[--stacktop], X = stack[--stacktop])
 #define notempty()     stacktop
 
 int map[105][105];
 int labels[105][105];
 
 int pickorder[5][2] = {
 	{ 0 , 0 },
 	{ -1, 0 },
 	{ 0, -1 },
 	{ 0, +1 },
 	{ +1, 0 }
 };
 
 int height, width;
 
 #define inside(h, w) (h >= 0 && h < height && w >= 0 && w < width)
 
 int pickflow(int h, int w, int *nh, int *nw)
 {
 	int i;
 	int lowest = 0;
 	int lowh, loww;
 
 	lowh = h;
 	loww = w;
 
 	for (i = 1; i <= 4; i++) {
 		int th = h + pickorder[i][0];
 		int tw = w + pickorder[i][1];
 
 		if (inside(th, tw) && map[th][tw] < map[lowh][loww]) {
 			lowh = th;
 			loww = tw;
 			lowest = i;
 		}
 	}
 
 	if (nh) {
 		*nh = lowh;
 		*nw = loww;
 	}
 
 	return lowest; 
 }
 
 
 int main(void)
 {
 	int nummaps, nummap;
 	int label;
 
 	scanf("%d", &nummaps);
 	for (nummap = 1; nummap <= nummaps; nummap++) {
 		int w, h;
 		int sw, sh;
 		
 		scanf("%d%d", &height, &width); 
 		for (h = 0; h < height; h++) {
 			for (w = 0; w < width; w++) {
 				scanf("%d", &map[h][w]);
 				labels[h][w] = '.';
 			}
 		}
 
 		label = 'a' - 1;
 		for (sh = 0; sh < height; sh++) {
 			for (sw = 0; sw < width; sw++) {
 
 				push(sh, sw);
 				if (labels[sh][sw] == '.') {
 					label++;
 				}
 
 				while (notempty()) {
 					int i, flowto, flowfrom;
 					int nh, nw;
 
 					pop(h, w);
 					if (labels[h][w] != '.') {
 						continue;
 					}
 					labels[h][w] = label;
 
 					if ((flowto = pickflow(h, w, &nh, &nw))) {
 						/* flows to the lowest neighbour
 						 */
 						push(nh, nw);
 					}
 					for (i = 1; i <= 4; i++) {
 						/* checks if the neighbours flow to me
 						 */
 						if (i == flowto) {
 							continue;
 						}
 						nh = h + pickorder[i][0];
 						nw = w + pickorder[i][1];
 						flowfrom = pickflow(nh, nw, NULL, NULL);
 						if (flowfrom == 5 - i) {
 							push(nh, nw);
 						}
 					}
 				}
 			}
 		}
 
 		printf("Case #%d:\n", nummap);
 		for (h = 0; h < height; h++) {
 			printf("%c", labels[h][0]);
 			for (w = 1; w < width; w++) {
 				printf(" %c", labels[h][w]);
 			}
 			printf("\n");
 		}
 	}
 
 	return 0;
 }

