#include <stdio.h>
 #include <stdlib.h>
 
 int main () {
 	int val_l, val_d, val_n;
 	int i,j,k,lk;
 	scanf ("%d %d %d\n", &val_l, &val_d, &val_n);
 	char ** words = (char **)malloc (val_d * sizeof (char *));
 	for (i=0; i<val_d; i++) {
 		words[i] = (char *) malloc (val_l * sizeof (char));
 		scanf ("%s", words[i]);
 //		printf ("%s\n", words[i]);
 	}
 	char temp[1000];
 	int * count = (int *)malloc (val_n * sizeof (int));
 	for (i=0; i<val_n; i++) {
 		scanf ("%s", temp);
 		printf ("%s\n", temp);
 		count [i] = 0;
 		for (j=0; j<val_d; j++) {
 			int flag = 0;
 			for (lk=0, k=0; k < val_l; k++, lk++) {
 				if (temp[lk] != '(') {
 					if (words[j][k] != temp[lk]) {
 					flag = 1;
 					break;
 					}
 				}
 				else {
 					while ( temp[++lk] != ')' ) {
 					//	printf ("hai %c %c\n",temp[lk], words[j][k]);
 						if (temp[lk] == words[j][k])
 							break;
 					}
 					if (temp[lk] != words[j][k]) {
 						flag = 1;
 						break;
 					}
 					else
 						while ( temp[++lk] != ')' );
 				}
 			}
 			if (flag == 0)
 				count[i]++;
 		}
 	}
 	for (i=0; i< val_n; i++)
 		printf ("Case #%d: %d\n", i+1, count[i]);
 }

