#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 int function(char*a, char*b)
 {
     if(a[0]=='\0')
         return 0;
     if(a[0]==b[0]){
         if(b[1]!='\0') return (function(a+1,b) + function(a+1,b+1))%10000;
         else return 1 + function(a+1,b);
     }
     return function(a+1,b);
 }
 
 int main()
 {
     char *a, *b;
     a = (char*)malloc(50*sizeof(char));
     b = (char*)malloc(50*sizeof(char));
     strcpy(b,"welcome to code jam");
 
     int t,i;
     scanf("%d",&t);getchar();
     for(i=0;i<t;i++){
         gets(a);
         printf("Case #%d: %04d\n",i+1,function(a,b));
     }
     return 0;
 }

