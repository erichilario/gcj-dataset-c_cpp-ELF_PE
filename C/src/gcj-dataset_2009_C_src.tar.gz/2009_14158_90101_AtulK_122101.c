#include <stdio.h>
 #include <string.h>
 
 typedef struct CharInfo
 {
     int FreqCount;
     int Pos[500];
     long long int NumSuffix[500];
 } CHAR_INFO;
 
 char Line[1000];
 char Welcome[] = "welcome to code jam";
 
 CHAR_INFO InfoArr[19];
 
 long long int Result;
 
 void Process( void )
 {
     int i, j, k;
 
     for ( i = 0; i < 19; i++ )
     {
         char ch = Welcome[i];
         char *p = Line;
         char *q;
 
         InfoArr[i].FreqCount = 0;
 
         while ( ( q = strchr( p, ch ) ) != NULL )
         {
             InfoArr[i].Pos[InfoArr[i].FreqCount] = q - Line;
             InfoArr[i].FreqCount++;
             p = q + 1;
         }
 
         if ( InfoArr[i].FreqCount == 0 )
         {
             Result = 0;
             return;
         }
     }
 
     for ( i = 0; i < InfoArr[18].FreqCount; i++ )
     {
         InfoArr[18].NumSuffix[i] = 1;
     }
 
     for ( i = 17; i >= 0; i-- )
     {
         for ( k = InfoArr[i].FreqCount - 1; k >= 0; k-- )
         {
             InfoArr[i].NumSuffix[k] = 0;
 
             if ( k == ( InfoArr[i].FreqCount - 1 ) )
             {
                 for ( j = 0; j < InfoArr[i + 1].FreqCount; j++ )
                 {
                     if ( InfoArr[i + 1].Pos[j] > InfoArr[i].Pos[k] )
                     {
                         InfoArr[i].NumSuffix[k] += InfoArr[i + 1].NumSuffix[j];
                     }
                 }
             }
             else
             {
                 InfoArr[i].NumSuffix[k] += InfoArr[i].NumSuffix[k + 1];
 
                 for ( j = 0; j < InfoArr[i + 1].FreqCount; j++ )
                 {
                     if ( ( InfoArr[i + 1].Pos[j] > InfoArr[i].Pos[k] ) && ( InfoArr[i + 1].Pos[j] < InfoArr[i].Pos[k + 1] ) )
                     {
                         InfoArr[i].NumSuffix[k] += InfoArr[i + 1].NumSuffix[j];
                     }
                 }
 
             }
         }
     }
 
     Result = 0;
 
     for ( k = 0; k < InfoArr[0].FreqCount; k++ )
     {
         Result += InfoArr[0].NumSuffix[k];
     }
 }
 
 int main( void )
 {
     int i, N;
     int res;
 
     gets( Line );
     sscanf( Line, "%d", &N );
 
     for ( i = 0; i < N; i++ )
     {
         gets( Line );
 
         Process();
 
         /* printf( "Case #%d: %I64d\n", i + 1, Result ); */
 
         res = (int)(Result % 10000);
 
         printf( "Case #%d: %04d\n", i + 1, res );
     }
 
     return 0;
 }

