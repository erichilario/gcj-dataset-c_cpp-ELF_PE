#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 #include <assert.h>
 
 /* Error checking is not being performed because the input file is assumed to be from
    a trusted source. */
 
 /* Use the limits for the large input, performance and resources are not important factors
    for this problem. */
 
 /* #define SMALL */
 #define LARGE
 
 #if defined(REALLYSMALL)
 #define L_LIMIT 3
 #endif
 
 #if defined(SMALL)
 #define L_LIMIT 10
 #endif
 
 #if defined(LARGE)
 #define L_LIMIT 15
 #endif
 
 #define MAX_LINE ((26 + 2) * L_LIMIT + 2 + 1)  /* (abc...xyz) L_LIMIT times with \r\n and \0 */
 
 /* A linked list will have to suffice because there is no time to implement a more
    efficient data structure.  Note to self:  PREPARE, get a useful library set. */
 
 typedef struct WORD
 {
 	char word[L_LIMIT + 1];
 	struct WORD *next;
 } WORD;
 
 typedef struct UNKNOWN
 {
         char guesses[26];
         int num;
         int pos;
 	int cur;
 } UNKNOWN;
 
 typedef struct CODE
 {
 	char code[L_LIMIT];
 	UNKNOWN unknowns[L_LIMIT];
 	int numUnknowns;
 } CODE;
 
 static void alienGetLDN(FILE *file, int *L, int *D, int *N);
 static WORD *alienBuildDictionary(FILE *file, int L, int D);
 static void alienTestCases(FILE *file, int N, WORD *words, int D);
 static void alienGenerateCode(char *line, CODE *code);
 static int alienCountMatches(WORD *words, CODE *code, int L);
 
 #if 0 /* UGH... */
 static int alienPermutateCode(WORD *words, CODE *code);
 static int alienFindCodeInDictionary(WORD *words, CODE *code);
 static int alienTrimCode(WORD *words, CODE *code);
 static void alienRemoveGuess(UNKNOWN *unknown, int guess);
 #endif
 
 int main(int argc, char *argv[])
 {
 	FILE *file;
 	int rc;
 	int L = 0;
 	int D = 0;
 	int N = 0;
 	WORD *words;
 int i = 0;
 
         assert(argc == 2);
 
 	file = fopen(argv[1], "r");
 	assert(file != NULL);
 
         rc = fscanf(file, "%d %d %d", &L, &D, &N);
 	assert(rc == 3);
 
 	words = alienBuildDictionary(file, L, D);
 
         alienTestCases(file, N, words, L);
 
 	return(0);
 }
 
 static WORD *alienBuildDictionary(FILE *file, int L, int D)
 {
 	int rc;
 	int i, j;
 	void *mem;
 	WORD *first;
 	WORD *word;
 	WORD *iter;
 
 	first = NULL;
 
 	for (i = 0; i < D; i++)
 	{
 		mem = malloc(sizeof(WORD));
 		assert(mem != NULL);
 
 		word = (WORD *)mem;
 
 		/* Again, assuming trusted input. */
 		rc = fscanf(file, "%s", word->word);
 		assert(rc == 1);
 
 		if (first != NULL)
 		{
                         if (strcmp(word->word, first->word) < 0)
                         {
 				word->next = first;
 				first = word;
 			}
 			else
 			{
 				iter = first;
 				while (iter->next != NULL)
 				{
 					rc = strcmp(word->word, iter->next->word);
 
 					if (rc < 0)
 					{
 						word->next = iter->next;
 						iter->next = word;
 
 						break;
 					}
 
 					iter = iter->next;
 				}
 
 				if (iter->next == NULL)
 				{
 					word->next = NULL;
 					iter->next = word;
 				}
 			}
 		}
 		else
 		{
 			first = word;
 			word->next = NULL;
 		}
 	}
 
 	return(first);
 }
 
 static void alienTestCases(FILE *file, int N, WORD *words, int L)
 {
 	char line[MAX_LINE];
 	CODE code;
 	int i;
 	int matches;
 	int rc;
 
 	rc = fscanf(file, "\n");
 
 	matches = 0;
 
 	for (i = 1; i <= N; i++)
 	{
 		memset(&code, 0, sizeof(code));
 
 		fgets(line, sizeof(line), file);
 
 		alienGenerateCode(line, &code);
 		//alienTrimCode(words, &code);
 
 		matches = alienCountMatches(words, &code, L);
 
 		printf("Case #%d: %d\n", i, matches);
 	}
 }
 
 static void alienGenerateCode(char *line, CODE *code)
 {
         char ch;
         int linePos;
         int codePos;
 	int unknownPos;
 
 	linePos = 0;
 	codePos = 0;
 
 //printf("line %s", line);
 
         while (isspace(ch = line[linePos++]) == 0)
 	{
                 if (ch != '(')
                 {
 			code->code[codePos] = ch;
 		}
 		else
 		{
 			unknownPos = 0;
 
 			while ((ch = line[linePos++]) != ')')
 			{
 				//printf("Adding %c unknown\n", ch);
 				code->unknowns[code->numUnknowns].guesses[unknownPos++] = ch;
 				code->unknowns[code->numUnknowns].num++;
 			}
 
 			code->unknowns[code->numUnknowns].pos = codePos;
 			code->numUnknowns++;
 		}
 
 		assert(codePos < L_LIMIT);
 
 		/* Leave an uninitialized character at each unknown location */
 		codePos++;
 	}
 
 	assert(codePos <= L_LIMIT);
 }
 
 /* This function was a HUGE mistake.  Instead of trying to match every permutation (HUGE NUMBER)
    to each dictionary word, it is MUCH easier to match each dictionary word to the code. */
 #if 0
 /* This function is crazy because I prefer to avoid recursion. */
 
 static int alienPermutateCode(WORD *words, CODE *code)
 {
 	int i, j, k, l, m;
 	int unknownIter;
 	int matches = 0;
 	int next;
 
 	 //printf("code->numUnknowns %d\n", code->numUnknowns);
 
         if (code->numUnknowns == 0)
         {
 		matches += alienFindCodeInDictionary(words, code);
 	}
 
         for (i = 0; i < code->numUnknowns; i++)
         {
                 code->code[code->unknowns[i].pos] = code->unknowns[i].guesses[0];
 	}
 
 	for (i = 0; i < code->numUnknowns; i++)
 	{
 		next = 0;
 		while (next == 0)
 		{
 			matches += alienFindCodeInDictionary(words, code);
 
 			/* Look for the lowest unknown that needs to be bumped. */
 			for (j = 0; j <= i; j++)
 			{
 				if (code->unknowns[j].cur < code->unknowns[j].num - 1)
 				{
  //printf("bumping %d's cur\n", j);
 					code->unknowns[j].cur++;
 
 					/* Really bad naming conventions going on here.  This
 					   updates the code character, I hope. */
 
 					code->code[code->unknowns[j].pos] = code->unknowns[j].
 						guesses[code->unknowns[j].cur];
 
 					break;
 				}
 				else
 				{
  //printf("resetting %d's cur\n", j);
 					/* Reset cur counters along the way. */
 					code->unknowns[j].cur = 0;
 					code->code[code->unknowns[j].pos] = code->unknowns[j].
 						guesses[0];
 
 					if (j == i)
 					{
 						if (j + 1 < code->numUnknowns)
 						{
 							 //printf("bumping %d's cur\n", j + 1);
 							code->unknowns[j + 1].cur++;
 
 							/* Really bad naming conventions going on here.  This
 							   updates the code character, I hope. */
 
 							code->code[code->unknowns[j + 1].pos] = code->unknowns[j + 1].
 								guesses[code->unknowns[j + 1].cur];
 						}
 
 						 //printf("moving on from %d\n", j);
 						/* Time to move on. */
 						next = 1;
 					}
 				}
 			}
 		}
 	}
 
 	return(matches);
 }
 #endif
 
 static int alienCountMatches(WORD *words, CODE *code, int L)
 {
 	WORD *w;
 	int i, k, l, matches = 0;
 
 	w = words;
 	while (w != NULL)
 	{
 		for (i = 0; i < L; i++)
 		{
 			for (k = 0; k < code->numUnknowns; k++)
 			{
 				if (i == code->unknowns[k].pos)
 				{
 					break;
 				}
 			}
 
 			if (k == code->numUnknowns)
 			{
 				/* Match directly */
 
 				if (w->word[i] != code->code[i])
 				{
 					break;
 				}
 			}
 			else
 			{
 				/* Match an unknown */
 
 				for (l = 0; l < code->unknowns[k].num; l++)
 				{
 					if (w->word[i] == code->unknowns[k].guesses[l])
 					{
 						break;
 					}
 				}
 
 				if (l == code->unknowns[k].num)
 				{
 					break;
 				}
 			}
 		}
 
 		if (i == L)
 		{
 			matches++;
 		}
 
 		w = w->next;
 	}
 
 	return(matches);
 }
 
 #if 0 /* Don't ask... */
 static int alienFindCodeInDictionary(WORD *words, CODE *code)
 {
 	int rc;
 	char buf[L_LIMIT];
 
         while (words != NULL)
         {
 		/* word has trailing junk because I was too lazy to clean it up,
 		   use code as the limiting factor. */
 
 //               memcpy(buf, code->code, 3);
 //               buf[10] = '\0';
 		 // printf("comparing %s to %s\n", buf, words->word);
 
 		rc = memcmp(code->code, words->word, sizeof(code->code));
 		if (rc > 0)
 		{
 			words = words->next;
 		}
 		else if (rc < 0)
 		{
 			return(0);
 		}
 		else
 		{
 			return(1);
 		}
 	}
 
 	return(0);
 }
 
 /* Necessary optimization to avoid extremely long runtimes... only inspect permutations
    which include unknown sequences that match a dictionary word.  The Universe would drift
    off into infinity before this program finished executing if this optimization was not
    performed. */
 
 static int alienTrimCode(WORD *words, CODE *code)
 {
 	int i, j;
 	WORD *w;
 
 	for (i = 0; i < code->numUnknowns; i++)
 	{
 		j = 0;
 		while (j < code->unknowns[i].num)
 		{
 			w = words;
 			while (w != NULL)
 			{
 				if (w->word[code->unknowns[i].pos] ==
 				    code->unknowns[i].guesses[j])
 				{
 					break;
 				}
 
 				w = w->next;
 			}
 
 			if (w == NULL)
 			{
 				alienRemoveGuess(&code->unknowns[i], j);
 			}
 			else
 			{
 				j++;
 			}
 		}
 	}
 }
 
 static void alienRemoveGuess(UNKNOWN *unknown, int guess)
 {
 printf("Removing guess %d\n", guess);
 	for (unknown->num--; guess < unknown->num; guess++)
 	{
 		unknown->guesses[guess] = unknown->guesses[guess + 1];
 	}
 }
 
 #endif
 

