#include <stdlib.h>
 #include <stdio.h>
 
 int a[105][105];
 char x[105][105];
 int h, w;
 
 int is_connect(int h1, int w1, int h2, int w2)
 {
 	if (h1 == 0 || h2 == 0 || h1 == h + 1 || h2 == h + 1 ||
 		w1 == 0 || w2 == 0 || w1 == w + 1 || w2 == w + 1)
 	{
 		return 0;
 	}
 
 	if (a[h1][w1] > a[h2][w2])
 	{
 		int min_h = 0;	
 		int min_w = 0;
 		
 		if (a[min_h][min_w] > a[h1 - 1][w1])
 		{
 			min_h = h1 - 1;
 			min_w = w1;
 		}
 		if (a[min_h][min_w] > a[h1][w1 - 1])
 		{
 			min_h = h1;
 			min_w = w1 - 1;
 		}
 		if (a[min_h][min_w] > a[h1][w1 + 1])
 		{
 			min_h = h1;
 			min_w = w1 + 1;
 		}
 		if (a[min_h][min_w] > a[h1 + 1][w1])
 		{
 			min_h = h1 + 1;
 			min_w = w1;
 		}
 
 		if (min_h == h2 && min_w == w2)
 		{
 			return 1;
 		}
 		else
 		{
 			return 0;
 		}
 	}
 	else if (a[h1][w1] < a[h2][w2])
 	{
 		return is_connect(h2, w2, h1, w1);
 	}
 	else
 	{
 		return 0;
 	}
 }
 
 void flood_fill(int hx, int wx, char ch)
 {
 	if (x[hx - 1][wx] == '.')
 	{
 		if (is_connect(hx, wx, hx - 1, wx) == 1)
 		{
 			x[hx - 1][wx] = ch;
 			flood_fill(hx - 1, wx, ch);
 		}
 	}
 	if (x[hx][wx-1] == '.')
 	{
 		if (is_connect(hx, wx, hx, wx - 1) == 1)
 		{
 			x[hx][wx - 1] = ch;
 			flood_fill(hx, wx - 1, ch);
 		}
 	}
 	if (x[hx][wx + 1] == '.')
 	{
 		if (is_connect(hx, wx, hx, wx + 1) == 1)
 		{
 			x[hx][wx + 1] = ch;
 			flood_fill(hx, wx + 1, ch);
 		}
 	}
 	if (x[hx + 1][wx] == '.')
 	{
 		if (is_connect(hx, wx, hx + 1, wx) == 1)
 		{
 			x[hx + 1][wx] = ch;
 			flood_fill(hx + 1, wx, ch);
 		}
 	}
 }
 
 int main()
 {
 	FILE* fin = fopen("B-small-attempt0.in", "r");
 
 	int num_test = 0;
 	fscanf(fin, "%d\n", &num_test);	
 	int t, i, j;
 	for (t = 1; t <= num_test; t++)
 	{
 		fscanf(fin, "%d %d\n", &h, &w);
 
 		for (i = 0; i <= 104; i++)
 			for (j = 0; j <= 104; j++)
 			{
 				a[i][j] = 100000;
 				x[i][j] = '.';
 			}
 
 
 		a[0][0] = 110000;
 
 		for (i = 1; i <= h; i++)
 		{
 			for (j = 1; j <= w; j++)
 			{
 				fscanf(fin, "%d ", &a[i][j]);
 			}
 			fscanf(fin, "\n");
 		}
 		
 		char ch = 'a';
 		for (i = 1; i <= h; i++)
 		{
 			for (j = 1; j <= w; j++)
 			{		
 				if (x[i][j] == '.')
 				{
 					x[i][j] = ch;
 					flood_fill(i, j, ch);
 					ch++;
 				}
 			}
 		}
 
 		printf("Case #%d:\n", t);
 		for (i = 1; i <= h; i++)
 		{
 			for (j = 1; j <= w; j++)
 			{
 				printf("%c ", x[i][j]);
 			}
 			printf("\n");
 		}
 	}
 
 	fclose(fin);
 }
 

