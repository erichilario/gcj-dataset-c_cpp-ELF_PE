// this program has been compiled and tested using GNU GCC compiler and Code::Blocks ide.
 
 #include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int main(){
 
     FILE* fp;
 
 
     int T;
     fp = fopen("B-large.in","r");
 
     if( fp == NULL){
         printf("could not open file");
     }
 
     char* s = NULL;
     while(1){
         char c = fgetc(fp);
 
         if(c == '\n'){
             T = atoi(s);
             s = NULL;
             break;
         }
         if(s == NULL){
             s = (char*)malloc(1);
             s[0] = c;
             s[1] = '\0';
         }
         else{
             int len = strlen(s);
             char* temp = (char*)malloc(len+1);
             strcpy(temp,s);
             temp[len] = c;
             temp[len+1] = '\0';
 
             s = temp;
         }
     }
 
     s = NULL;
 
     char c;
     int H,W;
 
     FILE* fpo;
 
     fpo = fopen("B-large.out","w");
     if(fpo == NULL){
         printf("could not open file");
     }
 
     for(int i = 0; i < T; i++){
         while(1){
              c = fgetc(fp);
 
              if(c == ' '){
                  H = atoi(s);
                  s = NULL;
              }
              else if(c == '\n'){
                  W = atoi(s);
                  s = NULL;
                  break;
              }
 
              if(s == NULL){
                 s = (char*)malloc(1);
                 s[0] = c;
                 s[1] = '\0';
             }
             else{
                 char* temp;
                 long len = strlen(s);
                 temp = (char*)malloc(len+2);
                 strcpy(temp,s);
                 temp[len] = c;
 
                 temp[len+1] = '\0';
                 s = temp;
             }
         }
 
         int hMap[H][W];
 
         int h = 0;
         int w = 0;
 
         //printf("%d,%d \n",H,W);
         while(1){
              c = fgetc(fp);
              if(c == ' '){
                  hMap[h][w] = atoi(s);
                  w++;
                  s = NULL;
              }
              else if(c == '\n' || c == EOF){
                  hMap[h][w] = atoi(s);
                  h++;
                  w = 0;
                  s = NULL;
              }
 
              if(h == H){
                  break;
              }
 
              if(s == NULL){
                 s = (char*)malloc(1);
                 s[0] = c;
                 s[1] = '\0';
             }
             else{
                 char* temp;
                 long len = strlen(s);
                 temp = (char*)malloc(len+2);
                 strcpy(temp,s);
                 temp[len] = c;
 
                 temp[len+1] = '\0';
                 s = temp;
             }
         }
 
        /*for(int k = 0; k < H; k++){
             for(int j = 0; j < W; j++){
                 printf("%d ",hMap[k][j]);
             }
             printf("\n");
         }*/
 
         int base[H][W];
         int baseIndex;
 
         for(int k = 0; k < H; k++){
             for(int j = 0; j < W; j++){
                 base[k][j] = -1;
             }
         }
         baseIndex = 0;
 
         for(int k = 0; k < H; k++){
             for(int j = 0; j < W; j++){
                 int ND = -1;
                 int WD = -1;
                 int ED = -1;
                 int SD = -1;
 
                 //printf("yeh hai %d %d %d %d \n",k,j,H,W);
                 if(k > 0){
                     ND = hMap[k-1][j];
                 }
                 if(k < H-1){
                     SD = hMap[k+1][j];
                 }
                 if(j > 0){
                     WD = hMap[k][j-1];
                 }
                 if(j < W-1){
                     ED = hMap[k][j+1];
                     //printf("kyu %d %d \n",ED,hMap[k][j+1]);
                 }
 
                 int smallest = 11111;
 
                 if(SD >= 0){
                     if(smallest >= SD){
                         smallest = SD;
                     }
                 }
                 if(ED >= 0){
                     if(smallest >= ED){
                         smallest = ED;
                     }
                 }
                 if(WD >= 0){
                     if(smallest >= WD){
                         smallest = WD;
                     }
                 }
                 if(ND >= 0){
                     if(smallest >= ND){
                         smallest = ND;
                     }
                 }
 
                 if(smallest >= hMap[k][j]){
                     base[k][j] = baseIndex;
                     baseIndex++;
                     //printf("%d %d %d %d %d\n",hMap[k][j],ND,WD,ED,SD);
                 }
             }
         }
 
         int treated = baseIndex;
 
         while(treated < H*W){
             for(int k = 0; k < H; k++){
                 for(int j = 0; j < W; j++){
                     if(base[k][j] >= 0){
                         continue;
                     }
                     int ND = -1;
                     int WD = -1;
                     int ED = -1;
                     int SD = -1;
 
                     if(k > 0){
                         ND = hMap[k-1][j];
                     }
                     if(k < H-1){
                         SD = hMap[k+1][j];
                     }
                     if(j > 0){
                         WD = hMap[k][j-1];
                     }
                     if(j < W-1){
                         ED = hMap[k][j+1];
                     }
 
                     int SIndex = -1;
                     int smallest = 11111;
 
                     if(SD >= 0){
                         if(smallest >= SD){
                             smallest = SD;
                             SIndex = 3;
                         }
                     }
                     if(ED >= 0){
                         if(smallest >= ED){
                             smallest = ED;
                             SIndex = 2;
                         }
                     }
                     if(WD >= 0){
                         if(smallest >= WD){
                             smallest = WD;
                             SIndex = 1;
                         }
                     }
                     if(ND >= 0){
                         if(smallest >= ND){
                             smallest = ND;
                             SIndex = 0;
                         }
                     }
 
                     if(smallest < hMap[k][j]){
                         switch(SIndex){
                             case 0:
                                 if(base[k-1][j] != -1){
                                     base[k][j] = base[k-1][j];
                                     treated++;
                                 }
                             break;
                             case 1:
                                 if(base[k][j-1] != -1){
                                     base[k][j] = base[k][j-1];
                                     treated++;
                                 }
                             break;
                             case 2:
                                 if(base[k][j+1] != -1){
                                     base[k][j] = base[k][j+1];
                                     treated++;
                                 }
                             break;
                             case 3:
                                 if(base[k+1][j] != -1){
                                     base[k][j] = base[k+1][j];
                                     treated++;
                                 }
                             break;
                         }
                     }
                 }
             }
         }
 
         //printf("next %d\n",baseIndex);
         int currentBasin = 0;
         int basinMap[baseIndex];
 
         for(int k = 0; k < baseIndex; k++){
             basinMap[k] = -1;
         }
 
         for(int k = 0; k < H; k++){
             for(int j = 0; j < W; j++){
                 if(basinMap[base[k][j]] == -1){
                     basinMap[base[k][j]] = currentBasin;
                     currentBasin++;
                 }
             }
         }
 
         char alpha[27] = "abcdefghijklmnopqrstuvwxyz";
 
         for(int k = 0; k < H; k++){
             for(int j = 0; j < W; j++){
                 base[k][j] = alpha[basinMap[base[k][j]]];
             }
         }
 
         fprintf(fpo,"Case #%d:\n",i+1);
         for(int k = 0; k < H; k++){
             for(int j = 0; j < W; j++){
                 fprintf(fpo,"%c",base[k][j]);
                 if(j < W-1){
                     fprintf(fpo," ");
                 }
             }
             fprintf(fpo,"\n");
         }
     }
 
 
 
 }

