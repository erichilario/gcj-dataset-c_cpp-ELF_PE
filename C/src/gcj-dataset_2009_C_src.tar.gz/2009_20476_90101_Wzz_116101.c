#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <malloc.h>
 #include <ctype.h>
 
 #define Max_size 5000
 
 int getline(FILE *fp,char *buf)
 {
 	int i = 0;
 	char ch = '\0';
 	ch = fgetc(fp);
 	while (ch != '\n')
 	{
 		buf[i] = ch;
 		i++;
 		ch = fgetc(fp);
 	}
 	buf[i] = '\0';
 	return 1;
 }
 
 
 void input()
 {
 	FILE *fp_in;
 	FILE *fp_out;
 	int length,lines,test_case;
 	int i=0,j=0,z=0;
 	char ch = '\0';
 	char ati[Max_size];
 	char buf[Max_size];
 	char temp[Max_size];
 	int ldc[3];
 	char temp_in[25];
 
 	char *words[Max_size];
 	char *cases[Max_size];
 	char *cases_length[Max_size];
 
 	int temp_len;
 	int location;
 	int kk=0;
 	int status=0;
 	int cc=0,hh=0;
 	int len;
 	int number_equal = 0;
 	int loop =0;
 	int free_num;
 
 	fp_out = fopen("D:\\A-large-practice.out","w+");
 	if ((fp_in = fopen("D:\\A-large.in","r+")) == NULL)
 	{
 		printf("open A-small-practice.in error!\n");
 		exit(1);
 	}
 	else
 	{
 		
 		ch = fgetc(fp_in);
 		while (ch != '\n')
 		{
 			while (ch != ' ' && ch != '\n')
 			{
 				if (z < (Max_size -1))
 				{
 					ati[z] = ch;
 					z++;
 				}
 				ch = fgetc(fp_in);
 			}
 			ati[z] = '\0';
 			ldc[i] = atoi(ati);
 			strcmp(ati,"\0");
 			z = 0;
 			i++;
 			if (ch == '\n')
 			{
 				break;
 			}
 			ch = fgetc(fp_in);
 		}
 		length = ldc[0];
 		lines = ldc[1];
 		test_case = ldc[2];
 
 		i = 0;
 		for(i = 0;i<lines;i++)
 		{
 			getline(fp_in,buf);
 			words[i] = (char *)malloc(strlen(buf)+1);
 			strcpy((words[i]),buf);
 		}
 		strcpy(buf,"\0");
 		for(i = 0;i<test_case;i++)
 		{
 			getline(fp_in,buf);
 			cases[i] = (char *)malloc(strlen(buf)+1);
 			strcpy(cases[i],buf);
 			strcpy(temp,cases[i]);
 			temp_len = strlen(temp);
 			z = 0;location=0;kk=0;
 			while(z < temp_len)
 			{
 				loop = 0;
 				if(temp[z] == '(')
 				{
 					z++;
 					while(temp[z] != ')')
 					{
 						temp_in[loop] = temp[z];
 						loop++;
 						z++;
 					}
 					temp_in[loop] = '\0';
 					cases_length[kk] = (char *)malloc(strlen(temp_in)+1);
 					strcpy(cases_length[kk],temp_in);
 					location++;
 					kk++;
 					z++;
 				}
 				else
 				{
 					cases_length[kk] = (char *)malloc(sizeof(char)+1);
 					*cases_length[kk] = temp[z];
 					*(cases_length[kk]+1) = '\0';
 					kk++;
 					z++;
 				}
 			}
 			status = 0;
 			for(j=0;j<lines;j++)
 			{
 				cc = 0;
 				while(cc < length)
 				{
 					hh = 0;
 					len = strlen(cases_length[cc]);
 					while(hh < len)
 					{
 						if (*(words[j]+cc) == *(cases_length[cc]+hh))
 						{
 							status = 1;
 							break;
 						}
 						else
 						{
 							status = 0;
 						}
 						hh++;
 					}
 					if (status != 1)
 					{
 						break;
 					}
 					cc++;
 				}
 				if (status == 1)
 				{
 					number_equal++;
 					status = 0;
 				}
 			}
 			fprintf(fp_out,"Case #%d: %d\n",(i+1),number_equal);
 			number_equal = 0;
 			for(free_num = 0;free_num < length;free_num++)
 			{
 				free(cases_length[free_num]);
 			}
 		}
 
 	}
 	for(free_num = 0;free_num < lines;free_num++)
 	{
 		free(words[free_num]);
 	}
 	fclose(fp_out);
 	fclose(fp_in);
 }
 
 
 int main(int argc,char **argv)
 {
 	input();
 	return 0;
 }
