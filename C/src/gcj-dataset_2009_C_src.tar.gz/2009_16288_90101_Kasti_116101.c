#include <stdio.h>
 #include <stdlib.h>
 
 
 char Words[5000][15] = {0};
 
 
 void Mark(int * Count, int D, char c, int j)
 {
   int i;
   for (i=0; i<D; i++)
   {
     if (Words[i][j] == c)
     {
       Count[i]++;
     }
   }
 }
 
 
 void Jam1(FILE * f)
 {
   int L, D, N;
   int i,j,k;
   int Count[5000] = {0};
   fscanf(f, "%d %d %d\n", &L, &D, &N);
   for (i=0; i<D; i++)
   {
     fscanf(f, "%s\n", &(Words[i][0]));
   }
   for (i=1; i<=N; i++)
   {
     char pattern[1024];
     int total = 0;
     fscanf(f, "%s\n", pattern);
     for (j=0,k=0; j<L; j++,k++)
     {
       if (pattern[k] == '(')
       {
         do
         {
           k++;
           Mark(Count, D, pattern[k], j);
         }
         while (pattern[k] != ')');
       }
       else
       {
         Mark(Count, D, pattern[k], j);
       }
     }
     for (j=0; j<D; j++)
     {
       if (Count[j] == L)
       {
         total++;
       }
       Count[j] = 0;
     }
     printf("Case #%d: %d\n", i, total);
   }
 }
 
 
 
 
 void main()
 {
   FILE * f;
   f = fopen("d:\\small1.txt", "r");
   if (f != NULL)
   {
     Jam1(f);
     fclose(f);
   }
 }
