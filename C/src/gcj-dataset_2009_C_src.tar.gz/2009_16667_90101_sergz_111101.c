#include <stdio.h>
 #include <stdlib.h>
 
 #define TOP 20000
 
 typedef struct _cell {
   int height;
   char label;
   struct _cell* sink;
 } cell;
 
 cell*
 cell_at(cell* map, int w, int h, int x, int y) {
   return map+y*(w+2)+x;
 }
 
 void
 find_sink(cell* map, int w, int h) {
   int i, j;
  
   for(i = 1; i <= h; i++) {
     for(j = 1; j <=w; j++) {
       cell* c = cell_at(map, w, h, j, i);
       cell* north = cell_at(map, w, h, j, i-1);
       cell* west = cell_at(map, w, h, j-1, i);
       cell* south = cell_at(map, w, h, j, i+1);
       cell* east = cell_at(map, w, h, j+1, i);
      
       if(north->height < c->sink->height) {
         c->sink = north;
       }
       if(west->height < c->sink->height) {
         c->sink = west;
       }
       if(east->height < c->sink->height) {
         c->sink = east;
       }
       if(south->height < c->sink->height) {
         c->sink = south;
       }
     }
   }
 }
 
 void
 label(cell* map, int w, int h) {
   char* l = "abcdefghijklmnopqrstuvwxyz";
   int i, j;
   int n = 0;
    
   for(i = 1; i <= h; i++) {
     for(j = 1; j <=w; j++) {
       cell* c = cell_at(map, w, h, j, i);
      
       if(c->label == '\0') {
         cell* cl = c;
 
         while((cl->sink != cl) && (cl->label == '\0')) {
           cl = cl->sink;
         }
        
         if(cl->label == '\0') {
           c->label = l[n++];
           while(c->sink != c) {
             c->sink->label = c->label;
             c = c->sink;
           }
         } else {
           c->label = cl->label;
         }
       }
     }
   }
 }
 
 cell*
 read_map(FILE* in, int w, int h) {
   cell* map;
   int i, j;
   int size;
  
   size = (h+2)*(w+2);
   map = (cell*)malloc(size*sizeof(cell));
   for(i = 0; i < size; i++) {
     map[i].height = TOP;
     map[i].label = '\0';
     map[i].sink = &(map[i]);
   }
  
   for(i = 1; i <= h; i++) {
     for(j = 1; j <=w; j++) {
       int height;
      
       fscanf(in, "%d", &height);
      
       cell_at(map, w, h, j, i)->height = height;
     }
   }
  
   return map;
 }
 
 void
 print_map(cell* map, int w, int h) {
   int i, j;
  
   for(i = 1; i <= h; i++) {
     cell* c = cell_at(map, w, h, 1, i);
     printf("%c", c->label);
     for(j = 2; j <= w; j++) {
       c = cell_at(map, w, h, j, i);
       printf(" %c", c->label);
     }
     printf("\n");
   }
 }
 
 int
 main(int argc, char** argv) {
   cell* map;
   int n;
   int i;
   FILE* in = stdin;
  
   if(argc == 2) {
     in = fopen(argv[1], "r");
   }
  
   fscanf(in, "%d", &n);
  
   for(i = 0; i < n; i++) {
     int w, h;
    
     fscanf(in, "%d %d", &h, &w);
  
     map = read_map(in, w, h);
    
     find_sink(map, w, h);
     label(map, w, h);
    
     printf("Case #%d:\n", i+1);
     print_map(map, w, h);
    
     free(map);
   }
  
   if(argc == 2) {
     fclose(in);
   }
  
   return 0;
 }

