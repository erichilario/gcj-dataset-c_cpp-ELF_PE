#include <stdio.h>
 #include <conio.h>
 #include <string.h>
 
 int main() {
     int noofchars, noofknowncases, nooftestcases;
     /*      L            D               N        */
 
     scanf("%d %d %d", &noofchars, &noofknowncases, &nooftestcases);
     int i, j;
     char *lang = (char*) malloc(noofchars * noofknowncases * sizeof (char));
 
     for (i = 1; i <= noofknowncases; i++) {
         scanf("%s", (lang + ((i - 1) * noofchars)));
     }
 
     char* temp = (char*) malloc(noofchars * noofchars * noofchars * sizeof (char));
     int* res = (int*) malloc(nooftestcases * sizeof (int));
     for (i = 0; i < nooftestcases; i++) {
         res[i] = 0;
     }
 
     int k = 0;
 
     for (j = 1; j <= nooftestcases; j++) {
         scanf("%s", temp);
 
        
 
         for (i = 1; i <= noofknowncases; i++) {
             int brac = 0;
             int count = 0;
             int tempp = -1;
             char *point;
             point = lang + ((i - 1) * noofchars);
 
             for (k = 1; k <= noofchars; k++) {
                 int matched = 0;
                 char next = temp[++tempp];
                 //printf("\nnext = %c\n",next);
 
                 if (next == '(') {
 
                     brac++;
                     next = temp[++tempp];
                     //printf("\nnext = %c\n",next);
 
                     while (next != ')') {
                         count++;
 
                         if (next == *(point + (k - 1))) {
                             matched = 1;
                         }
 
                         next = temp[++tempp];
                         //printf("\nnext = %c\n",next);
                     }
                     count++;
                     //printf("\ncount= %d",count);
 
                     if (next == ')') {
                         brac--;
 
                     }
                 } else {
                     //printf("\nnext = %c\n",next);
                     // printf("point = %c",*(point + count + (k - 1)));
                     if (next == *(point + (k - 1))) {
                         matched = 1;
                     }
                 }
                 if (matched == 0) break;
             }
 
 
             if (k == (noofchars + 1)) {
                 res[j - 1] += 1;
                 //printf("\nres increased!!\n");
 
             }
         }
 
     }
 
 
     for (i = 0; i < nooftestcases; i++) {
         printf("Case #%d: %d\n", i + 1, res[i]);
     }
     getch();
 
 }

