#include<stdio.h>
 //#define DBG
 
 char dict[5001][16];
 char cases[1000];
 
 int main()
 {
 int i, j, k, p, match;
 int len, wordcount, casecount;
 
 //input the LDN
 scanf("%d %d %d", &len, &wordcount, &casecount);
 
 #ifdef DBG	//DBG
 printf("[L]%d [D]%d [N]%d\n", len, wordcount, casecount);
 #endif		//DBG
 
 //input the words
 for(i = 0; i < wordcount; i++) {
 	scanf("%s", dict[i]);
 	
 #ifdef DBG	//DBG
 printf("dict[%d]: %s\n", i, dict[i]);
 #endif		//DBG
 
 }
 
 
 //input the cases
 for(i = 0; i < casecount; i++) {
 	scanf("%s", cases);
 
 #ifdef DBG	//DBG
 printf("case[%d]: %s\n", i, cases);
 #endif		//DBG
 
 
 	//matching
 	match = 0;
 	//loop for each word j, word index k, case index p
 	for(j = 0; j < wordcount; j++) {
 		k = 0;
 		p = 0;
 		while(dict[j][k] != '\0') {
 			if(cases[p] == '(') {
 				p++;
 				while(cases[p] != ')') {
 					if(dict[j][k] == cases[p]) {
 						k++;
 						while(cases[p] != ')')
 							p++;
 					}
 					else if(cases[p+1] == ')')
 						goto done;
 					else
 						p++;
 				}
 				p++;
 			}
 			else if(dict[j][k] == cases[p]) {
 				k++;
 				p++;
 			}
 			else
 				goto done;
 		}
 		if(dict[j][k] == '\0')
 			match++;
 		
 		done:
 		;
 	}
 	printf("Case #%d: %d\n", i+1, match);
 
 }
 
 
 
 
 
 return 0;
 }

