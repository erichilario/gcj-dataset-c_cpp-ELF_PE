#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 void chomp(char *s) {
   while(strlen(s) > 0 && strchr("\r\n",s[strlen(s)-1])!=NULL)
     s[strlen(s)-1] = 0;
 }
 
 void solve(int *alt, int *flow, char *label, int w, int h) {
   int i,j, d, bd;
   char nl=0, xl='a';
   int *stack;
   int stop = -1;
   int north,south,west,east,here;
 
   char map[256];
 
   for(i=0;i<256;i++) map[i]=0;
 
   stack = (int *) malloc((w*h+1)*sizeof(int));
 
   for(j=0;j<h;j++)
     for(i=0;i<w;i++) {
 
       here  = i+j*w;
       north = i+(j-1)*w;
       south = i+(j+1)*w;
       west  = (i-1)+j*w;
       east  = (i+1)+j*w;
 
       bd = alt[here];
       d = 0;
       if ( j-1 >= 0 ) if (alt[north] < bd) { bd = alt[north];   d = 1; }
       if ( i-1 >= 0 ) if (alt[west]  < bd) { bd = alt[west];    d = 2; }
       if ( i+1 < w )  if (alt[east]  < bd) { bd = alt[east];    d = 3; }
       if ( j+1 < h )  if (alt[south] < bd) { bd = alt[south];   d = 4; }
       
       switch(d) {
       case 0: label[here] = nl; nl++; stack[++stop] = here; break;
       case 1: flow[here] = north; break;
       case 2: flow[here] = west; break;
       case 3: flow[here] = east; break;
       case 4: flow[here] = south; break;
       }
     }
 
   while(stop>=0) {
     i = stack[stop] % w;
     j = stack[stop] / w;
     stop--;
 
     here  = i+j*w;
     north = i+(j-1)*w;
     south = i+(j+1)*w;
     west  = (i-1)+j*w;
     east  = (i+1)+j*w;
 
     //printf("pop %d,%d\n",i,j);
 
     if ( i-1 >= 0 ) if (label[ west ] < 0 && flow[west] == here) { label[west] = label[here]; stack[++stop] = west; }
     if ( i+1 < w  ) if (label[ east ] < 0 && flow[east] == here) { label[east] = label[here]; stack[++stop] = east; }
     if ( j-1 >= 0 ) if (label[ north ] < 0 && flow[north] == here) { label[north] = label[here]; stack[++stop] = north; }
     if ( j+1 < h  ) if (label[ south ] < 0 && flow[south] == here) { label[south] = label[here]; stack[++stop] = south; }
   }
 
   // fix labels
 
   for(j=0;j<h;j++)
     for(i=0;i<w;i++) {
       here = i+j*w;
       if (label[here]<0) continue;
       if (map[ label[here] ] == 0)
 	map[label[here]] = xl++;
       label[here] = map[label[here]];
     }
 
 }
 
 int main() {
   char t[1024], *p;
   int i,j,k,T,W,H;
   char *sep = " \r\n\t";
 
   int *alt, *flow;
   char *label;
 
   fgets(t,1024,stdin);
   chomp(t);
   T = atoi(t);
   
   for(i=0;i<T;i++) {
     fgets(t,1024,stdin);
     p = strtok(t,sep);
     H = atoi(p);
     p = strtok(NULL,sep);
     W = atoi(p);
     
     alt   = (int *) malloc(W*H*sizeof(int));
     flow  = (int *) malloc(W*H*sizeof(int));
     label = (char *) malloc(W*H*sizeof(int));
 
     for(j=0;j<H;j++) {
       fgets(t,1024,stdin);
       p=strtok(t,sep);
       for(k=0;k<W;k++) {
 	alt[k+W*j] = atoi(p);
 	p = strtok(NULL,sep);
 	flow[k+W*j] = -1;
 	label[k+W*j] = -1;
       }
     }
       
     solve(alt,flow,label,W,H);
    
     // print solution
     printf("Case #%d:\n",i+1);
     for(j=0;j<H;j++)
       for(k=0;k<W;k++)
 	printf("%c%c",label[k+j*W], k==(W-1) ? '\n' : ' ');
 
 
     free(alt);
     free(flow);
     free(label);
   }
 
   return 0;
 }

