#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char Wel[20] = "welcome to code jam";
 
 struct _Tcache
 {
 	char * input;
 	int pos;
 	__int64 total;
 } Cache[1000];
 
 int g_CacheCnt;
 	
 
 __int64 findcnt( char * input, int pos )
 {
 	int spellcnt = 0;
 	__int64 currentTotal = 0;
 	__int64 subTotal;
 	int i;
 	char * old_input = input;
 	int old_pos = pos;
 
 	if ( *input == '\0' && pos == 19)
 		return 1;
 
 	for ( i = g_CacheCnt-1 ; i >= 0 ; i-- )
 	{
 		if ( Cache[i].input == input && Cache[i].pos == pos )
 		{
 			return Cache[i].total;
 		}
 	}
 
 	while ( *input )
 	{
 		if ( *input == Wel[pos] )
 			spellcnt++;
 
 		if ( *(input+1) == Wel[pos+1] )
 		{
 			subTotal = findcnt( input+1, pos+1 );
 			if ( subTotal == 0 )
 				break;
 			currentTotal += subTotal * spellcnt;	
 			spellcnt = 0;
 		}
 
 		input++;
 	}
 
 	if ( g_CacheCnt < 1000 )
 	{
 		Cache[g_CacheCnt].input = old_input;
 		Cache[g_CacheCnt].pos = old_pos;
 		Cache[g_CacheCnt].total = currentTotal;
 		g_CacheCnt++;
 	}
 		
 
 	return currentTotal;
 }
 
 int main()
 {
 	int N;
 	char tN[100];
 	char input[501];
 	char input_refined[501];
 	char *p, *q;
 	int i;
 	__int64 ret;
 
 	gets(tN);
 	N = atoi(tN);
 
 	for ( i = 0; i < N; i++ )
 	{
 		gets(input);
 		//printf("%s\n", input);
 
 		p = input;
 		q = input_refined;
 		while ( *p )
 		{
 			if ( strchr(Wel, *p) )
 			{
 				*q++ = *p;
 			}
 			p++;
 		}
 		*q = '\0';
 		//printf("i = %s\n", input_refined);
 
 		g_CacheCnt = 0;
 
 		ret = findcnt( input_refined, 0 );
 
 		printf("Case #%d: %04d\n", i+1, ret%10000 );
 	}
 	return 0;
 }

