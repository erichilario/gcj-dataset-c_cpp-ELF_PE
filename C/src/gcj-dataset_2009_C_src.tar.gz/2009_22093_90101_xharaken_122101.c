#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char *ss = "welcome to code jam";
 char str[512];
 int ss_len = 19;
 int str_len, count;
 
 void search(int cur, int index)
 {
   int i;
   
   if(index == ss_len)
     {
       count++;
       return;
     }
   for(i = cur; i < str_len; i++)
     {
       if(str[i] == ss[index])
         {
           search(i + 1, index + 1);
         }
     }
   return;
 }
 
 int main(void)
 {
   int n, N;
   
   scanf(" %d\n", &N);
   
   for(n = 0; n < N; n++)
     {
       fgets(str, 512, stdin);
       str[strlen(str) - 1] = 0;
       str_len = strlen(str);
       count = 0;
       search(0, 0);
       printf("Case #%d: %04d\n", n + 1, count % 10000);
     }
   return 0;
 }

