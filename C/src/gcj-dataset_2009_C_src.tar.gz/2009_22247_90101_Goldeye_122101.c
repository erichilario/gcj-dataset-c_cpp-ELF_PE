#include <stdio.h>
 
 
 int work(char *start, char *check) {
 	int count = 0;
 	if(*check == 0)
 		return 1;
 	if(*start == 0)
 		return 0;
 	while(*start != 0) {
 		if(*start == *check)
 			count += work(start + 1, check + 1);
 		start++;
 		if(count >= 10000)
 			count %= 10000;
 	}
 	return count;
 	//while(
 }
 
 int main(int argc, char **argv) {
 	char line[600];
 	char *findit = "welcome to code jam";
 	int cases;;
 	int i = 1;
 
 	gets(line);
 	sscanf(line,"%d",&cases);
 	for(i=1;i <= cases; i++) {
 		gets(line);
 		int res = work(line,findit);
 		printf("Case #%d: %04d\n",i, res);
 		
 	}
 
 	return 148145;
 }

