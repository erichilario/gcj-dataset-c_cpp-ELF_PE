#include<stdio.h>
 
 int A[100][100],N,M,D;
 int U[100][100];
 int dx[4] = {-1,0,0,1};
 int dy[4] = {0,-1,1,0};
 
 int dir(int x, int y) {
 	int i,j,nx,ny,v=A[x][y], d=-1;
 	for(i=0;i<4;i++) {
 		nx = x+dx[i];
 		ny = y+dy[i];
 		if(nx<0||nx>=N) continue;
 		if(ny<0||ny>=M) continue;
 		if(v>A[nx][ny]) {v=A[nx][ny];d=i;}
 	}
 	return d;
 }
 
 int fans(int x, int y) {
 	if(U[x][y] > 0) return U[x][y];
 	int d = dir(x,y);
 	if(d<0) return U[x][y] = ++D;
 	return U[x][y] = fans(x+dx[d],y+dy[d]);
 }
 
 int main() {
 	int i,j,c,t,T;
 	scanf("%d",&T);
 	for(t=1;t<=T;t++) {
 		scanf("%d %d",&N,&M);
 		for(i=0;i<N;i++) {
 			for(j=0;j<M;j++) {
 				scanf("%d",&A[i][j]);
 				U[i][j]=0;
 			}
 		}
 		D=0;
 		printf("Case #%d:\n",t);
 		for(i=0;i<N;i++) {
 			for(j=0;j<M;j++) {
 				fans(i,j);
 				if(j>0) printf(" ");
 				printf("%c", U[i][j]-1+'a');
 			}
 			printf("\n");
 		}
 	}
 	return 0;
 }
 

