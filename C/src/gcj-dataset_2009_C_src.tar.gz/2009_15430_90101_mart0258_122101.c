#include <stdio.h>
 
 char str[]="welcome to code jam";
 
 int grid[600][30];
 
 char buf[512];
 
 int solve(int y, int x)
 {
 	int ret=0;
 	int pos=y;
 	if (grid[y][x]>=0)
 		return grid[y][x];
 	if (str[x]=='\0') return 1;
 
 	for (; buf[pos]; ++pos)
 	{
 		if (buf[pos]==str[x])
 		{
 			ret+=solve(pos+1, x+1);
 		}
 	}
 	ret%=10000;
 	grid[y][x]=ret; 
 	return ret; 
 }
 
 
 int main (void)
 {
 	int tests;
 	int test;
 	int y,x;
 	fgets(buf, 510, stdin);
 	sscanf(buf,"%d", &tests);
 
 	for (test=1; test<=tests; ++test)
 	{
 		fgets(buf, 510, stdin);
 		for (y=0; y<600; ++y)
 		{
 			for (x=0; x<30; ++x)
 			{
 				grid[y][x]=-1;
 			}
 		}
 		printf ("Case #%d: %04d\n", test, solve(0, 0));
 	}
 	return 0;
 }
