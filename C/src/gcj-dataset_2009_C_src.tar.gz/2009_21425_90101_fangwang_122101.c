#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 char target[] = "welcome to code jam";
 char str[550];
 int len;
 
 void recursion(unsigned long long *times, int strpos, int subpos)
 {
 	if (target[subpos] == '\0')
 	{
 		(*times)++;
 		return;
 	}
 	while (strpos < len)
 	{
 		if (str[strpos] == target[subpos])
 		{
 			recursion(times, strpos + 1, subpos + 1);
 		}
 		strpos++;
 	}
 }
 
 int main()
 {
 	FILE *fp;
 	int N, n;
 	unsigned long long times;
 	char *pos;
 	char buf[512] = "0000";
 
 	//fp = fopen("B-small-attempt0.in", "r");
 	fp = fopen("C-small-attempt0.in", "r");
 	//fp = fopen("sample-c", "r");
 	fscanf(fp, "%d\n", &N);
 	for (n = 0; n < N; n++)
 	{
 		fgets(str, sizeof(str), fp);
 		len = strlen(str);
 		times = 0;
 		recursion(&times, 0, 0);
 		snprintf(buf + 4, sizeof(buf) - 4, "%llu", times);
 		printf("Case #%d: %s\n", n + 1, buf + strlen(buf) - 4);
 	}
 
 	return 0;
 }

