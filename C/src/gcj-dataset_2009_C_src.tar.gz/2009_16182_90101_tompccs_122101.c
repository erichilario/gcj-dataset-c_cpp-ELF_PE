#include <stdio.h>
 #include <stdlib.h>
 
 char cjString[] = "welcome to code jam";
 char inString[501];
 int cjStringLen = 18;
 int inStringLen;
 
 long ssCount;
 
 void srf(int cjStringIndex, int inStringIndex);
 char * numConverter(long num);
 
 
 int main(){
     FILE *fin = fopen("C-small-attempt0.in.txt","r");
     FILE *fout = fopen("C-small.out","w");
     // read # of test cases:
     int cases;
     fscanf(fin, "%d\n", &cases);
     int i;
     for(i=0;i<cases;i++){
         // reset public variables:
         int j;
         for(j=0;j<501;j++){
             inString[j] = 0;
         }
         ssCount = 0;
         fgets(inString, 501, fin);
         srf(0,0);
         char *res = numConverter(ssCount);
         fprintf(fout, "Case #%d: ",i+1);
         fputs(res, fout);
         fprintf(fout, "\n");
         free(res);
     }
     return 0;
 }
 
 void srf(int cjStringIndex, int inStringIndex){
     int i;
     for(i=inStringIndex;i<501;i++){
         if(cjString[cjStringIndex] == inString[i]){
             // required char found in inputted string
             if(cjStringIndex == cjStringLen){
                 // final char found! ++ our count.
                 ssCount ++;
             }else{
                 // the show goes on...
                 srf(cjStringIndex + 1, i + 1);
             }
         }
     }
 }
 
 char * numConverter(long num){
     char temp[100];
     int i, j=0;
     for(i=0;i<100;i++){
         temp[i] = 0;
     }
     sprintf(temp, "%d", num);
     puts(temp);
     char *fdr = malloc((sizeof(char) * 4) + 1);
     int digits = 0;
     for(i=0;i<100;i++){
         // find how many digits:
         if(temp[i] != 0){
             digits ++;
         }else{
             break;
         }
     }
     if(digits < 4){
         // fill in the zeroes:
         for(i=0;i<(4-digits);i++){
             fdr[i] = '0';
             j++;
         }
         // fill in the digits:
         int k=0;
         for(i;i<4;i++){
             fdr[i] = temp[k];
             k++;
         }
     }else{
         j = 0;
         for(i=digits-4;i<digits;i++){
             fdr[j] = temp[i];
             j++;
         }
     }
     puts(fdr);
     return fdr;
 }
 

