#include<stdio.h>
 #include<stdlib.h>
 
 char label(int **a, char **M, int i, int j, int h, int w, char map);
 
 
 int main(){
   int N;
   scanf("%d", &N);
   int h,w;
   char map;
   int i,j,I;
   int ***AM = (int ***)malloc(N*sizeof(int **));
   char *** AC = (char ***)malloc(N*sizeof(char **));
   for(I=0;I<N;++I){
     *(AM+I) = (int **)malloc(100*sizeof(int *));
     *(AC+I) = (char **)malloc(100*sizeof(char *));
     for(i=0;i<100;++i){
       *(*(AM+I)+i) = (int *)malloc(100*sizeof(int));
       *(*(AC+I)+i) = (char *)malloc(100*sizeof(char));
     }
   }
   int ht[N];
   int wd[N];
   for(I=0;I<N;++I){
     scanf("%d%d",&h,&w);
     ht[I] = h;
     wd[I] = w;
   for(i=0;i<h;++i)
     for(j=0;j<w;++j)
       AC[I][i][j] = '1';
   for(i=0;i<h;++i)
     for(j=0;j<w;++j)
       scanf("%d", &AM[I][i][j]);
   }
 
   for(I=0;I<N;++I){
     map = '`';
     h = ht[I];
     w = wd[I];
     printf("Case #%d:\n",I+1);
   for(i=0;i<h;++i){
     for(j=0;j<w;++j){
       if(AC[I][i][j] == '1')
 	map = label(*(AM+I),*(AC+I),i,j,h,w,map);
       if(j==w-1)
 	printf("%c",AC[I][i][j]);
       else
 	printf("%c ",AC[I][i][j]);
     }
     putchar('\n');
   }
   }
   return 0;
 }
 
 char label(int **a, char **M, int i, int j, int h, int w, char map){
   int maxi = i, maxj = j;
   if(i-1>=0)
     if(a[maxi][maxj] > a[i-1][j]){
       maxi = i-1;
       maxj = j;
     }
   if(j-1>=0)
     if(a[maxi][maxj] > a[i][j-1]){
       maxj = j-1;
       maxi = i;
     }
   if(j+1<w)
     if(a[maxi][maxj] > a[i][j+1]){
       maxj = j+1;
       maxi = i;
     }
   if(i+1<h)
     if(a[maxi][maxj] > a[i+1][j]){
       maxi = i+1;
       maxj = j;
     }
   if(maxi == i && maxj == j){
     M[i][j] = map+1;
     return map+1;
   }
   else if(M[maxi][maxj] != '1'){
     M[i][j] = M[maxi][maxj];
     return M[maxi][maxj];
   }
   else
     M[i][j] = label(a,M,maxi,maxj,h,w,map);
   return M[i][j];
 
 }

