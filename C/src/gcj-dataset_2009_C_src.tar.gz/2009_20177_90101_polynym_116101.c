#include<stdio.h>
 #include<stdlib.h>
 
 int main(){
   int l,d,n;
   scanf("%d%d%d",&l,&d,&n);
   char *dict[d];
   int i,j,k;
   for(i=0;i<d;++i)
     dict[i] = (char *)malloc((l+2)*sizeof(char));
   for(i=0;i<d;++i)
     scanf("%s",dict[i]);
   int ***in = (int ***)malloc(n*sizeof(int **));
   for(i=0;i<n;++i){
     *(in+i) = (int **)malloc(l*sizeof(int *));
     for(j=0;j<l;++j)
       *(*(in+i)+j) = (int *)malloc(26*sizeof(int));
   }
   for(i=0;i<n;++i){
     for(j=0;j<l;++j){
       for(k=0;k<26;++k)
 	in[i][j][k] = 0;
     }
   }
   for(i=0;i<n;++i){
     getchar();
     //printf("newline\n");
     for(j=0;j<l;++j){
       char a;
       if ((a = getchar()) == '(')
 	{
 	  while((a = getchar()) != ')'){
 	    int val = (int)a-97;
 	    in[i][j][val] = 1;
 	  }
 	}
       else
 	in[i][j][(int)a-97] = 1;
     }
   }
   int wordcount = 0;
   int *count = (int *)malloc(n*sizeof(int));
   for(i=0;i<n;++i){
     count[i]=search(in,dict,i,l,d);
     printf("Case #%d: %d\n",i+1,count[i]);
   }
   return 0;
 }
 
 int search(int *** a, char **dict, int i, int l, int d){
   int count = 0;
   int k,j;
   int flag = 1;
   for(j=0;j<d;++j){
     flag = 1;
     for(k=0;k<l;++k){
       if((a[i][k][(int)dict[j][k]-97])==0){
 	flag = 0;
 	break;
       }
     }
     if(flag)
       ++count;
   }
   return count;
 }

