/*
  * File: main.c
  * Author: Corey Beres (corey.beres@gmail.com)
  * Description: solution to Code Jam problem C
  */
 
 #include <sys/types.h>
 #include <regex.h>
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 // number of matches
 int matches;
 
 // length of target phrase
 int length = 19;
 
 // target phrase
 char target[] = "welcome to code jam";
 	
 // indices of target letters within a line
 int indices[19][500];
 
 // frequences of target letters within a line
 int freq[19];
 
 // single line of the test cases
 char line[501];
 
 /**
  * welcome
  * recursive function that finds its way through a line while trying to
  * recreate the target phrase
  */
 int welcome(int offset, int depth) {
 	int i;
 
 	// call this function once for each occurrence of the current letter
 	// after the given offset
 	for (i = 0; i < freq[depth]; ++i) {
 		if (offset < indices[depth][i]) {
 			// see if we stepped through the entire phrase
 			if (depth < length - 1)
 				welcome(indices[depth][i], depth + 1);
 			else
 				++matches;
 		}
 	}
 }
 
 /**
  * main
  * Reads in the input file and output file and does all work
  */
 int main(int argc, char* argv[]) {
 	int i, j, N;
 	FILE* f;
 	FILE* o;
 
 	char* pch;
 	
 	// open file, get constants
 	f = fopen(argv[1], "r");
 	fscanf(f, "%d\n", &N);
 
 	// open output file
 	o = fopen(argv[2], "w");
 
 	// read in test cases
 	for (i = 0; i < N; ++i) {
 		// (re)set frequencies
 		for (j = 0; j < length; ++j) {
 			freq[j] = 0;
 		}
 
 		matches = 0;
 	
 		// read in line
 		fgets(line, 501, f);
 
 		// get indices and frequencies
 		for (j = 0; j < length; ++j) {
 			// find initial position of a certain letter
 			pch = strchr(line, target[j]);
 			while (pch) {
 				// record info
 				indices[j][freq[j]] = pch - line;
 				++freq[j];
 				// find next occurrence after offset
 				pch = strchr(pch + 1, target[j]);
 			}
 		}
 
 		// find the number of occurrences of the target phrase
 		welcome(-1, 0);
 
 		// print number of matches
 		fprintf(o, "Case #%d: %04d\n", i+1, matches);
 	}
 
 	fclose(f);
 	fclose(o);
 
 	return 0;
 }

