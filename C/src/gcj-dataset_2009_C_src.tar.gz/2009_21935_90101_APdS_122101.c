//#define DBG
 
 #include<stdio.h>
 #include<string.h>
 
 int match(char *input, char *p, int pstart);
 
 int main()
 {
 int i, j, cases, pstart, count;
 
 char p[]="welcome to code jam";
 char input[101];
 int length = strlen(p) -1;
 
 scanf("%d", &cases);
 
 #ifdef DBG		//HarryDBG
 printf("%d cases.\n", cases);
 #endif			//HarryDBG
 
 
 //printf("[%02X]\n", getchar());
 getchar();
 
 for(i = 0; i < cases; i++) {
 
 	j = 0;
 	while((input[j] = getchar()) != '\n' && input[j] != EOF)
 		j++;
 	input[j] = '\0';
 
 #ifdef DBG		//HarryDBG
 printf("Case #%d: %s\n", i+1, input);
 #endif			//HarryDBG
 
 	j = strlen(input);
 	while(input[j] != p[length])
 		j--;
 	input[j+1] = '\0';
 
 	pstart = 0;
 	count = match(input, p, pstart);
 
 	printf("Case #%d: %04d\n", i+1, count%10000);
 }
 
 return 0;
 }
 
 
 int match(char * input, char * p, int pstart)
 {
 
 #ifdef DBG		//HarryDBG
 printf("matching(%s, %s)\n", input, p+pstart);
 #endif			//HarryDBG
 
 int i = 0;
 int count = 0;
 
 if(p[pstart+1] == '\0') {
 	while(input[i] != '\0') {
 		if(input[i] == p[pstart])
 			count++;
 		i++;
 	}
 	return count;
 }
 
 while(input[i] != '\0') {
 	if(input[i] == p[pstart])
 		count += match(input+i+1, p, pstart+1);
 	i++;
 }
 
 return count;
 }
 
 

