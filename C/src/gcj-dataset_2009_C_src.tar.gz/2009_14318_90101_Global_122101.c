#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int main()
 {
 	FILE* fin = fopen("C-small-attempt0.in", "r");
 
 	int t, num_test;
 	fscanf(fin, "%d\n", &num_test);
 	
 	char line[511];
 	int a[510][20];
 
 	for (t = 1; t <= num_test; t++)
 	{
 		int i,j,k;
 
 		memset(a, 0, sizeof(int) * 510 * 20);
 		char welcome[20] = "welcome to code jam";
 
 		fgets(line, 510, fin);
 		int len = strlen(line) - 1;
 
 		for (i = 0; i < len; i++)
 		{
 			if (line[i] == 'w')		
 			{
 				a[i][0] = 1;
 			}
 			else 
 			{
 				for (k = 0; k < 19; k++)
 				{
 					if (line[i] == welcome[k])
 					{
 						for (j = 0; j < i; j++)
 						{
 							a[i][k] += a[j][k-1];
 						}
 					}
 				}
 
 				a[i][k] %= 1000;
 			}
 		}
 
 		int sum = 0;
 		for (i = 0; i < len; i++)
 		{
 			sum += a[i][18];
 		}
 		sum %= 1000;
 
 		if (sum < 10)
 		{
 			printf("Case #%d: 000%d\n", t, sum);
 		}
 		else if (sum < 100)
 		{
 			printf("Case #%d: 00%d\n", t, sum);
 		}
 		else if (sum < 1000)
 		{
 			printf("Case #%d: 0%d\n", t, sum);
 		}
 		else
 		{
 			printf("Case #%d: %d\n", t, sum);	
 		}
 	}
 
 	return 0;
 }
 

