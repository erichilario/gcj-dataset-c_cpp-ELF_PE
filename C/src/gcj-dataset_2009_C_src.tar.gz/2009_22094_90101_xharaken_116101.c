#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char dict[30][20];
 char str[20];
 char ch[20][40];
 int L, D, N, count;
 
 int main(void)
 {
   int i, j, k, m, p, flag;
   char query[1024];
   
   scanf(" %d %d %d", &L, &D, &N);
   for(i = 0; i < D; i++)
     {
       scanf(" %s", dict[i]);
     }
   for(i = 0; i < N; i++)
     {
       scanf(" %s", query);
       
       m = 0;
       for(j = 0; j < strlen(query); j++)
         {
           if(query[j] == '(')
             {
               j++;
               k = 0;
               do
                 {
                   ch[m][k] = query[j];
                   j++;
                   k++;
                 }
               while(query[j] != ')');
               ch[m][k] = 0;
               m++;
             }
           else
             {
               ch[m][0] = query[j];
               ch[m][1] = 0;
               m++;
             }
         }
       
       count = 0;
       for(j = 0; j < D; j++)
         {
           flag = 0;
           for(k = 0; k < L; k++)
             {
               p = 0;
               while(ch[k][p] != 0)
                 {
                   if(ch[k][p] == dict[j][k])
                     {
                       flag++;
                       break;
                     }
                   p++;
                 }
             }
           if(flag == L)
             {
               count++;
             }
         }
 
       printf("Case #%d: %d\n", i + 1, count);
     }
   return;
 }

