#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <search.h>
 
 int height;
 int width;
 
 typedef struct tagCell
 {
 	int altitude;
 	char label;
 	int lblIndex;
 }cell;
 
 cell mapa[100][100];
 int currLblIndex;
 char proxLetra = 'a';
 
 void trocaLblIndex (int de, int para)
 {
 	int j,k;
 
 	for (j=0;j<height;j++)
 	{
 		for (k=0;k<width;k++)
 			if (mapa[j][k].lblIndex == de)
 				mapa[j][k].lblIndex = para;
 	}
 }
 
 void trocaLbl (int index, char letra)
 {
 	int j,k;
 
 	for (j=0;j<height;j++)
 	{
 		for (k=0;k<width;k++)
 			if (mapa[j][k].lblIndex == index)
 				mapa[j][k].label = letra;
 	}
 }
 
 
 void poeLbl (void)
 {
 	int j,k;
 
 	for (j=0;j<height;j++)
 	{
 		for (k=0;k<width;k++)
 			if (mapa[j][k].label == 0)
 				trocaLbl (mapa[j][k].lblIndex, proxLetra++);
 	}
 
 }
 void watersheds (int j, int k)
 {
 	int destJ = -1, destK = -1, minAlt;
 	int auxIndex;
 
 	currLblIndex++;
 	if (mapa[j][k].lblIndex == 0)
 		auxIndex = currLblIndex;
 	else
 		auxIndex = mapa[j][k].lblIndex;
 	minAlt = mapa[j][k].altitude;
 	/* determina para onde vai a agua */
 	/* N W E S */
 	if (j != 0 && mapa[j-1][k].altitude < minAlt)
 	{
 		destJ = j -1;
 		destK = k;
 		minAlt = mapa[j-1][k].altitude;
 	}
 	if (k != 0 && mapa[j][k-1].altitude < minAlt)
 	{
 		destJ = j;
 		destK = k-1;
 		minAlt = mapa[j][k-1].altitude;
 	}
 	if (k != (width -1) && mapa[j][k+1].altitude < minAlt)
 	{
 		destJ = j;
 		destK = k + 1;
 		minAlt = mapa[j][k+1].altitude;
 	}
 	if (j != (height-1) && mapa[j+1][k].altitude < minAlt)
 	{
 		destJ = j +1;
 		destK = k;
 		minAlt = mapa[j+1][k].altitude;
 	}
 
 	if (destJ == -1) /* Plunct plact zum, no vai a lugar algum */
 	{
 		mapa[j][k].lblIndex = auxIndex;
 	}
 	else
 	{
 		if (mapa[destJ][destK].lblIndex == 0)
 		{
 			mapa[destJ][destK].lblIndex = auxIndex;
 			mapa[j][k].lblIndex = auxIndex;
 		}
 		else
 		{
 			if (mapa[j][k].lblIndex == 0)
 				mapa[j][k].lblIndex = mapa[destJ][destK].lblIndex;
 			else
 				trocaLblIndex (auxIndex, mapa[destJ][destK].lblIndex);
 		}
 	}
 }
 
 void main (void)
 {
 	FILE * inputFile;
 	FILE * outputFile;
 	int numCases;
 	int i,j,k;
 
 	inputFile = fopen ("input.txt", "rt");
 	if (inputFile == NULL)
 	{
 		puts ("File not found");
 		return;
 	}
 	outputFile = fopen ("output.txt", "wt");
 	if (outputFile == NULL)
 	{
 		puts ("Error creating file");
 		return;
 	}
 	fscanf (inputFile,"%d",&numCases);
 
 	for (i=0;i<numCases;i++)
 	{
 		memset (mapa, 0, sizeof(mapa));
 		fscanf (inputFile,"%d %d",&height, &width);
 		for (j=0;j<height;j++)
 		{
 			for (k=0;k<width;k++)
 				fscanf (inputFile,"%d",&mapa[j][k].altitude);
 		}
 
 		currLblIndex = 0;
 		for (j=0;j<height;j++)
 		{
 			for (k=0;k<width;k++)
 				watersheds(j,k);
 		}
 		proxLetra = 'a';
 		poeLbl();
 
 		fprintf (stdout, "Case #%d:\n",i+1);
 		fprintf (outputFile, "Case #%d:\n",i+1);
 		for (j=0;j<height;j++)
 		{
 			for (k=0;k<width;k++)
 				fprintf (outputFile,"%c ",mapa[j][k].label);
 			fprintf(outputFile, "\n");
 		}
 		fprintf(outputFile, "\n");
 
 	}
 
 
 	fclose (inputFile);
 	fclose (outputFile);
 }
