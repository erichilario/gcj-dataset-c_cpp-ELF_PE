#include <stdio.h>
 
 #define MAX_ROWS    100
 #define MAX_COLMS   100
 #define MAX_ALT     10000
 
 #define NO_DIR  0
 #define NORTH   1
 #define WEST    2
 #define EAST    3
 #define SOUTH   4
 
 int H, W;
 
 int Map[MAX_ROWS + 2][MAX_COLMS + 2];
 int Basin[MAX_ROWS + 2][MAX_COLMS + 2];
 int NumBasins;
 
 int Recurse( int i, int j )
 {
     if ( Basin[i][j] == - 1 )
     {
         int MinAlt = Map[i][j];
         int Dir = NO_DIR;
 
         if ( Map[i-1][j] < MinAlt )
         {
             Dir = NORTH;
             MinAlt = Map[i-1][j];
         }
 
         if ( Map[i][j-1] < MinAlt )
         {
             Dir = WEST;
             MinAlt = Map[i][j-1];
         }
 
         if ( Map[i][j+1] < MinAlt )
         {
             Dir = EAST;
             MinAlt = Map[i][j+1];
         }
 
         if ( Map[i+1][j] < MinAlt )
         {
             Dir = SOUTH;
             MinAlt = Map[i+1][j];
         }
 
         switch ( Dir )
         {
             case NORTH:
                 Basin[i][j] = Recurse( i - 1, j );
                 break;
 
             case WEST:
                 Basin[i][j] = Recurse( i, j - 1 );
                 break;
 
             case EAST:
                 Basin[i][j] = Recurse( i, j + 1 );
                 break;
 
             case SOUTH:
                 Basin[i][j] = Recurse( i + 1, j );
                 break;
 
             case NO_DIR:
                 Basin[i][j] = NumBasins;
                 NumBasins++;
                 break;
         }
     }
 
     return Basin[i][j];
 }
 
 void Process( void )
 {
     int i, j;
 
     for ( i = 1; i <= H; i++ )
     {
         for ( j = 1; j <= W; j++ )
         {
             (void)Recurse( i, j );
         }
     }
 }
 
 int main( void) 
 {
     int k, T;
 
     scanf( "%d", &T );
 
     for ( k = 0; k < T; k++ )
     {
         int i, j;
 
         scanf( "%d%d", &H, &W );
 
         for ( i = 1; i <= H; i++ )
         {
             for ( j = 1; j <= W; j++ )
             {
                 scanf( "%d", &Map[i][j] );
                 Basin[i][j] = -1;
             }
 
             Map[i][0] = Map[i][W + 1] = MAX_ALT + 1;
         }
 
         for ( j = 0; j <= W + 1; j++ )
         {
             Map[0][j] = Map[H + 1][j] = MAX_ALT + 1;
         }
 
         NumBasins = 0;
 
         Process();
 
         printf( "Case #%d:\n", k + 1 );
 
         for ( i = 1; i <= H; i++ )
         {
             for ( j = 1; j <= W; j++ )
             {
                 printf( "%c ", Basin[i][j] + 'a' );
             }
             printf( "\n" );
         }
     }
 
     return 0;
 }

