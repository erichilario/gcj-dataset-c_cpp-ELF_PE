# include<stdio.h>
 # include<malloc.h>
  
 typedef struct abc{
 	int i;
 	int j;
 }index;
  
 int main(){
 
 	int n,w,h;
 	int i=0,j=0,k=0;
 	char c=97,nc=97;
 	
 	index * ind;
 	int flag=0;
 	int ** alt;
 	char ** out;
 	
 	int dir[5];
 	dir[0]=10001;dir[1]=10001;dir[2]=10001;dir[3]=10001;dir[4]=10001;
 	int min=-1;
 	int win1,win2,win3;
 	index next;
 	flag=0;
 	int a=0,count=0;
 		scanf("%d",&n);
 		int b,d;
 	for(k=0;k<n;k++){
 	
 		c=97;
 		nc=97;
 		scanf(" %d %d",&h,&w);
 		ind=(index *)malloc(w*h*sizeof(index));
 	
 		alt=(int **)malloc(h*sizeof(int*));
 		for(i=0;i<h;i++) {
 			alt[i]=(int *)malloc(w*sizeof(int));
 			for(j=0;j<w;j++) scanf("%d",&alt[i][j]);
 		}
 		
 	
 	
 		out=(char **)calloc(h,sizeof(char*));
 		for(i=0;i<h;i++){
 		 out[i]=(char *)calloc(w,sizeof(char));
 		 for(j=0;j<w;j++) out[i][j]=0;
 		}
 		
 		for(b=0;b<h;b++){
 			for(d=0;d<w;d++){
 				if(out[b][d]!=0) continue;
 				flag=0;
 				count=0;
 				 dir[0]=10001;dir[1]=10001;dir[2]=10001;dir[3]=10001;dir[4]=10001;
 				 ind[0].i=b;ind[0].j=d;
 				 count=1;
 				 i=b;j=d;
 				 
 					while(flag==0){
 						if(out[i][j]!=0){
 							c=out[i][j];
 							flag=1;
 							for(a=0;a<count;a++)out[ind[a].i][ind[a].j]=c;					
 							break;
 						
 						}
 						if(i!=0) dir[0]=alt[i-1][j];
 						if(j!=0) dir[1]=alt[i][j-1];
 						if(i!=(h-1)) dir[2]=alt[i+1][j];
 						if(j!=(w-1)) dir[3]=alt[i][j+1];
 						dir[4]=alt[i][j];
 					
 						if(dir[0]>dir[1]) win1=1;else win1=0;
 						if(dir[2]<dir[3]) win2=2;else win2=3;
 					
 						if(dir[win1]>dir[win2]) win3=win2;else win3=win1;
 					
 						 if(dir[4]<=dir[win3]) {
 						 	out[i][j]=nc;
 						 	flag=1;
 						 	c=nc;
 						 	nc++;
 						 	for(a=0;a<count;a++)out[ind[a].i][ind[a].j]=c;
 						 	break;
 						 }else{
 						 	
 						 	if(win3==0) {(ind[count]).i=i-1;ind[count].j=j;i=i-1;}
 						 	if(win3==1) {ind[count].i=i;ind[count].j=j-1;j=j-1;}
 						 	if(win3==2) {ind[count].i=i+1;ind[count].j=j;i=i+1;}
 						 	if(win3==3) {ind[count].i=i;ind[count].j=j+1;j=j+1;}
 						 	count++;
 						 }
 						 dir[0]=10001;dir[1]=10001;dir[2]=10001;dir[3]=10001;dir[4]=10001;
 					 
 					 }
 			}
 			
 		}
 		
 		printf("Case #%d:\n",k+1);
 		for(i=0;i<h;i++){
 			for(j=0;j<w;j++) printf("%c ",out[i][j]);
 			printf("\n");
 			
 		}
 		
 		
 		//for(i=0;i<h;i++) free(alt[i]);
 		//for(i=0;i<h;i++) free(out[i]);
 		//free(ind);
 		//free(alt);
 		//free(out);
 		
 			
 	}
 	
 	
 	
 }

