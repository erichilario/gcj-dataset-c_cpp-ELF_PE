#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 int main() {
     int l, d, n;
     int i, j, k;
     char * line;
     char * words;
     char * pattenHash;
     char input;
     int output;
 
     scanf("%d %d %d\n", &l, &d, &n);
     line = malloc(l * 30);
     words = malloc(l*d);
     pattenHash = malloc(l * 30);
 
     //read words
     for (i = 0; i < d; i++) {
         for (j = 0; j < l; j++) {
             words[i * l + j] = getchar();
         }
         getchar(); //newline
     }
     /*
     for (i = 0; i < d; i++) {
         for (j = 0; j < l; j++) {
             putchar(words[i * l + j]);
         }
         putchar('\n');
     }
     */
     
     for (k = 0; k < n; k++) {
         memset(pattenHash, 0, l * 30);
         //make patten
         for (j = 0; j < l; j++) {
             input = getchar();
             if (input == '(') {
                 input = getchar();
                 while (input != ')') {
                     pattenHash[j*30 + input - 'a'] = 1;
                     input = getchar();
                 }
             } else {
                 pattenHash[j*30 + input - 'a'] = 1;
             }
         }
         getchar(); //newline
         output = 0;
         for (i = 0; i < d; i++) {
             for (j = 0; j < l; j++) {
                 if(!(pattenHash[j*30 + words[i * l + j] - 'a'])) {
                     break;
                 }
             }
             if (l == j) {
                 output++;
             }
         }
         printf("Case #%d: %d\n",k+1,output);
     }
 }

