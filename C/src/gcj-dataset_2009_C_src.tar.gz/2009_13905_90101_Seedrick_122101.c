#include<stdio.h>
 #include<conio.h>
 #include<string.h>
 #include<ctype.h>
 int c = 0;
 
 void coun(char* in, char* test) {
     //printf("%c,%c\n",*in,*test);
     if (*test == '!') {
         c++;
         c = c % 10000;
         return;
     }
     while (*in != *test && *in != '!')in++;
     if (*in != *test)return;
     else {
         coun(in + 1, test);
 
         coun(in + 1, test + 1);
     }
 }
 
 int main() {
     char *test = (char*) malloc(25 * sizeof (char));
     test = "welcome to code jam!";
     //printf("%s",test);
     int i;
     char *input = (char*) malloc(40 * sizeof (char));
     int no;
     scanf("%d\n", &no);
     int num = no;
     int* count = (int*) malloc(no * sizeof (count));
     for (i = 0; i < no; i++) {
         count[i] = 0;
     }
     while (no--) {
         c=0;
         gets(input);
         strcat(input, "!");
         coun(input, test);
         count[num-no-1]=c;
     }
     
     for(i=0;i<num;i++){
 printf("Case #%d: %04d\n",i+1,count[i]);
 }
     
     getch();
 }
 
 
 

