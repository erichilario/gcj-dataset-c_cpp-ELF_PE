#include <stdio.h>
 
 #define N 1
 #define W 2
 #define E 3
 #define S 4
 
 int n,h,w;
 int tab[200][200];
 char sol[200][200];
 
 int best_v( int tab[200][200] , int x, int y )
 {
 	int tmp,tmp_dir;
 	tmp = 99999;
 	tmp_dir = N;
 
 	if( (y!=0) && tab[x][y-1] < tmp )
 	{
 		tmp = tab[x][y-1];
 		tmp_dir = N;
 	}
 
 	if( (x!=0) && tab[x-1][y] < tmp )
 	{
 		tmp = tab[x-1][y];
 		tmp_dir = W;
 	}
 
 	if( (x!=w-1) && tab[x+1][y] < tmp )
 	{
 		tmp = tab[x+1][y];
 		tmp_dir = E;
 	}
 
 	if( (y!=h-1) && tab[x][y+1] < tmp )
 	{
 		tmp = tab[x][y+1];
 		tmp_dir = S;
 	}
 
 	if( tmp < tab[x][y] )	return tmp_dir;
 	else return -1;
 }
 
 void vxy( int dir, int x, int y, int *nx, int *ny )
 {
 	switch( dir )
 	{
 		case N :	*nx = x;
 							*ny = y-1;
 							break;
 		case W :	*nx = x-1;
 							*ny = y;
 							break;
 		case E :	*nx = x+1;
 							*ny = y;
 							break;
 		case S :	*nx = x;
 							*ny = y+1;
 							break;
 	}
 }
 
 void contamina( int x, int y, char nova_letra )
 {
 	char old = sol[x][y];
 	sol[x][y] = nova_letra;
 
 	if( x!=0 && sol[x-1][y] == old ) contamina( x-1, y, nova_letra );
 
 	if( y!=0 && sol[x][y-1] == old ) contamina( x, y-1, nova_letra );
 
 	if( x!=w-1 && sol[x+1][y] == old ) contamina( x+1, y, nova_letra );
 
 	if( y!=h-1 && sol[x][y+1] == old) contamina( x, y+1, nova_letra );
 }
 
 
 
 int main( void )
 {
 	int i,j,caso;
 	char tmp;
 	int viz;
 	int vx,vy;
 
 	scanf("%d", &n);
 	for( caso=1; caso <=n; caso++ )
 	{
 		scanf("%d %d", &h, &w);
 		for( i=0; i<h; i++ )
 		for( j=0; j<w; j++ )
 			scanf("%d", &tab[j][i] );
 
 		for( i=0; i<h; i++ )
 		for( j=0; j<w; j++ )
 			sol[j][i] = '?';
 
 		tmp = 'A';
 		sol[0][0] = tmp++;
 
 		for( i=0; i<h; i++ )
 		for( j=0; j<w; j++ )
 		{
 			/* Encontra o menor vizinho */
 			viz = best_v( tab, j, i );
 
 			// Nao tem vizinhos, ja tou setado
 			if( viz == -1 && sol[j][i] != '?' )
  				continue;
 
 			// nao tem vizinhos, nem fui setado
 			if( viz == -1 && sol[j][i] == '?' )
 			{
 				sol[j][i] = tmp++;
  				continue;
 			}
 
 			/* Melhor vizinho */
 			vxy( viz, j,i, &vx, &vy );
 
 			//printf("melhor vizinho de %d %d (%d): %d %d (%d) dir=%d\n", j, i,tab[j][i], vx, vy, tab[vx][vy], viz);
 			if( sol[j][i] != '?' && sol[vx][vy] == '?' )
 				sol[vx][vy] = sol[j][i];
 
 			else if( sol[j][i] == '?' && sol[vx][vy] != '?' )
 				sol[j][i] = sol[vx][vy];
 
 			else if( sol[j][i] == '?' && sol[vx][vy] == '?' )
 			{
 				sol[j][i] = tmp;
 				sol[vx][vy] = tmp++;
 			}
 
 			else if( sol[j][i] != '?' && sol[vx][vy] != '?' && sol[j][i] != sol[vx][vy] )
 				contamina( j,i, sol[vx][vy] );
 
 		}
 
 
 		/* Contamina */
 		tmp = 'a';
 		for( i=0; i<h; i++ )
 		for( j=0; j<w; j++ )
 		{
 			if( (sol[j][i] < 'a') || (sol[j][i] > 'z'))
 				contamina( j,i, tmp++ );
 		}
 
 
 
 		printf("Case #%d:\n", caso);
 		for( i=0; i<h; i++ )
 		{
 			for( j=0; j<w; j++ )
 				printf("%c ", sol[j][i] );
 			printf("\n");
 		}
 	}
 
 
 	
 	return 0;
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

