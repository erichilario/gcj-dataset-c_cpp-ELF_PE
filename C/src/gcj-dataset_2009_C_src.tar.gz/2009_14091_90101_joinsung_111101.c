#include <stdio.h>
 
 int main()
 {
 	int t;
 	scanf("%d",&t);
 	int ti;
 	int h,w;
 	int hi,wi;
 	int i;
 	int map[100][100];
 	int loc[100][100];
 	char cur;
 	char label[10000];
 	for (ti=1;ti<=t;ti++)
 	{
 		cur='a';
 		scanf("%d %d",&h,&w);
 		for (hi=0;hi<h;hi++)
 			for (wi=0;wi<w;wi++)
 				scanf("%d",&map[hi][wi]);
 		for (hi=0;hi<h;hi++)
 			for (wi=0;wi<w;wi++)
 				loc[hi][wi]=hi*w+wi;
 		for (hi=0;hi<h*w;hi++)
 			label[hi]=-1;
 		int min,minloc;
 		for (i=0;i<h*w;i++)
 			for (hi=0;hi<h;hi++)
 				for (wi=0;wi<w;wi++)
 				{
 					min=map[hi][wi];
 					minloc=0;
 					if (hi>0 && map[hi-1][wi]<min)
 					{
 						min=map[hi-1][wi];
 						minloc=1;
 					}
 					if (wi>0 && map[hi][wi-1]<min)
 					{
 						min=map[hi][wi-1];
 						minloc=2;
 					}
 					if (wi<w-1 && map[hi][wi+1]<min)
 					{
 						min=map[hi][wi+1];
 						minloc=3;
 					}
 					if (hi<h-1 && map[hi+1][wi]<min)
 					{
 						min=map[hi+1][wi];
 						minloc=4;
 					}
 					if (minloc==1)
 						loc[hi][wi]=loc[hi-1][wi];
 					else if (minloc==2)
 						loc[hi][wi]=loc[hi][wi-1];
 					else if (minloc==3)
 						loc[hi][wi]=loc[hi][wi+1];
 					else if (minloc==4)
 						loc[hi][wi]=loc[hi+1][wi];
 				}
 		printf("Case #%d:\n",ti);
 		for (hi=0;hi<h;hi++)
 		{
 			for (wi=0;wi<w;wi++)
 			{
 				if (label[loc[hi][wi]]==-1)
 					label[loc[hi][wi]]=cur++;
 				printf("%c ",label[loc[hi][wi]]);
 			}
 			printf("\n");
 		}
 	}
 	return 0;
 }

