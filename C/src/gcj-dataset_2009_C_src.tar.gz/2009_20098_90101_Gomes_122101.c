#include <stdio.h>
 #include <string.h>
 
 int Count(char *sBaseStr, char *sStr)
 {
         int lTotal = 0;
         int exists;
 	char *sRest;
 	int iLen, j;
 
 	iLen = strlen(sBaseStr);
 	
 
 	if ((sStr != NULL) && (iLen>0))
 	{
 		exists = 1;
 
 	        for(j=0; j<iLen; j++)
         	{
 	                sRest = strchr(sStr, sBaseStr[j]);
 
 	                if (sRest == NULL)
         	                exists = 0;
                 	else
 			{
                         	sStr = sRest + 1;
 				if (exists)
 				{
 					lTotal += Count(sBaseStr+j, sStr);
 				}
 			}
 		}
 		if (exists) lTotal++;
 	}
 
         return lTotal;
 }
 
 
 int main()
 {
 	char *sBaseStr = "welcome to code jam";
 	char sSample[500];
 	int iN, i;
 	int iLen = strlen(sBaseStr);
 	int total;
 
 	scanf("%d\n", &iN);
 		
 	for(i=0; i<iN; i++)
 	{
 //		gets(sSample);
 		scanf("%[^\t\n]\n", sSample);
 
 		total = Count(sBaseStr, sSample);
 		printf("Case #%d: %4.4d\n", i+1, total % 10000);
 	}
 
 	return 0;
 }
 

