#include<stdio.h>
 
 char words[5000][20];
 char pattern[100000];
 
 int match_pattern(char *A, char *B) {
 	if( *A == 0 ) return *B == 0;
 	if( *B != '(' ) return (*A == *B)?match_pattern(A+1,B+1):0;
 	int i,ok=0;
 	while(*B != ')') {
 		if(*A == *B) ok=1;
 		B++;
 	}
 	return ok?match_pattern(A+1,B+1):0;
 }
 
 int main() {
 	int i,j,c,L,D,N;
 	scanf("%d %d %d",&L,&D,&N);
 	for(i=0;i<D;i++) scanf("%s",words[i]);
 	for(i=1;i<=N;i++) {
 		scanf("%s",pattern);
 		c=0;
 		for(j=0;j<D;j++) 
 			c += match_pattern(words[j],pattern);
 		printf("Case #%d: %d\n",i,c);
 	}
 	return 0;
 }
 

