#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <search.h>
 
 
 typedef struct tagBloco
 {
 	char poss[26];
 	int sizePoss;
 }bloco;
 
 typedef struct tagDic
 {
 	char palavra[16];
 }tagDic;
 
 int lenWord, dicSize;
 tagDic dic[5000];
 tagDic tentativa[16];
 bloco entrada[15];
 int output=0;
 int maxCount;
 
 int ord (const void *a,const void *b)
 {
 	char * ca;
 	char * cb;
 
 	ca = ((tagDic *) a)->palavra;
 	cb = ((tagDic *) b)->palavra;
 
 	return strncmp (ca, cb, maxCount);
 }
 
 
 
 void alienLang (int ini)
 {
 	int i;
 	int j;
 	if (ini == lenWord)
 	{
 		maxCount = lenWord;
 		if (bsearch(&tentativa,dic,dicSize,sizeof(tagDic), ord) != NULL)
 			output++;
 		return;
 	}
 	for (i=0;i<entrada[ini].sizePoss;i++)
 	{
 		tentativa->palavra[ini] = entrada[ini].poss[i];
 		for (j=0;j<dicSize;j++)
 		{
 			maxCount = ini + 1;
 			if (bsearch(&tentativa,dic,dicSize,sizeof(tagDic), ord) != NULL)
 				break;
 		}
 		if (j == dicSize)
 			continue;
 		alienLang(ini + 1);
 	}
 }
 
 void main (void)
 {
 	FILE * inputFile;
 	FILE * outputFile;
 	int numCases;
 	int i,j,k;
 
 	char aux;
 
 	inputFile = fopen ("input.txt", "rt");
 	if (inputFile == NULL)
 	{
 		puts ("File not found");
 		return;
 	}
 	outputFile = fopen ("output.txt", "wt");
 	if (outputFile == NULL)
 	{
 		puts ("Error creating file");
 		return;
 	}
 	fscanf (inputFile,"%d %d %d",&lenWord, &dicSize, &numCases);
 
 	for (i=0;i<dicSize;i++)
 	{
 		fscanf (inputFile, "%s", dic[i].palavra);
 	}
 	fscanf (inputFile, "%c", &aux);
 
 	maxCount = lenWord;
 	qsort(dic,dicSize,sizeof(tagDic),ord);
 	for (i=0;i<numCases;i++)
 	{
 		k=0;
 		while (1)
 		{
 			fscanf (inputFile, "%c", &aux);
 			if (aux == '\n' || aux == '\r')
 				break;
 			if (aux == '(')
 			{
 				for (j=0;aux != ')';j++)
 				{
 					fscanf (inputFile, "%c", &aux);
 					if (aux != ')')
 						entrada[k].poss[j] = aux;
 				}
 				entrada[k].sizePoss = j-1;
 			}
 			else
 			{
 				entrada[k].poss[0] = aux;
 				entrada[k].sizePoss = 1;
 			}
 			k++;
 		}
 		output = 0;
 		memset (tentativa->palavra, 0, 16);
 		alienLang(0);
 		fprintf (outputFile, "Case #%d: %d\n",i+1, output);
 	}
 
 
 	fclose (inputFile);
 	fclose (outputFile);
 }
