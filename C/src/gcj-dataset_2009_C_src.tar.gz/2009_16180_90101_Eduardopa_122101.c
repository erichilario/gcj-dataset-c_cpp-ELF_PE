#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <search.h>
 
 char target[] = "welcome to code jam";
 char inputTxt[502];
 int output;
 
 
 void welcome (char *txt, int obj, int len)
 {
 	int i;
 
 	if (obj == 19)
 	{
 		output++;
 		if (output == 10000)
 			output = 0;
 		return;
 	}
 	for (i=0;i<len;i++)
 	{
 		if (txt[i] == target[obj])
 			welcome(&txt[i+1],obj+1,len-i-1);
 	}
 }
 
 void main (void)
 {
 	FILE * inputFile;
 	FILE * outputFile;
 	int numCases;
 	int i;
 	int j,k;
 
 	inputFile = fopen ("input.txt", "rt");
 	if (inputFile == NULL)
 	{
 		puts ("File not found");
 		return;
 	}
 	outputFile = fopen ("output.txt", "wt");
 	if (outputFile == NULL)
 	{
 		puts ("Error creating file");
 		return;
 	}
 	fscanf (inputFile,"%d",&numCases);
 	fgets(inputTxt,sizeof(inputTxt),inputFile);
 
 	for (i=0;i<numCases;i++)
 	{
 		memset (inputTxt, 0, sizeof(inputTxt));
 		for (j=0;inputTxt[j] != '\n' && inputTxt[j] != '\r';j++)
 		{
 			inputTxt[j] = fgetc (inputFile);
 			for (k=0;k<19;k++)
 				if (inputTxt[j] == target[k])
 					break;
 			if (k == 19)
 				j--;
 		}
 		inputTxt[j] = '\0';
 		if (j>0 && (inputTxt[j-1] == '\r' || inputTxt[j-1] == '\n'))
 			inputTxt[j-1] = '\0';
 		output = 0;
 		welcome(inputTxt, 0, strlen(inputTxt));
 
 		fprintf (stdout, "Case #%d: %04d\n",i+1,output);
 		fprintf (outputFile, "Case #%d: %04d\n",i+1,output);
 
 	}
 
 
 	fclose (inputFile);
 	fclose (outputFile);
 }
