#include<stdio.h>
 #include<limits.h>
 #include<stdlib.h>
 int main()
 {
 	int nos,m,n,tc,**mat,**ans,chr=97,north,east,south,west,s1,s2,s,i,j;
 	scanf(" %d",&nos);
 	for(tc=0;tc<nos;tc++)
 	{
 		chr = 97;
 		scanf(" %d%d",&m,&n);
 		mat = (int **)calloc(m,sizeof(int*));
 		ans = (int **)calloc(m,sizeof(int*));
 		for(i=0;i<m;i++)
 		{
 			mat[i] = (int *) calloc(n,sizeof(int));
 			ans[i] = (int *) calloc(n,sizeof(int));
 		}
 		for(i=0;i<m;i++)
 		{
 			for(j=0;j<n;j++)
 			{
 				scanf(" %d",&mat[i][j]);
 			}
 		}
 		///logic
 		ans[0][0]=chr;
 		for(i=0;i<m;i++)
 		{
 			for(j=0;j<n;j++)
 			{
 				s = north = west = south = east = INT_MAX;
 
 				if(i-1 >= 0)
 					north = mat[i-1][j];
 				if(j-1 >= 0)
 					west = mat[i][j-1];
 				if(j+1 < n)
 					east = mat[i][j+1];
 				if(i+1 < m)
 					south = mat[i+1][j];
 				//finding small
 				s1 = north;
 				s2 = east;
 				if(west < north )
 					s1 = west;
 				if(south < east )
 					s2 = south;
 				if(s2 < s1 )
 					s = s2;
 				else
 					s = s1;
 				if(s<=mat[i][j])
 				{
 					//check lable
 					if(s == north)
 					{
 						if(ans[i][j] == 0)
 						{
 							if(mat[i][j] <= mat[i-1][j])
 								ans[i][j] = ++chr;
 							else
 								ans[i][j] = ans[i-1][j];
 						}
 					//	printf("north");
 					}
 					else if(s == west)
 					{
 						if(ans[i][j] == 0)
 						{
 							if(mat[i][j] <= mat[i][j-1])
 								ans[i][j] = ++chr;
 							else
 								ans[i][j] = ans[i][j-1];
 						}
 					//	printf("west");
 					}
 					else if(s == east)
 					{
 						if(ans[i][j] == 0)
 						{
 							if(ans[i][j+1] == 0)
 								ans[i][j+1] = ++chr;
 							if(mat[i][j] <= mat[i][j+1])
 								ans[i][j]=++chr;
 							else
 								ans[i][j] = ans[i][j+1];
 						}
 						else if(ans[i][j+1] == 0)
 						{
 							if(mat[i][j+1] >= mat[i][j])     
 								ans[i][j+1] = ++chr;
 							else
 								ans[i][j+1] = ans[i][j];
 						}
 					//	printf("east");
 					}
 					else if(s == south)
 					{
 						if(ans[i][j] == 0)
 						{
 							if(ans[i+1][j] == 0)
 								ans[i+1][j] = ++chr;
 							if(mat[i][j] <= mat[i+1][j])
 								ans[i][j]=++chr;
 							else
 								ans[i][j] = ans[i+1][j];
 						}
 						else if(ans[i+1][j] == 0)
 						{
 							if(mat[i+1][j] >= mat[i][j])     
 								ans[i+1][j] = ++chr;
 							else
 								ans[i+1][j] = ans[i][j];
 						}
 					//	printf("south");
 					}
 				}
 				else if(ans[i][j]==0)
 					ans[i][j]=++chr;
 
 
 			}
 		}
 
 		///end of logic
 
 		printf("Case #%d:\n",tc+1);
 		for(i=0;i<m;i++)
 		{
 			for(j=0;j<n;j++)
 			{
 				if(j==n-1)
 					printf("%c",ans[i][j]);
 				else
 					printf("%c ",ans[i][j]);
 			}
 			printf("\n");
 		}
 		for(i=0;i<m;i++)
 		{
 			free(mat[i]);
 			free(ans[i]);
 		}
 		free(mat);
 		free(ans);
 		
 	}
 return 0;
 }

