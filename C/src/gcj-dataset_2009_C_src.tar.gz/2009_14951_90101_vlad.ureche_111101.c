#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #define MIN(a,b) (((a)<(b))?(a):(b))
 #define MAP(ch,cw) (map+(cw)+(ch)*w)
 #define ATT(ch,cw) (att+(cw)+(ch)*w)
 
 /*
  * Vlad Ureche
  * Romania
  */
 
 char walker_function(int ch, int cw);
 
 int w, h;
 int* att;
 char* map;
 char cchar;
 
 int main() {
 
 	const char infile[] = "input.txt";
 	const char outfile[] = "output.txt";
 
 	int testcases;
 	int testcase;
 	int cw, ch;
 
 	FILE *inf;
 	FILE *outf;
 
 	inf = fopen ( infile, "r" );
 	if ( inf == NULL ) { perror(infile); return 1; }
 	outf = fopen ( outfile, "w" );
 	if ( outf == NULL ) { perror(outfile); return 1; }
 
 	fscanf(inf, "%d", &testcases);
 
 
 	for (testcase=0; testcase<testcases; testcase++) {
 
 		cchar = 'a';
 
 		fscanf(inf, "%d", &h);
 		fscanf(inf, "%d", &w);
 
 		att = malloc(h*w*sizeof(int));
 		if (att==NULL) { perror("att_malloc"); return 1; }
 		map = malloc(h*w*sizeof(char));
 		if (map==NULL) { perror("map_malloc"); free(att); return 1; }
 
 		memset(att, 0, h*w*sizeof(int));
 		memset(map, 0, h*w*sizeof(char));
 
 		for (ch = 0; ch<h; ch++)
 			for (cw = 0; cw<w; cw++)
 				fscanf(inf, "%d", ATT(ch, cw));
 
 		for (ch = 0; ch<h; ch++)
 			for (cw = 0; cw<w; cw++)
 				if (*MAP(ch,cw)==0)
 					walker_function(ch, cw);
 
 
 		// print heading
 		fprintf(outf, "Case #%d:\n", testcase+1);
 
 		for (ch = 0; ch<h; ch++) {
 			for (cw = 0; cw<w; cw++)
 				fprintf(outf,"%c ",*MAP(ch,cw));
 			fprintf(outf,"\n");
 		}
 
 		free(att);
 		free(map);
 	}
 
 	return 0;
 }
 
 int is_valid(int ch, int cw) {
 	if ((ch>=0)&&(ch<h)&&(cw>=0)&&(cw<w))
 		return 1;
 	else
 		return 0;
 }
 
 char walker_function(int ch, int cw) {
 
 	if (*MAP(ch,cw)!=0)
 		return *MAP(ch,cw);
 
 	int minheight = *ATT(ch,cw);
 	if (is_valid(ch-1, cw)) minheight = MIN(minheight, *ATT(ch-1,cw));
 	if (is_valid(ch, cw-1)) minheight = MIN(minheight, *ATT(ch,cw-1));
 	if (is_valid(ch, cw+1)) minheight = MIN(minheight, *ATT(ch,cw+1));
 	if (is_valid(ch+1, cw)) minheight = MIN(minheight, *ATT(ch+1,cw));
 
 	// now get a label for the cell
 	if (*ATT(ch,cw)==minheight) {
 		// a new sink
 		*MAP(ch,cw) = cchar;
 		cchar++;
 	}
 	else if ((is_valid(ch-1, cw))&&(*ATT(ch-1,cw)==minheight)) *MAP(ch,cw) = walker_function(ch-1, cw);
 	else if ((is_valid(ch, cw-1))&&(*ATT(ch,cw-1)==minheight)) *MAP(ch,cw) = walker_function(ch, cw-1);
 	else if ((is_valid(ch, cw+1))&&(*ATT(ch,cw+1)==minheight)) *MAP(ch,cw) = walker_function(ch, cw+1);
 	else if ((is_valid(ch+1, cw))&&(*ATT(ch+1,cw)==minheight)) *MAP(ch,cw) = walker_function(ch+1, cw);
 
 	return *MAP(ch,cw);
 }

