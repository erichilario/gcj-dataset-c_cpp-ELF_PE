#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 
 long  map[102][102];
 char rmap[102][102];
 char cmap[102][102];
 char g_basin;
 
 char flow( int h, int w )
 {
 	int toflowH, toflowW;
 
 	if ( cmap[h][w] == 1 )
 		return rmap[h][w];
 
 	cmap[h][w] = 1;
 
 	toflowH = h;
 	toflowW = w;
 
 	if ( map[toflowH][toflowW] > map[h-1][w] ) // north
 	{
 		toflowH = h-1;
 		toflowW = w;
 	} 
 
 	if ( map[toflowH][toflowW] > map[h][w-1] ) // west
 	{
 		toflowH = h;
 		toflowW = w-1;
 	}
 
 	if ( map[toflowH][toflowW] > map[h][w+1] ) // east
 	{
 		toflowH = h;
 		toflowW = w+1;
 	}
 
 	if ( map[toflowH][toflowW] > map[h+1][w] ) // south
 	{
 		toflowH = h+1;
 		toflowW = w;
 	}
 	
 
 	if ( toflowH == h && toflowW == w )
 	{
 		rmap[h][w] = g_basin++;
 	}
 	else
 	{
 		rmap[h][w] = flow( toflowH, toflowW );
 	}
 
 	if ( rmap[h][w] == ' ' )
 	{
 		rmap[h][w] = g_basin++;
 	}
 	
 	return rmap[h][w];
 }
 
 int main()
 {
 
 	int T, H, W;
 	int t, h, w;
 
 	char basin = 'a';
 
 	scanf("%d", &T);
 
 	for ( t = 0; t < T; t++ )
 	{
 		for ( h = 0 ; h < 102 ; h++ )
 		{
 			for ( w = 0; w < 102 ; w++ )
 			{
 				map[h][w] = 2147483647; // 2147483647 = INT_MAX
 			}
 		}
 		memset(rmap, ' ', sizeof(rmap));
 		memset(cmap, 0, sizeof(cmap));
 		g_basin = 'a';
 			
 		scanf("%d %d", &H, &W);
 
 		for ( h = 1 ; h <= H ; h++ )
 		{
 			for ( w = 1; w <= W ; w++ )
 			{
 				scanf("%d", &map[h][w]);
 			}
 		}
 
 		for ( h = 1 ; h <= H ; h++ )
 		{
 			for ( w = 1; w <= W ; w++ )
 			{
 				flow(h, w);
 			}
 		}
 
 		printf("Case #%d: \n", t+1);
 
 		for ( h = 1; h <= H ; h++ )
 		{
 			for ( w = 1 ; w <= W ; w++ )
 			{
 				printf("%c ", rmap[h][w]);
 			}
 			printf("\n");
 		}
 
 	}
 	return 0;
 }

