#include <stdio.h>
 #include <string.h>
 
 int main()
 {
     int N, lineno;
     char line[512];
 
     const char cj[] = "welcome to code jam";
     int pos[32], cur;
     int cjlen;
     int i;
 
 
     cjlen = strlen(cj);
 
     scanf("%d\n", &N);
 
     for (lineno=0;lineno<N;lineno++)
     {
         int linelen;
         int occur = 0;
         fgets(line, 512, stdin);
         //printf("%s\n", line);
         linelen = strlen(line);
 
         for (i=0;i<cjlen;i++)
         {
             pos[i] = 0;
         }
         i = 0;
         while (1)
         {
             for (cur=pos[i];cur<linelen;)
             {
                 if (line[cur] == cj[i])
                 {
                     //printf("%c %d %d\n", line[cur], i, cjlen);
                     if (i == cjlen-1)
                     {
                         //int j;
                         //for (j=0;j<cjlen;j++)
                         //    printf("%d,",pos[j]);
                         //printf("\n");
                         occur++;
                         //i--;
                         //if (i<0) break;
                         //cur = pos[i];
                         //continue;
                     }
                     else
                     {
                         pos[i] = cur+1;
                         i++;
                     }
                 }
                 cur++;
             }
             i-= (cjlen-i);
             if (i < 0) break;
         }
 
         printf("Case #%d: %04d\n", (lineno+1), occur%1000);
     }
 }

