#include <stdio.h>
 #include <string.h>
 #include <conio.h>
 void main()
 {
 
 	int a[3];
     char words[5000][15];
     char test[500][500];
 	FILE *fp;
 	FILE *fp1;
     int i,k;
 	int count=0;
 	int flag=0;
 	int len;
 	int j;
     int output[500]={0};
 
 	//printf("%d\n",output[356]);
 	fp=fopen("d:A-small-attempt7.in","r");
     fp1=fopen("d:output.txt","w");
 
 	fscanf(fp,"%d %d %d",&a[0],&a[1],&a[2]);
     for(i=0;i<a[1];i++)
 	fscanf(fp,"%s",words[i]);
 	for(i=0;i<a[2];i++)
 		fscanf(fp,"%s",test[i]);
 	printf("%d %d %d \n",a[0],a[1],a[2]);
 
 	for(i=0;i<a[1];i++)
 		printf("%s\n",words[i]);
 
 	for(i=0;i<a[2];i++)
 		printf("%s\n",test[i]);
 
 	for(i=0;i<a[2];i++)
 	{
 		flag=0;
 		len=strlen(test[i]);
 		printf("strlen = %d\n",len);
 		for(j=0;j<a[1];j++)
 		{
 			for(k=0;k<len;k++)
 			 {
 				//if(test[i][k]==')' && count!=a[0] && )
 				//	break;
 				if(test[i][k]=='(')
 
 				{   k++;
 				    flag=1;
 				}
 
 				if(words[j][count]==test[i][k])
 				 {
 					 count++;
 					 if(flag)
 					 {
 					 while(test[i][k] != ')')
 						 k++;
 					 flag=0;
 					 }
 				 }
 				 else
 				 {
 
 				 }
 			 }
 		if(count == a[0])
 			output[i]= output[i]+1;
 		count=0;
 		}
 	}
 
 
 printf("%d\n",output[1]);
 	for(i=0;i<a[2];i++)
 {
 	fprintf(fp1,"Case #%d: %d\n",i+1,output[i]);
 }
 
 
 
 
 getch();
 
 }

