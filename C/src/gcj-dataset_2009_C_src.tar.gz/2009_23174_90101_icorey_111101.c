/*
  * File: main.c
  * Author: Corey Beres (corey.beres@gmail.com)
  * Description: solution to Code Jam problem C
  */
 
 #include <sys/types.h>
 #include <regex.h>
 #include <stdlib.h>
 #include <stdio.h>
 
 // "map" of altitudes
 int** map;
 
 // "map" of basins
 char** solved;
 
 // height and width of the map
 int H, W;
 
 // current new basin
 char new;
 
 /**
  * newBasin
  * returns a newBasin each time it's called
  */
 char newBasin() {
 	char n = new;
 	++new;
 	return n;
 }
 
 /**
  * min4
  * returns the index of the lowest element in a four-element array
  */
 int min4(int vals[4]) {
 	int min, i;
 
 	min = 0;
 
 	// find the minimum value
 	for (i = 0; i < 4; ++i) {
 		if (vals[i] < vals[min]) {
 			min = i;
 		}
 	}
 	return min;
 }
 
 /**
  * findLowestNeighbor
  * checks if there are neighbors in each direction and, if there are, gets
  * the neighbors' values and sets (nx,ny) to the coords of the lowest neighbor
  *
  * the order (N, W, E, S) is important and was set in the problem
  */
 void findLowestNeighbor(int y, int x, int *ny, int *nx) {
 	int neighbors[4];
 	int lowest;
 	int haveANeighbor = 0;
 
 	// north
 	if (y != 0) {
 		neighbors[0] = map[y-1][x];
 		haveANeighbor = 1;
 	} else {
 		neighbors[0] = 10000;
 	}
 
 	// west
 	if (x != 0) {
 		neighbors[1] = map[y][x-1];
 		haveANeighbor = 1;
 	} else {
 		neighbors[1] = 10000;
 	}
 	
 	// east
 	if (x != W - 1) {
 		neighbors[2] = map[y][x+1];
 		haveANeighbor = 1;
 	} else {
 		neighbors[2] = 10000;
 	}
 
 	// south
 	if (y != H - 1) {
 		neighbors[3] = map[y+1][x];
 		haveANeighbor = 1;
 	} else {
 		neighbors[3] = 10000;
 	}
 
 	// find the lowest one
 	lowest = min4(neighbors);
 
 	// set the new coords
 	if (haveANeighbor) {
 		switch (lowest) {
 			case 0:
 				*ny = y-1; *nx = x;
 				break;
 			case 1:
 				*ny = y; *nx = x-1;
 				break;
 			case 2:
 				*ny = y; *nx = x+1;
 				break;
 			case 3:
 				*ny = y+1; *nx = x;
 				break;
 		}
 	} else {
 		// there isn't a neighbor
 		// just return the same coords
 		*ny = y; *nx = x;
 	}
 }
 
 /**
  * KnownDrain
  * goes down the rabbit hole starting with a known basin
  */
 void KnownDrain(int y, int x, char basin) {
 	int ny, nx;
 	
 	findLowestNeighbor(y, x, &ny, &nx);
 	
 	// we're not at a sink
 	if (map[ny][nx] < map[y][x]) {
 		// set the neighbor
 		solved[ny][nx] = basin;
 		// go further down the drain
 		KnownDrain(ny, nx, basin);
 	}
 }
 
 /**
  * MysteryDrain
  * goes down the rabbit hole and comes back up to set basins we were unsure of
  */
 char MysteryDrain(int y, int x) {
 	int ny, nx;
 	char basin;
 	
 	findLowestNeighbor(y, x, &ny, &nx);
 	
 	// we're not at a sink
 	if (map[ny][nx] < map[y][x]) {
 		if (solved[ny][nx] != 'X') {
 			// we found a basin
 			basin = solved[ny][nx];
 		} else {
 			// go further down the drain
 			basin = MysteryDrain(ny, nx);
 		}
 	}
 	// we're at a sink
 	else {
 		// get a new basin
 		basin = newBasin();
 	}
 	
 	// set the basin
 	solved[y][x] = basin;
 	return basin;
 }
 
 /**
  * drain
  * call MysteryDrain or KnownDrain depending on whether we know the basin or not
  */
 void drain(int y, int x) {
 	if (solved[y][x] == 'X') {
 		MysteryDrain(y, x);
 	} else {
 		KnownDrain(y, x, solved[y][x]);
 	}	
 }
 
 /**
  * main
  * handle file i/o and call the drain function
  * 
  * command line args are the input file and then the output file
  */
 int main(int argc, char* argv[]) {
 	int i, j, k, T;
 	FILE* f;
 	FILE* o;
 
 	// open file, get constants
 	o = fopen(argv[2], "w");
 	f = fopen(argv[1], "r");
 	fscanf(f, "%d\n", &T);
 
 	for (i = 0; i < T; ++i) {
 		// read in height and width
 		fscanf(f, "%d %d\n", &H, &W);
 
 		// allocate space
 		map = (int**)malloc(H * sizeof(int*));
 		solved = (char**)malloc(H * sizeof(char*));
 		for (j = 0; j < H; ++j) {
 			map[j] = (int*)malloc(W * sizeof(int));
 			solved[j] = (char*)malloc(W * sizeof(char));
 		}
 		
 		// read in map
 		for (j = 0; j < H; ++j) {
 			for (k = 0; k < W; ++k) {
 				fscanf(f, "%d", &map[j][k]);
 				solved[j][k] = 'X';
 			}
 		}
 
 		// start first basin
 		new = 'a';
 		solved[0][0] = newBasin();
 
 		// find the basins
 		for (j = 0; j < H; ++j) {
 			for (k = 0; k < W; ++k) {
 				drain(j, k);
 			}
 		}
 
 		// print the solved map
 		fprintf(o, "Case #%d:\n", i+1);
 		for (j = 0; j < H; ++j) {
 			for (k = 0; k < W; ++k) {
 				fprintf(o, "%c", solved[j][k]);
 				if (k == W-1)
 					fprintf(o, "\n");
 				else
 					fprintf(o, " ");
 				fflush(o);
 			}
 		}
 
 		// free space
 		for (j = 0; j < H; ++j) {
 			free(map[j]);
 			free(solved[j]);
 		}
 		free(map);
 		free(solved);
 	}
 
 	fclose(f);
 	fclose(o);
 
 	return 0;
 }

