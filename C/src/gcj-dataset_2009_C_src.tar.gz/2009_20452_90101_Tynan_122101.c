#include <stdio.h>
 #include <string.h>
 
 char* welcome = "welcome to code jam";
 
 int main(void) {
 	int ncase, tcases;
 	int count[512][19];
 	char buf[1024];
 	int len;
 	int i, j, k;
 	scanf("%d ", &tcases);
 	for(ncase = 0; ncase < tcases; ncase++) {
 		fgets(buf, 1024, stdin);
 		buf[strlen(buf) - 1] = '\0';
 		len = strlen(buf);
 		for(i = 0; i < len; i++) {
 			if(buf[i] == welcome[0])
 				count[i][0] = 1;;
 		}
 		for(j = 1; j < 19; j++) {
 			for(i = 0; i < len; i++) {
 				count[i][j] = 0;
 				if(buf[i] != welcome[j]) continue;
 				for(k = 0; k < i; k++) {
 					count[i][j] += count [k][j-1];
 					count[i][j] %= 10000;
 				}
 			}
 		}
 		printf("Case #%d: %04d\n", ncase + 1, count[len - 1][18]);
 	}
 	return 0;
 }

