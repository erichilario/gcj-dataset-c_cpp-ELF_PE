#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <search.h>
 #define TARGET_LEN	19
 
 char target[] = "welcome to code jam";
 char inputTxt[502];
 int output;
 
 unsigned __int64 letras[TARGET_LEN] = {0};
 
 /*
 void welcome (char *txt, int obj, int len)
 {
 	int i;
 
 	if (obj == TARGET_LEN)
 	{
 		output++;
 		if (output == 10000)
 			output = 0;
 		return;
 	}
 	for (i=0;i<len;i++)
 	{
 		if (txt[i] == target[obj])
 			welcome(&txt[i+1],obj+1,len-i-1);
 	}
 }
 */
 
 void insere (int pos)
 {
 	if (pos == 0)
 	{
 		letras[0]++;
 		return;
 	}
 	letras[pos] += letras[pos-1];
 
 }
 void welcome (void)
 {
 	int i,j;
 	int len = strlen (inputTxt);
 
 	for (i=0;i<len;i++)
 	{
 		for (j=0;j<TARGET_LEN;j++)
 		{
 			if (inputTxt[i] == target[j])
 			{
 				insere(j);
 			}
 		}
 	}
 }
 
 
 void main (void)
 {
 	FILE * inputFile;
 	FILE * outputFile;
 	int numCases;
 	int i;
 	int j,k;
 
 	inputFile = fopen ("input.txt", "rt");
 	if (inputFile == NULL)
 	{
 		puts ("File not found");
 		return;
 	}
 	outputFile = fopen ("output.txt", "wt");
 	if (outputFile == NULL)
 	{
 		puts ("Error creating file");
 		return;
 	}
 	fscanf (inputFile,"%d",&numCases);
 	fgets(inputTxt,sizeof(inputTxt),inputFile);
 
 	for (i=0;i<numCases;i++)
 	{
 		memset (inputTxt, 0, sizeof(inputTxt));
 		for (j=0;inputTxt[j] != '\n' && inputTxt[j] != '\r' && inputTxt[j] != -1;j++)
 		{
 			inputTxt[j] = fgetc (inputFile);
 			for (k=0;k<TARGET_LEN;k++)
 				if (inputTxt[j] == target[k])
 					break;
 			if (k == TARGET_LEN)
 				j--;
 		}
 		inputTxt[j] = '\0';
 		if (j>0 && (inputTxt[j-1] == '\r' || inputTxt[j-1] == '\n'|| inputTxt[j-1] == -1))
 			inputTxt[j-1] = '\0';
 //		welcome(inputTxt, 0, strlen(inputTxt));
 		memset (letras,0,sizeof(letras));
 		welcome();
 		output = letras[TARGET_LEN - 1]%10000;
 
 		fprintf (stdout, "Case #%d: %04d\n",i+1,output);
 		fprintf (outputFile, "Case #%d: %04d\n",i+1,output);
 
 	}
 
 
 	fclose (inputFile);
 	fclose (outputFile);
 }
