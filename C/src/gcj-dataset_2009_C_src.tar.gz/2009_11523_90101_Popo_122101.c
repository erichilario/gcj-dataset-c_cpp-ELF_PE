#include<stdio.h>
 #include<string.h>
 
 char str[1024];
 char *pt = "welcome to code jam";
 
 int main(){
 	int i, j, k;
 	int tc;
 	int cs;
 	int ans[32];
 	char* ptr;
 	int len = strlen(pt);
 
 	scanf("%d", &tc);
 	fgets(str, 1024, stdin);
 
 	for(cs = 1; cs <= tc; ++cs){
 		memset(ans, 0, sizeof(ans));
 		ans[0] = 1;
 		
 		ptr = fgets(str, 1024, stdin);
 		
 		for(; *ptr; ++ptr){
 			for(i = 0; i < len; ++i) if(pt[i] == *ptr){
 				ans[i+1] += ans[i];
 				ans[i+1] %= 10000;
 			}		
 		}
 
 		printf("Case #%d: %04d\n", cs, ans[len]);
 	}
 
 	return 0;	
 }

