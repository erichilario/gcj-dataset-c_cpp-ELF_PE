#include<stdio.h>
 #include<stdlib.h>
 
 char linha[510];
 int total;
 char welcome[21] = "welcome to code jam";
 int qtd;
 void encontra(int i,char c,int qtd){
     int j;
     for(j=i;linha[j]!='\0';j++){
         if(linha[j] == c){
 
             qtd++;
             if(qtd == 19){
                 total++;
                 total = total%10000;
                 qtd--;
             }
             else{
                 encontra(j+1,welcome[qtd],qtd);
                 qtd--;
             }
         }
     }
 }
 
 
 int main(){
     int N;
     int caso=1;
     scanf("%d\n",&N);
     while(N--){
         gets(linha);
         qtd = 0;
         total = 0;
         encontra(0,welcome[qtd],qtd);
         printf("Case #%d: %04d\n",caso++,total);
     }
 
 }

