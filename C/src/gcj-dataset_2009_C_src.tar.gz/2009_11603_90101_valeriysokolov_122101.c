#include <stdio.h>
 #include <string.h>
 
 int N = 0;
 
 const char pattern[] = "welcome to code jam";
 char buffer[512];
 
 unsigned int compute_count(const char *str, const char *pattern) {
  // printf("->> %s || %s\n", str, pattern);
   if(strlen(pattern) == 0)
     return 1;
   
   unsigned int res = 0;
   for(int i=0; i<strlen(str); ++i) {
     if(str[i] == pattern[0])
       res += compute_count(str + i + 1, pattern + 1);
   }
 
   return res;
 }
 
 int main() {
   scanf("%d\n", &N);
 
   for(int i=1; i<=N; ++i) {
     gets(buffer);
 //    buffer[strlen(buffer)] = '\0';
     printf("Case #%d: %04u\n", i, compute_count(buffer, pattern));
   }
 
   return 0;
 }

