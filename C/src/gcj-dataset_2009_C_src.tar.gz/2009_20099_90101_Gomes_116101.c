#include <stdio.h>
 #include <string.h>
 
 int main()
 {
 	int iL, iD, iN, i, j, iNumPStr, iIsOpen, x, y, z, total, failed, a, globalTotal;
 	char sDict[5000][15];
 	char sPStr[5000][15];
 	int match[15], b[15];
 	char sMsg[1000];
 
 	scanf("%d %d %d", &iL, &iD, &iN);
 
 	for(i=0; i<iD; i++)
 		scanf("%s", sDict[i]);
 	
 	for(j=0; j<iN; j++)
 	{
 		scanf("%s", sMsg);
 
 		iNumPStr = 0;
 		iIsOpen = 0;
 
 		a = 0;
                 b[a] = 0;
 
 		for(i=0; i<strlen(sMsg); i++)
 		{
 			if (sMsg[i] == '(')
 			{
 				iIsOpen = 1;
 			}
 			else if (sMsg[i] == ')')
 			{
 				iIsOpen = 0;
 				a++;
 	                        b[a] = 0;
 			}
 			else if (iIsOpen)
 			{
 				sPStr[b[a]][a] = sMsg[i];
 				(b[a])++;
 			}
 			else 
 			{
 				sPStr[b[a]][a] = sMsg[i];
 				(b[a])++;
                                 a++;
 	                        b[a] = 0;
 			}		
 		}
 
 		globalTotal = 0;
 		for(x=0; x<iD; x++)
 		{
 	                for(y=0; y<iL; y++)
         	                match[y] = 0;
 
 			for(y=0; y<iL; y++)
 			{
 				for(z=0; z<b[y]; z++)
 					if (sPStr[z][y] == sDict[x][y])
 						(match[y])++;
 			}
 	                total = 0;
 	                failed = 0;
                 	for(y=0; y<iL; y++)
 	                {
 	                        if (match[y] == 0)
 	                                failed = 1;
 	                        if (failed)
 	                                total = 0;
 	                        else
 	                                total += match[y];
 	                }
 			if (total > 0)
 				globalTotal ++;
 		}
 
 		printf("Case #%d: %d\n", j+1, globalTotal);
 	}
 
 	return 0;
 }
 

