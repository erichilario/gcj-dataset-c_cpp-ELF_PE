#include <stdio.h>
 #include <memory.h>
 
 int main()
 {
     int L, D, N;
     char *words;
     int i,j,k;
 
     char line[512];
 
     int token_valid[15][26];
     int occur;
 
     scanf("%d %d %d\n", &L, &D, &N);
 
     words = (char*)malloc(sizeof(char)*L*D+100);
 
     for (i=0;i<D;i++)
     {
         fgets(line, 512, stdin);
 
         memcpy(words+i*L, line, L);
     }
     for (i=0;i<N;i++)
     {
         fgets(line, 512, stdin);
         
         //clean up tokens
         for (j=0;j<15;j++)
             for (k=0;k<26;k++)
                 token_valid[j][k] = 0;
 
         k = 0;
         for (j=0;j<L&&k<512;j++)
         {
             // parse one token
             if (line[k] == '(')
             {
                 k++;
                 while (line[k] != ')')
                 {
                     int letter = line[k] - 'a';
                     token_valid[j][ letter ] = 1;      
                     k++;
                 }
                 k++; 
             }
             else
             {
                 int letter = line[k] - 'a';
                 token_valid[j][ letter ] = 1;      
                 k++;
             }
         }
 
         occur = 0;
         for (j=0;j<D;j++)
         {
             int ok = 1;
             for (k=0;k<L;k++)
             {
                 int letter = words[j*L+k]-'a';
                 if (!token_valid[k][letter])
                 {
                     ok = 0;
                     break;
                 }
             }
             if (ok)
                 occur++;
         }
 
         printf("Case #%d: %d\n", (i+1), occur);
     }
 }

