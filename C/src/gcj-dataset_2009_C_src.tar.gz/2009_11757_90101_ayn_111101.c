#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 //#define PRINT_DEBUG(_X_) printf _X_
 #define PRINT_DEBUG(_X_)
 
 struct cell
 {
 	int i32altitude;
 
 	char clabel;
 
 	struct cell *parent;
 
 	struct cell *child1;
 	struct cell *child2;
 	struct cell *child3;
 	struct cell *child4;
 };
 
 enum
 {
 	NORTH,
 	WEST,
 	EAST,
 	SOUTH,
 	DIR_NONE
 };
 
 #define MAX_BASINS 26
 struct cell *pSink[MAX_BASINS];
 int i32BasinCount = 0;
 
 void NameChildren ( struct cell* pstCell, char clabel );
 
 int main( void )
 {
 	FILE *inputfp = fopen ("B-small-attempt0.in", "rb");
 	FILE *outputfp = fopen ("output.txt", "w");	
 
 	if ( !inputfp || ! outputfp )
 	{
 		PRINT_DEBUG (("Error in opening file\n"));
 
 		return 0;
 	}
 
 	int i32MapCount,i32NoOfMaps;
 
 	fscanf ( inputfp," %d", &i32NoOfMaps);
 
 	for ( i32MapCount = 1; i32MapCount<=i32NoOfMaps; ++i32MapCount )
 	{
 		int i32Height,i32Width,i32ht,i32wt;
 
 		struct cell *pMap;
 
 		fscanf (inputfp," %d",&i32Height);
 
 		fscanf (inputfp," %d",&i32Width);
 
 		PRINT_DEBUG (( "Map %d : Ht[%d] Wt[%d]\n",i32MapCount,i32Height,i32Width) );
 
 		pMap = ( struct cell *) malloc ( i32Height * i32Width * sizeof( struct cell) );
 
 		if ( pMap == NULL )
 		{
 			fclose ( inputfp );
 			fclose ( outputfp );
 			return 0;
 		}
 
 		memset ( pMap, 0, ( i32Height * i32Width * sizeof( struct cell) ) );
 
 		PRINT_DEBUG (( "Altitudes :\n") );
 
 		for ( i32ht = 0; i32ht < i32Height ; ++i32ht )
 		{
 			for ( i32wt = 0; i32wt < i32Width ; ++i32wt )
 			{
 				int i32Altitude;
 				struct cell *pstCell = pMap + ( i32ht * i32Width ) + i32wt;
 
 				fscanf ( inputfp," %d", &i32Altitude);
 
 				PRINT_DEBUG (( "%d ",i32Altitude) );
 
 				pstCell->i32altitude = i32Altitude;				
 			}
 		}
 
 
 		int i32basin;
 		for ( i32basin = 0; i32basin < MAX_BASINS; ++i32basin )
 		{
 			pSink[i32basin] = NULL;
 		}
 		i32BasinCount = 0;
 
 		for ( i32ht = 0; i32ht < i32Height ; ++i32ht )
 		{
 			for ( i32wt = 0; i32wt < i32Width ; ++i32wt )
 			{
 				struct cell*pstLowerAltitudeCell = NULL;
 
 				struct cell *pstCell = pMap + ( i32ht * i32Width ) + i32wt;
 
 				int i32LeastAltitude = pstCell->i32altitude;
 
 				PRINT_DEBUG (( "Cell[%d][%d]\n",i32ht,i32wt) );
 
 				if ( i32ht > 0 )
 				{
 					struct cell *pstNorthCell = pMap + ( (i32ht - 1) * i32Width ) + i32wt;
 					int i32NorthAltitude = pstNorthCell->i32altitude;
 
 					if ( i32NorthAltitude < i32LeastAltitude )
 					{
 						pstLowerAltitudeCell   = pstNorthCell;
 						i32LeastAltitude = pstNorthCell->i32altitude;
 
 						PRINT_DEBUG (( "North is lower\n") );
 					}
 				}
 
 				if ( i32wt > 0 )
 				{
 					struct cell *pstWestCell = pMap + ( i32ht * i32Width ) + i32wt - 1;
 					int i32WestAltitude = pstWestCell->i32altitude;
 
 					if ( i32WestAltitude < i32LeastAltitude )
 					{
 						pstLowerAltitudeCell   = pstWestCell;
 						i32LeastAltitude = pstWestCell->i32altitude;
 
 						PRINT_DEBUG (( "West is lower\n") );
 					}
 				}
 
 				if ( i32wt < (i32Width -1) )
 				{
 					struct cell *pstEastCell = pMap + ( i32ht * i32Width ) + i32wt + 1;
 					int i32EastAltitude = pstEastCell->i32altitude;
 
 					if ( i32EastAltitude < i32LeastAltitude )
 					{
 						pstLowerAltitudeCell   = pstEastCell;
 						i32LeastAltitude = pstEastCell->i32altitude;
 
 						PRINT_DEBUG (( "East is lower\n") );
 					}
 				}
 				
 				if ( i32ht < (i32Height-1) )
 				{
 					struct cell *pstSouthCell = pMap + ( ( i32ht + 1 )* i32Width ) + i32wt;
 					int i32SouthAltitude = pstSouthCell->i32altitude;
 
 					if ( i32SouthAltitude < i32LeastAltitude )
 					{
 						pstLowerAltitudeCell   = pstSouthCell;
 						i32LeastAltitude = pstSouthCell->i32altitude;
 
 						PRINT_DEBUG (( "South is lower\n") );
 					}
 				}
 
 				if ( pstLowerAltitudeCell == NULL )
 				{
 //					pSink[i32BasinCount] = pstCell;
 //					++i32BasinCount;
 					pstCell ->parent = NULL;
 
 
 					PRINT_DEBUG (("This is a sink\n"));
 				}
 				else
 				{
 					pstCell->parent = pstLowerAltitudeCell;
 
 					if ( pstLowerAltitudeCell->child1 == NULL )
 					{
 						pstLowerAltitudeCell->child1 = pstCell;
 
 						PRINT_DEBUG (("Parent Altitude[%d]\n", pstLowerAltitudeCell->i32altitude));
 					}
 					else if ( pstLowerAltitudeCell->child2 == NULL )
 					{
 						pstLowerAltitudeCell->child2 = pstCell;
 
 						PRINT_DEBUG (("Parent Altitude[%d]\n", pstLowerAltitudeCell->i32altitude));
 					}
 					else if ( pstLowerAltitudeCell->child3 == NULL )
 					{
 						pstLowerAltitudeCell->child3 = pstCell;
 
 						PRINT_DEBUG (("Parent Altitude[%d]\n", pstLowerAltitudeCell->i32altitude));
 					}
 					else if ( pstLowerAltitudeCell->child4 == NULL )
 					{
 						pstLowerAltitudeCell->child4 = pstCell;
 
 						PRINT_DEBUG (("Parent Altitude[%d]\n", pstLowerAltitudeCell->i32altitude));
 					}
 					else
 					{
 						PRINT_DEBUG (( "Error> cannot make a child of parent node\n") );
 					}
 				}
 			}
 		}
 
 
 		char cLabel = 'a';
 
 		// name the cells by determining their basin
 
 		for ( i32ht = 0; i32ht < i32Height ; ++i32ht )
 		{
 			for ( i32wt = 0; i32wt < i32Width ; ++i32wt )
 			{
 				struct cell *pstCell = pMap + ( i32ht * i32Width ) + i32wt;
 
 				if ( pstCell ->clabel == 0 )
 				{
 					pstCell ->clabel = cLabel;
 
 
 					// find the sink of this cell
 
 					struct cell *pstSink = pstCell;
 					while ( pstSink->parent )
 					{
 						pstSink = pstSink->parent;
 					}
 
 					// name all the cells of this basin the same letter
 
 					NameChildren ( pstSink,cLabel );
 
 					PRINT_DEBUG (( "Assigning label[%c]\n",cLabel) );
 
 					++cLabel;
 				}
 			}
 		}
 
 
 
 
 
 		fprintf (outputfp,"Case #%d:\n",i32MapCount);
 
 		//output the label in matrix format
 		for ( i32ht = 0; i32ht < i32Height ; ++i32ht )
 		{
 			for ( i32wt = 0; i32wt < i32Width ; ++i32wt )
 			{
 				int i32Altitude;
 				struct cell *pstCell = pMap + ( i32ht * i32Width ) + i32wt;
 
 				fprintf (outputfp,"%c ",pstCell->clabel);
 			}
 
 			fprintf (outputfp,"\n");
 		}
 
 		if ( pMap )
 		{
 			free ( pMap );
 			pMap = NULL;
 		}
 	}
 	
 	if ( inputfp )
 	{
 		fclose ( inputfp );
 		inputfp = NULL;
 	}
 
 	if ( outputfp )
 	{
 		fclose ( outputfp );
 		outputfp = NULL;
 	}
 
 	return 0;
 }
 
 void NameChildren ( struct cell* pstCell, char clabel )
 {
 	pstCell ->clabel = clabel;
 
 	if ( pstCell->child1 )
 	{
 		NameChildren (pstCell->child1, clabel);
 	}
 
 	if ( pstCell->child2 )
 	{
 		NameChildren (pstCell->child2, clabel);
 	}
 
 	if ( pstCell->child3 )
 	{
 		NameChildren (pstCell->child3, clabel);
 	}
 
 	if ( pstCell->child4 )
 	{
 		NameChildren (pstCell->child4, clabel);
 	}
 
 	return;
 }
 

