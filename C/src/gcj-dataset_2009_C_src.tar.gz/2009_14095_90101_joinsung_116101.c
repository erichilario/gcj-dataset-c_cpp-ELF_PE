#include <stdio.h>
 
 int main()
 {
 	int l,d,n;
 	char words[5000][16];
 	scanf("%d %d %d",&l,&d,&n);
 	int di;
 	for (di=0;di<d;di++)
 		scanf("%s",words[di]);
 	int ni;
 	int possible[15][26];
 	int i,j;
 	char buf[421];
 	int bi;
 	int li;
 	int open;
 	int ptr;
 	for (ni=1;ni<=n;ni++)
 	{
 		for (i=0;i<15;i++)
 			for (j=0;j<26;j++)
 				possible[i][j]=0;
 		scanf("%s",buf);
 		open=0;
 		ptr=0;
 		for (bi=0;buf[bi];bi++)
 		{
 			if (buf[bi]=='(')
 				open=1;
 			else if (buf[bi]==')')
 			{
 				open=0;
 				ptr++;
 			}
 			else
 			{
 				possible[ptr][buf[bi]-'a']=1;
 				if (!open) ptr++;
 			}
 		}
 		int cnt=0;
 		int flag;
 		for (di=0;di<d;di++)
 		{
 			flag=1;
 			for (li=0;li<l;li++)
 				if (!possible[li][words[di][li]-'a'])
 					flag=0;
 			if (flag) cnt++;
 		}
 		printf("Case #%d: %d\n",ni,cnt);
 	}
 	return 0;
 }

