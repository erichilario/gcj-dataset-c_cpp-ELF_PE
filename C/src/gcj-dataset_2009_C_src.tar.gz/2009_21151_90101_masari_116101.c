#include <stdio.h>
 #include <stdio.h>
 
 char w[5000][16];
 int n_p;
 char p[500][501];
 
 int main(void)
 {
 	int l, d, n, i, j, k, m, t, count, tag;
 	char c;
 	
 	scanf("%d %d %d ",&l, &d, &n);
 	/* le as palavras existentes */
 	for(i=0;i<d;i++){
 		j = 0;
 		c = getchar();
 		while(c!='\n'){
 			w[i][j++] = c;
 			c = getchar();
 		}
 		w[i][j] = '\0';
 	}
 	
 	t = 1;
 	while(n--){		
 		n_p = 0;
 		/* le um padrao possivel */
 		c = getchar();
 		while(c!='\n'&& !feof(stdin) ){
 			m = 0;
 			if(c == '('){
 				c = getchar();
 				while( c!=')' ){
 					p[n_p][m++] = c;
 					c = getchar();
 				}
 			}else{
 				p[n_p][m++] = c;	
 			}
 			p[n_p][m] = '\0';
 			n_p++;
 			c = getchar();
 		}
 		
 		count = 0;
 		for(k=0;k<d;k++){
 			i = 0;
 			while (w[k][i] != '\0'){				
 				m = tag = 0;
 				while(i<n_p && p[i][m] != '\0'){
 					if(p[i][m] == w[k][i]){
 						tag = 1; break;
 					}else{
 						m++;
 					}
 				}
 				if(!tag) break;
 				i++;
 			}
 			if(w[k][i] == '\0') count++;
 		}
 		
 		printf("Case #%d: %d\n",t++, count);
 	}
 	
 	
 	return 0;
 }
