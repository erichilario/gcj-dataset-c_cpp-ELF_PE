#include<stdio.h>
 #include<stdlib.h>
 #define NEG -20000
 
 struct _node{
 	 int ev;
 	 int color;
 	};
 
 typedef struct _node node;
 int COLOR = 'a';
 
 int color_map_problem(node **map, int H, int W, int h, int w){
 	
 	/* Find the direction of flow and recurse */
 	
 	if(map[h][w].color != -1)
 		return map[h][w].color;
 
 	else{//Find the direction of flow
 		int n_ev, e_ev, s_ev, w_ev, h1, w1, max;
 		if((h-1)>= 0 ) n_ev = map[h][w].ev - map[h-1][w].ev;
 		else n_ev = NEG;
 		
 		if((w+1) < W) e_ev = map[h][w].ev -map[h][w+1].ev;
 		else e_ev = NEG;
 		
 		if((h+1)< H) s_ev = map[h][w].ev - map[h+1][w].ev;
 		else s_ev = NEG;
 		
 		if((w-1)>=0 ) w_ev = map[h][w].ev - map[h][w-1].ev;
 		else w_ev = NEG;
 		
 		max = n_ev;
 		h1 = h-1;
 		w1 = w;
 		if(w_ev > n_ev){
 			h1 = h;
 			w1 = w-1;
 			max = w_ev;
 		}
 		if(e_ev > max){
 			h1 = h;
 			w1 = w+1;
 			max = e_ev;
 		}
 		
 		if(s_ev > max){
 			h1 = h+1;
 			w1 = w;
 			max = s_ev;
 		}
 		
 		if(max <= 0){ // It's a damn basin!
 			COLOR++;
 			map[h][w].color = COLOR;
 			return COLOR;
 		}
 		
 		else{
 			int temp_color = color_map_problem(map, H, W, h1, w1);
 			map[h][w].color = temp_color;
 			return temp_color;
 		}
 	}
 }
 		
 
 void run(node **map, int H, int W){
 	// Run through all the vertices and color them if they already aren't!
 	int h,w;
 	COLOR='a';
 	for(h=0;h<H;h++)
 	 for(w=0;w<W;w++)
 	   if(map[h][w].color == -1)
 	      color_map_problem(map, H, W, h, w);	
 }
 	
 
 int main(){
 	
 	int N;
 	scanf("%d",&N);	// Determine the number of maps
 	int i;
 	node **map;
 
 	for(i=0;i< N;i++){//For each map
 		int H, W;
 		scanf("%d%d",&H,&W);
 		int h,w;
 		map = (node **)malloc(H*sizeof(node*));
 		for(h=0;h<H;h++)		
 		  map[h] = (node *)malloc(W*sizeof(node));
 			
 		/* Sacn the graph */
 		for(h=0;h<H;h++)
 		 for(w=0;w<W;w++){
 		   scanf("%d",&(map[h][w].ev));
 		   map[h][w].color = -1;
 		 }
 
 		run(map, H, W);
 		printf("Case #%d:\n", i+1);
 		for(h=0;h<H;h++){
 		  for(w=0;w<W;w++)
 		    printf("%c ",map[h][w].color-1);
 		    printf("\n");
 		    }
 		}
 	
 	return(1);
 }

