#include <stdio.h>
 #include <string.h>
 
 int t, h, w;
 int map[128][128];
 int cl[128][128];
 int dir[5][2];
 int x[65536], y[65536];
 
 void next(int x, int y, int *nx, int *ny)
 {
    int min = 0x3f3f3f3f; 
    int pos = 4;
 
    if (x + 1 < h && map[x + 1][y] <= min)
    {
        min = map[x + 1][y];
        pos = 0;
    }
 
    if (y + 1 < w && map[x][y + 1] <= min)
    {
        min = map[x][y + 1];
        pos = 1;
    }
 
    if (y - 1 >= 0 && map[x][y - 1] <= min)
    {
        min = map[x][y - 1];
        pos = 2;
    }
 
    if (x - 1 >= 0 && map[x - 1][y] <= min)
    {
        min = map[x - 1][y];
        pos = 3;
    }
 
    if (map[x][y] <= min)
        *nx = x, *ny = y;
    else
    {
        *nx = x + dir[pos][0];
        *ny = y + dir[pos][1];
    }
 
 }
 
 int ok(int nowx, int nowy, int posx, int posy)
 {
     int xx, yy;
     if (posx < 0 || posy < 0 || posx >= h || posy >= w)
         return 0;
     if (cl[posx][posy])
         return 0;
     next(nowx, nowy, &xx, &yy);
     if (xx == posx && yy == posy)
         return 1;
     next(posx, posy, &xx, &yy);
     if (xx == nowx && yy == nowy)
         return 1;
     return 0;
 }
 
 int main()
 {
     int i, j, k, l, color;
     int nowx, nowy;
     int begin, end;
 
     freopen("b.in", "r", stdin);
     freopen("b.out", "w", stdout);
 
     dir[0][0] = 1; dir[0][1] = 0;
     dir[1][0] = 0; dir[1][1] = 1;
     dir[2][0] = 0; dir[2][1] = -1;
     dir[3][0] = -1; dir[3][1] = 0;
 
     scanf("%d", &t);
     for (i = 1; i <= t; ++i)
     {
         memset(cl, 0, sizeof(cl));
 
         scanf("%d %d\n", &h, &w);
         for (j = 0; j < h; ++j)
             for (k = 0; k < w; ++k)
                 scanf("%d", &map[j][k]);
 
         color = 0;
         for (j = 0; j < h; ++j)
             for (k = 0; k < w; ++k)
                 if (!cl[j][k])
                 {
                     color++;
                     cl[j][k] = color;
                     x[0] = j, y[0] = k;
                     for (begin = end = 0; begin <= end; ++begin)
                     {
                         for (l = 0; l < 4; ++l)
                         {
                             nowx = x[begin] + dir[l][0];
                             nowy = y[begin] + dir[l][1];
                             if (ok(x[begin], y[begin], nowx, nowy))
                             {
                                 ++end;
                                 x[end] = nowx;
                                 y[end] = nowy;
                                 cl[nowx][nowy] = color;
                             }
                         }
                     }
                 }
 
         printf("Case #%d:\n", i);
         for (j = 0; j < h; ++j, printf("\n"))
             for (k = 0; k < w; ++k)
                 printf("%c ", cl[j][k] - 1 + 'a');
     }
     return 0;
 }

