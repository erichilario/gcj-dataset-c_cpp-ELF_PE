#include<stdio.h>
 #include<string.h>
 
 FILE *fin, *fout;
 
 int prod(int *p)
 {
 	int nr=1, i;
 	for(i=0; i<19; i++) 
 	{
 		nr *= p[i];
 		nr %= 10000;
 	}
 	return nr;
 }
 
 void afisare(int x)
 {
     if(x<1000) fprintf(fout,"0");
     if(x<100) fprintf(fout,"0");
     if(x<10) fprintf(fout,"0");
     fprintf(fout,"%i\n",x);
 }
 
 int main()
 {
     int n, i, j, t, ok[256], len, nr, k, p[20], ind[20];
 	char s[501],v[501];
     fin = fopen("date.in", "rt");
     fout = fopen("date.out", "wt");
     fscanf(fin,"%i",&n);
     for(t=1; t<=n; t++)
 	{
 		fscanf(fin, "\n");
         fgets(s,501,fin);
 		for(i=0; i<256; i++) ok[i] = 0;
 		ok['w'] = 2;
 		len = strlen(s);
 		j=0;
 		for(i=0; i<len; i++)
 			if(ok[s[i]]!=0)
 			{
 				v[j++] = s[i];
 				if(ok[s[i]]==2)
 				{
 					switch(s[i])
 					{
 						case 'w': ok['e'] = 2; break;
 						case 'e': ok['l'] = 2; break;
 						case 'l': ok['c'] = 2; break;
 						case 'c': ok['o'] = 2; break;
 						case 'o': ok['m'] = 2; break;
 						case 'm': ok[' '] = 2; break;
 						case ' ': ok['t'] = 2; break;
 						case 't': ok['d'] = 2; break;
 						case 'd': ok['j'] = 2; break;
 						case 'j': ok['a'] = 2; break;
 						default: break;
 					}
 					ok[s[i]] = 1;
 				}	
 			}
 		v[j] = 0;
         len = j;
 		nr = 0;
 		k = 0;
 		j = 0;
 		strcpy(s,"welcome to code jam");
 		while(k>-1)
 		{
 			while(j<len && v[j]!=s[k]) j++;
             ind[k] = j;
 			while(ind[k]<len && v[ind[k]]==s[k]) ind[k]++;
 			p[k] = ind[k]-j;
         	if(p[k]==0)
             {
                 j = ind[--k];
                 continue;
             }
             j = ind[k];
         	k++;
             if(k==19) 	
 			{
 				nr += prod(p);
 				nr %= 10000;
 				j = ind[--k];
 			}
 			if(j==len) j = ind[--k];
 		}		
 		fprintf(fout, "Case #%i: ", t);
         afisare(nr);	
 	}
 	fclose(fin);
 	fclose(fout);
 	return 0;
 }
 		
 			
 		
 	
 		

