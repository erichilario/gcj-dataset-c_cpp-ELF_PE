#include <stdio.h>
 #include <string.h>
 #define N 100
 
 int test, H, W;
 int map[N][N];
 char label[N][N], tag;
 int dir[4][2] = {{-1, 0}, {0, -1}, {0, 1}, {1, 0}};
 
 char walk(int x, int y)
 {
     int k, alti = map[x][y];
     char ret;
 
     //printf("walk from (%d %d)\n", x, y);
 
     for (k = 0; k < 4; k++)
 	if (x + dir[k][0] >= 0 && x + dir[k][0] < H &&
 		y + dir[k][1] >= 0 && y + dir[k][1] < W &&
 		map[x + dir[k][0]][y + dir[k][1]] < alti)
 	    alti = map[x + dir[k][0]][y + dir[k][1]];
     if (alti == map[x][y]) {
 	//printf("-----> equal!\n");
 	label[x][y] = tag++;
 	//printf("set label %d, %d\n", x, y);
 	return tag - 1;
     } else {
 	for (k = 0; k < 4; k++) {
 	    if (x + dir[k][0] >= 0 && x + dir[k][0] < H &&
 		    y + dir[k][1] >= 0 && y + dir[k][1] < W &&
 		    label[x + dir[k][0]][y + dir[k][1]] != 0 &&
 		    map[x + dir[k][0]][y + dir[k][1]] == alti) {
 		//printf("%d, %d   already set\n", x + dir[k][0], y + dir[k][1]);
 		label[x][y] = label[x + dir[k][0]][y + dir[k][1]];
 		return label[x + dir[k][0]][y + dir[k][1]];
 	    }
 	    if (x + dir[k][0] >= 0 && x + dir[k][0] < H &&
 		    y + dir[k][1] >= 0 && y + dir[k][1] < W &&
 		    label[x + dir[k][0]][y + dir[k][1]] == 0 && 
 		    map[x + dir[k][0]][y + dir[k][1]] == alti) {
 		ret = walk(x + dir[k][0], y + dir[k][1]);
 		//printf("set label %d, %d\n", x, y);
 		label[x][y] = ret;
 		return ret;
 	    }
 	}
     }
 }
 
 void setlabel()
 {
     int i, j;
     char ret;
     tag = 'a';
     for (i = 0; i < H; i++) 
 	for (j = 0; j < W; j++) 
 	    if (label[i][j] == 0) {
 		walk(i, j);
 //		ret = walk(i, j);
 //		label[i][j] = ret;
 	    }
 }
 
 int main(int argc, char *argv[])
 {
     int cases, i, j;
     scanf("%d", &test);
     for (cases = 1; cases <= test; cases++) {
 	scanf("%d%d", &H, &W);
 	for (i = 0; i < H; i++) 
 	    for (j = 0; j < W; j++)
 		scanf("%d", &map[i][j]);
 	memset(label, 0, sizeof(label));
 	setlabel();
 	printf("Case #%d:\n", cases);
 	for (i = 0; i < H; i++) {
 	    printf("%c ", label[i][0]);
 	    for (j = 1; j < W; j++)
 		printf("%c ", label[i][j]);
 	    printf("\n");
 	}
     }
 
     return 0;
 }

