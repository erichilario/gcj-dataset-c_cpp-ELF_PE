#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 
 
 int main(){
 
 	int l, d, n;
 	int i, j, k, s, t;
 	int ln;
 	char dico[5000][16];
 	char word[5000];	
 	char matrix[16][5000];
 	int open;
 	int nums[15];
 	int cnt;
 	FILE *inp = fopen("A-large.in", "r");
 	FILE *outp = fopen("A-large.out", "w");
 			
 	fscanf (inp, "%d %d %d", &l, &d, &n);
 //	scanf ("%d %d %d", &l, &d, &n);
 	
 	for (i = 0; i < d; i ++) 
 		fscanf(inp, "%s", dico[i]);		
 //		scanf("%s", dico[i]);		
 		
 	for (i = 0; i < n; i++) {
 		
 		fscanf(inp, "%s", word);			
 //		scanf("%s", word);
 		ln = strlen(word);
 		
 		open = 0;
 		j = 0;
 		k = 0;
 		
 		for(s = 0; s < ln; s++){
 			
 			if(word[s] == '('){
 				
 				open = 1;
 				
 			}	else if(word[s] == ')'){
 				
 				matrix[j][k] = '\0';
 				j++;
 				k = 0;
 				open = 0;
 				
 			}	else if(open == 0){
 				
 				matrix[j][k] = word[s];
 				matrix[j][k+1] = '\0';
 				
 				j++;
 				k = 0;
 				
 			}	else {
 				
 				matrix[j][k] = word[s];
 				k++;		
 			}
 		}
 		
 		for (s = 0; s < l; s++)
 			fprintf(outp, "%s\n", matrix[s]);
 			
 		cnt = 0;				
 		for(s = 0; s < d; s++){
 
 			for(t = 0; t < l; t++){
 				if(strchr(matrix[t],dico[s][t]) == NULL)
 					break;
 			}
 			
 			if(t == l)
 				cnt++;
 		}
 		
 		fprintf(outp, "Case #%d: %d\n", i+1, cnt);		
 //		printf("Case #%d: %d\n", i+1, cnt);		
 	}
 	
 	return 0;
 }

