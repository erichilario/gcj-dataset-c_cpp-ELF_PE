// this program has been compiled and tested using GNU GCC compiler and Code::Blocks ide.
 
 
 #include<stdio.h>
 #include<string.h>
 #include <stdlib.h>
 
 
 int main(){
 
 
      FILE *fp;
     char ch;
     char* s;
 
 
 
     long L,D,N;
 
 
 
     long breakPoint = 0;
     fp = fopen("A-small-attempt1.in","r");
     if(fp == NULL){
         printf("could not open file");
     }
     s = NULL;
     while(1){
         ch = fgetc(fp);
         if(breakPoint > 2){
             break;
         }
         if(ch == EOF){
             break;
         }
         else if(ch == '\n'){
              switch(breakPoint){
                 case 0:
                     L = atol(s);
                 break;
                 case 1:
                     D = atol(s);
                 break;
                 case 2:
                     N = atol(s);
                 break;
             }
              breakPoint++;
             s = NULL;
             continue;
         }
         else if(ch == ' '){
             switch(breakPoint){
                 case 0:
                     L = atol(s);
                 break;
                 case 1:
                     D = atol(s);
                 break;
                 case 2:
                     N = atol(s);
                 break;
             }
             breakPoint++;
             s = NULL;
             continue;
         }
 
         if(s == NULL){
             s = (char*)malloc(1);
             s[0] = ch;
             s[1] = '\0';
 
         }
         else{
             char* temp;
             long len = strlen(s);
             temp = (char*)malloc(len);
             temp = s;
             s = (char*)malloc(len+2);
             s = temp;
             s[len] = ch;
             s[len+1] = '\0';
         }
     }
     fclose(fp);
 
     ///////////////////////////////////////////
 
     char* dict[D];
 
     char* testCases[N];
 
     long output[N];
 
     breakPoint = -1;
     fp = fopen("A-small-attempt1.in","r");
     if(fp == NULL){
         printf("could not open file");
     }
     s = NULL;
 
     int closing = 0;
     while(1){
         ch = fgetc(fp);
         if(ch == EOF){
             if(breakPoint >= 0){
                 if(breakPoint<D){
                     dict[breakPoint] = s;
                 }
                 else{
                     testCases[breakPoint-D] = s;
                 }
              }
              breakPoint++;
             s = NULL;
             closing = 1;
         }
         else if(ch == '\n'){
              if(breakPoint >= 0){
                 if(breakPoint<D){
                     dict[breakPoint] = s;
                 }
                 else{
                     testCases[breakPoint-D] = s;
 
                 }
              }
              breakPoint++;
             s = NULL;
             continue;
         }
          else if(ch == ' '){
              if(breakPoint >= 0){
                 if(breakPoint<D){
                     dict[breakPoint] = s;
                 }
                 else{
                     testCases[breakPoint-D] = s;
                 }
              }
             s = NULL;
             continue;
         }
 
         if(closing == 1){
             break;
         }
 
         if(s == NULL){
             s = (char*)malloc(1);
             s[0] = ch;
             s[1] = '\0';
 
         }
         else{
 
 
             char* temp;
             long len = strlen(s);
             temp = (char*)malloc(len+2);
 
             strcpy(temp,s);
 
             temp[len] = ch;
             temp[len+1] = '\0';
 
             s = temp;
 
         }
 
 
     }
     fclose(fp);
 
     //////////////////
     long l = L;
     long d = D;
 
 
     char* a[l];
     long i[l];
     long tot[l];
 
     for(long n = 0; n < l; n++){
         a[n] = "*************************";
         i[n] = 0;
     }
 
 
 
     char* str;
 
     long count;
 
     for( long n1 = 0; n1 < N; n1++){
 
         count = 0;
         str = testCases[n1];
         char c;
 
         long index,index1;
 
         index = -1;
         index1 = 0;
 
         int newWord = 0;
 
         char empty[1000];
 
 
 
         for(long n = 0; n<strlen(str); n++){
 
             c = char(str[n]);
 
             if(c == '('){
                 index++;
                 index1 = 0;
                 newWord = 1;
                 strcpy(empty,"*");
             }
             else if(c == ')'){
                 newWord = 0;
                 empty[index1] = '\0';
                 char *p ;
                 long len = strlen (empty ) ;
                 p = (char*) malloc(len + 1) ;
                 strcpy ( p, empty ) ;
                 a[index] = p ;
             }
             else{
 
                 if(newWord == 1){
                     empty[index1] = char(c);
                     index1++;
                 }
                 else{
                     index++;
                      strcpy(empty,"*");
                     empty[0] = char(c);
                     empty[1] = '\0';
                      char *p ;
                     long len = strlen (empty ) ;
                     p = (char*) malloc(len + 1) ;
                     strcpy ( p, empty ) ;
                     a[index] = p ;
 
                 }
             }
 
 
         }
 
         for(long n = 0; n < l; n++){
             tot[n] = strlen(a[n]);
         }
 
         count = d;
         for(long k = 0; k < d; k++){
             for(long n = 0; n < l; n++){
                 if(strchr(a[n],dict[k][n]) == NULL){
                     count--;
                     break;
                 }
             }
         }
 
         output[n1] = count;
         count = 0;
     }
 
     fp = fopen("A-small.out","w");
     if(fp == NULL){
         printf("could not open file");
     }
 
 
 
     for( long n1 = 0; n1 < N; n1++){
         fprintf(fp,"Case #%d: %ld \n",n1+1,output[n1]);
     }
     fclose(fp);
 
     return 0;
 }
 
 

