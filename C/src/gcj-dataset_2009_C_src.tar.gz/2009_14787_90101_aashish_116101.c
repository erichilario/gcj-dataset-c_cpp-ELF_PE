#include<stdio.h>
 #include<string.h>
 int main()
 {
 	int l,d,n;
 	int z=1;
 	char str[26][11];
 	char inp[1000];
 	int len,i,j,found=0,k,p;
 	scanf("%d%d%d",&l,&d,&n);
 	for(i=0;i<d;i++)
 	{
 		scanf("%s",str[i]);
 	}
 /*	for(i=0;i<d;i++)
 	{
 		for(j=0;j<l;j++)
 			printf("a[%d][%d] = %c\t",i,j,str[i][j]);
 	}
 */
 	while(n--)
 	{
 		p=0;
 		scanf("%s",inp);
 		len = strlen(inp);
 		for(i=0;i<d;i++)
 		{
 			j=0;
 			for(k=0;k<l;k++)
 			{
 				if(inp[j]=='(')
 				{
 //					printf("%c\n",str[i][k]);
 					j++;
 					found=0;
 					while(inp[j]!=')')
 					{
 						if(str[i][k]==inp[j])
 						{
 							found=1;
 						}
 						j++;
 					}
 					j++;
 					if(found!=1)
 						break;
 				}
 				else
 				{
 //					printf("yahan mara raha hai code");
 			    	if(inp[j]==str[i][k])
 					{
 						j++;
 						found=1;
 					}
 					else
 					{
 						found=0;
 						break;
 					}
 				}
 			}
 			if(found==1)
 				p+=1;
 
 		 }
 		 printf("Case #%d: ",z++);
 		 printf("%d\n",p);
 	}	
 }

