#include <stdio.h>
 #include <string.h>
 #include <ctype.h>
 #define LEN 35
 
 int ans, n, length;
 char str[LEN];
 const char wel[] = "welcome to code jam";
 
 void solve(int begin, int pos)
 {
     if (begin == length)
 	return;
     if (pos == 19) {
 	++ans;
 	if (ans == 10000)
 	    ans = 0;
 	return;
     }
     if (str[begin] == wel[pos])
 	solve(begin + 1, pos + 1);
     solve(begin + 1, pos);
 }
 
 int main(int argc, char *argv[])
 {
     int test;
     scanf("%d", &n);
     getchar();
     for (test = 1; test <= n; test++) {
 	fgets(str, LEN, stdin);
 	length = strlen(str);
 	ans = 0;
 	solve(0, 0);
 	printf("Case #%d: %04d\n", test, ans);
     }
     
     return 0;
 }

