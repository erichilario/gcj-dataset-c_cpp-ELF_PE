#include <stdio.h>
 #include <limits.h>
 
 #define MMAX 100
 #define NMAX 100
 #define NONE '.'
 static char ch;
 static int  m, n;
 static int  A [MMAX][NMAX];
 static char M [MMAX][NMAX];
 
 static void fill(int i, int j) {
 	static const int D[4][2] = {
 		{-1,  0},
 		{ 0, -1},
 		{ 0,  1},
 		{ 1,  0}
 	};
 
 	int best;
 	int d;
 	int x, y;
 
 	best = INT_MAX;
 	for (d = 0; d != 4; ++d) {
 		x = i + D[d][0];
 		y = j + D[d][1];
 
 		if ((0 <= x && x < m) && (0 <= y && y < n) && A[x][y] < A[i][j])
 			if (A[x][y] < best)
 				best = A[x][y];
 	}
 
 	for (d = 0; d != 4; ++d) {
 		x = i + D[d][0];
 		y = j + D[d][1];
 
 		if ((0 <= x && x < m) && (0 <= y && y < n) && A[x][y] == best) {
 			if (M[x][y] == NONE)
 				fill(x, y);
 			M[i][j] = M[x][y];
 			return;
 		}
 	}
 
 	M[i][j] = ch++;
 }
 
 int main(void) {
 	int tc, cs;
 	int i, j;
 
 	scanf("%d", &tc);
 	for (cs = 0; cs != tc; ++cs) {
 		printf("Case #%d:\n", cs+1);
 
 		scanf("%d%d", &m, &n);
 		for (i = 0; i != m; ++i)
 			for (j = 0; j != n; ++j) {
 				scanf("%d", &A[i][j]);
 				M[i][j] = NONE;
 			}
 
 		ch = 'a';
 		for (i = 0; i != m; ++i)
 			for (j = 0; j != n; ++j)
 				if (M[i][j] == NONE)
 					fill(i, j);
 
 		for (i = 0; i != m; ++i)
 			for (j = 0; j != n; ++j)
 				printf("%c%c", M[i][j], j == n-1 ? '\n' : ' ');
 	}
 
 	return 0;
 }
 
 

