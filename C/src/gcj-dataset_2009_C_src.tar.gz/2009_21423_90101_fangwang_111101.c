#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 #define min(x, y)  (x > y ? y : x)
 #define max(x, y)  (x > y ? x : y)
 
 int T, H, W;
 int **map;
 char **result;
 
 char lable;
 
 int getdirection(int h, int w)
 {
 	int dir[4];
 	int lowest;
 	dir[0] = map[h][w] - map[max(0, h - 1)][w];
 	dir[1] = map[h][w] - map[h][max(0, w - 1)];
 	dir[2] = map[h][w] - map[h][min(W - 1, w + 1)];
 	dir[3] = map[h][w] - map[min(H - 1, h + 1)][w];
 	
 	lowest = max(0, max(dir[0], max(dir[1], max(dir[2], dir[3]))));
 	if (lowest == 0)
 		return 0;
 	if (dir[0] == lowest)
 		return 1;
 	if (dir[1] == lowest)
 		return 2;
 	if (dir[2] == lowest)
 		return 3;
 	if (dir[3] == lowest)
 		return 4;
 	
 }
 
 char recursion(int h, int w)
 {
 	switch(getdirection(h, w))
 	{
 	case 0:
 		if (result[h][w] == 0)
 			result[h][w] = lable++;
 		break;
 	case 1:
 		result[h][w] = recursion(h - 1, w);
 		break;
 	case 2:
 		result[h][w] = recursion(h, w - 1);
 		break;
 	case 3:
 		result[h][w] = recursion(h, w + 1);
 		break;
 	case 4:
 		result[h][w] = recursion(h + 1, w);
 		break;
 	}
 	return result[h][w];
 }
 
 int main()
 {
 	FILE *fp;
 	int t, h, w;
 	int hi, wi;
 
 	//fp = fopen("B-small-attempt0.in", "r");
 	fp = fopen("B-large.in", "r");
 	fscanf(fp, "%d\n", &T);
 	for (t = 0; t < T; t++)
 	{
 		fscanf(fp, "%d %d\n", &H, &W);
 		lable = 'a';
 		map = malloc(sizeof(int *) * H);
 		result = malloc(sizeof(void *) * H);
 		for (h = 0; h < H; h++)
 		{
 			map[h] = malloc(sizeof(int) * W);
 			result[h] = malloc(W);
 			memset(result[h], 0, W);
 			for (w = 0; w < W - 1; w++)
 				fscanf(fp, "%d ", &map[h][w]);
 			fscanf(fp, "%d\n", &map[h][w]);
 		}
 		for (h = 0; h < H; h++)
 		{
 			for (w = 0; w < W; w++)
 			{
 				if (result[h][w] == 0)
 					result[h][w] = recursion(h, w);
 			}
 		}
 		printf("Case #%d:\n", t + 1);
 		for (h = 0; h < H; h++)
 		{
 			for (w = 0; w < W - 1; w++)
 				printf("%c ", result[h][w]);
 			printf("%c\n", result[h][w]);
 			free(result[h]);
 			free(map[h]);
 		}
 		free(result);
 		free(map);
 	}
 
 	return 0;
 }

