#include <stdio.h>
 #include <string.h>
 char w[19] = "welcome to code jam";
 char text[512];
 int d[512][19];
 int N;
 
 int main()
 {
     int i, j, k, l;
     int sol;
 
     freopen("c.in", "r", stdin);
     freopen("c.out", "w", stdout);
 
     scanf("%d\n", &N);
 
     for (i = 1; i <= N; ++i)
     {
         memset(d, 0, sizeof(d));
 
         gets(text);
         for (j = 0; j < strlen(text); ++j)
         {
             if (text[j] == w[0])
                 d[j][0] = 1;
             for (k = 1; k < 19; ++k)
                 if (text[j] == w[k])
                 {
                     for (l = 0; l < j; ++l)
                         d[j][k] = (d[j][k] + d[l][k - 1]) % 10000;
                 }
                 else
                     d[j][k] = 0;
         }
         for (sol = j = 0; j < strlen(text); ++j)
         {
             sol += d[j][18];
             sol %= 10000;
         }
         printf("Case #%d: %0.4d\n", i, sol);
     }
     return 0;
 }

