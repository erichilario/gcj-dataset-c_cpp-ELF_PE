#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 char ** s;
 char x[1000];
 
 int main()
 {
   int l,d,n,i,a,j,b,e,m,o;
   char * z;
   scanf("%d %d %d\n",&l,&d,&n);
   s=(char**)malloc(d*sizeof(char*));
   for (i=0;i<d;++i)
   {
     s[i]=(char*)malloc((l+1)*sizeof(char));
     scanf("%s",s[i]);
   }
   for (i=0;i<n;++i)
   {
     a=d;
     scanf("%s",x);
     b=0;
     for (j=0;j<l;++j)
     {
       if (x[b]==0) break;
       if (x[b]=='(') {
         ++b;
         e=b;
         while (x[e]!=')') ++e;
         --e;
       } else
       {
         e=b;
       }
       for (m=0;m<a;++m)
       {
         for (o=b;o<=e;++o) if (x[o]==s[m][j]) break;
         if (o>e)
         {
           --a;
           z=s[m];
           s[m]=s[a];
           s[a]=z;
           --m;
         }
       }
       b=e+1;
       if (x[b]==')') ++b;
     }
     if (j<l) a=0;
     printf("Case #%d: %d\n",i+1,a);
   }
   for (i=0;i<d;++i) free(s[i]);
   free(s); 
   return 0;
 }

