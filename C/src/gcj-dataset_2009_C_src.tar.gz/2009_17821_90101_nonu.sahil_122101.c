#include<stdio.h>
 #include<conio.h>
 #include<malloc.h>
 #include<string.h>
 char *str;
 int *temp;
 int len=0,count=0;
 void find_count(int ,int );
 char *cdm="welcome to code jam";
 int main()
 {
           int n,i,k;
           FILE *fp,*fp2;
           char ch;
           
           temp=(int*)calloc(19,sizeof(int));
           str=(char*)malloc(sizeof(char)*500);
           fp=fopen("C-small-attempt0.in","r");
           fp2=fopen("output.txt","w");
           fscanf(fp,"%d",&n);
           fgetc(fp);
           for(i=0;i<n;i++)
           {
                           
                           str[len]=(char)fgetc(fp);
                           while(str[len]!='\n')
                           {
                                              
                                                len++;
                                                str[len]=fgetc(fp);
                           }
                           find_count(0,0);
                           fprintf(fp2,"Case #%d: ",i+1);
                           if(count/1000>0)
                           {
                                           
                                           fprintf(fp2,"%d\n",count);
                                           }
                           else
                           if(count/100>0)
                           {
                                          fprintf(fp2,"0%d\n",count);
                                          }
                           else
                           if(count/10>0)
                           {
                                         fprintf(fp2,"00%d\n",count);
                                         }
                           else
                           {
                               fprintf(fp2,"000%d\n",count);
                           }
                           len=0;
                           count=0;
                           
           }
           return 0;
           
 }
 void find_count(int id,int j)
 {
                     int flag=0,z;
                     if(id==19)
                     {
                               if(count==9999)
                               {
                                              count=0;
                               }
                               else
                               count++;
                               return;
                     }
                     if(id==18)
                     {
                               z=0;
                               }
                     while(1)
                     {
                                      flag=0;
                                      while(1)
                                      {
                                                       
                                                       if(str[j]==cdm[id])
                                                       {
                                                                         
                                                                         temp[id]=j;
                                                                          flag=1;
                                                                          break;
                                                       }
                                                       j++;
                                                       if(j>=len)
                                                       {
                                                                break;
                                                       }
                                                       
                                      }
                                      if(flag==1)
                                      {
                                               find_count(id+1,j+1);
                                               j++;
                                      }
                                      else
                                      {
                                          break;
                                      }
                                      
                  }
 }

