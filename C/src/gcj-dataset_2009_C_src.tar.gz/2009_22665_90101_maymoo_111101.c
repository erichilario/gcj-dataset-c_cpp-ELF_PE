#include <stdio.h>
 
 #define LIMIT 10
 #define NMAX 10
 int n, m, H[NMAX][NMAX], N; 
 char L[NMAX][NMAX], l;
 
 char conquer(int i, int j)
 {
      int hmin, dir;
      char let;
      
      hmin = LIMIT;
      
      if (i-1 >= 0 && H[i-1][j] < hmin)
      { 
         hmin = H[i-1][j];
         dir = 0;
         let = L[i-1][j];
      }
      if (j-1 >= 0 && H[i][j-1] < hmin)
      {
         hmin = H[i][j-1];
         dir = 1;
         let = L[i][j-1];
      }
      
      if (j+1 < m && H[i][j+1] < hmin)
      {
         hmin = H[i][j+1];
         dir = 2;
         let = L[i][j+1];
      }
      
      if (i+1 < n && H[i+1][j] < hmin)
      {
         hmin = H[i+1][j];
         dir = 3;
         let = L[i+1][j];
      }
      
      if (hmin < H[i][j])
         if (let != '0')
            return let;
         else
             switch (dir)
             {
                    case 0: return L[i][j] = conquer(i-1, j); break;
                    case 1: return L[i][j] = conquer(i, j-1); break;
                    case 2: return L[i][j] = conquer(i, j+1); break;
                    case 3: return L[i][j] = conquer(i+1, j); break;
             }
      else
      {
          if (L[i][j] == '0')
             L[i][j] = l;
          l++;
          return l-1;
      }
 }
 
 int main()
 {
     int i, j, h, test;
     
     freopen("b.in", "rt", stdin);
     freopen("b.out", "wt", stdout);
     scanf("%d", &N);
     for (test = 1; test <= N; test++)
     {
           scanf("%d %d", &n, &m);
           for (i = 0; i < n; i++)
               for (j = 0; j < m; j++)
               {
                   scanf("%d", &H[i][j]);
                   L[i][j] = '0';
               }
               
           l = 'a';    
           //for (h = LIMIT-1; h >= 0; h--)
               for (i = 0; i < n; i++)
                   for (j = 0; j < m; j++)
                       if (L[i][j] == '0')
                          L[i][j] = conquer(i, j);
           
           printf("Case #%d:\n", test);               
           for (i = 0; i < n; i++)
           {
               for (j = 0; j < m; j++)
                     printf("%c ", L[i][j]);
               printf("\n");
           }     
     }
     return 0;
 }

