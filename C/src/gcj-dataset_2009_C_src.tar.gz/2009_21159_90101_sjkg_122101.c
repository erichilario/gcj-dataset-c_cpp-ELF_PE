#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 int my_strstr(char findString[], int whichLetter, char testString[]);
 int  main(void) {
    FILE *fp;
    fp = fopen("input.txt", "r");
    int numCases;
    int result = 0;  
       int tmp=0;
    tmp = fscanf(fp, "%d", &numCases);
 
    char testString[1000];
    int caseNumber = 1;
    int ignoreFirst = 1;
     
 
       while(fgets(testString, 1000, fp)!=NULL) { 
          
          if (ignoreFirst >0) {
             ignoreFirst--;
          } else {
          
             testString[strlen(testString)-1] = '\0';
             char findString[] = "welcome to code jam";
             
             result = my_strstr(findString, 0, testString);
             result = result % 10000;
             printf("Case #%d: %04d\n", caseNumber, result);  
             caseNumber ++;
 
          }
 
       }
    
 
    return 0;
 }
 int my_strstr(char findString[], int whichLetter, char testString[]) {
 
    
    int total = 0;
    
    if (whichLetter == 18) {
    if(strlen(testString)>1) {
    
          testString++;
    } else {
       return 0;
    }
       
       if ((testString = strchr(testString,findString[whichLetter])) == NULL) {
          
          return 0;
       } else {
          
          return my_strstr(findString, whichLetter, testString) + 1;
       }
    } else {
       
      
       
       while(testString != NULL && (testString = strchr(testString,findString[whichLetter])) != NULL) {   
          
          total= total+ my_strstr(findString, whichLetter+1, testString);
          if(strlen(testString)>1) {
             testString++;
          } else {
             testString = NULL;
          }
          
       }
       
    }
    return total;
 }   
 

