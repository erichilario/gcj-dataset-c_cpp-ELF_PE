// GCJ Qualifications 2009, Problem C
 // Lucas Garron
 
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 //Possible improvements:
 // - start search at pointer for first 'w'
 // - Parse through the string and take out any characters not in jamstr
 
 #define MAX_LINE_LENGTH 512
 #define ANSWER_MOD 1000
 
 int jams_at_all(char* str, char* jamstr)
 {
   int ct1=strlen(jamstr)-1;
   int ct2=strlen(str)-1;
 
   while(ct1>=0)
   {
     while(str[ct2]!=jamstr[ct1])
     {
 //printf(" %c\n", str[ct2]);
     if(ct2<0)
       return 0;
     --ct2;
     }
  // printf("%c %c: %d %d\n", jamstr[ct1], str[ct2], ct2, ct1);
   --ct1;
   }
   return 1;
 }
 
 int count_jams(char* str, char* jamstr)
 {
   if(!jams_at_all(str, jamstr))
   {
     printf("-");
     return 0;
   }
 
   int count_mod, i, len=strlen(str), j, jlen=strlen(jamstr), k;
   int counters_prev[MAX_LINE_LENGTH], counters[MAX_LINE_LENGTH];
 
   for(i=0; i<len; ++i)
   {
     if(str[i]==jamstr[0])
       counters[i]=1;
     else
       counters[i]=0;
   }
 
   for(j=1; j<jlen; ++j)
   {
     for(i=0; i<len; ++i)
     {
       counters_prev[i] = counters[i];
       counters[i] = 0;
     }
     for(i=0; i<len; ++i)
     {
       if(str[i]==jamstr[j])
       for(k=0; k<i; ++k)
         counters[i] = ((counters[i] + counters_prev[k]) % ANSWER_MOD);
       printf("%d ", counters[i]);
     }
     printf("\n");
 
   }
   
   count_mod=0;
   for(i=0; i<len; ++i)
   {
     count_mod = ((count_mod + counters[i]) % ANSWER_MOD);
   }
   //printf("%s_%d_\n", str, jams_at_all(str, jamstr));
 
   return count_mod;
 }
 
 int main(int argc, char** argv)
 {
   char* jamstr="welcome to code jam";
 
   printf("\nBeginning %s\n", argv[1]);
 
   FILE *file;
   FILE *fileout;
   int num_lines;
   char buffer[MAX_LINE_LENGTH];
   int count_mod;
 
   file = fopen(argv[1], "r");
   fileout = fopen(argv[2], "w");
   if (file == NULL || fileout == NULL) {
     printf("Couldn't open file %s\n", argv[1]);
     return -1;
   }
 
   fscanf(file, "%d\n", &num_lines);
   printf("%d lines.\n", num_lines);
   
   int line;
   for(line = 0; line < num_lines; ++line)
   {
     fgets(buffer, MAX_LINE_LENGTH, file);
     buffer[strlen(buffer)-1] = '\0'; //Remove \n
     //skip to initial w WHEN PASSING ONLY?
     count_mod = count_jams(buffer, jamstr);
     printf("#%d (%c...): %d\n", line+1, buffer[1], count_mod);
     fprintf(fileout, "Case #%d: %04d\n", line+1, count_mod);
   }
 
 //  while (fscanf(file, "%s", buffer) == 1)
 //  printf()
 
   return 0;
 }
