#include <stdio.h>
 
 int map[100][100];
 int basins[100][100];
 int H = 0;
 int W = 0;
 
 int T = 0;
 char next_color = 'a';
 
 int next_cell(int i, int j, int *ni, int *nj) {
   int n, s, w, e;
   int min;
   n = s = e = w = 100000;
 
   if(i > 0) n = map[i-1][j];
   if(i < H-1) s = map[i+1][j];
   if(j > 0) w = map[i][j-1];
   if(j < W-1) e = map[i][j+1];
 
   *ni = i -1;
   *nj = j;
   min = n;
 
   if(w < min) {
     *ni = i;
     *nj = j-1;
     min = w;
   }
 
   if(e < min) {
     *ni = i;
     *nj = j+1;
     min = e;
   }
 
   if(s < min) {
     *ni = i+1;
     *nj = j;
     min = s;
   }
 
   if(min < map[i][j])
     return 1;
   else {
     *ni = i;
     *nj = j;
     return 0;
   }
 }
 
 int main() {
   scanf("%d", &T);
   for(int t=1; t<=T; ++t) {
     scanf("%d %d", &H, &W);
     for(int i=0; i<H; ++i) {
       for(int j=0; j<W; ++j) {
         basins[i][j] = 'N';
         scanf("%d", &(map[i][j]));
       }
     }
 
     next_color = 'a';
 
     for(int i=0; i<H; ++i) {
       for(int j=0; j<W; ++j) {
         if(i == 0 && j == 0) { // the beginning
           int ni = i, nj = j;
           basins[0][0] = 'a';
           while(next_cell(ni, nj, &ni, &nj))
             basins[ni][nj] = 'a';
           continue;
         } else {
           if(basins[i][j] != 'N')
             continue;
 
           int ni = i, nj = j;
           while(next_cell(ni, nj, &ni, &nj)) {
             if(basins[ni][nj] != 'N')
               break;
           }
           if(basins[ni][nj] == 'N') {
             next_color++;
             basins[i][j] = next_color;
             ni = i; nj = j;
             while(next_cell(ni, nj, &ni, &nj))
               basins[ni][nj] = next_color;
           } else {
             char color = basins[ni][nj];
             basins[i][j] = color;
             ni = i; nj = j;
             while(next_cell(ni, nj, &ni, &nj)) {
               if(basins[ni][nj] != 'N') break;
               basins[ni][nj] = color;
             }
           }
         }
       }
     }
 
     printf("Case #%d:\n", t);
     for(int i=0; i<H; ++i) {
       for(int j=0; j<W; ++j) {
         printf("%c ", basins[i][j]);
       }
       printf("\n");
     }
   }
 
   return 0;
 }

