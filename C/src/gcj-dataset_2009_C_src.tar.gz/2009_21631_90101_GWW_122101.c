#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 char *s = "welcome to code jam";
 char b[550];
 int l,sl;
 
 int go(int start,int p){
 	int i;
 	int c;
 	c=0;
 	for(i = start; i<l; i++){
 		if(b[i] == s[p]){
 			if(p==(sl-1)){
 				c++;
 				if(c>100000){
 					c = c % 10000;
 				}
 			}else{				
 				c = c + go(i+1,p+1);
 			}
 		}
 	}
 	return c;
 }
 
 int main(){
 	FILE *fp;
 	int i,n,c;
 	sl = strlen(s);
 	fp = fopen("./data.txt","r");
 	fgets(b,500,fp);
 	printf("%s\n",b);
 	n = atoi(b);
 	c = 0;
 	for(i=0;i<n;i++){
 		fgets(b,500,fp);
 		l = strlen(b);
 		c = go(0,0);
 		c = c %10000;
 		printf("Case #%d: %04d\n",(i+1),c);
 	}
 }

