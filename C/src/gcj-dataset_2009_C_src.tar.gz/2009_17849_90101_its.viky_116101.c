#include<stdio.h>
 #include<string.h>
 #include<sys/types.h>
 #include<stdlib.h>
 #include<unistd.h>
 int checkcase(char *,char *);
 int main()
 {
 	FILE *fd;
 	int l,d,n,i,j,count=0;
 	char buf[5000][15];
 	char cbuf[500];
 	fd=fopen("test.txt","r");
 	fscanf(fd,"%d %d %d",&l,&d,&n);
 	for(i=0;i<d;i++)
 	{	fscanf(fd,"%s",buf[i]);
 	}
 	for(j=0;j<n;j++)
 	{	fscanf(fd,"%s",cbuf);
 		for(i=0;i<d;i++)
 			count=count+checkcase(cbuf,buf[i]);
 		bzero(cbuf,500);
 		printf("Case #%d: %d\n",j+1,count);
 		count=0;
 	}		
 }
 int checkcase(char tock[500],char wchk[15])
 {
 	int a=0;
 	char Tchk[15][15]={0};
 	char c,i,j,k,flag=0,tflag=0;
 	for(i=0,j=0,k=0;tock[k]!='\0';k++)
 	{	
 		c=tock[k];
 		if(c=='(')
 		{
 			flag=1;
 			continue;
 		}
 		if(c==')')
 		{
 			j=0,flag=0,++i;
 			continue;
 		}
 		else
 		{
 			if(flag==1)
 				Tchk[i][j++]=c;
 			else
 				Tchk[i++][j]=c;
 		}
 	}
 	//printf(" %s ,%s, %s, %s\n",wchk,Tchk[0],Tchk[1],Tchk[2],Tchk[4]);
 	
 	for(i=0;wchk[i]!=0;i++)
 	{
 		if(strchr(Tchk[i],wchk[i])==NULL)
 		{	tflag=0;
 			break;
 		}
 		else		
 			tflag=1;		
 		
 	}
 	if(tflag==1)
 		return 1;
 	else
 		return 0;
 }

