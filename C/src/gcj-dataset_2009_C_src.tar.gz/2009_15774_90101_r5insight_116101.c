#include <stdio.h>
 
 int l, d, n;
 
 int have[15][26];
 char word[5000][16];
 char q[1000];
 
 int main(){
 	int i,j,k,ans,pos;
 	scanf("%d%d%d",&l,&d,&n);
 	for(i=0;i<d;i++)
 		scanf("%s",word[i]);
 	for(i=0;i<n;i++){
 		for(j=0;j<15;j++)
 			for(k=0;k<26;k++)
 				have[j][k]=0;
 		scanf("%s",q);
 		pos=0;ans=0;
 		for(j=0;j<l;j++){
 			if(q[pos]=='('){
 				for(++pos;q[pos]!=')';++pos){
 					have[j][q[pos]-'a']=1;
 				}
 				++pos;
 			}else
 				have[j][q[pos++]-'a']=1;
 		}
 		for(j=0;j<d;j++){
 			for(k=0;k<l;k++)
 				if(!have[k][word[j][k]-'a']) break;
 			if(k==l)ans++;
 		}
 		printf("Case #%d: %d\n",i+1,ans);
 	}
 }

