#include <string.h>
 #include <stdio.h>
 #include <stdlib.h>
 #define MAX_LEN 600
 char** map;
 int row, col, m;
 
 char getValue(int y, int x){
   if (map[y][x] == 0){
     map[y][x] = 'a' + m;
     m++;
     return map[y][x];
   }
   if (map[y][x] == 1){
     map[y][x] = getValue(y-1, x);
     return map[y][x];
   }
   if (map[y][x] == 2){
     map[y][x] = getValue(y, x-1);
     return map[y][x];
   }
   if (map[y][x] == 3){
     map[y][x] = getValue(y, x+1);
     return map[y][x];
   }
   if (map[y][x] == 4){
     map[y][x] = getValue(y+1, x);
     return map[y][x];
   }
   return map[y][x];
 }
 
 int main(int argc, char**argv){
   char * filename = argv[1];
   FILE * data = fopen(filename, "r");
   char * str_buf = (char *) malloc((MAX_LEN + 1) * sizeof(char));
   int n, i, j, k, current, value;
   fgets(str_buf, MAX_LEN, data);
   n = atoi(str_buf);
   for (i=0; i<n; i++){
     printf("Case #%i:\n", i+1);
     fgets(str_buf, MAX_LEN, data);
     row = atoi(strtok(str_buf, " "));
     col = atoi(strtok(NULL, " "));
     int region[row][col];
     map = (char**) malloc(row * sizeof(char*));
     for(j=0; j<row; j++){
       map[j] = (char*)malloc(col * sizeof(char));
     }
     for (j = 0; j< row; j++){
       fgets(str_buf, MAX_LEN, data);
       region[j][0] = atoi(strtok(str_buf, " "));
       for (k = 1; k<col; k++){
 	region[j][k] = atoi(strtok(NULL, " "));
       }
     }
     m = 0;
     for (j=0; j<row; j++){
       for(k=0; k<col; k++){
 	current = region[j][k];
 	map[j][k] = 0;
 	if (j>0 && region[j-1][k] < current){
 	  current = region[j-1][k];
 	  map[j][k] = 1;
 	}
 	if (k>0 && region[j][k-1] < current){
 	  current = region[j][k-1];
 	  map[j][k] = 2;
 	}
 	if (k<(col-1) && region[j][k+1] < current){
 	  current = region[j][k+1];
 	  map[j][k] = 3;
 	}
 	if (j<(row-1) && region[j+1][k] < current){
 	  map[j][k] = 4;
 	}
       }
     }
     for (j=0; j<row; j++){
       for(k=0; k<col; k++){
 	printf("%c ", getValue(j, k));
       }
       printf("\n");
     }
     for(j=0; j<row; j++){
       free(map[j]);
     }
     free(map);
   }
   free(str_buf);
   return 0;
 }

