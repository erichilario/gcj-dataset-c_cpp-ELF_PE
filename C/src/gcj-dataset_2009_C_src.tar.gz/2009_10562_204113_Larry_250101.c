#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 int m[45][3];
 
 double go2( int a, int b ) {
   return sqrt( ( m[a][0] - m[b][0] ) *
 	     ( m[a][0] - m[b][0] ) +
 	     ( m[a][1] - m[b][1] ) *
 	     ( m[a][1] - m[b][1] ) ) +
     m[a][2] + m[b][2];
 }
 
 double go( int a, int b, int c ) {
   double d1, d2;
 
   d1 = go2( a, b ) / 2.0;
   d2 = m[c][2];
 
   if ( d1 > d2 ) return d1;
   return d2;
 }
 
 int main(){
   int C, N, i, j, ca;
   double dist, d;
 
   scanf("%d\n", &C );
   for ( ca = 1; ca <= C; ca++ ) {
     scanf("%d\n", &N );
 
     for ( i = 0; i < N; i++ ) {
       scanf("%d %d %d\n", &m[i][0], &m[i][1], &m[i][2] );
     }
 
     if ( N == 1 ) {
       dist = m[0][2];
     }
     else if ( N == 2 ) {
       dist = go2( 0, 1 ) / 2.0;
 
       d = m[0][2];
       if ( m[1][2] > d ) d = m[1][2];
       if ( dist > d ) dist = d;
     }
     else if ( N == 3 ) {
       dist = go( 0, 1, 2 );
       d = go( 0, 2, 1 );
       if ( dist > d ) dist = d;
       d = go( 1, 2, 0 );
       if ( dist > d ) dist = d;
 
     }
     printf("Case #%d: %.6lf\n", ca, dist );
   }
 
   return 0;
 }

