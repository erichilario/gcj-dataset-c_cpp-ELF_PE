#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<assert.h>
 int compute(FILE* fin);
 
 char wel[]={'w','e','l','c','o','m','e',' ','t','o',' ','c','o','d','e',' ','j','a','m'};
 
 int main(int c,char* argv[]){
 
 FILE* fin=fopen(argv[1],"r");
 FILE* fout=fopen(argv[2],"w");
 
 if(!fin || !fout){
 printf("unable to open files \n");
 return 0;
 }
 int cases;
 fscanf(fin,"%d\n",&cases);
 int this_case=1;
 int val;
 for(this_case;this_case<=cases;this_case++){
 val=compute(fin);
 fprintf(fout,"Case #%d: %04d\n",this_case,val);
 }
 
 return 0;
 }
 #define MAX_LEN 502
 #define SIZE 60
 int compute(FILE* fin){
 
 char buf[MAX_LEN];
 int len;
 fgets(buf,MAX_LEN,fin);
 len=strlen(buf);
  if(buf[len-1]=='\n')
       buf[len-1]='\0';
 //printf("string s= %s\n",buf);
 int count[19]={0,};
 int indexs[19]={0,};
 len=strlen(buf);
 //printf("strlen = %d  str[len]=%c",len,buf[len]);
 int i=0;
 int j=0;
 int wloc;
 for(j=0;j<len;j++){
 //printf(" wel[i]=%c  buf[j]=%c \n",wel[i],buf[j]);
 	if(wel[i]==buf[j]){ //we got a character of welcome to code jam
 		
 		indexs[i]=j;
 			if(i==0)
 			wloc=j;//location of first w
 		i++;
 	//	printf("c= %c\n",buf[j]);
 		if(i==19)//total string fround
 			break;
 	}
 //printf(" wel[i]=%c  buf[j]=%c \n",wel[i],buf[j]);
 }
 //printf("\n well \n");
 i--;
 if(buf[j]!=wel[i])return 0;
 int short_loc=j;
 i=0;
 //int loc1=wloc;
 /*int prev_let_last_loc=wloc;
 for(i=0;i<19;i++){
 for(j=prev_let_last_loc;j<=short_loc;j++){
 		if(wel[i]==buf[j])
 		count[i]++;
 		else if(count[i] && buf[j]==wel[i+1])break; //at least one instance of the letter should be present
 }
 prev_let_last_loc=j;
 }*/
 int* loc[19];
 int* val[19];
 
 
 for(i=0;i<19;i++){
 loc[i]=calloc(sizeof(int),SIZE);
 val[i]=calloc(sizeof(int),SIZE);
 }
 
 int x=0,y=0;
 
 
 
 int flag;
 int next_let_last_loc=len;
 for(i=18;i>=0;i--){
 	flag=1;
 	x=y=0;
 	for(j=(next_let_last_loc-1);j>=indexs[i];j--){
 		if(wel[i]==buf[j]){
 		if(flag){
 			next_let_last_loc=j;
 			flag=0;
 			}
 		if(i==18){
 			loc[i][x++]=j;
 			val[i][y++]=1;
 			}
 		else {
 			int n=0;
 			long long sum=0;
 			while(loc[i+1][n]>j)
 				sum+=val[i+1][n++];
 			assert(j==0||loc[i+1][n]<j);
 			loc[i][x++]=j;
 			val[i][y++]=sum;
 			}
 			
 				
 			
 	
 		//count[i]++;
 		}
 	}
 }
 long long  sum[19]={0,};
 for(i=0;i<19;i++){
 	for(j=0;;j++){
 		if(val[i][j]<=0)break;
 		//printf("val[%d][%d]=%d\n",i,j,val[i][j]);
 		sum[i]+=val[i][j];
 	}
 printf("sum= %ld \n",sum[i]);
 }
 //sum[0]%=10000;
 
 for(i=0;i<19;i++)
 printf("count[%d]= %d \n",i,count[i]);
 /*
 //now multiply all leters of count to get the value;
 long mul1=1,mul2=1,mul3=1,mul4=1;
 for(i=0;i<19;i++){
 if(i<5)
 mul1*=count[i];
 if(i>=5&&i<10)
 mul2*=count[i];
 if(i>=10&&i<15)
 mul3*=count[i];
 if(i>=15)
 mul4*=count[i];
 }
 printf("mul1=%ld mul2=%ld mul3=%ld mul4=%ld\n",mul1,mul2,mul3,mul4);
 mul1=mul1%10000;
 mul2%=10000;
 mul3%=10000;
 mul4%=10000;
 
 long a1=(mul1*mul2)%10000;
 long a2=(mul3*mul4)%10000;
 
 long a3= (a1*a2)%10000;*/
 return (sum[0])%10000;
 }
 
 
 	
 		
 
 	
 
 
 

