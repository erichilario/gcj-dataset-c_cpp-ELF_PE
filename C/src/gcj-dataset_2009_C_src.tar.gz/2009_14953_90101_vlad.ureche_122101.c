#include <stdio.h>
 #include <string.h>
 #define SIZE 1000
 #define MAXLINES 101
 #define MODULO % 10000;
 
 /*
  * Vlad Ureche
  * Romania
  */
 
 int main() {
 
 	int lines=0;
 	int i, j;
 	const char infile[] = "input.txt";
 	const char outfile[] = "output.txt";
 	FILE *inf;
 	FILE *outf;
 	char line[SIZE];
 
 	inf = fopen ( infile, "r" );
 	if ( inf == NULL ) { perror(infile); return 1; }
 	outf = fopen ( outfile, "w" );
 	if ( outf == NULL ) { perror(outfile); return 1; }
 
 	if (fgets ( line, (SIZE-1), inf ) == NULL)
 		return 1; // file finished prematurely
 	else
 		sscanf(line, "%d", &lines);
 
 
 	for (i=0; i<lines; i++) {
 
 		if (fgets ( line, (SIZE-1), inf ) == NULL)
 			return 1; // file finished prematurely
 
 		long long words[19];
 		for (j=0; j<19; j++)
 			words[j]=0;
 
 		for (j=0; j<SIZE; j++) {
 
 			char c = line[j];
 
 			if (c==0) {
 				// Announce the result
 				fprintf(outf, "Case #%d: %04lld\n", i+1, words[18]);
 				break;
 			} else if (c=='w') {
 				words[0] = words[0] + 1 MODULO;
 			} else if (c=='e') {
 				words[ 1] = (words[ 0] + words[ 1]) MODULO;
 				words[ 6] = (words[ 5] + words[ 6]) MODULO;
 				words[14] = (words[13] + words[14]) MODULO;
 			} else if (c=='l') {
 				words[ 2] = (words[ 1] + words[ 2]) MODULO;
 			} else if (c=='c') {
 				words[ 3] = (words[ 2] + words[ 3]) MODULO;
 				words[11] = (words[10] + words[11]) MODULO;
 			} else if (c=='o') {
 				words[ 4] = (words[ 3] + words[ 4]) MODULO;
 				words[ 9] = (words[ 8] + words[ 9]) MODULO;
 				words[12] = (words[11] + words[12]) MODULO;
 			} else if (c=='m') {
 				words[ 5] = (words[ 4] + words[ 5]) MODULO;
 				words[18] = (words[17] + words[18]) MODULO;
 			} else if (c=='t') {
 				words[ 8] = (words[ 7] + words[ 8]) MODULO;
 			} else if (c=='d') {
 				words[13] = (words[12] + words[13]) MODULO;
 			} else if (c=='j') {
 				words[16] = (words[15] + words[16]) MODULO;
 			} else if (c=='a') {
 				words[17] = (words[16] + words[17]) MODULO;
 			} else if (c==' ') {
 				words[ 7] = (words[ 6] + words[ 7]) MODULO;
 				words[10] = (words[ 9] + words[10]) MODULO;
 				words[15] = (words[14] + words[15]) MODULO;
 			}
 		}
 	}
 
 	fclose ( inf );
 	fclose ( outf );
 
 	return 0;
 }

