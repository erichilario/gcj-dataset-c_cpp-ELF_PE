/*
 TASK: Alien Language
 LANG: C
 AUTHOR: PeaTT~
 */
 
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 typedef struct{
 	char a[20];
 }word;
 
 word w[5001];
 int mark[16][30];
 
 int sort(const void* a,const void* b){
 	word *p,*q;
 	p=(word *)a;
 	q=(word *)b;
 	return strcmp(p->a,q->a);
 }
 char b[200000000];
 int main(){
 	int l,d,n,i,o,p,j,k,count;
 	
 	scanf("%d %d %d",&l,&d,&n);
 	for(i=0;i<d;i++)
 		scanf("%s",w[i].a);
 	//qsort(w,d,sizeof(w[0]),sort);
 	//for(i=0;i<d;i++)
 	//	printf("%s\n",w[i].a);
 	for(i=0;i<n;i++){
 		scanf("%s",b);
 		o=strlen(b);
 		for(j=0;j<l;j++){
 			for(k=0;k<26;k++)
 				mark[j][k]=0;
 		}
 		for(j=0,p=0;j<l;j++){
 			if(b[p]=='('){
 				p++;
 				while(p<o&&b[p]!=')'){
 					mark[j][b[p]-'a']=1;
 					p++;
 				}
 				p++;
 			}
 			else{
 				mark[j][b[p]-'a']=1;
 				p++;
 			}
 		}
 		for(j=0,count=0;j<d;j++){
 			for(k=0;k<l&&mark[k][w[j].a[k]-'a'];k++);
 			if(k==l)	count++;
 		}
 		printf("Case #%d: %d\n",i+1,count);
 	}
 	return 0;
 }

