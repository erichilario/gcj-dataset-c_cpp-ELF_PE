/*
  * =====================================================================================
  *
  *       Filename:  alien.c
  *
  *    Description:  A program for Google Code Jam 2009 qualification round.
  *
  *        Version:  1.0
  *        Created:  09/03/2009 07:36:11 PM
  *       Revision:  none
  *       Compiler:  gcc
  *
  *         Author:  Bonn Yang (), 
  *        Company:  
  *
  * =====================================================================================
  */
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 #define MAX_L 10
 #define MAX_D 25
 #define MAX_N 10
 #define LETTERS 26
 
 char *ifname="A-small.in";
 char *ofname="A-small.out";
 char dic[MAX_D][MAX_L+1]={'\0'};	// Dictionary
 char test[MAX_N][LETTERS*MAX_L+2*MAX_L+1]={'\0'};	// Test case
 char cur_case[LETTERS*MAX_L+2*MAX_L+1]={'\0'};
 char cur_test[MAX_L][LETTERS+1]={'\0'};	// Current test case
 
 int L,D,N;
 int case_no=0;	// Record the number of cases
 int match_no=0;	// Number of matched cases
 int lenofacase=LETTERS*MAX_L+2*MAX_L+1;
 
 // Process a test group
 void proc_a_testgrp(FILE *ofp)
 {
 	int itest,idic,iword,j,k,l;
 	int anchor,brace_no,letter_no;
 	char *pch,*pword;
 			
 	for(itest=0;itest<N;itest++)
 	{
 		for(j=0;j<MAX_L;j++)
 			memset(cur_test[j],'\0',LETTERS+1);
 		memset(cur_case,'\0',lenofacase);
 
 		match_no=0;
 		case_no++;
 
 		strcpy(cur_case,test[itest]);
 		printf("cur_case=%s\n",cur_case);	// TEST ONLY //
 		printf("%d:Begin spliting test case...\n",itest);
 		if(strchr(cur_case,')') != NULL){ // There is "()" in cur test case
 			// Split the test case
 			// Consider such a string:
 			// 	ab(cd)efg(hij)kl
 			k=0;iword=0;
 			while(k<lenofacase && cur_case[k]!='\0' && iword<L)
 			{
 				// Handling the letters before '('
 				printf("\n%d:Handling the letters before \'(\'... k=%d iword=%d\n",itest,k,iword);
 				while(k<lenofacase && cur_case[k]!='(')
 				{
 					printf("%c",cur_case[k]);
 					cur_test[iword][0]=cur_case[k];
 					cur_test[iword][1]='\0';
 					k++;iword++;
 				}
 				// Handling letters between '(' and ')'
 				printf("\n%d:Handling the letters between \'(\' and \')\'... k=%d\n",itest,k);
 				k++; // Skip '('
 				l=0;
 				while(k<lenofacase && cur_case[k]!=')')
 				{
 					printf("%c",cur_case[k]);
 					cur_test[iword][l++]=cur_case[k];
 					k++;
 				}
 				cur_test[iword][l]='\0';
 				k++; // Skip ')'
 				iword++;
 			}
 
 			printf("Hello, TEST ONLY! k=%d\n",k);
  	 		j=0;	// TEST ONLY //
 			printf("test[%d]=%s\n",itest,test[itest]);	// TEST ONLY //
 			while(j<MAX_L && cur_test[j][0]!='\0')
 			{
 				printf("\n%s ",cur_test[j++]);	// TEST ONLY //
 			}
 			printf("\n");	// TEST ONLY //
 
 			// Match every letter of a word in a dictionary from a test case
 			for(idic=0;idic<D;idic++)
 			{
 				printf("Handling outer\n");
 				pword=dic[idic];
 				anchor=0;
 				for(iword=0;iword<LETTERS+1;++iword)
 				{
 					printf("Handling inner\n");
 					if(cur_test[iword][0]=='\0')
 					{
 						break;
 					}
 					if(strchr(cur_test[iword],pword[iword]) != NULL){
 						// The letter pword[iword] is in cur_test[anchor]
 						++anchor;
 					}else{
 						// The letter pword[iword] is not in cur_test[anchor]
 						break;
 					}
 				} // end of for(iword)
 				if(anchor==L)
 					match_no++;
 			} // end of for(idic)
 		}else{	// No "()" in this test case
 			for(idic=0;idic<MAX_D;++idic){
 				if(!strcmp(cur_case,dic[idic]))
 					match_no++;
 			}
 		}
 		printf("%d:Complete spliting test case...\n",itest);
 
 		// Print the result of current test case to output file
 		fprintf(ofp,"Case #%d: %d\n",case_no,match_no);
 	} // end of for
 }
 
 int main(void)
 {
     FILE *ifp, *ofp;
 	int i,j;
 
 	ifp=fopen(ifname,"r");
 	if(ifp==NULL)
 	{
 		printf("Failed to open %s!\n",ifname);
 		return EXIT_FAILURE;
 	}else{
 		printf("Successfully open %s!\n",ifname);
 	}
 	ofp=fopen(ofname,"w+");
 	if(ofp==NULL)
 	{
 		printf("Failed to open %s!\n",ofname);
 		return EXIT_FAILURE;
 	}else{
 		printf("Successfully open %s!\n",ofname);
 	}
 
 	while(!feof(ifp))
 	{
 		// Read the L,D,N
 		fscanf(ifp,"%d %d %d",&L,&D,&N);
 		printf("L=%d,D=%d,N=%d\n",L,D,N);
 		// Read the dictionary
 		for(i=0;i<D;i++)
 		{
 			fscanf(ifp,"%s",dic[i]);
 			printf("dic[%d]=%s\n",i,dic[i]);
 		}
 		// Read the test cases
 		for(i=0;i<N;i++)
 		{
 			fscanf(ifp,"%s",test[i]);
 			printf("test[%d]=%s\n",i,test[i]);
 		}
 		proc_a_testgrp(ofp);
 		L=0; D=0; N=0;	// zero the gloal vars
 	}
 
 	fclose(ifp);
 	fclose(ofp);
 	return EXIT_SUCCESS;
 }

