
 #include <stdio.h>
 #include <ctype.h>
 #include <stdarg.h>
 #include <stdlib.h>
 
 #define KCNULL -1
 #define ALPHABET "abcdefghijklmnopqrstuvwxyz"
 
 typedef struct {
 	int width;
 	int height;
 	int *data;
 } KCMap;
 
 typedef KCMap KCSinkMap;
 
 typedef struct{
 	int count;
 	int map[26];
 } KCBasinMap;
 
 KCMap KCMapCreate(int h, int w) {
 	KCMap m;
 	m.width = w;
 	m.height = h;
 	m.data = malloc(w * h * sizeof(int));
 	return m;
 }
 
 KCMap KCSinkMapCreate(int h, int w) {
 	KCMap m;
 	m.width = w;
 	m.height = h;
 	int i;
 	int count = w * h * sizeof(int);
 	m.data = malloc(count);
 	for (i = 0; i < count; ++i) {
 		m.data[i] = KCNULL;
 	}
 	return m;
 }
 
 int KCMapAltitudeAt(KCMap m, int x, int y) {
 	if (x < 0 || x >= m.width || y < 0 || y >= m.height)
 		return 20000;
 	return m.data[m.width * y + x];
 }
 
 int KCMapSetAltitudeAt(KCMap m, int x, int y, int alt) {
 	return m.data[m.width * y + x] = alt;
 }
 
 void KCMapPrint(KCMap m) {
 	printf("%d %d\n", m.height, m.width);
 	int x, y, alt;
 	for (y = 0; y < m.height; ++y) {
 		for (x = 0; x < m.width; ++x) {
 			alt = KCMapAltitudeAt(m, x, y);
 			if (alt == KCNULL) {
 				printf("N ");
 			} else {
 				printf("%d ", alt);
 			}
 		}
 		printf("\n");
 	}
 }
 
 void KCMapFree(KCMap m) {
 	free(m.data);
 }
 
 KCBasinMap KCSinkMapGenerateBasinMap(KCSinkMap sm) {
 	int x, y, sink, i;
 	i = 0;
 	KCBasinMap bm;
 	for (y = 0; y < sm.height; ++y) {
 		for (x = 0; x < sm.width; ++x) {
 			sink = KCMapAltitudeAt(sm, x, y);
 			if (i == 0 || bm.map[i - 1] != sink) {
 				bm.map[i] = sink;
 				i++;
 			}
 		}
 	}
 	bm.count = i;
 	return bm;
 }
 
 void KCSinkMapPrint(KCMap m, KCBasinMap bm) {
 	int x, y, sink, j;
 	for (y = 0; y < m.height; ++y) {
 		for (x = 0; x < m.width; ++x) {
 			sink = KCMapAltitudeAt(m, x, y);
 			for (j = 0; j < bm.count; ++j) {
 				if (bm.map[j] == sink) {
 					printf("%c ", ALPHABET[j]);
 					break;
 				}
 			}
 		}
 		printf("\n");
 	}
 }
 
 int KCSinkMapSetSinkAt(KCSinkMap sm, KCMap m, int x, int y) {
 	int here, north, west, east, south;
 	int dir_x, dir_y;
 	here = KCMapAltitudeAt(m, x, y);
 	north = KCMapAltitudeAt(m, x, y - 1);
 	west = KCMapAltitudeAt(m, x - 1, y);
 	east = KCMapAltitudeAt(m, x + 1, y);
 	south = KCMapAltitudeAt(m, x, y + 1);
 	if (here <= north && here <= west && here <= east && here <= south) {
 		int s = m.width * y + x;
 		KCMapSetAltitudeAt(sm, x, y, s);
 		return s;
 	} else if (north <= west && north <= east && north <= south) {
 		dir_x = x;
 		dir_y = y - 1;
 	} else if (west <= east && west <= south) {
 		dir_x = x - 1;
 		dir_y = y;
 	} else if (east <= south) {
 		dir_x = x + 1;
 		dir_y = y;
 	} else {
 		dir_x = x;
 		dir_y = y + 1;
 	}
 	int sink = KCMapAltitudeAt(sm, dir_x, dir_y);
 	if (sink == KCNULL) {
 		sink = KCSinkMapSetSinkAt(sm, m, dir_x, dir_y);
 	}
 	KCMapSetAltitudeAt(sm, x, y, sink);
 	return sink;
 }
 
 int main (int argc, char const *argv[])
 {
 	FILE * testFile;
 	testFile = fopen ("/Users/keishi/Documents/B-test.in","r");
 	int T, H, W, A;
 	int t_index, h_index, w_index;
 	char line[800];
 	fgets(line, 800, stdin);
 	sscanf(line, "%d", &T);
 	for (t_index = 0; t_index < T; ++t_index) {
 		fgets(line, 800, stdin);
 		sscanf(line, "%d %d", &H, &W);
 		KCMap map = KCMapCreate(H, W);
 		KCSinkMap sinkmap = KCSinkMapCreate(H, W);
 		for (h_index = 0; h_index < H; ++h_index) {
 			fgets(line, 800, stdin);
 			char *p = line;
 			for (w_index = 0; w_index < W; ++w_index) {
 				A = atoi(p);
 				KCMapSetAltitudeAt(map, w_index, h_index, A);
 				while(isdigit(p[0])) {
 					p++;
 				}
 				p++;
 			}
 		}
 		for (h_index = 0; h_index < H; ++h_index) {
 			for (w_index = 0; w_index < W; ++w_index) {
 				KCSinkMapSetSinkAt(sinkmap, map, w_index, h_index);
 			}
 		}
 		KCBasinMap basinmap = KCSinkMapGenerateBasinMap(sinkmap);
 		//KCMapPrint(sinkmap);
 		printf("Case #%d:\n", t_index + 1);
 		KCSinkMapPrint(sinkmap, basinmap);
 		//KCMapFree(map);
 		//KCMapFree(sinkmap);
 	}
 	
 	return 0;
 }
