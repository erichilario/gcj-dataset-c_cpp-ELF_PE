#include <string.h>
 #include <stdio.h>
 
 int stktop = 0;
 int stack[20000];
 
 void push(int d)
 {
     stack[stktop++] = d;
 }
 
 int pop()
 {
     if (stktop == 0)
         return -1;
     return stack[--stktop];
 }
 
 int calculate_line(char *line)
 {
     static char *wel = "welcome to code jam";
     int c = 0,i = 0;
     int sum = 0;
     for(;;) {
         while (line[i] != wel[c]) {
             i++;
             if (i >= strlen(line))
                 break;
         }
         if (i >= strlen(line)) {
             i = pop()+1;
             if (i == 0)
                 break;
             c--;
         } else {
             push(i);
             c++;
             if (c == strlen(wel)) {
                 sum++;
                 pop();
                 c--;
             }
             i++;
         }
     }
     return sum;
 }
 
 int main()
 {
     char l[20000];
     int n, i;
     scanf("%d", &n);
     getchar();
     for (i = 0; i<n; ++i) {
         stktop = 0;
         gets(l);
         printf("Case #%d: %0.4d\n", i+1, calculate_line(l));
     }
     return 0;
 }
 
 
 
 

