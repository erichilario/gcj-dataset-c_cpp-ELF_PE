#include <stdio.h>
 
 char s[3000];
 char d[]="welcome to code jam";
 int p[3000][30];
 
 int main()
 {
   int i,j,k=1;
   gets(s);
   while (1)
   {
     s[0]=1;
     gets(s);
     if (s[0]==1) break;
     for (i=0;i<30;++i) p[0][i]=0;
     p[0][0]=1;
     for (i=0;s[i];++i) 
     {
       p[i+1][0]=1;
       for (j=0;d[j];++j) 
       {
         if (d[j]==s[i])
         {
           p[i+1][j+1]=(p[i][j+1]+p[i+1][j])%10000;
         } else
         {
           p[i+1][j+1]=p[i][j+1];
         }
       }
     }
     printf("Case #%d: %04d\n",k++,p[i][j]);
   }
   return 0;
 }

