#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 #define L_LEN 16
 
 int num_d; //num words
 char ** words;//the dictonary
 
 int possible_words(int num_l,int * valid,int val_len,char** pattern,int pat_start);
 int compute(FILE* fin,int num_l);
 
 int main(int c,char* argv[]){
 
 FILE* fin=fopen(argv[1],"r");
 FILE* fout=fopen(argv[2],"w");
 
 if(!fin || !fout){
 printf("unable to open files \n");
 return 0;
 }
 int num_l;
 int num_case;
 fscanf(fin,"%d",&num_l);
 fscanf(fin,"%d",&num_d);
 fscanf(fin,"%d\n",&num_case);
 int this_case=1;
 int i=0;
 //create dictonary
 char buf[L_LEN];
 int len=0;
 words=malloc(num_d*sizeof(char*));
 for(i=0;i<num_d;i++){
 	fgets(buf,L_LEN,fin);
 	len=strlen(buf);
 	if(buf[len-1]=='\n')
 		buf[len-1]='\0';
 	words[i]=malloc(strlen(buf)+1);
 	strcpy(words[i],buf);
 }
 int val;
 for(this_case=1;this_case<=num_case;this_case++){
 	val=compute(fin,num_l);
 	fprintf(fout,"Case #%d: %d\n",this_case,val);
 }
 
 return 0;
 }
 	
 #define PATTERN_LEN 100
 int compute(FILE* fin,int num_l){
 //read the pattern from fin and use words array to find the possible number of pattern matches
 //
 
 char ** pattern=malloc(num_l*sizeof(char*));
 int i=0;
 for(i=0;i<num_l;i++)
 pattern[i]=malloc(PATTERN_LEN+1);
 int pattern_len=PATTERN_LEN;
 
 int c;
 int prev_c=')';
 int j=0;
 int in_para=0;
 for(i=0;((c=fgetc(fin))!='\n')&&(c!=EOF&& (i<num_l));((c!=' ')?prev_c=c:1) ){
 	if(c==' ')continue;
 //	printf("c=%c \n ",c);
 	if(c=='('){
 	
 		if(prev_c!=')'){
 			pattern[i][j]='\0';
 			i++;
 			j=0;
 			pattern_len=PATTERN_LEN;
 			
 		}
 		in_para=1;
 		continue;
 	}
 
 	if(c==')'){
 		 pattern[i][j]='\0';
 		 i++;
 		 j=0;
 		 in_para=0;
 		pattern_len=PATTERN_LEN;
 		 continue;
 		}
 	
 	if(!in_para&& j>0){
 		pattern[i][j]='\0';
 		i++;
 		j=0;
 		pattern_len=PATTERN_LEN;
 		}
 	if(j>=pattern_len)
 	pattern[i]=realloc(pattern[i],pattern_len*=2);
 	
 	pattern[i][j++]=c;
 //printf("c =%c \n",c);		
 }
 if(prev_c!=')')pattern[i][j]='\0';
 for(i=0;i<num_l;i++)
 printf(" %d == %s \n",i,pattern[i]);
 
 //do the processing for location zero
 int* valid=malloc(sizeof(int)*num_d);
 for(i=0;i<num_d;i++)
 valid[i]=1;//all dic locations are valid till now
 
 int val=possible_words(num_l,valid,num_d,pattern,0);
 
 return val;
 }
 int possible_words(int num_l,int * valid,int val_len,char** pattern,int pat_start){
 
 if(pat_start>=num_l || val_len==0){
 return val_len;
 }
 
 char* pat=pattern[pat_start];//the pattern i am concerned with
 int d_array_loc=pat_start;
 int i=0;
 int j=0;
 int sum=0;
 int* valid1=calloc(sizeof(int),num_d);
 int val_len1=0;
 int k=0;
 int pat_len=strlen(pat);
 for(i=0;i<pat_len;i++){
 	
 	val_len1=0;
 
 	for(j=0; j<num_d;j++){
 		if(valid[j]){
 			
 			if(words[j][d_array_loc]==pat[i]){
 				valid1[j]=1;
 				val_len1++;
 				}
 			
 
 
 		}
 	}
 	sum+=possible_words(num_l,valid1,val_len1,pattern,pat_start+1);
 	for(k=0;k<num_d;k++)
 		valid1[k]=0;
 }	
 
 return sum;
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

