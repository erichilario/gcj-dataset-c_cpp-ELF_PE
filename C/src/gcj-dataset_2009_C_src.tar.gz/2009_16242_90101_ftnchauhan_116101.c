#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 typedef struct
 {
 char ar[1000];
 }solv;
 typedef struct
 {
 char *as;
 }word1;
 typedef struct
 {
 char ad[1000];
 }cases1;
 word1 *word;
 int *case1;
 int solve(cases1,int,int,int);
 int main()
 {
 int l,d,n,i;
 cases1 *cases;
 scanf("%d%d%d",&l,&d,&n);
 word=(word1 *)malloc(d*sizeof(word1));
 for(i=0;i<d;++i)
 word[i].as=(char *)malloc(l*sizeof(char));
 
 for(i=0;i<d;++i)
 scanf("%s",word[i].as);
 cases=(cases1 *)malloc(n*sizeof(cases1));
 
 case1=(int *)malloc(n*sizeof(int));
 
 for(i=0;i<n;++i)
 {
 scanf("%s",cases[i].ad);
 case1[i]=solve(cases[i],l,d,n);
 }
 for(i=0;i<n;++i)
 printf("Case #%d: %d\n",i+1,case1[i]);
 return 0;
 }
 int solve(cases1 cases,int l,int d,int n)
 {
 int i,j,k,z=0,g=0,row,ct=0,flag=0;
 solv *sol;
 k=0;
 row=l;
 sol=(solv *)malloc(row*sizeof(solv));
 for(i=0;i<row;++i)
 {
 if(cases.ad[g]=='(')
 {
 n=0;
 while(cases.ad[++g]!=')')
 {
 sol[i].ar[n]=cases.ad[g];
 ++n;
 }
 sol[i].ar[n]='\0';
 ++g;
 }
 else
 {
 sol[i].ar[0]=cases.ad[g];
 sol[i].ar[n]='\0';
 ++g;
 }
 }
 
 for(i=0;i<d;++i)
 {
 for(k=0;k<l;++k)
 {
 flag=0;
 for(j=0;sol[k].ar[j];++j)
 {
 if(word[i].as[k]==sol[k].ar[j])
 {
 flag=1;
 break;
 }
 }
 if(flag==0)
 break;
 }
 if(k==l && flag==1)
 ++ct; 
 } 
 return ct;
 }
 
 
 
 
 
 
  

