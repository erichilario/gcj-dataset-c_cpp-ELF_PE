/*
  * Copyright © 2009 Jérémie Corbier <jeremie@famille-corbier.net>
  *
  * Permission is hereby granted, free of charge, to any person obtaining a copy
  * of this software and associated documentation files (the "Software"), to deal
  * in the Software without restriction, including without limitation the rights
  * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  * copies of the Software, and to permit persons to whom the Software is
  * furnished to do so, subject to the following conditions:
  *
  * The above copyright notice and this permission notice shall be included in
  * all copies or substantial portions of the Software.
  *
  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  * SOFTWARE.
  */
 
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 struct pattern_element
 {
     int size;
 
     union
     {
         char *characters;
         char character;
     } u;
 };
 
 static char **words = NULL;
 struct pattern_element **tests;
 
 static int append_test_case(long int index, long int L, char *buf)
 {
     long int elem_idx = 0;
 
     while(*buf && (*buf != '\n'))
     {
         if(*buf == '(')
         {
             char *end;
 
             buf++;
 
             end = strchr(buf, ')');
             if(end == NULL)
                 return -1;
 
             *end = '\0';
             tests[index][elem_idx].u.characters = strdup(buf);
             tests[index][elem_idx].size = strlen(buf);
 
             buf += tests[index][elem_idx].size;
         }
         else
         {
             tests[index][elem_idx].size = 1;
             tests[index][elem_idx].u.character = *buf;
         }
 
         elem_idx++;
         buf++;
     }
 
     if(elem_idx != L)
         return -1;
 
     return 0;
 }
 
 int main(int argc, char *argv[])
 {
     int ret = 1, i, j, k, l;
     char buf[BUFSIZ];
     long int cur_line = 0, L, D, N;
 
     /* Process input on stdin */
     while(1)
     {
         if(fgets(buf, BUFSIZ, stdin) == NULL)
             break;
         cur_line++;
 
         if(cur_line == 1)
         {
             char *nptr = buf, *endptr;
             L = strtol(nptr, &endptr, 0);
             nptr = endptr;
             D = strtol(nptr, &endptr, 0);
             nptr = endptr;
             N = strtol(nptr, &endptr, 0);
 
             if((L == 0) || (D == 0) || (N == 0))
                 goto end;
 
             /* Allocate words table */
             words = malloc(D * sizeof(char *));
             if(words == NULL)
                 goto end;
             for(i = 0; i < D; i ++)
             {
                 words[i] = malloc(L + 1);
                 if(words[i] == NULL)
                     goto end;
             }
 
             /* Allocate tests table */
             tests = malloc(N * sizeof(struct pattern_element *));
             if(tests == NULL)
                 goto end;
             for(i = 0; i < N; i++)
             {
                 tests[i] = malloc(L * sizeof(struct pattern_element));
                 if(tests[i] == NULL)
                     goto end;
             }
 
             continue;
         }
 
         if((cur_line > 1) && (cur_line < D + 2))
         {
             strncpy(words[cur_line - 2], buf, L);
             words[cur_line - 2][L] = '\0';
         }
 
         if((cur_line > D + 1) && (cur_line < D + 2 + N))
         {
             if(append_test_case(cur_line - D - 2, L, buf) == -1)
                 goto end;
         }
     }
 
     /* Run tests */
     for(i = 0; i < N; i++)
     {
         int match = 0;
 
         for(j = 0; j < D; j++)
         {
             int count = 0;
 
             for(k = 0; k < L; k++)
             {
                 if(tests[i][k].size == 1)
                 {
                     if(words[j][k] == tests[i][k].u.character)
                         count++;
                 }
                 else
                 {
                     for(l = 0; l < tests[i][k].size; l++)
                         if(words[j][k] == tests[i][k].u.characters[l])
                         {
                             count++;
                             break;
                         }
                 }
             }
 
             if(count == L)
                 match++;
         }
 
         printf("Case #%d: %d\n", i + 1, match);
     }
 
     ret = 0;
 
 end:
     if(words)
     {
         for(i = 0; i < D; i++)
             if(words[i])
                 free(words[i]);
         free(words);
     }
 
     if(tests)
     {
         for(i = 0; i < N; i++)
             if(tests[i])
             {
                 for(j = 0; j < L; j++)
                     if(tests[i][j].size > 1)
                         free(tests[i][j].u.characters);
                 free(tests[i]);
             }
     }
     free(tests);
 
     return ret;
 }

