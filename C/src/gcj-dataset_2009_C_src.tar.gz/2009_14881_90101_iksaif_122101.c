#include <stdlib.h>
 #include <stdio.h>
 #include <unistd.h>
 #include <string.h>
 #include <math.h>
 
 # define GNL_BUFFER_SIZE (1 << 10)
 
 typedef struct	s_gnl_buf
 {
   char		buf[GNL_BUFFER_SIZE];
   int		size;
   int		start;
   int		fd;
 }		t_gnl_buf;
 
 static int      copy_buf(char **pline, t_gnl_buf *buf, int readed)
 {
   int		i;
   char		*line;
 
   if (!buf->size)
     return (0);
   i = 0;
   *pline = realloc(*pline, readed + buf->size + 1);
   line = *pline + readed;
   while (i < buf->size)
     {
       line[i] = buf->buf[buf->start + i];
       if (line[i] == '\n')
 	{
 	  line[i] = '\0';
 	  buf->start = (buf->start + i + 1) % GNL_BUFFER_SIZE;
 	  buf->size = (buf->start ? buf->size - i - 1 : 0);
 	  return (1);
 	}
       i++;
     }
   buf->start = 0;
   buf->size = 0;
   return (0);
 }
 
 static int      check_old_buf(char **pline, t_gnl_buf *buf, size_t *readed)
 {
   int		tmp;
 
   tmp = buf->size;
   if (tmp)
     {
       if (copy_buf(pline, buf, *readed))
 	return (1);
       *readed = tmp;
     }
   return (0);
 }
 
 char		*get_next_line(t_gnl_buf *buf)
 {
   ssize_t	ret;
   size_t	readed;
   char		*line;
 
   line = NULL;
   readed = 0;
   if (check_old_buf(&line, buf, &readed))
     return (line);
   while ((ret = read(buf->fd, buf->buf, GNL_BUFFER_SIZE)) > 0)
     {
       buf->size = ret;
       if (copy_buf(&line, buf, readed))
 	return (line);
       readed += ret;
     }
   if (!ret && !readed)
     {
       free(line);
       return (NULL);
     }
   line[readed] = '\0';
   return (line);
 }
 
 const char *orig = "welcome to code jam";
 
 static int search(char *s, const char *p)
 {
   int i = 0;
 
   if (!*s)
     return 0;
   if (*s == *p) {
     int count = 0;
     if (!*(p + 1))
       return 1;
     while (*++s)
       count += search(s, p + 1);
     return count;
   }
   return 0;
 }
 
 static double count(char *s)
 {
   size_t len = strlen(s);
   double count = 0;
 
   for (int i = 0; i < len; ++i) {
     count += search(s + i, orig);
 
   }
   return count;
 }
 
 int main(void)
 {
   t_gnl_buf buf;
   int n = 0;
   int i = 0;
   char *s;
   double c = 0 ;
   int size;
 
   memset(&buf, 0, sizeof (buf));
   buf.fd = STDIN_FILENO;
 
   s = get_next_line(&buf);
   n = strtol(s, NULL, 0);
   while (i++ < n) {
     s = get_next_line(&buf);
     if (!s)
       break ;
     c = count(s);
     size = log(c) / log(10);
     if (size > 3)
       c = c / pow(10, size - 3);
     printf("Case #%d: %04d\n", i, (int)c);
     free(s);
   }
   return 0;
 }

