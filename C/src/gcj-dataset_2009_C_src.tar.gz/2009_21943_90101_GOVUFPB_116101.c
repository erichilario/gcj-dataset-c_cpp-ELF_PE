#include <stdio.h>
 
 int main( void )
 {
 	int l,d,n;
 	int i,j,k,m;
 	char tmp;
 	int index;
 	int acc;
 
 	scanf( "%d %d %d\n", &l, &d, &n );
 
 	char tab[d][l+5];
 	char marca[d];
 
 	char palavra[ 1025 ];
 	char pool[30];
 	int top_pool;
 
 	for(i=0; i<d; i++ )
 		scanf( "%s", tab[i] );
 
 	for(i=0; i<n; i++ )
 	{
 		scanf( "%s", palavra );
 		for(j=0; j<d; j++ )
 			marca[j] = 'S';
 
 		k=0;
 		index=0;
 
 		while( index < l )
 		{
 			top_pool = 0;
 
 			tmp=palavra[k++];
 			if( tmp != '(' ) pool[ top_pool++ ] = tmp;
 			else
 			{
 				tmp=palavra[k++];
 				while( tmp != ')' )
 				{
 					pool[ top_pool++ ] = tmp;
 					tmp=palavra[k++];
 				}
 			}
 
 			for( j=0; j<d; j++ )
 			if( marca[j] != 'X' )
 			{
 				marca[j] = 'X';
 				for( m=0; m<top_pool; m++ )
 					if( tab[j][index] == pool[m] ) marca[j] = 'S';
 			}
 
 			index++;
 		}
 
 		acc=0;
 		for( j=0; j<d; j++ )
 			if( marca[j] == 'S' ) acc++;
 
 		printf("Case #%d: %d\n",i+1, acc);
 
 	}
 
 
 
 	return 0;
 }
 
 
 
 
 
 
 
 
 
 
 

