#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 char	buffer[512];
 char	jam[] = "welcome to code jam";
 int	n;
 
 void
 count_occurences(char *pattern, char *str)
 {
   int	i;
 
   for (i = 0; str[i] != '\0'; i++)
     {
       if (*pattern == str[i])
 	{
 	  if (pattern[1] == '\0')
 	    ++n;
 	  count_occurences(pattern + 1, str + i + 1);
 	}
     }
 }
 
 int
 main(int ac, char **av)
 {
   char	*s;
   FILE	*fh;
   int	i, len;
 
   if (ac == 2)
     {
       fh = fopen(av[1], "r");
       if (fh != NULL)
 	{
 	  s = fgets(buffer, sizeof(buffer), fh);
 	  if (s != NULL)
 	    {
 	      len = atoi(s);
 	      for (i = 0; i < len; i++)
 		{
 		  s = fgets(buffer, sizeof(buffer), fh);
 		  n = 0;
 		  count_occurences(jam, s);
 		  printf("Case #%d: %04d\n", i + 1, n % 10000);
 		}
 	    }
 	  fclose(fh);
 	}
     }
   return (0);
 }

