#include <stdio.h>
 #include <string.h>
 #include <ctype.h>
 
 int main(){
     
     int l, d, n;
     char words[6000][30];
     char str[10000];
     char patt[100][100];
     int casno;
     int i, j;
     int pos, curr, ans, len, inflag;
     char ch;
 
     scanf("%d %d %d", &l, &d, &n);
     for (i = 0; i < d; i ++)
 	scanf("%s", words[i]);
 	
     for (casno = 1; casno <= n; casno ++){
 	scanf("%s", str);
 
 	len = strlen(str);
 	inflag = 0;
 	pos = 0;
 	curr = 0;
 
 	for (i = 0; i < len; i ++){
 	    ch = str[i];
 
 	    if (ch == '('){
 		inflag = 1;
 		curr = 0;
 	    }
 	    else if (ch == ')'){
 		inflag = 0;
 		patt[pos][curr] = '\0';
 		pos ++;
 		curr = 0;
 	    }
 	    else if (islower(ch)){
 		if (inflag){
 		    patt[pos][curr++] = ch;
 		}
 		else{
 		    patt[pos][0] = ch;
 		    patt[pos][1] = '\0';
 		    pos ++;
 		    curr = 0;
 		}
 	    }
 	    else{
 		printf("it's wrong\n");
 	    }
 	}
 
 	ans = 0;
 	for (i = 0; i < d; i ++){
 	    for (j = 0; j < l; j ++){
 		if (strchr(patt[j], words[i][j]) == NULL)
 		    break;
 	    }
 	    if (j >= l)
 		ans ++;
 	}
 	printf("Case #%d: %d\n", casno, ans);
     }
     return 0;
 }

