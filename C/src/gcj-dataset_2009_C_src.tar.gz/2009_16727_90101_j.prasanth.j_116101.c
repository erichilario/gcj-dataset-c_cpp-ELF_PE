#include <stdio.h>
 #include <stdlib.h>
 #include <unistd.h>
 #include <string.h>
 #include <assert.h>
 
 #define ALP_MAX 26
 #define L_MAX 15
 #define D_MAX 5000
 #define N_MAX 500
 
 #define GO_TO_NEXTLINE skip = fgetc(fp);\
                               while(skip != '\n')\
                               {\
                                   skip = fgetc(fp);\
                               }
 
 int ltrmat = 0;
 int mat = 0;
 int k,l;
 static int cmpstringp(const void *p1, const void *p2)
 {
 /* The actual arguments to this function are "pointers to
  * pointers to char", but strcmp(3) arguments are "pointers
  * to char", hence the following cast plus dereference */
    return strcmp(* (char * const *) p1, * (char * const *) p2);
 }
 
 
 struct everyletter_struct
 {
        char letter[L_MAX][ALP_MAX];
        int numletter[L_MAX];
        int nummat;
 }word[N_MAX];
  
 static int index_dict_start[ALP_MAX];
 static int index_dict_end[ALP_MAX];
 
 /* First let us sort all the words in the alien language and create an index */
 int main (int argc,char *argv[]) 
 {
 	FILE *fp = NULL;
 	int i = 0;
 	int j = 0;
 	int Lstrlen = 0;
 	int Dwords = 0;
         int Ntestcases = 0;	
 	char **dictionary = NULL;
 	char *testword = NULL;
 	char dummy[500];
 	char skip;
 	char ch;
 	char temp;
 	int testcasenumber = 1;
         int matpossible = 0;
         int nummates = 0;
 
 	/* Open the file and get L D and N */
 	fp = fopen(argv[1],"r");
 	j = 0;	
 	dummy[j] = fgetc(fp);
 	while(dummy[j] != ' ')
 	{
 	    j++;
 	    dummy[j] = fgetc(fp);
 	}
 	dummy[j] = '\0';
 	Lstrlen = atoi(dummy);	
 
         j = 0;
         dummy[j] = fgetc(fp);
         while(dummy[j] != ' ')
         {
             j++;
             dummy[j] = fgetc(fp);
         }
         dummy[j] = '\0';
 	Dwords = atoi(dummy);	
 
         j = 0;
         dummy[j] = fgetc(fp);
         while(dummy[j] != ' ' && dummy[j] != '\n')
         {
             j++;
             dummy[j] = fgetc(fp);
 	    skip = dummy[j];
         }
         dummy[j] = '\0';
         Ntestcases = atoi(dummy);
 
 	/* if at all the last read char was not a newline char then */
 	if (skip != '\n')
 	{
 		GO_TO_NEXTLINE;
 	}	
 #ifdef __DEBUG
 	printf("Lstrlen = %d, Dwords = %d, Ntestcases = %d\n",Lstrlen,Dwords,Ntestcases);
 #endif
 
 	/* First let us creat an array for holding all the alien words in their dictionary */
 	dictionary = (char **) malloc(sizeof(char *) * Dwords);   	
 	
 	for (i = 0 ; i < Dwords; i++)
 	{
 		dictionary[i] = (char *)malloc(sizeof(char) * (Lstrlen+1));
 		for (j = 0; j < Lstrlen; j++)
 		{
 			dictionary[i][j] = fgetc(fp);
 		}
 		dictionary[i][j] = '\0';
 		GO_TO_NEXTLINE;
 	}	
 	
 	/* Let us sort the dictionary */	
 	qsort(dictionary,Dwords,sizeof(char *),cmpstringp);
 	
 #ifdef __DEBUG
 	for (i = 0; i < Dwords; i++)
 	{
 		printf("%s\n",dictionary[i]);
 	}
 	fclose(fp);
 #endif
 
 	/* So let us create an index to our dictionary */
 
 #if __NEED_SORT
 	/* We need start and end */
 	for (ch = 'a'; ch <= 'z'; ch++)
 	{
             index_dict_start[(ch - 'a')] = -1;
             index_dict_end[(ch - 'a')] = -1;
 	    /* find first occurance of ch in dictionary */
 	    for (i = 0; i < Dwords; i++)
 	    {
                 if (dictionary[i][0] == ch)
                 {
                     index_dict_start[(ch - 'a')] = i;
                     break;
                 }
             }
 
             /* find the last occurance of ch in dictionary */
             if (index_dict_start[(ch - 'a')] != -1) /* we will find end only if there is start */
             {
                 for (i=(index_dict_start[(ch - 'a')]+1);i<Dwords;i++)
                 {
                      if (dictionary[i][0] != ch)
                      {
                          index_dict_end[(ch - 'a')] = i-1;
                          break;
                      }
                 }
                 
                 /* If we could not find a word starting with next alpha then start is the end*/
                 if (index_dict_end[(ch - 'a')] == -1)
                 {
                     index_dict_end[(ch - 'a')] = index_dict_start[(ch - 'a')];
                     if (dictionary[Dwords-1][0] == ch)
                     {
                         index_dict_end[(ch - 'a')] = Dwords - 1;
                     }
                 }
             }
         } 
 
         /* Now we have the dictionary sorted and indexed */ 
 #endif
 
         /* Start with the test cases */
 
         /* there are Ntestcases */
 	for (i = 0; i < Ntestcases; i++)
         {
             /* The word is of length L */
             for (j = 0; j < Lstrlen; j++)
             {
                 word[i].numletter[j] = 0; 
                 word[i].nummat = 0;
                 temp = fgetc(fp);
                 if (temp == '(') /* Idhu ellam oru polappa ? */
                 { 
                     while (temp != ')')
                     {
                         temp = fgetc(fp);
                         word[i].letter[j][(word[i].numletter[j])] = temp;
                         word[i].numletter[j] = word[i].numletter[j] + 1;
                     }
                     word[i].numletter[j] = word[i].numletter[j] - 1; 
                     word[i].letter[j][(word[i].numletter[j])] = '\0';
                 }
                 else
                 {
                    word[i].letter[j][(word[i].numletter[j])] = temp;
                    word[i].numletter[j] = word[i].numletter[j] + 1;
                 }
             }
             GO_TO_NEXTLINE;
         }
 
         /* we got all fucking propable words */
 
         /* Now cycle through so that all the letters overflow */
 
         /* Take each word in dictionary, check whether it can be formed using the current test case or not */
 
        	for (i = 0; i < Dwords; i++)
         {
             for (j = 0; j < Ntestcases; j++)
             {
                 ltrmat = 0;
                 for (k = 0; k < Lstrlen; k++)
                 {
                     mat = 0;
                     /* check whether the current dictionary ith word can be formed by jth testcase */
                     for (l = 0; l < word[j].numletter[k]; l++)
                     {
                         if (dictionary[i][k] == word[j].letter[k][l])
                         {
                             mat = 1;
                             break;
                         }
                     }
                     
                     if (0 == mat)
                     {
                         break;
                     }
                     else
                     {
                         ltrmat++;
                     }
                  }
                  
                  if (ltrmat == Lstrlen)
                  {
                      word[j].nummat++;   
                  }
           }                 
       }
 
       /* Print the output */
       for (i = 0; i < Ntestcases; i++)
       {
           printf("Case #%d: %d\n",(i+1),word[i].nummat);
       }
 
     return 0;
 }

