#include<stdio.h>
 #include<string.h>
 #define _L 15
 #define _D 5000
 #define _N 500
 
 char words[_D][_L+1];
 char pattern[_N][_D*_L*30],p;
 int l,d,n;
 int iter1;
 int getCount(char pat[_D*_L*30]);
 
 int main()
 {
     scanf("%d%d%d",&l,&d,&n);
     for(iter1=0;iter1<=d;iter1++)
     {
         gets(words[iter1]);
     }
     for(iter1=0;iter1<n;iter1++)
     {
         gets(pattern[iter1]);
     }
 
     for(iter1=0;iter1<n;iter1++)
     {
         printf("Case #%d: %d\n",iter1+1,getCount(&pattern[iter1][0]));
         if(iter1 == 205)
             break;
     }
 
     return 0;
 }
 
 int getCount(char pat[_D*_L*30])
 {
     int len = strlen(pat), j =0, i =0, count[_L],pos =0, tot=0;
     char strcha[_L][_D];
     bool multi = false;
     for(i=0; i<len;i++)
     {
         if(pat[i]=='(')
         {
             multi = true;
             j=0;
         }
         else if(pat[i] == ')')
         {
             multi = false;
             count[pos]=j;
             pos++;
         }
         else
         {
             if(multi)
                 strcha[pos][j++] = pat[i];
             else
             {
                 strcha[pos][0] = pat[i];
                 count[pos] = 1;
                 pos++;
             }
         }
     }
 
     for(i=1; i<=d;i++)
     {
         bool ok = true;
         int k,leng=0;
         for(j=0;j<l && ok;j++)
         {
             for(k=0;k<=count[j];k++)
             {
                 if(words[i][j]==strcha[j][k])
                 {
                     leng++;
                     break;
                 }
                 else if(count[j]==1)
                     ok=false;
             }
 
 
             if(words[i][j]!=strcha[j][k])
             {
                 ok = false;
                 break;
             }
         }
         if(ok && leng >0)
         {
              tot++;
         }
     }
     return tot;
 }

