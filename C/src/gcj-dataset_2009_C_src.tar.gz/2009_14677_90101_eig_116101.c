#include <stdio.h>
 #define MAXD 5000
 #define MAXL 15
 char words[MAXD][MAXL];
 char temp[MAXL*(MAXL+3)];
 int pass[MAXD];
 int vec[26];
 
 int main(){
     int L,D,N,i,j,k,count,mem;
     
     freopen("A-small-attempt0.in","r",stdin);
     scanf("%d %d %d",&L,&D,&N);    
     for(i=0;i<D;i++){
         scanf("%s",words[i]);
         //printf("%s",words[i]);
     }
     
     for(i=0;i<N;i++){
         scanf("%s",temp);
         count=0;
         for(j=0;j<D;j++)
             pass[j]=1;
         
         mem=0;
         for(j=0;j<L;j++){
             for(k=0;k<26;k++)
                 vec[k]=0;
             if(temp[mem]=='(')
             {
                 while(temp[++mem]!=')')
                     vec[temp[mem]-'a']=1;    
                 mem++;
             }
             else{
                 vec[temp[mem]-'a']=1;
                 mem++;
             }
             /*for(k=0;k<26;k++){
                 if(vec[k]==1)
                     printf("%c",k+'a');    
             }printf("\n");*/
             for(k=0;k<D;k++){
                 //printf("%d %d %c\n",j,k,words[k][j]);
                 if(pass[k])
                     if(vec[words[k][j]-'a']==0)
                         pass[k]=0;
             }
         }/**/
         for(j=0;j<D;j++)
             count+=pass[j];
         printf("Case #%d: %d\n",i+1,count);
     }
 }

