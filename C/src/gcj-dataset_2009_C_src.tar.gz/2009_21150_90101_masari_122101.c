#include <stdio.h>
 #include <string.h>
 
 #define len 19
 
 
 char * f = "welcome to code jam";
 char s[501];
 int pivo[19];
 
 int main(void)
 {
 	int n, t, i, j;
 	unsigned long long int count;
 	
 	
 	scanf("%d ",&n);
 	t = 1;
 	while(n--){
 		gets(s);
 		count = j = i = pivo[0] = 0;
 		while(1){
 			if(s[i]==f[j]){
 				pivo[j] = i;
 				i++; j++;
 				if(j==len) {count++; j--;}
 			}else{
 				i++;
 			}
 			if (s[i]=='\0') {
 				if (--j >= 0 ) {i = pivo[j]+1;} else { break; }
 			}
 		}
 		
 		printf("Case #%d: %04lld\n",t++, count%1000);
 	}
 		
 		
 	
 	
 	return 0;
 }

