#include<stdio.h>
 #include<string.h>
 int main()
 {
         char s[101];
         int n, length, i;
         int count;
         scanf("%d", &n);
         for (i = 0; i< n; i++) {
                 memset(s, 0, sizeof(s));
                 scanf("%s", s);
                 length = strlen(s);
                 count  = 0;
                 length--;
                 while (length >= 0)
                 {
                         while ( (length >= 0) && (s[length] == '+')) {
                                 length--;
                         }
                         if (length <0 )
                                 break;
                         count++;
                         while ((length >= 0) && (s[length] == '-')) {
                                 length--;
                         }
                         if (length < 0)
                                 break;
                         count++;
                 }
                 printf("Case #%d: %d\n", i+1, count);
         }
         return 0;
 }

