#include <stdio.h>
 #include <stdlib.h>
 
 #define STACK_MAX_SIZE 100
 
 int main(int argc, char** argv)
 {
   int stack[STACK_MAX_SIZE];
   int stack2[STACK_MAX_SIZE];
   char buffer[256];
   int i, j, k, l;
   int T;
   int c;
 
   FILE* f = fopen(argv[1], "r");
   
   /* nb test case */
   fgets(buffer, 256, f);
   T = atoi(buffer);
 
   /* traitements des cas de test */
   for(i=0; i<T; i++){
     /* je rempli le stack */
     j=0;
     c = fgetc(f);
     while((c != '\n') && (c != EOF)){
       stack[j] = (c == '+') ? 1 : 0;
       j++;
       c = fgetc(f);
     }
     /* traitement */
     c = 0;
     while(1){
       /* checking */
       for(k=0; k<j; k++){
 	if(!stack[k])
 	  goto algo;
       }
       printf("Case #%d: %d\n", i+1, c);
       break;
       
     algo:
       /* copie dans stack2 */
       for(k=0; k<j; k++)
 	stack2[k]=stack[k];
 
       if(stack[0]){
 	/* je cherche tous les + */
 	k = 0;
 	while(stack[k]){
 	  stack[k] = 0;
 	  k++;
 	}
       } else {
 	k=0;
 	while(!stack[k]){
 	  stack[k] = 1;
 	  k++;
 	}
       }
 
       c++;
     }
   }
   
   fclose(f);
 
   return 0;
 }

