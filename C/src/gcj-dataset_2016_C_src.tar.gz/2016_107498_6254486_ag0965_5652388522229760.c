#include <stdio.h>
 #include<math.h>
 int main(void) {
 	long long int t,n,m,j,i,l,z,p,flag=0,ans;
 	scanf("%lld",&t);
 	long long int a[10];
 	for(i =1; i <=t;i++){
 		l=1;flag=0;
 		for(j = 0; j <10; j++){
 			a[j]=0;
 		}
 		scanf("%lld",&n);
 		if(n == 0){
 			printf("Case #%d: INSOMNIA\n",i);
 		}
 		else{
 			while(1){
 			ans = n*l;
 			m = ans;
 			p = 10;
 			flag = 0;
 			while(m>0){
 				// printf("jjjjjCase #%d:%d\n",i,m);
 				z = m%10;
 				a[z]++;
 				m = m/p;
 			}
 			for(j = 0; j <10; j++){
 				if(a[j]==0){
 					flag=1;
 					break;
 				}
 			}
 			if(flag==1){
 				l = l+1;
 				flag = 0;
 			}
 			else{
 				printf("Case #%lld: %lld\n",i,ans);
 				break;
 			}
 			}
 		}
 	}
 	// your code goes here
 	return 0;
 }
 

