/*******************************************************************************
  *
  * PROJECT:
  *    Google Code Jam Round 1A
  *
  * FILE DESCRIPTION:
  *     Complete solution to 1A    
  *
  * CREATED BY:
  *   jonathan cressman April 15, 2016    
  *
  ******************************************************************************/
 
 /*** HEADER FILES TO INCLUDE  ***/
 #include "stdio.h"
 #include "stdbool.h"
 #include "string.h"
 #include "stdint.h"
 
 /*** DEFINES                  ***/
 
 /*** MACROS                   ***/
 
 /*** TYPE DEFINITIONS         ***/
 
 /*** VARIABLE DEFINITIONS     ***/
 
 /*** FUNCTION PROTOTYPES      ***/
 
 /*** FUNCTIONS                ***/
 /******************************************************************************
  * NAME:
  *    
  *
  * SYNOPSIS:
  *    
  *
  * PARAMETERS:
  *    OUTPUT
  * 
  *    INPUT/OUTPUT
  *
  *    INPUT
  *
  * GLOBAL VARIABLES
  *
  * FUNCTION:
  *    
  *
  * RETURNS:
  *    
  *
  ******************************************************************************/
 int main(int argc, char **argv)
 {
  	int T, i, j, n;
 	char largest;
 	int indexS, indexE;
 	char S[1001];
 	char O[2001];
 
 	scanf("%d", &T);
 
 	for (i=0; i<T; i++)
 	{
 		scanf("%s", S);
 		n = strlen(S);
 
 		largest = S[0];
 		indexS = indexE = 1000;
 		O[indexS] = S[0];
 		for (j=1; j<n; j++)
 		{
 			if (S[j]>=largest)
 			{
 				largest = S[j];
 				indexS--;
 				O[indexS]=S[j];
 			}
 			else
 			{
 				indexE++;
 				O[indexE]=S[j];
 			}
 		}
 		indexE++;
 		O[indexE]=0;
 
 		printf("Case #%d: %s\n", i+1, &O[indexS]);
 	}
 
 	return 0;
 }

