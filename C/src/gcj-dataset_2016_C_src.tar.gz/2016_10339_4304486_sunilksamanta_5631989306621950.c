#include<stdio.h>
 #include<string.h>
 void rshift(char *s){
     int i,l;
     l=strlen(s);
     for(i=l;i>=0;i--){
         s[i+1]=s[i];
     }
 }
 
 void main(){
     char x,s[1001],a[1001];
     int i,j,n,l;
     FILE *in,*out;
     in=fopen("A-large.in","r");
     out=fopen("test-large.out","w");
     fscanf(in,"%d",&n);
     for(l=0;l<n;l++){
         fscanf(in,"%s",s);
         x=s[0];
         i=1;
         a[1]='\0';
         a[0]=x;
         while(s[i]!='\0'){
             if(s[i]>=a[0]){
                 rshift(a);
                 a[0]=s[i];
                 i++;
             }
             else{
                 j=strlen(a);
                 a[j]=s[i];
                 a[j+1]='\0';
                 i++;
             }
         }
         fprintf(out,"Case #%d: %s\n",l+1,a);
     }
 }

