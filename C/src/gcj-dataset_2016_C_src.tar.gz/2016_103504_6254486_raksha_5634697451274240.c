#include<stdio.h>
 #include<String.h>
 
 char s[10];int ans=0;
 
 int flip(char s[],int n,int x)
    {ans++;int i;
    if(x==0)
    {for(i=0;i<n;i++)
    {
    s[i]='+';
    }}
    else
    {
    for(i=0;i<n;i++)
    s[i]='-';
    }
    return ans;
    }
 
 
 
 
 int main()
 {
 int t,a,i,z;
 scanf("%d",&t);
 
 for(z=0;z<t;z++)
 {
    
    scanf("%s",&s);
    a=strlen(s);
    for(i=0;i<a-1;)
    {if(s[i]=='-')
 	 {
 	 if(s[i+1]=='-')
 	 i++;
 	else
 	 {flip(s,i,0);
        i++;
 	 }
      }
 	 
 	 
 	else if(s[i]=='+')
 	 {
 	 if(s[i+1]=='+')
 	 i++;
 	 else
 	 {flip(s,i,1);
       i++;
 	  }
    
    
    }
    }
    if(s[i]=='-')
    printf("Case #%d: %d\n",z+1,flip(s,i,0));
    
    else
    printf("Case #%d: %d\n",z+1,ans);
    
    ans=0;
    
    }
    
    
    }
    
    
    
    
    
   
   
