#include<stdio.h>
 #include<string.h>
 
 int main(){
 	int n = 0;
 	scanf("%d", &n);
 
 	int i = 0;
 	for(i = 0; i < n; i++){
 		long long N = 0;
 		scanf("%llu", &N);
 		
 		if(!N){
 			printf("Case #%d: INSOMNIA\n", i + 1);
 			continue;
 		}
 
 		int digit[10] = {0,0,0,0,0,0,0,0,0,0};
 
 		int j = 0;
 		for(j = 1; j>0; j++){
 			long long curr = N*j;
 			long long temp = curr;
 			
 			while(temp){
 				digit[temp % 10] = 1;
 				temp /= 10;
 			}
 
 			if(digit[0]&&digit[1]&&digit[2]&&digit[3]&&digit[4]&&digit[5]&&digit[6]&&digit[7]&&digit[8]&&digit[9]){
 				printf("Case #%d: %llu\n", i + 1,curr);
 				break;
 			}
 		}
 	}
 	return 0;
 }

