#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define BUFFERSIZE 8012
 
 char *saveptr;
 char buffer[BUFFERSIZE];
 
 char * nextLine(){
 	fgets(buffer, BUFFERSIZE, stdin);
 	return buffer;
 }
 
 char * nextToken(){
 	char *token;
 	token = strtok_r(NULL, " ", &saveptr);
 	while(token == NULL){
 		char *newline = nextLine();
 		if(newline == NULL) return NULL;
 		token = strtok_r(newline, " ", &saveptr);
 	}
 	return token;
 }
 
 int nextInt(){
 	return atoi(nextToken());
 }
 
 double nextDouble(){
 	return atof(nextToken());
 }
 
 long nextLong(){
 	return atol(nextToken());
 }
 
 int check(int *nums, long n){
 	int i;
 	while(n > 0){
 		nums[n%10] = 1;
 		n/=10;
 	}
 	for(i=0;i<10;i++){
 		if(nums[i] == 0) return 0;
 	}
 	return 1;
 }
 
 void doStuff(int run){
 	long n = nextInt();
 	int i;
 	long sum;
 	int nums[10];
 	for(i=0;i<10;i++){
 		nums[i] = 0;
 	}
 	sum = n;
 	i = 0;
 	while(check(nums, sum) == 0 && i < 100000){
 		sum += n;
 		i++;
 	}
 	if(i == 100000) {
 		printf("Case #%d: INSOMNIA\n", run);
 	} else {
 		printf("Case #%d: %d\n", run, sum);
 	}
 }
 
 int main(){
 	int run, n;
 	n = nextInt();
 	for(run=1;run<=n;run++){
 		doStuff(run);
 	}
 	// int i;
 	// for(i=0;i<1000000;i++){
 	// 	printf("%d\n",i);
 	// }
 }
 

