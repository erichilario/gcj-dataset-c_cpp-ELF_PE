//
 //  1A.c
 //  codejam
 //
 //  Created by ayoon on 2016-04-08.
 //  Copyright © 2016 ayoon. All rights reserved.
 //
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 
 typedef struct entry_ {
     bool found;
     int num;
     int final;
 } entry;
 
 bool allFound(int* arr) {
     for (int i=0; i<10; i++) {
         if (arr[i] == 0) return false;
     }
     return true;
 }
 
 void fillArr(int* arr, int num) {
     while (num) {
         int next = -1;
         next = num - ((num/10)*10);
         
         if (next >= 0 && next < 10) {
             arr[next]++;
         }
         
         num /= 10;
     }
 }
 
 
 int main(int argc, const char * argv[]) {
 
     int tc = 0;
     
     // How many TC?
     scanf("%d", &tc);
     
     // assign storage
     entry* nums = (entry *) calloc(tc, sizeof(entry));
     
     for (int i=0; i<tc; i++) {
         // take input
         scanf("%d", &nums[i].num);
         if (nums[i].num == 0) {
             // insomnia
             continue;
         } else {
             // lets find out?
             int arr[10] = {0};
             int curr = nums[i].num;
             int count = 1;
             
             while (!nums[i].found) {
                 fillArr(arr, curr);
                 if (allFound(arr)) {
                     nums[i].found = true;
                     nums[i].final = curr;
                 } else {
                     curr /= count;
                     count++;
                     curr *= count;
                 }
             }
         }
     }
     
     for (int i=0; i<tc; i++) {
         printf("Case #%d: ", i+1);
         if (nums[i].found) {
             printf("%d\n", nums[i].final);
         } else {
             printf("INSOMNIA\n");
         }
     }
     
     return 0;
 }

