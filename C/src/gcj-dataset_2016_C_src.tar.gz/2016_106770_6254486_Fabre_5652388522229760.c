#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
 	int t,max;
 	scanf("%d",&t);
 	max=t;
 	while(t--)
 	{
 		int i,n,num,x,digits,count;
 		int seen[10]={0};
 		scanf("%d",&n);
 		count=0;
 		i=2;
 		num=n;
 		if(n==0)
 		{
 			printf("Case #%d: INSOMNIA\n",max-t);
 		}
 		else
 		{
 			while(count < 10)
 			{
 				digits= num;
 				while(num > 0)
 				{
 					x= num%10;
 					if(seen[x]==0)
 					{
 						count++;
 						seen[x]=1;
 					}
 					num = num/10;
 				}
 				if(count==10)
 				{
 					printf("Case #%d: %d\n",max-t,digits);
 				}
 				else
 				{
 					num = i*n;
 					i++; 
 				}	
 			}
 		}
 	}
 	return 0;
 }
