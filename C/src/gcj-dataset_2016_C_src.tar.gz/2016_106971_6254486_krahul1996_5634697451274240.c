#include<stdio.h>
 int main(){
 int t,k,flag,sum,i,j;
 char str[100000];
 scanf("%d",&t);
 for(k=1;k<=t;k++){
     scanf("%s",&str);
 
    for(i=0,sum=0;str[i]!='\0';i++){
     if(str[i]=='+')
         break;
     else
         sum=1;
 
    }
    for(j=i;str[j]!='\0';j++){
 
     if(str[j]=='-' && flag==1){
         sum+=2;
         flag=0;
     }
     else if(str[j]=='+')
         flag=1;
    }
 
  printf("Case #%d: %d\n",k,sum);
 
 
 
 }
 
 
 }

