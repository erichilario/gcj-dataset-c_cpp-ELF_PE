#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 #include<string.h>
 
 int main()
 {//freopen("D-large.in","r",stdin);
  //freopen("D-large.out","w",stdout);
     
  int T,K,C,S,i,j;
  
  
  scanf("%d",&T);
  for(i=1;i<=T;i++)
     {scanf("%d %d %d",&K,&C,&S);
      printf("Case #%d:",i);
      if(K==1)
        {if(S==1)
           printf(" 1");
           else
             printf(" IMPOSSIBLE");  
        }
      else if(C==1)
        {if(S==K)
            for(j=1;j<=K;j++)
               printf(" %d",j);
           else
             printf(" IMPOSSIBLE");         
        }
       else if(C>1)
         {if((S+1)>=K)
             for(j=K;j>1;j--)
                printf(" %d",j);
            else
              printf(" IMPOSSIBLE");       
         }       
      printf("\n");         
     }   
 return 0;
 }

