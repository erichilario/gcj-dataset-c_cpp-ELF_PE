#include<stdio.h>
 #include<string.h>
 void flip(char *a,int n)
 {
  int i;
  for(i=0;i<=n;i++)
  {
   if(*(a+i)=='+')
       *(a+i)='-';
   else
       *(a+i)='+';
  }
  return ;
 }
 int main()
 {
  freopen("b.in","r",stdin);
  freopen("gcj2.out","w",stdout);
  int t,a0;
  scanf("%d",&t);
  for(a0=0;a0<t;a0++)
  {
   char a[1000];
   int i,cnt=0;
   scanf("%s",a);
 
   for(i=strlen(a)-1;i>-1;i--)
   {
    if(a[i]=='+')
       continue;
    flip(a,i);
    cnt++;
   }
   printf("Case #%d: %d\n",a0+1,cnt);
  }
  return 0;
 }

