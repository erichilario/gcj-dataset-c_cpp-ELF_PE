#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
 	FILE *fin,*fout;
 	fin=fopen("B-large.in-2.txt","r");
 	fout=fopen("B-one2.txt","w");
 	int t,m=1;
 	fscanf(fin,"%d",&t);
 	while(t--)
 	{
 		int n,x;
 		fscanf(fin,"%d",&n);
 		int a[2501],i;
 		for(i=0;i<2501;i++)
 		{
 			a[i]=0;
 		}
 		for(i=0;i<n*((2*n)-1);i++)
 		{
 			fscanf(fin,"%d",&x);
 			a[x]++;
 		}
 		fprintf(fout,"Case #%d:",m);
 		m++;
 		for(i=0;i<2501;i++)
 		{
 			if(a[i]%2==1 && a[i]!=0)
 			{
 				fprintf(fout," %d",i);
 			}
 		}
 		fprintf(fout,"\n");
 	}
 }
 			
