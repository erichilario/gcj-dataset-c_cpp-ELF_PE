#include <stdio.h>
 #include <stdlib.h>
 
 void check_digits( int n, int arr_seen[10] ) {
 
     int digit;
     while( n != 0 ) {
         digit = n % 10;
         n = n/10;
         arr_seen[ digit ] = 1;
     }
 
 }
 
 int is_done(int n, int arr_seen[10]) {
 
     int i = 0;
     int count = 0;
 
     check_digits( n, arr_seen );
 
     for( i = 0 ; i < 10; i++ ) {
         if( arr_seen[i] == 1 ) {
             count++;
         }
     }
 
     if( count == 10 ) {
         return 1;
     } else {
         return 0;
     }
 }
 
 int main() {
     
     int T ; // # Test Cases
     int n[ 200 ]; // Numbers 
 
     int i, j;
 
     scanf("%d", &T);
 
     for( i = 0; i < T; i++ ) {
         scanf( "%d", &n[i] );
     }
     
     for( i = 0; i < T; i++ ) {
         int * arr_seen = (int *) ( malloc( sizeof(int) * 10 ) );
         memset( arr_seen, 0, sizeof(int) * 10 );
         int cur_num = n[i];
         int k = 1;
 
         if( cur_num == 0 ) {
             printf("Case #%d: INSOMNIA\n", i+1);
         } else {
             while( !is_done( cur_num * k, arr_seen ) ) {
                 k++;
             } 
             printf("Case #%d: %d\n", i+1, cur_num * k);
         }
         free( arr_seen );
     }
     
     return 0;
 }

