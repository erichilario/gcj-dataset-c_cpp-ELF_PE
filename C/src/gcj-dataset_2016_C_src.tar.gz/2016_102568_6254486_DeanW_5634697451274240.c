#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 //#define DBG_PRINT
 
 #ifdef DBG_PRINT
 #define DbgPrintf(...) printf(__VA_ARGS__)
 #else
 #define DbgPrintf(...)
 #endif
 
 /* run this program using the console pauser or add your own getch, system("pause") or input loop */
 
 char status[100];
 
 
 int main(int argc, char *argv[]) {
 	
 	int T;
 	int N;
 	int i, j;
 	int times;
 
 	//DbgPrintf("MAX: %lld \n", LLONG_MAX);
 
 	scanf("%d", &T);
 	DbgPrintf("T: %d \n", T);
 
 	for( i = 1 ; i <= T ; i++ ) {
 		
 		times = 0;
 		memset(status, 0, 100);
 		scanf("%s", &status);
 		DbgPrintf("status: %s \n", status);
 		DbgPrintf("strlen(status): %d \n", strlen(status));
 		
 		for( j = 0 ; j < strlen(status)-1 ; j++ ) {
 			if(status[j]!=status[j+1]) {
 				times++;
 			}
 		}
 		
 		if( status[strlen(status)-1] == '-' ) {
 			times++;
 		}
 		
 		printf("Case #%d: %d\n", i, times);
 		DbgPrintf("\n\n");
 	}
 
 	return 0;
 }

