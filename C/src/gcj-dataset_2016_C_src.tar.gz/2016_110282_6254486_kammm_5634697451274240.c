//
 //  B.c
 //  codejam
 //
 //  Created by ayoon on 2016-04-08.
 //  Copyright © 2016 ayoon. All rights reserved.
 //
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <string.h>
 
 #define MAX_LEN 100
 
 typedef struct entry_ {
     char* stack;
     int count;
 } entry;
 
 
 void flip(char* stack, int n) {
     // flip 0~n
     for (int i=0; i<n; i++) {
         if (stack[i] == '+') stack[i] = '-';
         else stack[i] = '+';
     }
     
     return;
 }
 
 
 int main(int argc, const char * argv[]) {
     
     int tc = 0;
     
     // How many TC?
     scanf("%d", &tc);
 
     entry* input = (entry *)calloc(tc, sizeof(entry));
     
     for (int i=0; i<tc; i++) {
         input[i].stack = (char *)calloc(MAX_LEN, sizeof(char));
         scanf("%s", input[i].stack);
         
         for (int j=strlen(input[i].stack)-1; j>=0; j--) {
             if (input[i].stack[j] == '-') {
                 flip(input[i].stack, j);
                 input[i].count++;
             }
         }
     }
     
     for (int i=0; i<tc; i++) {
         printf("Case #%d: %d\n", i+1, input[i].count);
     }
     
     return 0;
 }

