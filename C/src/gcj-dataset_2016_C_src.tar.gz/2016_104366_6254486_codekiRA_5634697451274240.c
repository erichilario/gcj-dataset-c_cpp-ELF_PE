#include<stdio.h>
 #include<string.h>
 int main() {
 int T,i=1,j;
 scanf("%d",&T);
 while(i<=T) {
 				char pan[100];
 				int ans=0,len;
 				scanf("%s",pan);
 				for(j=1;j<strlen(pan);j++) {
 					if(pan[j]!=pan[j-1]) ans++;
 				}
 				if(pan[j-1]=='-') ans++;
 				printf("Case #%d: %d\n",i,ans);
 	
 	i++;
 	}
 }
