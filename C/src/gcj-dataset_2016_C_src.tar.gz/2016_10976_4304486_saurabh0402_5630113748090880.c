#include <stdio.h>
 
 int main(){
 	int n, x = 1;
 	int l, i, max, count = 0, j;
 	scanf("%d", &n);
 
 	while(x <= n){
 		scanf("%d", &l);
 		int temp = (2*l - 1)*l;
 		int arr[temp], ans[l];
 		max = 0, count = 0;
 
 		i = 0;
 		while(i < temp){
 			scanf("%d", &arr[i]);
 			i++;
 		}
 
 		int arrAns[3] = {-1, -1, -1}, heights[2500];
 
 		i = 0;
 		while(i < 2500){
 			heights[i] = 0;
 			i++;
 		}
 
 		i = 0;
 		while(i < temp){
 			if(arr[i] > max)
 				max = arr[i];
 			heights[arr[i] - 1] += 1;
 			i++;
 		}
 
 		i = 0;
 		while(i < max){
 
 			if(heights[i]%2 != 0){
 				ans[count] = i + 1;
 				count++;
 			}
 			i++;
 
 		}
 
 		i = 0;
 		printf("Case #%d: ", x);
 		while(i < l){
 			printf("%d ", ans[i]);
 			i++;
 		}
 
 		printf("\n");
 		x++;
 	}
 	return 0;
 }
