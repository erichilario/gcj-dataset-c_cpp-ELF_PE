#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define BUFFERSIZE 8012
 
 char *saveptr;
 char buffer[BUFFERSIZE];
 
 char * nextLine(){
 	fgets(buffer, BUFFERSIZE, stdin);
 	return buffer;
 }
 
 char * nextToken(){
 	char *token;
 	token = strtok_r(NULL, " ", &saveptr);
 	while(token == NULL){
 		char *newline = nextLine();
 		if(newline == NULL) return NULL;
 		token = strtok_r(newline, " ", &saveptr);
 	}
 	return token;
 }
 
 int nextInt(){
 	return atoi(nextToken());
 }
 
 double nextDouble(){
 	return atof(nextToken());
 }
 
 long nextLong(){
 	return atol(nextToken());
 }
 
 int flipper[] = {0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15};
 int powers[] = {1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048};
 
 int flip(int num, int n){
 	int lower, i, tmp = 0;
 	if(n == 0) return num;
 	lower = num & (powers[n] - 1);
 	for(i=0;i<((n+3)/4);i++){
 		tmp = (tmp << 4) + flipper[lower & 15];
 		lower = lower >> 4;
 	}
 	if(4*i+4 > n)  tmp = tmp >> (4+(i*4)-n);
 	return ((num >> n) << n) + tmp ^ (powers[n] - 1);
 }
 
 int solve(int *dp, int len){
 	int i, j, k, tmp,t;
 	int solved = 0;
 	for(t=0;t<10;t++){
 		for(i=0;i<2*len;i++){
 			for(j=0;j<powers[len];j++){
 				if(dp[j] == i){
 					for(k=1;k<=len;k++){
 						tmp = flip(j, k);
 						if(dp[tmp] == -1 || dp[tmp] > dp[j]+1){
 							dp[tmp] = dp[j] + 1;
 						}
 					}
 				}
 			}
 		}
 	}
 	
 }
 
 void doStuff(int run){
 	char *str;
 	int i, len;
 	// int s[100];
 	char w;
 	int n = 1;
 	str = nextToken();
 	len = strlen(str);
 	if(str[len-1] == '\n') len--;
 	w = str[0];
 	for(i=0;i<len;i++){
 		if(str[i] != w){
 			w = str[i];
 			n++;
 		}
 	}
 	if(str[len-1] == '+') n--;
 	// 	if(str[len - 1 - i] == '+'){
 	// 		s[len - 1 - i] = 1;
 	// 	} else {
 	// 		s[len - 1 - i] = 0;
 	// 	}
 	// }
 	printf("Case #%d: %d\n", run, n);
 }
 
 int main(){
 	int run, n;
 	n = nextInt();
 	for(run=1;run<=n;run++){
 		doStuff(run);
 	}
 }
 

