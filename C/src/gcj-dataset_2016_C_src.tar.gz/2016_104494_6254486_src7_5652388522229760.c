#include<stdio.h>
 #include<conio.h>
 void main()
 {
 	int a,n,i,z=0,t=0,k,j,m=0,p=0,ans,b[10];
 	FILE *fp;
 	fp=fopen("Output.out","a");
 
 	clrscr();
 	freopen("input.in", "r", stdin);
 	scanf("%d",&n);
 
 	for(i=0;i<n;i++)
 	{
 	scanf("%d",&a);
 	 if(a==0)
 	 {printf("Case #%d: INSOMANIA\n",i);goto me;}
 	 for(j=1;j;j++)
 	 {
 	   z=a*j;  ans=z;
 	   for(;z;z=z/10)
 	   {
 		t=z%10;
 		for(k=0;k<m;k++)
 		{
 		    if(b[k]==t)
 		    {p=1;}
 		}
 		if(p!=1)
 		{b[k]=t;m++;}
 		p=0;
 		if(m==10)
 		{ printf("Case #%d: %d\n",i,ans);
 		fprintf(fp,"Case #%d: %d\n",i+1,ans);goto me;
 		goto me;}
 
 	   }
 	 }me:m=0;z=0;p=0;t=0;
 	}
 	 fclose(fp);
 	 getch();
 
 }
