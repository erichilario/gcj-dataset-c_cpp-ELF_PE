#include<stdio.h>
 #include<math.h>
 #include<string.h>
 
 int main(){
 	int T = 0;
 	scanf("%d", &T);
 
 	int i = 0;
 	for(i = 0; i < T; i++){
 		int K = 0;
 		int C = 0;
 		int S = 0;
 		scanf("%d %d %d", &K, &C, &S);
 		long long length = pow(K, C-1); //since S = K
 		int j = 0;
 		printf("Case #%d: 1", i + 1);
 		for(j = 1; j < S; j++){	
 			long long n = j * length;
 			printf(" %llu", n + 1);
 		}	
 		puts("");
 	}
 	return 0;
 }

