#include<stdio.h>
 
 char s[101];
 void flipStack(int);
 int allPlus();
 char inv(char);
 
 int main(){
     int t,ti,i,p,counter,len;
     scanf("%d",&t);
     for(ti=1;ti<=t;ti++){
 	counter=0;
 	scanf("%s",s);
 	for(len=0;s[len]!='\0';len++);
 	while(!allPlus()){
 	    for(i=0;i<len;i++){
 		if(s[i]!='+'){
 		    if(i!=0){
 		    counter++;
 		    flipStack(i-1);
 		    }
 		    break;
 		}
 	    }
 	    for(i=len-1;i>=0;i--){
 		    if(s[i]=='-'){
 			counter++;
 			flipStack(i);
 			break;
 		    }
 	    }
 	}
 	printf("Case #%d: %d\n",ti,counter);
     }
     return 0;
 }
 int allPlus(){
     int i;
     for(i=0;s[i]!='\0';i++){
 	if(s[i]=='-')
 	    return 0;
     }
     return 1;
 }
 
 void flipStack(int i){
     int j,t;
     for(j=0;j<=(i/2);j++)
     {
 	t=s[j];
 	s[j]=inv(s[i-j]);
 	s[i-j]=inv(t);
     }
 }
 
 char inv(char c){
     if(c=='+')
 	return '-';
     else
 	return '+';
 }

