#include<stdio.h>
 #include<stdlib.h>
 int check(int digit[]);
 int main()
 {
 	int t,i,n,k,count,digit[10];
 	scanf("%d",&t);
 	for(i = 0; i < t; i++)
 	{
 		for(k=0;k<10;k++)
 			digit[k]=0;
 		scanf("%d",&n);
 		k = n;
 		count = 0;
 		if(n == 0)
 			printf("Case #%d: INSOMNIA\n",i+1);
 		else
 		{
 			while(check(digit))
 			{
 				count++;
 				k = count * n;
 				while(k!=0)
 				{
 					digit[k%10] = 1;
 					k = k / 10;
 				}
 			}
 			printf("Case #%d: %d\n",i+1,count*n);
 		}
 	}
 	return 0;
 }
 int check(int digit[])
 {
 	int i;
 for(i=0;i<10;i++)
 {
 	if(digit[i] == 0)
 		return 1;
 
 }
 return 0;
 }
