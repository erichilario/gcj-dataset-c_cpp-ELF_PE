#include <stdio.h>
 #include <stdlib.h>
 
 int check_all(int *A)
 {
 	int i;
 	for (i = 0 ; i<10 ; i++)
 	{
 		if (A[i]==0)
 			break;
 	}
 	if (i==10)
 		return 1;
 	else
 		return -1;
 }
 
 int main ( int argc, char **argv )
 {
 	int is_found[10];
 	int num_dissected[10],num_dissected_new[10];
 	int N,T,num_digit;
 	int i,j,k;
 	int is_done;
 	FILE *infile, *outfile;
 	
 	infile = fopen("A-large.in", "r");
 	outfile = fopen("A-large.out", "w");
 
 	
 
 	
 	
 	fscanf(infile,"%d",&T);
 
 	for (i=0 ; i<T; i++)
 	{
 		fscanf(infile,"%d",&N);
 		for (j=0 ; j<10; j++)
 		{
 			is_found[j] = 0;
 			num_dissected[j] = 0;
 			num_dissected_new[j] = 0;
 		}
 
 		j=0;
 		while(N!=0)
 		{
 			num_dissected[j] = num_dissected_new[j] = N%10;
 			j++;
 			N = N/10;
 		}
 		num_digit = j;
 
 		if (num_digit == 0)
 			fprintf(outfile,"Case #%d: INSOMNIA\n", i+1);
 		else
 		{
 			k = 2;
 			while(1)
 			{
 				for(j=0 ; j<num_digit ; j++)
 					is_found[num_dissected_new[j]] = 1;
 
 				is_done = check_all(is_found);
 				if (is_done == 1)
 					break;
 				else
 				{
 					for(j=0 ; j<num_digit ; j++)
 						num_dissected_new[j] = num_dissected[j]*k;
 					for(j=0 ; j<num_digit ; j++)
 					{
 						if (num_dissected_new[j] > 9)
 						{
 							num_dissected_new[j+1] += (num_dissected_new[j]/10);
 							num_dissected_new[j] = num_dissected_new[j]%10;
 						}
 					}
 
 					if (num_dissected_new[j] != 0)
 						num_digit++;
 					k++;
 				}
 			}
 			fprintf(outfile,"Case #%d: ", i+1);
 			for (j=num_digit ; j>0 ; j--)
 				fprintf(outfile,"%d", num_dissected_new[j-1]);
 			fprintf(outfile,"\n");
 		}
 
 	}
 
 	fclose(infile);
 	fclose(outfile);
 	return 0;
 }
