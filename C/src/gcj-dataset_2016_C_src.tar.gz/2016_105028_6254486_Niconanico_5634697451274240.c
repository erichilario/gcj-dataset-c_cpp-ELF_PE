#include <stdio.h>
 #include <string.h>
 
 int main()
 {
   int n;
   char panStr[110];
   scanf("%d", &n);
 
   for( int i = 0; i < n; i++)
     {
       char last = '+';
       int foundProblem = 0;
       int invs = 0;
       int lim;
       int res;
       scanf("%s", panStr);
       lim = strlen(panStr);
       for(int j = lim-1; j >= 0; j--)
 	{
 	  if (panStr[j] == '+' && !foundProblem)
 	    {
 	      continue;
 	    }
 	  else if(!foundProblem)
 	    {
 	      last = '-';
 	      foundProblem = 1;
 	      continue;
 	    }
 	  
 	  if (panStr[j] == last)
 	    {
 	      continue;
 	    }
 	  else
 	    {
 	      invs++;
 	      last = panStr[j];
 	    }
 	}
       if(foundProblem)
 	res = invs+1;
       else
 	res = 0;
       printf("Case #%d: %d\n", i+1, res);
     }
   return 0;
 }

