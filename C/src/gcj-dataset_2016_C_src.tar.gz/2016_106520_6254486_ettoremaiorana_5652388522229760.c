#include <stdio.h>
 
 
 int sumDigits (int digits[]) {
 	int i;
 	int sum = 0;
 	for (i = 0; i < 10; i++) {
 		sum += digits[i];
 	}
 	return sum;
 }
 
 int main() {
 
 	FILE *file, *o_file;
 	int n, i, j, number, err;
 	int digits[10];
 	file = fopen("A-small-counting-sheep.in", "r");
 	o_file = fopen("A-small-counting-sheep.out", "w");
 	err = fscanf(file, "%d", &n);
 	if (err < 0) {
 		printf("unable to read from file");
 		return 1;
 	}
 	for (i = 1; i <= n; i++) {
 		for (j = 0; j < 10; j++) {
 			digits[j] = 0 ;
 		}
 		err = fscanf(file, "%d", &number);
 		if (err < 0) {
 			printf("unable to read from file");
 			return 1;
 		}
 		if (number == 0) {
 			printf("INSOMNIA\n");
 			fprintf(o_file, "Case #%d: INSOMNIA\n", i);
 			continue;
 		}
 		int iter = 0;
 		do  {
 			iter++;
 			int currNumber = iter * number;
 			printf(" ");
 			while (currNumber > 0) {
 				int r = currNumber % 10;
 				printf("%d", r);
 				currNumber = currNumber / 10;
 				digits[r] = 1;
 			}
 		} while(sumDigits(digits) < 10);
 		printf(" ");
 		printf("%d\n", iter*number);
 		fprintf(o_file, "Case #%d: %d\n", i, iter*number);
 	}
 
 	fclose(file);
 	fclose(o_file);
 	return 0;
 }

