#include<stdio.h>
 #include<string.h>
 
 
 int main()
 {
   int T,_T;
   scanf("%d",&T);
   _T=T;
   while(T--)
   {
     int flag=0;
     int Count=10,i;
     int D[10]={0,0,0,0,0,0,0,0,0,0};
     unsigned long long int Num;
     unsigned long long int temp;
     scanf("%llu",&Num);
     if(Num)
     {
        for(i=1;i<100;i++)
        {
          temp = Num*i;
          while(temp)
          {
            if(D[temp%10]==0) {D[temp%10]=1;Count--;}
            temp=temp/10;
          }
          if(Count==0) { flag=1;break;}
        }
     }
     if(flag)
       printf("Case #%d: %lld\n",_T-T,Num*i);
     else
       printf("Case #%d: INSOMNIA\n",_T-T);
 
   }
   return 0;
 }

