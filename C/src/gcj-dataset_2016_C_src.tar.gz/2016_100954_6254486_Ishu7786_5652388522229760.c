#include <stdio.h>
 char a[10];
 int number(int);
 int number(int n){
 	while(n>0){
 		a[n%10]='F';
 		n/=10;
 	}
 	int i;
 	for(i=0;i<10;i++)
 		if(a[i]=='T')
 			return 1;
 	return 0;
 }
 
 char a[10];
 int main(void){
 	int t,z=0;
 	scanf("%d",&t);
 
 	while(t--){
 		z++;
 		long long int result,n,i=0,j,lnum;
 		scanf("%lld",&n);
 		if(n){
 			while(i<10){
 				a[i]='T';
 				i++;
 			}
 			result=2;
 			j=1;
 			while(result){
 				lnum=n*j;
 				result=number(lnum);
 				j++;	
 			}
 			printf("Case #%d: %lld\n",z,lnum);
 		}
 		else
 			printf("Case #%d: INSOMNIA\n",z);			
 	}
 	return 0;
 }
 
 	
 		
 		
 			
 		
 		

