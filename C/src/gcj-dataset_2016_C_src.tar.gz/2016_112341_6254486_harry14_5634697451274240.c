#include <stdio.h>
 #include <string.h>
 int flip(char a[101], int l){
 	int i, j, k, c = 0;
 	for(i = l - 1; i >= 0; i--){
 		if(a[i] == '-'){
 			k = i;
 			for(j = 0; j <= k; j++){
 				if(a[j] == '+'){
 					a[j] = '-';
 				}
 				else{
 					a[j] = '+';
 				}
 			}
 			c++;
 		}
 	}
 	return c;
 }
 int main(void) {
 	freopen("B-small-attempt0.in","r",stdin);
         freopen("B-small.out","w",stdout);
 	int i, t, l;
 	scanf("%d",&t);
 	char a[101];
 	for(i = 0; i < t; i++){
 		scanf("%s",a);
 		l = strlen(a);
 		printf("Case #%d: %d\n", i + 1, flip(a, l));
 	}
 	return 0;
 }
 

