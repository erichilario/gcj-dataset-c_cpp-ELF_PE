#include <stdio.h>
 
 int main(){
   int n;
   scanf("%d", &n);
   for(int i = 0; i < n; i++)
     {
       int k, c, s;
       printf("Case #%d: ", i+1);
       scanf("%d %d %d", &k, &c, &s);
       for(int j = 1; j <= s; j++)
 	{
 	  printf("%d ", j);
 	}
       printf("\n");
     }
   return 0;
 }

