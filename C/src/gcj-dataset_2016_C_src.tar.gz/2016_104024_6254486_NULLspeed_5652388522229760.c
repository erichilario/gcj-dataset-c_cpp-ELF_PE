#include<stdio.h>
 
 int main(void){
 	int flg[10]={0};
 	int i,j,n,t,tmp,num,rem;
 	
 	scanf("%d",&t);
 	for(i=1;i<=t;i++){
 		for(j=0;j<10;j++) flg[j]=0;
 		scanf("%d",&n);
 		num=n;
 		rem=10;
 		if(n==0) printf("Case #%d: INSOMNIA\r\n",i);
 		else{
 			while(rem>0){
 				//printf("NOW:%d\r\n",num);
 				tmp=num;
 				while(tmp>0){
 					if(flg[tmp%10]==0){
 						flg[tmp%10]=1;
 						rem--;
 					}
 					tmp/=10;
 				}
 				//for(j=0;j<10;j++) printf("%d%s",flg[j],(j==9)?"\r\n":" ");
 				num+=n;
 			}
 			printf("Case #%d: %d\r\n",i,num-n);
 		}
 	}
 	return 0;
 }
