#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int T;
 char S[100];
 
 char stack[100],tmp[100],stack0[100];
 
 #define DEBUG 0
 
 void fliptop(int n) {
 
   bcopy(stack,tmp,n);
   for (int i=0;i<n;i++) {
     //fprintf(stderr,"%d -> %d\n",stack[i],tmp[n-1-i]);
     stack[i]=(tmp[n-1-i] ? 0 : 1);
   }
 }
 
 int last_0(int n) {
   while(n > 0 && stack[n-1]==1)
     n--;
   if (n)
     return n;
   else
     return -1;
 }
 
 int last_1(int n) {
   while(n > 0 && stack[n-1]==0)
     n--;
   if (n)
     return n;
   else
     return -1;
 }
 
 int first_0(int n) {
   while(n > 0 && stack[n-1]==1)
     n--;
   if (n)
     return n;
   else
     return -1;
 }
 
 int first_1(int n) {
   int i=0;
 
   while(i < n && stack[i]==0)
     i++;
   if (i==n)
     return -1;
   else
     return i;
 }
 
 
 void pstack(n) {
   for(int i=0;i<n;i++)
     fprintf(stdout,"%c",(stack[i] == 1 ? '+' : '-') );
   fprintf(stdout,"\n");
 }
 
 int main() {
   int n,N,ops1,ops2,ops3,ops;
 
   scanf("%d",&T);
 
   for(int i=1;i<=T;i++) {
     scanf("%s",S);
     N=strlen(S);
     for(int i=0;i<N;i++)
       if (S[i]=='+')
         stack[i]=1;
       else
         stack[i]=0;
 
     if (DEBUG) fprintf(stderr,"############ %d %lu\n",i,strlen(S));
 
     // backup
     bcopy(stack,stack0,N);
     //pstack(N);
     n=last_0(N);
     ops=0;
     while(n>=0) {
       if (DEBUG) fprintf(stdout,"%d %d\n",ops,n);
       if (stack[0]==1 && n>1) {
         fliptop(1);
         ops++;
         n=last_0(n);
         continue;
       }
       fliptop(n);
       if (DEBUG) pstack(N);
       n=last_0(n);
       ops++;
     }
 
     ops1=ops;
     //printf("Case #%d: %d\n",i,ops);
 
     // restore and rerun in opposite
     bcopy(stack0,stack,N);
     //pstack(N);
     n=last_1(N);
     ops=0;
     while(n>=0) {
       if (DEBUG) fprintf(stdout,"%d %d\n",ops,n);
       if (stack[0]==0 && n>1) {
         fliptop(1);
         ops++;
         n=last_1(n);
         continue;
       }
       fliptop(n);
       if (DEBUG) pstack(N);
       n=last_1(n);
       ops++;
     }
 
 
     ops2=ops+1;
 
 
     bcopy(stack0,stack,N);
 
 
     if (ops1<ops2)
       ops=ops1;
     else
       ops=ops2;
 
     printf("Case #%d: %d\n",i,ops);
 
   }
 }

