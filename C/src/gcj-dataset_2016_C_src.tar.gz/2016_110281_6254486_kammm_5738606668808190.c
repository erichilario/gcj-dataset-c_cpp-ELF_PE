//
 //  B.c
 //  codejam
 //
 //  Created by ayoon on 2016-04-08.
 //  Copyright © 2016 ayoon. All rights reserved.
 //
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <string.h>
 #include <math.h>
 
 unsigned long long int is_prime(unsigned long long int num)
 {
     unsigned long long int res = 0;
     
     if (num <= 1) res = 1;
     else if (num % 2 == 0) res = 2;
     else {
         for(unsigned long long int i = 3; i < num / 2; i+= 2)
         {
             if (num % i == 0)
                 return i;
         }
     }
     return res;
 }
 
 unsigned long long int is_prime2(unsigned long long int num){
     
     unsigned long long int res = 0;
     
     if (num <= 1) res = 1;
     else if (num % 2 == 0) res = 2;
     else {
         for (unsigned long long int i=3;i<=sqrt(num);i+=2)
             if (num%i==0)
                 return i;
     }
     
     return res;
 }
 
 bool incr(char* str)
 {
     // return true at the end
     int len = (int) strlen(str);
     bool end = false;
     
     for (int i=1; i<len-1; i++) {
         if (str[i] == 0) break;
         if (i == len-2 && str[i] == 1) end = true;
     }
     
     if (end) return true;
     
     bool inc = false;
     for (int i=len-2; i>0; i--) {
         if (!inc) {
             str[i]++;
             inc = true;
         }
         if (str[i] == '2') {
             str[i] = '0';
             str[i-1]++;
         }
     }
     
     return end;
 }
 
 unsigned long long int to_base(char* str, int base) {
     unsigned long long int res = 0;
     int len = (int) strlen(str);
     
     for (int i=0; i<len; i++) {
         if (str[i] == '1') res++;
         if (i != len-1) res *= base;
     }
     
     return res;
 }
 
 
 int main(int argc, const char * argv[]) {
     
     int tc=0, digit=0, num=0;
 
     // How many TC?
     scanf("%d", &tc);
     scanf("%d %d", &digit, &num);
     
     char* str = (char *) calloc(digit, sizeof(char));
     str[0] = '1';
     for (int i=1; i<digit-1; i++) str[i] = '0';
     str[digit-1] = '1';
 
     //result* res = (result *) calloc(num, sizeof(result));
     
     // now str = "100..01"
     
     int found = 0;
     
     // loop until find all
     printf("Case #1:\n");
 
     while (found < num) {
         //printf("testing %s, found %d, num %d\n", str, found, num);
         
         bool hasprime = false;
         unsigned long long int div[9];
         
         for (int base=2; base<11; base++) {
             unsigned long long int thisnum = to_base(str, base);
             //printf("#### thisnum %llu\n", thisnum);
             unsigned long long int curr;
             if (thisnum % 2 != 0)
                 curr = is_prime2(thisnum);
             else curr = 2;
             
             //printf("#### base %d, thisnum %llu, curr %llu\n", base, thisnum, curr);
 
             if (curr == 0) {
                 //printf("####**** PRIME FOUND, %llu\n", thisnum);
                 hasprime = true;
                 break;
             }
             else div[base-2] = curr;
         }
         
         // if current didnt have prime, we found it
         // print out
         if (!hasprime) {
             //res[found].str = strdup(str);
             found++;
             
             
             printf("%s ", str);
                 
             for (int k=0; k<9; k++) {
                 printf("%llu ", div[k]);
             }
             printf("\n");
         
         }
         
         // increment second LSB
         incr(str);
         
         
     }
 }

