#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     long int T,N,flag,k,l,i,j,z;
     scanf("%d",&T);
     if(T>=1&&T<=100){
     for(i=0;i<T;i++){
         scanf("%ld",&N);
         if(N>=0&&N<=1000000){
         if(N==0)
             printf("Case #%ld: INSOMNIA\n",i+1);
         else{   int a[10]={15,16,11,12,13,14,15,19,20,10};
                 flag=0;
                 k=1;
             while(flag!=1)
             {
                 l=N*k;
                 j=l;
                 while(l!=0){
                     z=l%10;
                     a[z]=z;
                     l=l/10;
                 }
                 flag=1;
                 for(z=0;z<10;z++)
                 {
                  if(a[z]!=z)
                     flag=0;
                 }
                 k++;
             }
             printf("Case #%ld: %ld\n",i+1,j);
         }
     }
     }
     }
     return 0;
 }

