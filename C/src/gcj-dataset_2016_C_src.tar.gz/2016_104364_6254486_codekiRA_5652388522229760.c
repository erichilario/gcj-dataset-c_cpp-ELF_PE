#include<stdio.h>
 int main() {
 int T,i=1,j=0,flag=1,x;
 long long int N,temp;
 scanf("%d",&T);
 while(i<=T) {
 		flag=1;
 		scanf("%lld",&N);
 		if (0==N) {
 				printf("Case #%d: INSOMNIA\n",i);
 			}
 		else {
 				int hash[10]={0};
 				x=1;
 				while(flag==1) {
 					temp=N*x;
 					flag=0;
 					while(temp) {
 						int d=temp%10;
 						temp=temp/10;
 						if(hash[d]==0) hash[d]=1;
 					}
 					for(j=0;j<10;j++) {
 						if(hash[j]==0) {
 							flag=1;
 							x=x+1;
 							break;
 						}
 					}
 				}
 				printf("Case #%d: %lld\n",i,N*x);
 	}
 	i++;
 }
 }
