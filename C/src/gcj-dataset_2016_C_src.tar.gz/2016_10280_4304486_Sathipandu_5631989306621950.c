#include <stdio.h>
 #include<string.h>
 
 FILE *p,*q;
 
    //fscanf(p,"%ld",&t);
    //fprintf(q," %ld",t);
 
 int main(void) 
 {
 	int t,i,j,l,n;
 	
 	p=fopen("input","r+");
 	q=fopen("output","w+");
 	fscanf(p,"%d",&t);
 	for(i=1;i<=t;i++)
 	{
 		char s[1001],a[1001],b[1001];
 		fscanf(p,"%s",s);
 		l=strlen(s);
 		a[0]=s[0];
 		a[1]='\0';
 		for(j=1;j<l;j++)
 		{
 			b[0]=s[j];
 			b[1]='\0';
 			//printf("%s",b);
 			if(b[0]>=a[0])
 			{
 				strcat(b,a);
 				strcpy(a,b);
 			}
 			else
 			{
 				strcat(a,b);
 			}
 		}
 		
 		fprintf(q,"Case #%d: %s\n",i,a);
 		
 		
 	}
 	return 0;
 }
