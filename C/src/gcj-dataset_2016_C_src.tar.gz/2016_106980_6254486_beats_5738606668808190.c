#include <stdio.h>
 #include <math.h>
 
 void generateCoins(int n, int j);
 void binaryRep(unsigned long num, int *bits, int len);
 int isValidCoin(int *bits, int n, unsigned long *divs);
 unsigned long getDecimal(int base, int *bits, int len);
 unsigned long getDiv(unsigned long num);
 
 int main()
 {
 	int i, n, j, testCases;
 
 	scanf("%d", &testCases);
 
 	for(i = 1; i <= testCases; i++)
 	{
 		printf("Case #%d:\n", i);
 
 		scanf("%d%d", &n, &j);
 		generateCoins(n, j);
 	}
 
 	return 0;
 }
 
 void generateCoins(int n, int j)
 {
 	unsigned long i;
 	unsigned long coins;
 	int k, count = 0;
 	int bits[n];
 	unsigned long divs[9];
 
 	bits[0] = 1;
 	bits[n - 1] = 1;
 
 	coins = pow(2, n - 2);
 
 	for(i = 0; i < coins; i++)
 	{
 		for(k = 1; k < n - 1; k++)
 			bits[k] = 0;
 
 		binaryRep(i, bits, n);
 
 		if(isValidCoin(bits, n, divs))
 		{
 			for(k = 0; k < n; k++)
 				printf("%d", bits[k]);
 
 			for(k = 0; k < 9; k++)
 				printf(" %lu", divs[k]);
 
 			printf("\n");
 			count++;
 
 			if(count == j)
 				break;
 		}
 	}
 }
 
 void binaryRep(unsigned long num, int *bits, int len)
 {
 	int bit;
 
 	len = len - 2;
 
 	while(num)
 	{
 		bit = num % 2;
 		num = num / 2;
 
 		bits[len--] = bit;
 	}
 }
 
 int isValidCoin(int *bits, int n, unsigned long *divs)
 {
 	int i, j = 0;
 	unsigned long num, div;
 
 	for(i = 2; i <= 10; i++)
 	{
 		num = getDecimal(i, bits, n);
 		div = getDiv(num);
 
 		if(div == -1)
 			return 0;
 		else
 			divs[j++] = div;
 	}
 
 	return 1;
 }
 
 unsigned long getDecimal(int base, int *bits, int len)
 {
 	int i;
 	unsigned long j;
 	unsigned long num = 0;
 
 	j = 1;
 
 	for(i = len - 1; i >= 0; i--)
 	{
 		num = num + bits[i] * j;
 		j = j * base;
 	}
 
 	return num;
 }
 
 unsigned long getDiv(unsigned long num)
 {
 	unsigned long i;
 	unsigned long temp = sqrt(num);
 
 	for(i = 2; i <= temp; i++)
 	{
 		if((num % i) == 0)
 				return i;
 	}
 
 	return -1;
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

