#include<stdio.h>
 struct keyword
 {
     char b[100];
 }word[100];
 int main()
 {
     int t,l=0,k=0,tmp,i,j;
     char s[100];
     FILE *r;
     scanf("%d",&t);
         r=fopen("abcd.txt","r");
         for(i=0;(fscanf(r,"%s",&word[i].b))!=EOF;)
         {
             i++;
         }
         fclose(r);
         while(t>0)
         {
             k=0;
         strcpy(s,word[l].b);
         for(i=strlen(s)-1;i>=0;i--)
         {
             if(s[i]=='-')
             {
                 k++;
                 for(j=i;j>=0;j--)
                 {
                     if(s[j]=='-')
                         s[j]='+';
                     else
                         s[j]='-';
                 }
             }
         }
         printf("Case #%d: %d\n",101-t,k);
         l++;
         t--;
     }
 }

