#include<stdio.h>
 #include<math.h>
 #include<string.h>
 
 int sum(int *a) {
   int sum = 0;
   for(int i = 0; i < 10; i++) {
     sum = sum + a[i];
   }
   return sum;
 }
 
 int main() {
   int t;
   scanf("%d", &t);
   for(int j = 1; j <= t; j++) {
     int a;
     scanf("%d", &a);
     int count[10];
     for(int i = 0; i < 10; i++)
       count[i] = 0;
     int i = 1, ans;
     if(a == 0) {
       printf("Case #%d: INSOMNIA\n", j);
     }
     else { 
       while(sum(count) != 10) {
 	int temp = i * a;
 	ans = temp;
 	while(temp > 0) {
 	  int n = temp % 10;
 	  count[n] = 1;
 	  temp = temp / 10;
 	}
 	i++;
       }
       printf("Case #%d: %d\n", j, ans);
     }
   }
 }

