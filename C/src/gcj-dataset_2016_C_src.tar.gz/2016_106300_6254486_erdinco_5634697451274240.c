#include <stdio.h>
 #include <stdlib.h>
 
 
 
 void main()
 {
 	int i,T,j,len, flip, counter;
 	char S[101];
 	FILE *infile, *outfile;
 	int index[100];
 	
 	infile = fopen("B-large.in", "r");
 	outfile = fopen("B-large.out", "w");
 
 	fscanf(infile,"%d", &T);
 
 	for (i=0 ; i<T ; i++)
 	{
 		counter = 0;
 		flip = 0;
 		fscanf(infile,"%s", S);
 		j = 0;
 		while(S[j] != 0)
 		{
 			if (S[j] == '-')
 				index[j] = 0;
 			else
 				index[j] = 1;
 			j++;
 		}
 		len = j;
 
 
 		for (j = len ; j>0 ; j--)
 		{
 			if (flip == 0)
 			{
 				if(index[j-1] == 0)
 				{
 					counter++;
 					flip = 1;
 				}
 			}
 			else if (flip == 1)
 			{
 				if(index[j-1] == 1)
 				{
 					counter++;
 					flip = 0;
 				}
 			}
 		}
 		fprintf(outfile, "Case #%d: %d\n", i+1, counter);
 
 
 		
 	}
 
 	fclose(infile);
 	fclose(outfile);
 
 }
