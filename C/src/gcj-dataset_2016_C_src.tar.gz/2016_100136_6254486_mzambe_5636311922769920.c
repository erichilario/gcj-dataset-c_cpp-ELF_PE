/*
  * =====================================================================================
  *
  *       Filename:  foo.c
  *
  *    Description:  
  *
  *        Version:  1.0
  *        Created:  04/09/2016 04:47:23 PM
  *       Revision:  none
  *       Compiler:  gcc
  *
  *         Author:  YOUR NAME (), 
  *   Organization:  
  *
  * =====================================================================================
  */
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 int main(){
   int i, j, k, l;
   int T, K, C, S, M;
   int count;
   scanf("%d\n", &T);
 
   for( i = 1; i <= T; i++ ){
     scanf("%d %d %d\n", &K, &C, &S);   
 
     printf("Case #%d:", i);
 
     for( j = 1; j <= S; j++ )
       printf(" %d", j);
 
     printf("\n");
   }
 
   return 0;
 }
 

