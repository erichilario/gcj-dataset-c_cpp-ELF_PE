#include <stdio.h>
 #include <string.h>
 
 
 
 int main(void){
 
 
 
 	int t;
 	scanf("%d", &t);
 	for(int i = 0; i < t; i++){
 		char str[100];
 		for(int j = 0; j<100; j++) str[j] = 0;
 		scanf("%s",str);
 		int count = 1;
 		//char *c = str;
 		char temp = str[0];
 		for(int x = 0; str[x] != 0; x++){
 			if(str[x] != temp){
 				temp = str[x];
 				count++;
 			}
 		}
 		if(str[strlen(str)-1] == '+') count--;
 		printf("Case #%d: %d\n", i+1, count);
 		
 
 	}
 
 
 
 
 
 
 return 0;
 }
 
 
 
 
 
 

