#include <stdio.h>
 
 void reset (int values[10])
 {
    int i;
    for (i = 0; i < 10; i++)
       values[i] = 0;
 }
 
 int isCompleted(int values[10])
 {
    int i;
    for (i = 0; i < 10; i++)
       if (values[i] == 0)
          return 0;
 
    return 1;
 }
 
 void main(int argc, char * argv[])
 {
    int i, j, ans;
    int t, n;
    int readed[10];
 
    scanf("%d", &t);
    for(i = 0; i < t; i++)              // Test cases.
    {
       printf("Case #%d: ", i+1);
       scanf("%d", &n);
       reset(readed);
 
       if (n == 0)
          printf("INSOMNIA\n");
       else
       {
          j = 1;
          ans = n;
          do
          {
             n = ans * j;
 
             while(n > 9)
             {
                readed[n%10] = 1;
                n /= 10;
             }
             readed[n] = 1;
             j++;
          } while (!isCompleted(readed));
          printf("%d\n", ans * (j-1));
       }
    }
 }

