#include <stdio.h>
 
 
 void setZero(int arr[]){
 
 	int i = 0;
 	for(i = 0; i < 10; i++){
 		arr[i] = 0;
 	}
 }
 int checkYes(int arr[]){
 	int t = 0;
 	int s = 0;
 	for(t = 0; t < 10; t++){
 		if(arr[t]==1) s++;			
 	}
 	if(s == 10) return 1;
 	else return 0;
 }
 
 int main(){
 	int examples = 0;
 	fscanf(stdin, "%d", &examples);
 	int numbers[10];
 	int theNumber = 0;//dont think i will need
 	int current = 0;
 	int i = 0;
 	int work = 0;
 	int z = 0;
 	int track = 0;
 	for(i = 0; i < examples; i++){
 		fscanf(stdin, "%d", &current);
 		if(current == 0) fprintf(stdout, "Case #%d: INSOMNIA\n", i+1);
 		else{
 		setZero(numbers);
 		track = 1;
 		work = current;
 		while(1==1){
 
 
 			////////////////
 			for(z = 1; z <= current; z*=10){
 				theNumber = (current / z) % 10;
 				numbers[theNumber]  = 1;
 			
 			} 
 			if(checkYes(numbers) == 1) break;
 			track++;
 			current = track * work;
 
 		}		
 		fprintf(stdout, "Case #%d: %d\n", i + 1, current);
 
 		}
 	}
 	return 0;
 
 }
