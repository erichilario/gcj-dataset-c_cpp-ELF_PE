#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
     int T;
     long long i,cas,N,temp,pro;
     scanf("%d",&T);
     int a[11],count=0;
     cas=0;
     while(T--)
     {
     	for(i=0;i<=10;i++)
         a[i]=0;
         count=0;
         cas++;
         scanf("%lld",&N);
         pro=2;
         temp=N;
         if(N==0)
         	printf("Case #%lld: INSOMNIA\n",cas);
         if(N!=0)
         {
             while(count<10)
             {
             while(N>0)
             {
 
                 if(a[N%10]==0)
                     {count++;
                     a[N%10]++;}
                 N=N/10;
             }
                 N=pro*temp;
                 pro++;
             }
             printf("Case #%lld: %lld\n",cas,(pro-2)*temp);
         }
     }
     return 0;
 }

