
 #include<stdio.h>
 #include<stdbool.h>
 #include<time.h>
 #define D(x)            printf("-> %d\n", x);
 #define PLIM            65536
 #define pc              __builtin_popcount
 typedef long long int LL;
 typedef unsigned int ui;
 
 ui oddSet, EvenSet;
 int dvxr[] = {0, 0, 3, 2, 5, 2, 7, 2, 9, 2, 11};
 int plist[6550], indx;
 bool sts[PLIM+11];
 
 bool AC(ui x)
 {
     if(pc(x) & 1) return false;
     if(pc(x&oddSet) != pc(x&EvenSet)) return false;
     return true;
 }
 
 int main()
 {
     freopen("c:\\Users\\User\\Desktop\\out.txt", "w", stdout);
     //double start = clock();
     puts("Case #1:");
 
     int i, j, k, N = 32;
     int J = 500;
     ui cur;
 
     for(i = 2; i <= PLIM; i++)
         if(!sts[i])
         {
             plist[++indx] = i;
             for(j = i; j <= PLIM; j+= i)
                 sts[j] = true;
         }
 
     for(i = 0; i < N; i+=2) oddSet |= (1 << i);
     for(i = 1; i < N; i+=2) EvenSet |= (1 << i);
 
     cur = (1 << (N-1)) + 1;
     while(J)
     {
         if(AC(cur))
         {
             J--;
             for(i = N-1; i >= 0; i--) printf("%d", (bool) (cur & (1 << i)));
             for(i = 2; i <= 10; i++) printf(" %d%s", dvxr[i], i == 10? "\n":"");
         }
         if(!J) break;
         cur += 2;
     }
 
     //printf("%0.10f\n", (clock()-start)/CLOCKS_PER_SEC);
     return 0;
 }

