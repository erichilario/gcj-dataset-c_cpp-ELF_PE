#include <stdio.h>
 #include <string.h>
 
 
 int howMany(char arr[]){ //returns number of +- in arr abcdef = 6
 	int count = 0; //either \0 or \n
 	while(arr[count] != '\0'){
 		count++;
 	} 
 
 	return count;
 }
 int countNext(int from, int size, char arr[]){ //returns index of next change
 	int i = 0;
 
 	for(i = from; i < size; i++){
 		if(arr[i] != arr[i+1]){
 			i++;
 			break;
 		}
 	}
 
 	return i;
 }
 int flip(char enough[], int size){ //returns 1 if -+, 2 if +-, 0 if no change
 	int i = 0;
 	int flipped = 0;
 	int k = 0;
 	int to = 0;
 	i = countNext(0, size, enough); //i would = to index of next so ---+, i ==3
 	if(i == size) return 0;
 	else if(enough[0] == '+') flipped = 2;
 	else if(enough[0] == '-') flipped = 1;
 	to = countNext(i, size, enough);
 	for(k = 0; k < to; k++)
 		enough[k] = '+';
 	//printf("%d\n", k);
 	return flipped;
 }
 
 
 int main(){
 	int examples = 0;
 	fscanf(stdin, "%d", &examples);
 	int sizeN = 0;
 	int i = 0;
 	int flips = 0;
 	int dummy = 0;
 	char enough[102];
 	for(i = 0; i < examples; i++){
 		memset(enough,'0',102);
 		fscanf(stdin, "%s", enough);
 		sizeN = howMany(enough); //size of string.
 		flips = 0;
 		if(enough[0] == '+' && countNext(0, sizeN, enough)==(sizeN)) 
 			flips = 0;
 		else if(enough[0] == '-' && countNext(0, sizeN, enough)==(sizeN))
 			flips = 1;
 		else{
 			while((dummy=flip(enough,sizeN))!=0){
 				flips+=dummy;
 
 				
 			}
 				
 		}
 		fprintf(stdout, "Case #%d: %d\n", i + 1, flips);	
 	}
 	return 0;
 
 }
