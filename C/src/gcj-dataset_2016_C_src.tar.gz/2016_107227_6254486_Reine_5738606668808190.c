#include<stdio.h>
 #include<math.h>
 
 int N = 0;
 long long iscomposite(long long n){
 	long long i = 0;
 	long double X;
 
 	if(n < 100000000000000) X = sqrt(n);
 	else X = pow(10,8);
 	
 	for(i = 2; i <= X; i++){
 		if(!(n%i)) return i;
 	}
 
 	return 0;
 }
 
 long long nbase(int *jamcoin, int base){
 	long long n = 0;
 	long long p = 0;
 	int i = 0;
 	for(p = pow(base,N-1), i = 0; p; p /= base, i++){
 		n += jamcoin[i] * p;
 	}
 	return n;
 }
 
 int main(){
 	int T = 0;
 	scanf("%d", &T);
 
 	int i = 0;
 	for(i = 0; i < T; i++){
 		printf("Case #%d:\n", i + 1);
 		int J = 0;
 		scanf("%d %d", &N, &J);
 		
 		long long j = 0;
 		int jamcoin[100];
 		int counter = 0;
 		for(j = pow(2,N-1) + 1; j < pow(2,N) && counter != J; j += 2){
 			
 			long long factors[10];
 			if(!(factors[0] = iscomposite(j))) continue;
 
 			int k = 0;
 			long long temp = j;
 			for(k = N-1; k >= 0; k--, temp /= 2){
 				jamcoin[k] = temp%2;			
 			}	
 
 			int isjamcoin = 1;
 			int b = 0;
 			for(k = 3, b = 1; k < 11; k++, b++){
 				long long n = nbase(jamcoin,k);
 				if(!(factors[b] = iscomposite(n))) { 
 					isjamcoin = 0;
 					break;
 				}				 
 			}	
 
 			if(!isjamcoin) continue;
 			for(k = 0; k < N; k++){
 				printf("%d", jamcoin[k]);
 			}
 			for(k = 0; k < 9; k++){
 				printf(" %llu", factors[k]);
 			}
 			puts("");
 			counter++;
 		}
 	}
 	return 0;
 }

