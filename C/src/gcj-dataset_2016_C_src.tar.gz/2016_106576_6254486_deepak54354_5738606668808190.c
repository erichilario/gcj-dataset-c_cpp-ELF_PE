#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <stdint.h>
 #include <math.h>
 #include <inttypes.h>
 #define __STDC_FORMAT_MACROS
 #define BYTE uint64_t
 
 BYTE convert (BYTE number,int base);
 BYTE generate(BYTE number, int arr[]);
 int check_for_prime(BYTE number);
 int t, S, j;
 int main()
 {
     scanf("%d %d %d", &t, &S, &j);
     int jam_coins = 0;
     int arr[S];
     BYTE number;
     BYTE numbers[50];
     int divisor[9];
     bool flag;
     BYTE temp;
     arr[0] = 1; arr[S-1] = 1;
         for (int count = 0 ;jam_coins < j ; count++)
         {
             number = generate(count,arr);
             for(int i = 2; i <= 10; i++)
             {
                 temp = convert(number, i);
                 divisor[i-2] = check_for_prime(temp);
             }
             for (int i = 0; i < 9; i++)
             {
                 if(divisor[i] == 0)
                 {
                     flag  = false;
                     break;
                 }
                 flag = true;
             }
             if(flag)
             {
                 if (jam_coins == 0)
                     printf("Case #1:\n");
                 jam_coins++;
                 numbers[jam_coins-1] = number;
                 printf("%"PRIu64" ", numbers[jam_coins-1]);
                 for (int c = 0; c < 9; c++)
                 {
                     printf("%d ", divisor[c]);
                 }
                 printf("\n");
             }
         }
 
     return 0;
 }
 BYTE convert(BYTE number,int base)
 {
     if(number == 0 || base == 10)
         return number;
 
     BYTE sum = 0;
     int temp;
     for (int i = 0; i < S; i++)
     {
       temp = number%10;
       sum += temp * pow(base,i);
       number = number / 10;
     }
     return sum;
 }
 
 BYTE generate(BYTE number, int arr[])
 {
     int rem;
     int s = S-2;
     for (int i = 0; i < s; i++)
     {
         if (number == 0)
         {
             arr[s-i] = 0;
             continue;
         }
         rem = number%2;
         number /= 2;
         arr[s-i] = rem;
     }
     BYTE sum = 0;
     BYTE power = 1;
     for(int i = 0; i < S; i++)
     {
         sum += arr[S-i-1]*power;
         power *= 10;
     }
     return sum;
 }
 
 int check_for_prime(BYTE number)
 {
     for(int i = 2; i < 1001; i++)
     {
         if(number % i == 0)
         {
             return i;
         }
     }
     return 0;
 }

