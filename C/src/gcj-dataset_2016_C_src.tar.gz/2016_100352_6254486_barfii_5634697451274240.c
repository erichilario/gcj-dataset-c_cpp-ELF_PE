#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
 char a[100],swap;
 int T,s,i,c=0,k,l,j,z,t=0;
 scanf("%d",&T);
 if(T<1)
 exit(0);
 if(T>100)
 exit(0);
 while(T)
 {
 s=0;
 scanf("%s",a);
 while(a[s]!='\0')
 {s++;}
 if(s<1)
 exit(0);
 if(s>10)
 exit(0);
 for(i=0;i<s;i++)
 {
 if(a[i]!='-' && a[i]!='+')
 exit(0);
 }
 for(i=s-1;i>0;i--)
 {
 if(a[i]=='-')
 {
 if(a[0]=='+')
 {
 a[0]='-';
 c++;
 }
 for(j=0;j<=i;j++)
 {
 if(j==0)
 c++;
 if(a[j]=='-')
 a[j]='+';
 else if(a[j]=='+')
 a[j]='-';
 }
 k=0;
 l=i;
 while(k<l)
 {
 swap=a[k];
 a[k]=a[l];
 a[l]=swap;
 k++;
 l--;
 }
 }
 }
 if(a[0]=='-')
 {c++;
 a[0]='+';
 }
 t++;
 printf("Case #%d: %d\n",t,c);
 c=0;
 T--;
 }
 return 0;
 }

