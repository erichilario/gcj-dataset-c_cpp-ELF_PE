#include<stdio.h>
 #include<fstream>
 int main()
 {
     long long int n,ans,i,temp,flag,k,j;
     int t,arr[10],c;
     scanf("%d",&t);
     c=1;
     file *
     while(t--)
     {
         scanf("%lld",&n);
         for(i=0;i<10;i++)
         {
             arr[i]=0;
         }
         flag=0;
         i=1;
         while(i<99 && !flag)
         {
             ans=temp=i*n;
             while(temp)
             {
                 k=temp%10;
                 arr[k]=1;
                 temp/=10;
             }
             i++;
             flag=1;
             for(j=0;j<10;j++)
             {
                 if(arr[j]==0)
                 {
                     flag=0;
                 }
             }
         }
         if(flag==1)
         {
             printf("Case #%d: %lld\n",c,ans);
         }
         else
         {
             printf("Case #%d: INSOMNIA\n",c);
         }
         c++;
     }
     return 0;
 }

