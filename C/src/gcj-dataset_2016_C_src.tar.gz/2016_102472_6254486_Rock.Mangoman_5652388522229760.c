#include<stdio.h>
 void reset(void);
 void calc(int q);
 int search(int x);
 int arr[10],c;
 int main()
 {
    long int i,n,p,t,q,l;
     scanf("%d",&t);
     for(i=1;i<=t;i++)
     {
         scanf("%d",&n);
         p=1;
         c=0;
         l=-1;
         reset();
         while(1)
     {
             q=p*n;
             calc(q);
             if(c>=10)
             {
                 l=q;
                 printf("\nCase #%d: %d",i,l);
                 break;
             }
             else if(p>=5 && c>0 && l==q)
             {
                 printf("\nCase #%d: INSOMNIA",i);
                 break;
             }
             l=q;
             p++;
         }
     }
 
 }
 
 void reset(void)
 {
     int i;
     for(i=0;i<10;i++)
         arr[i]=-1;
 }
 
 
 void calc(int q)
 {
     int rem,i;
     if(!q)
     {
         arr[c++]=rem;
     }
     else
     {
         while(q)
         {
             rem=q%10;
             if(!search(rem))
             {
                 arr[c++]=rem;
             }
             q=q/10;
         }
     }
 }
 
 
 int search(int x)
 {
     int i;
     for(i=0;i<=c;i++)
     {
         if(arr[i] ==  x)
             return(1);
 
     }
     return(0);
 }

