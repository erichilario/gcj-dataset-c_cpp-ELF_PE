#include<stdio.h>
 
 int check(int count[]){
     int i;
     for(i=0; i<10; i++){
         if(count[i]==0)
             return 1;
     }
     return 0;
 }
 
 int main(){
     int i,t,n,count[10],digit,c,last_digit,j;
     scanf("%d",&t);
     j=1;
     while(j<=t){
         for(i=0; i<10; i++){
             count[i]=0;
         }
         scanf("%d",&n);
         if(n==0)
             printf("Case #%d: INSOMNIA\n",j);
         else{
             c=n;
             i=2;
             while(check(count)){
                 last_digit=c;
                 while(c){
                     digit=c%10;
                     count[digit]=1;
                     c/=10;
                 }
                 c=i*n;
                 i++;
             }
             printf("Case #%d: %d\n",j,last_digit);
         }
         j++;
     }
     return 0;
 }

