#include <stdio.h>
 #include <stdlib.h>
 
 int calculateIteration(int c[10], int number,int it){
     int num = number*it;    
     int digit ;
     while(num>0){
         digit=num%10;
         c[digit]=1;
         num=num/10;        
     }
     for(int i=0;i<10;i++){
         if(c[i]!=1) break;
         if(i==9) return it*number;
     }
     calculateIteration(c, number, it+1);    
 }
 
 int main()
 {
     FILE *input = fopen("A.in","r");
     FILE *output = fopen("./A.out","w");
     
     int numberTest;
     //numberTest = read(input)
     fscanf(input,"%d",&numberTest);
     int testcase;
     //printf("number of cases are %d \n", numberTest);
     static int vue[10] ;
     for(int i=0;i<numberTest;i++){
         fscanf(input,"%d",&testcase);
         if(testcase==0){
             fprintf(output,"Case #%d: INSOMNIA\n",i+1);
             continue;
         }
         for(int i=0;i<10;i++){
             vue[i]=0;
         }
         
         fprintf(output,"Case #%d: %d\n",i+1,calculateIteration(vue, testcase,1));
     }
     for(int i=0;i<10;i++){
             vue[i]=0;
         }
     //printf("Case #%d: %d\n",1,calculateIteration(vue, 140,1));
     fclose(input);
     fclose(output);
     return 0;
 }
 

