#include <stdio.h>
 #include<string.h>
 
 int main()
 {
     int count,i,j,t,k;
     char str[11];
     scanf("%d",&t);
     
     for(k=1;k<=t;k++)
     {
       count=0;
     
     scanf("%s",str);
     
     while(1)
     {
     i=0;
     while(str[i]==str[i+1])
        i++;
      
         
         if(i==(strlen(str)-1))
           break;
         
     for(j=0;j<=i;j++)
      {
         if(str[j]=='+')
           str[j]='-';
         else
            str[j]='+';
          
      }
        
       
         count++;
         
     }
     
     if(str[i]=='-')
        printf("Case #%d: %d\n",k,count+1);
     else
         printf("Case #%d: %d\n",k,count);
 
     }     
         
     return 0;
 }
 

