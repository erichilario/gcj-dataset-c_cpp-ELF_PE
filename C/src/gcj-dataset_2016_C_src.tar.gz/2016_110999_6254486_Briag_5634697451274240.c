#include <stdio.h>
 
 FILE * openIn() {
     FILE * pFile;
 
     pFile = fopen ("in","r+");
     return pFile;
 }
 
 
 FILE * out;
     
 int caseIndex = 1;
 void printResult(int result) {
     fprintf(out,"Case #%d: %d\n", caseIndex, result);
     caseIndex++;
 }
 
 int check(char data[], int size) {
     
     for(int i = 0; i < size; i++) {
         if(data[i] != '+')
             return 0;
     }
     
     return 1;
 }
 
 
 void flipfirst(char data[]) {
     
     char comp = data[0];
     
     for(int i = 0; data[i] == comp; i++) {
         if(comp == '+')
             data[i] = '-';
         else
             data[i] = '+';
     }
     
     
 }
 
 void compute(char data[], int size) {
 
     int result = 0;
     
     while(!check(data,size)) {
         result++;
         flipfirst(data);
     }
     printf("%s\n", data);
     printResult(result);
 
     
     
 }
 
 int main() {
     
     
     out = fopen ("out","w+");
     FILE * pDataFile = openIn();
     
     int N;
     char data[101];
     
     fscanf (pDataFile, "%i", &N);
     
     for(int i = 0; i < N; i++) {
         
         fscanf (pDataFile, "%s", &data);
         compute(data, strlen(data));
     }
     
     fclose (pDataFile);
     
     return 0;
 }

