#include<stdio.h>
 #include<string.h>
 int main()
 {
 	int t=0,i=0,j;
 	char s[11];
 	scanf("%d",&t);
 	for(j=1;j<=t;j++){
 		int p=0,n=0;
 		scanf("%s",s);
 		int ns = strlen(s);
 		char c=(s[0]=='+'?'+':'-');
 		for(i=0;i<ns;i++){
 			if(s[i]==c){
 				if(c=='+'){
 					p++;
 					c='-';
 				}
 				else{
 					n++;
 					c='+';
 				}
 			}
 		}
 		printf("Case #%d: %d\n",j,(s[ns-1]=='+')?(n+p-1):(n+p));
 	}
 	return 0;
 }

