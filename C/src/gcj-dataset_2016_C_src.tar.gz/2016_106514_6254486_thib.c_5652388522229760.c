
 #include <stdio.h>
 #include <stdlib.h>
 
 void setTab(int *tab){
 	int k;
 	for (k=0;k<10;k++)
 		tab[k]=0;
 }
 
 void remp(int *tab, int m){
 	while (m>0){
 		tab[m%10]=1;
 		m=m/10;
 	}
 }
 
 char estRemp(int * tab){
 	int k;
 	for (k=0;k<10;k++){
 		if (tab[k]==0)
 			return 0;
 	}
 	return 1;
 }
 
 int solve(int N){
 	int m=N, i=1, tab[10];
 	setTab(tab);
         remp(tab, m);
         while (!estRemp(tab)){
                 i++;
                 m=i*N;
                 remp(tab, m);
                 if (i>1000)
                         return -1;
         }
         return m;
 }
 
 int getNumb(FILE *f){
 	int n=0;
 	char k=fgetc(f);
 	if (k==EOF)
 		return -1;
 	while (k<='9' && k>='0'){
 		n=10*n+(k-'0');
 		k=fgetc(f);
 	}
 	return n;
 }
 
 int main(int argc, char ** argv){
 	FILE *f, *g;
 	int cas=1, N, res;
 	char fin=0;
 	if (argc!=2){
 		printf("Usage : %s file\n", argv[0]);
 		return EXIT_FAILURE;
 	}
 	f=fopen(argv[1], "r");
 	g=fopen("out", "w");
 	if (f==NULL || g==NULL){
 		printf("Erreur fichier\n");
 		return EXIT_FAILURE;
 	}
 	N=getNumb(f);
 	while (!fin){
 		N=getNumb(f);
 		if (N==-1)
 			fin=1;
 		else {
 			res=solve(N);
 			if (res==-1)
 				fprintf(g, "Case #%i: INSOMNIA\n", cas);
 			else
 				fprintf(g, "Case #%i: %i\n", cas, res);
 			cas++;
 		}
 	}
 	fclose(g);
 	fclose(f);
 	return EXIT_SUCCESS;
 }
 

