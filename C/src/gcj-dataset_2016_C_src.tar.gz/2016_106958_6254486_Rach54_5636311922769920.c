#include <stdio.h>
 int main(void) {
     int t,i,k,c,s,j;
     i=1;
     scanf("%d",&t);
     while(i<=t)
     {
         scanf("%d %d %d",&k,&c,&s);
         if(k==s)
         {
             printf("Case #%d: ",i);
             for(j=1;j<=s;j++)
             {
                 printf("%d ",j);
             }
             printf("\n");
         }
         i++;
     }
         
 	// your code goes here
 	return 0;
 }
 

