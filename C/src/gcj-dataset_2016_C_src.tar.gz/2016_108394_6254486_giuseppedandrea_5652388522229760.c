#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 #define INPUT_FILE "A-large.in"
 #define OUTPUT_FILE "output"
 
 
 int main()
 {
     FILE *fp_in, *fp_out;
 
     int T, n_digit, current_digit, N, n, x, increment;
     int i,k;
     int digit[10];
     int asleep, flag;
 
     fp_in=fopen(INPUT_FILE,"r");
     fp_out=fopen(OUTPUT_FILE,"w");
 
     fscanf(fp_in,"%d",&T);
 
     for(i=0;i<T;i++)
     {
         asleep=1;
         increment=1;
         for(k=0;k<10;k++)
             digit[k]=0;
 
         fscanf(fp_in,"%d",&N);
 
         if(N==0)
         {
             fprintf(fp_out,"Case #%d: INSOMNIA\n",i+1);
         }else
         {
             while(asleep)
             {
                 n=N*increment;
                 x=n;
                 n_digit=floor(log10(abs(n)))+1;
                 for(k=0;k<n_digit;k++)
                 {
                     current_digit=n%10;
                     digit[current_digit]++;
                     n/=10;
                 }
 
                 flag=1;
                 for(k=0;k<10 && flag;k++)
                 {
                     if(!digit[k])
                         flag=0;
                 }
                 if(flag)
                     asleep=0;
 
                 increment++;
             }
             fprintf(fp_out,"Case #%d: %d\n",i+1,x);
         }
     }
     fclose(fp_in);
     fclose(fp_out);
 
     exit(EXIT_SUCCESS);
 }

