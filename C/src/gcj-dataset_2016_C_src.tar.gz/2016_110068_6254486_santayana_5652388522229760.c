#include<stdio.h>
 int digit[10];
 int main() {
     long long int n , t , i , j , m , s , k;
     scanf("%lld" , &t);
     for(j=1 ;j<=t; ++j){
         for(i=0 ;i<10 ;++i)
             digit[i] = 0;
         s = 0 ;
         scanf("%lld" , &n);
         if( n==0 )
             printf("Case #%lld: INSOMNIA\n" , j);
         else {
            i = 1;
            while(s==0){
             m = i*n ;
             while(m!=0){
                 digit[m%10] = 1 ;
                 m/=10;
             }
             s = 1;
             for( k=0 ; k<10 ;++k)
                 if(digit[k]==0)
                 {  s = 0;i++;
                     break; }
            }
            printf("Case #%lld: %lld\n" , j , i*n);
         }
     }
     return 0;
 }

