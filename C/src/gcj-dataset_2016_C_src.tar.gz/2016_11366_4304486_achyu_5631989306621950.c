#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 int main(){
 	int T,i;
 	scanf("%d",&T);
 	for(i=1;i<=T;i++){
 		char a[10000],result[10000],temp[10000];
 		int j;
 		scanf("%s",a);
 		for(j=0;j<strlen(a);j++){
 			int k;
 			if(result[0]=='\0' || result[0] <= a[j]){
 				temp[0] = a[j];
 				for(k=1;k<=strlen(result);k++)
 					temp[k]=result[k-1];			
 			}
 			else{
 				for(k=0;k<strlen(result);k++)
 					temp[k]=result[k];
 				temp[k] = a[j];
 			}
 			strcpy(result,temp);			
 			for(k=0;k<10000;k++)
 				temp[k]='\0';
 		}
 		printf("Case #%d: %s\n",i,result);
 		for(j=0;j<10000;j++)
 			result[j]='\0';
 		for(j=0;j<10000;j++)
 			a[j]='\0';
 	}
 	return  0;
 }

