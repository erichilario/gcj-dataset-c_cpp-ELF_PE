#include <stdio.h>
 int main()
 {
     int test,i,j,k,a[10],flag=0;
     long long int n,lastn,ans;
     scanf("%d",&test);
     for(i=0;i<test;i++)
     {
         for(j=0;j<10;j++)
             a[j]=0;
         scanf("%lld",&n);
         if(n==0)
             printf("Case #%d: INSOMNIA\n",i+1);
         else
         {
             for(j=1;;j++)
             {
                 flag=0;
                 ans=lastn=n*j;
                 while(lastn>0)
                 {
                     if(a[lastn%10]==0)
                         a[lastn%10]=1;
                     lastn=lastn/10;
                 }
                 for(k=0;k<10;k++)
                 {
                     if(a[k]==0)
                     {
                         flag=1;
                         break;
                     }
                 }
                 if(flag==0)
                 {
                     break;
                 }
             }
             printf("Case #%d: %lld\n",i+1,ans);
         }
     }
     return 0;
 }
