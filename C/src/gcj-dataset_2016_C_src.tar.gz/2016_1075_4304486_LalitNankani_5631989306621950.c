#include <stdio.h>
 #include <string.h>
 
 int mstrcmp(char *a, char *b) {
   for(int i = 0; i < strlen(a) && i < strlen(b); ++i) {
     if(a[i] > b[i]) {
       return 1;
     }
     else if (a[i] > b[i]) {
       return 0;
     }
    
   }
   return 0;
 }
 
 int main() {
   int t;
   fscanf(stdin, "%d", &t);
   for(int tt = 0; tt<t; ++tt) {
     char s[1000], a[1000], b[1000];
     fscanf(stdin, "%s", s);
     int x, l;
     x = 0;
     l = 0;
     a[x++] = s[0];
     a[x] = 0;
     for(int i = 1; i < strlen(s);++ i) {
       b[l++] = s[i];
       b[l] = 0;
       if(mstrcmp(a, b)) {
 	strcat(a, b);
 	b[0] = 0;
 	l = 0;
       }
       else {
 	strcat(b, a);
 	strcpy(a, b);
 	b[0] = 0;
 	l = 0;
       }
     }
     fprintf(stdout, "Case #%d: %s\n", tt+1, a);
   }
   return 0;
 }

