#include <stdio.h>
 #include <string.h>
 
 int main(){
 
 	int t,cases=1,len,max,min,i;
 	char ans[2010],str[2010];
 	scanf("%d",&t);
 
 	while (cases <= t){
 
 		scanf("%s",str);
 		len = strlen (str);
 
 		min=1005;i=0;max=1006;
 		ans[min] = str[i++];
 		for (; i< len;i++ ){
 			if (str[i] < ans[min]){
 				max++;
 				ans[max-1] = str[i];
 			}else{
 				min--;
 				ans[min] = str[i];
 			}
 		}
 		ans[max] = '\0';
 
 		printf("Case #%d: %s\n",cases,&ans[min]);
 		cases++;
 	}
 
 
 	return 0;
 }
