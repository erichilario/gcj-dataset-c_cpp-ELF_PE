#include <stdio.h>
 #include <stdlib.h>
 
 int a[10], dc;
 void addAllDigits(int n)
 {
     int t;
     while(n>0)
     {
         t = n % 10;
         n = n / 10;
         if(a[t] == 0)
         {
             a[t] = 1;
             dc++;
         }
     }
 }
 
 int main()
 {
     int t, ti, n, i;
     scanf("%d", &t);
     for(ti=1;ti<=t;ti++)
     {
         for(i=0;i<10;i++)
         {
             a[i] = 0;
         }
         dc = 0;
         i = 1;
         scanf("%d",&n);
         if(n==0)
         {
             printf("Case #%d: INSOMNIA\n",ti);
         }
         else
         {
             while(dc<10)
             {
                 addAllDigits(n*i);
                 i++;
             }
             printf("Case #%d: %d\n",ti,n*(i-1));
         }
     }
     return 0;
 }

