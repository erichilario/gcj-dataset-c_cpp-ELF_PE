#include<stdio.h>
 #include<string.h>
 main()
 {
      FILE *f;
      FILE *i;
      f = fopen ("output_file.txt", "w");
      i = fopen ("B-small-attempt3.in", "r");
     int T,c;
     fscanf(i,"%d",&T);
 
     for(c=0;c<T;c++){
     char s[11]={"\0"};
     int a,x,y,j,change=0;
     fscanf(i, "%s",s);
 
     a= strlen(s);
     for(j=0;j<a;j++)
     {
         if(s[j]!=s[j+1])
             {change++;}
     }
     //printf("%c",s[a-1]);
      if(s[a-1]=='-')
      {
          y=change;
      }
      else
      {
          y=change-1;
      }
      x=c+1;
      printf("Case #%d: %d\n",x,y);
      fprintf(f,"Case #%d: %d\n",x,y);
     }
 }

