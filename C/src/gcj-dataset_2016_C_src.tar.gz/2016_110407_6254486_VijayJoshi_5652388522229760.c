// Problem 1
 #include<stdio.h>
 typedef long long unsigned int LLU;
 typedef long long int LL;
 void solve();
 int flags[11];
 int checkDigits(LLU n) {
      int i;
      while(n!=0) {
        flags[n%10] = 1;
        n/=10;
      }     
      for(i=0;i<10;i++)
       if(!flags[i])
        return 0;
      return 1;
 }
 int main(void)
 {
     LLU T,t,max=0,temp;
 /*    freopen("sample_input.txt","r",stdin);
     freopen("sample_output.txt","w",stdout);
 
     freopen("A-small-attempt0.in","r",stdin);
     freopen("A-small-attempt0_output.txt","w",stdout);
 */
     freopen("A-large.in","r",stdin);
     freopen("A-large_output.txt","w",stdout);
 
     scanf("%llu",&T);
     for(t=1;t<=T;t++)
      {
        printf("Case #%llu: ",t);
        solve();       
        printf("\n");
      }
     return 0;
 }
 void solve()
 {
      LLU N,nameIt;
      int i;
      int _Magic_Number=172;
      scanf("%llu",&N);
      if(N>0) {
           memset(flags,0,sizeof flags);
           for(i=1;i<=_Magic_Number;i++) {
               nameIt=i*N;
               if(checkDigits(nameIt)) {
                  printf("%llu",nameIt);
                  return;
               }
           }
      }
      printf("INSOMNIA");
 }

