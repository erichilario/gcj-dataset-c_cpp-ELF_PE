#include <stdio.h>
 
 int main(int argc, char **argv){
 	int i,j;
 	int t,k,c,s;
 	FILE *f = fopen(argv[1],"r");
 
 	fscanf(f,"%d\n",&t);
 	for(i=0;i<t;i++){
 		fscanf(f,"%d %d %d\n",&k,&c,&s);
 		if(c==1){
 			if(k>s){
 				printf("Case #%d: IMPOSSIBLE\n", i+1);
 			}else{
 				printf("Case #%d: ", i+1);
 				for(j=0;j<k;j++){
 					printf("%d%s",j+1, j==(k-1) ? "\n": " ");
 				} 
 			}
 		}else{
 			if(k==1){
 				printf("Case #%d: 1\n", i+1);
 				continue;
 			}
 			if(s>=(k-1)){
 				printf("Case #%d: ", i+1);
 				for(j=1;j<k;j++){
 					printf("%d%s",j+1, j==(k-1) ? "\n": " ");
 				}
 			}else{
 				printf("Case #%d: IMPOSSIBLE\n", i+1);
 			}
 		}
 	}
 	return 0;
 }

