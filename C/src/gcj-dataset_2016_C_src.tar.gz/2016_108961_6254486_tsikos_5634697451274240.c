//
 //  main.c
 //  Code Jam
 //
 //  Created by Konstantinos Mitropoulos on 9/4/2016.
 //  Copyright (c) 2016 NTUA. All rights reserved.
 //
 
 #include <stdio.h>
 
 int main(int argc, const char * argv[]) {
 
     FILE *fp;
     fp = fopen ("/Users/konstantinos/Desktop/B-small-attempt0.in.txt", "r");
     
     int i = 0, j = 0, T;
     
     fscanf(fp, "%d\n", &T);
 
     for (i = 0; i < T; i++) {
         char S[100] = "", ch;
         j = 0;
         
         while ((ch = fgetc(fp)) != '\n') {
             S[j++] = ch;
         }
         char temp = S[j - 1];
         char temp2 = S[0];
         j = 1;
         int count = 0;
         while (S[j] != '\0') {
             if (S[j] != temp2) {
                 count++;
                 temp2 = S[j];
             }
             j++;
         }
         
         if (temp == '-')   fprintf(stdout, "Case #%d: %d\n", i+1, count+1);
             else fprintf(stdout, "Case #%d: %d\n", i+1, count);
     
     }
         
     fclose(fp);
     return 0;
 }

