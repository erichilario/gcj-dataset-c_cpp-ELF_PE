#include<stdio.h>
 #include<math.h>
 int main(){
 	int m,i,k,c,s,j;
 	FILE *mp,*ni;
 	mp=fopen("D-small-attempt0.in","r");
 	ni=fopen("outputsmall4.txt","w");
 	fscanf(mp,"%d",&m);
 	for(i=0;i<m;i++){
 		fscanf(mp,"%d",&k);
 		fscanf(mp,"%d",&c);
 		fscanf(mp,"%d",&s);
 		fprintf(ni,"Case #%d: ",i+1);
 		for (j=1;j<=k;j++){
 			fprintf(ni,"%d ",j);
 		}
 		fprintf(ni,"\n");
 	}
 	return 0;
 } 

