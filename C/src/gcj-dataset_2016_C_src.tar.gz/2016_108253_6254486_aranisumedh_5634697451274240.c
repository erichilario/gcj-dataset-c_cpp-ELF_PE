#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int calc(char t1, char t2);
 
 int main()
 {
 	int tc;
 	int count = 1;
 	scanf("%d", &tc);
 	while(tc--)
 	{
 		char* istr = (char*)malloc(100*sizeof(char));
 		scanf("%s", istr);
 
 		int i=0;
 		int n =strlen(istr);
 		int res =0;
 		while(i<n-1)
 		{
 			while(*(istr+i)==*(istr+i+1))
 				i++;
 			char t1 = *(istr+i);
 			i+=1;
 			while(*(istr+i)==*(istr+i+1))
 				i++;
 			char t2 = *(istr+i);
 			res+= calc(t1, t2);
 			*(istr+i) = '+';
 		}
 		if(n==1)
 		{
 			if(*(istr)=='-')
 				res=1;
 		}
 		printf("Case #%d: %d\n", count, res);
 		count++;
 	}
 }
 
 int calc(char t1, char t2)
 {
 	if (t2=='+'||t2=='-')
 	{
 		if(t1=='+')
 			return 2;
 		else
 			return 1;
 	}
 	else
 	{
 		if(t1=='+')
 			return 0;
 		else 
 			return 1;
 	}
 }
