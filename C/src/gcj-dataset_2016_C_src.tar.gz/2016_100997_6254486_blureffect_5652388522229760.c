#include <stdio.h>
 int main(void) {
 	long long t,i,m,j,k;
 	scanf("%lld",&t);
 	for(i=0;i<t;i++){
 		long long r[10] = {0},c,n;
 		scanf("%d",&n);
 		if(n==0) {
 			printf("Case #%lld: INSOMNIA\n",i+1);
 			continue;
 		}
 		for(j=1;j<201;j++){
 			m=n*j;
 			c=0;
 			while(m){
 				r[m%10]++;
 				m/=10;
 			}
 			for(k=0;k<10;k++){
 				if(r[k]>0)c++;
 			}
 			if(c==10) break;
 		}
 		
 
 		if(c==10)
 			printf("Case #%lld: %d\n",i+1,n*j);
 		else
 			printf("Case #%lld: INSOMNIA\n",i+1);
 		
 	}
 	return 0;
 }

