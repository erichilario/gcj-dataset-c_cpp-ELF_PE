#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
 int a[10],x,c,m,N,T,i=0,r=0,b=0,j=0,f,h=1;
 scanf("%d",&T);
 if(T<1)
 exit(0);
 if(T>100)
 exit(0);
 while(T)
   {
    scanf("%d",&N);
    if(N<0)
    exit(0);
    for(i=0;i<10;i++)
    a[i]=0;
    j=1;  
    m=0;
    c=0;
    while(1)
     {
      x=N*j;
      f=x;
      b=b+1;
      if(x==N)
       {
         c++;
         if(c>2)
          {
           printf("Case #%d: INSOMNIA\n",h);
           h++;
           break;
          }
       }
      while(x!=0)
       {
        r=x%10;
        a[r]=a[r]+1;
        x=x/10;
        
       }
      for(i=0;i<10;i++)
       {
        if(a[i]==0)
        m++;
       }
      if(m==0){
       printf("Case #%d : %d\n",h,f);
       h++;
       break;
       }
      else
       m=0;
    j++;
    }
   T--;
  }
 return 0;
 }

