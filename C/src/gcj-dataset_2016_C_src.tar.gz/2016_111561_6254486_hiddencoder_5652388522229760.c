#include <stdio.h>
 #include <stdlib.h>
 #define TRUE 1
 #define FALSE 0
 int checkNumber(int num, int numPre[]){
     int temp = 0,i;
     while (num != 0){
         temp = num%10;
         num = num/10;
         numPre[temp] = 1;
      }
      for ( i = 0; i < 10; i++){
          if (numPre[i] == 0)
              return FALSE;
       }
       return TRUE;
 }
 int main(int argc, char **argv)
 {
     FILE * fp, *fpWrite;
     char * line = NULL;
     size_t len = 0;
     ssize_t read;
     int inputSize = 0, number = 0, count =0;
 
     fp = fopen(argv[1], "r");
     if (fp == NULL)
         exit(EXIT_FAILURE);
     fpWrite = fopen("output.txt", "w");
     if (fpWrite == NULL)
         exit(EXIT_FAILURE);
     getline(&line, &len, fp);
     inputSize = atoi(line);
     while ((read = getline(&line, &len, fp)) != -1) {
         count++;
         int insomnia = TRUE;
         number = atoi(line);
         int i= 1, checkNum = 0;
         int numPresent[10] = {0};
         while(TRUE){ 
             checkNum = number * i;
             if (checkNumber(checkNum, numPresent)){
 		insomnia = FALSE;
                 break;
             }
             if (i > 100 && checkNum == number)
                 break; 
             i++;      
         }
         if (insomnia)
             fprintf(fpWrite, "Case #%d: INSOMNIA\n",count);
         else
             fprintf(fpWrite, "Case #%d: %d\n",count, checkNum);
     }
 
     fclose(fp);
     fclose(fpWrite);
     if (line)
         free(line);
     exit(EXIT_SUCCESS);
 }

