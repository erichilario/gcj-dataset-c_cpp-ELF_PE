#include <stdio.h>
 #include <string.h>
 
 FILE *open_input_file(char *filename)
 {
   FILE *fp ;
   fp = fopen(filename, "r") ;
   return fp ;
 }
 
 int get_case_count(FILE *fp) 
 {
   char buffer[1024] ;
   int count ;
 
   fgets(buffer, sizeof(buffer), fp) ;
   count = atoi(buffer) ;
   return count ;
 }
 
 void process_sleep(FILE *fp, int case_count) 
 {
   char buffer[1024] ;
   char num_buf[1024] ;
   int i = 0 , j, k ;
   int digit_count = 0 , start_num = 0, proc_num = 0 ;
   int digit = 0, num_buf_len = 0 ;
   int num_array[10] ;
   char tmp[2] ;
 
   for(i = 0; i < case_count; i++)
   {
     memset(buffer, '\0', sizeof(buffer)) ;
     fgets(buffer, sizeof(buffer), fp) ;
 
     if(feof(fp)) 
       break ;
 
     if( buffer[0] == '\0' || buffer[0] == '\n' ) 
       break ;
 
     start_num = atoi(buffer) ;
     digit_count = 0 ;
 
     memset(num_array, '\0', 10 * sizeof(int) ) ;    
 
     for( j = 1; j > 0; j++) 
     {
       if( start_num == 0 )
       {
         j = -2 ;
         continue ;
       }
       proc_num = start_num * j ;
       //printf("%d = %d, %d\n", start_num, proc_num, j) ;
 
       memset(num_buf, '\0', sizeof(num_buf)) ;
       snprintf(num_buf, sizeof(num_buf), "%d",proc_num) ;
 
       num_buf_len = strlen(num_buf) ;
       //printf("num_buf: %s\n", num_buf) ;
 
       for( k = 0; k < num_buf_len; k++)
       {
         tmp[0] = num_buf[k] ;
         tmp[1] = '\0' ;
         digit = atoi(tmp) ;
         
         if( num_array[digit] == 0 )
         {
           num_array[digit] = 1;
           digit_count++ ;
         }
       }
       if(digit_count == 10)
         break ;
     }
 
     if( j > 0 )
     {
       printf("Case #%d: %d\n",i+1, proc_num) ;
     }
     else
       printf("Case #%d: INSOMNIA\n", i+1) ;
   }
 }
 
 int main(int argc, char *argv[])
 {
   char filename[1024] ;
   FILE *fp = NULL ;
   int case_count = 0;
   
   memset(filename, '\0', sizeof(filename)) ;
   
   strncpy(filename, argv[1], sizeof(filename));
 
   fp = open_input_file(filename) ;
   case_count = get_case_count(fp) ;
 
   process_sleep(fp, case_count) ;  
 }

