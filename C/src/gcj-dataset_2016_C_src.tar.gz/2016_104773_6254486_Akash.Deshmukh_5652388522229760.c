#include<stdio.h>
 typedef unsigned long long int llu;
 llu check(llu *a)
 {
  llu i;
  for (i=0;i<10;i++)
  {
   if(*(a+i)==0)
       break;
  }
  return  (i==10);
 }
 int main()
 {
  freopen("a.in","r",stdin);
  freopen("gcj1.out","w",stdout);
  llu t,a0;
  scanf("%llu",&t);
  for(a0=0;a0<t;a0++)
  {
   llu n,k,i,j,a[10];
   scanf("%llu",&n);
   for(i=0;i<10;a[i++]=0);
   if(n==0)
   {
    printf("Case #%llu: INSOMNIA\n",a0+1);
    continue;
   }
   for(i=1;;i++)
   {
    for(k=n*i;k>0;k/=10)
    {
     a[(k%10)]++;
     if(check(a))
     {
       printf("Case #%llu: %llu\n",a0+1,n*i);
       break;
     }
    }
    if(k>0)
      break;
   }
  }
  return 0;
 }

