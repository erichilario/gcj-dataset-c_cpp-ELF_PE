
 #include<stdio.h>
 #include<stdbool.h>
 #include<string.h>
 typedef long long int LL;
 bool vis[15];
 
 int main()
 {
     freopen("in.txt", "r", stdin);
     freopen("out.txt", "w", stdout);
 
     int i, j, k, t, n, cs;
     LL N, P;
 
     scanf("%d", &t);
     for(cs = 1; cs <= t; cs++)
     {
         printf("Case #%d: ", cs);
 
         scanf("%d", &n);
         memset(vis, 0, sizeof(vis));
 
         if(n == 0)
         {
             puts("INSOMNIA");
             continue;
         }
 
         N = n, k = 1;
         while(true)
         {
             N = (LL) n * k;
 
             P = N;
             while(P)
             {
                 vis[P%10] = true;
                 P/=10;
             }
 
             for(i = 0; i < 10; i++)
                 if(!vis[i]) break;
 
             if(i == 10) break;
             k++;
         }
 
         printf("%lld\n", N);
     }
     return 0;
 }

