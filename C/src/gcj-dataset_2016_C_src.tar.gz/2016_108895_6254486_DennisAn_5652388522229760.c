#include <stdio.h>
 #include <stdlib.h>
 
 int is_valid(int input);
 int have_all_num(int a[]);
 void digit_separte(int *a, int input);
 
 int main(int argc, char const *argv[])
 {	
 	int num_of_test;
 	int input;
 	int i = 0;
 	scanf ("%d", &num_of_test);
 	while (i<num_of_test) {
 		i++;
 		scanf("%d", &input);
 		printf("Case #%d: ", i);
 		if (input == 0) {
 			printf("INSOMNIA\n");
 			continue;
 		}
 		printf("%d\n", is_valid(input));
 	}
 	return 0;
 }
 
 int is_valid(int input) {
 	int original_input = input;
 	int a[10];
 	int i;
 	int result;
 	for (i=0; i<10; i++) {
 		a[i] = 0;
 	}
 
 	i=1;
 	while (1) {
 		if (have_all_num(a)) {
 			result = original_input*(i-1);
 			return result;
 		} else {
 			digit_separte(&a, input);
 		}
 		input = (i+1)*original_input;
 		//printf("input: %d\n", input);
 		i++;
 	}
 }
 
 int have_all_num(int a[]) {
 	int i;
 	for (i=0; i<10; i++) {
 		if (a[i] == 0) {
 			return 0;
 		}
 	}	
 	return 1;
 }
 
 void digit_separte(int *a, int input) {
 	int digit;
 	while (1) {
 		digit = input%10;
 		input = input/10;
 		//printf("%d\n", digit);
 		a[digit] = 1;
 
 		if (input == 0) {
 			break;
 		}
 	}
  }
 

