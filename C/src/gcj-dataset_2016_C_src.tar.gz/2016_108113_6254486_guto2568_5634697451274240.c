#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 #define MAX 10
 int min;
 
 int allPositive(char s[], int len){
     int i;
     for(i = 0; i< len; i++)
         if(s[i] == '-')
             return 0;
     return 1;
 }
 
 void flipStack(char s[],int N){
     int i;
     for(i = 0; i< N; i++){
         if(s[i] == '+')
             s[i] = '-';
         else
             s[i] = '+';
     }   
 }
 
 void copyOperations(int v[], int s[], int len){
     int i;
     for(i = 0; i< len; i++)
         v[i] = s[i];
 }
 
 void setOperationsToZero(int v[]){
     int i;
     for(i = 0; i< MAX; i++)
         v[i] = 0;
 }
 
 void executeOp(int op[], char s[], int len){
     int i;
     for(i = 0; i< len; i++)
         if(op[i] == 1)
             flipStack(s, i+1);
 }
 
 void imprimeop(int v[], int len){
     int i;
     for(i = 0; i< len; i++)
         printf("%d ", v[i]);
     printf("\n");
 }
 
 void minFlips(char s[], int flips, int len, int op[], int begin){
     char *newS;
     int *newOp;
     int i;
     newS = malloc(len*sizeof(char));
     newOp = malloc(len*sizeof(int));
     
     strcpy(newS, s);
     copyOperations(newOp, op, len);
     executeOp(op, newS, len);
     
     if(allPositive(newS, len)){
         if(flips < min)
             min = flips;
     }
     else if(flips < min-1){
         for(i = begin; i< len; i++){
            newOp[i] = 1;
            minFlips(s, flips + 1, len, newOp, i+1);
            copyOperations(newOp, op, len);
         }            
     }
            
     free(newS);
     free(newOp);
 }
 
 int main(){
     int T;
     char string[MAX+1];
     int operations[MAX];
     int i;
     
     scanf("%d", &T);
     
     for(i = 0; i< T; i++){
         setOperationsToZero(operations);
         scanf("%s", string);
         min = strlen(string); 
         minFlips(string, 0, strlen(string), operations, 0);
         printf("Case #%d: %d\n", i+1, min);
     }
     
     return 0;
 }
