/*
  ============================================================================
  Name        : Jam1.c
  Author      : 
  Version     :
  Copyright   : Your copyright notice
  Description : Hello World in C, Ansi-style
  ============================================================================
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <memory.h>
 
 int main(void) {
 
 	FILE * input = fopen("A-small-attempt0.in", "r");
 	FILE * output = fopen("output.txt", "w");
 
 	unsigned int max_case = 0;
 	fscanf(input, "%i", &max_case);
 
 	fprintf(stdout, "Max cases : %i", max_case);
 
 	unsigned int curr_case = 1;
 	while(curr_case <= max_case) {
 
 		unsigned int init_val = 0;
 		fscanf(input, "%i", &init_val);
 
 		if(init_val == 0) {
 			fprintf(output, "Case #%i: INSOMNIA\n", curr_case);
 		} else {
 
 			unsigned int values[10];
 			memset(values, 0, sizeof(values));
 
 			unsigned int mult = 1;
 			while(1) {
 				unsigned int curr_val = mult * init_val;
 				while(curr_val != 0) {
 					unsigned int digit = curr_val % 10;
 					values[digit] = 1;
 					curr_val /= 10;
 				}
 				if(values[0]
 						&& values[1]
 						&& values[2]
 						&& values[3]
 						&& values[4]
 						&& values[5]
 						&& values[6]
 						&& values[7]
 						&& values[8]
 						&& values[9]) {
 					fprintf(output, "Case #%i: %i\n", curr_case, mult * init_val);
 					break;
 				}
 				++mult;
 			}
 
 		}
 
 		++curr_case;
 	}
 
 	fclose(input);
 	fclose(output);
 
 	return EXIT_SUCCESS;
 
 }

