#include <stdio.h>
 int main(void) {
 	freopen("A-large.in","r",stdin);
     	freopen("A-large.out","w",stdout);
 	int t, n, sum, i, dig, l, num, j, a[10], c, k;
 	scanf("%d",&t);
 	for(i = 0; i < t; i++){
 		scanf("%d",&n);
 		num = n;
 		sum = 0, c = 0, k = 1;
 		for(l = 0; l < 10; l++){
 			a[l] = -9999;
 		}
 		if( n != 0){
 			while(c != 10){
 				n = num*(k++);
 				while(n != 0){
 					dig = n%10;
 					for(j = 0; j < c; j++){
 						if (a[j] == dig){
 							break;
 						}
 					}
 					if(j == c){
 						a[c] = dig;
 						c++;
 					}
 					n = n/10;
 				}
 			}
 			printf("Case #%d: %d\n",i + 1, num*(--k));
 		}
 		else{
 			printf("Case #%d: INSOMNIA\n",i + 1);
 		}	
 	}
 	return 0;
 }

