// non-combinatoric brute force-like solution
 
 #include <stdio.h>
 
 int main() {
 	int current=1;
 	int line=0;
 	int lineCopy;
 	int cases;
 	
 	scanf("%d",&cases);
 	
 	while (scanf("%d",&line) && cases>0) {
 		int seen[]={0,0,0,0,0,0,0,0,0,0};
 		int cycleDetect=0;
 		int finished=0;
 		lineCopy=line;
 		
 		while (cycleDetect<1002 && !finished) {
 			int lineTemp=line;
 			int i=0;
 			int j=0;
 			
 			while (lineTemp>0) {
 				int digit=lineTemp%10;
 				lineTemp=lineTemp/10;
 				
 				// check digit in array
 				if (seen[digit]==0) {
 					seen[digit]=1;
 					cycleDetect=0;
 				}
 			}
 			// current number checked
 			line=line+lineCopy;
 			cycleDetect++;
 			
 			// check if all seen
 			finished=1;
 			while (i<10) {
 				if (seen[i]==0) {
 					finished=0;
 				}
 				i++;
 			}
 		}
 		
 		if (finished) {
 			printf("Case #%d: %d\n",current,line-lineCopy);
 		}
 		else {
 			printf("Case #%d: INSOMNIA\n",current);
 		}
 		current++;
 		cases--;
 	}
 	
 	return 0;
 }
 

