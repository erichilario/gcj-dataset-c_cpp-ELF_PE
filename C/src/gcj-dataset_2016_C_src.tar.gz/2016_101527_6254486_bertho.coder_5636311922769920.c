
 #include<stdio.h>
 
 int main()
 {
     freopen("c:\\Users\\User\\Desktop\\in.txt", "r", stdin);
     freopen("c:\\Users\\User\\Desktop\\out.txt", "w", stdout);
 
     int i, j, t, cs;
     int K, C, S;
 
     scanf("%d", &t);
     for(cs = 1; cs <= t; cs++)
     {
         printf("Case #%d:", cs);
         scanf("%d %d %d", &K, &C, &S);
         for(i = 1; i <= K; i++) printf(" %d", i);
         puts("");
     }
     return 0;
 }

