#include <stdio.h>
 
 int main()
 {
 
 	int digits[10];
 	int tests, i, N, notYet, number, temp, rest, j, k, c=1;
 	
 	scanf("%d\n", &tests);
 	
 	for( i=0; i<tests; i++ )
 	{
 		scanf("%d\n", &N);
 				
 		// initialize digits
 		for( k=0; k<10; k++ )
 		{
 			digits[k] = 0;
 		}
 		
 		for( k=1; ; k++ )
 		{
 			number = N*k;
 			
 			if( number > 1000000 || number == 0)
 			{
 				notYet = 1;
 				break;
 			}	
 			
 			temp = number;
 			do
 			{
 				rest = temp%10;
 				//printf("%d 10 = %d\n", temp,rest);
 				digits[rest] = 1;
 				temp = temp/10;
 			} while( temp != 0 ); 		
 			
 			// check digits
 			notYet = 0;
 			for( j=0; j<10; j++ )
 			{
 				//printf("digits[%d] = %d\n", j, digits[j]);
 				if( digits[j] == 0 )
 				{
 					
 					notYet = 1;
 					break;
 				}
 			}
 			if( notYet == 0 )
 			{
 				break;
 			}
 		}
 		if( notYet == 0 )
 			printf("Case #%d: %d\n", c++, number);
 		else
 			printf("Case #%d: INSOMNIA\n", c++ );	
 	}
 }
