/**
  * pancakes.c
  * 
  * Yatharth Manocha
  * yathman97@gmail.com
  * 
  * Google Code Jam - Qualification Round
  * Problem B. Revenge of the Pancakes
  * 
  * Helps the Head Chef of The Infinite House of Pancakes
  * to serve the customer pancakes with happy side up.
  * 
  */
  
 // includes
 #include <stdio.h>
 #include <string.h>
 
 // typedefs
 typedef enum {
   false = 0,
   true = 1
 } bool;
 
 // prototypes
 bool check(char*);
 void flip(char*, int);
 void print(int, int);
 
 int main()
 {
     // test Cases
     int T;
     scanf("%d", &T);
     
     for (int i = 0; i < T; i++)
     {
         // stack
         char S[100];
         scanf("%s", S);
         
         int n = strlen(S);
         
         // for only 1 pancake
         if (n == 1)
         {
             bool isdone;
             
             isdone = check(S);
             if (isdone == true)
             {
                 print(i + 1, 0);
             }
             else
             {
                 print(i + 1, 1);
             }
             
         }
         else 
         {
             // max flips would be n
             for (int j = 0, max = 0; j < n + 1; j++, max = 0)
             {
                 bool isdone;
                 
                 isdone = check(S);
                 
                 if (isdone == true)
                 {
                     print(i + 1, j);
                     break;
                 }
                 else
                 {
                     for (int k = 0; k < n; k++)
                     {
                         if (S[k] == S[k + 1])
                         {
                             max++;
                         }
                         else 
                             break;
                     }   
                     
                     flip(S, max);
                 }
             }
         }
     }
     
     return 0;
 }
 
 bool check(char* stack)
 {
     for (int i = 0; stack[i] != '\0'; i++)
     {
         if (stack[i] != '+')
             return false;
     }
     
     return true;
 }
 
 void flip(char* stack, int max)
 {
     char temp[max + 1];
     
     strncpy(temp, stack, max + 1);
     temp[max + 1] = '\0';
     
     for (int i = 0, j = max; i < max + 1; i++, j--)
     {
         switch(temp[j])
         {
             case '+':
                 stack[i] = '-';
                 break;
                 
             case '-':
                 stack[i] = '+';
                 break;
         }
     }
 }
 
 void print(int t, int flips)
 {
     printf("Case #%d: %d\n", t, flips);
 }
