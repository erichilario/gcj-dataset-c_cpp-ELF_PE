/**
  * sheep.c
  * 
  * Yatharth Manocha
  * yathman97@gmail.com
  * 
  * Google Code Jam - Qualification Round
  * Problem A: Counting Sheep
  * 
  * Helps Bleatrix Trotter the sheep sleep.
  */
  
 // includes
 #include <stdio.h>
 
 // defines
 #define DIGITS 10
 #define MAX_ITERATIONS 100
 
 // typedefs
 typedef enum {
   false = 0,
   true = 1
 } bool;
 
 // prototypes
 bool check(bool*);
 bool fill(int, bool*);
 unsigned long work(int);
 
 
 int main()
 {
     // test Cases
     int T;
     scanf("%d", &T);
     
     for (int i = 0; i < T; i++)
     {
         int N;
         scanf("%d", &N);
         
         unsigned long ans = work(N);
         
         // Insomnia
         if (ans == -1)
         {
             printf("Case #%d: INSOMNIA\n", i + 1);
         }
         else
         {
             printf("Case #%d: %lu\n", i + 1, ans);
         }
     }
 }
 
 bool check(bool* checklist)
 {
     for (int i = 0; i < DIGITS; i++)
     {
         if (checklist[i] == 0)
             return false;
     }
     
     return true;
 }
 
 bool fill(int d, bool* checklist)
 {
     if (checklist[d] == 0)
     {
         checklist[d] = 1;
         return true;
     }
     else
         return false;
 }
 
 unsigned long work(int N)
 {
     // checklist for digits
     bool checklist[DIGITS] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
     
     // for (int i = 0; i < "Insomnia condition"; i++)
     int i = 0; 
     
     while (i < 100)
     {
         unsigned long num = (i + 1)* N;
         
         for (int d = 1; num > 0; )
         {
             d = num % 10;
             num = num / 10;
             
             bool flag1;
             flag1 = fill(d, checklist);
             
             // check when checklist is updated
             if (flag1 == true)
             {
                 bool flag2;
                 
                 // check for completion
                 flag2 = check(checklist);
                 
                 // if complete
                 if (flag2 == true)
                 {
                     return (i + 1)* N;
                 }
             }
         }
         i++;
     }
     
     // counting takes forever
     return -1;
 }
