#include <stdio.h>
 
 int main()
 {
 	bool panel[11];
 	int i,j,t,cnt,now;
 	int n,np,no,k;
 	char path[20];
 	FILE* fip,*fop;
 	scanf("%s",path);
 	fip=fopen(path,"r");
 	fop=fopen("qr_a_l.out","w");
 	fscanf(fip,"%d",&t);
 	for(j=1;j<=t;j++)
 	{
 		cnt=1;
 		now=0;
 		for(i=0;i<10;i++)
 		{
 			panel[i]=false;
 		}
 		fscanf(fip,"%d",&n);
 		no=n;
 		while(cnt<=200)
 		{
 			np=n;
 			while(n)
 			{
 				k=n%10;
 				if(!panel[k])
 				{
 					now++;
 					panel[k]=true;
 				}
 				n/=10;
 			}
 			cnt++;
 			n=np+no;
 			if(np==n||now==10)
 			{
 				break;
 			}
 		}
 		fprintf(fop, "Case #%d: ",j);
 		if(now==10)
 		{
 			fprintf(fop, "%d\n",np);
 		}else
 		{
 			fprintf(fop, "INSOMNIA\n");
 		}
 	}
 	fclose(fip);
 	fclose(fop);
 	return 0;
 }
