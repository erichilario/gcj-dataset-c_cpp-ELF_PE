#include<stdio.h>
 int main(){
   long long t,n,i,k,x,arr[10],count,j,r,m;
   scanf("%lld",&t);
   for(k=1;k<=t;k++){
     scanf("%lld",&n);
     j=2;
     m=n;
     if(n==0)
     {
       printf("Case #%lld: INSOMNIA\n",k);
       continue;
     }
     for(i=0;i<=9;i++)
         arr[i]=0;
     while(1){
           x=n;
         while(x){
            r=x%10;
           arr[r]=1;
             x/=10;
         }
 
 
       for(i=0,count=0;i<=9;i++){
         if(arr[i]==0)
             break;
         else
             count++;
       }
       if(count==10){
         break;
       }
        n=j*m;
         j++;
 
     }
 
     printf("Case #%lld: %d\n",k,n);
 
 
 
 
   }
 
 return 0;
 }

