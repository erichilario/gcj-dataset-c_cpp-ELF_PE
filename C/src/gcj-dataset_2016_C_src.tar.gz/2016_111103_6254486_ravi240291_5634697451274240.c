#include<stdio.h>
 #include<string.h>
 
 #define MAX_SIZE 100
 
 int reverse(char *S)
 {
 	int i = 0, temp =0;
 	int len = strlen(S)/2;
 	for (i = 0 ; i < len; i++)
 	{
 		temp = S[i];
 		S[i] = S[len-i-1]; 
 		S[len-i-1] = temp;
 	}
 	return 0;
 }
 
 int main()
 {
 	int i = 0, j = 0, k = 0;
 	int T = 0;
 	int len = 0, count = 0;
 	int front, rear, top;
 	char S[MAX_SIZE+1];
 	scanf("%d",&T);
 	for (i = 0; i < T; i++)
 	{
 		count = 0;
 		memset(S, 0, MAX_SIZE+1);
 		scanf("%s",S);
 		len = strlen(S);
 		rear = len;
 
 		while(1)
 		{
 			front = 0;
 
 			for (j = rear; j > 0; j--)
 			{
 				if (S[j-1] != '+')
 				{
 					break;
 				}
 			}
 			if (j == 0)
 			{
 				printf("Case #%d: %d\n", i+1, count);
 				break;
 			}
 			for (k = front; k != j; k++ )
 			{
 				if (S[k] == '+') S[k] = '-';
 				else if (S[k] == '-')  S[k] = '+';	
 			}
 			if (j == len)
 			{
 				reverse(S);
 			}
 			else
 			{
 				rear = j;
 			}
 			count++;
 		}
 	}
 }

