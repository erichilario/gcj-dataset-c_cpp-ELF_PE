#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <error.h>
 
 #define NDEBUG			0
 #include <assert.h>
 
 #define RES_BAD			1
 #define RES_OK			0
 
 #if NDEBUG
 #	define dbg_printf(...)	((void)0)
 #else
 #	define dbg_printf(...)	printf(__VA_ARGS__) /* variadic macro, C99 */
 #endif
 
 #define MAX_LEN			1024
 
 int solve(FILE *f, char *result)
 {
 	int scanned;
 	char p[MAX_LEN] = { 0 };
 	int flips = 0;
 	int len = 0;
 	int i = 0;
 	int prev = 0;
 
 	scanned = fscanf(f, "%s", p);
 	if (scanned != 1) {
 		printf("Parsing failed\n");
 		return RES_BAD;
 	}
 
 	len = strlen(p);
 
 	dbg_printf("\n%s len %d:\n", p, len);
 
 	for (i = 0; i < len; i++) {
 		if (p[i] == '+') {
 			dbg_printf("got + (+0)\n");
 			prev = 1;
 			continue;
 		}
 
 		if (p[i] == '-') {
 			switch (prev) {
 			case 0:
 				dbg_printf("got - (+1)\n");
 				flips += 1;
 				break;
 
 			case 1:
 				dbg_printf("got - (+2)\n");
 				flips += 2;
 				break;
 
 			case -1:
 				dbg_printf("got - (+0)\n");
 				break;
 
 			default:
 				error(-1, 0, "bad prev %d\n", prev);
 			}
 
 			prev = -1;
 		}
 	}
 
 
 	sprintf(result, "%d", flips);
 
 	return RES_OK;
 }
 
 int main(void)
 {
 	FILE *file_in, *file_out;
 	char result[MAX_LEN] = { 0 };
 	int cases, a_case;
 	int scanned;
 
 	file_in = fopen("in.txt", "r");
 	file_out = fopen("out.txt", "w");
 
 	if (!file_in || !file_out)
 	{
 		printf("Bad i/o file\n");
 		return RES_BAD;
 	}
 
 	scanned = fscanf(file_in, "%d", &cases);
 	if (scanned != 1) {
 		printf("Reading number of cases failed\n");
 		return RES_BAD;
 	} else {
 		printf("Solving %d cases... \n", cases);
 	}
 
 	for (a_case = 0; a_case < cases; a_case++)
 	{
 		if (solve(file_in, result) == RES_BAD) {
 			printf("Solving failed!\n");
 			return RES_BAD;
 		}
 		fprintf(file_out, "Case #%d: %s\n", a_case + 1, result);
 	}
 
 	fclose(file_in);
 	fclose(file_out);
 
 	printf("Done!\n");
 
 	return RES_OK;
 }

