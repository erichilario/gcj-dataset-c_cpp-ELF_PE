#include <stdio.h>
 #include <string.h>
 
 void update_mask (unsigned long long N, unsigned short *mask)
 {
 	int n;
 	n = N%10;
 	if (n == 0)
 	{
 		*mask = (1 << (9)) | *mask;
 	}
 	else
 	{
 		*mask = (1 << (n-1)) | *mask;
 	}
 	while((N = N/10) != 0)
 	{
 		n = N %10;
 		if (n == 0)
 		{
 			*mask = (1 << (9)) | *mask;
 		}
 		else
 		{
 			*mask = (1 << (n-1)) | *mask;
 		}
 	}
 }
 
 int main()
 {
 	#define NUMBERS_SEEN 0b01111111111
         int T = 0;
 	int a[11] = {0, 10, 90, 30, 92, 90, 90, 70, 96, 90, 90};
         int len = 0;
 	unsigned long long N;
 	unsigned short bitmask = 0;
 	
 	scanf("%d", &T);
         for (int k = 0; k < T; k++)
         {
 		scanf("%llu", &N);
 		unsigned  long long value = N;
 		unsigned long long orig_value = value;
 		int digit=1;
 		int bittmask = 0;
 		int n;
 
 		bitmask = 0;
 		if (orig_value == 0)
 		{
 			printf("Case #%d: INSOMNIA\n", (k+1));
 			continue;
 		}
 
 		int count = 1;
 		while (NUMBERS_SEEN != bitmask)
 		{
 			value = count * orig_value;
 			update_mask(value, &bitmask);
 			count++;
 		} 
 		printf("Case #%d: %llu\n", (k+1), value);
 	}
 }

