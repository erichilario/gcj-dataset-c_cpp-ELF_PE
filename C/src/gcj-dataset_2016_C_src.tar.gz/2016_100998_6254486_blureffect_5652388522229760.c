#include <stdio.h>
 int main(void) {
 	int t,i,m,j,k;
 	scanf("%d",&t);
 	for(i=0;i<t;i++){
 		int r[10] = {0},c,n;
 		scanf("%d",&n);
 		if(n==0) {
 			printf("Case #%d: INSOMNIA\n",i+1);
 			continue;
 		}
 		for(j=1;j<201;j++){
 			m=n*j;
 			c=0;
 			while(m){
 				r[m%10]++;
 				m/=10;
 			}
 			for(k=0;k<10;k++){
 				if(r[k]>0)c++;
 			}
 			if(c==10) break;
 		}
 		
 
 		if(c==10)
 			printf("Case #%d: %d\n",i+1,n*j);
 		else
 			printf("Case #%d: INSOMNIA\n",i+1);
 		
 	}
 	return 0;
 }

