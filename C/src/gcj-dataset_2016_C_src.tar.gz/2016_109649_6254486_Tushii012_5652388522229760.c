#include <stdio.h>
 #define ULLX unsigned long long
 ULLX val;
 ULLX Sol[100];
 int N[100];
 int hashtable[10];
 
 void calchash(ULLX val){
 	int remainder;
 	while(val){
 		remainder = val % 10;
 		val = val / 10;
 		hashtable[remainder] = 1;
 	}
 }
 
 int checkhash(){
 	int i;
 	for(i = 0; i < 10; i++){
 		if(hashtable[i] == 0)
 		  return 0;
 	}
 	return 1;
 }
  
 int main(){
 	int i = 0, j, T, mul;
 	scanf("%d", &T);
 	while(i < T){
 		scanf("%d", &N[i]);
 		i++;
 	}	
 
 	for(i = 0; i < T; i++){
 		if(N[i] == 0){
 			printf("Case #%d: INSOMNIA\n", i+1);
 		}else{
 			mul = 1;
 			while(1){
 				Sol[i] = mul * N[i];
 				mul += 1;	
 				calchash(Sol[i]);
 				if(checkhash())
 					break;
 			}
 			printf("Case #%d: %llu\n", i+1, Sol[i]);
 
 			for(j = 0; j < 10; j++){
 				hashtable[j] = 0;
 			}
 		}
 	}			
 
 }
 

