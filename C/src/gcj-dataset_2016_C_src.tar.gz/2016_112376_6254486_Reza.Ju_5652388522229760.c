#include<stdio.h>
 int main()
 {
     freopen("in.txt","r",stdin);
     freopen("out.txt","w",stdout);
     int i,n,t,j,k,l,n1,n2,num,a[20];
     scanf("%d",&t);
     for(i=1; i<=t; i++)
     {
         scanf("%d",&n);
         a[0]=0;
         a[1]=0;
         a[2]=0;
         a[3]=0;
         a[4]=0;
         a[5]=0;
         a[6]=0;
         a[7]=0;
         a[8]=0;
         a[9]=0;
         if(n==0)
         {
             printf("Case #%d: INSOMNIA\n",i);
         }
         else
         {
             for(j=1;; j++)
             {
                 n1=n*j;
                 n2=n*j;
                 for(k=1; n1!=0; k++)
                 {
                     num=n1%10;
                     a[num]++;
                     n1=n1/10;
                 }
                 if(a[0]!=0&&a[1]!=0&&a[2]!=0&&a[3]!=0&&a[4]!=0&&a[5]!=0&&a[6]!=0&&a[7]!=0&&a[8]!=0&&a[9]!=0)
                 {
                     break;
                 }
             }
             printf("Case #%d: %d\n",i,n2);
         }
     }
     return 0;
 }

