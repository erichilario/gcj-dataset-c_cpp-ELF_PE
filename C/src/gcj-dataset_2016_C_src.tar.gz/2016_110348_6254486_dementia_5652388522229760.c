#include <stdio.h>
 
 bool asleep(bool panel[11])
 {
 	int i;
 	for(i=0;i<10;i++)
 		{
 			if(!panel[i])
 			{
 				return false;
 			}
 		}
 		return true;
 }
 int main()
 {
 	bool panel[11];
 	int i,j,k,t,n,cnt,np,no;
 	char path[20];
 	FILE* fip,*fop;
 	scanf("%s",path);
 	fip=fopen(path,"r");
 	fop=fopen("qr_a.out","w");
 	fscanf(fip,"%d",&t);
 	for(j=1;j<=t;j++)
 	{
 		cnt=1;
 		for(i=0;i<10;i++)
 		{
 			panel[i]=false;
 		}
 		fscanf(fip,"%d",&n);
 		no=n;
 		while(cnt<=200)
 		{
 			np=n;
 			while(n)
 			{
 				k=n%10;
 				panel[k]=true;
 				n/=10;
 			}
 			cnt++;
 			n=no*cnt;
 			if(np==n||asleep(panel))
 			{
 				printf("%d\n",np);
 				break;
 			}
 		}
 		fprintf(fop, "Case #%d: ",j);
 		if(asleep(panel))
 		{
 			fprintf(fop, "%d\n",np);
 		}else
 		{
 			fprintf(fop, "INSOMNIA\n");
 		}
 	}
 	fclose(fip);
 	fclose(fop);
 	return 0;
 }
