#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define BUFFERSIZE 8012
 
 char *saveptr;
 char buffer[BUFFERSIZE];
 
 char * nextLine(){
 	fgets(buffer, BUFFERSIZE, stdin);
 	return buffer;
 }
 
 char * nextToken(){
 	char *token;
 	token = strtok_r(NULL, " ", &saveptr);
 	while(token == NULL){
 		char *newline = nextLine();
 		if(newline == NULL) return NULL;
 		token = strtok_r(newline, " ", &saveptr);
 	}
 	return token;
 }
 
 int nextInt(){
 	return atoi(nextToken());
 }
 
 double nextDouble(){
 	return atof(nextToken());
 }
 
 long nextLong(){
 	return atol(nextToken());
 }
 
 int interpret(char *num, int len, int base){
 	int i;
 	int baseholder = 1, ret = 0;
 	for(i=0;i<len;i++){
 		ret += baseholder * (num[len - i - 1]-48);
 		baseholder *= base;
 	}
 	return ret;
 }
 
 void toBin(int n, char *s){
 	int i, len, tmp;
 	tmp = n;
 	len = 0;
 	while(tmp != 0){
 		tmp /= 2;
 		len ++;
 	}
 	s[len] = 0;
 	for(i=1;i<=len;i++){
 		s[len-i]=n%2+48;
 		n/=2;
 	}
 }
 
 void toJamBin(int n, char *s, char* rep){
 	int i, len, tmp, j, replen;
 	tmp = n;
 	len = 0;
 	replen = strlen(rep);
 	len = 2;
 	for(i=0;i<32;i++){
 		s[i] = '0';
 	}
 	s[16] = 0;
 	for(i=1;i<=len;i++){
 		for(j=0;j<replen;j++){
 			if((n%2)==0){
 				s[replen*(len-i)+j]='0';
 			} else {
 				s[replen*(len-i)+j]=rep[j];
 			}
 		}
 		n/=2;		
 	}
 }
 
 void doStuff(int run){
 	int n, j, i, jam, k, replen, repnum;
 	char buffer[33], rep[9];
 	n = nextInt();
 	j = nextInt();
 	jam = 11;
 	replen = 8;
 	repnum = 0;
 	// for(i=1;i<n/replen;i++){
 	// 	jam = (jam << 1)+1;
 	// }
 	printf("Case #%d:\n",run);
 	for(i=0;i<j;i++){
 		toBin((repnum << 1) + 129, rep);
 		toJamBin(jam,buffer, rep);
 
 		printf("%s ", buffer);
 		for(k=2;k<=10;k++){
 			printf("%d ",interpret(rep,replen,k));
 		}
 		printf("\n");
 		// jam -= 2;
 		repnum+=1;
 	}
 }
 
 int main(){
 	int run, n;
 	n = nextInt();
 	for(run=1;run<=n;run++){
 		doStuff(run);
 	}
 }
 

