#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <math.h>
 
 
 long long int prime(long long int n)
 {
     long long int flag=sqrt(n),i;
     for(i=2;i<=flag;i++)
         if(n%i==0)
             return n/i;
     return 1;
 }
 
 int main(void) {
 
     int t,j;
     scanf("%d",&t);
     for(j=1;j<=t;j++)
     {
         printf("Case #%d:\n",j);
         int n,k,count=0;
         scanf("%d%d",&n,&k);
         char s[n+1];
         s[n]='\0';
         s[0]=s[n-1]='1';
         long long int var,a[11],pri;
         int flag=(int)pow(2,n-2),i,c,temp,l;
         for(i=1;i<flag;i++)
             {
             if(count==k)
                 break;
             temp=i;
             c=n-2;
             while(temp)
             {
                 s[c--]=(int)(temp%2)+'0';
                 temp/=2;
             }
             while(c>0)
                 s[c--]='0';
             //printf("%s\n",s);
             for(l=2;l<11;l++)
             {
                 var = strtol(s, NULL, l);
                 pri=prime(var);
                 if(pri==1)
                     break;
                 a[l]=pri;
             }
             if(l==11)
             {
                 count++;
                 printf("%s ",s);
                 for(l=2;l<11;l++)
                     printf("%lld ",a[l]);
                 printf("\n");
             }
         }
     }
     
     return 0;
 }

