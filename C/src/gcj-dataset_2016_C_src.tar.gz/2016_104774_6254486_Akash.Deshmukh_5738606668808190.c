#include<stdio.h>
 #include<math.h>
 
 char a[1000];
 void bin( long long int);
  long long int prime( long long int n)
 {
   long long int i;
  for(i=2;i<n;i++)
  {
   if(n%i==0)
     break;
  }
  return (i<n);
 }
  long long int convertobase( long long int n, long long int i, long long int j)
 {
   long long int k,t=0;
  if(j==11)
   return 1;
  for(k=0;n>0;n/=i,k++)
   t+=((n%i)*pow(j,k));
  if(prime(t))
    return (convertobase(t,i+1,j+1));
  return 0;
 }
  long long int lowfac( long long int n)
 {
   long long int i=3;
  for(;i<=(n/2);i++)
  {
   if(n%i==0)
      break;
  }
  return i;
 }
  long long int converto( long long int n, long long int j)
 {
   long long int k,t=0;
  for(k=0;n>0;n/=2,k++)
   t+=((n%2)*pow(j,k));
  return (lowfac(t));
 }
 void print( long long int n)
 {
   long long int i;
  for(i=1;i<=9;i++)
   printf(" %llu",converto(n,i+1));
  return;
 }
 void bin( long long int n)
 {
   long long int i=0,j;
  for(;n>0;n/=2)
  {
   if(n%2)
    a[i++]='1';
   else
    a[i++]='0';
  }
  for(--i;i>=0;i--)
     printf("%c",a[i]);
  return;
 }
 int main()
 {//freopen("cs.in","r",stdin);
  freopen("css.out","w",stdout);
   long long int t,a0;
  scanf("%llu",&t);
  for(a0=0;a0<t;a0++)
  {
    long long int n,k,i,m;
   scanf("%llu %llu",&m,&k);
   n=pow(2,m-1)+pow(2,0);
    printf("Case #%lld: \n",a0+1);
   for(i=0;k>0 && n+i<pow(2,m);i+=2)
   {
    if(prime(n+i))
    {
     if(convertobase(n+i,2,3))
     {
 
      bin(n+i);
      print(n+i);
      k--;
      printf("\n");
     }
    }
   }
  }
  return 0;
 }

