#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 int isSorted(char s[]){
 int flag=0,i,j;
 j=strlen(s);
 for(i=0;i<j;i++)
 {
     if(s[i]=='-')
     {
         flag =1;
         break;
     }
 
 }
 return flag;
 }
 int main()
 {
    char s[100];
    int T,i,j,k,l,sorty,count=0;
    scanf("%d",&T);
    if(T>=1&&T<=100){
    fflush(stdin);
    for(j=0;j<T;j++){
         count=0;
    scanf("%s",&s);
    fflush(stdin);
    i=strlen(s);
    if(i>=1&&i<=100){
    sorty=isSorted(s);
    while(sorty==1){
     if(s[0]=='+')
     { k=0;
       while(s[k]=='+')
       {
           k++;
       }
       for(l=0;l<k;l++)
       {s[l]='-';}
       count++;
     }
     else
     {
         k=0;
       while(s[k]=='-')
       {
           k++;
       }
       for(l=0;l<k;l++)
       {s[l]='+';}
       count++;
      }
      sorty=isSorted(s);
     }
 
      printf("Case #%d: %d\n",j+1,count);
    }
    }
 }
    return 0;
    }
 
 

