
 #include <stdio.h>
 #include <stdlib.h>
 
 void printTab(int *tab, int len){
 	int k;
         for (k=0;k<len;k++)
 		printf("%i", tab[k]);
 	printf("\n");
 }
 
 void setTab(int *tab){
         int k;
         for (k=0;k<100;k++)
                 tab[k]=0;
 }
 
 char isHappy(int *tab, int len){
 	int k;
 	for (k=0;k<len;k++){
                 if (tab[k]==0)
                         return 0;
         }
         return 1;
 }
 
 void flip(int *tab, int n){
 	int k;
 	char tmp;
 	for (k=0;k<n/2;k++){
 		tmp=!tab[k];
 		tab[k]=!tab[n-1-k];
 		tab[n-1-k]=tmp;
 	}
 	if (n&1)
 		tab[n/2]=!tab[n/2];
 }
 
 int solve(int *tab, int len){
 	int k, n=0;
 	for (k=1;k<len;k++){
 		if (tab[k]!=tab[k-1]){
 			flip(tab, k);
 			/*printTab(tab, len);*/
 			n++;
 		}
 	}
 	if (tab[0]==0){
 		flip(tab, len);
 		/*printTab(tab, len);*/
 		n++;
 	}
 	return n;
 }
 
 void remp(int *tab, int *len, FILE *f){
 	char k=fgetc(f);
 	*len=0;
 	while (k=='+' || k=='-'){
 		if (k=='+')
 			tab[*len]=1;
 		else
 			tab[*len]=0;
 		(*len)++;
 		k=fgetc(f);
 	}
 }
 
 void saute(FILE *f){
 	char k;
 	while ((k=fgetc(f))!='\n'){}
 }
 
 int main(int argc, char ** argv){
 	FILE *f, *g;
 	int tab[100], len, cas=1;
 	char fin=0;
 	if (argc!=2){
 		printf("Usage : %s file\n", argv[0]);
 		return EXIT_FAILURE;
 	}
 	f=fopen(argv[1], "r");
 	g=fopen("out", "w");
 	if (f==NULL || g==NULL){
 		printf("Erreur fichier\n");
 		return EXIT_FAILURE;
 	}
 	saute(f);
 	while (!fin){
 		remp(tab, &len, f);
 		if (len==0)
 			fin=1;
 		else {
 			fprintf(g, "Case #%i: %i\n", cas, solve(tab, len));
 			cas++;
 		}
 	}
 	fclose(g);
 	fclose(f);
 	return EXIT_SUCCESS;
 }
 

