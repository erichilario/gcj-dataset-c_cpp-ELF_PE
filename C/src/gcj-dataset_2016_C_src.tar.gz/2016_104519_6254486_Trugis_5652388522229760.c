#include <stdio.h>
 #include <stdlib.h>
 
 int didMeetAllNumber(int number_met[10]){
 	int i = 0;
 	for (i = 0; i< 10 ; i++){
 		if(number_met[i] == 0){
 			return 0;
 		}
 	}
 	return 1;
 }
 
 void clear_numberMet(int* number_met){
 	int i = 0;
 	for(i=0;i<10;i++){
 		number_met[i]=0;
 	}
 	return;
 }
 int* parseInputFile(char* filename, int *inputNumber){
 	FILE* fp = fopen(filename,"r");
 	int inputnb = 0;
 	int *inputs;
 	fscanf(fp,"%d\n",inputNumber);
 	inputs = (int*) malloc(sizeof(int) *(*inputNumber));
 	for(int i=0;i<(*inputNumber);i++){
 		fscanf(fp,"%d\n",&inputs[i]);
 	}
 	return inputs;
 }
 
 int fellAsleepAt(int N){
 	int number_met[10];
 	clear_numberMet(number_met);
 	unsigned int current_nb= 0;
 	if(N==0){
 		return 0;
 	}
 	unsigned int current = 0;
 	while(!didMeetAllNumber(number_met)){
 		current ++;
 		current_nb = current * N;
 		unsigned int current_nb_work = current_nb;
 		while(current_nb_work != 0){
 			if(number_met[current_nb_work%10]==0){
 				number_met[current_nb_work%10]=1;
 			}
 			current_nb_work/=10;
 		}
 	}
 	return current_nb;
 }
 
 int main(int argc, char *argv[]){
 
 int i = 0;
 int inputNumber=0;
 int *inputs;
 
 inputs = parseInputFile(argv[1],&inputNumber);
 printf("input number: %d\n",inputNumber);
 
 
 	printf("Listing inputs:\n");
 	for(int i=0;i<inputNumber;i++){
 		printf("%d\n",inputs[i]);
 	}
 
 	FILE* output = fopen("output.txt","w");
 
 	for(int i=0;i<inputNumber;i++){
 	printf("Input: %d\n",inputs[i]);
 	int solution = fellAsleepAt(inputs[i]);
 	if(solution == 0)
 		fprintf(output, "Case #%d: INSOMNIA\n",i+1);
 	else
 		fprintf(output, "Case #%d: %d\n",i+1,solution);
 	printf("Solution:%d\n\n", solution);
 	}
 	fclose(output);
 
 
 }
