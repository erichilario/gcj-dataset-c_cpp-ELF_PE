#include <stdio.h>
 int main(void) {
 	                          int t,N,d,e,j,i,k,a[100000],b;
 	                          scanf("%d",&t);
 	                          for(i=1;i<=t;i++)
 	                          {
 	                              scanf("%d",&N);
 	                              int f=0,q=0,r=0,s=0,t=0,u=0,v=0,w=0,x=0,y=0;
 	                              for(j=1;j<=100;j++)
 	                              {
 	                                  d=N*j;
 	                                  while(d!=0)
 	                                  {
 	                                    e=d%10;
 	                                    if(e==0)
 	                                    {
 	                                        f++;
 	                                    }
 	                                    if(e==1)
 	                                    {
 	                                        q++;
 	                                    }
 	                                    if(e==2)
 	                                    {
 	                                        r++;
 	                                    }
 	                                    if(e==3)
 	                                    {
 	                                        s++;
 	                                    }
 	                                    if(e==4)
 	                                    {
 	                                        t++;
 	                                    }
 	                                    if(e==5)
 	                                    {
 	                                        u++;
 	                                    }
 	                                    if(e==6)
 	                                    {
 	                                        v++;
 	                                    }
 	                                    if(e==7)
 	                                    {
 	                                        w++;
 	                                    }
 	                                    if(e==8)
 	                                    {
 	                                        x++;
 	                                    }
 	                                    if(e==9)
 	                                    {
 	                                        y++;
 	                                    }
 	                                    d=d/10;
 	                                  }
 	                                  
 	                                  if(f>=1&&q>=1&&r>=1&&s>=1&&t>=1&&u>=1&&v>=1&&w>=1&&x>=1&&y>=1)
 	                                  {
 	                                      b=N*j;
 	                                      printf("Case #%d: %d\n",i,b);
 	                                      break;
 	                                  }
 	                                  if(N==0)
 	                                  {
 	                                      printf("Case #%d: INSOMNIA\n",i);
 	                                      break;
 	                                  }
 	                              }
 	                          }
 	return 0;
 }
