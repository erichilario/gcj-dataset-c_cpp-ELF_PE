#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #define MAX 11
 int arr[10];
 void flip(int N)
 {
     int i;
     for(i=0;i<=N;i++)
     {
 	arr[i]*=-1;
     }
 }
 
 void conv(char str[MAX])
 {
     int i;
     for(i=0;i<strlen(str);i++)
     {
 	if(str[i]=='+')
 	    arr[i]=1;
 	else
 	    arr[i]=-1;
     }
 
 }
 void main()
 {
     FILE *fp1,*fp2;
     int T,i,j,l,ctr=0;
     int *res;
     char str[11];
     fp1=fopen("abc.in","r");
     fp2=fopen("res.out","w");
     fscanf(fp1,"%d",&T);
     res=(int *)malloc(T*sizeof(int));
     for(i=0;i<T;i++)
     {
 	fscanf(fp1," %[^\n]s",str);
 	conv(str);
 	ctr=0;
 	for(j=0;j<strlen(str)-1;j++)
 	{
 	    while(arr[j]==arr[j+1])
 	    {
 		j++;
 	    }
 	    if(j==strlen(str)-1)
 		break;
 	    flip(j);
 	    ctr++;
 	}
 	if(arr[0]==1)
 	    res[i]=ctr;
 	else
 	    res[i]=ctr+1;
     }
     for(i=0;i<T;i++)
     {
 	fprintf(fp2,"Case #%d: %d\n",i+1,res[i]);
     }
 }
 
 
 
 

