#include<stdio.h>
 #include<stdlib.h>
 int main(){
   char pan[1000];
   int test,i,a,y=0;
   scanf("%d",&test);
   for(i=1;i<=test;i++){
     y++;
     scanf("%s",pan);
     int x;
     for(x=0;pan[x]!='\0';x++);
     int c=0,k,l = x;
     for(k=1;k<l;k++){
       if(pan[k] != pan[k-1]){
 	c++;
       }
     }
     if(pan[x-1] == '-'){
       c++;
     }
     printf("Case #%d: %d\n",y,c);
   }
   return 0;
 }
     

