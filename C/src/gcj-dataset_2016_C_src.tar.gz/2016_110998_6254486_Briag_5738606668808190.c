#define __STDC_FORMAT_MACROS
 #include <inttypes.h>
 
 
 #include <stdio.h>
 #include <stdint.h>
 #define OUT "out.small.c"
 
 FILE * out;
     
 int caseIndex = 1;
 
 void printResult(uint64_t result, uint64_t tab[9]) {
     fprintf(out,"%" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 " %" PRIu64 "\n", result, tab[0],tab[1],tab[2],tab[3],tab[4],tab[5],tab[6],tab[7],tab[8]);
     caseIndex++;
 }
 
 uint64_t convert(uint64_t number,int base){
     if(number == 0 || base==10)
         return number;
 
     return (number % 10) + convert(number / 10, base) * base;
 }
 
 uint64_t is_not_prime(uint64_t  p)
 {
     uint64_t d;
 
     for (d = 2; d < 15; d = d + 1)
 	if (p % d == 0)
 	    return d;
 
     return 0;
 }
 
 int isFull(uint64_t tab[]) {
     for(int i  = 0; i < 9; i++)
         if(tab[i] == 0)
             return 0;
             
     return 1;
 }
 
 uint64_t progress2(uint64_t number, uint64_t pr) {
 
     uint64_t result = number;
     
     if(number % (10 * pr) > (pr)) {
         result-=pr;
         return progress2(result, pr * 10);
     } else {
         result+=pr;
         return result;
     }
         
 }
 uint64_t progress(uint64_t number) {
 
     uint64_t result = number;
     
     if(number % (100) > (10)) {
         result-=10;
         return progress2(result, 100);
     } else {
         result+=10;
         return result;
     }
 }
 
 
 int compute( uint64_t number, int J) {
     
     for(int i = 0; i < J;) {
      
         uint64_t result[9];
         
         for(int j = 2; j <= 10; j++) {
             uint64_t prime = is_not_prime(convert(number,j));
 
             result[j-2] = prime;
         }
         
         if(isFull(result) != 0) {
             printResult(number, result);
             i++;
         }
             
         number = progress(number);
     }
     
     
 }
 
 
 int main() {
     
     out = fopen (OUT, "w+");
     
     int N = 16;
     int J = 50;
     
     
     
     uint64_t number = 1;
     
     for(int i = 1; i < N; i++) {
         number = number * 10;
     }
     number = number + 1;
     
     fprintf(out,"Case #%d:\n", caseIndex);
     
     
     compute(number , J);
     
     //printf("%" PRIu64 " %" PRIu64 " %" PRIu64" %" PRIu64" %" PRIu64" %" PRIu64" %" PRIu64" %" PRIu64"\n", convert(a,2),convert(a,3),convert(a,4),convert(a,5),convert(a,6),convert(a,7),convert(a,8),convert(a,9));
     //precompute();
     
     return 0;
 }

