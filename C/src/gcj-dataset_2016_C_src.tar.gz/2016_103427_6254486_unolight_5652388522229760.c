#include <stdio.h>
 
 void parse_num(long long N, int *digit) {
 	int d;
 	while(N / 10 != 0) {
 		d = N % 10;
 		N /= 10;
 		digit[d] = 1;
 	}
 	digit[N] = 1;
 	return;
 }
 int isSleep(int *digit) {
 	int i;
 	for(i=0;i<10;i++) {
 		if(digit[i] == 0)
 			return 0;
 	}
 	return 1;
 }
 int main() {
 	int T;
 	long long N;
 
 	scanf("%d", &T);
 	int i;
 	long long a;
 	for(i = 0; i < T; i++) {
 		int digit[10] = {0};
 		int count = 1;
 		scanf("%lld", &N);
 		if(N == 0) {
 			printf("Case #%d: INSOMNIA\n", i+1);
 			continue;
 		}
 		parse_num(N, digit);
 		do{
 			a = N * count;
 			parse_num(a, digit);
 			count++;
 		}while(!isSleep(digit));
 
 		printf("Case #%d: %lld\n", i+1, a);
 
 	}
 
 
 	return 0;
 }

