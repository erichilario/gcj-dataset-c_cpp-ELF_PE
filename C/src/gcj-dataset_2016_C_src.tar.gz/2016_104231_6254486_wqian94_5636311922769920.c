// D: Fractiles
 
 #include <stdio.h>
 
 typedef unsigned int uint32_t;  // Avoid annoying typecast compiler warnings
 typedef unsigned long long uint64_t;  // Avoid annoying typecast compiler warnings
 
 int main(int argc, char *argv[]) {
     uint32_t T, C, K, S;
     scanf("%u", &T);
     for (uint32_t cases = 0; cases < T; cases++) {
         scanf("%u %u %u", &K, &C, &S);
 
         printf("Case #%u: ", cases + 1);
         // Small case solution: just look at the first S tiles.
         for (uint32_t i = 0; i < S; i++) {
             printf(" %u", i + 1);
         }
         printf("\n");
     }
 }

