#include<stdio.h>
 #include<stdlib.h>            
 int main(){
   int N,m,test;
   scanf("%d",&test);
   for(int i=1;i<=test;i++){
     int arr[] = {0,0,0,0,0,0,0,0,0,0};
     scanf("%d",&N);
     m = N;
     int sum = 0,a;
     int x = 1;
     if(N == 0){
       sum = 10;
       printf("Case #%d: INSOMNIA\n",i);
     }
     else{
       while(sum < 10){
 	m = N * (x);
 	x++;
 	while(m>0){
 	  a = m % 10;
 	  if(arr[a] == 0){
 	    arr[a] = 1;
 	    sum++;
 	  }
 	  m = m / 10;
 	}
       }
       if(sum == 10){
 	printf("Case #%d: %d\n",i,N*(x-1));
       }
     }
   }
   return 0;
 }

