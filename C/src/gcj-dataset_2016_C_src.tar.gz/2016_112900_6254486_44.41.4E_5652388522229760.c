#include <stdio.h>
 #include <string.h>
 
 
 
 int isFull(int list[10]){
 	
 	for(int i = 0; i < 10; i++){
 		if(list[i] == 0){
 			return 0;
 		}
 	}
 	return 1;
 }
 int main(void){
 	
 	
 	int t;
 	scanf("%d", &t);
 	for(int i = 0; i < t; i++){
 		int numList[10];
 		for(int i = 0; i < 10; i++)numList[i] = 0;
 		
 		int n;
 		scanf("%d", &n);
 		int multiplier = 1;
 		int result = 0;
 		while(!isFull(numList)){
 			int temp = n * multiplier;
 			result = temp;
 			while(temp){
 				numList[temp%10] = 1;
 				temp /= 10;
 			}
 			multiplier++;
 			if(multiplier > 10000){
 				break;
 			}
 		}
 			if(multiplier> 10000){
 				printf("Case #%d: INSOMNIA\n", i+1);
 			}else{
 
 				printf("Case #%d: %d\n", i+1, result);
 			}
 	}
 	
 	return 0;
 }

