#include <stdio.h>
 #include <conio.h>
 
 void lastdig(int t,int n)
 {
 	int c[100],x,k=0,i,j,l,a,m;
 	int b[10]={0,1,2,3,4,5,6,7,8,9};
 	for(i=1;i<100;i++)
 	{
 		a=n*i;
 		m=a;
 		while(a>0)
 		{
 			x=a%10;
 			c[k]=x;
 			a/=10;
 			k++;
 		}
 
 		for(j=0;j<k;j++)
 		{
 			for(l=0;l<10;l++)
 			{
 				if(c[j]==b[l])
 				{
 					b[l]=10;
 					break;
 				}
 			}
 		}
 
 		for(l=0;l<10;l++)
 		{
 			if(b[l]!=10)
 			break;
 		}
 		if(l==10)
 		{printf("Case #%d: %d\n",t,m);
 		 break;
 		}
 
 	}
 	if(i==100)
 	printf("Case #%d: INSOMNIA\n",t);
 
 }
 void main()
 {
 	int t,n,e;
 	scanf("%d",&e);
 	for(t=1;t<=e;t++)
 	{
 		scanf("%d",&n);
 		lastdig(t,n);
 	}
 	getch();
 }

