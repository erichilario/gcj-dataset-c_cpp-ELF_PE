#include<stdio.h>
 #include<math.h>
 #include<string.h>
 
 long long int checkPrime(long long int test, long long int *div, long long int index) {
   long long int flag = 0;
   for(long long int i = 2; i <= sqrt(test); i++) {
     if(test % i == 0 ) {
       div[index] = i;
       return 1;
     }
   }
   return 0;
 }
 
 long long int decTobin(long long int dec) {
   long long int binary = 0, place = 1;
   while(dec != 0) {
     int rema = dec % 2;
     binary = (rema * place) + binary;
     dec = dec / 2;
     place = place * 10;
   }
   return binary;
 }
 
 long long int getNumbers(long long int number, long long int *div) {
   long long int test = 0, index = 0;
   for(long long int i = 2; i <= 10; i++) {
     long long int temp = number;
     long long int j = 0;
     long long int flag = 10;
     test = 0;
     while(temp > 0) {
       long long int rem = temp % 10;
       test = test + pow(i, j) * rem;
       temp = temp / 10;
       j++;
     }
     //printf("\n\nTest %d", test);
     flag = checkPrime(test, div, index);
     index++;
     if(flag == 0)
       return 0;
   }
   return 1;
 }
 
 long long int getAns(long long int number, long long int *div, long long int j, long long int n) {
   long long int i = 1,count = 2, a = number, flag = 10;
   while(i <= j && count <= pow(2, n - 1)) {
     flag = getNumbers(a, div);
     if(flag == 1) {
       i++;
       printf("%lld ", a);
       for(long long int k = 0; k < 9; k++)
 	printf("%lld ", div[k]);
       printf("\n");
       a = number + decTobin(count);
       count = count + 2;
     }
     if(flag == 0) {
       a = number + decTobin(count);
       count = count + 2;
     }
   }
   return 0;
 }
 
 int main() {
   long long int t, n, j;
   scanf("%lld", &t);
   scanf("%lld", &n);
   scanf("%lld", &j);
   long long int number = 1 * pow(10, n - 1) + 1;
   //number = number + decTobin(4);
   //printf("%d\n", number);
   
   long long int div[9];
   printf("Case #1:\n");
   getAns(number, div, j, n);
 }

