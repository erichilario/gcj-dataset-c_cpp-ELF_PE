#include <stdio.h>
 #include<string.h>
 int main() 
 {
 	int j,n,i,p,k;
 	scanf("%d",&n);
 	for(i=0;i<n;i++)
 	{
 		char s[1010],s1[1010],temp;
 		scanf("%s\n",s);
 		k=strlen(s);
 		s1[0]=s[0];
 		for(p=1;p<k;p++)
 		{
 			if(s[p]<s1[0])
 			s1[p]=s[p];
 			else
 			{
 				for(j=p-1;j>=0;j--)
 				s1[j+1]=s1[j];
 				s1[0]=s[p];
 			}
 			s1[p+1]='\0';
 		}
 		s1[k]='\0';
 		printf("Case #%d: %s\n",i+1,s1);
 	}
 	return 0;
 }

