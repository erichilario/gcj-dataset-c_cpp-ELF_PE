#include <stdio.h>
 long long int calans(int *A, int *B, int len, int flag)
 {
 	if(flag==0)
 	{
         if(len==1)
         {
             if(A[0]==0)return 1;
             return 0;
         }
         else if(len==2)
         {
             if(A[1]==1)
             {
                 if(A[0]==0)return 1;
                 return 0;
             }
             else
             {
                 if(A[0]==0)return 1;
                 else return 2;
             }
         }
         else
     	{
     	    if(A[len-1]==1)
     	    {
     	        B = B+1;
     	        return calans(A,B,len-1,0);
     	    }
     	    else
     	    {
     	        B = B+1;
     	        return 1+calans(A,B,len-1,1);
     	    }
     	}
 	}
 	else
 	{
 	    if(len==1)
         {
             if(B[0]==0)return 1;
             return 0;
         }
         else if(len==2)
         {
             if(B[1]==1)
             {
                 if(B[0]==0)return 1;
                 return 0;
             }
             else
             {
                 if(B[0]==0)return 1;
                 else return 2;
             }
         }
         else
     	{
     	    if(B[len-1]==1)
     	    {
     	        A = A+1;
     	        return calans(A,B,len-1,1);
     	    }
     	    else
     	    {
     	        A = A+1;
     	        return 1+calans(A,B,len-1,0);
     	    }
     	}
 	}
 }
 int main(void) {
    int t,i,j,jprev;
    char inparr[102];
    long long int countminus;
    scanf("%d",&t);
    i=1;
    while(i<=t)
    {
        scanf("%s",inparr);
        jprev = 0;
        for(j=1,countminus=0;inparr[j]!='\0';j++)
        {
             if(inparr[j]!=inparr[jprev])
             {
                 if(inparr[jprev]=='-')countminus++;
                 jprev = j;
             }
        }
        if(inparr[jprev]=='-')countminus++;
        if(inparr[0]=='-')
        {
            printf("Case #%d: %lld\n",i,2*countminus-1);
        }
        else
        {
            printf("Case #%d: %lld\n",i,2*countminus);
        }
        i++;
    }
  return 0;  
 }
 

