#include <stdio.h>
 #include <stdlib.h>
 #include <gmp.h>
 
 int J = 500;
 int N = 32;
 
 void bin(unsigned long long n, char* end){
     *end = '\0';
 
     while (n) {
 	end--;
 
 	if (n & 1)
 	    *end = '1';
 	else
 	    *end = '0';
 
 	n >>= 1;
     }
 }
 
 void divisor(mpz_t p, mpz_t *div){
     mpz_t rem;
     mpz_init(rem);
     mpz_mod_ui(rem, p, 2);
 
     if (mpz_cmp_ui(rem, 0) == 0){
 	mpz_set_ui(*div, 2);
 	return;
     }
 
     mpz_t up_bnd;
     mpz_init(up_bnd);
     mpz_tdiv_q_ui(up_bnd, p, 2000000); // upper bound for div search is p/2*10^6
 
     mpz_set_ui(*div, 3);
 
     while (mpz_cmp(up_bnd, *div)){
 	mpz_mod(rem, p, *div);
 
 	if (mpz_cmp_ui(rem, 0) == 0)
 	    return;
 	
 	mpz_add_ui(*div, *div, 2);
     }
 }
 
 /*unsigned long long divisor(unsigned long long p){
     if (p % 2 == 0)
 	return 2;
 
     for (unsigned long long i = 3; i < p/2; i+=2)
 	if (p % i == 0)
 	    return i;
 
     return 0;
     }*/
 
 main(int argc, char** argv){
     printf("Case #1:\n");
     
     int jamcount = 0;
 
     char binjam[N+1];
     unsigned long jam = atol(argv[1]); //should start at 2^31+1
 
     mpz_t divs[9];
     mpz_inits(divs[0], divs[1], divs[2], divs[3], divs[4], divs[5], divs[6], divs[7], divs[8], NULL);
 
     while (jam < 4294967296 && jamcount < J) { // 2^32
 
 	bin(jam, binjam+N);
 
 	mpz_init(divs[8]);
 	for (int b = 2; b < 11; b++){
 	    mpz_t x;
 	    mpz_init_set_str (x, binjam, b);
 
 	    mpz_t div;
 	    mpz_init(div);
 	    divisor(x, &div);
 
 	    if (mpz_sgn(div))
 		mpz_set(divs[b-2], div);
 	    else
 		break;	
 	}
 
 	if (mpz_sgn(divs[8])){
 	    printf("%s", binjam);
 	    for (int i = 0; i < 9; i++){
 		printf(" ");
 		mpz_out_str(NULL, 10, divs[i]);
 	    }
 	    printf("\n");
 
 	    jamcount++;
 	}
 	    
 	jam+=2;
     }
 }

