#include <stdio.h>
 #define he printf("\nHeere\n")
 
 int cmpfunc (const void * a, const void * b)
 {
    return ( *(int*)a - *(int*)b );
 }
 
 
 
 int main(){
 
 	int t,cases=1,temp,index,i,N;
 	int ans[100];
 
 	scanf("%d",&t);
 	
 
 	while (cases <= t){
 
 		int hts[3000] = {0};
 		
 		scanf("%d",&N);
 		N =(2 * (N*N)) - N;
 
 		for (i=0; i< N ;i++){
 
 			scanf("%d",&temp);
 			// printf("%d\n", temp);
 			hts[temp] += 1;
 		}
 
 		for(i=0,index=0; i < 3000; i++){
 
 			// printf("--%d--\n",i );
 			if( (hts[i]%2) != 0 && hts[i] != 0 ){
 				// printf("--%d--\n",i );
 				ans[index]=i;
 				index++;
 			}
 		}
 
 		// printf("%d\n", index);
 		// if (index < N){
 
 		// }
 
 		// qsort(ans,index, sizeof(int),cmpfunc);
 
 		printf("Case #%d:",cases);
 		for (i=0; i < index; i++){
 			printf(" %d",ans[i]);
 		}
 		printf("\n");
 
 		cases++;
 	}
 
 	return 0;
 }
