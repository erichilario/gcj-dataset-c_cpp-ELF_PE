#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
 	FILE *fin,*fout;
 	fin=fopen("C-in.txt","r");
 	fout=fopen("c-3.txt","w");
 	int t,m=1;
 	fscanf(fin,"%d",&t);
 	while(t--)
 	{
 		int n,cr=0,j,ncr=0;
 		fscanf(fin,"%d",&n);
 		int i,a[1000];
 		int ff=n;
 		for(i=0;i<n;i++)
 		{
 			a[i]=0;
 			}
 		for(i=0;i<n;i++)
 		{
 			fscanf(fin,"%d",&a[i]);
 			}
 		for(i=0;i<n-1;i++)
 		{
 			
 			
 				if(a[i]==a[i+1]&& a[i]!=0)
 				{
 				a[i]=0;
 				cr++;
 				i++;
 				}
 				
 			
 		}
 		for(i=0;i<n;i++)
 		{
 			
 			for(j=i+1;j<n;j++)
 			{
 				if(a[i]==a[j]&& a[i]!=0)
 				{
 				ncr++;
 				a[i]=0;
 				}
 			
 		}
 		}if(cr==0 && ncr>=1)
 		{
 			ff-=ncr;
 		}
 		else if(cr>1)
 		ff=ff-(cr*2);
 		else if(cr==1)
 		ff-=cr;
 		else if(ncr>0)
 		ff-=ncr;
 		fprintf(fout,"Case #%d: %d\n",m,ff);
 		m++;
 		}
 		fclose(fin);
 		fclose(fout);
 		}		
