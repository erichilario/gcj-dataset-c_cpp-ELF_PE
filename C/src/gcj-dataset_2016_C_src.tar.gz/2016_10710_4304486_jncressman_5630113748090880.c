/*******************************************************************************
  *
  * PROJECT:
  *    Google Code Jam Round 1A
  *
  * FILE DESCRIPTION:
  *     Complete solution to 1A    
  *
  * CREATED BY:
  *   jonathan cressman April 15, 2016    
  *
  ******************************************************************************/
 
 /*** HEADER FILES TO INCLUDE  ***/
 #include "stdio.h"
 #include "stdbool.h"
 #include "string.h"
 #include "stdint.h"
 
 /*** DEFINES                  ***/
 
 /*** MACROS                   ***/
 
 /*** TYPE DEFINITIONS         ***/
 
 /*** VARIABLE DEFINITIONS     ***/
 
 /*** FUNCTION PROTOTYPES      ***/
 
 /*** FUNCTIONS                ***/
 /******************************************************************************
  * NAME:
  *    
  *
  * SYNOPSIS:
  *    
  *
  * PARAMETERS:
  *    OUTPUT
  * 
  *    INPUT/OUTPUT
  *
  *    INPUT
  *
  * GLOBAL VARIABLES
  *
  * FUNCTION:
  *    
  *
  * RETURNS:
  *    
  *
  ******************************************************************************/
 int main(int argc, char **argv)
 {
  	int T, i, j, k, m, n;
 	int count;
 	int smallest;
 	int previousSmallest;
 	
 	int soldier[100][50];
 	//int missingRow[50];
 	
 	scanf("%d", &T);
 
 	for (i=0; i<T; i++)
 	{
 		scanf("%d", &n);
 
 		
 		for (j=0; j<2*n -1; j++)
 		{
 			for (k=0; k<n; k++)
 			{
 				scanf("%d", &soldier[j][k]);
 			}
 		}
 
 		//we don't actually have to solve the final arrangement
 		//just find which numbers don't appear an even number of times, 
 		//sort them and that's the answer
 
 		m = 0;
 		
 		previousSmallest = -1;
 		smallest = -1;
 
 		printf("Case #%d:", i+1);
 
 		while (m < n)
 		{
 			count = 0;
 			for (j=0; j<2*n -1; j++)
 			{
 				for (k=0; k<n; k++)
 				{
 					if (previousSmallest == smallest)
 					{
 						if (soldier[j][k] > smallest)
 						{
 							smallest = soldier[j][k];
 							count = 1;
 						}
 					}
 					else if (  (soldier[j][k] > previousSmallest)
 						     && (soldier[j][k] < smallest) )
 					{
 						smallest = soldier[j][k];
 						count = 1;
 					}
 
 					else if (soldier[j][k] == smallest)
 					{
 						count++;
 					}
 				}
 			}
 			
 			previousSmallest = smallest;
 
 			if (count%2 == 1)
 			{
 				printf(" %d", smallest);
 				m++;
 			}
 		}
 		printf("\n");
 
 	}
 
 	return 0;
 }

