#include<stdio.h>
 #include<string.h>
 
 #define TRUE 0
 #define FALSE -1
 
 int flag[10];
 int count = 0;
 
 int scan_digits(int N)
 {
 	while (N != 0)
 	{
 		if (flag[N%10] != 1)
 		{
 			flag[N%10]=1;
 			count++;
 			if (count>=10)
 				return TRUE;
 		}
 		N=N/10;
 	}
 	return FALSE;
 }
 
 int main()
 {
 	int i = 0, j = 0;
 	int T = 0;
 	int N = 0, nextN = 0;
 	scanf("%d",&T);
 	for (i = 0; i < T; i++)
 	{
 		count = 0;
 		nextN = 0;
 		memset(flag, 0, 10*sizeof(int));
 		scanf("%d",&N);
 		if (N == 0)
 		{
 			printf("Case #%d: INSOMNIA\n",i+1);
 			continue;
 		}
 		for (j = 1;;j++)
 		{
 			nextN = N*j;
 			if (TRUE == scan_digits(nextN))
 			{
 				printf("Case #%d: %d\n", i+1, nextN);
 				break;
 			}
 		}
 	}
 	return TRUE;
 }

