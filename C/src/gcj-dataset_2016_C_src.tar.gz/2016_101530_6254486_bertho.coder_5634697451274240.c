
 #include<stdio.h>
 #include<string.h>
 #define MAX     100
 
 char str[MAX+11];
 
 int main()
 {
     freopen("in.txt", "r", stdin);
     freopen("out.txt", "w", stdout);
 
     int i, j, k, t, cs, n, cnt;
 
     scanf("%d", &t);
     for(cs = 1; cs <= t; cs++)
     {
         printf("Case #%d: ", cs);
 
         cnt = 0;
         scanf("%s", str + 1);
         n = strlen(str + 1);
 
         for(i = 1; i <= n; i++)
         {
             if(str[i] == '+') continue;
             j = i;
             while(j <= n && str[j] == '-') j++;
             if(i-1) cnt++;
             cnt++;
             i = j-1;
         }
 
         printf("%d\n", cnt);
     }
     return 0;
 }

