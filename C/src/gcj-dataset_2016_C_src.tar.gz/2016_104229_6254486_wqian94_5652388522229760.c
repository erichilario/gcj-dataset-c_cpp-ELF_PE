// A: Counting Sheep
 
 #include <stdbool.h>
 #include <stdint.h>
 #include <stdio.h>
 
 int main(int argc, char *argv[]) {
     unsigned int T;
     unsigned long long N;
     scanf("%u", &T);
     for (unsigned int i = 0; i < T; i++) {
         scanf("%llu", &N);
         uint16_t seen = 0;
         unsigned long long k;
         for (k = 1; k * N > (k - 1) * N; k++) {
             char buffer[100];
             sprintf(buffer, "%llu", k * N);
             for (char *ch = buffer; *ch != '\0'; ch++) {
                 seen |= (1LL << (*ch - '0'));
             }
             if (seen + 1 == (1LL << 10)) {
                 break;
             }
         }
         printf("Case #%u: ", i + 1);
         if (seen + 1 < (1LL << 10)) {
             printf("INSOMNIA\n");
         } else {
             printf("%llu\n", k * N);
         }
     }
 }

