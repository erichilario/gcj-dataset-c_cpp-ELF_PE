#include<stdio.h>
 #include<string.h>
 
 void prepend(char* s,  char c)
 {
     size_t len = 1;
      size_t i;
     memmove(s + len, s, strlen(s) + 1);
        for (i = 0; i < len; ++i)
     {
             s[i] = c;
        }
 }
 void prepend1(char* s,  char c)
 {
     int len = 1;
      int i;
      int len1 = strlen(s);
      for(i=len-1; i >=0 ;i--) {
 	     s[i+1] = s[i];
      }
      s[0] = c;
 }
 
 void main(void) {
 	int i = 0,j=1,k=1;
 	int test_cases = 0;
 	int len = 0;
 	int temp = 0;
 	char line[1024];
 	char new_string[1024];
 	FILE *fp = NULL;
 	fp = fopen("file","r");
 	fgets(line,1024,fp);
 	test_cases = atoi(line);
 	for(k = 1; k <=test_cases; k++) {
 		fgets(line,1024,fp);
 		len = strlen(line);
 		memset(new_string,0,1024);
 		for(i= 0; i < len-1; i++) {
 			if(i==0)
 				new_string[i] = line[i];
 			else {
 				//printf("\n %c %c %c \n",line[i],line[0],line[i-1]);
 				if((line[i] >= new_string[0])) {
 					prepend((char *)new_string,line[i]);
 				}
 				else
 					new_string[i] = line[i];
 			}
 			//printf("\n %s \n",new_string);
 		}
 		printf("Case #%d: %s\n", k, new_string);
 	}
 		
 	return;
 }
 

