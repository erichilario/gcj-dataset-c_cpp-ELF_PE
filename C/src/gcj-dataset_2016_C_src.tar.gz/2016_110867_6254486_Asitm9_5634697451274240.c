#include<stdio.h>
 
 int main(){
 	int T;
 	scanf("%d", &T);
 	int t;
 	for(t=1;t<=T;t++){
 		char a[106];
 		scanf("%s", a);
 		int l = strlen(a);
 		// printf("%d\n",l);
 		int i;
 		int c=0;
 		for(i=0;i<l;i++){
 			if(i>0 && a[i-1]!=a[i]) c++;
 		}
 		if(a[l-1]== '-' ) c++;
 		printf("Case #%d: %d\n",t,c);
 		
 	}
 	return 0;
 }

