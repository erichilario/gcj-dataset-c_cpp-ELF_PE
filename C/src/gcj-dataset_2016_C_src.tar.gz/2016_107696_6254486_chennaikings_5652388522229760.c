#include <stdio.h>
 
 int main(void) {
 	
 	int n[100],t,i,x[10],j,k,d,c,f,m;
 	scanf("%d",&t);
 		for(i=0;i<t;i++)
 	{
 		scanf("%d",&n[i]);
 	}
 	
 	for(k=0;k<t;k++)
 	{
 		for(i=0;i<10;i++)
 		{
 		x[i]=1;
 		}
 		
 	 if(n[k]==0)
 	 printf("\nCase #%d: INSOMNIA",k+1);
 	 else
 	{  m=n[k];f=0;
 		while(1)
 		 {
 		  d=m;
 		  while(d>0)
 		 {
 		 	c=d%10;
 		 	d=d/10;
 		    for(j=0;j<10;j++)
 		  	{
 		  		if(c==j)
 		  		 x[j]=0;
 		  	}
 		 }	
 		    for(j=0;j<10;j++)
 		    {
 		    	if(x[j]==0)
 		    	 f=1;
 		    	else
 		    	 {f=0; break;}
 		    }
 		  	
 		  	if(f==1)
 		  	 {  printf("\nCase #%d: %d",k+1,m);
 		  	 	break;
 		  	 }
 		  	 m=m+n[k];
 		  }
 	}
 	}
 	return 0;
 }
