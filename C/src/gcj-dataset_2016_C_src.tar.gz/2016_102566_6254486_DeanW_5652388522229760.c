#include <stdio.h>
 #include <stdlib.h>
 
 //#define DBG_PRINT
 
 #ifdef DBG_PRINT
 #define DbgPrintf(...) printf(__VA_ARGS__)
 #else
 #define DbgPrintf(...)
 #endif
 
 /* run this program using the console pauser or add your own getch, system("pause") or input loop */
 
 #define ALL_DIGIT 1023
 int digitEn;
 
 int checkDigit(int N)
 {
 	int a;
 	while(N) {
 		a = N % 10;
 		DbgPrintf("a: %d \n", a);
 		digitEn |= (1 << a);
 		DbgPrintf("digitEn: %d \n", digitEn);
 		if(digitEn == ALL_DIGIT) {
 			return 1;
 		}
 		N = N / 10;
 	}
 	return 0;
 }
 
 int main(int argc, char *argv[]) {
 	
 	int T;
 	int N;
 	int i, j;
 	int xN;
 
 	//DbgPrintf("MAX: %lld \n", LLONG_MAX);
 
 	scanf("%d", &T);
 	DbgPrintf("T: %d \n", T);
 
 	for( i = 1 ; i <= T ; i++ ) {
 		scanf("%d", &N);
 		DbgPrintf("N: %d \n", N);
 
 		if(N) {
 			digitEn = 0;
 			xN = N;
 			DbgPrintf("xN: %d \n", xN);
 			while( !checkDigit(xN) ) {
 				xN += N;
 				DbgPrintf("xN: %d \n", xN);
 			}
 	
 			printf("Case #%d: %d\n", i, xN);
 			DbgPrintf("\n");
 		}
 		else {
 			printf("Case #%d: INSOMNIA\n", i);
 			DbgPrintf("\n");
 		}
 
 	}
 
 	return 0;
 }

