#include <stdio.h>
 #include<string.h>
 int len;
 int noofflips = 0;
 
 int notsolved(int cakestack[])
 {
 	int i;
 	for(i = 0; i<len; i++)
 	{
 		if(cakestack[i] != 1)
 			break;
 	}
 	
 	if(i<len)
 		return 1;
 	return 0;
 }
 
 void flip(int a[], int pos)
 {
 	int temp;
 	for(int i = 0; i < pos; i++)
 		a[i] = 1 - a[i];
 		
 	for(int i = 0; i < pos/2; i++)
 	{
 	
 		temp = a[i];
 		a[i] = a[pos-i-1];
 		a[pos-i-1] = temp;
 	}
 	noofflips++;
 }
 
 void solve(int a[])
 {
 		int i;
 	while(notsolved(a))
 	{
 		if(a[0] == 0)
 		{
 			for(i = 0; i < len; i++)
 			{
 				if(a[i] == 1)
 					break;
 			}
 			flip(a, i);
 		}
 		
 		if(notsolved(a))
 		{
 			if(a[0] == 1)
 			{
 				for(i = 0; i < len; i++)
 				{
 					if(a[i] == 0)
 						break;
 				}
 			flip(a, i);
 			}	
 		}
 		
 	}
 }
 
 void convertinput(char inp[], int a[])
 {
 	len = strlen(inp);
 	for(int i = 0; i < len; i++)
 	{
 		if(inp[i]=='+')
 		{
 			a[i] = 1;
 		}
 		else if(inp[i] == '-')
 		{
 			a[i] = 0;
 		}
 	}
 }
 int main(void) {
 	
 	char inp[20];
 	int a[20], T;
 	int c = 0;
 	scanf("%d", &T);
 	
 	while(T>0)
 	{
 		c++;
 		noofflips = 0;
 		inp[0]='\0';
 		scanf("%s", inp);
 		convertinput(inp, a);
 		solve(a);
 		printf("Case #%d: %d\n", c, noofflips);
 		T--;
 	}
 	return 0;
 }

