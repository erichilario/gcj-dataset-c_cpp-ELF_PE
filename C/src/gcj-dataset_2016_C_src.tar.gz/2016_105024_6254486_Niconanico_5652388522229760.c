#include <stdio.h>
 
 int main()
 {
   int n;
   scanf("%d", &n);
   for(int i = 0; i < n; i++)
     {
       long long myNum = 0;
       long long ana = 0;
       int bitm = 0;
       int mult = 1;
       char anaStr[20] = "";
       scanf("%lld", &myNum);
 #if 1
       if (myNum == 0)
 	{
 	  printf("Case #%d: INSOMNIA\n", i+1);
 	}
       else
 	{
 	  int found = 0;
 	  while(mult < 1000)
 	    {
 	      int len;
 	      ana = myNum*mult;
 	      len = snprintf(anaStr, sizeof(anaStr), "%lld", ana);
 	      for(int k = 0; k < len; k++)
 		{
 		  bitm = bitm | (1 << (anaStr[k] - '0'));
 		}
 	      if (bitm == 1023)
 		{
 		  found = 1;
 		  break;
 		}
 	      mult++;
 	    }
 	  if (found)
 	    printf("Case #%d: %lld\n",i+1,ana);
 	  else
 	    printf("Case #%d: INSOMNIA\n", i+1);
 	}
 #endif      
     }
   return 0;
 }

