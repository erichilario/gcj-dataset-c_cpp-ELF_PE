#include<stdio.h>
 #include<string.h>
 int main(){
 	int t,a[12],i,j,l,f;
 	long long int n,k,m,mn,result;
 	scanf("%d", &t);
 	for(i=1;i<=t;i++){
 		memset(a,0,sizeof(a));
 		scanf("%lld", &n);
 		mn = n;
 		for(k=1;;k++){
 			if(n==0){
 				result = -1;
 				break;
 			}else{
 				mn = k*n;
 				m = mn;
 				while(m > 0){
 					l = m%10;
 					a[l] = 1;
 					m = m/10;
 				}
 				f = 0;
 				for(m = 0;m<=9;m++){
 					if(a[m] == 0){
 						f=1;
 						break;
 					}
 				}
 				if(f==0){
 					result = mn;
 					break;
 				}
 				
 			}
 		}
 		if(result == -1){
 			printf("Case #%d: INSOMNIA\n",i);
 		}else{
 			printf("Case #%d: %lld\n",i,result );
 		}
 	}
 	return 0;
 }

