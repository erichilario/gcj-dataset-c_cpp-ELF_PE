#include<stdio.h>
 #include<stdlib.h>
 
 long arr[10];
 
 int check()
 {
     int i,flag=-1;
     for(i=0;i<10;i++)
     {
         if(arr[i]==0)
         {
             flag=1;
             break;
         }
     }
     if(flag==1)
         return 0;
     else return 1;
 }
 
 void bisect(long n)
 {
     int rem;
     while(n>0)
     {
         if(n%10!=0)
             rem=(int)(n%10);
         else rem=0;
         arr[rem]+=1;
         n=n/10;
     }
 }
 long count(int x)
 {
     if(x==0)
     return -1;
     long i;
     for(i=1;check()!=1;i++)
     {
         bisect(x*i);
     }
     return x*(i-1);
 }
 static void reset()
 {
     int i;
     for(i=0;i<10;i++)
         arr[i]=0;
 }
 
 void main()
 {
     FILE *fp1,*fp2;
     fp1=fopen("abc.in","r");
     fp2=fopen("res.out","w");
 
     long *res;
     long T,N,i;
     fscanf(fp1,"%ld",&T);
     res=(long *)malloc(T*sizeof(long));
     for(i=0;i<T;i++)
     {
         fscanf(fp1,"%ld",&N);
         reset();
         res[i]=count(N);
     }
     for(i=0;i<T;i++)
     {
         if(res[i]!=-1)
         {
             fprintf(fp2,"Case #%d: %ld\n",i+1,res[i]);
         }
         else
         {
             fprintf(fp2,"Case #%d: INSOMNIA\n",i+1);
         }
     }
 }

