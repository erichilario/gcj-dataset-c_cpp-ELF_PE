#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 #include<string.h>
 
 int main()
 {//freopen("A-small-attempt0.in","r",stdin);
  //freopen("A-small-attempt0.out","w",stdout);
     
  int T,N,i,result,count,flag,j,temp,bit;
  int sign[10];
  
  
  scanf("%d",&T);
  for(i=1;i<=T;i++)
     {scanf("%d",&N);
      flag=0;
      if(N)
        {count=0;
         for(j=0;j<10;j++)
            sign[j]=0;
         for(j=1;j<=100;j++)
            {result=N*j;
             temp=result;
             while(temp)
                  {bit=temp%10;
                   if(!sign[bit])
                     {sign[bit]=1;
                      count++;
                     }
                    temp/=10; 
                  }
             if(count==10)
               {flag=1;
                break;
               }     
            }       
        }
     if(flag)
       printf("Case #%d: %d\n",i,result);
       else
         printf("Case #%d: INSOMNIA\n",i);   
     }
 return 0;
 }

