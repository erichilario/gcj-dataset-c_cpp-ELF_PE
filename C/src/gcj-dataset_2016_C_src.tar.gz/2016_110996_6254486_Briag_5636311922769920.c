#define __STDC_FORMAT_MACROS
 #include <inttypes.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 
 FILE * openIn() {
     FILE * pFile;
 
     pFile = fopen ("in","r+");
     return pFile;
 }
 
 
 FILE * out;
     
 int caseIndex = 1;
 void printResult(uint64_t result[], int size) {
     fprintf(out,"Case #%" PRIu64 ":", caseIndex);
     
     for(int i = 0; i < size; i++) {
         fprintf(out, " %" PRIu64, result[i]);
     }
     fprintf(out, "\n");
     caseIndex++;
 }
 
 
 void printFail() {
     fprintf(out,"Case #%d: IMPOSSIBLE\n", caseIndex);
     caseIndex++;
 }
 
 void compute(int K, int C, int S) {
 
     int neededS = K;
     
     for(int i = 1 ; i < C; i++) {
         neededS = floor(sqrt(K));
     }
 
     if(S < neededS)
         printFail();
     else {
         
         int size = K;
         uint64_t* place = malloc(size*sizeof(uint64_t));
         
         
         for(uint64_t i = 0; i < size; i++) {
             place[i] = i+1;
         }
         
         
         for(int i = 1; i < C; i++) {
             
             int newSize = (size / 2) + (size % 2);
             printf("Turn %d, Size = %d -> %d\n", i, size, newSize);
             
             uint64_t* newPlace = malloc(newSize*sizeof(uint64_t));
             
             for(int i = 0; i < newSize && 2*i + 1 < size; i++) {
                 
                 newPlace[i] = (place[i*2] - 1) * K + place[i*2+1];
                 printf("%d + %d = %d\n", (place[i*2] - 1) * K, place[i*2+1], newPlace[i]);
             } 
             
             if(size % 2 != 0) {
                 newPlace[newSize-1] = place[size - 1] * K;
                 printf("%d\n", newPlace[newSize-1]);
             }
             
             size = newSize;
             free(place);
             place = newPlace;
             
         }
         
         printResult(place, size);
         
         free(place);
         
     }
 }
 
 int main() {
     
     
     out = fopen ("out","w+");
     FILE * pDataFile = openIn();
     
     int N;
     
     int K, C, S;
     
     fscanf (pDataFile, "%i", &N);
     
     for(int i = 0; i < N; i++) {
         
         fscanf (pDataFile, "%i", &K);
         fscanf (pDataFile, "%i", &C);
         fscanf (pDataFile, "%i", &S);
         compute(K, C, S);
     }
     
     fclose (pDataFile);
     
     return 0;
 }

