#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <stdint.h>
 #include <math.h>
 #include <inttypes.h>
 #include <string.h>
 #define __STDC_FORMAT_MACROS
 #define BYTE uint64_t
 
 int t;
 char S[101];
 int main()
 {
     scanf("%d", &t);
     for (int i = 0; i < t; i++)
     {
         int m;
         scanf("%s", S);
         int length = strlen(S);
         int flips = 0;
         for (int j = 0; j < (length-1); j++)
         {
             if (*(S+j) != *(S+j+1))
             {
                 flips++;
             }
         }
         if (*(S+length-1) == '-')
             printf("Case #%d: %d\n",i+1, flips+1);
 
         else
             printf("Case #%d: %d\n", i+1, flips);
     }
     return 0;
 }

