#include<stdio.h>
 #include<string.h>
 
 int main(){
     char s[100];
     int plus,count,cont_minus,i,j,t,d=0,l;
     scanf("%d",&t);
     while(t>=1){
         count=0;
         cont_minus=0;
         plus=0;
         scanf("%s",s);
         for(i=0;i<strlen(s);i++){
                 l=0;
             if(s[i]=='+')
                 plus++;
             if(s[i]=='-'){
                 if(plus>=1){
                     count=count+2;
                     l=1;
                 }
 
                 while(s[++i]=='-');
                     if(!l)
                         count++;
                     i=i-1;
 
             }
         }d++;
         printf("Case #%d: %d\n",d,count);
         t--;
     }
 return 0;
 }

