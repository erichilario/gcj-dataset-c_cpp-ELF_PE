#include<stdio.h>
 #include<malloc.h>
 int main()
 {
     int t,n,i=0,j=1,k=0,a[10000],p,m,b[10],v,o=100,l=0,d[100],x;
     FILE *r,*q;
     scanf("%d",&t);
         r=fopen("abc.txt","r");
         for(i=0;(fscanf(r,"%d",&d[i]))!=EOF;)
         {
             i++;
         }
         fclose(r);
         for(i=0;i<100;i++)
         {
             printf("%d",d[i]);
         }
     while(t>0)
     {
         n=d[l];
         p=n;
         k=0;
         i=0;
         o=100;
         for(i=0;i<10;i++)
         {
             b[i]=i;
         }
         j=1;
     while(n>0)
     {
         while(n!=0)
         {
             a[i]=n%10;
             n=n/10;
             for(m=0;m<10;m++)
             {
                 if(b[m]==a[i])
                 {
                     b[m]=-1;
                     k++;
                 }
             }
             i++;
         }
         if(k==10)
         {
             break;
         }
         j++;
         n=j*p;
         v=n;
        }
     if(k==10)
     {
         printf("Case #%d: %d\n",101-t,v);
     }
     else
     {
         printf("Case #%d: INSOMNIA\n",101-t);
     }l++;
     t--;
     }
 }

