#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     freopen("input.in","r",stdin);
     freopen("newfile.txt","w",stdout);
     int t;
     scanf("%d",&t);
     int caseCount = 0;
     while(t--)
     {
     //int n;
     //scanf("%d",&n);
     caseCount++;
     char arr[1000];
     int i=0;
     int k=0;
     int count=0;
     scanf("%s",arr);
     int len = strlen(arr);
     int n = len-1;
 
     while(arr[n]!='\0')
     {
         int flag=0;
         if(arr[n]=='+')
         {
             n--;
             flag=1;
         }
         else if(arr[n]=='-')
         {
 
             int i=0;
             flag=0;
             for(i=n; i>=0; i--)
             {
                 if(arr[i]=='+' && flag==1)
                 {
                     count++;
                     flag=0;
                 }
                 else if(arr[i]=='-' && flag==0)
                 {
                     count++;
                     flag=1;
                 }
             }
             break;
         }
     }
     printf("Case #%d: %d\n",caseCount,count);
 
     }
     return 0;
 }

