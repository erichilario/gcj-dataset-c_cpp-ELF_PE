#include<stdio.h>
 int num[10];
 
 void traverse(int x){
     int y =0;
     while(x!=0){
         y = x % 10;
         num[y] = 1;
         x = x / 10;
     }
 }
 
 int sum(){
     int i =0;
     int s = 0;
     for(i=0;i<10;i++){
         s = s + num[i];
     }
     return s;
 }
 
 int main(){
     int t = 0;
     int i = 0;
     scanf("%d",&t);
     int temp = 1;
     while(t != 0){
 
         for(i=0;i<10;i++){
             num[i] = 0;
         }
 
         long int n = 0;
         long int fn = 0;
         int bla = 0;
 
         scanf("%ld",&n);
 
         if(n == 0){
             printf("Case #%d: INSOMNIA\n",temp);
         }
         else{
             while(sum() != 10){
                 fn = n * bla;
                 traverse(fn);
                 bla++;
             }
             printf("Case #%d: %ld\n",temp,fn);
         }
 
         temp = temp + 1;
         t = t - 1;
     }
 }

