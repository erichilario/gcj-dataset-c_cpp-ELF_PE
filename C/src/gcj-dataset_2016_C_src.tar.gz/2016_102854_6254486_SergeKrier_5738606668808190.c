#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 int T=1;
 
 #define N 32
 #define J 500
 
 __uint128_t divisor[11];
 
 char JAMS[N+1];
 
 __uint128_t JAM=((1<<(N-1))|1);
 
 __uint128_t jambase(__uint128_t base) {
 
   __uint128_t jam=0,coeff;
 
   for(int i=N-1;i>0;i--) {
     coeff=JAM>>i & 0x1;
     jam+=coeff;
     jam*=base;
   }
   jam+=JAM&0x1;
   return jam;
 
 }
 
 __uint128_t find_div(__uint128_t num) {
 
     __uint128_t max=10000,i;
     //max=floor(sqrt(num));
     max=10000; // no need to search long, skip to next candidate
 
     for(__uint128_t i = 3; i < max ; i+= 2)
          if (num % i == 0)
              return i;
     if (i>=max)
       return 0;
 
 }
 
 char *jams() {
   for (int i = 0; i < N; i++) {
       JAMS[i]=(JAM>>(N-1-i) & 1) ? '1' : '0';
   }
   JAMS[N]='\0';
   return JAMS;
 
 }
 
 
 
 int main() {
 
   int cnt=0,base;
   __uint128_t jam,div1;
   //scanf("%d",&T);
 
   printf("Case #%d:\n",T);
 
   while(cnt<J) {
 
 
     for (base=2;base<=10;base++) {
       jam=jambase(base);
       div1=find_div(jam);
       if (div1==0)
         break;
       else
         divisor[base]=div1;
     }
 
     if (base==11) {
       cnt++;
       printf("%s ",jams());
 
       for (base=2;base<=10;base++) {
         printf("%lld ",divisor[base]);
       }
       printf("\n");
     }
     JAM+=2;
 
   }
 
 
 }

