#include <stdio.h>
 
 int main()
 {
        int t,n,k,i,j,y,m,a[10],rem,flag;
        scanf("%d",&t);
        for(i=1;i<=t;i++)
        {
            scanf("%d",&n);
             for(k=0;k<10;k++)
                 a[k]=0;
                 
              flag=1;   
            for(y=1;y<=1000;y++)
             {
            
              m= y*n;
              while(m>0)
              {
                  rem=m%10;
                  m=m/10;
                  a[rem]++;
              }
              flag=1;
             for(j=0;j<10;j++)
              {
                 // printf("%d",a[j]);
                         if(a[j]==0)
                           flag=0;
              }
                      
             if(flag==1)
             break;
            else if(y>=1000)
             {
                 printf("Case #%d: INSOMNIA\n",i);
                 break;
             }
             
         }
         
         if(flag==1)
           printf("Case #%d: %d\n",i,y*n);
            
            
        }
 
     return 0;
 }

