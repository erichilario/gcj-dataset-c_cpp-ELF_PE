#include <stdio.h>
 #include <stdlib.h>
 
 int flip_stack(char *stack, int stack_len) {
   int i;
   for (i = 0; i < stack_len; i++) {
     if (stack[i] == 1) 
       stack [i] = 0;
     else 
       stack[i] = 1;
   }
 }
 
 int get_input(char *stack) {
   char c;
   int j = 0;
   int stack_len = 0;
     while (1) {
       scanf("%c",&c);
       if (c == '+')
         stack[j] = 1;
       else if (c == '-')
         stack[j] = 0;
       else if (c == '\n')  
         break;
       j++;
       stack_len++;
     }
   return stack_len;
 }
 
 int work(char *stack, int stack_len) {
   int i;
   int flips = 0;
   for (i = stack_len-1; i >= 0; i--) {
     if (stack[i] != 1) {
       flip_stack(stack, stack_len);
       flips++;
     }
     stack_len--;
   }
   return flips;
 }
 
 int main(int argc, char* argv[]) {
   int n;
   int i,j,k;
   char stack[100];
   int stack_len;
   scanf("%d", &n);
 
   for (i = 0; i <= n; i++) {
     stack_len = get_input(stack);
     if (stack_len == 0) {
       // Skip 0 len stack caused by number of test cases T.
     } else {
       printf("Case #%d: %d\n", i, work(stack, stack_len));
     }
   }
 
   return 0;
 } 

