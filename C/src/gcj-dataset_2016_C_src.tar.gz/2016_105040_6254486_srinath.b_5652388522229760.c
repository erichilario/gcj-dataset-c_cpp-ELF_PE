#include<stdio.h>
 
 int main() {
 	int t,t1,i,j,n,count;
 	scanf("%d",&t);
 	t1=t;
 	while(t--){
 		scanf("%d",&n);
 		int flag[10]={0};
 		count=0;
 		j=1;
 		if(n==0) {
 			printf("Case #%d: INSOMNIA\n",t1-t);
 			continue;
 		}
 		while(1){
 			int temp=n*j,r;
 			while(temp>0){
 				r=temp%10;
 				temp=temp/10;
 				if(flag[r]==0) {
 					flag[r]=1;
 					count++;
 				}
 				else continue;
 			}
 			if(count<10)
 				j++;
 			else break;
 		} 
 		printf("Case #%d: %d\n",t1-t,j*n);
 	}
 	return 0;
 }
