#include <stdio.h>
 
 int main() {
     int t, i;
     scanf("%d", &t);
     for (i = 0; i < t; i++) {
         int k,c,s;
         scanf("%d %d %d", &k, &c, &s);
         printf("Case #%d:", i+1);
         int j;
         for (j = 1; j <= s; j++) {
             printf(" %d", j);
         }
         printf("\n");
     }
 }

