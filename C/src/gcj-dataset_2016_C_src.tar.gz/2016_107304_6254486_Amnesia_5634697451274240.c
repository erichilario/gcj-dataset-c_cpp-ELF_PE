// utilizing the obvious simple, optimal algorithm
 
 #include <stdio.h>
 
 int main() {
 	char paincakes[101]="";
 	int current=1;
 	int cases;
 
 	scanf("%d",&cases);
 
 	while (scanf("%s",paincakes) && cases>0) {
 		int flips=0;
 		char *ppaincakes=paincakes;
 		char last=0;
 		
 		// solve
 		last=*ppaincakes;
 		while (*ppaincakes != '\0') {
 			if (*ppaincakes==last) {
 				ppaincakes++;
 				continue;
 			}
 			last=*ppaincakes;
 			flips++;
 			ppaincakes++;
 		}
 		
 		// should be a finished state. final check on solution
 		if (last == '-') {
 			flips++;
 		}
 		
 		printf("Case #%d: %d\n",current,flips);
 		current++;
 		cases--;
 	}
 
 	return 0;
 }
 

