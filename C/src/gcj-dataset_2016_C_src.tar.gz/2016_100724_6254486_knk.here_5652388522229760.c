#include <stdio.h>
 
 int main(void) {
 int t=0,i=0;
 scanf("%d",&t);
 	for(i=1;i<=t;i++)
 	{
 		int x=0,j=0,k=0,temp=0,l=1,no=10,remainder=0;
 		int a[10]={0,1,2,3,4,5,6,7,8,9};
 		scanf("%d",&x);	
 		if(x!=0)
 		{ 
 		    temp=x;
 		   while(no!=0)
 		   {	temp=l*x;
 		   //split a number int digits and check
 				   while(temp != 0)
 				   {
 					  remainder = temp % 10;	
 					  for(j=0;j<no;j++)
 					  {
 							if(a[j]==remainder)
 							{ no--;  
 							  for(k=j;k<no;k++)
 							  a[k] = a[k+1];
 							}	
 					  }
 					  temp= temp / 10;
 				   }
 			l++;
 		   }
 			printf("Case #%d: %d\n",i,((l-1)*x)); 
 		}
 		 else{  
 		   printf("Case #%d: INSOMNIA\n",i);
 			 }	
 	}
 	return 0;
 }

