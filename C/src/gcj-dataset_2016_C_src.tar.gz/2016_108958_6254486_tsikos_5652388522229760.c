//
 //  main.c
 //  Code Jam
 //
 //  Created by Konstantinos Mitropoulos on 9/4/2016.
 //  Copyright (c) 2016 NTUA. All rights reserved.
 //
 
 #include <stdio.h>
 
 int main(int argc, const char * argv[]) {
 
     FILE *fp;
     
     fp = fopen ("/Users/konstantinos/Desktop/A-small-attempt0.in.txt", "r");
     
     
     int T, N, i, j, Digits[10];
     fscanf(fp, "%d", &T);
 
     
     
     for (i = 0; i < T; i++) {
         fscanf(fp, "%d", &N);
         //Initialization of Digits array
         for (j = 0; j < 10; j++) Digits[j] = 0;
         //N = 0 case
         if (N == 0) {
             printf("Case #%d: INSOMNIA\n", i+1);
             continue;
         }
         
         //N != 0 cases
         int count = 0;
         int Ncons = N;
         while (1 == 1) {
             int check = N;
             int temp = 0;
             
             while (check != 0) {
                 temp = check % 10;
                 
                 if (Digits[temp] == 0) {
                     Digits[temp] = 1;
                     count++;
                 }
                 
                 check = check / 10;
             }
             
             if (count == 10) {
                 printf("Case #%d: %d\n", i+1, N);
                 break;
             }
         
             N = N + Ncons;
         
             
         }
         
         
         
     }
     
     fclose(fp);
     return 0;
 }

