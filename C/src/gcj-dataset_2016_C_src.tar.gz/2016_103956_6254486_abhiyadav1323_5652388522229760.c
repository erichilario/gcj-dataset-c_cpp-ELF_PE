#include <stdio.h>
 
 int main(void) {
 	// your code goes here
     //FILE *fp=fopen('','r');
 	int t,j;
 	scanf("%d",&t);
 	for(j=1;j<=t;j++)
 	{
         int n,count=0,a[10]={0};
         scanf("%d",&n);
         long long int temp,i=1,flag=0;
         
         if(n==0)
             printf("Case #%d: INSOMNIA\n",j);
         else{
         for(i=1;;i++)
             {
             flag+=n;
             temp=flag;
             while(temp)
                 {
                 int var=temp%10;
                 if(a[var]==0)
                 {
                     count++;
                     a[var]=1;
                 }
                 temp/=10;
             }
             if(count==10)
                 {
                 printf("Case #%d: %lld\n",j,flag);
                 break;
             }
         }
         }
         
 	}
     
 	return 0;
 }
 

