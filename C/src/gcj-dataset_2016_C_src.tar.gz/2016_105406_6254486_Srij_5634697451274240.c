#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 
 int main(){
 	int T;
 	int tn = 1;
 	scanf("%d", &T);	
 	while(tn <= T){
 		int length;
 		char string[100 + 10];
 		scanf("%s", string);
 		length = strlen(string);
 		int index = length - 1;
 		int flag = 1;
 		int inversions = 0;
 		if(index >= 0){
 			if(string[index] == '+'){
 				while(string[index] == '+'){
 						if(index >= 0)
 							index --;
 						else 
 							break;
 					}
 			}
 		}
 		// - means 0, + means 1
 		while (index >= 0){
 			if(string[index] == '+'){
 				if(flag == 0){
 					inversions ++;
 					flag = 1;
 				}
 				
 				while(string[index] == '+'){
 					if(index >= 0)
 						index --;
 				}
 
 			}
 
 			else if(string[index] == '-'){
 				if(flag == 1){
 					inversions ++;
 					flag = 0;
 				}
 				index--;
 			}
 			
 		}
 		printf("Case #%d: %d\n", tn, inversions);
 		tn++;
 	}
 }
