#include<stdio.h>
 int main()
 {
     FILE *in=fopen("input.txt","r");
     FILE *out=fopen("output.txt","w");
     int caseT, i, j, c, a[10]={0,},cnt=0, n, times=1, checkN;
 
     fscanf(in,"%d",&caseT);
 
     for(c=1;c<=caseT;c++)
     {
         fscanf(in,"%d",&n);
         cnt=0;
         times=1;
         for(j=0;j<10;j++)
             a[j]=0;
 
         while(cnt!=10)
         {
             if(n==0)
             {
                 fprintf(out,"Case #%d: INSOMNIA\n",c);
                 break;
             }
             cnt=0;
             n = n*times;
             checkN=n;
             //printf("%d ",n);
 
             while(checkN>0)
             {
                 a[checkN%10]++;
                 checkN/=10;
             }
             for(i=0;i<10;i++)
             {
                 if(a[i]>0)
                     cnt++;
             }
             if(cnt==10)
             {
                 fprintf(out,"Case #%d: %d\n",c,n);
             }
              n/=times;
              times++;
         }
     }
 }

