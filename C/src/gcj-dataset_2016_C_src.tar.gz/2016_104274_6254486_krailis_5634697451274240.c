#include <stdio.h>
 #include <stdlib.h>
 
 int main (void) {
 
     int T, i, m_to_p, p_to_m, j;
     char s[101];
 
     scanf("%d\n", &T);
     for (i = 1; i <= T; i++) {
         m_to_p = 0;
         p_to_m = 0;
         scanf("%s", s);
         j = 1;
         while (s[j] != '\0') {
             if (s[j-1] == '+' && s[j] == '-')
                 p_to_m += 1;
             if (s[j-1] == '-' && s[j] == '+')
                 m_to_p += 1;
             j++;
         }
         if (m_to_p == 0 && p_to_m == 0) {
             if (s[0] == '+')
                 printf("Case #%d: %d\n", i, 0);
             else if (s[0] == '-')
                 printf("Case #%d: %d\n", i, 1);
         }
         else {
             printf("Case #%d: %d\n", i, m_to_p + p_to_m + 1);
         }
     }
     return 0;
 }

