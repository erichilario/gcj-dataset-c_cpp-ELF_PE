#include<stdio.h>
 int main()
 {
 	int i,t;
 	scanf("%d",&t);
 	for(i=1;i<=t;i++)
 	{
 		char s[10001],ans[20001];
 		int j,left,right;
 		scanf("%s",s);
 		ans[1000]=s[0];
 		left=right=1000;
 		for(j=1;s[j]!='\0';j++)
 		{
 			if(ans[left]<=s[j])
 			{
 				left--;
 				ans[left]=s[j];
 			}
 			else
 			{
 				right++;
 				ans[right]=s[j];
 			}
 		}
 		printf("Case #%d: ",i);
 		for(j=left;j<=right;j++)
 		{
 			printf("%c",ans[j]);
 		}
 		printf("\n");
 	}
 }

