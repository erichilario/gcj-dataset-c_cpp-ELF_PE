#include<stdio.h>
 int main(){
     int t = 0;
     scanf("%d",&t);
     int temp = 1;
     while(t != 0){
         char ip[101];
         int i = 0;
 
         scanf("%s",ip);
 
         int p = 0;
         int m = 0;
         int count = 0;
 
         if(ip[0] == '+'){
                 p = 1;
             }
             else{
                 m = 1;
         }
         //printf("INIT :: P: %d M: %d \n",p,m);
         while(ip[i] != '\0'){
             if( p == 1 && ip[i] == '-'){
                 //printf("MISMATCH - \n");
                 count++;
                 p = 0;
                 m = 1;
             }
             else if( m == 1 && ip[i] == '+'){
                 //printf("MISMATCH + \n");
                 count++;
                 p = 1;
                 m = 0;
             }
             //printf("P: %d M: %d \n",p,m);
             i++;
         }
         if(ip[i-1] == '-'){
             count++;
         }
         printf("Case #%d: %d\n",temp,count);
         temp = temp + 1;
         t = t - 1;
     }
 }
 

