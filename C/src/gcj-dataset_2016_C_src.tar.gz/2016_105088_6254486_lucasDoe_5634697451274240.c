#include <stdio.h>
 #include <string.h>
 #define CHANGE(symbol) ((symbol) == '+' ? '-' : '+')
 #define ABS(my_val) ((my_val) < 0) ? -(my_val) : (my_val)
 void flip(char * readed, int lengh, int m)
 {
    int i;
    char tmp, changed[101];
 
    if (m == 0)
       for (i = 0; i < lengh; i++)
          changed[i] = CHANGE(readed[lengh-i-1]);
 
    else
    {
       for (i = 0; i < m; i++)
          changed[i] = CHANGE(readed[m-i-1]);
 
       for (i = m; i < lengh; i++)
          changed[i] = readed[i];
    }
 
    memcpy(readed, changed, lengh);
 }
 
 int header(char * readed, int lengh)
 {
    int i;
    for (i = 0; i < lengh; i++)
       if (readed[i] == '-')
          break;
 
    flip(readed, lengh, i);
 }
 
 int completed(char * readed, int lengh)
 {
    int i, ans = 0;
    for (i = 0; i < lengh; i++)
       if (readed[i] == '-')
          ans = i+1;
 
    return ans;
 }
 
 void main(int argc, char * argv[])
 {
    int i, j, remain;
    int t, n;
    char readed[101];
 
    scanf("%d\n", &t);
    for(i = 0; i < t; i++)              // Test cases.
    {
       printf("Case #%d: ", i+1);
       scanf("%s\n", &readed);
       remain = completed(readed, strlen(readed));
 
       j = 0;
       while (remain != 0)
       {
          j++;
          header(readed, remain);
          remain = completed(readed, strlen(readed));
       }
 
       printf("%d\n", j);
    }
 }

