#include <stdio.h>
 
 int main() {
   int t;
   fscanf(stdin, "%d", &t);
   for(int tt = 0; tt < t; ++tt) {
     int n;
     fscanf(stdin, "%d", &n);
     int x;
     int a[2501];
     for(int i = 0; i < 2501; ++i) {
       a[i] = 0;
     }
     int min=10000, max = 0;
     for(int i = 0; i < 2*n-1; ++i)
       for(int j = 0; j < n; ++j) {
 	fscanf(stdin, "%d", &x);
 	a[x]++;
 	if(max < x) {
 	  max = x;
 	}
 	if(min > x)
 	  min = x;
       }
     fprintf(stdout, "Case #%d: ", tt+1);
     for(int i = min; i <= max; ++i) {
       if(a[i] & 1)
 	fprintf(stdout, "%d ", i);
     }
     fprintf(stdout, "\n");
   }
   
 }

