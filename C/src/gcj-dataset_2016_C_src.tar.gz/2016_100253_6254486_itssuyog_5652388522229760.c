#include <stdio.h>
 
 void initialize(int A[])
 {
 	for(int i=0; i<10; i++)
 		A[i] = 10;
 }
 
 void addToarray(int num, int X[])
 {
 	if(X[num] == 10)
 	{
 		X[num] = num;
 	}
 }
 
 void extractNum(int n, int Y[])
 {
 	int digit;
 	
 	while(n>0)
 	{
 		digit = n % 10;
 		n = n/10;
 		addToarray(digit, Y);
 	}
 }
 
 int checkFilled(int Z[])
 {
 	int i;
 	for(i=0; i<10; i++)
 	{
 		if(Z[i] != i)
 			break;
 	}
 	
 	if(i == 10)
 		return 1;
 	
 	return 0;
 }
 
 
 int main(void) {
 	
 	int A[10];
 	int flag;
 	int x = 1;
 	int n, count, T, y;
 	
 	scanf("%d", &T);
 	while(T>0)
 	{
 		initialize(A);
 		flag = 9;
 		count = 1;
 		scanf("%d", &n);
 		
 		if(n > 0)
 		{
 			while(checkFilled(A) == 0)
 			{
 				if(count==1000)
 					break;
 				
 				y = n*count;
 				extractNum(y, A);
 				count++;
 			}
 		}
 		else
 		{
 			flag = 0;
 		}
 		
 		if(count < 1000 && flag == 9)
 		{
 			flag = 1;
 		}
 		else
 		{
 			flag = 0;
 		}
 		
 		if(flag == 1)
 		{
 			printf("Case #%d: %d\n", x, y);
 
 		}
 		else
 		{
 			printf("Case #%d: INSOMNIA\n", x);
 
 		}
 		T--;
 		x++;
 	}
 	return 0;
 }

