#include<stdio.h>
 #include<math.h>
 
 long long int b[35],t,t1,i,n,j,bs[15],fcount,jcount;
 
 long long int notPrime(long long int n) {
     int i;
     if(n==2) return 0;
     if(n%2==0) return 2;
     for(i=3;i<=sqrt(n);i+=2)
         if(n%i==0)
             return i;
     return 0;
 }
 int decimal_binary(long long int dec,long long int base) {
     long long int i=0,quotient;
     quotient = dec;
     while(quotient!=0) {
         b[i++]=quotient%base;
         quotient=quotient/base;
     }
 }
 void display(long long int bs[]) {
 	decimal_binary(bs[2],2);
 	for(i=n-1;i>=0;i--)
 		printf("%d",b[i]);
 	for(i=2;i<=10;i++)
 		printf(" %lld",notPrime(bs[i]));
 	printf("\n");
 }
 long long int generate(long long int dec,int base) {
 	dec>>1;
 	dec+=base;
 	dec<<1;
 	dec|1;
 	return dec;
 }
 int main() {
 	bs[0]=bs[1]=0;
 	scanf("%d",&t);
 	t1=t;
 	while(t--) {
 		printf("Case #%d:\n",t1-t);
 		fcount=jcount=0;
 		scanf("%d %d",&n,&j);
 		for(i=2;i<=10;i++) {
 			bs[i]=pow(i,n-1)+1;
 			if(notPrime(bs[i])) 		
 				fcount++;
 		}
 		if(fcount==9) {
 			display(bs);
 			jcount++;
 		}
 		while(jcount<j) {
 			fcount=0;
 			for(i=2;i<=10;i++) {
 				bs[i]=generate(bs[i],i);
 				if(notPrime(bs[i])) 
 					fcount++;
 			}
 			if(fcount==9) {
 				display(bs);
 				jcount++;
 			}
 		}
 	}	
 	return 0;
 }
