#include <stdio.h>
 
 
 int main(){
 	int i, restant, nb;
 	int q,r;
 	int tab[10]={0};
 	printf("0 INSOMNIA\n");
 	for(nb=1;nb<=1000000;nb++){
 		restant = 10;
 		i=0;
 		do {
 			i+=nb;
 			q=i;
 			while(q){
 				r=q%10;
 				q=q/10;
 				if(tab[r]==0){
 					tab[r]=1;
 					restant--;
 				}
 			}
 		} while(restant);
 		printf("%d %d\n", nb,i);
 		for(i=0;i<10;i++){
 			tab[i]=0;
 		}
 	}
 	return 0;
 } 

