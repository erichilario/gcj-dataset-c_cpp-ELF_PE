#include<stdio.h>
 
 
 int main()
 {int t,z,i,y,n,d,a[10]={0},flag=0,x=1;
 scanf("%d",&t);
 for(z=0;z<t;z++)
 {
 for(i=0;i<10;i++)
 a[i]=0;
 flag=0;x=1;
 scanf("%d",&n);y=n;
 while (flag<10)
 {flag=0;x++;
 while(n>0)
 {
 d=n%10;
 n=n/10;
 a[d]=1;}
     for(i=0;i<10;i++)
   {
    if(a[i]!=0)
      flag++;
    }
    if(flag==0)
    {printf("Case #%d: INSOMNIA\n",z+1);
    break;}
 n=x*y;
 }
 n=n-y;
 if(flag==10)
 printf("Case #%d: %d\n",z+1,n);
 }
 }
