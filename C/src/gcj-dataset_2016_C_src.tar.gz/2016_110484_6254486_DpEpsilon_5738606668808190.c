#include <stdio.h>
 #define N 16
 #define J 50
 #define SIEVE_SIZE 100000001
 
 char sieve[SIEVE_SIZE];
 
 int primes[SIEVE_SIZE/2];
 int p_upto = 0;
 int found = 0;
 
 int factors[11];
 
 int is_jamcoin(int coin);
 
 int main() {
     int i;
     for (i = 2; i < SIEVE_SIZE; i++) {
         if (sieve[i]) continue;
         int j;
         for (j = i*2; j < SIEVE_SIZE; j += i) {
             sieve[j] = 1;
         }
         primes[p_upto++] = i;
     }
     //printf("Done sieve %d\n", p_upto);
     for (i = (1<<(N-1))+1; found < J; i += 2) {
         if (is_jamcoin(i)) {
             found++;
             int start_bit = 1 << (N-1);
             while (start_bit != 0) {
                 if (start_bit & i) {
                     putchar('1');
                 } else {
                     putchar('0');
                 }
                 start_bit >>= 1;
             }
             int j;
             for (j = 2; j <= 10; j++) {
                 printf(" %d", factors[j]);
             }
             putchar('\n');
         }
     }
 
     return 0;
 }
 
 int is_jamcoin(int coin) {
     //printf("coin %d\n", coin);
     int b;
     for (b = 2; b <= 10; b++) {
         long long num;
         if (b != 2) {
             num = 0;
             int start_bit = 1 << (N-1);
             while (start_bit != 0) {
                 if (start_bit & coin) {
                     num = num*b + 1;
                 } else {
                     num = num*b;
                 }
                 start_bit >>= 1;
             }
         } else {
             num = (long long)coin;
         }
         //printf("base %d: %lld\n", b, num);
         int i;
         factors[b] = -1;
         for (i = 0; i < p_upto; i++) {
             if (num % (long long)primes[i] == 0) {
                 if (num == (long long)primes[i]) return 0;
                 factors[b] = primes[i];
             }
         }
         if (factors[b] == -1) return 0;
     }
     return 1;
 }

