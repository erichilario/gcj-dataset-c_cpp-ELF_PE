#include <stdio.h>
 #include<string.h>
 
 FILE *p,*q;
 
    //fscanf(p,"%ld",&t);
    //fprintf(q," %ld",t);
 
 int main(void) 
 {
 	int t,i,j,l,n,sp;
 	
 	p=fopen("input","r+");
 	q=fopen("output","w+");
 	fscanf(p,"%d",&t);
 	for(i=1;i<=t;i++)
 	{
 		int a[1000],c[1000],s[1000],count=0,tot1,tot2,prev,k;
 		fscanf(p,"%d",&n);
 		for(j=0;j<n;j++)
 		{
 			a[j]=0;
 			c[j]=0;
 			fscanf(p,"%d",&s[j]);
 			s[j]--;
 		}
 		//printf("\n0->");
 		c[0]=1;
 	for(count=0,prev=-1,tot1=0,tot2=0,j=0;count<=n;count++)
 		{
 			if(a[j]==0)
 			{
 				//printf("%d->",s[j]);
 				a[j]=1;
 				prev=j;
 				j=s[j];
 			}
 			else
 			{
 			//	printf(" #### ");
 				c[j]=1;
 				for(l=0;l<n;l++)
 				{
 					a[l]=0;
 				}
 				if(prev!=-1)
 				{
 				
 					printf("\n");
 					for(k=j,tot1=0;k!=prev;k=s[k],tot1++)
 					{
 						c[k]=1;		
 					}
 					c[prev]=1;
 					if(tot2<tot1)
 						tot2=tot1;
 				}
 				for(k=0;c[k]==1&&k<n;k++);
 				j=k;
 				c[j]=1;
 		//		printf("%d->",j);
 				prev=-1;
 			}
 				printf("\n");
 			for(k=0;k<n;k++)
 		//		printf("%d ",c[k]);
 			printf("\n");
 			
 		}
 		printf("Case closed %d",i);
 		fprintf(q,"Case #%d: %d\n",i,tot2+1);
 		
 		
 	}
 	fclose(p);
 	fclose(q);
 	return 0;
 }
