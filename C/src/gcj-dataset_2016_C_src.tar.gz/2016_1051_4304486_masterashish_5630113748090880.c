#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int main()
 {
  int testcase;
  int array[2600];
  int count;
  int n, input;
  int count_1, element, i, j;
  int output[2500];
 
  scanf("%d", &testcase);
 
  for(count = 1 ; count <= testcase ; count++)
  {
   memset(array, 0, sizeof(array));
   memset(output, 0 , sizeof(output));
   scanf("%d", &n);
   element = 0;
 
   for(count_1 = 0 ; count_1 < ((2*n) - 1)*n ; count_1++)
   {
    scanf("%d", &input);
 
    array[input] += 1;
   }
 
   for( count_1 = 0 ; count_1 < 2600 ; count_1++)
   {
    array[count_1] %= 2;
    if(array[count_1] != 0)
    {
     output[element] = count_1;
     element++;
    }
   }
 
   for(i = 1 ; i < element ; i++)
   {
    for( j = 0 ; j < element ; j++)
    { 
     int temp = 0;
     if(output[i] < output[j])
     {
      temp = output[i];
      output[i] = output[j];
      output[j] = temp;
     }
    }
   }
 
   printf("Case #%d: ", count);
   for(count_1 = 0 ; count_1 < element ; count_1++)
   {
    printf("%d ", output[count_1]);
   }
   printf("\n");
  }
 }
 

