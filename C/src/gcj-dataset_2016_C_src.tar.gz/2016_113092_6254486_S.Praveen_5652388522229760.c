#include<stdio.h>
 int digit[10];
 int isAllDigits();
 int main(){
     int t,n,ti,i,val;
     scanf("%d",&t);
     for(ti=1;ti<=t;ti++){
 	for(i=0;i<10;i++)
 	    digit[i]=0;
 	scanf("%d",&n);
 	if(n==0)
 	    printf("Case #%d: INSOMNIA",ti);
 	else{
 	    for(i=1;;i++){
 		val=i*n;
 		while(val!=0){
 		    digit[val%10]=1;
 		    val/=10;
 		    if(isAllDigits()){
 			printf("Case #%d: %d",ti,i*n);
 			goto e;
 		    }
 		}
 	    }
 	}
 e:printf("\n");
     }
     return 0;
 }
 int isAllDigits(){
     int i;
     for(i=0;i<10;i++){
 	if(digit[i]==0)
 	    return 0;
     }
     return 1;
 }

