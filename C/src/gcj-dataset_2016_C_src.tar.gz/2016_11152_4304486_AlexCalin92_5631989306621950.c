#include <stdio.h> 
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 int size_buf(char buf[105]){
     int i=0;
     int n=0;
     while(buf[i]!=NULL)
         i++;
     return i;
 }
 int main()
   {
         FILE *ptr_file;
         FILE *out_file;
         char buf[105];
         char numar[50]="";
         //char response[105]="";
         //int numar[105];
         int nr=0;
         int n,j;
         unsigned long int cifre[11];
         int dimensiune;
         int i;
         int q;
         int nr1;
         unsigned long int ij;
         unsigned long int numar_baza;
         unsigned long int numar_prim;
         int pluss;
         ptr_file = fopen("Input","r");
         out_file = fopen("Output1","w");
         fgets(buf,105, ptr_file);
         int num_test = atoi(buf);  
                  
         for(nr1=1;nr1<=num_test;nr1++)
         {   
             fgets(buf,105, ptr_file);
             nr=size_buf(buf);
             char response[105]="";
             for(i=0;i<nr;i++){
                 if (i==0) response[i]=buf[i];
                 else {
                     if (response[0]>buf[i]) response[i]=buf[i];
                         else {
                             for (j=i;j>=0;j--)
                                 response[j]=response[j-1];
                             response[0]=buf[i];
                         }  
                 }
             }
             fprintf(out_file,"Case #%i: %s",nr1,response);
         }
     fclose(ptr_file);
     fclose(out_file);
         return 0;
 }
