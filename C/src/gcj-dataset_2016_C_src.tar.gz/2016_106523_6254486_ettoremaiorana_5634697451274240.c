#include <stdio.h>
 #include <string.h>
 
 void print_array(int array[], int size) {
 	int i;
 	for (i = 0; i < size; i++) {
 		printf("%d ", array[i]);
 	}
 	printf("\n");
 }
 
 int sumDigits (int digits[], int size) {
 	int i;
 	int sum = 0;
 	for (i = 0; i < size; i++) {
 		sum += digits[i];
 	}
 	return sum;
 }
 
 int find_cons(int digits[], int size) {
 	int i;
 	int cons = 1;
 	if (digits[size - 1] == -1) {
 		return 0;
 	}
 	for (i = size-1; i > 0; i--) {
 		if (digits[i] == 1 && digits[i-1] == 1) {
 			cons++;
 		} else {
 			break;
 		}
 	}
 	return cons;
 }
 
 void flip_first(int size, int digits[]) {
 	int i;
 	for (i = 0; i < size; i++) {
 		digits[i] *= -1;
 	}
 }
 
 void reverse(int digits[], int size) {
 	int i;
 	for (i = 0; i < size/2; i++) {
 		int temp = digits[size - i - 1];
 		digits[size - i - 1] = digits[i]*-1;
 		digits[i] = temp*-1;
 	}
 	if (size % 2 == 1) {
 		digits[size/2 + 1] *= -1;
 	}
 }
 
 int main() {
 
 	FILE *file, *o_file;
 	int n, i, j, err;
 	file = fopen("A-small-pancakes.in", "r");
 	o_file = fopen("A-small-pancakes.out", "w");
 	err = fscanf(file, "%d", &n);
 	if (err < 0) {
 		printf("unable to read from file");
 		return 1;
 	}
 	for (i = 1; i <= n; i++) {
 		char line[100];
 		if(fscanf(file, "%s", &line) < 0) {
 			printf("Unable to read a line");
 			return 1;
 		}
 		int s_length = strlen(line);
 		printf("%s is %d character long\n", line, s_length);
 		int digits[s_length];
 		for (j = 0; j < s_length; j++) {
 			if (line[j] == '-') {
 				digits[j] = -1;
 			}
 			else {
 				digits[j] = 1;	
 			}
 		}
 		if (s_length == 1) {
 			int response = 1;
 			if (digits[0] == 1) {
 				response = 0;
 			}
 			fprintf(o_file, "Case #%d: %d\n", i, response);
 			continue;
 		}
 		int sum = sumDigits(digits, s_length);
 		printf("The initial sum of digits is %d\n", sum);
 		int iter = 0;
 		//if (sum < -1) {
 		//	reverse(digits, s_length);
 		//	iter++;
 		//}
 		while (sum < s_length) {
 			print_array(digits, s_length);
 			int cons = find_cons(digits, s_length);
 			printf("Cons are %d\n", cons);
 			flip_first(s_length - cons, digits);
 			iter++;
 			printf("Iter is %d\n", iter);
 			print_array(digits, s_length);
 			sum = sumDigits(digits, s_length);
 			printf(".. and the sum is %d whereas length is %d\n", sum, s_length);
 		}
 		printf("Done!\n");
 		printf("Case #%d: %d\n", i, iter);
 		fprintf(o_file, "Case #%d: %d\n", i, iter);
 	}
 
 	fclose(file);
 	fclose(o_file);
 	return 0;
 }

