#include <stdio.h>
 
 int main() {
 	int t, T;
 	scanf("%d",&T);
 	int K, C, S;
 	for(t=1;t<=T;t++) {
 		scanf("%d %d %d", &K, &C, &S);
 		printf("Case #%d: ", t);
 		for (int i = 0; i < K; ++i)
 		{
 			printf("%d ", i+1);
 		}
 		printf("\n");
 	}
 
 	return 0;
 }
