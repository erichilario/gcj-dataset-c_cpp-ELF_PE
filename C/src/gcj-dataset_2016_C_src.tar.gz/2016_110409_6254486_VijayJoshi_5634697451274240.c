// Problem 2
 #include<stdio.h>
 typedef long long unsigned int LLU;
 typedef long long int LL;
 
 char S[105];
 
 void solve();
 int getLastBlankCookieIdx(int);
 void flipCookies(int,int);
 void flipHappySides();
 
 int main(void)
 {
     int T,t;
 /*
     freopen("sample_input.txt","r",stdin);
     freopen("sample_output.txt","w",stdout);
 
 
     freopen("s_input_attempt1.in","r",stdin);
     freopen("s_output_attempt1.txt","w",stdout);
 */    
 
     freopen("b_input.in","r",stdin);
     freopen("b_output.txt","w",stdout);
 
     scanf("%d",&T);
     for(t=1;t<=T;t++)
      {
        printf("Case #%d: ",t);
        solve();
        printf("\n");
      }
     return 0;
 }
 
 void solve()
 {
      int i,lastBlankCookieIdx=-1;
      LLU ans=0;
      scanf("%s",S);
      
      for(i=0;S[i]!='\0';i++) {
          if(S[i]=='-')
            lastBlankCookieIdx=i;
      }  
 
      while(lastBlankCookieIdx!=-1) {
        if(S[0]=='+') {
              flipHappySides();
              ans++;             
        }        
        flipCookies(0,lastBlankCookieIdx);
        ans++;
        lastBlankCookieIdx=getLastBlankCookieIdx(lastBlankCookieIdx);       
      }
      
      printf("%llu",ans);
 }
 
 int getLastBlankCookieIdx(int upto) {  
     int i,lastBlankCookieIdx=-1;  
     for(i=0;i<upto;i++) {
          if(S[i]=='-')
            lastBlankCookieIdx=i;
      }
      return lastBlankCookieIdx;
 }
 
 void flipCookies(int from,int upto) {
      char flipBuffer[105];
      int i,j;
      for(i=from,j=0;i<=upto;i++,j++) {
            if(S[i]=='+')
               flipBuffer[j]='-';
            else
               flipBuffer[j]='+';
        }
      flipBuffer[j]='\0';
      for(i=0;flipBuffer[i]!='\0';i++)
        S[upto-i]=flipBuffer[i];     
 }
 
 void flipHappySides() {
      int i=0;
      while(S[i]=='+') {
         S[i]='-';
         i++;
      }
 }

