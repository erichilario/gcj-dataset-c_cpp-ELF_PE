#include<stdio.h>
 #include<string.h>
 int main()
 {
     FILE *in=fopen("input.txt","r");
     FILE *out=fopen("output.txt","w");
     int i, j, start=0, end, max=0, leng, zeroCount=1, tmp_start, maxi, happy=0, cntChange=0, happycnt=0;
     char s[101];
     int a[100]={0,}, tmp[100]={0,}, tmpc;
     int cnt=1, caseT, c;
 
 
     fscanf(in,"%d",&caseT);
 
     for(c=1;c<=caseT;c++)
     {
         cntChange=0;
         fscanf(in,"%s",s);
         leng = strlen(s);
         //printf("leng : %d\n",leng);
 
         for(i=0;i<leng;i++)
         {
             if(s[i]=='+')
                 a[i]=1;
             else
                 a[i]=0;
         }
 
         //for(i=0;i<leng;i++)
         //    printf("%d ",a[i]);
         //printf("\n%d ",a[0]);
         zeroCount=1;
         while(zeroCount>0)
         {
             start=0;
             end=0;
             zeroCount=0;
             if(a[0]==0)
             {
                 zeroCount=1;
                 start=0;
                 end=0;
             }
             if(a[0]==1 && a[1]==0)
             {
                 a[0]=0;
                 cntChange++;
             }
 
             for(i=1;i<leng;i++)
             {
          //       printf("%d ",a[i]);
                 if(a[leng-1]==0)
                 {
                     start=0;
                     end = leng-1;
                     zeroCount=1;
                 }
                 if(a[i]==0)
                 {
                     start=0;
                     end = i;
                     zeroCount++;
                 //printf("end=i:%d ",i);
                 }
             //if(a[i]==0 && a[i-1]==0)
             //    zeroCount++;
             }
             if(a[start]==1 && (a[start]!=a[end]))
             {
                 zeroCount=1;
                 end=0;
                 tmpc=a[start];
                 for(i=1;i<leng;i++)
                 {
                     if(a[i]==tmpc)
                        end++;
                     else
                         break;
                 }
                 end;
             }
             //printf("finalend:%d\n",end);
 
 
         //printf("zeroCount:%d, start:%d, end:%d\n",zeroCount,start,end);
     //0   1 ٲ
             if(zeroCount>0)
             {//+- --> -+
                 for(i=start;i<=end;i++)
                 {
                     tmp[i]=a[i];
                 }
                 for(i=end;i>=start;i--)
                 {
                     if(tmp[end-i]==1)
                         a[i]=0;
                     else
                         a[i]=1;
                 }
                 cntChange++;
         //    printf("%d ",a[i]);
             }
             zeroCount=0;
             for(i=0;i<leng;i++)
             {
                 if(a[i]==0)
                     zeroCount++;
             }
             if(zeroCount==0)
             {
           //  printf("\ncntChange:%d\n",cntChange);
             fprintf(out,"Case #%d: %d\n",c,cntChange);
                 break;
             }
         //for(i=0;i<leng;i++)
         //{
         //    printf("%d ",a[i]);
         //}
 
         //printf("\n");
 
         }
     }
 }

