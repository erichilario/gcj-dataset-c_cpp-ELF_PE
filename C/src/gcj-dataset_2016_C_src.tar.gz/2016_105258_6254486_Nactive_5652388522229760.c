#include <stdio.h>
 #include <stdlib.h>
 
 int solve(int n) {
 	int curr = n;
 	
 	int seen[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
 
 	while (1) {
 		int see = curr;
 		while (see > 0) {
 			seen[see % 10] = 1;
 			see = see / 10;
 		}
 
 		int end = 1;
 		for (int i = 0; i < 10; i++) {
 			if (seen[i] == 0) {
 				end = 0;
 			}
 		}
 
 		if (end == 1) {
 			return curr;
 		}
 
 		curr += n;
 
 		if (curr < 0) {
 			printf("We are overlooping!!!");
 			exit(0);
 		}
 	}
 }
 
 int main() {
 	int t;
 	scanf("%d", &t);
 
 	for (int x = 1; x <= t; x++) {
 		int n;
 		scanf("%d", &n);
 
 		if (n == 0) {
 			printf("Case #%d: INSOMNIA\n", x);
 		} else {
 			printf("Case #%d: %d\n", x, solve(n));
 		}
 	}
 	
 
 	return 0;
 }
