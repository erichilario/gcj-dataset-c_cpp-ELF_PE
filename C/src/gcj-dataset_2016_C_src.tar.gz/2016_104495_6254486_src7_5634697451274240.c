#include<stdio.h>
 #include<conio.h>
 void main()
 {
 int test,i,j=0,k,turn[102],flag=0;
 char p[10];
 FILE *fp;
 fp=fopen("Output.out","w");
 
 clrscr();
 freopen("input.in","r",stdin);
 scanf("%d",&test);
 for(i=0;i<test+1;i++)
 	{  j=0;flag=0;   turn[i]=0;
       /*	while(p[j-1]!=13)
 		{
 		//scanf("%c",&p[j]);//p[j]=getche();
 		j++;
 		}
 		//printf("\n");  */
 		gets(p);
 	 for(k=0;k<strlen(p);k++)
 	 {
 	 if(p[k]=='-'||(p[k]=='+'&&p[k+1]=='-')||(p[k]=='+'&&p[k+1]=='-'))
 	 turn[i]++;
 	 if(p[k]=='-'&&p[k+1]=='-')
 	 turn[i]--;
 	 if((p[j-1]=='-'&&p[j]=='-')&&flag==0)
 	 {turn[i]++; flag=1;}
 	 }
 	}
 	for(i=1;i<test+1;i++)
 	{printf("\nCase #%d: %d",i,turn[i]);
 	fprintf(fp,"\nCase #%d: %d",i,turn[i]);
 
 	}
 	fclose(fp);
 	getch();
 
 
 }
