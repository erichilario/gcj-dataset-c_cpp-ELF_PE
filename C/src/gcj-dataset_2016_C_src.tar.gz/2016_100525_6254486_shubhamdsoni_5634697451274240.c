#include<stdio.h>
 #include<string.h>
 
 
 int main()
 {
   int T,_T;
   scanf("%d",&T);
   _T=T;
   while(T--)
   {
     long long int C=0,i;
     char S[101];
     memset(S,'\0',101);
     scanf("%s",S);
     //char P=S[0];
     for(i=1;i<100;i++)
     {
       if((S[i]=='+')||(S[i]=='-'))
       {
         if(S[i-1]!=S[i])
         {
           C++;
         }
       }
       else
       {
         break;
       }
     }
     if(S[i-1]=='-') C++;
     printf("Case #%d: %lld\n",_T-T,C);
   }
   return 0;
 }

