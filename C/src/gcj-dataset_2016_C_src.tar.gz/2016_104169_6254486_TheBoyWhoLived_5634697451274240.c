#include<stdio.h>
 #include<math.h>
 #include<string.h>
 
 int main() {
   int t;
   scanf("%d", &t);
   for(int i = 1; i <= t; i++ ) {
     char strs[100];
     scanf("%s", strs);
     int len = strlen(strs);
     int j = 0;
     int ans = 0, count = 0;
     while(strs[j] != '+' && j < len)
       j++;
     if(j > 0) 
       ans++;
     while(strs[j] != '-' && j < len) {
       j++;
       if(strs[j] == '-') {
 	count++;
 	while(strs[j] != '+' && j < len)
 	  j++;
       }	
     }
     ans = ans + count * 2;
     printf("Case #%d: %d\n", i, ans);
   }
 }

