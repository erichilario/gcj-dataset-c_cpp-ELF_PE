#include <stdio.h>
 #include <string.h> 
 
 int main() {
 
     int T; // Test Cases
     char input[100][100]; // Input
     memset(input, 0, 100 * 100);
     int i, j; // Indices
     int length[100];
 
     // Algorithm : Flip each time you see some different character
 
     scanf("%d", &T);
 
     for( i = 0 ; i < T ; i++ ) {
         scanf("%s", input[i]);
         length[i] = strlen( input[i] );
     }    
 
     for( i = 0; i < T; i++ ) {
         int flip = 0;
         char cur_top = input[i][0];
 
         for( j = 1; j < length[i]; j++ ) {
            if( cur_top != input[i][j] ) {
                 flip++;
                 cur_top = input[i][j];
            }
         }
 
         if( cur_top == '-' ) {
             flip++;
         }
 
         printf("Case #%d: %d\n", i+1, flip);
     }
     
     return 0;
 }

