#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 int isprime(unsigned long long int n);
 //void print(unsigned long long int val1);
 int main()
 {
 	unsigned long long int  val,var,count=0,i,j,ans[11],flag,k=1,val1,kcount=0,flag1=0;
 	int les;
 	val=val1=32769;
 	printf("Case #1:\n");
 	while(count<50)
 	{
 		flag=0;
 		var =0;
 		for(i=2;i<=10;i++)
 		{
 			var=0;
 			for(j=0;j<16;j++)
 			{
 				if(val1 & (unsigned long long int)pow(2,j))
 				{
 					//printf("hai\n");
 					var+=(unsigned long long int)pow(i,j);
 				}
 			}
 			//printf("%ld\n",var);
 			if(isprime(var))
 			{
 				//if(count==0)
 				//printf("hai\n");
 				val1=val;
 				val1 = val1 | (unsigned long long int)pow(2,k);
 				k++;
 				if(k>14)
 				{
 					kcount++;
 					val = val | (unsigned long long int)pow(2,kcount);
 					val1=val;
 					k=kcount+1;
 					val1=val1 | (unsigned long long int)pow(2,k);
 					flag1=1;
 				}
 				flag=1;
 				break;
 			}
 			else
 			{
 				j=2;
 				while(var%j!=0 && j<var)
 					j++;
 				if(j<var)
 				{
 					ans[i]=j;
 					//printf("%ld\n",ans[i]);
 				}
 			}
 		}
 		if(flag==0)
 		{
 			count++;
 			for(les=15;les>=0;les--)
             {
                     if((val1 & (int)pow(2,les)))
                     printf("1");
                 else
                     printf("0");
             }
             printf(" ");
 			//print(unsigned long long int val1);
 			//printf("%ld\n",val1);
 			val1=val;
 			val1 = val1 | (unsigned long long int)pow(2,k);
 			k++;
 			if(k>14)
 				{
 					kcount++;
 					val = val | (unsigned long long int)pow(2,kcount);
 					k=kcount+1;
 					val1=val;
 					val1=val1 | (unsigned long long int)pow(2,k);
 					flag1=1;
 				}
 			for(i=2;i<=10;i++)
 				printf("%llu ",ans[i]);
 			printf("\n");
 		}
 		//break;
 	}
 		//printf("%ld",(long int)pow(var,val));
 }
 int isprime(unsigned long long int n){
    unsigned long long int i;
 
     if (n==2)
         return 1;
 
     if (n%2==0)
         return 0;
 
     for (i=3;i<=sqrt(n);i+=2)
         if (n%i==0)
             return 0;
 
     return 1;
 }
 /*void print(unsigned long long int val1)
 {
 	long long int i;
 	//val = (long long int)val1;
     for(i=15;i>=0;i--)
             {
                     if((val1 & (int)pow(2,i)))
                     printf("1");
                 else
                     printf("0");
             }
             printf(" ");
 }*/
