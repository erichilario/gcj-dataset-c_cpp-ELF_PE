#include <stdio.h>
 #include<string.h>
 
 int main()
 {
     long count,i,j,t,k;
     char str[110];
     scanf("%ld",&t);
     
     for(k=1;k<=t;k++)
     {
       count=0;
     
     scanf("%s",str);
     
     while(1)
     {
     i=0;
     while(str[i]==str[i+1])
        i++;
      
         
         if(i==(strlen(str)-1))
           break;
         
     for(j=0;j<=i;j++)
      {
         if(str[j]=='+')
           str[j]='-';
         else
            str[j]='+';
          
      }
        
       
         count++;
         
     }
     
     if(str[i]=='-')
        printf("Case #%ld: %ld\n",k,count+1);
     else
         printf("Case #%ld: %ld\n",k,count);
 
     }     
         
     return 0;
 }

