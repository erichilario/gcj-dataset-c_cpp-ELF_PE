#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 void rstrip(char *str)
 {
     if (str[strlen(str) - 1] == '\n') {
         str[strlen(str) - 1] = '\0';
     }
 }
 
 int main()
 {
     int size;
     
 
     char array[200] = "";
     fgets(array, 101, stdin);
     sscanf(array, "%d", &size);
     for (int i = 0; i < size; i++) {
         fgets(array, 101, stdin);
 	rstrip(array);
         char last_ch = array[0];
         size_t flips = 0, len = strlen(array);
         for (size_t l = 1; l < len; l++) {
             if (last_ch != array[l]) {
                 flips++;
             }
             last_ch = array[l];
         }
         if (last_ch != '+') {
             flips++;
         }
         printf("Case #%d: %u\n",(int) i + 1,(int) flips);
     }
     return 0;
 }
 

