#include <stdio.h>
 #include <memory.h>
 #define N 10
 typedef unsigned long long ulong;
 unsigned char digit_was[N];
 
 int main(){
     
     FILE *in, *out;
     in = fopen("A-large.in", "r");
     out = fopen("A-large.out", "w");
     
     int t;
     fscanf(in, "%d", &t);
     
     int i;
     for ( i = 1; i <= t; i++ )
     {
         ulong n;
         fscanf(in, "%llu", &n);
         
         if ( n == 0 )
         {
             fprintf(out, "Case #%d: INSOMNIA\n", i);
             continue;
         }
         
         memset(digit_was, 0, sizeof(digit_was));
         int digits = 0;
         int j;
         for ( j = 1; digits < N; j++ )
         {
             ulong ncopy = j * n;
             while ( ncopy )
             {
                 int digit = ncopy % 10;
                 if ( !digit_was[digit] )
                 {
                     digits++;
                     digit_was[digit] = 1;
                 }
                 
                 ncopy /= 10;
             }
         }
         
         fprintf(out, "Case #%d: %llu\n", i, (j-1) * n);
         
     }
     
     return 0;
 }
