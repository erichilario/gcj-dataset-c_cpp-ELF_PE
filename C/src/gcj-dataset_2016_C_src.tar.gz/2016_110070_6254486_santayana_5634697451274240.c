#include<stdio.h>
 #include<string.h>
 int main() {
     int t , l , i , j , c ;
     char s[101];
     scanf("%d" , &t);
     for(j=1 ; j<=t ; ++j){
         c = 0;
         scanf("%s" , s);
         l = strlen(s);
         while(l--){
             if(s[l]=='-'){
               c++;
               for(i=0 ;i<=l ; ++i){
                 if(s[i]=='-')
                     s[i] = '+';
                 else
                     s[i] = '-';
               }
             }
         }
         printf("Case #%d: %d\n" , j , c);
     }
     return 0;
 }

