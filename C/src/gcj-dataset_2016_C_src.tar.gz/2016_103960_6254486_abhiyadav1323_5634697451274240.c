#include <stdio.h>
 #include <string.h>
 
 void flip(char s[],int len)
     {
     int i;
     for(i=0;i<=len;i++)
         {
         if(s[i]=='+')
             s[i]='-';
         else
             s[i]='+';
     }
 }
 
 int main(void) {
 
     int t,j;
     scanf("%d",&t);
     for(j=1;j<=t;j++)
     {
         char s[101];
         scanf("%s",s);
         int i;
         long long int count=0;
         for(i=strlen(s);i>=0;i--)
             {
             if(s[i]=='-')
             {
                 flip(s,i);
                 count++;
             }
         }
         printf("Case #%d: %lld\n",j,count);
     }
     
     return 0;
 }
 

