#include <stdio.h>
 int main(void) {
    int t,i;
    long long int n;
    scanf("%d",&t);
    i=1;
    while(i<=t)
    {
        scanf("%lld",&n);
        if(n==0)
        {
            printf("Case #%d: INSOMNIA\n",i);
        }
        else
        {
            long int j,k;
            long long int no,notemp;
            int flag[10];
            int flag2;
            for(j=0;j<10;j++)
            {
                flag[j] = -1;
            }
            j=1;
            while(1)
            {
                flag2=1;
                no = notemp = j*n;
                while(notemp>0)
                {
                    flag[(notemp)%10] = 1;
                    notemp = notemp/10;
                }
                for(k=0;k<10;k++)
                {
                    if(flag[k]==-1)
                    {
                        flag2= -1;
                    }
                }
                if(flag2==1)
                {
                    break;
                }
                j++;
            }
            printf("Case #%d: %lld\n",i,j*n);
        }
        i++;
    }
  return 0;  
 }
