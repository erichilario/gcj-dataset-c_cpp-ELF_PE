#include <math.h>
 #include <stdio.h>
 
 #ifndef _DEBUG
 #define _NO_DEBUG
 #endif
 
 int gcd(unsigned long long a, unsigned long long b)
 {
   unsigned long long remainder;
   while (b != 0)
     {
       remainder = a%b;
       a = b;
       b = remainder;
     }
   return a;
 }
 
 unsigned long long factor(unsigned long long number)
 {
   unsigned long long xi = 2;
   unsigned long long clen = 2;
   unsigned long long xj = 2;
   unsigned long long f = 1;
   int npassos = 1;
 #ifdef _DEBUG  
   printf("Factoring: %llu\n", number);
 #endif  
   while(f == 1)
     {
       for(unsigned long long i=1; i < clen && f <= 1; i++)
 	{
 	  xj = (xj*xj+1)%number;
 	  f = gcd(xj - xi, number);
 #ifdef _DEBUG	  
 	  printf("xj: %llu xi: %llu passo: #%d f:%llu\n", xj, xi, npassos, f);
 #endif	  
 	  npassos++;
 	}
       clen *=2;
       xi = xj;
       if(npassos > 1000)
 	{
 	  f = number;
 	  break;
 	}
     }
   return f;
 }
 
 int main()
 {
   int casos;
   scanf("%d", &casos);
   for(int abi = 1; abi <= casos; abi++)
     {
       int n;
       int j;
       scanf("%d %d", &n, &j);
       unsigned int maxnum = 2 << (n-1);
       unsigned int basenum = (maxnum/2) + 1;
       int nJoins = 0;
 
 #ifdef _DEBUG
       printf("Printing debug log!!!");
 #endif  
       printf("Case #%d:\n",abi);
       for (unsigned int i = 0; basenum+i < maxnum; i=i+2)
 	{
 	  int res = basenum+i;
 	  unsigned int jamcoin[n];
 	  int k = 0;
 	  char output[1000] = "";
 	  int indo = 0;
 	  int isJamCoin = 1;
 	  while(res != 0)
 	    {
 	      jamcoin[k] = res%2;
 	      res /= 2;
 	      k++;
 	    }
 	  for(int a = k-1; a >= 0; a--)
 	    {
 	      indo += snprintf(output+indo, sizeof(output)-indo, "%d", jamcoin[a]);
 	    }
 
 	  indo += snprintf(output+indo, sizeof(output)-indo, " ");
 
 	  for(int m = 2; m <= 10; m++)
 	    {
 	      unsigned long long numinbase = 0;
 	      unsigned long long f = 0;
 	      for(int l = 0; l < n; l++)
 		{
 		  numinbase += jamcoin[l]*((unsigned long long) pow(m,l));
 		}
 #ifdef _DEBUG	  
 	      printf("#%d: %llu ", m, numinbase);
 #endif	  
 	      f = factor(numinbase);
 	      if (numinbase != f)
 		{
 		  indo += snprintf(output+indo, sizeof(output)-indo, "%llu ", f);
 		}
 	      else
 		{
 #ifdef _DEBUG	      
 		  printf("Not JAMCOIN aborting...\n");
 #endif	      
 		  isJamCoin = 0;
 		  break;
 		}
 	    }
 	  if(isJamCoin)
 	    {
 	      printf("%s\n", output);
 	      nJoins++;
 	    }
 
 	  if(nJoins == j)
 	    {
 	      break;
 	    }
 	}
     }
   return 0;
 }

