#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <math.h>
 
 int main()
 {
   int arr[10];
   int t;
   scanf("%d", &t);
   int cases[t];
   for (int m = 0; m< t; m++)
   {
     for (int count = 0; count < 10; count++)
     {
       arr[count] = 0;
     }
     bool fill;
     int N;
     scanf("%d", &N);
     int number;
     if (N == 0)
     {
       cases[m] = 0;
       continue;
     }
     for (int i = 1; ; i++)
     {
       number = i*N;
       while(number != 0)
       {
         int digit = number%10;
         number /= 10;
         arr[digit]++;
       }
       for (int j = 0; j < 10; j++)
       {
         if(arr[j] == 0)
         {
           fill = false;
           break;
         }
         fill = true;
       }
       if(fill)
       {
           cases[m] = i*N;
           break;
       }
     }
   }
   for (int n = 0; n < t; n++)
   {
     if (cases[n] == 0)
       printf("Case #%d: INSOMNIA\n", n+1);
 
     else
       printf("Case #%d: %d\n", n+1, (cases[n]));
   }
   return 0;
 }

