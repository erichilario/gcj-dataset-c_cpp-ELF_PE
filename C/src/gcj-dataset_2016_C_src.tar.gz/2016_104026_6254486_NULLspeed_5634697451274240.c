#include<stdio.h>
 #include<string.h>
 
 int main(void){
 	char pancake[128];
 	int i,j,l,t,count;
 	char side;
 	
 	scanf("%d%*c",&t);
 	for(i=1;i<=t;i++){
 		scanf("%s",pancake);
 		count=0;
 		side=pancake[0];
 		l=strlen(pancake);
 		for(j=1;j<l;j++){
 			if(side!=pancake[j]){
 				count++;
 				side=pancake[j];
 			}
 		}
 		if((count%2==0 && pancake[0]=='-') || (count%2==1 && pancake[0]=='+')) count++;
 		printf("Case #%d: %d\r\n",i,count);
 	}
 	return 0;
 }

