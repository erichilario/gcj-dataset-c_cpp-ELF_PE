#include <stdio.h>
 #include <time.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 int i,j,k;
 int factors[10];
 
 char numbers[500][100];
 int size_num= 0;
 
 int isPrime(int num, int base) {
 	int m, exists= 0;
 
 	for(k= 2; k< (num); k++) {
 		exists= 0;
 
 		if(num%k == 0) {
 
 			for(m= 0; m< 9; m++) {
 				if(factors[m] == k) {
 					exists= 1;
 					break;
 				}
 			}
 
 			if(!exists) {
 				factors[base - 2]= k;
 				return 0;
 			}
 		}
 	}
 
 	return 1;
 }
 
 int bintowhtevr(char *str) {
 	int i, j, num= 0, cpy_num, res;
 
 	for(i= 0; str[i] != '\0'; i++)
 		num= 10*num + (str[i] - '0');
 
 	for(i= 2; i<= 10; i++, cpy_num) {
 		cpy_num= num;
 		res= 0;
 
 		for(j= 0; cpy_num != 0; j++, cpy_num/= 10)
 			res+= ((cpy_num%10)*pow(i, j));
 
 		if(isPrime(res, i))
 			return 0;
 	}
 
 	return 1;
 }
 
 void generate_num(char str[], int N) {
 	str[0]= '1';
 	for(k= 1; k< N - 1; k++)
 		str[k]= (rand()%2) + '0';
 	str[k]= '1';
 	str[k + 1]= '\0';
 
 	for(k= 0; k< size_num; k++) {
 
 		if(strcmp(numbers[k],str) == 0) {
 			generate_num(str, N);
 			break;
 		}
 	}
 
 	if(size_num == k) {
 		strcpy(numbers[size_num], str);
 		size_num++;
 	}
 }
 
 void main() {
 	int T, N, J, m;
 	char str[100];
 
 	FILE *fin, *fout;
 
 	fin= fopen("file.in", "r");
 	fout= fopen("file.out", "w");
 
 	srand(time(NULL));
 
 	fscanf(fin, "%d", &T);
 
 	for(i= 0; i< T; i++) {
 		fscanf(fin, "%d %d", &N, &J);
 
 		fprintf(fout, "Case #%d:\n", i + 1);
 
 		for(j= 0; j< J; j++) {
 
 			while(1) {
 				generate_num(str, N);
 
 				if(bintowhtevr(str)) {
 
 					fprintf(fout, "%s", str);
 
 					for(m= 0; m<= 8; m++)
 						fprintf(fout, " %d", factors[m]);
 
 					fprintf(fout, "\n");
 
 					break;
 				}
 			}
 		}
 	}
 
 	fclose(fin);
 	fclose(fout);
 }
