#include<stdio.h>
 #include<string.h>
 
 
 char str16[16384][16]={"1000000000000001",
 "1110000000000001",
 "1001000000000001",
 "1011000000000001",
 "1000100000000001",
 "1100100000000001",
 "1001100000000001",
 "1111100000000001",
 "1010010000000001",
 "1101010000000001",
 "1111010000000001",
 "1000110000000001",
 "1100110000000001",
 "1110110000000001",
 "1101110000000001",
 "1011110000000001",
 "1100001000000001",
 "1010001000000001",
 "1001001000000001",
 "1111001000000001",
 "1000101000000001",
 "1010101000000001",
 "1110101000000001",
 "1101101000000001",
 "1011101000000001",
 "1111101000000001",
 "1000011000000001",
 "1110011000000001",
 "1101011000000001",
 "1011011000000001",
 "1111011000000001",
 "1100111000000001",
 "1010111000000001",
 "1001111000000001",
 "1011111000000001",
 "1111111000000001",
 "1000000100000001",
 "1010000100000001",
 "1001000100000001",
 "1101000100000001",
 "1111000100000001",
 "1000100100000001",
 "1100100100000001",
 "1110100100000001",
 "1001100100000001",
 "1101100100000001",
 "1011100100000001",
 "1000010100000001",
 "1110010100000001",
 "1001010100000001"};
 
 
 unsigned long long int Solution(unsigned long long int N)
 {
   unsigned long long int i;
   for(i=2;(i*i)<=N;i++)
   {
     if(N%i==0) break;
   }
 
   return i;
 }
 
 int counting(int N)
 {
   switch(N)
   {
     case 16: return 16384;
   }
 }
 
 char *pointer(int N,int k)
 {
  
   //printf("Pointer %d %d\n",N,k);
 
   switch(N)
   {
     case 16: return str16[k];
 
   }
 }
 
 int isPrime(unsigned long long int N)
 {
   unsigned long long int i;
   int flag=1;
   for(i=2;(i*i)<=N;++i)
   {
     if(N%i==0) {flag=0;break;}
   }
   return flag;
 }
 
 int main()
 {
   int T,_T;
   scanf("%d",&T);
   _T = T;
   while(T--)
   {
   printf("Case #%d:\n",_T-T);
   unsigned long long int Arr[9];
   int N,J,i,j,k;
   scanf("%d %d",&N,&J);
   int count = counting(N);
   char *S;
   int flag = 0;
   unsigned long long int Num=0,Mul;
 
   //Converting into Different base
 for(k=0;k<count;k++)
 {
   if(!J) break;
   flag = 0;
   S = pointer(N,k);
 
   for(i=2;i<=10;i++)
   {
     Num = S[N-1]-'0';
     Mul = 1;
     for(j=N-2;j>=0;j--)
     {
       Mul*=i;
       Num+=(S[j]-'0')*Mul;
     }
 
    Arr[i-2] = Num;
    if(isPrime(Num)) {flag =1; break;}
   }//Base converting
  
     if(flag==0)
     {
     J--;
     for(j=0;j<N;j++)
      printf("%c",S[j]);
     printf(" ");
     for(j=0;j<9;j++) printf("%llu ",Solution(Arr[j]));
     printf("\n");
     }
    }
   }
   return 0;
 }

