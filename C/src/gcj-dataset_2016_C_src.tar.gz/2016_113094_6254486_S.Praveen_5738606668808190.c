#include<stdio.h>
 #include<math.h>
 void generateCoin();
 long long int getVal(int);
 int isPrime(long long int,int);
 char coin[33];
 int n,j;
 int facts[9];
 int x;
 int main(){
     int t,ti,base,i,k;
     scanf("%d",&t);
     for(ti=1;ti<=t;ti++){
 	x=0;
 	scanf("%d%d",&n,&j);
 	printf("Case #%d:\n",ti);
 	coin[0]='1'; coin[n-1]='1'; coin[n]='\0';
 	for(i=0;i<j;i++){
 a:generateCoin();
 	    for(k=2;k<=10;k++){
 		if(isPrime(getVal(k),k-2)==1){
 		    goto a;
 		}
 	    }
 	printf("%s ",coin);
 	for(k=0;k<9;k++)
 	    printf("%d ",facts[k]);
 	printf("\n");
 	}
     }
     return 0;
 }
 void generateCoin(){
     int i,t;
     t=x;
     for(i=n-2;i>=1;i--){
 	coin[i]=t&1?'1':'0';
 	t>>=1;
     }
     x++;
 }
 long long int getVal(int b){
     int i;
     long long int val=0,power=1;
     for(i=n-1;i>=0;i--){
 	if(coin[i]=='1')
 	    val+=power;
 	power=power*b;
     }
     return val;
 }
 
 int isPrime(long long int num,int b){
 int i;
 for(i=2;i<=sqrt(num);i++){
 if(num%i==0){
     facts[b]=i;
     return 0;
 }
 if(i>2)
     i++;
 }
 return 1;
 }

