#include <stdio.h>
 #include <stdlib.h>
 #include <assert.h>
 #include <unistd.h>
 
 int main(void) {
 
     int digits_seen[10] = {0};
 
 
     // note: add a few heuristics to see if we will never view a certain number
     // for example, we'll never see a 9 because we only get even numbers
     // or...idk.
 
     int N;
     int code;
     int case_num;
     int T;
 
     int good = scanf("%i\n", &T);
 
     assert(good == 1);
     //printf("T: %i\n", T);
     
     for (case_num = 1; case_num <= T; ++case_num) {
         //printf("case: %i\n", case_num);
 
         code = scanf("%i", &N);
         assert(code == 1);
         
         if (N == 0) {
             // never will see anything!
             printf("Case #%i: INSOMNIA\n", case_num);
             continue;           
         }
 
         int M = N;
 
         int i = 0;
         for (;;) {
             i++;
             int n = M;
             int digit;
             while(n != 0) {
                 digit = n % 10;
                 digits_seen[digit]++;
                 n /= 10;
             }
 
             // if all seen, terminate!
             if  (  digits_seen[0] > 0
                 && digits_seen[1] > 0
                 && digits_seen[2] > 0
                 && digits_seen[3] > 0
                 && digits_seen[4] > 0
                 && digits_seen[5] > 0
                 && digits_seen[6] > 0
                 && digits_seen[7] > 0
                 && digits_seen[8] > 0
                 && digits_seen[9] > 0) {
                 printf("Case #%i: %i\n", case_num, M);
 
                 // clear state!
                 i = 0;
                 digits_seen[0] = 0;
                 digits_seen[1] = 0;
                 digits_seen[2] = 0;
                 digits_seen[3] = 0;
                 digits_seen[4] = 0;
                 digits_seen[5] = 0;
                 digits_seen[6] = 0;
                 digits_seen[7] = 0;
                 digits_seen[8] = 0;
                 digits_seen[9] = 0;
                 M = N;
                 break;
             }else {
                 M = i * N;
                 //printf("i = %i, M = %i\n", i, M);
                 //sleep(1);
             }
         }
     }
 }
