#include <stdio.h>
 int a[10];
 int func()
 {
     int i;
     for(i=0;i<10;i++)
     {
         if(a[i]==1)
          continue;
         else
          return 0;
     }
     return 1;
 }
 void func1(long long int n)
 {
     while(n)
     {
         int k=n%10;
         a[k]=1;
         n/=10;
     }
 }
 int main(void) {
 	long long int t,i;
 	scanf("%lld",&t);
 	for(i=1;i<=t;i++)
 	{long long int j,n;
 	  for(j=0;j<10;j++)
 	     a[j]=0;
 	     
 	    scanf("%lld",&n);
 	    j=1;
 	    while(1)
 	    {
 	        long long int k=n*j;
 	        func1(k);
 	        
 	        if(func()==1||j==100)
 	         break;
 	        else
 	         j++;
 	    }
 	    if(func()==1)
 	     printf("Case #%lld: %lld\n",i,n*j);
 	    else
 	     printf("Case #%lld: INSOMNIA\n",i);
 	}
 	return 0;
 }

