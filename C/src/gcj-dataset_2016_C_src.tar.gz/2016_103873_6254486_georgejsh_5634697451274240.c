#include<stdio.h>
 int main(){
 	int t,i,j,flag,res;
 	char s[101];
 	for(scanf("%d",&t),i=0;i<t;i++){
 		scanf("%s",s);
 		flag=0;
 		res=0;
 		for(j=0;s[j]!='\0';j++)
 			if(s[j]=='-'){
 				if(j>0)
 					res+=2;
 				else 
 					res+=1;
 			while(s[j++]=='-' && s[j]!='\0');
 			j--;
 			}
 		printf("Case #%d: %d\n",i+1,res);
 		
 	}
 	return 0;
 }

