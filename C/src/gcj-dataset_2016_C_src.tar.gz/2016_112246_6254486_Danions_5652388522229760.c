#include <stdio.h>
 
 void clear (void){
   while ( getchar() != '\n' );
 }
 
 int test(int G){
     int c1, c2, S, p, i, c[11];
     for(i=1; i<=10; i++) c[i]=1;
     c1=G;
     if(G==0) S=0;
     else S=55;
     while(S){
         c2=G;
         while(c2){
             p=c2%10+1;
             c2/=10;
             if(c[p]){
                 c[p]=0;
                 S-=p;
             }
         }
         G+=c1;
     }
     return G-c1;
 }
 
 void main(){
     freopen("in.txt", "r", stdin);
     freopen("out.txt", "w+", stdout);
     int T, N, i;
     scanf("%d", &T);
     for(i=1; i<=T; i++){
         scanf("%d", &N);
         if(!N)
             printf("Case #%d: INSOMNIA\n", i);
         else
             printf("Case #%d: %d\n", i, test(N));
     }
 }

