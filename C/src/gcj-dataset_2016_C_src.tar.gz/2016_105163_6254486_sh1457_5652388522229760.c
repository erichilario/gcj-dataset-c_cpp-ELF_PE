#include <stdio.h>
 
 int main(void) {
     int T, N;
     int digits[10];
     int M, P, sum;
     int i, j, k;
     
     scanf("%d", &T);
     
     for(i=1;i<=T;i++) {
         scanf("%d", &N);
         
         if(N==0) {
             printf("Case #%d: INSOMNIA\n", i);
             continue;
         }    
         
         j=0;
         for(k=0;k<=9;k++)
             digits[k]=0;
         
         while(j<100) {
             j++;
             M=N*j;
             P=M;
 
             while(P>0) {
                 k=P%10;
                 P=P/10;
                 if(!digits[k])
                     digits[k]=1;
             }
 
             sum=0;
             for(k=0;k<=9;k++)
                 sum+=digits[k];
             
             if(sum==10) {
                 printf("Case #%d: %d\n", i, M);
                 break;
             }
         }
     }
 	return 0;
 }

