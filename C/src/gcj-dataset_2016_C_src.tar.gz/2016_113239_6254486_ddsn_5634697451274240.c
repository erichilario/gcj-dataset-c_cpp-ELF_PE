#include <stdio.h>
 #include <stdint.h>
 #include <memory.h>
 #include <limits.h>
 
 void swap(char *x, char *y)
 {
     char tmp = *y;
     *y = (*x  == '+' ? '-' : '+');
     *x = (tmp == '+' ? '-' : '+');
 }
 
 void maneuver(char S[], uint32_t pos)
 {
     uint32_t i;
     for (i = 0; i <= pos / 2; i++) {
         swap(&S[i], &S[pos-i]);
     }
 }
 
 uint32_t getNumOfTopX(const char S[], const char X, const uint32_t len)
 {
     uint32_t cnt = 0;
     for (cnt = 0; cnt < len; cnt++) {
         if (S[cnt] != X) return cnt;
     }
     return cnt;
 }
 
 uint32_t getNumOfTopBlanks(const char S[], const uint32_t len)
 {
     return getNumOfTopX(S, '-', len);
 }
 
 uint32_t getNumOfTopSmiles(const char S[], const uint32_t len)
 {
     return getNumOfTopX(S, '+', len);
 }
 
 uint8_t isSolved(const char S[], const uint32_t len)
 {
     uint32_t i;
     for (i = 0; i < len; i++) {
         if (S[i] == '-') return 0;
     }
     return 1;
 }
 
 uint32_t solve(char S[], const uint32_t len)
 {
     uint32_t cnt = 0;
     uint32_t numTb;
     uint32_t numTs;
 
     // printf("input:    %s\n", S);
     while (isSolved(S, len) == 0) {
         numTb = getNumOfTopBlanks(S, len);
         numTs = getNumOfTopSmiles(S, len);
         if (numTb > 0) {
             // printf("maneuver(S, %u)\n", numTb - 1);
             maneuver(S, numTb - 1);
         } else {
             maneuver(S, numTs - 1);
         }
         // printf("cnt = %u : %s\n", cnt, S);
         cnt++;
     }
 
     return cnt;
 }
 
 int main(void)
 {
     uint32_t T, t;
     scanf("%u", &T);
 
     for (t = 0; t < T; t++) {
         char S[100+1];
         scanf("%s", S);
         printf("Case #%u: %u\n", t+1, solve(S, strlen(S)));
     }
 
     return 0;
 }
 

