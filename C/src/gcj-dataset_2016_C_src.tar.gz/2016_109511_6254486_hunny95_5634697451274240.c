#include<stdio.h>
 #include<string.h>
 void func(char s[],int i)
 {
     int j;
     char s1[100];
     for(j=0;j<=i;j++)
     {
         if(s[j]=='-')
           s[j]='+';
         else
          s[j]='-';
     }
    int k=i;
    s1[i+1]='\0';
   for(j=0;j<=i;j++)
    {
        s1[k]=s[j];
        k--;
    }
   for(j=0;j<=i;j++)
   {
       s[j]=s1[j];
   }
 }
 int func1(char s[])
 {int i;
     for(i=0;i<strlen(s);i++)
      { if(s[i]=='+')
         continue;
       else
        return 0;}
        
        
      return 1;
      
 }
 int func2(char s[])
 {int i;
     for(i=0;i<strlen(s);i++)
      { if(s[i]=='-')
         continue;
       else
        return 0;}
        
      return 1;
      
 }
 int main()
 {
     long long int t,j;
     scanf("%lld",&t);
     for(j=1;j<=t;j++)
     { int i,sum=0;
         char s[100];
         scanf("%s",&s);
     while(1)
     {
         
         if(func1(s)==1)
           break;
         else if(func2(s)==1)
           {sum++;
           break;}
         else
         {
         for(i=strlen(s)-1;i>=0;i--)
         {
             if(s[i]=='-')
              break;
             else
              continue;
         }
         if(s[0]=='-')
           func(s,i);
         else
         {
             sum++;
             int r=0;
             while(s[r]=='+')
               {
                   s[r]='-';
                   r++;
               }
             func(s,i);
         }
      
         sum++;
         }
     }
     printf("Case #%lld: %d\n",j,sum);
     }
     return 0;
 }
