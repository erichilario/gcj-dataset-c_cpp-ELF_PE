#include <stdio.h>
 #include <string.h>
 int main()
 {
 	char a[110] = {'0',};
 	int T = 0;
 	scanf("%d", &T);
 	int len = 0;
 	for (int k = 0; k < T; k++)
 	{
 		scanf("%s", a);
 		len = strlen(a);
 		int l = 0;
 		int count = 0;
 		char old;
 		while (1)
 		{
 			int i;
 			old = a[l];
 			for(i = l; i < len; i++)
 			{
 				if (old != a[i])
 				{
 					l = i;
 					break;
 				}
 			}
 
 			if (i >= len)
 			{
 				if (a[len - 1] == '-')
 				{
 					count++;
 				}
 				break;
 			}
 			if (old == '-')
 			{
 				for (int i = 0; i < l; i++)
 				{
 					/* Swap '-' to '+' */
 					a[i] = '+';
 				}
 			}
 			else if (old == '+')
 			{
 				for (int i = 0; i < l; i++)
 				{
 					/* Swap '+' to '-' */
 					a[i] = '-';
 				}
 			}
 			count++;
 		}
 		
 		printf("Case #%d: %d\n", (k+1), count);
 	}
 	return 0;
 }

