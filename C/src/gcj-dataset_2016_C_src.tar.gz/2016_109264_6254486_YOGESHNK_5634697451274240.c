#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
         int i,l,j,cnt,ex,t,p;
         scanf("%d",&t);
         for(p=0;p<t;p++)
         {
                 cnt=0;
                 ex=0;
                 char c[200];
         scanf("%s",c);
         l=strlen(c);
         i=l-1;
         while(i>0)
         {
 
             if(c[i]!=c[i-1])
             {
                 cnt++;
                 for(j=l-1;j>=i;j--)
                 {
                     if(c[j]=='+')
                         c[j]='-';
                     else
                         c[j]='+';
                 }
             }
             else
                 i--;
         }
         for(i=0;i<l;i++)
         {
             if(c[i]=='-')
                 ex++;
         }
         if(ex==l)
             cnt=cnt+1;
         printf("Case #%d: ",p+1);
         printf("%d\n",cnt);
         }
 }

