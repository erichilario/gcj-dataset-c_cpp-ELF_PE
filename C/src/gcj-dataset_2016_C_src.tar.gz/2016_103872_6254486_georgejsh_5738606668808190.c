#include<stdio.h>
 char s[35];
 void printbin(int n,int c){
 	int i;
 	s[c]='\0';
 	for(i=0;i<c;i++)
 		s[c-i-1]=((n&(1<<i))>>i)+48;
 }
 int main(){
 	int a,b;
 	int i;
 	long long int res;
 	scanf("%d",&i);
 	scanf("%d%d",&a,&b);
 	a=a-1;
 	res=1<<(a-1);
 	printf("Case #1:\n");
 	for(i=0;i<b;i++){
 		printbin(res,a);
 		printf("%s0 %d %d %d %d %d %d %d %d %d\n",s,2,3,2,5,2,7,2,3,2);
 		res++;
 	}
 }

