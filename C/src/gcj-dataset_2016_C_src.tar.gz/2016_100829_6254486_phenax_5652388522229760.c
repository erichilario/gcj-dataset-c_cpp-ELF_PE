#include <stdio.h>
 
 int digits[10];
 
 int check_if_all_seen() {
 	int i;
 
 	for(i= 0; i< 10; i++) {
 		if(digits[i] == -1)
 			return 0;
 	}
 
 	return 1;
 }
 
 void make_normal() {
 	int i;
 
 	for(i= 0; i< 10; i++) {
 		digits[i]= -1;
 	}
 }
 
 void main() {
 	int T, N, i, num, j, slept= 0;
 
 	FILE *fp, *fout;
 
 	fp= fopen("file.in","r");
 	fout= fopen("file.out","w");
 
 	fscanf(fp, "%d", &T);
 
 	for(i= 0; i< T; i++) {
 		fscanf(fp,"%d", &N);
 
 		make_normal();
 
 		for(j= 1; j < 500;j++) {
 			num= j*N;
 
 			while(num != 0) {
 				digits[num%10]= 1;
 				num/= 10;
 			}
 
 			if(check_if_all_seen()) {
 				fprintf(fout, "Case #%d: %d\n", i + 1, j*N);
 				slept= 1;
 				break;
 			}
 		}
 
 		if(!slept) {
 			fprintf(fout, "Case #%d: INSOMNIA\n", i + 1);
 		}
 	}
 
 	fclose(fp);
 	fclose(fout);
 }
