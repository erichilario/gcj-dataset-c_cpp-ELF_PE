#include <stdio.h>
 #include <stdlib.h>
 
 int main (void) {
 
     int T, N, i, j, cnt = 0, prev_cnt = 0, count[10];
     long long mult = 0, tmp_mult;
      
     scanf("%d\n", &T);
     
     for (i = 1; i <= T; i++) {
         scanf("%d", &N);
         mult = 0;
         for (j = 0; j < 10; j++)
             count[j] = 0;
         while (1) {
             mult += N;
             tmp_mult = mult;
             while (tmp_mult > 0) {
                 count[tmp_mult % 10] = 1;
                 tmp_mult /= 10;
             }
             cnt = 0;
             for (j = 0; j < 10; j++)
                 cnt += count[j];
             if (mult == 0) {
                 printf("Case #%d: INSOMNIA\n", i);
                 break;
             }
             else if (cnt == 10) {
                 printf("Case #%d: %lld\n", i, mult);
                 break;
             } 
         }
     }
     return 0;
 }

