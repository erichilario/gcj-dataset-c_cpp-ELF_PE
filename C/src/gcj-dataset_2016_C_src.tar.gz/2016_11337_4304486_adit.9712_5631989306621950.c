#include<stdio.h>
 #include<string.h>
 int main()
 {
   int t,i,j,m,b,d;
   char arr[15];
   char arr1[15];
   scanf("%d",&t);
   for(i=0;i<t;i++)
   {
     scanf("%s",arr);
     b=strlen(arr);
     for(j=0;j<b;j++)
     {
       if(j==0)
       {
         arr1[j]=arr[j];
 
       }
       else
       {
         if(arr[j]>=arr1[0])
         {
           for(m=j-1;m>=0;m--)
           {
             arr1[m+1]=arr1[m];
 
           }
           arr1[0]=arr[j];
         }
         else
         arr1[j]=arr[j];
       }
 
     }
     printf("Case #%d: ",i+1);
     for(d=0;d<b;d++)
     {
       printf("%c",arr1[d]);
     }
     printf("\n");
 
   }
 
   return 0;
 }

