// C: Coin Jam
 
 // #include <omp.h>
 #include <stdbool.h>
 #include <stdio.h>
 
 typedef unsigned __int128 uint128_t;
 typedef unsigned int uint32_t;  // Avoid annoying typecast compiler warnings
 typedef unsigned long long uint64_t;  // Avoid annoying typecast compiler warnings
 
 uint64_t findAFactor(uint32_t bits, uint128_t base) {
     uint128_t number = 0, base_value = 1;
     for (uint32_t i = 0; i < 32; i++) {
         number += base_value * ((bits >> i) & 1);
         base_value *= base;
     }
     for (uint64_t factor = 2; ((uint128_t)factor) * ((uint128_t)factor) <= number; factor++) {
         if (0 == number % factor) {
             return factor;
         }
     }
     return -1;
 }
 
 void findJamcoins(uint64_t N, uint64_t J) {
     uint64_t num_left = J;
     for (uint32_t bit_string = (1 << (N - 1)) | 1; num_left > 0 && (uint64_t)bit_string < (1LL << N); bit_string += 2) {
         uint64_t factors[9];
         bool all_composite = true;
         for (uint128_t base = 2; base <= 10; base++) {
             factors[base - 2] = findAFactor(bit_string, base);
             if (-1LL == factors[base - 2]) {
                 all_composite = false;
                 break;
             }
         }
         if (all_composite) {
             for (int index = N - 1; index >= 0; index--) {
                 printf("%c", '0' + ((bit_string >> index) & 1));
             }
             for (uint32_t index = 0; index < 9; index++) {
                 printf(" %llu", factors[index]);
             }
             printf("\n");
             num_left--;
         }
     }
 }
 
 int main(int argc, char *argv[]) {
     uint32_t T;
     uint64_t N, J;
     scanf("%u %llu %llu", &T, &N, &J);
     for (uint64_t cases = 0; cases < T; cases++) {
         printf("Case #%llu:\n", cases + 1);
         findJamcoins(N, J);
     }
 }

