//John Wang
 //Google Code Jam
 //9/4/16
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <assert.h>
 
 static int numStrings = 0;
 
 static int pancakesHappy (char* s);
 static void flipTop (char* s, int n);
 static int countNumHappyStart (char* s);
 static int countNumBlankStart (char* s);
 static int countNumBlank (char* s);
 static char** readInput (void);
 static void freeAllStrings (char** pointer);
 
 int main(int argc, char* argv[]) {
    char** strings = readInput();
    int count = 0;
    for (count = 0; count < numStrings; count++) {
       printf("Case #%d: %d\n", count, pancakesHappy(strings[count]));
    }
    freeAllStrings (strings);
    return EXIT_SUCCESS;
 }
 
 static int pancakesHappy (char* s) {
    int flips = 0;
    while (countNumBlank(s) != 0) {
       if (countNumBlankStart(s) != 0) {
          flipTop(s, countNumBlankStart(s));
       } else {
          flipTop(s, countNumHappyStart(s));
       }
       flips++;
    }
    return flips;
 }
 
 static void flipTop (char* s, int n) {
    int count;
    for (count = 0; count < n; count++) {
       if (s[count] == '-') s[count] = '+';
       else s[count] = '-';
    }
 }
 
 static int countNumHappyStart (char* s) {
    int numHappy = 0, count = 0, length = strlen(s);
    for (count = 0; count < length; count++) {
       if (s[count] == '+') numHappy++;
       else break;
    }
    return numHappy;
 }
 
 static int countNumBlankStart (char* s) {
    int numBlank = 0, count = 0, length = strlen(s);
    for (count = 0; count < length; count++) {
       if (s[count] == '-') numBlank++;
       else break;
    }
    return numBlank;
 }
 
 static int countNumBlank (char* s) {
    int numBlank = 0, count = 0, length=strlen(s);
    for (count = 0; count < length; count++)
       if (s[count] == '-') numBlank++;
    return numBlank;
 }
 
 static char** readInput (void) {
    assert(scanf("%d", &numStrings) == 1);
    if (numStrings <= 0) return NULL;
    char** allStrings = (char**)malloc(sizeof(char*)*numStrings);
    assert(allStrings != NULL);
    int count;
    for (count = 0; count < numStrings; count++) {
       allStrings[count] = (char*)malloc(sizeof(char)*11);
       assert(allStrings[count] != NULL);
       assert(scanf("%s", allStrings[count]) == 1);
    }
    return allStrings;
 }
 
 static void freeAllStrings (char** pointer) {
    int count = 0;
    for (count = 0; count < numStrings; count++) {
       free(pointer[count]);
       pointer[count] = NULL;
    }
    free(pointer);
 }
