#include <stdio.h>
 #include <string.h>
 int main()
 {
     int i,test,j,a[100],count;
     char s[100];
     scanf("%d",&test);
     for(i=0;i<test;i++)
     {
         count=0;
         scanf(" %s",s);
         length=strlen(s);
         for(j=0;j<length;j++)
         {
             if(s[j]=='+')
                 a[j]=1;
             else
                 a[j]=2;
         }
         for(j=length-1;j>=0;j--)
         {
             if(a[j]==2)
             {
                 for(k=0;k<=j;k++)
                 {
                     if(a[k]==1)
                         a[k]=2;
                     else
                         a[k]=1;
                 }
                 count++;
             }
         }
         printf("Case #%d: %d\n",i+1,count);
     }
     return 0;
 }
