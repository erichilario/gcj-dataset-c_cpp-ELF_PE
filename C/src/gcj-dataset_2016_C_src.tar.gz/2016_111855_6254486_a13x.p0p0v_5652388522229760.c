#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 #define NDEBUG			1
 #include <assert.h>
 
 #define RES_BAD			1
 #define RES_OK			0
 
 #if NDEBUG
 #	define dbg_printf(...)	((void)0)
 #else
 #	define dbg_printf(...)	printf(__VA_ARGS__) /* variadic macro, C99 */
 #endif
 
 #define MAX_LEN			1024
 
 int solve(FILE *f, char *result)
 {
 	int scanned;
 	unsigned long long N;
 	unsigned long long sum = 0;
 	char sum_str[MAX_LEN] = { 0 };
 	int i = 0;
 	char met[10][2] = {
 		{'0', 1},
 		{'1', 1},
 		{'2', 1},
 		{'3', 1},
 		{'4', 1},
 		{'5', 1},
 		{'6', 1},
 		{'7', 1},
 		{'8', 1},
 		{'9', 1},
 	};
 	int met_cnt = 0;
 
 	scanned = fscanf(f, "%llu", &N);
 	if (scanned != 1) {
 		printf("Parsing failed\n");
 		return RES_BAD;
 	}
 
 	dbg_printf("N is %llu\n", N);
 
 /*
 	for (i = 0; i < 10; i++) {
 		dbg_printf("met: %c %d\n", met[i][0], met[i][1]);
 	}
 */
 
 	if (N == 0) {
 		snprintf(result, MAX_LEN, "INSOMNIA");
 		return RES_OK;
 	}
 
 	while (met_cnt < 10) {
 		sum += N;
 		snprintf(sum_str, MAX_LEN, "%llu", sum);
 
 		dbg_printf("sum %s\n", sum_str);
 
 		for (i = 0; i < 10; i++) {
 			if (met[i][1] && strchr(sum_str, met[i][0]) != NULL) {
 				dbg_printf("\tmet %c\n", met[i][0]);
 				met[i][1] = 0;
 				met_cnt++;
 			}
 		}
 
 	}
 
 	snprintf(result, MAX_LEN, "%llu", sum);
 
 	return RES_OK;
 }
 
 int main(void)
 {
 	FILE *file_in, *file_out;
 	char result[MAX_LEN] = { 0 };
 	int cases, a_case;
 	int scanned;
 
 	file_in = fopen("in.txt", "r");
 	file_out = fopen("out.txt", "w");
 
 	if (!file_in || !file_out)
 	{
 		printf("Bad i/o file\n");
 		return RES_BAD;
 	}
 
 	scanned = fscanf(file_in, "%d", &cases);
 	if (scanned != 1) {
 		printf("Reading number of cases failed\n");
 		return RES_BAD;
 	} else {
 		printf("Solving %d cases... \n", cases);
 	}
 
 	for (a_case = 0; a_case < cases; a_case++)
 	{
 		if (solve(file_in, result) == RES_BAD) {
 			printf("Solving failed!\n");
 			return RES_BAD;
 		}
 		fprintf(file_out, "Case #%d: %s\n", a_case + 1, result);
 	}
 
 	fclose(file_in);
 	fclose(file_out);
 
 	printf("Done!\n");
 
 	return RES_OK;
 }

