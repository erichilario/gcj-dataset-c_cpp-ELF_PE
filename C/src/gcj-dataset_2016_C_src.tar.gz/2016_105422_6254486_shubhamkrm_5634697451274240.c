#include<stdio.h>
 #include<string.h>
 
 void flip(char expr[], int pos)
 {
 	char expr_c[101];
 	strcpy(expr_c, expr);
 	int i;
 	for (i=0;i<=pos;++i)
 		if (expr_c[pos-i]=='+')
 			expr[i]='-';
 		else
 			expr[i]='+';
 }
 
 int make_all_plus(char expr[], int len)
 {
 	if (len==1 && expr[0]=='+')
 		return 0;
 	else if(len==1)
 		return 1;
 	if (expr[len-1]=='+')
 		return make_all_plus(expr,len-1);
 	else
 	{
 		if (expr[0]=='-')
 		{
 			flip(expr,len-1);
 			return 1+make_all_plus(expr, len-1);
 		}
 		else
 		{
 			int i,pos=-1;
 			for (i=len-1;i>=0;i--)
 				if (expr[i]=='+')
 				{
 					pos=i;
 					break;
 				}
 			if (pos==-1)
 				return 1;
 			flip(expr,pos);
 			return 1+make_all_plus(expr, len-1);
 		}
 	}
 }
 
 int main()
 {
 	int i,t;
 	scanf("%d",&t);
 	for(i=1;i<=t;++i)
 	{
 		int steps;
 		char expr[101];
 		scanf("%s",expr);
 		steps = make_all_plus(expr,strlen(expr));
 	       printf("Case #%d: %d\n",i,steps);	
 	}
 	return 0;
 }

