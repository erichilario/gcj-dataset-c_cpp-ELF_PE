#include<stdio.h>
 #include<string.h>
 int main()
 {
 	int t,i,c,count,len;
 	char str[101],sign;
 	FILE *fin,*fout;
 	fin=fopen("B-large.in","r");
 	fout=fopen("outputBlarge.out","w");
 	fscanf(fin,"%d",&t);
 	c=1;
 	while(t--)
 	{
 		fscanf(fin,"%s",str);
 		len=strlen(str);
 		i=len-1;
 		sign='+';
 		count=0;
 		while(i>=0)
 		{
 			if(str[i]!=sign)
 			{
 				count++;
 				sign=(sign=='+')?'-':'+';
 			}
 			i--;
 		}
 		fprintf(fout,"Case #%d: %d\n",c,count);
 		c++;
 	}
 	fclose(fin);
 	fclose(fout);
 	return 0;
 }

