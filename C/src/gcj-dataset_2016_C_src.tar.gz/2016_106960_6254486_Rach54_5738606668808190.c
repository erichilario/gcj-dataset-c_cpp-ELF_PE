#include <stdio.h>
 int Prime(long long int number)
 {
     if(number%2==0) return 0;
     else if(number%3==0) return 0;
     else if(number%5==0) return 0;
     else if(number%7==0) return 0;
     else if(number%11==0) return 0;
     else if(number%13==0) return 0;
     else if(number%17==0) return 0;
     else if(number%19==0) return 0;
     else if(number%23==0) return 0;
     else if(number%29==0) return 0;
     else if(number%31==0) return 0;
     else if(number%37==0) return 0;
     else if(number%41==0) return 0;
     else if(number%43==0) return 0;
     else if(number%47==0) return 0;
     else if(number%53==0) return 0;
     else return 1;
 }
 int main(void) {
     
         
         int iteration = 5;
         int N[16];
         int i;
         for(i=0;i<16;i++)N[i] = 0;
         N[0] =1;
         N[15] =1;
         long long int number;
         long long int nos[9];
         int k2 =0;
         int k;
         int flag2 = 1;
         int count = 50;
         long long int step;
         long long int no;
         printf("Case #1:\n");
         while(k2<count)
         {
             flag2 = 1;
             for(k = 2;k<=10;k++)
             {
                 number = 0;
                 for(i=0;i<16;i++)
                 {
                     number = number*k + N[i];
                 }
                 nos[k-2] = number;
                 //cout<<number<<"\n";
                 if(k==2)step = number;
                 if(Prime(number) == 1)
                 {
                     flag2 = -1;
                     break;
                 }
             }
             if(flag2==1)
             {
                 k2++;
                   printf("%lld ",nos[8]);
                   for(i=0;i<9;i++)
                   {
                       if(nos[i]%2==0){printf("2 ");}
                       else if(nos[i]%3==0){printf("3 ");}
                       else if(nos[i]%5==0){printf("5 ");}
                       else if(nos[i]%7==0){printf("7 ");}
                       else if(nos[i]%11==0){printf("11 ");}
                       else if(nos[i]%13==0){printf("13 ");}
                       else if(nos[i]%17==0){printf("17 ");}
                       else if(nos[i]%19==0){printf("19 ");}
                       else if(nos[i]%23==0){printf("23 ");}
                       else if(nos[i]%29==0){printf("29 ");}
                       else if(nos[i]%31==0){printf("31 ");}
                       else if(nos[i]%37==0){printf("37 ");}
                       else if(nos[i]%41==0){printf("41 ");}
                       else if(nos[i]%43==0){printf("43 ");}
                       else if(nos[i]%47==0){printf("47 ");}
                       else if(nos[i]%53==0){printf("53 ");}
                       else printf("asda");
                   }
                   printf("\n");
             }
             step = step +2;
             no = step;
             int l=0;
             while(no>0)
             {
                 N[15-l] = no%2;
                 no = no/2;
                 l++;
             }
             
             
         }
 
 	// your code goes here
 	return 0;
 }
 

