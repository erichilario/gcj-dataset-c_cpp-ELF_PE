#include <stdio.h>
 #include <string.h>
 
 int isPositive(char *s, int length) {
 	int i;
 	for(i = 0; i < length; i++) {
 		if(s[i] != '+') {
 			return 0;
 		}
 	}
 	return 1;
 }
 int main() {
 	int T;
 	char cake[1000];
 	scanf("%d", &T);
 	int i, t;
 	for(t=0;t<T;t++) {
 		scanf("%s", cake);
 		int length = strlen(cake);
 		int num = 0;
 		while(!isPositive(cake, length)) {
 			// bottom '+'
 			int p = 0;
 			for(i = length-1; i >= 0; i--)
 				if(cake[i] == '+')
 					p++;
 				else
 					break;
 			length -= p;
 			// find top '+'
 			int pos = 0;
 			for(i = 0; i < length; i++) {
 				if(cake[i] == '+')
 					pos++;
 				else
 					break;
 			}
 			// flip top '+'
 			if(pos!=0) num++;
 			for(i=0; i<pos;i++) {
 				cake[i] = '-';
 			}
 
 			if(isPositive(cake, length)) break;
 			// find top '-'
 			int neg=pos;
 			for(i=pos;i<length;i++)
 				if(cake[i] == '-')
 					neg++;
 				else
 					break;
 			//flip all 1. flip '+' '-' 2. swap(head, end)
 			char temp;
 			if(neg!=0) num++;
 			for(i=0; i<length;i++)
 				if(cake[i] == '+')
 					cake[i] = '-';
 				else
 					cake[i] = '+';
 
 			for(i=0; i < length/2;i++) {
 				temp = cake[i];
 				cake[i] = cake[length-1-i];
 				cake[length-1-i] = temp;
 			}
 
 			length-=neg;
 		}
 		printf("Case #%d: %d\n", t+1, num);
 	}
 
 	return 0;
 }
 
 // flip top max + pl to -
 // find top max '-' length nl flip total length  +-.....++++ total length - nl

