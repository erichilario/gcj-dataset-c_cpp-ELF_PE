#include <stdio.h>
 #include <stdlib.h>
 int res;
 void get_res(int n){
 	char num[10];
 	int chars[10] = {0}, i, sum =0, ctr = 1, n1;
 	n1 = n;
 	if(n1 == 0){
 		res = -1;
 		return ;
 	}
 	do{
 		n1 = n*ctr;		
 		//printf("**%d\n", n1);		
 				
 		snprintf(num, 10, "%d", n1);
 		
 		for(i = 0; num[i] != '\0'; i++){
 			chars[num[i] - '0'] = 1;
 		}
 		
 		for(i = 0; i < 10; i++)
 			sum += chars[i];
 		if(sum == 10){
 			res = n1;			
 			return ;
 		}
 		else 
 			sum = 0;
 
 		ctr++;
 		
 	}while(1 == 1);
 	//return n;
 }
 
 
 int main(){
 	int t, *arr, i;
 	
 	FILE *fp = fopen("A-large.in", "r");
 	FILE *fpo = fopen("OUTPUT.txt", "w");
 	fscanf(fp, "%d", &t);
 	arr = (int *)malloc(sizeof(int)*t);
 	for(i = 0; i < t; i++){
 		fscanf(fp, "%d", &arr[i]);
 		
 	}
 	
 	for(i = 0; i< t; i++){
 //		res = 
 		get_res(arr[i]);
 		if(res == -1)
 			fprintf(fpo, "Case #%d: INSOMNIA\n", i+1);
 		else
 			fprintf(fpo, "Case #%d: %d\n", i+1, res);
 	}
 	return 0;
 }

