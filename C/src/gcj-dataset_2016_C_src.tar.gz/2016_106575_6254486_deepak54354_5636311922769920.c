#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <stdint.h>
 #include <math.h>
 #include <inttypes.h>
 #define __STDC_FORMAT_MACROS
 #define BYTE uint64_t
 int t, K, C, S;
 int main()
 {
   scanf("%d", &t);
   for (int test = 0; test< t; test++)
   {
     scanf("%d %d %d", &K, &S, &C);
     printf("Case #%d: ", test+1);
     for (int i = 1; i <= K; i++)
     {
       printf("%d ", i);
     }
     printf("\n");
   }
 }

