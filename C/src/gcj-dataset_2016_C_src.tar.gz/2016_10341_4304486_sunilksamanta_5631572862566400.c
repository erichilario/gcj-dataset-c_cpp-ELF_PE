#include<stdio.h>
 
 void main(){
     int t,i,n,j,k,s[11][11],f[11],a,count;
     FILE *in,*out;
     in=fopen("C-small-attempt0.in","r");
     out=fopen("c-small.out","w");
     fscanf(in,"%d",&t);
     for(k=0;k<t;k++){
         count=0;
         fscanf(in,"%d",&n);
         for(i=1;i<=n;i++){
             for(j=1;j<=n;j++)
                 s[i][j]=0;
         }
 
         for(i=1;i<=n;i++){
             fscanf(in,"%d",&a);
             s[i][a]=1;
             s[a][i]=1;
 
             f[i]=0;
         }
 
         i=1;
         f[1]=1;
         while(i<=n){
             j=1;
             while(1){
                 if((s[i][j]==1)&&(f[j]==0))
                     break;
                 j++;
             }
             if(f[j]==1)
                 break;
             f[j]=1;
             i=j;
         }
 
         for(i=1;i<=n;i++)
             if(f[i]==1)
                 count++;
         fprintf(out,"Case #%d: %d\n",k+1,count);
     }
 }

