#include<stdio.h>
 #include<stdlib.h>
 
 void main(){
    long T,t,N,i,count,k,last;
    scanf("%ld",&T);
    int pot[10]={1,2,4,8,16,32,64,128,256,512};
    for(t=1;t<=T;++t){
       scanf("%ld",&N);
       count=0;
    
       for(i=1;count!=1023;++i){
          k=N*i;
          if(k==0){
             last=-1;
             break;
          }
          last=k;
          while(k>0){
             count |= pot[k%10];
             k=k/10;
          }
       }
       if(last>=0)
          printf("Case #%ld: %ld\n",t,last);
       else
          printf("Case #%ld: INSOMNIA\n",t);
    }
 }

