#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 #define INPUT_FILE "C-small-attempt2.in"
 #define OUTPUT_FILE "output"
 #define MAX_N 16
 
 
 int main()
 {
     FILE *fp_in, *fp_out;
 
     int N, J;
     int j,k,m;
     int jamcoin;
     short flag, prime, repeat, no_repeat;
     unsigned long binary[MAX_N];
     unsigned long bases[11], divisors[50][11];
 
     fp_in=fopen(INPUT_FILE,"r");
     fscanf(fp_in,"%*d");
     fscanf(fp_in,"%d %d", &N, &J);
     fclose(fp_in);
 
     fp_out=fopen(OUTPUT_FILE,"w");
     fprintf(fp_out,"Case #1:\n");
 
     jamcoin=0;
     for(j=0;j<pow(2,N-2) && jamcoin<J;j++)
     {
         binary[0]=1;
         for (k=0;k<(N-2);k++)
         {
             if (j&(int)pow(2,k))
               binary[k+1]=1;
             else
               binary[k+1]=0;
         }
         binary[N-1]=1;
 
         printf("%d\n",j);
         //printf("%d%d%d%d%d%d\n",binary[0],binary[1],binary[2],binary[3],binary[4],binary[5]);
 
         flag=1;
         no_repeat=0;
         for(k=2;k<11 && flag;k++)
         {
             bases[k]=0;
             for(m=N-1;m>=0;m--)
             {
                 if(binary[N+1-m])
                     bases[k]+=pow(k,m);
             }
             //printf("%lu\n",bases[k]);
             prime=1;
             divisors[jamcoin][k]=2;
             while(divisors[jamcoin][k]<bases[k] && prime)
             {
                 if((bases[k]%(divisors[jamcoin][k]))==0)
                 {
                     if(!no_repeat)
                     {
                         repeat=0;
                         for(m=0;m<jamcoin && !repeat;m++)
                         {
                             if(divisors[m][k]==divisors[jamcoin][k])
                                 repeat=1;
                         }
                         if(!repeat)
                         {
                             prime=0;
                             no_repeat=1;
                         }
                     }else
                         prime=0;
                 }
                 if(prime)
                     divisors[jamcoin][k]++;
             }
             if(prime)
                 flag=0;
 
         }
 
         if(flag)
         {
             printf("######    %d    ######\n",jamcoin);
 
             for (k=0;k<N;k++)
                 fprintf(fp_out,"%lu",binary[(N-1)-k]);
             fprintf(fp_out," ");
             for(k=2;k<11;k++)
             {
                 printf("%lu\n",divisors[jamcoin][k]);
                 fprintf(fp_out,"%lu ",divisors[jamcoin][k]);
             }
 
             fprintf(fp_out,"\n");
             jamcoin++;
         }
 
     }
     fclose(fp_out);
 
     exit(EXIT_SUCCESS);
 }

