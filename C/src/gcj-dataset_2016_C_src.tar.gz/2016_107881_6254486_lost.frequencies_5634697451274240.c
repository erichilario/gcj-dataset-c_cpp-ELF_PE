#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 void flip(int i,char s[]){
     char ch ;
     s[0]=='+'? (ch = '-'):(ch = '+');
     for(int j=0;j<i;j++){
         s[j]=ch;
     }    
 }
 int main(int argc, char **argv)
 {
     FILE *input = fopen("A.in","r");
     FILE *output = fopen("A.out","w");
 	printf("hello world\n");
     static int j=0;
     int opration=0;
     int cases,testcase;
     char num[8];
     fgets(num,sizeof(num),input);
     sscanf(num,"%d",&cases);
     char *chr=malloc(100);
     char *temp=malloc(100);
     testcase=0;
     while(testcase<cases){
             opration=0;
             j=0;
             memset(chr,0,sizeof(chr));
             memset(temp,0,sizeof(temp));
             fgets(temp,100,input);
             sscanf(temp,"%s",chr);
             int len = strlen(chr);                       
             while(j!=len-1){
                 while(chr[j]==chr[j+1]){
                     j++;
                 } if(j==len-1) break;
                 flip(j+1,chr);opration++;
             }
             if(chr[j]=='-') opration++;
             //printf("case %d; string %s; len %d requires %d\n",testcase+1,chr,len, opration);
             fprintf(output,"Case #%d: %d\n",testcase+1,opration);
             testcase++; 
     }
     // @ free resource
     free(chr);
     free(temp);
     fclose(input);
     fclose(output);
     return 0;	
 }

