#include<stdio.h>
 
 /*Set all values of vector as zero*/
 void initiateVector(int v[10]){
     int i;
     for(i = 0; i<10; i++)
         v[i] = 0;
 }
 
 int vectorFilled(int v[10]){
     int i;
     int filled = 1;
     for(i = 0; i< 10 && filled == 1 ; i++)
         if(v[i] == 0)
             filled = 0;
     return filled;    
 }
 
 void modifyVector(int v[10], int N){
     while(N != 0){
         v[N%10]++;
         N = N/10;
     }
 }
 
 int main(){
     long int N; 
     int T;
     /*M = number she will arrive in (i*N)*/
     long int M;
     /*counters*/
     int i, j;
     /*vector that stores how many times she has seen each number*/
     int vector[10];
     
     /*Data input*/
     scanf("%d", &T);
     
     for(i = 0; i< T; i++){
         j = 1;
         initiateVector(vector);
         scanf("%ld", &N);
         if(N > 0){
             while(!vectorFilled(vector)){
                 M = N*(j++);
                 modifyVector(vector, M);
             }
             printf("Case #%d: %ld\n", i+1, M);
         }
         
         else
             printf("Case #%d: INSOMNIA\n", i+1);
     }
     return 0;
 }
