#include <stdio.h>
 #include <stdbool.h>
 //using namespace std;
 
 int updateFound(long int number, bool found[]){
 	int updatedCount = 0;
 	while(number != 0){
 		if (!found[number%10])
 		{
 			found[number%10] = true;
 			updatedCount++;
 		}
 		number /= 10;
 	}
 	return updatedCount;
 }
 
 int main(){
 	freopen("input.txt", "r", stdin);
 	freopen("output.txt", "w", stdout);
 	int totalCases, caseNo;	scanf("%d", &totalCases);
 	for (caseNo = 0; caseNo < totalCases; ++caseNo)
 	{
 		
 		bool found[10];
 		int noOfFound = 0, i;
 		//init
 		for (i = 0; i < 10; ++i)
 			found[i] = false;
 		long int n, multiplier = 0;	scanf("%ld", &n);
 		if (n == 0)
 		{
 			printf("Case #%d: INSOMNIA\n", caseNo + 1);
 			continue;
 		}
 		while(noOfFound != 10){
 			multiplier++;
 			noOfFound += updateFound(n*multiplier, found);
 		}
 		printf("Case #%d: %ld\n", caseNo + 1, n*multiplier);
 	}
 	return 0;
 }

