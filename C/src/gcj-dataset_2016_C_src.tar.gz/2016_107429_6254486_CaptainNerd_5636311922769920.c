#include<stdio.h>
 #include<conio.h>
 void main()
 {
 	int t,k,c,s,p=1,i;
 	long long int x,m;
 	scanf("%d",&t);
 	while(t>0)
 	{
 		scanf("%d%d%d",&k,&c,&s);
 	         if(k==s)   
 		         { printf("Case #%d: ",p);
 		           for(i=1;i<=k;i++)
 			        printf("%d ",i);
 			     }
 
 	         else
 	           {   x=pow(k,c);
 		           m=k;
 		           printf("Case #%d: ",p);
 		           printf("%d ",k-1);
 		           while(m<x)
 		              {    m=m*c;
 			               printf("%d ",m);
 		              }
 
 	             }
 
 	     t--;
 	     p++;
 		 printf("\n");
 
     }
     getch();
 }
