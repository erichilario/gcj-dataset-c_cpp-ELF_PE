#include<stdio.h>
 
 int main()
 {
 	int t,i;
 	scanf("%d",&t);
 	for(i=1;i<=t;++i)
 	{
 		long long int num,num_c;
 		int c=2,digits[10]={0};
 		scanf("%lld",&num);
 		num_c=num;
 		if (num==0)
 			printf("Case #%d: INSOMNIA\n",i);
 		else
 		{
 			while(1)
 			{
 				int k,count=0,digit;
 				while(num_c>0)
 				{
 					digit=num_c%10;
 					digits[digit]=1;
 					num_c/=10;
 				}
 				for (k=0;k<10;k++)
 					if (digits[k]==1)
 						count++;
 				if (count==10)
 					break;
 				num_c=num*c;
 				c++;
 			}
 			printf("Case #%d: %lld\n",i,num*(c-1));
 		}
 	}
 	return 0;
 }

