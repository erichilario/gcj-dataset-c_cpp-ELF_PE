/*
  * =====================================================================================
  *
  *       Filename:  foo.c
  *
  *    Description:  
  *
  *        Version:  1.0
  *        Created:  04/09/2016 04:47:23 PM
  *       Revision:  none
  *       Compiler:  gcc
  *
  *         Author:  YOUR NAME (), 
  *   Organization:  
  *
  * =====================================================================================
  */
 #include <stdlib.h>
 #include <stdio.h>
 
 int main(){
   int i, j, k, l;
   int T, N, M;
   int count;
   int bits[10];
   scanf("%d\n", &T);
 
   for(i = 1; i <= T; i++){
     scanf("%d\n", &N);
     
     if(N == 0){
       printf("Case #%d: INSOMNIA\n", i);
     }
     else{
       count = 0;
       for(j = 0; j < 10; j++) bits[j] = 0;
       M = N;
       while(count < 10){
         for(k = 1; k <= M ; k = k*10)
           if (bits[( (M % (k * 10)) / k )] == 0){
             bits[( (M % (k * 10)) / k )] = 1;
             count++;
           } 
         M = M + N;
       }
 
       printf("Case #%d: %d\n", i, (M - N));
     }
   }
 
   return 0;
 }
 

