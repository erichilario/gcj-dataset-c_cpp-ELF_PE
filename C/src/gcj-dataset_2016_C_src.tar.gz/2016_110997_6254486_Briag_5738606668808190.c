#define __STDC_FORMAT_MACROS
 #define uint128_t __uint128_t 
 #include <inttypes.h>
 
 /*      UINT64_MAX 18446744073709551615ULL */
 #define P10_UINT64 10000000000000000000ULL   /* 19 zeroes */
 #define E10_UINT64 19
 #define STRINGIZER(x)   # x
 #define TO_STRING(x)    STRINGIZER(x)
 
 #include <stdio.h>
 #include <stdint.h>
 #define OUT "out.big.c"
 
 FILE * out;
     
 int caseIndex = 1;
 
 static int print_u128_u(uint128_t u128)
 {
     int rc;
     if (u128 > UINT64_MAX)
     {
         uint128_t leading  = u128 / P10_UINT64;
         uint64_t  trailing = u128 % P10_UINT64;
         rc = print_u128_u(leading);
         rc += fprintf(out,"%." TO_STRING(E10_UINT64) PRIu64, trailing);
     }
     else
     {
         uint64_t u64 = u128;
         rc = fprintf(out,"%" PRIu64, u64);
     }
     return rc;
 }
 
 void printResult(uint128_t  result, uint128_t  tab[9]) {
     
     print_u128_u(result);
     for(int i = 0; i < 9; i++) {
         fprintf(out," ");
         print_u128_u(tab[i]);
     }
     
     fprintf(out, "\n");
     
     
    
     caseIndex++;
 }
 
 uint128_t  convert(uint128_t  number,int base){
     if(number == 0 || base==10)
         return number;
 
     return (number % 10) + convert(number / 10, base) * base;
 }
 
 uint128_t  is_not_prime(uint128_t   p)
 {
     uint128_t  d;
 
     for (d = 2; d < 15; d = d + 1)
 	if (p % d == 0)
 	    return d;
 
     return 0;
 }
 
 int isFull(uint128_t  tab[]) {
     for(int i  = 0; i < 9; i++)
         if(tab[i] == 0)
             return 0;
             
     return 1;
 }
 
 uint128_t  progress2(uint128_t  number, uint128_t  pr) {
 
     uint128_t  result = number;
     
     if(number % (10 * pr) > (pr)) {
         result-=pr;
         return progress2(result, pr * 10);
     } else {
         result+=pr;
         return result;
     }
         
 }
 uint128_t  progress(uint128_t  number) {
 
     uint128_t  result = number;
     
     if(number % (100) > (10)) {
         result-=10;
         return progress2(result, 100);
     } else {
         result+=10;
         return result;
     }
 }
 
 
 int compute( uint128_t  number, int J) {
     
     for(int i = 0; i < J;) {
      
         uint128_t  result[9];
         
         for(int j = 2; j <= 10; j++) {
             uint128_t  prime = is_not_prime(convert(number,j));
 
             result[j-2] = prime;
         }
         
         if(isFull(result) != 0) {
             printResult(number, result);
             i++;
         }
             
         number = progress(number);
     }
     
     
 }
 
 
 int main() {
     
     out = fopen (OUT, "w+");
     
     int N = 32;
     int J = 500;
     
     
     
     uint128_t  number = 1;
     
     for(int i = 1; i < N; i++) {
         number = number * 10;
     }
     number = number + 1;
     
     fprintf(out,"Case #%d:\n", caseIndex);
     
     
     compute(number , J);
     
     //printf("%" PRIu64 " %" PRIu64 " %" PRIu64" %" PRIu64" %" PRIu64" %" PRIu64" %" PRIu64" %" PRIu64"\n", convert(a,2),convert(a,3),convert(a,4),convert(a,5),convert(a,6),convert(a,7),convert(a,8),convert(a,9));
     //precompute();
     
     return 0;
 }

