#include<stdio.h>
 #define size 100
 #include<string.h>
 
 char stack[size],temp[size];
 int top1=-1,top2=-1;
 
 int main(){
     char S[100],c;
     int i=1,t,j,count;
     scanf("%d",&t);
     while(i<=t){
         scanf("%s",S);
         j=0;
         count=0;
         while(j<strlen(S)){
             stack[++top1]=S[j];
             j++;
         }
         while(top1!=-1){
             c=stack[top1--];
             while(c=='+' && top1!=-1)
                 c=stack[top1--];
             if(c=='-'){
                 c='+';
                 temp[++top2]=c;
                 while(top1!=-1){
                     c=stack[top1--];
                     if(c=='+')
                         c='-';
                     else
                         c='+';
                     temp[++top2]=c;
                 }
                 while(top2!=-1){
                     stack[++top1]=temp[top2--];
                 }
                 count++;
             }
         }
         printf("Case #%d: %d\n",i,count);
         i++;
     }
     return 0;
 }

