#include <stdio.h>
 #include <string.h>
 int comp(char *);
 int main(void) {
 int t=0,i=0;
 scanf("%d",&t);
 	for(i=1;i<=t;i++)
 	{
 		int j=0,k=0,counter=0;
 		char x[10];
 		scanf("%s",x);	
 		while(comp(x))//-------while all chars are not +
 		{	
 			if(x[0]=='+')
 			{
 				j=0;
 				while(x[j]!='-'&&j<strlen(x))
 				{ j++; }
 				for(k=0;k<j;k++)
 				{  x[k]='-';  }
 				counter++;
 			}
 			else if(x[0]=='-')
 			{
 				j=0;
 				while(x[j]!='+'&&j<strlen(x))
 				{  j++;  }
 				for(k=0;k<j;k++)
 				{  x[k]='+';  }
 				counter++;
 			}
 		}
 		//--------	one test ends--- printing result
 		printf("Case #%d: %d\n",i,counter);
 	}	
 	return 0;
 }
 int comp(char *x)
 {	int count=0;
 	for(int l=0;l<strlen(x);l++)
 	{	
 		if(x[l]=='+')
 		{ count++; }
 	}
 	if(count==strlen(x)){ return 0;}
 	return 1;
 }
