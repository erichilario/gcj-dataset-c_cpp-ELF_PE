#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int traverse(int*array, int next, int count, int parent, int n)
 {
 // printf("next = %d, count = %d, parent -= %d\n", next, count, parent);
  if(count > n)
  {
   return -1;
  }
  if(next == parent)
   {
    return count;
   }
   else
   {
    return traverse(array, array[next], count + 1, parent, n);
   }
 }
 
 
 
 int main()
 {
 
  int testcase, count, i, count_1, n, max, temp;
  int arr[100];
 
  scanf("%d", &testcase);
 
  for(count = 1 ; count <= testcase; count++)
  {
   memset(arr, 0 , sizeof(arr));
 
   max = 0;
   temp = 0;
  
  scanf("%d", &n);
 
 // printf("t = %d, n = %d\n" , testcase,n);
   //fflush(stdin);
 
   for(i = 0 ; i < n ; i++)
   {
   // printf("index = %d\n", i);
 
    scanf("%d", arr + i);
 
    arr[i] = arr[i] - 1;
   // printf("__%d\n " , arr[i]);
 
   }
 
 //  sleep(2);
   for(i = 0 ; i < n ; i++)
   {
    //printf("_%d ", array[i]);
    if(arr[i] != i)
    {
     temp = traverse(arr, arr[0] , 1, i, n);
     if(temp > max)
     {
      max = temp;
     }
    }
   }
 
   printf("Case #%d: %d\n", count, max);
 
  }
 }
 

