#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 int main()
 {
 	int t,i,j,k,count,last,len;
 	char s[100],str[100];
 	scanf("%d",&t);
 	for(i=0;i<t;i++)
 	{
 		count=0;
 		scanf("%s",s);
 		len=strlen(s);
 		//printf("%s\n",s);
 		while(1)
 		{
 			last=200;
 			for(j=len-1;j>=0;j--)
 		    {
 			    if(s[j]=='-')
 			    {
 				   last=j;
 				   break;
 			    }
 		    }
 		if(last==200)
 		{
 			printf("Case #%d: %d\n",i+1,count);
 			break;
 		}
 		else
 		{
 			j=0;
 			if(s[j]=='+')
 			{
 				str[j]='+';
 				j++;
 				while(s[j]=='+')
 				{
 					str[j]='+';
 					j++;
 				}
 				count++;
 				while(s[j]=='-'&&j<=last)
 				{
 					str[j]='+';
 					j++;
 				}
 				while(j<=last)
 				{
 					if(s[j]=='+')
 						str[j]='-';
 					else
 						str[j]='+';
 					j++;
 				}
 				count++;
 				for(j=0;j<=last;j++)
 					s[last-j]=str[j];
 			}
 			else
 			{	
 				j=0;
 				while(s[j]=='-'&&j<=last)
 				{
 					str[j]='+';
 					j++;
 				}
 				while(j<=last)
 				{
 					if(s[j]=='+')
 						str[j]='-';
 					else
 						str[j]='+';
 					j++;
 				}
 				count++;
 				for(j=0;j<=last;j++)
 					s[last-j]=str[j];
 			}
 		}
 	    }
 	}
 }
 /*int check(char s,int len)
 {
 	int i;
 	for(i=0;i<len;i++)
 		if(s[i]=='-')
 			return 1;
 	return 0;
 }*/

