#include <stdio.h>
 #include <stdlib.h>
 
 
 int T;
 
 int digit;
 
 int CHECK=(1<<0)+(1<<1)+(1<<2)+(1<<3)+(1<<4)+(1<<5)+(1<<6)+(1<<7)+(1<<8)+(1<<9);
 
 void count_digit(unsigned long long N) {
 
   do {
     digit |=  1 << (N % 10);
     //fprintf(stderr,"%llu %llu %d\n",N,N%10,digit);
     N=N/10;
   } while (N>0);
 }
 
 #define MAX 1000000
 
 long long insomnia(unsigned long long N) {
 
   digit=0;
 
   for(int i=1;i<MAX+1;i++) {
     count_digit(N*i);
     if (digit==CHECK)
       return N*i;
   }
 
   return 0;
 };
 
 int main() {
   unsigned long long n;
   unsigned long long N;
 
   //printf("%lu\n",sizeof(long long));
 
   scanf("%d",&T);
   for(int i=1;i<T+1;i++){
     scanf("%llu",&N);
 
     //fprintf(stderr,"############ %d %llu\n",i,N);
 
     n=insomnia(N);
     if (n)
       printf("Case #%d: %llu\n",i,n);
     else
       printf("Case #%d: INSOMNIA\n",i);
   }
 }

