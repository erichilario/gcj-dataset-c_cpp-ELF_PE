#include<stdio.h>
 #include<string.h>
 int main(void){
 	long long int t;
 	scanf("%lld",&t);
 	int p=0;
 	while(t--){
 		p++;
 		char x[11];
 		int length,i,count=0;
 		scanf("%s",x);
 		if(strlen(x)==1){
 			if(x[0]=='+')
 				printf("Case #%d: %d\n",p,count);
 			else
 				printf("Case #%d: %d\n",p,count+1);
 		}
 		
 		else{
 			
 			length=strlen(x);
 			while(1){
 				
 				for(i=0;i<length;i++)
 					if(x[i]=='-')
 						break;
 				if(i==length)
 					break;
 				i=1;
 				while(i<length && x[0]==x[i]){
 					if(x[0]=='+')
 						x[i]='-';
 					else
 						x[i]='+';
 					i++;
 				}
 				if(x[0]=='+')
 					x[0]='-';
 				else
 					x[0]='+';
 				count++;
 							
 			}
 			printf("Case #%d: %d\n",p,count);
 		}
 	}	
 	return 0;
 }

