#include <stdio.h>
 #include <stdlib.h>
 
 int J = 10;
 int N = 16;
 
 void bin(int n, char* end){
     *end = '\0';
 
     unsigned int i = 1; 
     while (n) {
 	end--;
 
 	if (n & i)
 	    *end = '1';
 	else
 	    *end = '0';
 
 	n >>= 1;
     }
 }
 
 unsigned long divisor(unsigned long p){
     if (p % 2 == 0)
 	return 2;
 
     for (unsigned long i = 3; i < p/2; i+=2)
 	if (p % i == 0)
 	    return i;
 
     return 0;
 }
 
 main(){
     printf("Case #1:\n");
     
     int jamcount = 0;
 
     char binjam[N+1];
     unsigned long jam = 32769; //1000000000000001
 
     unsigned long divs[11];
     while (jam < 65536 && jamcount < J) {
 
 	if (jam&1) {
 	    bin(jam, binjam+N);
 
 	    divs[10] = 0;
 	    for (int b = 2; b < 11; b++){
 		unsigned long div = divisor(strtol(binjam, NULL, b));
 		if (div)
 		    divs[b] = div;
 		else
 		    break;	
 	    }
 
 	    if (divs[10]){
 		printf("%s", binjam);
 		for (int i = 2; i < 11; i++)
 		    printf(" %ld", divs[i]);
 		printf("\n");
 
 		jamcount++;
 	    }
 	}
 	    
 	jam++;
     }
 }

