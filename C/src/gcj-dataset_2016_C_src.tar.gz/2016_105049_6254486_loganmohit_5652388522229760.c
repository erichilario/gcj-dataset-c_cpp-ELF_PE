#include<stdio.h>
 void checkdig(int p,int q[]){
 	int dig;
 	while(p!=0){
 		dig=p%10;
 		p/=10;
 		q[dig]=1;
 	}
 }
 int allcheck(int r[]){
 	int m;
 	for(m=0;m<10;m++){
 		if(r[m]==0)
 			return 0;
 	}
 	return 1;
 }
 int main(){
 int t,n,i,j,k,n1;
 int check[10];
 for(k=0;k<10;k++)
 	check[k]=0;
 scanf("%d",&t);
 for(j=1;j<=t;j++){
 scanf("%d",&n);
 for(k=0;k<10;k++)
 	check[k]=0;
 if(n!=0){
 for(i=1;!allcheck(check);i++){
 	n1=n*i;
 	checkdig(n1,check);
 
 }
 if(j!=t)
 printf("Case #%d: %d\n",j,n1);
 else
 	printf("Case #%d: %d",j,n1);
 }
 else
 {
 if(j!=t)
 printf("Case #%d: INSOMNIA\n",j);
 else
 	printf("Case #%d: INSOMNIA",j);
 }
 }
 }

