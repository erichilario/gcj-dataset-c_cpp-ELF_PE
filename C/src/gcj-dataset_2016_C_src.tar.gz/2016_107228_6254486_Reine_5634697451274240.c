#include<stdio.h>
 #include<string.h>
 
 void flip(char *stack, int i){
 	int j = 0;
 	char temp = 0;
 
 	for(j = 0; j < i/2; j++){
 		temp = stack[j];
 		stack[j] = stack[i-j];
 		stack[i-j] = temp;
 	}
 	if(i%2){
 		temp = stack[i/2];
 		stack[i/2] = stack[(i/2)+1];
 		stack[(i/2)+1] = temp;
 	}
 
 	for(j = 0; j <= i; j++){
 		if(stack[j] == '-') stack[j] = '+';
 		else stack[j] = '-'; 
 	}
 }
 
 int main(){
 	int n = 0;
 	scanf("%d", &n);
 
 	int i = 0;
 	for(i = 0; i < n; i++){
 		char stack[102];
 		scanf("%s", stack);
 
 		int j = 0;
 		int flips = 0;
 		for(j = strlen(stack) - 1; j > -1; j--){
 			if(stack[j] == '+') continue;
 			if(stack[0] == '+') {
 				int k = 0;
 				for(k = 0; stack[k] == '+'; k++){
 					stack[k] = '-';
 				}				
 				flips++;
 			}
 			flip(stack, j);
 			flips++;
 		}
 		printf("Case #%d: %d\n", i+1, flips);
 	}
 	return 0;
 }

