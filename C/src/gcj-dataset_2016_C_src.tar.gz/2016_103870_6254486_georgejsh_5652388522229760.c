#include<stdio.h>
 int a[10];
 int check(){
 	int i;
 	for(i=0;i<10;i++)
 		if(a[i]==0)
 			return 0;
 	return 1;
 }
 void reset(){
 	int i;
 	for(i=0;i<10;i++)
 		a[i]=0;
 }
 void set(long long int n){
 	while(n){
 		a[n%10]=1;
 		n=n/10;
 	}
 }
 int main(){
 	int t;
 	int i;
 	long long int n,res;
 	for(scanf("%d",&t),i=0;i<t;i++){
 		reset();
 		scanf("%lld",&n);
 		if(n==0)
 			printf("Case #%d: INSOMNIA\n",i+1);	
 		else {
 			res=n;
 			do{
 				set(res);
 				res+=n;
 			}while(!check());
 			printf("Case #%d: %lld\n",i+1,res-n);
 		}
 	}
 }

