//John Wang
 //Code Jam Qualification Round
 //9/4/2016
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <assert.h>
 #include <math.h>
 
 typedef unsigned long long num;
 typedef struct _digitInfo {
    int digitsLeft;
    int digit;
 } digitInfo;
 
 static num length = 0;
 //static int numSeen[10] = {0};
 
 static num* readInput (void);
 static digitInfo getDigit (num n, num p);
 static int getNumDigits (num n);
 static num updateNumSeen (int* numseen, num n, num numdigits);
 static int checkAllNumSeen (int* numseen);
 
 int main (int argc, char* argv[]) {
    num* allNum = readInput();
    num count = 0;
    while (count < length) {
       int* numseen = (int*)calloc(10, sizeof(int));
       num n = updateNumSeen(numseen, allNum[count], getNumDigits(allNum[count]));
       if (n == 0) printf("Case #%llu: INSOMNIA\n", count+1);
       else printf("Case #%llu: %llu\n", count+1, n);
       count++;
       free(numseen);
    }
    return EXIT_SUCCESS;
 }
 
 static num* readInput (void) {
    assert(scanf("%llu", &length) == 1);
    if (length <= 0) return NULL;
    num* allNum = (num*)malloc(sizeof(num)*length);
    assert(allNum != NULL);
    num count = 0;
    while (count < length) {
       assert(scanf("%llu", &(allNum[count])) == 1);
       count++;
    }
    return allNum;
 }
 
 static digitInfo getDigit (num n, num p) {
    num power = (num)pow(10,(double)p);
    num moded = n%power;
    digitInfo d;
    d.digitsLeft = !(moded == n);
    d.digit = (int)(moded/(power/10.0));
    return d;
 }
 
 static int getNumDigits (num n) {
    num i = 0;
    for (i = 0; n != 0; n/=10, i++);
    return i;
 }
 
 static num updateNumSeen (int* numseen, num n, num numdigits) {
    if (n == 0) return 0;
    num count, l;
    num currN = n;
    for (l=1; 1; currN=n*++l) {
       for (count = 1; count <= getNumDigits(currN); count++) {
          digitInfo d = getDigit(currN, count);
          numseen[d.digit] = 1;
          if (checkAllNumSeen(numseen))
             return currN;
       }
    }
    return 0;
 }
 
 static int checkAllNumSeen (int* numseen) {
    int count = 0;
    for (count = 0; count < 10; count++)
       if (numseen[count] == 0) return 0;
    return 1;
 }

