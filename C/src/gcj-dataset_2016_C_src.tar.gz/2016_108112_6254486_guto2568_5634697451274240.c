#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 
 #define MAX 101
 
 void flipStack(char s[],int N){
     int i;
     for(i = 0; i< N; i++){
         if(s[i] == '+')
             s[i] = '-';
         else
             s[i] = '+';
     }   
 }
 
 int minFlip(char s[], char size){
     int i;
     int operation = 0;
     int normalDeff = 1;
     for(i = size - 1; i>=0; i--){
         if(normalDeff){
             while(s[i] == '+' && i>0)
                 i--;
             if(s[i] == '-'){
                 operation++;
                 normalDeff = 0;
             }
         }
         
         else{
             while(s[i] == '-' && i>0)
                 i--;
             if(s[i] == '+'){
                 operation++;
                 normalDeff = 1;
             }
         }
     }
     return operation;
 }
 
 int main(){
     int T;
     char string[MAX];
     int i;
     int min;
     
     scanf("%d", &T);
     
     for(i = 0; i< T; i++){
         scanf("%s", string);
 
         min = minFlip(string, strlen(string));
         
         printf("Case #%d: %d\n", i+1, min);
     }
     
     return 0;
 }
