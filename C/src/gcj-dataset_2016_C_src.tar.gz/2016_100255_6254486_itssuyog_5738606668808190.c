#include <stdio.h>
 #include <math.h>
 
 
 long long returnpow(int x)
 {
 	long long y = pow(2, x);
 	return y;
 }
 
 void printArr(int x[], int length)
 {
 	for(int i = 0; i<length; i++)
 	{
 		printf("%d", x[i]);
 	}
 }
 long long getNumInBase(int x[], int base, int length)
 {
 	long long y = 0;
 	
 	for(int i = 0; i < length; i++)
 	{
 		y += x[i]*pow(base, length-i-1);
 	}
 	return y;
 }
 
 long long getFactor(long long x)
 {
 	for(long long i = 2; i<x/2; i++)
 	{
 		if(x % i == 0)
 			return i;
 	}
 }
 
 void printAllBase(int x[], int length)
 {
 	for(int i = 2; i<=10; i++)
 	{
 		printf("%lld ", getFactor(getNumInBase(x, i, length)));
 	}
 }
 
 int isPrime(long long n)
 {
     if(n == 2)
         return 1;
     if(n == 3)
         return 1;
     if(n % 2 == 0)
         return 0;
     if(n % 3 == 0)
         return 0;
 
     long long i = 5;
     long long w = 2;
 
     while(i * i <= n)
     {
         if(n % i == 0)
             return 0;
             
 
         i += w;
         w = 6 - w;
     }
     return 1;
 }
 
 void genBin(int length, int c, int caseno)
 {
 	printf("Case #%d:\n", caseno);
 	int a[20], count=0;
 	int flag = 0;
 	
 	for(long long i = 1; i < returnpow(length) && count < c; i = i+4) {
 	    flag = 0;
 	    if(length>2)
 	    {
 		    for(int j = length, k = length-1 ; j>0; j--, k--)
 		    {
 		    	a[k-1] = i/returnpow(j-1)%2;
 		    	//printf("%u", a[j+1]);
 		    }
 		}
 		
 	    a[0] = 1;
 	    a[length-1]=1;
 	    
 	    for(int m = 2; m<=10; m++)
 	    {
 	    	flag = 0;
 	    	long long num = getNumInBase(a ,m, length);
 	    	if(isPrime(num) == 1)
 	    	{
 	    		flag = 99;
 	    		break;
 	    	}
 	    }
 	    
 	    if(flag != 99)
 	    {
 	    	printArr(a, length);
 	    	printf(" ");
 	    	printAllBase(a, length);
 	    	printf("\n");
 	    	count++;
 	    }
 	}
 }
 
 int main(void) {
 	
 	int length, c, T, n=0;
 	scanf("%d", &T);
 	while(T>0)
 	{
 		n++;
 		scanf("%d%d", &length, &c);
 		genBin(length, c, n);
 		T--;
 	}
 	return 0;
 }
 

