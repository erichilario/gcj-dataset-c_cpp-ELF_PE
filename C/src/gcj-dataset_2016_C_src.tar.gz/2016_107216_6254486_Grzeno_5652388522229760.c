//
 //  main.c
 //  CountingSheep
 //
 //  Created by Raymond Tse on 4/8/16.
 //  Copyright © 2016 Raymond Tse. All rights reserved.
 //
 
 #include <stdio.h>
 
 long countSheep(long input)
 {
     int digits[10] = {0};
     long currNum;
     int multiplier = 1;
     
     for(;;)
     {
         currNum = input * multiplier;
         long tempNum = currNum;
         while(tempNum)
         {
             digits[tempNum%10] = 1;
             tempNum /= 10;
         }
         multiplier++;
         int sum = 0;
         for(int i = 0; i< 10;i++)
         {
             sum+=digits[i];
         }
         if (sum == 10){ break;}
     }
     return currNum;
 }
 
 
 int main(int argc, const char * argv[]) {
     
     FILE *inFp;
     inFp = fopen(argv[1],"r");
     
     if (inFp == NULL)
     {
         fprintf(stderr, "Can't open the file");
         exit(1);
     }
     
     FILE *outFp;
     outFp = fopen("out.txt","w");
     
     int numInputs;
     long input;
     long result;
     
     fscanf(inFp, "%d",&numInputs);
     
     for (int i = 0; i < numInputs; i++)
     {
         if (fscanf(inFp, "%li",&input) == 1)
         {
             if (input == 0)
             {
                 fprintf(outFp, "Case #%d: %s\n", i+1, "INSOMNIA");
             }
             else
             {
                 result = countSheep(input);
                 fprintf(outFp, "Case #%d: %li\n", i+1, result);
 
             }
         }
     }
     
     fclose(inFp);
     fclose(outFp);
     
     return 0;
 }
 
 

