#include <stdio.h>
 #include <stdlib.h>
 #include <limits.h>
 
 int length(int n)
 {
     if(n<10)
         return 1;
     else
     {
          int r = 1;
         while (n > 9)
         {
             n /= 10;
             r++;
         }
         return r;
     }
 }
 
 void convertNumberIntoArray(int* res, int number)
 {
     //int length = (int)floor(log10((float)number)) + 1;
     //int* arr = new char[length];
     int i = 0;
     do
     {
     	res[i] = number % 10;
     	number /= 10;
     	i++;
     } while (number != 0);
 }
 
 int main()
 {
     freopen("input.in","r",stdin);
     freopen("newfile.txt","w",stdout);
     int t;
     scanf("%d",&t);
     int caseCount = 0;
     while(t--)
     {
         caseCount++;
         int n;
         scanf("%d",&n);
         if(n==0)
         {
                 printf("Case #%d: INSOMNIA\n",caseCount);
 
         }
         else
         {
             int i=0;
             int factorI=1;
             int p=n;
             int flag=0;
             int count0=0, count1=0, count2=0, count3=0, count4=0, count5=0, count6=0, count7=0, count8=0, count9=0;
             while(flag!=1)
             {
                 int length_of_number = length(p);
                 if(p<10)
                 {
                     if(n==0)
                         count0++;
                     else if(p==1)
                         count1++;
                     else if(p==2)
                         count2++;
                     else if(p==3)
                         count3++;
                      else if(p==4)
                         count4++;
                      else if(p==5)
                         count5++;
                      else if(p==6)
                         count6++;
                     else if(p==7)
                         count7++;
                     else if(p==8)
                        count8++;
                    else if(p==9)
                         count9++;
 
                 }
                 else if(p>=10)
                 {
                     int* res = (int*)malloc(sizeof(int)*length_of_number);
                     convertNumberIntoArray(res, p);
 
                     int j;
                     for(j=0; j<length_of_number; j++)
                     {
 
                         if(res[j]==0)
                         count0++;
                         else if(res[j]==1)
                         count1++;
                         else if(res[j]==2)
                         count2++;
                         else if(res[j]==3)
                         count3++;
                         else if(res[j]==4)
                         count4++;
                         else if(res[j]==5)
                         count5++;
                         else if(res[j]==6)
                         count6++;
                         else if(res[j]==7)
                         count7++;
                         else if(res[j]==8)
                         count8++;
                         else if(res[j]==9)
                         count9++;
                     }
                 }
                 if(count0>=1 && count1>=1 && count2>=1 && count3>=1 && count4>=1 && count5>=1 && count6>=1 && count7>=1 && count8>=1 && count9>=1)
                 {
                     flag=1;
                     printf("Case #%d: %d\n",caseCount,p);
                     break;
                 }
                 p = n*(++factorI);
             }
         }
     }
     return 0;
 }

