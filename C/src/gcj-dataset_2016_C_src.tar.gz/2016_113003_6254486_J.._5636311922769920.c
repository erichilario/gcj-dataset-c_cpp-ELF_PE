#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 #include<string.h>
 
 int main()
 {//freopen("D-small-attempt0.in","r",stdin);
  //freopen("D-small-attempt0.out","w",stdout);
     
  int T,K,C,S,i,j;
  
  
  scanf("%d",&T);
  for(i=1;i<=T;i++)
     {scanf("%d %d %d",&K,&C,&S);
      printf("Case #%d:",i);
      for(j=1;j<=S;j++)
         printf(" %d",j);
      printf("\n");   
     }   
 
 
 return 0;
 }

