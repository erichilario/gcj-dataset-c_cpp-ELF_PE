#include<stdio.h>
 #include <stdlib.h>
 main(){
 int T,c,b[100]={0};
 FILE *f;
 FILE *i;
 f = fopen ("output_file.txt", "w");
 i = fopen ("A-small-attempt0.in", "r");
 fscanf(i, "%d",&T);
 //scanf("%d",&T);
 if(T>100 || T<0){
 
     exit(1);
 }
 else{
 for(c=0;c<T;c++)
 {
     //rewind(i);
    fscanf(i, "%d",&b[c]);
 
 //scanf("%d",&b[c]);
 }
 for(c=0;c<T;c++)
 {
 
     int i,numbersCount=0,num,j,k,g=2,N;
     int a[1000]={0},d[10]={0};
 
     N=b[c];
     num=N;
     while(num!=0)
     {
         a[numbersCount]=num%10;
         num /= 10;
         numbersCount++;
     }
 
 
     j= numbersCount;
 
     for(i=0;i<j;i++){k=a[i]; d[k]=1;}
 
 
     while(1){
     int p=c+1;
         if(g==1000){printf("Case #%d: INSOMNIA\n",p);
         fprintf(f,"Case #%d: INSOMNIA\n",p);
     break;}
         if(d[0]==1 && d[1]==1 && d[2]==1 && d[3]==1 && d[4]==1 && d[5]==1 && d[6]==1 && d[7]==1 && d[8]==1 && d[9]==1){break;}
 
         num=N*g;
         numbersCount=0;
          while(num!=0)
     {
         a[numbersCount]=num%10;
         num /= 10;
         numbersCount++;
     }
 
      j= numbersCount;
     for(i=0;i<j;i++){k=a[i]; d[k]=1;}
     g=g+1;
 
     }
     if(N==0){
    continue;}
    g=g-1;
   N=N*g;
     int p=c+1;
 printf("Case #%d : %d\n",p,N);
 fprintf(f,"Case #%d: %d\n",p,N);
     }
 }
 fclose(f);
 fclose(i);
 }

