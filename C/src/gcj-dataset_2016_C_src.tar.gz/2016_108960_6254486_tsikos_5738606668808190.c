//
 //  main.c
 //  Code Jam
 //
 //  Created by Konstantinos Mitropoulos on 9/4/2016.
 //  Copyright (c) 2016 NTUA. All rights reserved.
 //
 
 #include <stdio.h>
 #include <math.h>
 
 long long int IsPrime(long long int number) {
     if (number <= 1) return 0; // zero and one are not prime
     long long int i;
     for (i=2; i*i<=number; i++) {
         if (number % i == 0)
             return i;
     }
     return -1;
 }
 
 long long int ConvNumToDec(long long int base, long long int binary) {
     long long decimal = 0, count = 0, temp = binary;
     
     while (temp != 0) {
         temp = temp/10;
         count++;
     }
     count--;
     
     while (count != -1) {
         temp = binary/pow(10, count);
         temp = temp % 10;
         if (temp == 1) decimal = decimal + pow(base, count);
         count--;
     }
     
     return decimal;
 }
 
 
 long long int ConvDecToBin(long long int decimalNumber){
     
     long long int remainder,quotient;
     
     long long int binaryNumber[100],i=1,j;
     
     
     //printf("Enter any decimal number: ");
     
     
     
     
     quotient = decimalNumber;
     
     
     while(quotient!=0){
         
         binaryNumber[i++]= quotient % 2;
         
         quotient = quotient / 2;
         
     }
     
     
     //printf("Equivalent binary value of decimal number %d: ",decimalNumber);
     long long int sum = 0;
     for(j = i -1 ;j> 0;j--)
         sum = sum + (binaryNumber[j]*pow(10, j - 1));
        // printf("%d",binaryNumber[j]);
     
     
     return sum;
     
 }
 
 
 
 int main(int argc, const char * argv[]) {
 
     FILE *fp;
     fp = fopen ("/Users/konstantinos/Desktop/B-small-attempt0.in.txt", "r");
     
     int T, N, J;
     fscanf(stdin, "%d", &T);
     fscanf(stdin, "%d", &N);
     fscanf(stdin, "%d", &J);
     
     fprintf(stdout, "Case #1:\n");
     long long int count = 0;
     long long int i, j, Binary = 1*pow(10, N-1) + 1;
 
     long long int Decimal = ConvNumToDec(2, Binary);
 
     while (1 == 1) {
         
         
         for (i = 2; i < 11; i++) {
             long long int temp  = ConvNumToDec(i, Binary);
             long long int temp2 = IsPrime(temp);
             if (temp2 == -1) break;
             
             if (i == 10) {
                 count++;
                 fprintf(stdout, "%lld", Binary);
                 for (j = 2; j < 11; j++) {
                     long long int temp3  = ConvNumToDec(j, Binary);
                     long long int temp4 = IsPrime(temp3);
                     if (j == 10) {
                         fprintf(stdout, " %lld\n", temp4);
                         continue;
                     }
                     fprintf(stdout, " %lld", temp4);
 
                 }
                 if (count == 50) return 0;
             }
         }
        
         Decimal = Decimal + 2;
         Binary = ConvDecToBin(Decimal);
         if (Binary == 10000000000000001) break;
         }
     
    // i = ConvDecToBin(163);
     
     
     fclose(fp);
     return 0;
 }

