#include <stdio.h>
 
 
 int main() {
 	int n = 16, k = 10 * 1000;
 	int arr[n];
 	int total = 50;
 
 	for (int i = 0; i < n; i++) {
 		arr[i] = 0;
 	}
 
 	arr[0] = 1; //Min value
 	arr[n - 1] = 1; //max value
 
 	printf("Case #1:\n");
 
 
 	int rest[k];
 	int result[10];
 
 	while (1) {
 		int idx = 1;
 		while (idx < n && arr[idx] != 0) {
 			arr[idx] = 0;
 			idx++;
 		}	
 
 		if (idx == n) {
 			printf("All ones, we are done!\n");
 			return 1;
 		}
 		arr[idx] = 1;
 
 		
 		for (int i = 0; i < k; i++) {
 			rest[i] = 0;
 		}
 
 
 		for (int i = n - 1; i >= 0; i--) {
 			for (int j = 0; j < k; j++) {
 				int base = (j % 10) + 1;
 				int devider = j / 10 + 2;
 				rest[j] = ((rest[j] * base) + arr[i]) % devider;
 			}
 		}
 
 		int match = 1;
 		//We are only intrested in 2 --> 10
 		for (int i = 1; i < 10; i++) {
 			int j = i;
 
 			while (j < k && rest[j] != 0) {
 				j += 10;
 			}
 
 			if (j < k) {
 				result[i] = j / 10 + 2;				
 			} else {
 				match = 0;
 			}
 		}
 
 		if (match == 1) {
 			for (int i = n - 1; i >= 0; i--) {
 				printf ("%d", arr[i]);
 			}
 
 			printf (" ");
 
 			for (int i = 1; i < 10; i++) {
 				if (i != 9) {
 					printf ("%d ", result[i]);
 				} else {
 					printf ("%d\n", result[i]);	
 				}
 			}
 
 			total--;
 			if (total == 0) {
 				return 1;
 			}
 		}
 	}
 
 	return 0;
 }
