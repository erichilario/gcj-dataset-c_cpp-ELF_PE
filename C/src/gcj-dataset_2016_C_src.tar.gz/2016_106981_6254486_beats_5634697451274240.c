#include <stdio.h>
 #include <string.h>
 
 unsigned int getFlips(char *input, int len);
 
 int main()
 {
 	int i, testCases, len;
 	unsigned int res;
 	char input[101];
 
 	scanf("%d", &testCases);
 
 	for(i = 1; i <= testCases; i++)
 	{
 		scanf("%s", input);
 		len = strlen(input);
 
 		res = getFlips(input, len);
 
 		printf("Case #%d: %u\n", i, res);
 	}
 
 	return 0;
 }
 
 unsigned int getFlips(char *input, int len)
 {
 	int i, minus, plus;
 	unsigned int count = 0;
 	char c;
 
 	minus = 0;
 	plus = 0;
 
 	for(i = 0; i < len; i++)
 	{
 		c = input[i];
 
 		if(minus == 0 && plus == 0 && c == '-')
 		{
 			minus = 1;
 			plus = 0;
 			count++;
 		}
 		else if(minus == 1 && c == '+')
 		{
 			minus = 0;
 			plus = 1;
 		}
 		else if(minus == 0 && plus == 1 && c == '-')
 		{
 			minus = 1;
 			plus = 0;
 			count += 2;
 		}
 		else if(plus == 0 && minus == 0 && c == '+')
 		{
 			minus = 0;
 			plus = 1;
 		}
 	}
 
 	return count;
 }
 

