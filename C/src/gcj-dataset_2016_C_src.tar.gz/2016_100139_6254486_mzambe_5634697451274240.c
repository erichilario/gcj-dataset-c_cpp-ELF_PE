/*
  * =====================================================================================
  *
  *       Filename:  foo.c
  *
  *    Description:  
  *
  *        Version:  1.0
  *        Created:  04/09/2016 04:47:23 PM
  *       Revision:  none
  *       Compiler:  gcc
  *
  *         Author:  YOUR NAME (), 
  *   Organization:  
  *
  * =====================================================================================
  */
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 int main(){
   int i, j, k, l;
   int T, N, M;
   int count;
   char *s;
   char t;
   scanf("%d\n", &T);
 
   for( i = 1; i <= T; i++ ){
     scanf("%s\n", s);
     
     N = strlen(s);
     k = (s[N - 1] == '-');
     count = 0;
 
     for( j = 0, t = s[0]; j < N; j++ ){
       if( (s[j] != t) )
         count++;
       t = s[j];
     }
 
     count += k;
 
     printf("Case #%d: %d\n", i, count);
   }
 
   return 0;
 }
 

