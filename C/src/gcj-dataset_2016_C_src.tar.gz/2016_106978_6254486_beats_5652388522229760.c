#include <stdio.h>
 #include <limits.h>
 
 int check(int *done);
 void update(unsigned long num, int *done);
 unsigned long count(unsigned long num);
 
 int main()
 {
 	int i, testCases;
 	unsigned long num, res;
 
 	scanf("%d", &testCases);
 
 	for(i = 1; i <= testCases; i++)
 	{
 		scanf("%lu", &num);
 
 		res = count(num);
 
 		if(res == EOF)
 			printf("Case #%d: INSOMNIA\n", i);
 		else
 			printf("Case #%d: %lu\n", i, res);
 	}
 	
 	return 0;
 }
 
 unsigned long count(unsigned long num)
 {
 	int done[10];
 	int i;
 	unsigned long temp;
 
 	if(num == 0)
 		return EOF;
 
 	for(i = 0; i < 10; i++)
 		done[i] = 0;
 
 	temp = num;
 	for(i = 2; temp < ULONG_MAX; i++)
 	{
 		update(temp, done);
 
 		if(check(done))
 			return temp;
 
 		temp = i * num;
 	}
 
 	return EOF;
 }
 
 void update(unsigned long num, int *done)
 {
 	int d;
 
 	while(num)
 	{
 		d = num % 10;
 		num = num / 10;
 		done[d] = 1;
 	}
 }
 
 int check(int *done)
 {
 	int i;
 
 	for(i = 0; i < 10; i++)
 	{
 		if(done[i] == 0)
 			return 0;
 	}
 
 	return 1;
 }
 
 

