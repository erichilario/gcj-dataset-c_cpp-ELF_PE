#include<stdio.h>
 
 int a[1000000],ind=0,number[10];
 static int turn=0;
 void split_number(int,int);
 int search_number(int *,int);
 int main()
 {
  unsigned long int T,N,i,j;
  FILE *fp1,*fp2;
 
  fp1=fopen("OUTPUT_FILE1","w");
  fp2=fopen("INPUT_FILE1","r");
  fscanf(fp2,"%d",&T);
  for(i=0;i<T;i++)
  {
   fscanf(fp2,"%d",&a[i]);
  }
 
  for(i=0;i<T;i++)
  {
    if(a[i]==0)
     fprintf(fp1,"\nCase #%d: INSOMNIA",i+1);
    else
    {
     turn=1;
     ind=0;
     for(j=0;j<10;j++)
        number[j]=-1;
     split_number(turn*a[i],i);
     fprintf(fp1,"\nCase #%d: %d",i+1,turn*a[i]);
    }
  }
  fclose(fp1);
  fclose(fp2);
  return 0;
 }
 
 void split_number(int x,int y)
 {
  int num,j;
 
  if((x>0)&&(ind<10))
  {
 
   while(x>0)
   {
    num=x%10;
    if(search_number(number,num))
      number[ind++]=num;
    x/=10;
   }
 
   if(ind<10)
   {
     turn++;
     split_number(turn*a[y],y);
   }
  }
 }
 
 int search_number(int *arr,int num)
 {
  int ai=0;
  for(ai=0;ai<=9;ai++)
   if(*(arr+ai)==num)
      return 0;
  return 1;
 }

