#include <stdio.h>
 int main()
 {
     int test, i;
     scanf("%d", &test);
     for(i=0; i<test; i++)
     {
         int a[10] = {0,0,0,0,0,0,0,0,0,0};
         long long int n; 
         int k, j = 1, flag;
         scanf("%d", &n);
         long long int temp = n;
         printf("\nCase #%d: ",i+1);
         while(1)
         {
             temp = j * n;
             long long int result = temp;
             flag = 1;
             while(temp>0)
             {
                 int num = temp % 10;
                 a[num]++;
                 temp = temp/10;
             }
             for(k=0; k<10; k++)
             {
                 if(a[k]==0)
                 {
                     flag = 0;
                     break;
                 }
             }
             if(temp == n && j>1)
             {
                 printf("Insomnia");
                 break;
             }
             if(flag == 1)
             {
                 printf("%d",result);
                 break;
             }
             j++;
         }
     }
     return 0;
 }

