#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define INPUT_FILE "B-small-attempt0.in"
 #define OUTPUT_FILE "output"
 
 
 int main()
 {
     FILE *fp_in, *fp_out;
 
     int T, pancake, times, reverse;
     char S[10+1];
 
     int i,j;
 
     fp_in=fopen(INPUT_FILE,"r");
     fp_out=fopen(OUTPUT_FILE,"w");
 
     fscanf(fp_in,"%d",&T);
 
     for(i=0;i<T;i++)
     {
         times=0;
         reverse=0;
 
         fscanf(fp_in,"%s",S);
         pancake=strlen(S);
 
         while(pancake)
         {
             if(S[pancake-1]=='-')
             {
                 for(j=0;j<pancake;j++)
                 {
                     if(S[j]=='-')
                         S[j]='+';
                     else
                         S[j]='-';
                 }
                 times++;
             }
             pancake--;
         }
         fprintf(fp_out,"Case #%d: %d\n",i+1,times);
     }
     fclose(fp_in);
     fclose(fp_out);
 
     exit(EXIT_SUCCESS);
 }

