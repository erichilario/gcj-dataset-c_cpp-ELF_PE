#include<stdio.h>
 int result(int a);
 int check(int c[]);
 
 int main()
 {
 	int t,n[100],i,c[9]={0};
 	
 	scanf("%d",&t);
 	if(t>=1 && t<=100)
 	{
 		
 		
 	for(i=0;i<t;i++)	
 		scanf("%d",&n[i]);
 		
 		
 	for(i=0;i<t;i++)
 	{
 			
 		if(result(n[i])==0)
 		
 		printf("\nCASE #%d: INSOMNIA",i+1);
 	else
 	
 
 	printf("\nCASE #%d: %d",i+1,result(n[i]));
 
 	}
 }
 	
 	return 0;
 }
 int result(int d)
 {int k=1;
 int c,b,i,a[10];
 
 for(i=0;i<=10;i++)
 a[i]=0;
 
 if(d==(d*2))
 return 0;
 
 do
 { 
 b=d*k;
 
 while(b!=0)
 { 
 c=b%10;
 a[c]=a[c]+1;
 b=b/10;	
 
 	}	
 	
 	
 
 k++;	
 
 	
 }while(check(a)!=1);
 
 return d*(k-1);
 
 
 
 
 }
 int check(int c[9])
 {
 int i;
 
 i=0;
 	while(c[i]!=0 && i<10){
 		i++;
 	}
 	if(i==10)
 	return 1;
 	else
 	return 0;
 }

