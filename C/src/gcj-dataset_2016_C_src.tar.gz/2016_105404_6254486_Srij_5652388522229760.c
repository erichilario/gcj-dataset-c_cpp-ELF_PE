#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 long long scanNo(long long N);
 int array[10];
 
 int main(){
 	int T;
 	int tn = 1;
 	long long N;
 	scanf("%d", &T);
 	while(tn <= T){
 		scanf("%lld", &N);
 		if(N == 0){
 			printf("Case #%d: INSOMNIA\n", tn);
 			tn++;
 			continue;
 		}
 		int i = 1;
 		memset((array), 0, sizeof(array));
 		long long answer = 0;
 		while(i <= 100){
 			answer = scanNo(N * i);
 			if(answer != 0){
 				break;
 			}
 			i++;
 		}
 
 		printf("Case #%d: %lld\n", tn, answer);
 		tn++;
 	}
 	return 0;
 }
 
 long long scanNo(long long N){
 	long long orignal = N;
 	int digit;
 
 	while( N != 0 ){
 		digit = N % 10;
 		array[digit] = 1;
 		N = N/10;
 	}
 
 	int flag = 1;
 	int index;
 	for(index = 0; index < 10; index++){
 		if(array[index] == 0)
 			flag = 0;
 	}
 	if(flag == 0)
 		return 0;
 	else{
 		return orignal;
 	}
 }
