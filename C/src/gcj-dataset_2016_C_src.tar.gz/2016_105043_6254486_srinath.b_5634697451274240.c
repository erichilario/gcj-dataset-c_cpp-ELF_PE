#include<stdio.h>
 #include<string.h>
 
 int main() {
 	int t,t1,i,count;
 	char s[105];
 	scanf("%d",&t);
 	t1=t;
 	while(t--) {
 		scanf("%s",s);
 		count=0;
 		for(i=0;i<strlen(s)-1;i++)
 			if(s[i]=='+' && s[i+1]=='-')
 				count+=2;
 		if(s[0]=='-')
 			count++;
 		printf("Case #%d: %d\n",t1-t,count);
 	}
 	return 0;
 }
