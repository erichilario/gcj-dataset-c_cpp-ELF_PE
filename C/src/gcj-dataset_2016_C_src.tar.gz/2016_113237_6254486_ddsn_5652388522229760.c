#include <stdio.h>
 #include <stdint.h>
 #include <memory.h>
 
 #define MAX_KETA (7 * 100)
 
 void initUint8Array(uint8_t array[], const uint32_t len)
 {
     memset(array, 0, sizeof(uint8_t) * len);
 }
 
 uint32_t strToUint8Array(uint8_t dstArray[], const char src[], const uint32_t keta)
 {
     const uint32_t len = strlen(src);
     uint32_t i;
 
     for (i = 0; i < len; i++) {
         dstArray[i] = src[len - i - 1] - '0';
     }
 
     for (; i < keta; i++) {
         dstArray[i] = 0;
     }
 
     return len;
 }
 
 uint32_t getKeta(uint32_t val)
 {
     uint32_t keta = 0;
 
     while (val) {
         keta++;
         val /= 10;
     }
 
     return keta;
 }
 
 uint32_t mulVal(uint8_t arr[], const uint32_t len, const uint32_t val)
 {
     uint32_t carry = 0;
     uint32_t i;
 
     for (i = 0; i < len; i++) {
         uint32_t digit = arr[i];
         digit = digit * val + carry;
         arr[i] = digit % 10;
         carry = digit / 10;
     }
 
     if (carry) {
         arr[i] = carry;
         // printf("finalize\n");
         // printf("carry=%u\n", carry);
         // printf("keta=%u\n", getKeta(carry));
         return len + getKeta(carry);
     }
 
     return len;
 }
 
 uint8_t getProgress(uint8_t flag[10])
 {
     uint8_t i;
     uint8_t ans = 0;
     for (i = 0; i < 10; i++) {
         ans += flag[i];
     }
     return ans;
 }
 
 int main(void)
 {
     uint32_t T;
     char N[7+1];
     uint8_t numArr[MAX_KETA];
     uint32_t t, m, i;
     uint32_t len;
     uint8_t flag[10];
 
     /* input number of test cases */
     scanf("%u", &T);
     
     for (t = 0; t < T; t++) {
         /* init */
         initUint8Array(flag, 10);
         initUint8Array(numArr, MAX_KETA);
 
         /* input N */
         scanf("%s", N);
 
         /* name sheeps */
         printf("Case #%u: ", t+1);
         for (m = 1; ; m++) {
             const uint8_t prevProgress = getProgress(flag);
             uint8_t progress;
 
             /* create uint8_t array */
             len = strToUint8Array(numArr, N, MAX_KETA);
             len = mulVal(numArr, len, m);
 
             /* check digit and update flag */
             for (i = len; i > 0; i--) {
                 const uint32_t idx = i - 1;
                 // printf("%u", numArr[idx]);
                 flag[numArr[idx]] = 1;
             }
             // putchar('\n');
 
             /* finished? */
             progress = getProgress(flag);
             if (prevProgress == progress && flag[1] == 0) {
                 printf("INSOMNIA\n");
                 break;
             }
             if (progress == 10) {
                 for (i = len; i > 0; i--) {
                     const uint32_t idx = i - 1;
                     printf("%u", numArr[idx]);
                 }
                 putchar('\n');
                 break;
             }
         }
     }
     return 0;
 }
 

