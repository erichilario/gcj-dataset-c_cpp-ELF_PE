#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 #define BUFSIZE (1024)
 char    buf[BUFSIZE];
 
 #define PRIMEBUFMAX     (40000)
 
 int     primenummax = 0;
 unsigned long primemax = 0;
 unsigned long primelist[PRIMEBUFMAX];
 
 void
 setprime(char* fn)
 {
     FILE*       fp;
     char        pb[BUFSIZE];
 
     if ((fp = fopen(fn, "r")) == NULL) {
         perror(fn);
         exit(1);
     }
     primenummax = 0;
     unsigned long*      ppl;
     ppl = primelist;
     while ((primenummax < PRIMEBUFMAX) && fgets(pb, BUFSIZE, fp) != NULL) {
         primemax = atol(pb);
         *ppl = primemax;
         ppl++;
         primenummax++;
 //        printf("%ld\n", primemax);
     }
 //    printf("%d\n", primenummax);
     fclose(fp);
 }
 
 int
 main(int argc, char** argv)
 {
     int         base;
     int         ai;
     char*       pdigit;
     int         buflen;
     unsigned long       num;
     unsigned long       ntd;
     unsigned long       ntdmax;
 //    unsigned long       rem;
     
     ai = 1;
 
     base = atoi(argv[ai]);
     ai++;
     setprime(argv[ai]);
     ai++;
     //printf("base = %d\n", base);
     while (fgets(buf, BUFSIZE, stdin) != NULL) {
         pdigit = buf;
         num = 0;
         while ((*pdigit == '1') || (*pdigit == '0')) {
             num *= base;
             num += ((*pdigit == '1') ? 1 : 0);
 //            printf("%d %ld\n", *pdigit, num);
             pdigit++;
         }
         buflen = strlen(buf);
         buf[buflen - 1] = 0;
 
 #if 0
         printf("%s %lu \n", buf, num);
 #else
 #if 1
         unsigned long*      ppl;
         ppl = primelist;
         for (int idx = 0; idx < primenummax; idx++) {
             ntd = *ppl;
 //            printf("ntd = %ld\n", ntd); 
             if ((num / 2) < ntd) {
                 break;
             }
             if ((num % ntd) == 0) {
                 printf("%s %lu \n", buf, ntd);
                 break;
             }
             ppl++;
         }
 
 #else
         if ((num % 2) == 0) {
             printf("%s 2 \n", buf);
         } else {
             ntdmax = num / 2;
             for (ntd = 3; ntd < ntdmax; ntd += 2) {
                 if ((num % ntd) == 0) {
                     printf("%s %lu \n", buf, ntd);
                     break;
                 }
             }
         }
 #endif
         fflush(stdout);
 #endif
     }
 }

