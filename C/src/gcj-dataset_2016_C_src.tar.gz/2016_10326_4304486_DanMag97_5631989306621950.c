#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 void shiftRight(char lastWord[], int length);
 
 int main(void) {
 	FILE * input;
 	input = fopen("A-large.in", "r");	//A-small-attempt1.in
 	FILE * output;
 	output = fopen("output.txt", "w");
 
 	int no_of_inputs;
 	fscanf(input, "%d", &no_of_inputs);
 
 	int i, j;
 	for(i=0; i<no_of_inputs; i++){
 		char S[1000];
 		char lastWord[1000];
 
 		fscanf(input, "%s", &S);
 
 		int letters = strlen(S);
 		lastWord[0] = S[0];
 		for(j=1; j<letters; j++){
 			if(S[j] < lastWord[0]){
 				lastWord[j] = S[j];
 			}
 			else{
 				lastWord[j] = '\0';
 				shiftRight(lastWord, j);
 				lastWord[0] = S[j];
 			}
 		}
 		lastWord[j] = '\0';
 		fprintf(output, "Case #%d: %s\n", (i+1), lastWord);
 	}
 
 	fclose(input);
 	fclose(output);
 
 	return 0;
 }
 
 void shiftRight(char lastWord[], int length){
 	int i;
 	for(i=0; i<length; i++){
 		lastWord[length-i] = lastWord[length-(1+i)];
 	}
 }

