#include <stdio.h>
 
 int main(void)
 {
 	int a[]={0,0,0,0,0,0,0,0,0,0};
 	int t,b,n;
 	scanf("%d",&t);
 	for(int i=1;i<=t;i++)
 	{
 		scanf("%d",&n);
 		int k=1;
 		if(n==0)
 		printf("Case #%d: INSOMNIA\n",i);
 		while(n!=0)
 		{
 			 b=n*k++;
 				
 
 		while(b>0)
 		{
 			a[b%10]=i;
 			b/=10;
 			
 		}
 		
 		if(a[0]+a[1]+a[2]+a[3]+a[4]+a[5]+a[6]+a[7]+a[8]+a[9]==i*10)
 	{	printf("Case #%d: %d\n",i,n*(--k));
 		break;}
 		}
 		
 	}
 	return 0;
 }

