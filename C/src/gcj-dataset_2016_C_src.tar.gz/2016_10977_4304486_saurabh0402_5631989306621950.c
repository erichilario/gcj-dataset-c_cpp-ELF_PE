#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 struct node {
 	char info;
 	struct node * next;
 };
 
 struct node *insertBefore(struct node *start, char data){
 	struct node *temp = (struct node *)malloc(sizeof(struct node));
 
 	temp->info = data;
 	temp->next = start;
 	start = temp;
 	return start;
 }
 
 struct node *insertAtLast(struct node *start, char data){
 	struct node *temp = (struct node *)malloc(sizeof(struct node));
 
 	struct node *p = start;
 
 	while(p->next != NULL)
 		p = p->next;
 
 	temp->info = data;
 	temp->next = NULL;
 	p->next = temp;
 	return start;
 }
 
 struct node *traverse(struct node *start){
 	while(start != NULL){
 		printf("%c", start->info);
 		start = start->next;
 	}
 	printf("\n");
 }
  
 int main(){
 	int n, x = 0, len;
 	scanf("%d", &n);
 	while(x < n){
 		char str[1001];
 		struct node *start = (struct node *)malloc(sizeof(struct node));
 		scanf("%s", str);
 		len = strlen(str);
 		int i = 0;
 		char temp = 0; 
 		while(i < len){
 			if(str[i] >= temp){
 				start = insertBefore(start, str[i]);
 				temp = str[i];
 			}
 			else {
 				start = insertAtLast(start, str[i]);
 			}
 			i++;
 		}
 		printf("Case #%d: ", x+1);
 		traverse(start);
 		x++;
 	}
 	return 0;
 }

