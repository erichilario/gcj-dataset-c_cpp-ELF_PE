#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <stdint.h>
 #include <math.h>
 #include <inttypes.h>
 #define __STDC_FORMAT_MACROS
 int t, K,C,S;
 int main()
 {
     scanf("%d", &t);
     for (int i = 0; i < t; i++)
     {
         scanf("%d %d %d", &K, &C, &S);
         printf("Case #%d: ", i+1);
         if(K == 1)
         {
             printf("1\n");
             continue;
         }
         if (C == 1)
         {
             if (S < K)
                 printf("IMPOSSIBLE\n");
 
             else
             {
                 for (int j = 1; j <= K; j++)
                     printf("%d ", j);
 
                 printf("\n");
             }
         }
 
         else
         {
             if (S < K-1)
             {
                 printf("IMPOSSIBLE\n");
                 continue;
             }
 
             else
             {
                 for (int j = 2; j <= K; j++)
                     printf("%d ", j);
 
                 printf("\n");
             }
         }
 
     }
     return 0;
 }

