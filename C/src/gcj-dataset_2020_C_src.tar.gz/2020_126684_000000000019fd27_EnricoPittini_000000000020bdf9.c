#include<stdio.h>
#include<stdlib.h>

typedef struct{
	int start;
	int end;
  int index;
  char person;
} Intervallo;

void stampa(Intervallo v[],int dim){
    int i;
    for(i=0;i<dim;i++)
      printf("(%d,%d) ",v[i].start,v[i].end);
    printf("\n");
}
void merge(Intervallo v[],int inf,int med,int sup){
		int i,j,k;
		int n1=med-inf+1;
		int n2=sup-med;
		Intervallo *L=(Intervallo *)malloc(sizeof(Intervallo)*n1);
		Intervallo *R=(Intervallo *)malloc(sizeof(Intervallo)*n2);
		for(i=0;i<n1;i++)
				L[i]=v[inf+i];
		for(j=0;j<n2;j++)
				R[j]=v[med+j+1];
		i=j=0;
		k=inf;
		while(i<n1 && j<n2){
				if(L[i].start<=R[j].start){
						v[k]=L[i];
						i++;
						k++;
				}
				else{
						v[k]=R[j];
						j++;
						k++;
				}
		}
		while(i<n1){
				v[k]=L[i];
				i++;
				k++;
		}
		while(j<n2){
				v[k]=R[j];
				j++;
				k++;
		}
		free(L);
		free(R);
}

void mergesort(Intervallo v[], int inf, int sup){
	int med;
	if(inf<sup){
			med=(inf+sup)/2;
			mergesort(v,inf,med);
			mergesort(v,med+1,sup);
			merge(v,inf,med,sup);
	}
}
void mergeIndex(Intervallo v[],int inf,int med,int sup){
		int i,j,k;
		int n1=med-inf+1;
		int n2=sup-med;
		Intervallo *L=(Intervallo *)malloc(sizeof(Intervallo)*n1);
		Intervallo *R=(Intervallo *)malloc(sizeof(Intervallo)*n2);
		for(i=0;i<n1;i++)
				L[i]=v[inf+i];
		for(j=0;j<n2;j++)
				R[j]=v[med+j+1];
		i=j=0;
		k=inf;
		while(i<n1 && j<n2){
				if(L[i].index<=R[j].index){
						v[k]=L[i];
						i++;
						k++;
				}
				else{
						v[k]=R[j];
						j++;
						k++;
				}
		}
		while(i<n1){
				v[k]=L[i];
				i++;
				k++;
		}
		while(j<n2){
				v[k]=R[j];
				j++;
				k++;
		}
		free(L);
		free(R);
}

void mergesortIndex(Intervallo v[], int inf, int sup){
	int med;
	if(inf<sup){
			med=(inf+sup)/2;
			mergesortIndex(v,inf,med);
			mergesortIndex(v,med+1,sup);
			mergeIndex(v,inf,med,sup);
	}
}

char *compute(Intervallo activity[],int N,int *errOut){
    Intervallo cameron,jamie;
    int i,err=0;
    char *res=(char *)malloc(sizeof(char)*(N+1));
    mergesort(activity,0,N-1);
    stampa(activity,N);
    activity[0].person='C';
    cameron=activity[0];
    activity[1].person='J';
    jamie=activity[1];
    i=2;
    while(i<N && !err){
        if(activity[i].start<cameron.end && activity[i].start<jamie.end)
          err=1;
        else if(activity[i].start>=cameron.end){
            activity[i].person='C';
            cameron=activity[i];
            i++;
        }
        else{
            activity[i].person='J';
            jamie=activity[i];
            i++;
        }
    }
    *errOut=err;
    if(err){
        free(res);
        return "IMPOSSIBLE";
    }
    else{
        mergesortIndex(activity,0,N-1);
        stampa(activity,N);
        for(i=0;i<N;i++)
          res[i]=activity[i].person;
        res[i]='\0';
        return res;
    }
}

int main(){
    int T,N;
    Intervallo *activity;
    int i,j;
    scanf("%d",&T);
    for(i=1;i<=T;i++){
        char *s;
        int err;
        scanf("%d",&N);
        activity=(Intervallo *)malloc(sizeof(Intervallo)*N);
        for(j=0;j<N;j++){
            scanf("%d",&(activity[j].start));
            scanf("%d",&(activity[j].end));
            activity[j].index=j;
        }
        stampa(activity,N);
        s=compute(activity,N,&err);
        printf("Case #%d: %s\n",i,s);
        free(activity);
        if(!err)
          free(s);
    }
    return 0;
}

