#include <stdio.h>
#include <stdlib.h>

int main(){
	int t;
	scanf("%d",&t);
	for (int m = 1; m <= t; ++m)
	{
		int n;
		scanf("%d",&n);
		int mat[n][n];
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
			{
				scanf("%d",&mat[i][j]);
			}
		}
		int n_row = 0;
		int n_col = 0;
		int trace = 0;
		for (int i = 0; i < n; ++i)
		{
			trace += mat[i][i];
		}
		for (int i = 0; i < n; ++i)
		{
			int arr_row[n];
			int arr_col[n];
			for (int j = 0; j < n; ++j)
			{
				arr_row[j] = 0;
				arr_col[j] = 0;
			}
			for (int j = 0; j < n; ++j)
			{
				arr_row[mat[i][j]-1]++;
				arr_col[mat[j][i]-1]++;
			}
			int flag_row = 1;
			int flag_col = 1;
			for (int j = 0; j < n; ++j)
			{
				if(flag_row && arr_row[j]==0){
					flag_row = 0;
					n_row ++;
				}
				if(flag_col && arr_col[j] == 0){
					flag_col = 0;
					n_col++;
				}
			}
		}
		printf("Case #%d: %d %d %d\n",m,trace,n_row,n_col);
	}
}
