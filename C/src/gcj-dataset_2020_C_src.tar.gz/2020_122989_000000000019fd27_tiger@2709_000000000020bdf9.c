#include <stdio.h>
#include <stdlib.h>
#define N 1000
void mergesort(int left,int right);
void merge(int ,int ,int );
int assignJob(int jobNo,int freec,int freej);
void initJob();

int tasks[N][2],job[N];
char str[N+1]={'\0'};
char out[N+1]={'\0'};
int n;
int main()
{
    int i,k=0,test_cases;
    scanf("%d",&test_cases);
    while(k<test_cases)
    {
        k++;
        scanf("%d",&n);
        
        initJob();
        for(i=0;i<n;i++)
        {
            scanf("%d %d",&tasks[i][0],&tasks[i][1]);
        }
        mergesort(0,n-1);
        i=assignJob(0,0,0);
        if(!i)
        {
            for(i=0;i<n;i++)
                out[job[i]]=str[i];
            out[n]='\0';
            printf("Case #%d: %s\n",k,out);
        }
        else
            printf("Case #%d: IMPOSSIBLE\n",k);
    }
    return 0;
}
int assignJob(int jobNo,int freec,int freej)
{
    int result=1;
    if(jobNo==n)
    {
        return 0;
    }
    else
    {
        if(freec<=tasks[job[jobNo]][0])
        {
            str[jobNo]='C';
            result=assignJob(jobNo+1,tasks[job[jobNo]][1],freej);
        }
        if(freej<=tasks[job[jobNo]][0] && result==1)
        {
            str[jobNo]='J';
            result=assignJob(jobNo+1,freec,tasks[job[jobNo]][1]);
        }
        return result;
    }
}

void initJob()
{
    for(int i=0;i<1000;i++)
    {
        job[i]=i;
    }
}

void mergesort(int left,int right)
{
	int mid=(left+right)/2;

	if(left<right)
	{
		mergesort(left,mid);
		mergesort(mid+1,right);
		merge(left,mid,right);
	}
}

void merge(int l,int mid,int r)
{
	int n1,n2,i=0,j=0,k;
	n1=mid-l+1;
	n2=r-mid;

	int arr1[n1],arr2[n2];

	k=l;
	while(i<n1)
		arr1[i++]=job[k++];
	while(j<n2)
        arr2[j++]=job[k++];
	k=l;
	i=j=0;

	while(i<n1 && j<n2)
	{
		if(tasks[arr1[i]][0]<=tasks[arr2[j]][0])
			job[k++]=arr1[i++];
		else
			job[k++]=arr2[j++];
	}

	while(i<n1)
		job[k++]=arr1[i++];

	while(j<n2)
		job[k++]=arr2[j++];
}

