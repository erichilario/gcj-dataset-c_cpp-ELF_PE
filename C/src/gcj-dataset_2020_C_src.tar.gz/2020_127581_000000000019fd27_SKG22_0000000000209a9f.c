#include<stdio.h>
#include<stdlib.h>
int main()
{
	int testCase,x=1;
	//printf("Enter no of test cases :");
	scanf("%d",&testCase);
	while(testCase)
	{
		char str[100];
		scanf("%s",str);
		int i=0,k=0;
		printf("Case #%d: ",x);
		while(str[i]!='\0')
		{
			int temp=(int)str[i]-48;
			if(temp==0)
			{
				while(k!=0)
				{
					printf(")");
					k--;
				}
			}
			if(k<temp)
			{
				while(k!=temp)
				{
					printf("(");
					k++;
				}
				printf("%d",temp);
			}
			else if(k>temp)
			{
				while(k!=temp)
				{
					printf(")");
					k--;
				}
				printf("%d",temp);
			}
			else
				printf("%d",temp);
			i++;
		}
		while(k!=0)
		{
			printf(")");
			k--;
		}
		printf("\n");
		x++;
		testCase--;
	}
	return 0;		
}
