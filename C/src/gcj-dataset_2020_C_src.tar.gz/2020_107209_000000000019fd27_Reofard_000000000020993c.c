#include<stdio.h>
int TestCase(int t, int n)
{
    int i,j;
    int sum=0, row=0, column=0;
    int rows[101];
    int columns[101];
    int metrix[100][100];
    
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&metrix[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)rows[j+1]=columns[j+1]=0;
        for(j=0;j<n;j++)
        {
            if(++rows[metrix[i][j]]==2)
            {
                row++;
                break;
            }
        }
        for(j=0;j<n;j++)
        {
            if(++columns[metrix[j][i]]==2)
            {
                column++;
                break;
            }
        }
        sum+=metrix[i][i];
    }
    printf("Case #%d: %d %d %d\n",t,sum,row,column);
}
int main()
{
    int t,n,i,j;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%d",&n);
        TestCase(i+1,n);
    }
}
