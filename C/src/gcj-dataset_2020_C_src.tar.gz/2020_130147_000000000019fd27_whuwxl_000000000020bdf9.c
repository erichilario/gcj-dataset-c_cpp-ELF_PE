#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Task {
    int start;
    int end;
    int index;
};

int comp(const void *a, const void *b)
{
    const struct Task *arg1 = (const struct Task *)a;
    const struct Task *arg2 = (const struct Task *)b;
    if (arg1->start < arg2->start) {
        return -1;
    } else if (arg1->start > arg2->start) {
        return 1;
    }
    if (arg1->end > arg2->end) {
        return -1;
    } else if (arg1->end < arg2->end) {
        return 1;
    }

    return 0;
}

int main(int argc, char *argv[])
{
    int t;
    scanf("%d", &t);
    for (int k = 1; k <= t; k++) {

        int n;
        scanf("%d", &n);
        struct Task a[n];

        for (int i = 0; i < n; i++) {
            scanf("%d %d", &a[i].start, &a[i].end);
            a[i].index = i;
        }

        qsort(a, n, sizeof(struct Task), comp);

        char result[1024];
        memset(result, 0, sizeof(result));

        struct Task c_task;
        c_task = a[0];
        result[c_task.index] = 'C';

        struct Task j_task;
        j_task.start = j_task.end = j_task.index = -1;

        for (int i = 1; i < n; i++) {
            if (a[i].start >= c_task.end) {
                c_task = a[i];
                result[c_task.index] = 'C';
            } else {
                if (j_task.index == -1) {
                    j_task = a[i];
                    result[j_task.index] = 'J';
                } else {
                    if (a[i].start >= j_task.end) {
                        j_task = a[i];
                        result[j_task.index] = 'J';
                    } else {
                        strcpy(result, "IMPOSSIBLE");
                        break;
                    }
                }
            }
        }

        printf("Case #%d: %s\n", k, result);
    }
    return 0;
}

