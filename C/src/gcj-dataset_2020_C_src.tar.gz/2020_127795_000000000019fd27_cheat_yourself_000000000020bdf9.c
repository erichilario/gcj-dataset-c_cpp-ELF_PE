#include<iostream>
#include<algorithm>
using namespace std;

struct node
{
    int s,e;
    bool oc;
    bool operator<(const node & a)
    {
        if(a.e>e)return true;
        return a.s>s;
    }
};

node sc[1000];

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int T,n,cases=0;
    cin>>T;
    while(T--)
    {
        int up[1441]={0},down[1441]={0},s,e;
        char res[1001];
        cin>> n;
        cout << "Case #"<<cases<<": ";
        for(int i=0;i<n;i++)
        {
            cin >> sc[i].s>>sc[i].e;
            sc[i].oc=true;
            up[sc[i].s]++;
            down[sc[i].e]--;
        }
        sort(sc,sc+n);
        int cnt=0,jt,ct,k=0;
        bool j=true,c=true;
        for(int i=0;i<=1440;i++)
        {
            cnt+=up[i]+down[i];
            if(cnt>2 || cnt<-2)
            {
                cout << "IMPOSSIBLE\n";
                k=0;
                break;
            }

            if(down[i]<0)
            {
//                cout << "i-jt" << i<< "-" <<jt<<endl;
//                cout << "i-ct" << i<< "-" <<ct<<endl;
                if(i>=jt)j=true,jt=0;
                if(i>=ct)c=true,ct=0;
            }

            if(up[i]>0)
            {
                if(j)
                {
                    res[k++]='J';
                    j=false;
                    for(int x=0;x<n;x++)
                    {
                        if(i==sc[x].s && sc[x].oc)
                        {
                            jt=sc[x].e;
                            sc[x].oc=false;
                            break;
                        }
                    }
                }
                else if(c)
                {
                    res[k++]='C';
                    c=false;
                    for(int x=0;x<n;x++)
                    {
                        if(i==sc[x].s && sc[x].oc)
                        {
                            ct=sc[x].e;
                            sc[x].oc=false;
                            break;
                        }
                    }
                }
            }
        }
        if(k==0)continue;
        res[k]='\0';
        cout << res<<endl;
    }

    return 0;
}

