#include<stdio.h>
#include<string.h>
#include<stdlib.h>

/*void stampa(char *S){
    int i;
    for(i=0;S[i]!='\0';i++)
      printf("%c",S[i]);

}*/
char *compute(char *S){
  int dimRes=2*strlen(S);
    char *res=(char *)malloc(sizeof(char)*(dimRes));
    int i,j=0;
    for(i=0;S[i]!='\0';i++){
        if(S[i]=='1' && (i==0 || S[i-1]=='0')){
            if(j+3>dimRes)
                res=realloc(res,sizeof(char)*2*dimRes);
            res[j]='(';
            res[j+1]='1';
            j=j+2;
        }
        else if(S[i]=='0' && i>0 && S[i-1]=='1'){
            if(j+3>dimRes)
                res=realloc(res,sizeof(char)*2*dimRes);
            res[j]=')';
            res[j+1]='0';
            j=j+2;
        }
        else{
          if(j+2>dimRes)
              res=realloc(res,sizeof(char)*2*dimRes);
          res[j]=S[i];
          j++;
        }
    }
    if(res[j-1]=='1'){
      if(j+2>dimRes)
          res=realloc(res,sizeof(char)*2*dimRes);
      res[j]=')';
      j++;
    }

    res[j]='\0';
    return res;

}
int main(){
      int T,i;
      char S[101];
      char *res;
      scanf("%d",&T);
      for(i=1;i<=T;i++){
          scanf("%s",S);
          res=compute(S),
          printf("Case #%d: %s\n",i,res);
          free(res);
      }
      return 0;
}

