#include<stdio.h>

int main()
{
	int T,_T;
	scanf("%d",&T);
	_T = T;
	while(T--)
	{
		int N,K,value,mod,i,j,impossible=0,V[51],data;
		scanf("%d %d", &N, &K);
		mod=K%N;
		value=(N*(N+1))/2;
		if((N==2)&&(K==3))
		{
			impossible=1;
		}
		else if(value==K)
		{
			impossible=0;
		}
		else if(mod==0)
		{
			impossible=0;
		}
		else
		{
			impossible=1;
		}
                printf("Case #%d: %s\n",_T-T , impossible?"IMPOSSIBLE":"POSSIBLE");
		if(impossible==1) continue;    
		if(value==K)
		{
                        for(i=0;i<N;i++)
                        {
                                for(j=0;j<N;j++)
                                {
                                        data = (j + i + 1)%N;
                                        if(data<0) data=0-data;
                                        printf("%d ",data?data:N);
                                }
                                printf("\n");
                        }
		}
		else
		{
			mod = K/N;
			for(i=0;i<N;i++)
			{
				for(j=0;j<N;j++)
				{
					data = (j + mod - i)%N;
					if(data<0) data=0-data;
					printf("%d ",data?data:N);
				}
				printf("\n");
			}
		}
	}
	return 0;
}


