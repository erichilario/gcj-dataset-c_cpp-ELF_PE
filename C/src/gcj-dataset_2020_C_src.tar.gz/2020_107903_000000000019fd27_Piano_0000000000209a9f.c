#include<stdio.h>

int main(){
    int t, u;
    char l[] = "(((((((((", r[] = ")))))))))";

    scanf("%d%*c", &t);
    for (u = 1; u <= t; ++u){
        char s[101];
        int i, last = 0;

        printf("Case #%d: ", u);
        gets(s);
        for (i = 0; s[i]; ++i){
            int now = s[i] - '0';
            if (now > last)
                printf("%s", l + (9 - (now - last)));
            else if (now < last)
                printf("%s", r + (9 - (last - now)));
            putchar('0' + now);
            last = now;
        }
        puts(r + (9 - last));
    }
}

