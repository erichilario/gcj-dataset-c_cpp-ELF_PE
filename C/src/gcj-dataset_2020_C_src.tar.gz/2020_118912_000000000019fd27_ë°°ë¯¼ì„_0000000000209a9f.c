#include<stdio.h>

int main()
{
    int N,i;
    char str[110]={'0'};
    scanf("%d",&N);
    for(int t=1 ; t<=N ; t++)
    {
        scanf("%s",str+1);
        for(i=0 ; str[i] ; i++);
            str[i]='0'; str[i+1]=0;
        printf("Case #%d: ",t);
        for(i=1 ; str[i] ; i++)
        {
            if(str[i-1]!=str[i])
                for(int j=str[i-1] ; j!=str[i] ; j+=(str[i-1]<str[i]? 1 : -1))
                    printf("%c",str[i-1]<str[i] ? '(' : ')');
            if(str[i+1])
                printf("%c",str[i]);
        }
        printf("\n");
    }
}

