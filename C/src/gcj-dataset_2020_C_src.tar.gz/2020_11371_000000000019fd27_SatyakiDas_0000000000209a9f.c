// C++ program to pritn Latin Square
#include<stdio.h>
#include<string.h>

void input_br(int inp_br)
{
    switch(inp_br)
       {
           case 0:printf("");
                 break;
           case 1:printf("(");
                 break;
           case 2:printf("((");
                 break;
           case 3:printf("(((");
                 break;
           case 4:printf("((((");
                 break;
           case 5:printf("(((((");
                 break;
           case 6:printf("((((((");
                 break;
           case 7:printf("(((((((");
                 break;
           case 8:printf("((((((((");
                 break;
           case 9:printf("(((((((((");
                 break;
       }

}
void output_br(int out_br)
{
    switch(out_br)
       {
           case 0:printf("");
                 break;
           case 1:printf(")");
                 break;
           case 2:printf("))");
                 break;
           case 3:printf(")))");
                 break;
           case 4:printf("))))");
                 break;
           case 5:printf(")))))");
                 break;
           case 6:printf("))))))");
                 break;
           case 7:printf(")))))))");
                 break;
           case 8:printf("))))))))");
                 break;
           case 9:printf(")))))))))");
                 break;
       }



}

int main()
{
int n,i;
char str[100][100]; // Can store 20 strings, each of length 20
scanf("%d",&n);

for(i=0;i<n;i++)
{
   scanf("%s",str[i]);
}

int num;
int numpre;
//display each string
for(i=0;i<n;i++)
{
  // printf("%s\n",str[i]);
   for(int x=0;str[i][x]!='\0';x++)
   {
       //printf("\t %d",str[i][x]-48);

       num=str[i][x]-48;

        if(x==0)
        {
            input_br(num);
        }
        else{
            if(numpre==num)
            {

            }
            else if(numpre>num)
            {
                output_br(numpre-num);

            }
            else if(numpre<num)
            {
                input_br(num-numpre);

            }
        }



       printf("%d",num);
       numpre=num;

   }
   output_br(num);
   printf("\n");
}

return 0;
}

