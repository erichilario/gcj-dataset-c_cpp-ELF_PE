#include<stdio.h>
#include<string.h>
int main(){
	int t;
	scanf("%d",&t);
	for(int i=1;i<=t;i++){
		char x[101];
		scanf("%s",x);
		int len=strlen(x);
		printf("Case #%d: ",i);
		for(int j=0;j<len;j++){
			if(j==0){
				for(int n=0;n<x[0]-48;n++)printf("(");
			}
			else {
				if(x[j-1]>x[j]){
					for(int n=0;n<x[j-1]-x[j];n++)printf(")");
				}
				if(x[j-1]<x[j]){
					for(int n=0;n<x[j]-x[j-1];n++)printf("(");
				}
			}
			printf("%c",x[j]);
		}
		for(int n=0;n<x[len-1]-48;n++)printf(")");
		puts("");
	}
}
