#include <stdio.h>

int tcase;
char s[110];

int main()
{
    int cas,i,x,y;

    scanf("%d",&tcase);
    for(cas=1;cas<=tcase;cas++)
    {
        scanf("%s",s+1);
        printf("Case #%d: ",cas);
        for(i=1,x=0;s[i];i++)
        {
            y = s[i] - '0';
            while(x < y) printf("("), x++;
            while(x > y) printf(")"), x--;
            printf("%d",y);
        }
        while(x--) printf(")");
        printf("\n");
    }

    return 0;
}

