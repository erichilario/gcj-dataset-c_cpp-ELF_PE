#include<stdio.h>
#include<string.h>

int main()
{
        int t,b;
        scanf("%d %d",&t,&b);
        int T=1;
        while(T<=t)
        {
                int arr[b+1][2],index=1;
                int Q=150,q=1;
                int ie=0,ine=0;
                int c=0,r=0;
                while(q<=Q)
                {
                        int mq=10,f=0;
                        if(ie!=0)
                        {
                                printf("%d\n",ie);
                                mq--;
                                int k;
                                scanf("%d",&k);
                                fflush(stdout);

                                if(k==arr[ie][0])
                                        c=0;
                                else
                                {
                                        c=1;
                                        for(int j=1;j<index,j<=b/2;j++)
                                        {
                                                if(arr[j][1]==0)
                                                {
                                                        arr[j][1]=(!arr[j][1]);
                                                        arr[b-j+1][1]=(!arr[b-j+1][1]);
                                                }
                                        }
                                }
                        }

                        if(ine!=0)
                        {
                                printf("%d\n",ine);
                                mq--;
                                int k;
                                scanf("%d",&k);
                                fflush(stdout);

                                if(c==0)
                                {
                                        if(arr[ine][0]==k)
                                                r=0;
                                        else
                                                r=1;
                                }
                                else
                                {
                                        if(arr[ine][1]==k)
                                                r=1;
                                        else
                                                r=0;
                                }
                                if( ( c==1 && r==0 ) || ( c==0 && r==1 ) )
                                {
                                        for(int j=1;j<index,j<=b/2;j++)
                                        {
                                                if(arr[j][1]==1)
                                                {
                                                        int h=arr[j][0];
                                                        arr[j][0]=arr[b-j+1][0];
                                                        arr[b-j+1][0]=h;
                                                }
                                        }
                                }
                        }

                        while(mq)
                        {
                                printf("%d\n",index);
                                int k1,k2;
                                scanf("%d",&arr[index][0]);
                                fflush(stdout);


                                printf("%d\n",b-index+1);
                                scanf("%d",&arr[b-index+1][0]);
                                fflush(stdout);
                                mq--;


                                k1=arr[index][0];
                                k2=arr[b-index+1][0];

                                if(k1==k2)
                                {
                                        arr[index][1]=arr[b-index+1][1]=0;
                                        if(ie==0)
                                                ie=index;
                                }
                                else
                                {
                                        arr[index][1]=arr[b-index+1][1]=1;
                                        if(ine==0)
                                                ine=index;
                                }
                                if(index==b/2)
                                {
                                        f=1;
                                        break;
                                }
                                index++;
                        }

                        if(f)
                                break;

                        q=q+10;
                }
                printf("HERE\n");
                fflush(stdout);
                for(int i=1;i<=b;i++)
                        printf("%d",arr[i][0]);
                printf("\n");

                fflush(stdout);
                char decide[10];
                scanf("%s",decide);

                if(decide[0]=='N')
                        break;
                T++;
        }
        return 0;
}

