#include <stdio.h>

int map[110][110];
int main()
{
    int T;
    scanf("%d",&T);
    for(int i=1;i<=T;i++)
    {
        int N;
        int row=0,col=0,dia=0;
        scanf("%d",&N);
        for(int a=0;a<N;a++)
        {
            for(int b=0;b<N;b++)
            {
                scanf("%d",&map[a][b]);
            }
        }
        for(int hori=0;hori<N;hori++)
        {
            for(int a=0;a<N;a++)
            {
                for(int b=a+1;b<N;b++)
                {
                    if(map[a][hori]==map[b][hori])
                    {
                        col++;
                        b=N;
                        a=N;
                    }
                }
            }
        }
        for(int ver=0;ver<N;ver++)
        {
            for(int a=0;a<N;a++)
            {
                for(int b=a+1;b<N;b++)
                {
                    if(map[ver][a]==map[ver][b])
                    {
                        row++;
                        b=N;
                        a=N;
                    }
                }
            }
        }
        for(int i=0;i<N;i++)
        {
            dia+=map[i][i];
        }
        printf("Case #%d: ",i);
        printf("%d %d %d\n",dia,row,col);
    }
}
