#include<stdio.h>

int main(){
    int t, u;

    scanf("%d", &t);
    for (u = 1; u <= t; ++u){
        int n, k, x, i, j;
        scanf("%d%d", &n, &k);
        if (k % n == 0){
            printf("Case #%d: POSSIBLE\n", u);
            x = k / n - 1;
            for (i = 0; i < n; ++i){
                for (j = 0; j < n; ++j){
                    printf("%d%c", (n + x + j - i) % n + 1, j == n - 1 ? '\n' : ' ');
                }
            }
        }
        else printf("Case #%d: IMPOSSIBLE\n", u);
    }
    return 0;
}
