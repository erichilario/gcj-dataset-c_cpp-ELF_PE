#include<stdio.h>
int main(){
    int T;
    scanf("%d",&T);
    for(int t = 1;t<=T;t++){
        int N,k,r=0,c=0;
        scanf("%d",&N);
        int matrix[N+1][N+1];
        k = 0;
        for(int i = 1;i<=N;i++){
            for(int j =1;j<=N;j++){
                scanf("%d ",&matrix[i][j]);
                if(i == j){
                    k = k + matrix[i][j];
                }
            }
        }
        int rf=0,cf =0;
        for(int i = 1;i<=N;i++){
            rf = 0;
            cf = 0;
            for(int j = 1;j<N;j++){
                for(int l = j+1;l<=N;l++){
                    if(rf == 0){
                        if(matrix[i][j] == matrix[i][l]){
                        r++;
                        rf = 1;
                    }
                   }
                    if(cf == 0 && matrix[j][i] == matrix[l][i]){
                        c++;
                        cf =1;
                    }
                    if(rf == 1 && cf == 1){
                        break;
                    }
                }
                if(rf == 1 && cf == 1){
                        break;
                    }
            }
        }
        printf("Case #%d: %d %d %d\n",t,k,r,c);
    }
}
