#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define size 102

char s[size];


int main(){
    int i, len, test, t;
 
    scanf("%d",&test);
    fgets(s, sizeof(s), stdin);

    for(t=1;t<=test;t++){
      
        fgets(s, sizeof(s), stdin);
        len = strlen(s) - 1;
    
        printf("Case #%d: ",t);    
        for(i=0;i<len;i++){
            if(s[i]=='0')
              printf("0");
            else{
                printf("(");
                for(;i<len;i++){
                    if(s[i]=='1')
                        printf("1");
                    else
                    {
                        printf(")");
                        printf("%c",s[i]);
                        break;
                    }
                        
                }
                if(i==len){
                 printf(")");
                }

            }  
        }
        printf("\n");
        
    }


    return 0;
}
