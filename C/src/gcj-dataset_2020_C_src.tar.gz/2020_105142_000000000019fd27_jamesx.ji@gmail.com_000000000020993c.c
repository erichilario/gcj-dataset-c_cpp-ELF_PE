#include <stdio.h>
#include <string.h>


int main (void) {
    int t; // Number of test cases
    int tno = 1; // Test case number
    scanf("%d", &t);

    // For each test case
    while (tno <= t) {
        int array[100][100];    // Array of max size
        int n; // Size of matrix
        scanf("%d", &n);

        // Scan in the matrix
        // Get its diagonal sum while we scan
        int trace = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                scanf("%d", &array[i][j]);
                if (i == j) {
                    trace += array[i][j];
                }
            }
        }
        
        // Check for repeated rows
        int repeated_rows = 0;
        for (int row = 0; row < n; row++) {
            for (int i = 0, stop = 0; i < n && stop == 0; i++) {
                // Start from 1st element, check all on right, then go to 2nd
                // element, check all on right, etc. Break when repeat is found
                for (int j = i + 1; j < n && stop == 0; j++) {
                    if (array[row][i] == array[row][j]) {
                        stop = 1;
                        repeated_rows++;
                    }
                }
            }
        }

        // Check for repeated columns
        int repeated_cols = 0;
        for (int col = 0; col < n; col++) {
            for (int i = 0, stop = 0; i < n && stop == 0; i++) {
                // Start from 1st element, check all elements below, then go to
                // next element down, check all below, etc. Break when repeat found
                for (int j = i + 1; j < n && stop == 0; j ++) {
                    if (array[i][col] == array[j][col]) {
                        stop = 1;
                        repeated_cols++;
                    }
                }
            }
        }

        printf("Case #%d: %d %d %d\n", tno, trace, repeated_rows, repeated_cols);

        tno++;
    }



    return 0;
}
