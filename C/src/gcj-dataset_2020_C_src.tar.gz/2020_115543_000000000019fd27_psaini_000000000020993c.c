#include<stdio.h>

int a[100][100];
int C[100];

int main() {
	int t;
	scanf("%d", &t);
	for( int tt=1; tt<=t; ++tt ) {
		int n;
		scanf("%d", &n);
		for( int i=0; i<n; ++i )
			for( int j=0; j<n; ++j )
				scanf("%d", &(a[i][j]));
		int k=0;
		for( int i=0; i<n; ++i ) k+=a[i][i];
		int r=0;
		for( int i=0; i<n; ++i ) {
			int f = 0;
			for( int j=0; j<n; ++j )
				C[j] = 0;
			for( int j=0; j<n; ++j ) {
				if( C[a[i][j]-1] ) f = 1;
				C[a[i][j]-1] += 1;
			}
			r += f;
		}
		int c=0;
		for( int j=0; j<n; ++j ) {
			int f = 0;
			for( int i=0; i<n; ++i )
				C[i] = 0;
			for( int i=0; i<n; ++i ) {
				if( C[a[i][j]-1] ) f = 1;
				C[a[i][j]-1] += 1;
			}
			c += f;
		}
		printf("Case #%d: %d %d %d\n", tt, k, r, c);
	}
}
