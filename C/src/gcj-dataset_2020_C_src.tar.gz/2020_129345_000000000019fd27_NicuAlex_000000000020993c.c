#include <stdio.h>
#include <stdlib.h>
int mat[101][101], f[100 * 100 + 1];
int main()
{
    int t, n, l, c, i, sum, row_reapeat, column_reapeat;
    scanf( "%d", &t );
    for ( i = 1; i <= t; i++ ) {
      scanf( "%d", &n );
      sum = 0;
      for ( l = 1; l <= n; l++ ) {
        for ( c = 1; c <= n; c++ ) {
          scanf( "%d", &mat[l][c] );
          if ( l == c )
            sum += mat[l][c];
        }
      }
      printf( "Case #%d: %d", i, sum );
      row_reapeat = column_reapeat = 0;
      for ( l = 1; l <= n; l++ ) {
         c = 1;
         while ( c <= n && f[mat[l][c]] == 0 )
           f[mat[l][c++]] = 1;
         if ( c <= n )
          row_reapeat++;
         while ( c >= 1 )
          f[mat[l][c--]] = 0;
      }
      for ( c = 1; c <= n; c++ ) {
         l = 1;
         while ( l <= n && f[mat[l][c]] == 0 )
           f[mat[l++][c]] = 1;
         if ( l <= n )
          column_reapeat++;
         while ( l >= 1 )
          f[mat[l--][c]] = 0;
      }
      printf( " %d %d\n", row_reapeat, column_reapeat );
    }
    return 0;
}

