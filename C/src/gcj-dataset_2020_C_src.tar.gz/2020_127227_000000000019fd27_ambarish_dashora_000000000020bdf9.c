#include<stdio.h>
#include<stdlib.h>
void quicksort(int ar[][],int a, int l);
void swap(int *a,int *b);
int main()
{
    int i,k,tc,n,q,flagj,flagc,out;
    char c,j;
    c='C';
    j='J';
    scanf("%d",&tc);
    for(q=0;q<tc;q++)
    {
        scanf("%d",&n);
        int ar[n][4];
        for(i=0;i<n;i++)
        {
            scanf("%d",&ar[i][0]);
            scanf("%d",&ar[i][1]);
            ar[i][4]=i;
        }
        quicksort(ar,0,n);
        out=1;
        ar[0][2]=c;
        for(i=1;i<n;i++)
        {
            flagc=0;flagj=0;
            for(k=0;k<i;k++)
            {
                if(ar[k][1]>ar[i][0] && ar[k][0]<ar[i][1] && ar[k][2]==j) flagj=1;
                if(ar[k][1]>ar[i][0] && ar[k][0]<ar[i][1] && ar[k][2]==c) flagc=1;
            }
            if(flagj==1 && flagc==1)
            {
                out=0;
                break;
            }
            else if(flagc==0) ar[i][2]=c;
            else if(flagj==0) ar[i][2]=j;
        }
        
        printf("Case #%d: ",q+1);
        if(out)
        {
            for(i=0;i<n;i++)
            {
                printf("%c",ar[i][2]);
            }
        }
        else
        printf("IMPOSSIBLE");
        printf("\n");
        
    }
    return 0;
}



void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

void quicksort(int arr[][], int l, int r)
{
    if (l >= r)
    {
        return;
    }
    int pivot = arr[r][0];
    int cnt = l;
    for (int i = l; i <= r; i++)
    {
        if (arr[i][0] <= pivot)
        {
            swap(&arr[cnt][0], &arr[i][0]);
            swap(&arr[cnt][1], &arr[i][1]);
            swap(&arr[cnt][2], &arr[i][2]);
            swap(&arr[cnt][3], &arr[i][3]);
            cnt++;
        }
    }
    
    quicksort(arr, l, cnt-2); // Recursively sort the left side of pivot
    quicksort(arr, cnt, r);   // Recursively sort the right side of pivot
}

