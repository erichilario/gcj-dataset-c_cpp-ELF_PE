//#include<stdio.h>
//
//int main()
//{
//    int T,cases=0;
//    char i=0,pre=-1,ch=1;
//    scanf("%d%*c",&T);
//    printf("Case #%d: ",++cases);
//    while(ch!=EOF)
//    {
//        ch=getchar();
//        if(ch==EOF)
//            break;
//        ch-='0';
//        if(ch!=pre)
//        {
//            for(i=1;i<pre;i++)
//                putchar(')');
//            if(pre!=-1 && ch==0 || ch+'0'=='\n' && pre!=0)
//                putchar(')');
//
//            if(ch+'0'=='\n')
//            {
//                pre=-1,ch=1;
//                cases++;
//                printf("\n");
//                if(cases<=T)printf("Case #%d: ",cases);
//                continue;
//            }
//
//            if((pre==0||pre==-1||pre==-38) && ch+'0'!='\n' && ch!=0)
//                putchar('(');
//            for(i=1;i<ch;i++)
//                putchar('(');
//        }
//        putchar(ch+'0');
//        pre=ch;
//    }
//    return 0;
//}

#include<stdio.h>

int main()
{
    char s[101],i,j;
    int T,cases=0;
    scanf("%d",&T);
    while(T--)
    {
        scanf(" %s",s);
        printf("Case #%d: ",++cases);
        for(i=0;s[i];i++)
        {
            if(s[i]=='0')
            {
                putchar(s[i]);
                continue;
            }
            if(i==0 && s[i] || i>0 && s[i-1]=='0')
                putchar('(');
            for(j='1';j<s[i] && (i>0 && s[i-1]!=s[i] || i==0);j++)
                putchar('(');
            putchar(s[i]);
            if(s[i+1]==s[i])continue;
            for(j='1';j<s[i];j++)
                putchar(')');
            if(s[i+1]=='\0' &&s[i] || s[i+1]=='0' && s[i])
                putchar(')');
        }
        printf("\n");
    }
    return 0;
}

