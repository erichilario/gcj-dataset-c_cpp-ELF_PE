#include<stdio.h>
int t,b;
char x[101];
int main(){
	scanf("%d%d\n",&t,&b);
	for(int i=0;i<t;i++){
		for(int j=1;j<=b;j++)x[j]=' ';
		int count=1,n=1;
		while(count){
			if(n%10==1&&n!=1){
				printf("1");
				char a;
				scanf("%c\n",&a);
				if(x[1]==x[b]){
					char c;
					int che=0;
					for(int j=1;j<=b;j++){
						if(x[j]!=x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
							che=j;
							j=b+1;
						}	
					}
					printf("%d",che);
					scanf("%c\n",&c);
					if(x[1]!=a){
						for(int j=1;j<=b;j++){
				    		if(x[j]==x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
				    			if(x[j]=='1')x[j]='0';
			    				else x[j]='1';
		    				}	
			    		}
					}
					if(x[che]!=c){
						for(int j=1;j<=b;j++){
		    				if(x[j]!=x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
		    					if(x[j]=='1')x[j]='0';
	    						else x[j]='1';
	    					}	
	    				}
    				}
    			}
				else {
					char c;
					int che=0;
					for(int j=1;j<=b;j++){
						if(x[j]==x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
							che=j;
							break;
						}	
					}
					printf("%d",che);
					scanf("%c\n",&c);
					if(x[1]!=a){
						for(int j=1;j<=b;j++){
				    		if(x[j]!=x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
			    				if(x[j]=='1')x[j]='0';
			    				else x[j]='1';
				    		}	
		    			}
					}
					if(x[che]!=c){
						for(int j=1;j<=b;j++){
			    			if(x[j]==x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
			    				if(x[j]=='1')x[j]='0';
			    				else x[j]='1';
			    			}	
		    			}
		    		}
			    }
				n+=2;
			}
			else {
		        int c=0;
				for(int j=1;j<=b;j++){
					if(x[j]==' ')c++;
				}
				if(c==1&&n%10!=0)count=0;
				c=(char)c;
				for(int j=1;j<=b;j++){
					if(x[j]==' '){
						printf("%d ",j);
						scanf("%c\n",&c);
						x[j]=c;
						j=1000000;
					}
				}
				n++;
			}
		}
		for(int j=1;j<=b;j++)printf("%c",x[j]);
		char ans;
		scanf("%c\n",&ans);
		if(ans=='N')return 0;
	}
}

