#include<stdio.h>

void main(){
    int T;
    scanf("%d",&T);
    for(int i=1;i<=T;i++){
        int N;
        char out[12];
        scanf("%d",&N);
        int s[N],e[N];
        for(int j=0;j<N;j++){
            scanf("%d %d",&s[i],&e[i]);
        }
        
        int imp=0;
    //check for imposible

        for(int j=0;j<N-1;j++){
            for(int k=j;k<N;k++){
                if(e[j]>s[k])
                    imp=1;
                else{
                    imp=0;
                    goto a;
                }
            }
        }
        a:
        if(imp==0){
            printf("Case #%d: IMPOSSIBLE\n",i);
            return;
        }
        out[i]='C';
        for(int j=0;j<N-1;j++){
                if(j<i && s[i]>=e[j]){
                    out[j]='C';
                }
                else{
                    out[j]='J';
                }
                if(j>i){
                    if(e[i]>s[j])
                        out[j]='C';
                    else
                        out[j]='J';
                }
            }
        printf("Case #%d: %s\n",i,out);
        
        
    
    }
}
