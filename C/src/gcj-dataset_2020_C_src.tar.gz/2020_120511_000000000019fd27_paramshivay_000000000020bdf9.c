#include<stdio.h>
int main(){
    int T;
    scanf("%d",&T);
    for(int t=1;t<=T;t++){
        int N,s,e;
        scanf("%d",&N);
        int time[24*60+1][3];
        int rec[N+1][2];
        char result[N+2];
        for(int i = 0;i<=1440;i++){
            time[i][0] = 0;
            time[i][1] = 0;
            time[i][2] = 0;
            if(i>0 && i<=N){
                scanf("%d %d",&rec[i][0],&rec[i][1]);
            }
        }
         int flag =0;
        for(int i = 1;i<=N;i++){
            int j =0;
            while(time[i][j]!=0 && j<3){
                j++;
            }
            time[rec[i][0]][j] = i;
            if(j == 3){
            flag = 1;
            break;
            }
        }
        if(flag!=1){
          int C[3] = {1,0,0}; 
          int J[3] = {1,0,0};
          int index,j=0;
          
          result[N+1] = '\0';
          for(int i = 0;i<=1440;i++){
              j=0;
             while(time[i][j]!=0){
                 index = time[i][j];
                 if(C[0] == 1){
                     C[0] = 0;
                     C[1] = i;
                     C[2] = rec[index][1];
                     result[index] = 'C';
                 }else if(C[0] == 0 && C[2]<=rec[index][0]){
                     C[1] = rec[index][0];
                     C[2] = rec[index][1];
                     result[index] = 'C';
                 }else if(J[0] == 1){
                     J[0] = 0;
                     J[1] = i;
                     J[2] = rec[index][1];
                     result[index] = 'J';
                 }else if(J[0] == 0 && J[2]<=rec[index][0]){
                     J[1] = rec[index][0];
                     J[2] = rec[index][1];
                     result[index] = 'J';
                 }else{
                     flag = 1;
                 }
                 j++;
             }
          }
        }
        if(flag == 1){
            printf("Case #%d: IMPOSSIBLE\n",t);
        }else {
            printf("Case #%d: %s\n",t,result +1);
        }
     
    }
}
