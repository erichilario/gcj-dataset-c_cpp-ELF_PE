#include<stdio.h>
#include<string.h>
#include<stdlib.h>



void inizializza(int *v,int dim){
    int i;
    for(i=0;i<dim;i++)
      v[i]=0;
}

void compute(int **M,int N,int *trace,int *rows,int *columns){
    int i,j;
    int errR=0,errC=0;
    int* r=(int *)malloc(sizeof(int)*N);
    int* c=(int *)malloc(sizeof(int)*N);
    inizializza(r,N);
    inizializza(c,N);

    for(i=0;i<N;i++)
      *trace=*trace+M[i][i];
    for(i=0;i<N;i++){
      j=0;
      errR=0;
      while(!errR && j<N){
          r[M[i][j]-1]++;
          if(r[M[i][j]-1]>1){
            errR=1;
            *rows=*rows+1;
          }

          j++;
      }
      inizializza(r,N);
    }

    for(i=0;i<N;i++){
      j=0;
      errC=0;
      while(!errC && j<N){
          c[M[j][i]-1]++;
          if(c[M[j][i]-1]>1){
            errC=1;
            *columns=*columns+1;
          }

          j++;
      }
      inizializza(c,N);
    }
    free(r);
    free(c);
}

int main(){
    int T,N;
    int **M;
    int t,i,j;
    scanf("%d",&T);
    for(t=1;t<=T;t++){
        int trace=0,rows=0,columns=0;
        scanf("%d",&N);
        M=(int **)malloc(sizeof(int *)*N);
        for(i=0;i<N;i++)
          M[i]=(int *)malloc(sizeof(int)*N);
        for(i=0;i<N;i++)
          for(j=0;j<N;j++)
            scanf("%d",&(M[i][j]));
        
        compute(M,N,&trace,&rows,&columns);
        printf("Case #%d: %d %d %d\n",t,trace,rows,columns);
        for(i=0;i<N;i++)
          free(M[i]);
        free(M);
    }
    return 0;
}

