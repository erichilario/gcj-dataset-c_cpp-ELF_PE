#include<stdio.h>
int check[101],check1[101];
int main(){
	int t;
	scanf("%d",&t);
	for(int a=1;a<=t;a++){
		int x;
		scanf("%d",&x);
		int arr[x+1][x+1],sum=0,r=0,c=0,b=0,d=0;
		for(int i=1;i<=x;i++){
			for(int j=1;j<=x;j++){
				scanf("%d",&arr[i][j]);
				if(i==j)sum+=arr[i][j];
				check[arr[i][j]]++;
				if(b==0&&check[arr[i][j]]>=2){
					b=1;
					r++;
				}
			}
			for(int j=1;j<=x;j++)check[j]=0;
			b=0;
		}
        for(int i=1;i<=x;i++){
        	for(int j=1;j<=x;j++){
        		check1[arr[j][i]]++;
        		if(d==0&&check1[arr[j][i]]>=2){
        			d=1;
        			c++;
				}
			}
			for(int j=1;j<=x;j++)check1[j]=0;
			d=0;
		}

		printf("Case #%d: %d %d %d\n",a,sum,r,c);
		
	}
}
