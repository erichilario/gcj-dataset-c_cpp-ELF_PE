#include<stdio.h>

int main()
{
        int t,b;
        scanf("%d %d",&t,&b);
        while(t--)
        {
                int arr[b+1],index=1,fe=0,fne=0;
                char type[b+1];

                int q=1;
                while(q<=150)
                {
                        int mq=10,k,f=0;
                        if(fe!=0)
                        {
                                printf("%d\n",fe);
                                mq--;
                                fflush(stdout);
                                scanf("%d",&k);

                                if(k!=arr[fe])
                                {
                                        for(int i=0;i<index;i++)
                                        {
                                                if(type[i]=='e')
                                                {
                                                        arr[i]=(!arr[i]);
                                                        arr[b-i+1]=(!arr[b+1-i]);
                                                }
                                        }
                                }
                        }

                        if(fne!=0)
                        {
                                printf("%d\n",fne);
                                fflush(stdout);
                                scanf("%d",&k);
                                mq--;

                                if( arr[fne]!=k )
                                {
                                        for(int i=0;i<index;i++)
                                        {
                                                if(type[i]=='n')
                                                {
                                                        arr[i]=(!arr[i]);
                                                        arr[b-i+1]=(!arr[b+1-i]);
                                                }
                                        }
                                }
                        }

                        while(mq--)
                        {
                                printf("%d\n",index);
                                fflush(stdout);
                                scanf("%d",&arr[index]);
                                printf("%d\n",b+1-index);
                                fflush(stdout);
                                scanf("%d",&arr[b+1-index]);

                                if(arr[index]==arr[b+1-index])
                                {
                                        type[index]=type[b+1-index]='e';
                                        if(fe==0)
                                                fe=index;
                                }
                                else
                                {
                                        type[index]=type[b+1-index]='n';
                                        if(fne==0)
                                                fne=index;
                                }

                                if(index==b/2)
                                {
                                        f=1;
                                        break;
                                }
                                index++;
                        }
                        if(f)
                                break;
                        q=q+10;
                }

                fflush(stdout);
                for(int i=1;i<=b;i++)
                        printf("%d",arr[i]);
                printf("\n");

                char decide[10];
                scanf("%s",decide);

                if(decide[0]=='N')
                        break;

        }

        return 0;
}

