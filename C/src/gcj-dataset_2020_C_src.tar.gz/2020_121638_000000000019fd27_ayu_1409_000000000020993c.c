#include<stdio.h>
#define ll long long int

int main()
{
    ll t,T;
    scanf("%lld",&T);
    t=1;
    while(t<=T)
    {
        ll n;
        scanf("%lld",&n);
        
        ll arr[n+1][n+1];
        ll k=0,r=0,c=0;
        
        for(ll i=0;i<n;i++)
        {
            int flag=0;
            for(ll j=0;j<n;j++)
            {
                scanf("%lld",&arr[i][j]);
                
                if(i==j)
                    k+=arr[i][j];
            
                if(flag==0)
                    for(int h=0;h<j;h++)
                        if(arr[i][h]==arr[i][j])
                            flag=1;
            }
            if(flag)
                r++;
        }
        
        for(ll j=0;j<n;j++)
        {
            int flag=0;
            for(ll i=0;i<n-1;i++)
            {
                if(flag==0)
                {
                    for(ll h=i+1;h<n;h++)
                    {
                        if(arr[i][j]==arr[h][j])
                            {
                                flag=1;
                                c++;
                                break;
                            }
                    }
                }
                if(flag)
                    break;
            }
        }
        
        printf("Case #%lld: %lld %lld %lld\n",t,k,r,c);
        t++;
    }
    return 0;
}
