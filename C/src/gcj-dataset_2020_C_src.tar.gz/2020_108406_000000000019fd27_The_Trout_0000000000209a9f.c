#include <stdio.h>
#include <string.h>
#define MAX 105

char s[MAX];

void solve(int head, int tail, int depth) {
  int i, j, dive;
  for (i = head; i <= tail;) {
    dive = 0;
    for (; i <= tail; i++)
      if (s[i] != '0' + depth) {
        dive = 1;
        for (j = i; j <= tail && s[j] != '0' + depth; j++)
          ;
        break;
      } else
        printf("%c", s[i]);
    if (dive) {
      printf("(");
      solve(i, j - 1, depth + 1);
      printf(")");
      i = j;
    }
  }
}

int main() {
  int T, N, trace, row, col;
  scanf("%d", &T);
  for (int k = 1; k <= T; k++) {
    scanf("%s", s);
    printf("Case #%d: ", k);
    solve(0, strlen(s) - 1, 0);
    printf("\n");
  }
  return 0;
}

