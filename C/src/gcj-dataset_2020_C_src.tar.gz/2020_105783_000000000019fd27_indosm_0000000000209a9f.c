#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    int T;
    scanf("%d",&T);
    for(int i=1;i<=T;i++)
    {
        printf("Case #%d: ",i);
        char S[110];
        int level=0;
        scanf("%s",&S);
        for(int a=0;a<strlen(S);a++)
        {
            if((S[a]-'0')>level)
            {
                for(int t=0;t<S[a]-'0'-level;t++)printf("(");
                printf("%c",S[a]);
                level=S[a]-'0';
            }
            else if((S[a]-'0')==level){
                printf("%c",S[a]);
            }
            else{
                for(int t=0;t<level-(S[a]-'0');t++)printf(")");
                printf("%c",S[a]);
                level=S[a]-'0';
            }
        }
        if(level>0)
        {
            for(int t=0;t<level;t++)printf(")");
        }
        printf("\n");
    }
}
