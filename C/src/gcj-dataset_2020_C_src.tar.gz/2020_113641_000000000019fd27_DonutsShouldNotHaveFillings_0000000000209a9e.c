#include <stdio.h>
#include <stdlib.h>

int main(void) {
    setbuf(stdout, NULL);
    int ncases;
    int len;
    scanf("%d %d", &ncases, &len);
    printf("9999");
    return 0;
}
