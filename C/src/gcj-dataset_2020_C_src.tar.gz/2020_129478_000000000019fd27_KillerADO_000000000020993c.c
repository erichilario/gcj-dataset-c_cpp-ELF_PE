#include <stdio.h>
#include <string.h>

int main(){
    int T, t, N;
    int M[100][100];
    int i, j, trace = 0, row, col;
    int rowMask[101], rowUpdate;
    int colMask[101], colUpdate;
    
    scanf("%d", &T);
    for(t = 1; t <= T; t++){
        scanf("%d", &N);
        trace = row = col = 0;
        
        for(i = 0; i < N; i++){
            memset(rowMask, 0, sizeof(rowMask));
            rowUpdate = 0;
            
            for(j = 0; j < N; j++){
                scanf("%d", &M[i][j]);
                
                if(i == j)
                    trace += M[i][j];
                
                if(rowMask[M[i][j]] == 1 && rowUpdate == 0){
                    row++;
                    rowUpdate = 1;
                }
                else
                    rowMask[M[i][j]] = 1;
            }
        }
        
        for(i = 0; i < N; i++){
            memset(colMask, 0, sizeof(colMask));
            colUpdate = 0;
            for(j = 0; j < N; j++){
                if(colMask[M[j][i]] == 1 && colUpdate == 0){
                    col++;
                    colUpdate = 1;
                }
                else
                    colMask[M[j][i]] = 1;
            }
        }
        
        
        printf("Case #%d: %d %d %d\n", t, trace, row, col);
    }
    
    return 0;
}
