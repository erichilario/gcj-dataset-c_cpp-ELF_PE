#include <stdlib.h>
#include <stdio.h>

int ok(int n,int k){
    int i,j,m=0;
    if(k==0 || k < n ){
        printf("IMPOSSIBLE\n");
    }
    if(k%n == 0 && k < n*n){
        printf("POSSIBLE\n");
        int a = k/n;
        m=0;
        for(i=1;i<n+1;i++){
            for(j=1;j<n+1;j++){
                if(i==j){
                    printf("%d ",a);
                    continue;
                }
                if(m%n+1 != a){
                    printf("%d ",m%n+1);
                }else{
                    m++;
                    printf("%d ",m%n+1);
                }
                m++;
            }printf("\n");m--;
        }
    }else if(n%2 == 1 && n*(n+1)/2 == k){
        printf("Possible\n");
        m=0;
        for(i=1;i<n+1;i++){
            for(j=1;j<n+1;j++){
                if(i==j){
                    printf("%d",i);
                    continue;
                }
                if(m%n+1 != i){
                    printf("%d",m%n+1);
                }else{
                    m++;
                    printf("%d",m%n+1);
                }
                m++;
            }printf("\n");m--;
        }
    }else{
        printf("IMPOSSIBLE\n");
    }
}

int main(){
    int i,j,k,a,n;
    scanf("%d",&a);
    for(i=0;i<a;i++){
        printf("Case #%d: ",i+1);
        scanf("%d",&n);
        scanf("%d",&k);
        ok(n,k);
    }
}
