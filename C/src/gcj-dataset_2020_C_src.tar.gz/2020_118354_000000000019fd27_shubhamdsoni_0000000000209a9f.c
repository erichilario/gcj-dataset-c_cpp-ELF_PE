#include<stdio.h>

int main()
{
	int T,_T;
	scanf("%d", &T);
	_T = T;
	while(T--)
	{
          char S[101];
	  scanf("%s",S);
          printf("Case #%d: ", _T-T);
	  int i=0,p=0;
	  while(S[i]!='\0')
	  {
		  if(p==(S[i]-'0'))
		  {
			  printf("%c",S[i]);
		  }
		  else
		  {
			  if((p==0)&&(S[i]=='1'))
			  {
				  printf("(1");
			  }
			  else
			  {
				  printf(")0");
			  }
			  p = S[i] - '0';
		  }
		  i++;
	  }
	  if(p==1)
	  {
		  printf(")");
	  }
	  printf("\n");
	}
	return 0;
}

