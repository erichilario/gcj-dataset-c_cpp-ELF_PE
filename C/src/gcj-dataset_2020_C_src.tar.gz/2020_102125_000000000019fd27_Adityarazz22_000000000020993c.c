#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
    int i,k,j,t=0,r=0,c=0,p,n,m,x;
    
    
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&m);
        int* a=(int*)malloc(m*m*sizeof(int));
        
        for(j=0;j<m;j++){
            int* b=(int*)malloc((m+1)*sizeof(int));
        memset(b,0,sizeof(int)*(m+1));
            for(k=0;k<m;k++){
                scanf("%d",&x);
                *(a+ j*m +k)=x;
                if(j==k){
                    t+=x;
                }
                if(b[x]==1 && p==0){
                    p=1;
                    r++;
                    
                }
                b[x]=1;
                
            }
            p=0;
            free(b);
        }
        
        
        for(j=0;j<m;j++){
            int* ca=(int*)malloc((m+1)*sizeof(int));
        memset(ca,0,sizeof(int)*(m+1));
            for(k=0;k<m;k++){
                
                if(ca[*(a + k*m + j)]==1){
                    c++;
                    break;
                }
                ca[*(a + k*m + j)]=1;
                
            }free(ca);
        }
         free(a);
        printf("Case #%d: %d %d %d\n",i,t,r,c);
        t=0;r=0;c=0;
    }
}
