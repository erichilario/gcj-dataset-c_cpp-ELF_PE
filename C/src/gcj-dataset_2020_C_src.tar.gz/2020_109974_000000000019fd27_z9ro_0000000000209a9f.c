#include<stdio.h>
#include<string.h>

int main(){
    int t;
    char s[105];
    char ans[1000];
    scanf("%d", &t);
    for(int i=0; i<t; i++){
        int left = 0;
        int pans = 0;
        int num = 0;
        scanf("%s", s);

        int len = strlen(s);
        for(int i=0; i<len; i++){
            num = s[i] - '0';
            // if(left<num){
            for(int k=0; k<num-left; k++){
                ans[pans] = '(';
                pans++;
            }
                
            // }else if (left>num){
            for(int k=0; k<left-num; k++){
                ans[pans] = ')';
                pans++;
            }
            // }
            left = num;
            
            ans[pans] = s[i];
            pans++;
        }
        for(int k=0; k<left; k++){
            ans[pans] = ')';
            pans++;
        }
        ans[pans] = '\0';
        
        printf("Case #%d: %s\n", i+1, ans);
    }
    return 0;
}
