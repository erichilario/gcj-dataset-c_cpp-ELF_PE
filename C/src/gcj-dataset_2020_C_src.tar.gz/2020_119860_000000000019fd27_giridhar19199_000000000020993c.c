#include<bits/stdc++.h>

using namespace std;

#define fri(x,n) for(i=x;i<n;i++)
#define frj(x,n) for(j=x;j<n;j++)
#define ll long long
#define boost ios::sync_with_stdio(NULL);cin.tie(0);
#define mod9 1000000007
#define endl "\n"
#define deb(x) cout <<#x<<" "<<x<<endl; 

int main()
{
	boost;
	int i,tests,j,cases = 1;
	cin>>tests;
	while(tests--)
	{
		int n,rows = 0,cols = 0, trace = 0;
		cin>>n;
		int mat[n][n];
		fri(0,n)
		{
			set<int> s;
			frj(0,n)
			{
				cin>>mat[i][j];
				s.insert(mat[i][j]);
			}
			if(s.size() != n)
			{
				rows++;
			}
		}
		frj(0,n)
		{
			set<int> s;
			fri(0,n)
			{
				s.insert(mat[i][j]);
				if(i == j)
				{
					trace += mat[i][j];
				}
			}
			if(s.size() != n)
			{
				cols++;
			}
		}
		cout<<"Case #"<<cases<<": "<<trace<<" "<<rows<<" "<<cols<<endl;
		cases++;
	}
    return 0;
}    
