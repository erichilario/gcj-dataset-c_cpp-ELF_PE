#include<stdio.h>

char s[100];
char ans[2000];

int main() {
	int t;
	scanf("%d", &t);
	for( int tt=1; tt<=t; ++tt ) {
		scanf("%s", s);
		int d=0;
		int j=0;
		for( char *ts=s; *ts; ++ts ) {
			if( *ts-'0' < d ) {
				for( int i=0; i<d-*ts+'0'; ++i )
					ans[j++] = ')';
			}
			else if( *ts-'0' > d ) {
				for( int i=0; i<*ts-'0'-d; ++i )
					ans[j++] = '(';
			}
			ans[j++] = *ts;
			d = *ts - '0';
		}
		for( ; d != 0; --d ) ans[j++] = ')';
		ans[j++] = '\0';
		printf("Case #%d: %s\n", tt, ans );
	}
}
