#include<iostream>
#include<string.h>
#include<string>
using namespace std;
int arr[2][1500];
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
	int T;
	cin >> T;
	int a = T;
	while (T--) {
		string s = "";
		int num=0;
		cin >> num;
		int k = 0;
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 1500; j++) {
				arr[i][j] = 0;
			}
		}
		for (int i = 0; i < num; i++) {
			int startT;
			int endT;
			cin >> startT >> endT;
			int tmp = 0;
			int tmp2 = 0;
			if (k == 0) {
				for (int j = startT; j < endT; j++) {
					if (arr[0][j] != 0) {
						tmp = 1;
					}
					if (arr[1][j] != 0) {
						tmp2 = 1;
					}
				}
				if (tmp == 0) {
					for (int j = startT; j < endT; j++) {
						arr[0][j] = 1;
					}
					s += "J";
				}
				else if (tmp2 == 0) {
					for (int j = startT; j < endT; j++) {
						arr[1][j] = 1;
					}
					s += "C";
				}
				else {
					s = "IMPOSSIBLE";
					k = 1;
				}
			}
		}
		cout << "Case #" << a - T << ": " << s << "\n";
	}
	return 0;
}
