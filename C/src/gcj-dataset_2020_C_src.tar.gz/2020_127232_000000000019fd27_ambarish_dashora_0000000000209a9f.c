#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i,tc,q,cl,nl,open,j,e,p;
    char n[100];
    int ar[100];
    char result[50000];
    scanf("%d",&tc);
    for(q=0;q<tc;q++)
    {
        scanf("%s",&n);
        nl=0;open=0;
        for(i=0;n[i]!='\0';i++)
        {
            ar[i]=n[i]-48;
            nl++;
        }
        for(i=0,j=0;i<nl;i++)
        {
            if(open<ar[i])
            {
                e=ar[i]-open;
                for(p=0;p<e;p++)
                {
                    result[j]='(';
                    j++;
                    open++;
                }
            }
            else if(open>ar[i])
            {
                e=open-ar[i];
                for(p=0;p<e;p++)
                {
                    result[j]=')';
                    j++;
                    open--;
                }
            }
            result[j]=ar[i]+48;
            j++;
        }
        while(open>0)
        {
            result[j]=')';
            j++;
            open--;
        }
        result[j]='\0';
        printf("Case #%d: %s \n",q+1,result);
    }
    
    return 0;
}
