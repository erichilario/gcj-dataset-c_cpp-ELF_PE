#include <stdio.h>
#define MAX_N 50
int n_test;
int n;
int k;
int form1[MAX_N + 9][MAX_N + 9];
int form2[MAX_N + 9][MAX_N + 9];
int form3[MAX_N + 9][MAX_N + 9];
int has_ans;
int ans[MAX_N + 9][MAX_N + 9];
int map[MAX_N + 9];
int used[MAX_N + 9];

int func_has_row(int form[MAX_N + 9][MAX_N + 9], int i, int x) {
	for(int j = 1; j <= n; j++) {
		if(form[i][j] == x) {
			return 1;
		}
	}
	return 0;
}

int func_has_col(int form[MAX_N + 9][MAX_N + 9], int j, int x) {
	for(int i = 1; i <= n; i++) {
		if(form[i][j] == x) {
			return 1;
		}
	}
	return 0;
}

void func_fill(int form[MAX_N + 9][MAX_N + 9]) {
	for(int x = 1; x <= n; x++) {
		for(int i = 1; i <= n; i++) {
			if(!func_has_row(form, i, x)) {
				for(int j = 1; j <= n; j++) {
					int jj = (i + j - 2) % n + 1;
					if(!form[i][jj] && !func_has_col(form, jj, x)) {
						form[i][jj] = x;
						break;
					}
				}
			}
		}
	}
}

void func_transform(int form[MAX_N + 9][MAX_N + 9], int tp, int val1, int val2, int val3) {
	map[1] = val1;
	map[2] = val2;
	map[3] = val3;
	for(int i = 1; i <= n; i++) {
		used[i] = 0;
	}
	for(int i = 1; i <= tp; i++) {
		used[map[i]] = 1;
	}
	for(int i = tp + 1; i <= n; i++) {
		for(int j = 1; j <= n; j++) {
			if(!used[j]) {
				map[i] = j;
				used[j] = 1;
				break;
			}
		}
	}
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j <= n; j++) {
			ans[i][j] = map[form[i][j]];
		}
	}
}

int main() {
	scanf("%d", &n_test);
	for(int i_test = 1; i_test <= n_test; i_test++) {
		scanf("%d%d", &n, &k);
		for(int i = 1; i <= n; i++) {
			for(int j = 1; j <= n; j++) {
				form1[i][j] = 0;
				form2[i][j] = 0;
				form3[i][j] = 0;
			}
		}
		for(int i = 1; i <= n - 2; i++) {
			form1[i][i] = 1;
			form2[i][i] = 1;
			form3[i][i] = 1;
		}
		form1[n - 1][n - 1] = 1;
		form2[n - 1][n - 1] = 2;
		form3[n - 1][n - 1] = 2;
		form1[n][n] = 1;
		form2[n][n] = 2;
		form3[n][n] = 3;
		func_fill(form1);
		func_fill(form2);
		func_fill(form3);
		has_ans = 0;
		for(int val1 = 1; val1 <= n; val1++) {
			for(int val2 = 1; val2 <= n; val2++) {
				int val3 = k - val1 * (n - 2) - val2;
				if(val3 < 1 || val3 > n) {
					continue;
				}
				if(val1 == val2 && val1 == val3) {
					has_ans = 1;
					func_transform(form1, 1, val1, val2, val3);
					break;
				}
				if(val1 != val2 && val2 == val3 && n > 3) {
					has_ans = 1;
					func_transform(form2, 2, val1, val2, val3);
					break;
				}
				if(val1 != val2 && val1 != val3 && val2 != val3) {
					has_ans = 1;
					func_transform(form3, 3, val1, val2, val3);
					break;
				}
			}
			if(has_ans) {
				break;
			}
		}
		if(!has_ans) {
			printf("Case #%d: IMPOSSIBLE\n", i_test);
		}
		else {
			printf("Case #%d: POSSIBLE\n", i_test);
			for(int i = 1; i <= n; i++) {
				for(int j = 1; j <= n; j++) {
					printf("%d ", ans[i][j]);
				}
				printf("\n");
			}
		}
	}
	return 0;
}
