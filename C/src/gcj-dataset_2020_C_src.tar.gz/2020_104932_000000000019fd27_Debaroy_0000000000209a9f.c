#include<stdio.h>
int main()
{
    int t=0,i,j,k; char dummy,s[101],ans[100000];
    scanf("%d",&t); scanf("%c",&dummy);
    for(i=1;i<=t;i++)
    {
        scanf("%s",s);  char pch=s[0]; int x=0;
        for(j=0;s[j]!='\0';j++)
        {
            if(j==0)
            {
                for(k=0;k<(s[j]-'0');k++)
                ans[x++]='(';
                ans[x++]=s[j];
            }
            else
            {
                char ch=s[j];
                if(ch>pch)
                {
                    for(k=0;k<ch-pch;k++)
                    ans[x++]='(';
                    ans[x++]=ch;
                }
                else if(ch<pch)
                {
                    for(k=0;k<pch-ch;k++)
                    ans[x++]=')';
                    ans[x++]=ch;
                }
                else
                ans[x++]=ch;
                pch=ch;
            }
            
        }
        for(k=0;k<(pch-'0');k++)
        ans[x++]=')';
        ans[x]='\0';
        printf("Case #%d: %s\n",i,ans);
    }
    return 0;
}

