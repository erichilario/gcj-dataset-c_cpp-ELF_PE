#include <stdio.h>
#include<stdlib.h>
typedef struct node{
    int left;
    int right;
}node;
int isoverlap(node *arr,int l,int r,int j,int *hash){
    int a=0,count=0;
   // printf("%d %d %d",l,r,j);
    for(int i=0;i<j;i++){
     //   printf("%d %d %d",arr[i].left,arr[i].right,hash[i]);
        if(arr[i].left>=r || arr[i].right<=l)continue;
        else{
            a=!hash[i];
            count++;
        }
    }
    if(count<2) return a;
    else return -1;
}
int main() {
	int t,m=1,n,hash[1002];
	scanf("%d",&t);
	while(t--){
	    scanf("%d",&n);
	    node *arr=(node *)malloc(sizeof(node)*n);
	    for(int i=0;i<n;i++){
	        scanf("%d%d",&arr[i].left,&arr[i].right);
	        
	    }
	    int flag=1;
	     for(int i=0;i<n;i++){
	        if(i==0) {hash[0]=0;continue;}
	        hash[i]=isoverlap(arr,arr[i].left,arr[i].right,i,hash);
	        if(hash[i]==-1) {flag=0;break;}
	        
	    }
	    printf("Case #%d: ",m);
	    if(flag){
	    for(int i=0;i<n;i++){
	        if(hash[i]==0) printf("C");
	        else printf("J");
	    }}
	    else printf("IMPOSSIBLE");
	    printf("\n");
	    m++;
	}
	
	return 0;
}
