#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#define rep(E, F) for (E = 0; E < (F); E++)
int get_int();
double get_double();
int get_string(char*, char);
int min(int a, int b) { if (a > b) { return b; } return a; }
int max(int a, int b) { if (a < b) { return b; } return a; }

int main()
{
	int t = get_int(), cc = 1;
	while (t--)
	{
		int i, j, n = get_int(), r[3] = {0, 0, 0};
		int a[n][n];
		rep(i, n) rep(j, n) a[i][j] = get_int() - 1;
		rep(i, n) r[0] += a[i][i] + 1;
		rep(i, n)
		{
			int f[n];
			rep(j, n) f[j] = 0;
			rep(j, n) if (f[a[i][j]] == 1) break; else f[a[i][j]] = 1;
			if (j < n) r[1]++;
		}
		rep(i, n)
		{
			int f[n];
			rep(j, n) f[j] = 0;
			rep(j, n) if (f[a[j][i]] == 1) break; else f[a[j][i]] = 1;
			if (j < n) r[2]++;
		}
		printf("Case #%d: %d %d %d\n", cc++, r[0], r[1], r[2]);
	}

	return 0;
}

int get_string(char* b, char t)
{
	int i = 0;
	b[i++] = getchar();
	while (b[i - 1] != t) b[i++] = getchar();
	b[i - 1] = '\0';
	return i - 1;
}

double get_double()
{
	double ret = 0;
	char c = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF) return EOF;
		if (c >= '0' && c <= '9') { sgn = 1; break; }
		if (c == '-')
		{
			c = getchar();
			if (c < '0' || c > '9') continue;
			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = ret*10 + c - '0';
		c = getchar();
		if (c == '.')
		{
			double pos = 0.1;
			c = getchar();
			while (c >= '0' && c <= '9')
			{
				ret += pos*(c - '0');
				pos /= 10;
				c = getchar();
			}
			return sgn*ret;
		}
		else if (c < '0' || c > '9') return sgn*ret;
	}
}

int get_int()
{
	int ret = 0;
	char c = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF) return EOF;
		if (c >= '0' && c <= '9') { sgn = 1; break; }
		if (c == '-')
		{
			c = getchar();
			if (c < '0' || c > '9') continue;
			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = ret*10 + c - '0';
		c = getchar();
		if (c < '0' || c > '9') return sgn*ret;
	}
}

