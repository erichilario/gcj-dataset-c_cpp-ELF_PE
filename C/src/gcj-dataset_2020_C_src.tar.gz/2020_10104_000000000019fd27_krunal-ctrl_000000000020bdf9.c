#include<stdio.h>

void main(){
    int T;
    scanf("%d",&T);
    for(int i=1;i<=T;i++){
        int N;
        char s[12];
        scanf("%d",&N);
        int S[N],e[N];
        for(int j=0;j<N){
            scanf("%d %d",&s[i],&e[i]);
        }
        
        int imp=0;
    //check for imposible

        for(int j=0;j<N-1;j++){
            for(int k=j;k<N;k++){
                if(e[j]>s[k])
                    imp=1;
                else{
                    imp=0;
                    goto a;
                }
            }
        }
        a:
        if(imp==0){
            printf("Case #%d: IMPOSSIBLE\n",i);
            return;
        }
        S[i]='C';
        for(int j=0;j<N-1;j++){
                if(j<i && s[i]>=e[j]){
                    S[j]='C';
                }
                else{
                    S[j]='J';
                }
                if(j>i){
                    if(e[i]>s[j]){
                        S[j]='C';
                    else
                        S[j]='J';
                }
            }
        }
        printf("Case #%d: %s\n",i,S);
        
        
    
    }
}
