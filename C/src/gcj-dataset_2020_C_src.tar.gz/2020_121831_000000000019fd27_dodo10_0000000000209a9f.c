#include<stdio.h>
#include<stdlib.h>

void stackAdjust(int old, int new) {

    while (old != new) {

        if (old < new) {
            // increase
            printf("(");
            old++;
        } else {
            // decrease, old > new
            printf(")");
            old--; 
        }
    }
}

void doStuff(char* cc) {

    int pos = 0;
    int stackDepth = 0;

    while (cc[pos] != '\0') {
        int depth = cc[pos] - '0';
        stackAdjust(stackDepth, depth);
        stackDepth = depth;
        printf("%d", depth);
        pos++; 
    }

    stackAdjust(stackDepth, 0);
    printf("\n");

}

int main(void) {

    int n, i=0;
    char cc[101] = {0};


    scanf("%d", &n);

    while (n--) {

        scanf("%s", cc);
        printf("Case #%d: ", ++i);

        doStuff(cc);
    }

    return 0;
}


