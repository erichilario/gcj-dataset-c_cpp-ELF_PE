#include <bits/stdc++.h>
using namespace std;

#define ll long long int
ll const mod = 1e9 + 7;

ll power(ll x, ll y, ll p){ //x^y % p
    ll res = 1;      // Initialize result 
    x = x % p;  // Update x if it is more than or equal to p 
    while (y > 0) {
        if (y & 1) // If y is odd, multiply x with result 
        res = (res*x) % p; 
        // y must be even now 
        y = y>>1; // y = y/2 
        x = (x*x) % p; 
    } 
    return res; 
}

int main() {
    
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int t;
    cin>>t;
    for(int m=1;m<=t;m++)
    {
        int n;
        cin>>n;
        int a[n][n];
        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)
                cin>>a[i][j];
        
        int h[n+1] {0};
        int r=0, c=0;
        for(int i=0;i<n;i++)
        {
            memset(h, 0, sizeof(h));
            for(int j=0;j<n;j++)
            {
                h[a[i][j]]++;
            }
            for(int k=1;k<=n;k++)
                if(h[k]>1)  
                {
                    r++;
                    break;
                }
        }
        for(int j=0;j<n;j++)
        {
            memset(h, 0, sizeof(h));
            for(int i=0;i<n;i++)
            {
                h[a[i][j]]++;
            }
            for(int k=1;k<=n;k++)
                if(h[k]>1)
                {
                    c++;
                    break;
                }
        }
        int s=0;
        for(int i=0;i<n;i++)
            s+=a[i][i];
        
        cout<<"Case #"<<m<<":"<<" "<<s<<" "<<r<<" "<<c<<endl;
    }
    
	// your code goes here
	return 0;
}

