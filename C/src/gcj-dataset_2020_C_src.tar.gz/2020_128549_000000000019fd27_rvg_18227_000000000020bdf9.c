#include <stdio.h>
#define SIZE 1000

struct task
{
    int s, e, key;
    char p;
} a [SIZE];

int main ()
{
    int t, n, b, c, flag, l = 0;
    scanf ("%d", &t);
    while (l != t)
    {
        scanf ("%d", &n);
        for (int i = 0; i < n; i ++)
        {
            scanf ("%d %d", &a [i].s, &a [i].e);
            a [i].key = i;
            a [i].p = '\0';
        }
        b = c = flag = 0;
        printf ("Case #%d: ", l + 1);
        
        for (int i = 0; i < n - 1; i ++)
        {
            for (int j = i + 1; j < n; j ++)
            {
                if (a [i].s > a [j].s)
                {
                    struct task tmp = a [i];
                    a [i] = a [j];
                    a [j] = tmp;
                }
            }
        }
        
        for (int i = 0; i < n; i ++)
        {
            if (a [i].s >= b)
            {
                b = a [i].e;
                a [i].p = 'C';
            }
            else if (a [i].s >= c)
            {
                c = a [i].e;
                a [i].p = 'J';
            }
            else
            {
                flag = 1;
                break;
            }
        }
        
        l ++;
        
        if (flag)
        {
            printf ("IMPOSSIBLE\n");
            continue;
        }
        for (int i = 0; i < n; i ++)
        {
            for (int j = 0; j < n; j ++)
            {
                if (i == a [j].key)
                {
                    printf ("%c", a [j].p);
                    break;
                }
            }
        }
        printf ("\n");
    }
}
