#include<stdio.h>

int main()
{
	int testCase,x=1;
	printf("Enter no. of test cases: ");
	scanf("%d",&testCase);
	while(testCase)
	{
		int n;
		printf("\nEnter n: ");
		scanf("%d",&n);
		int latsq[n][n],trace=0,rowcount=0,colcount=0,flag=0;
		printf("\nEnter elements:\n");
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
				latsq[i][j]=i+1;
		}
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
				printf("%d\t",latsq[i][j]);
			printf("\n");
		}
		
		for(int i=0;i<n;i++)
		{
			trace+=latsq[i][i];
			for(int j=0;j<n;j++)
			{
				for(int k=0;k<n;k++)
				{
					if(j!=k && latsq[i][j]==latsq[i][k])
					{
						rowcount++;
						flag=1;
						break;
					}
				}
				if(flag==1)
					break;
			}
			flag=0;	
		}
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				for(int k=0;k<n;k++)
				{
					if(j!=k && latsq[j][i]==latsq[k][i])
					{
						colcount++;
						flag=1;
						break;
					}
				}
				if(flag==1)
					break;
			}
			flag=0;	
		}
		
		printf("Case #%d: %d %d %d\n",x,trace,rowcount,colcount);
		x++;
		testCase--;
	}
	return 0;
}
