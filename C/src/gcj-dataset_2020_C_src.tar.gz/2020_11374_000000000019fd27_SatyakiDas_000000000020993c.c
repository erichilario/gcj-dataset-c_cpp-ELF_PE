#include<stdio.h>
#include<stdlib.h>

int main(void) {
    int T,k=0;
    scanf("%d",&T);

    while(T--){
        int n;
        scanf("%d",&n);

        int a[n][n];

        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)
                scanf("%d",&a[i][j]);

        int trace=0;

        for(int i=0;i<n;i++)
            trace+= a[i][i];

        int rowCount=0,columnCount=0;

        for(int k=0;k<n;k++)
        {

            for(int i=0;i<n;i++)
            {
                for(int j=i+1;j<n;j++)
                {
                    if(a[k][i]==a[k][j]){
                        rowCount++;
                        i=n;
                        j=n;
                    }
                }
            }
        }
        for(int k=0;k<n;k++)
        {
            for(int i=0;i<n;i++)
            {
                for(int j=i+1;j<n;j++)
                {
                    if(a[i][k]==a[j][k]){
                        columnCount++;
                        i=n;
                        j=n;
                    }
                }
            }
        }
        printf("\nCase #%d: %d",++k,trace);
        printf(" %d ",rowCount);
        printf("%d",columnCount);
    }
    return 0;
}

