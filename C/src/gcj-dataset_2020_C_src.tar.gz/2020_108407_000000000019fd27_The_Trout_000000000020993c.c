#include <stdio.h>
#define MAX 105

int m[MAX][MAX];
int h[MAX];

void set(int N) {
  for (int i = 0; i <= N; i++)
    h[i] = 0;
}

int main() {
  int T, N, trace, row, col;
  scanf("%d", &T);
  for (int k = 1; k <= T; k++) {
    scanf("%d", &N);
    for (int i = 0; i < N; i++)
      for (int j = 0; j < N; j++)
        scanf("%d", &m[i][j]);
    trace = row = col = 0;
    for (int i = 0; i < N; i++)
      trace += m[i][i];
    for (int i = 0; i < N; i++) {
      set(N);
      for (int j = 0; j < N; j++)
        if (h[m[i][j]]) {
          row++;
          break;
        } else
          h[m[i][j]] = 1;
    }
    for (int j = 0; j < N; j++) {
      set(N);
      for (int i = 0; i < N; i++)
        if (h[m[i][j]]) {
          col++;
          break;
        } else
          h[m[i][j]] = 1;
    }

    printf("Case #%d: %d %d %d\n", k, trace, row, col);
  }
  return 0;
}

