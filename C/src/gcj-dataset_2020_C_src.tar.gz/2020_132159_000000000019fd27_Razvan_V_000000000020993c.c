#include <stdio.h>

void solve(int case_no) {
	int i, j, N, k = 0, r = 0, c = 0;
	int a[101][101], lines[101][101], cols[101][101];

	scanf("%d", &N);


	for(i = 1; i <= N; i++) {
		for(j = 1; j <= N; j++) {
			lines[i][j] = cols[i][j] = 0;
			scanf("%d", &a[i][j]);
		}
	}

	for(i = 1; i <= N; i++) {
	  for(j =1; j <= N; j++) {
			if(lines[i][a[i][j]] == 0)
				lines[i][a[i][j]] ++;
			else {
				r++;
				break;
			}
		}
	}


	for(j = 1; j <= N; j++) {
	  for(i = 1; i <= N; i++) {
			if(cols[a[i][j]][j] == 0)
				cols[a[i][j]][j] ++;
			else {
				c++;
				break;
			}
		}
	}

	for(i = 1; i <= N; i++)
		k += a[i][i];

	printf("Case #%d: %d %d %d\n", case_no, k, r, c);
}

int main() {
	int T, i;
	
	scanf("%d", &T);
	for(i = 1; i <= T; i++)
		solve(i);

	return 0;
}
