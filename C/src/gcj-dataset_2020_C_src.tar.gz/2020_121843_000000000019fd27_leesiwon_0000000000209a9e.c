#include<stdio.h>
int t,b;
char x[101];
int main(){
	scanf("%d%d",&t,&b);
	for(int i=0;i<t;i++){
		for(int j=1;j<=b;j++)x[j]=' ';
		int count=1,n=1;
		while(count){
			if(n%10==1&&n!=1){
				printf("1");
				int a;
				scanf("%d",&a);
				if(x[1]==x[b]){
					int c;
					int che=1;
					for(int j=1;j<=b;j++){
						if(x[j]!=x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
							che=j;
							j=b+1;
						}	
					}
					printf("%d",che);
					scanf("%c\n",&c);
					if(x[1]!=a+48){
						for(int j=1;j<=b;j++){
				    		if(x[j]==x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
				    			if(x[j]=='1')x[j]='0';
			    				else x[j]='1';
		    				}	
			    		}
					}
					if(x[che]!=c+48){
						for(int j=1;j<=b;j++){
		    				if(x[j]!=x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
		    					if(x[j]=='1')x[j]='0';
	    						else x[j]='1';
	    					}	
	    				}
    				}
    			}
				else {
					int c;
					int che=1;
					for(int j=1;j<=b;j++){
						if(x[j]==x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
							che=j;
							break;
						}	
					}
					printf("%d",che);
					scanf("%d",&c);
					if(x[1]!=a+48){
						for(int j=1;j<=b;j++){
				    		if(x[j]!=x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
			    				if(x[j]=='1')x[j]='0';
			    				else x[j]='1';
				    		}	
		    			}
					}
					if(x[che]!=c+48){
						for(int j=1;j<=b;j++){
			    			if(x[j]==x[b-j+1]&&x[j]!=' '&&x[b-j+1]!=' '){
			    				if(x[j]=='1')x[j]='0';
			    				else x[j]='1';
			    			}	
		    			}
		    		}
			    }
				n+=2;
			}
			else {
		        int c=0;
				for(int j=1;j<=b;j++){
					if(x[j]==' '){
						printf("%d",j);
						scanf("%d",&c);
						x[j]=c+48;
						j=1000000;
					}
				}
				int ch=0;
				for(int j=1;j<=b;j++)if(x[j]==' ')ch++;
				if(ch==0)break;
				n++;
			}
		}
		puts(x+1);
		char ans;
		scanf(" %c",&ans);
		if(ans=='N')return 0;
	}
}

