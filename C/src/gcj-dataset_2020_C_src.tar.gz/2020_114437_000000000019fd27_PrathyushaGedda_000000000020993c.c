#include<stdio.h>
#include<conio.h>
int main()
{
    int T,N,a[10][10],temp;
    scanf("%d",T)
    scanf("%d",N);
    for(int i=0;i<N;i++)
    {
        for (int j=0;j<N;j++){
            scanf("%d",&a[N][N]);
        }
    }
    for(int i=0;i<rows;i++)
    {
        temp=temp+a[N][N];
    }
    printf("\n%d",temp);
    return 0;
}
