#include <stdio.h>

int main(){
	int t;
	char arr[110] = {0};
	
	scanf("%d", &t);
	for(int cnt=1; cnt<=t; cnt++){
		scanf("%s", arr);
		
		printf("Case #%d: ", cnt);
		
		int idx=1, pre = arr[0]-'0';
		for(int i=0; i<pre; i++){
			printf("(");
		}
		printf("%d", pre);
		
		while(arr[idx] != '\0'){
            int num = arr[idx] - '0';
			if(num > pre){
				int chr = num - pre;
				for(int i=0; i<chr; i++){
					printf("(");
				}
			}
			else if(num < pre){
				int chr = pre - num;
				for(int i=0; i<chr; i++){
					printf(")");
				}
			}
			printf("%d", num);
			pre = num;
			idx++;
		}

        for(int i=0; i<pre; i++){
            printf(")");
        }
        printf("\n");
	}
}
