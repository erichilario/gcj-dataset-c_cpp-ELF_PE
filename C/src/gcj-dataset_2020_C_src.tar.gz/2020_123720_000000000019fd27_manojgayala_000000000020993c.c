#include <stdio.h>
#include <stdlib.h>
#define SIZE 100
void main()
{
int i,t;
scanf("%d",&t);

for(i=0;i<t;i++)
{
	int n;
	scanf("%d",&n);
	
	int i1,i2;
	int s,r_count=0,c_count=0;
	int trace=0;
	
	int b[SIZE][SIZE]={0};
	int c_check[SIZE]={0};
	int r_check[SIZE]={0};
	
	for(i2=0;i2<n;i2++)
	{
	int a[SIZE]={0};
	for(i1=0;i1<n;i1++)
	{
		scanf("%d",&s);
		
		if(c_check[i1]==0)
		{
		
		if(b[s-1][i1]!=0)
		{
			c_count++;
			c_check[i1]++;
		}
		b[s-1][i1]++;
		}
		
		if(r_check[i2]==0)
		{
		
		if(a[s-1]!=0)
		{
			r_count++;
			r_check[i2]++;
		}
		a[s-1]++;
		}
		if(i1==i2)
		{
			trace+=s;
		}
		
	}
	
	}
	printf("\nCase #%d: %d %d %d\n",i+1,trace,r_count,c_count);
}
}
