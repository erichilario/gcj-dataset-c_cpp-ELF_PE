#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int t;
    scanf("%d", &t);
    for (int k = 1; k <= t; k++) {
        char a[128];
        char result[10240];
        scanf("%s", a);
        int len = strlen(a);
        memset(result, 0, sizeof(result));
        int j = 0;
        int last_d = 0;
        for (int i = 0; i < len; i++) {
            if (a[i] > '0' + last_d) {
                memset(result + j, '(', a[i] - '0' - last_d);
                j += a[i] - '0' - last_d;
                last_d = a[i] - '0';
            } else if (a[i] < '0' + last_d) {
                memset(result + j, ')', last_d + '0' - a[i]);
                j += last_d + '0' - a[i];
                last_d = a[i] - '0';
            }
            result[j++] = a[i];
        }

        if (last_d) {
            memset(result + j, ')', last_d);
            j += last_d;
        }
        result[j] = 0;

        printf("Case #%d: %s\n", k, result);
    }
    return 0;
}

