int main(void) { 
 
 int cases;
 cases = scanf("%d", &cases);
 int i = 0;
 
 
 while (cases--) {
     i++; 
     int n;
     scanf("%d", &n);
     int r=0; int c=0;
     
     int kResult = 0;
     int rResult = 0;
     int cResult = 0;
     
     int* rowHash = calloc(n, sizeof(int));
     int* colHash = calloc(n, sizeof(int));

     
     while (r < n) {
         while (c < n) {
             
             int currNum;
             scanf("%d", &currNum);
             
             // 
             if (r == c) {
                 kResult += currNum;
             }
             
             // Check if seen in row
             if (rowHash[currNum-1]++) {
                 rResult += 1;
             }
             
             // Check if seen in col
             if (colHash[currNum-1]++) {
                 cResult += 1;
             }
             
             c++; 
         }
         r++;
         c=0;
         memset(rowHash, 0, n);
         
     }
     
     // Print results
     printf("Case #%d: %d %d %d\n", i, kResult, rResult, cResult);
     
     free(rowHash);
     free(colHash);
     

 }
 
 return 0;
}
