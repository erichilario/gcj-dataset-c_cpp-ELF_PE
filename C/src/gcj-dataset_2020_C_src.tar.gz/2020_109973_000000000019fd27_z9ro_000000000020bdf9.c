#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int cmp(const void *, const void * );
typedef struct Node tn;

struct Node{
    int s;
    int e;
    int idx;
};


int main(){
    int t, n;
    char ans[1005];
    tn se[1005];
    scanf("%d", &t);
    for(int k=0; k<t; k++){
        int pans,ce,je;
        int flag = 1;
        pans = ce = je = 0;
        scanf("%d", &n);
        for(int i=0; i<n; i++){
            scanf("%d %d", &(se[i].s), &(se[i].e));
            se[i].idx = i;
        }
        qsort(se, n, sizeof(tn), cmp);

        for(int i=0; i<n; i++){
            if(se[i].s < ce){
                if(se[i].s < je){
                    flag = 0;
                    break;
                }
                je = se[i].e;
                ans[se[i].idx] = 'J';
            }else{
                ce = se[i].e;
                ans[se[i].idx] = 'C';
            }
        }
        ans[n] = '\0';


        if(flag){
            printf("Case #%d: %s\n", k+1, ans);
        }else{
            printf("Case #%d: %s\n", k+1, "IMPOSSIBLE");
        }
        
    }
    return 0;
}

int cmp(const void * a, const void * b){
    // >
    tn* pa = (tn *)a;
    tn* pb = (tn *)b;
    return pa->s > pb->s;
}
