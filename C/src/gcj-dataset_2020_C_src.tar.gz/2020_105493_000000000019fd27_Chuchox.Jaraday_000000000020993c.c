#include <stdio.h>

int main(void){
    int cases, casos, n;
    int traza, cols, rows;
    int i, j, k;
    int matriz[101][101];

    scanf("%d\n",&cases);
    for(casos=1;casos<=cases;casos++){
        scanf("%d\n",&n);
        for(i=0;i<n;i++){
            for(j=0;j<n;j++){
                scanf("%d",&matriz[i][j]);
            }
        }

        traza=0;
        for(i=0;i<n;i++){
            traza+=matriz[i][i];
        }

        rows = 0;
        for(i=0;i<n;i++){
            for(j=0;j<(n-1);j++){
                for(k=j+1;k<n;k++){
                    if(matriz[i][j] == matriz[i][k]){
                        rows++;
                        j=k=n;
                    }
                }
            }
        }

        cols = 0;
        for(i=0;i<n;i++){
            for(j=0;j<(n-1);j++){
                for(k=j+1;k<n;k++){
                    if(matriz[j][i] == matriz[k][i]){
                        cols++;
                        j=k=n;
                    }
                }
            }
        }

        printf("Case #%d: %d %d %d\n",casos,traza,rows,cols);
    }

    return(0);
}

