#include <stdlib.h>
#include <stdio.h>

#define BUF_SIZE 20

int main()
{
    char* buffer = NULL;
    int read_size;

    getline(&buffer,&read_size,stdin);

    int num_tests = atoi(buffer);
    printf(buffer);
    for (int t = 0; t < num_tests; t++)
    {
       getline(&buffer,&read_size,stdin);
       printf(buffer);
    }
    free(buffer);
}
