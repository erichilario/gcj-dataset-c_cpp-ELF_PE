#include<stdio.h>
#include<string.h>

int map[100][100];
int vis[101];

int main()
{
    int T,n,i,j,k,cases=1;
    scanf("%d",&T);
    while(T--)
    {
        int a=0,b=0,c=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            char flag=1;
            memset(vis,0,sizeof(vis));
            for(j=0;j<n;j++)
            {
                scanf("%d",&map[i][j]);
                if(vis[map[i][j]]==0)
                    vis[map[i][j]]=1;
                else
                {
                    if(flag)b++;
                    flag=0;
                }
                if(i==j)a+=map[i][j];
            }

        }

        for(i=0;i<n;i++)
        {
            memset(vis,0,sizeof(vis));
            for(j=0;j<n;j++)
            {
                if(vis[map[j][i]]==0)
                    vis[map[j][i]]=1;
                else
                {
                    c++;
                    break;
                }
            }
        }
        printf("Case #%d: %d %d %d\n",cases++,a,b,c);
    }

    return 0;
}

