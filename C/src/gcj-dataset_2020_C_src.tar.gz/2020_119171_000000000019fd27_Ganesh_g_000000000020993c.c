#include<stdio.h>
#include<string.h>
#include<stdbool.h>
int main()
{
    int t,i,j,n,trace,q,rrep,crep,a[100][100];
    bool r[100][100],c[100][100],rr[100],cr[100];
    scanf("%d",&t);
    for(q=1;q<=t;q++)
    {
        trace=0;
        rrep=crep=0;
        memset(r,false,sizeof(r));
        memset(c,false,sizeof(c));
        memset(rr,0,sizeof(rr));
        memset(cr,0,sizeof(cr));
        scanf("%d",&n);
        for(i=0;i<n;i++)
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
            if(r[i][a[i][j]-1]==true)
            rr[i]=1;
            if(c[j][a[i][j]-1]==true)
            cr[j]=1;
            r[i][a[i][j]-1]=true;
            c[j][a[i][j]-1]=true;
        }
        for(i=0;i<n;i++)
        rrep+=rr[i];
        for(i=0;i<n;i++)
        crep+=cr[i];
        for(i=0;i<n;i++)
        trace+=a[i][i];
        if(rrep==1)
        rrep=0;
        if(crep==1)
        crep=0;
        if(q!=t)
        printf("Case #%d: %d %d %d \n",q,trace,rrep,crep);
        else
        printf("Case #%d: %d %d %d ",q,trace,rrep,crep);
    }
    return 0;
}
