#include<stdio.h>
#include<string.h>
int main()
{
	int n;
	int x=1;
	scanf("%d",&n);
	while(n--)
	{
		char a[102];
		memset(a,0,102*sizeof(char));
		scanf("%s",a);
		int i=0,f=0,g=1;
		printf("Case #%d: ",x);
		while(a[i]!='\0')
		{
			if(a[i]=='1'&&f==0)
			{
				printf("(%c",a[i]);
				f=1;g=0;
				i++;
				continue;
			}
			if(a[i]=='1'&&f==1)
			{
				g=0;
				printf("%c",a[i]);
				i++;
				continue;
			}
			if(a[i]=='0'&&g==0)
			{
				printf(")%c",a[i]);
				g=1;f=0;
				i++;
				continue;
			}
			if(a[i]=='0'&&g==1)
			{
				printf("%c",a[i]);
				f=0;
				i++;
				continue;
			}	
		 } 
		 if(f==1)
		 printf(")");
		 printf("\n");
	}
	return 0;
}
