#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i,j,tc,n,q,r,c,d,k;
    //int *map;
    //int **m;
    scanf("%d",&tc);
    for(q=0;q<tc;q++)
    {
        scanf("%d",&n);
        r=0;c=0;d=0;
        //m=(int**)malloc(sizeof(int*)*n);
        //map=(int*)malloc(sizeof(int)*n);
        int map[n];
        int m[n][n];
        for(i=0;i<n;i++)
        {
            //m[i]=(int*)malloc(sizeof(int)*n);
            for(j=0;j<n;j++)
            {
                scanf("%d",&m[i][j]);
            }
        }

        
        for(i=0;i<n;i++)
        {
                    for(k=0;k<n;k++)
                    {
                        map[k]=0;
                    }
            for(j=0;j<n;j++)
            {
                map[m[i][j]-1]++;
                if(map[m[i][j]-1]>1) 
                {	
                    r++;
                    break;
                }
            }
        }
        for(j=0;j<n;j++)
        {
                    for(k=0;k<n;k++)
                    {
                        map[k]=0;
                    }
            for(i=0;i<n;i++)
            {
                
                map[m[i][j]-1]++;
                if(map[m[i][j]-1]>1) 
                {
                    c++;
                    break;
                }
            }
        }
        for(i=0,j=0;i<n;i++,j++)
        {
            d=d+m[i][j];
        }
       /* free(map);
        for(i=0;i<n;i++)
        {
            free(m[i]);
        }
        free(m); */
        if(q+1==tc) printf("Case #%d: %d %d %d ",q+1,d,r,c);
        else printf("Case #%d: %d %d %d \n",q+1,d,r,c);
    }
    return 0;
}
