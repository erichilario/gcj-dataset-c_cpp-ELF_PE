#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i=0;i<(n);i++)
#define REP(i,n) for(int i=1;i<=(n);i++)
typedef long long ll;
typedef pair<int,int> pii;

void solve(int index){
    int n,k,r,c;
    cin>>n;
    vector<vector<int>> mat;
    k=0;r=0;c=0;
    rep(i,n){
        vector<int> v(n,0);
        rep(j,n)cin>>v[j];
        mat.push_back(v);
    }
    rep(i,n){
        k+=mat[i][i];
    }

    rep(i,n){
      set<int> s;
      rep(j,n)s.insert(mat[i][j]);
      if(s.size()!=n) r++; 
    }
    rep(i,n){
      set<int> s;
      rep(j,n) s.insert(mat[j][i]);
      if(s.size()!=n) c++; 
    }
    cout<<"Case #"<<index+1<<": "<<k<<" "<<r<<" "<<c<<endl;
}

int main(){
    int t;cin>>t;

    rep(i,t){
        solve(i);
    }

    return 0;
}
