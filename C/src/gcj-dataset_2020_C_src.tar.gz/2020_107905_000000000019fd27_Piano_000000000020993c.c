#include<stdio.h>

int main(){
    int t, u;

    scanf("%d", &t);
    for (u = 1; u <= t; ++u){
        int n, m, trace = 0, i, j;
        char row[100][100] = {}, col[100][100] = {}, fr[100] = {}, fc[100] = {}, r = 0, c = 0;

        scanf("%d", &n);
        for (i = 0; i < n; ++i){
            for (j = 0; j < n; ++j){
                scanf("%d", &m);
                if (i == j)
                    trace += m;
                if (row[i][m])
                    fr[i] = 1;
                if (col[j][m])
                    fc[j] = 1;
                row[i][m] = col[j][m] = 1;
            }
        }
        for (i = 0; i < n; ++i){
            r += fr[i];
            c += fc[i];
        }
        printf("Case #%d: %d %d %d\n", u, trace, r, c);
    }
}
