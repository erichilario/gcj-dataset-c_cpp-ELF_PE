#include <stdio.h>
#include <string.h>

int main() {
     fflush(stdout);
  int t,b; scanf("%d%d", &t,&b);
 fflush(stdout);

  for (int id = 1; id <= t; ++id) {
  
  int f=0;
  char arr[1000];
  int a=1;int j=1;
  while(j<=140)
  {
      printf("%d\n",j%10);
      fflush(stdout);
      scanf("%c",&arr[j]);
      fflush(stdout);
      j++;
      
  }
  }
  /*
  
  /*
  if(b==10)
  {
      for(int i=3*b+1;i<=4*b;i++)
      {
         printf("%c",arr[i]);
      }
      fflush(stdout);
      char ch;
      scanf("%c",&ch);
      
      if(ch=='N')
      {
          f=1;
          break;
      }
      else
      {
          continue;
      }
      
      
      
  }
  else
  {
      f=1;
      break;
  }
  
  if(f==1)
  break;
  
  */
  

  return 0;
}
