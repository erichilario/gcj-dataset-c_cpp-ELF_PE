#include<stdio.h>
#include<string.h>
int main()
{
    int t,i,j,n,trace,q,rrep,crep,a[100][100],r[100][100],c[100][100];
    scanf("%d",&t);
    for(q=1;q<=t;q++)
    {
        trace=0;
        scanf("%d",&n);
        memset(r,0,sizeof(r));
        memset(c,0,sizeof(c));
        for(i=0;i<n;i++)
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
            r[i][a[i][j]-1]++;
            c[j][a[i][j]-1]++;
        }
        rrep=crep=0;
        for(i=0;i<n;i++)
        for(j=0;j<n;j++)
        if(rrep<r[i][j])
        rrep=r[i][j];
        for(i=0;i<n;i++)
        for(j=0;j<n;j++)
        if(crep<c[i][j])
        crep=c[i][j];
        for(i=0;i<n;i++)
        trace+=a[i][i];
        if(rrep==1)
        rrep=0;
        if(crep==1)
        crep=0;
        if(q!=t)
        printf("Case #%d: %d %d %d \n",q,trace,rrep,crep);
        else
        printf("Case #%d: %d %d %d ",q,trace,rrep,crep);
    }
    return 0;
}
