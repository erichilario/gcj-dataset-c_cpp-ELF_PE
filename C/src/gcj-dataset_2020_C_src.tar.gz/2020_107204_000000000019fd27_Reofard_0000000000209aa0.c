#include<stdio.h>
int main()
{
    int n,k,t,i,j,count;
    scanf("%d",&t);
    for(count=0;count<t;count++)
    {
        scanf("%d %d",&n,&k);
        printf("Case #%d: %s\n",i+1,k%n==0?"POSSIBLE":"IMPOSSIBLE");
        if(k%n==0)
		{
            for(i=1;i<=n;i++)
            {
                for(j = (k/n)-i; j < (k/n)-i+n; j++)
                {
					int temp =j%n+1;
					if(temp<=0)temp+=n;
                    printf("%d ",temp);
                }
                printf("\n");
            }
        }
    }
    return 0;
}
