#include <stdio.h>
#define SIZE 100

int main ()
{
    int t, n, a [SIZE][SIZE], ch [SIZE], k, r, c, l = 0;
    scanf ("%d", &t);
    while (l != t)
    {
        scanf ("%d", &n);
        for (int i = 0; i < n; i ++)
        {
            ch [i] = -1;
            for (int j = 0; j < n; j ++)
                scanf ("%d", &a[i][j]);
        }
        k = r = c = 0;
        
        for (int  i = 0; i < n; i ++)
            k += a [i][i];
        
        for (int i = 0; i < n; i ++)
        {
            for (int j = 0; j < n; j ++)
            {
                if (ch [a [i][j] - 1] == -1)
                    ch [a [i][j] - 1] = 0;
                else
                {
                    r ++;
                    break;
                }
            }
            for (int j = 0; j < n; j ++)
                ch [j] = -1;
        }
        
        for (int i = 0; i < n; i ++)
        {
            for (int j = 0; j < n; j ++)
            {
                if (ch [a [j][i] - 1] == -1)
                    ch [a [j][i] - 1] = 0;
                else
                {
                    c ++;
                    break;
                }
            }
            for (int j = 0; j < n; j ++)
                ch [j] = -1;
        }
        
        printf ("Case #%d: %d %d %d\n", l + 1, k, r, c);
        
        l ++;
    }
}
