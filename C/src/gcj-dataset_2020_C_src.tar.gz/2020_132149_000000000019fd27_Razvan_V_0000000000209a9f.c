#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void solve(int case_no) {
	 char s[103], s_read[100];
	 int d_curr, d_next, k = 0, i, j;

	 fgets(s, 101, stdin);
	 strcpy(s + strlen(s) - 1,"\0");

	 printf("Case #%d: ",case_no);
	
	 for(i = 0; i < strlen(s); i++) {
	 	d_curr = s[i] - '0';

	 	if((d_curr - k) > 0)
	 		for(j = 0; j < (d_curr - k); j++) {
	 			printf("(");
	 		}
	    else 
	    	for(j = 0; j > (d_curr - k); j--) {
	 			printf(")");
	 		}
	 	k = d_curr;

	 	printf("%c", s[i]);

	 	if(i < (strlen(s) - 1)) {
	 		d_next = s[i + 1] - '0';
	 		if(d_next < d_curr) {
	 			for(j = 0; j < (d_next - d_curr); j++) {
	 				printf(")");
	 			}
	 		}
	 	}
	 	else {
	 		for(j = 0; j < d_curr; j++) {
	 			printf(");");
	 		}
	 	}
	 	
	 }
	 printf("\n");
}

int main() {

	int T, i;
	char c;
	
	scanf("%d", &T); fgetc(stdin);
	for(i = 1; i <= T; i++) {
		solve(i);
	}

	return 0;
}
