#include <stdio.h>
int array[100][100];
int n;
int findcol(int j)
{
    int flag=0;
    int i,k;
    int repeat[100];
    for(i=0;i<n;i++)
    {
        repeat[i]=0;
    }
    for(i=0; i<n; i++)
    {
        for(k=0; k<n; k++)
        {
            if(array[i][j]==k+1)
            {
                repeat[k]++;
            }
            if(repeat[k]>1)
            {
                return flag=1;
            }
        }
    }
}
int findrepeat(int i)
{
    int flag=0;
    int j,k;
    int repeat[100];
    for(j=0;j<n;j++)
    {
        repeat[j]=0;
    }
    for(j=0; j<n; j++)
    {
        for(k=0; k<n; k++)
        {
            if(array[i][j]==k+1)
            {
                repeat[k]++;
            }
            if(repeat[k]>1)
            {
                return flag=1;
            }
        }
    }
}
int main()
{
    int test;
    int p=1;
    int i,j,k;
    scanf("%d",&test);
    while(p<=test)
    {
        int row=0,col=0;//計算重複
        scanf("%d",&n);
        for(i=0; i<n; i++)
        {
            for(j=0; j<n; j++)
            {
                scanf("%d",&array[i][j]);
            }
        }
        int tracesum=0;
        for(i=0;i<n;i++)
        {
            tracesum=array[i][i]+tracesum;
        }
        for(i=0;i<n;i++)
        {
            if(findrepeat(i)==1)
            {
                row++;
            }
        }
        for(j=0;j<n;j++)
        {
            if(findcol(j)==1)
            {
                col++;
            }
        }
        printf("Case #%d: %d %d %d\n",p,tracesum,row,col);
        p++;


    }
    //陣列存完
}

