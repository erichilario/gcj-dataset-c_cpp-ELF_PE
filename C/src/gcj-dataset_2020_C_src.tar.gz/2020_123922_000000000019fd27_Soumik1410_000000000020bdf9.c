#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<limits.h>
  
int partition (int *start, int *end, int *order, int low, int high)  
{  
    int pivot = start[high]; 
    int i = (low - 1); 
    int temp1,temp2,temp3;
  
    for (int j = low; j <= high - 1; j++)  
    {  
        if (start[j] < pivot)  
        {  
            i++; 
            temp1=start[i];
            start[i]=start[j];
            start[j]=temp1;
            temp2=end[i];
            end[i]=end[j];
            end[j]=temp2;
            temp3=order[i];
            order[i]=order[j];
            order[j]=temp3;
        }  
    }  
    temp1=start[i+1];
    start[i+1]=start[high];
    start[high]=temp1;
    temp2=end[i+1];
    end[i+1]=end[high];
    end[high]=temp2;
    temp3=order[i+1];
    order[i+1]=order[high];
    order[high]=temp3;
    return (i + 1);  
}  

void quicksort(int *start, int* end, int *order, int low, int high)  
{  
    if (low < high)  
    { 
        int pi = partition(start, end, order, low, high);  
        quicksort(start, end, order, low, pi - 1);  
        quicksort(start, end, order, pi + 1, high);  
    }  
}  
int main()
{
    int T;
    int i;
    scanf("%d",&T);
    for(i=1;i<=T;i++)
    {
        int n;
        scanf("%d",&n);
        int start[n],end[n];
        int j,cs,ce,js,je;
        cs=ce=js=je=0;
        int order[n];
        int assign[n];
        for(j=0;j<n;j++)
        {
            scanf("%d %d",&start[j],&end[j]);
            order[j]=j+1;
        }
        quicksort(start,end,order,0,n-1);
        int flag=1;
        char str[10000];
        int k=0;
        for(j=0;j<n;j++)
        {
            if(start[j]>=ce)
            {
                cs=start[j];
                ce=end[j];
                str[order[j]-1]='C';
            }
            else if(start[j]>=je)
            {
                js=start[j];
                je=end[j];
                str[order[j]-1]='J';
            }
            else
            {
                flag=-1;
                break;
            }
        }
        if(flag==-1)
        printf("Case #%d: IMPOSSIBLE\n",i);
        else
        {
            str[n]='\0';
            printf("Case #%d: %s\n",i,str);
        }
    }
    return 0;
}
