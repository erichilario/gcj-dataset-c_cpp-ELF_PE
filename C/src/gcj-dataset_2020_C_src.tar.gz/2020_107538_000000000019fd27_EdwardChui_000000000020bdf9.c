#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int compare(const void *pa, const void *pb){
	const int* a = pa;
	const int* b = pb;
	if(a[0] == b[0])
		return a[1] - b[1];
	else
		return a[0] - b[0];
}

int main(){
	int testCases;
	int n;
	int event[1500][5];
	int endC, endJ;
	int answer[1500][5];
	int j, flag;

	scanf("%d", &testCases);
	for(int t = 0; t < testCases; t++){
		scanf("%d", &n);
		for(int i = 0; i < n; i++){
			scanf("%d %d", &event[i][0], &event[i][1]);
			event[i][2] = i;
		}

		qsort(event, n, sizeof(event[0]), compare);

		flag = 0;
		j = 0;
		// C first
		answer[j][0] = event[0][2];
		answer[j++][1] = 'C';
		endC = event[0][1];
		// J
		answer[j][0] = event[1][2];
		answer[j++][1] = 'J';
		endJ = event[1][1];
		// Alternating jobs
		for(int i = 2; i < n; i++){
			if(event[i][0] < endC && event[i][0] < endJ){
				flag = 1;
				break;
			}
			if(endC < endJ){
				answer[j][0] = event[i][2];
				answer[j++][1] = 'C';
				endC = event[i][1];
			}
			else{
				answer[j][0] = event[i][2];
				answer[j++][1] = 'J';
				endJ = event[i][1];
			}
		}
		if(flag == 1)
			printf("Case #%d: IMPOSSIBLE\n", t+1);
		else{
			qsort(answer, n, sizeof(answer[0]), compare);
			printf("Case #%d: ", t+1);
			for(int i = 0; i < n; i++){
				printf("%c", answer[i][1]);
			}
			printf("\n");
		}
	}
	return 0;
}

