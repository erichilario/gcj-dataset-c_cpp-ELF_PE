#include <stdio.h>
#include <string.h>

int main() {
    int T,i,l,l2,j,k,f1,f2;
    char S[102],s[1009];
    
    scanf("%d",&T);
    
    for(i=1;i<=T;i++) {
        scanf("%s",S);
        l=strlen(S);
        l2=(10*l)+9;
        
        S[l]='0';
        S[l+1]='\0';
        
        for(j=0;j<l2;j++) s[j]='-';
        for(j=0;j<l;j++) s[((10*j)+9)]=S[j];
        
        while(1) {
            f1=0;
            for(j=0;j<=l;j++) {
                if((S[j]!='0')&&(!f1)) {
                    for(k=(10*j);k<((10*j)+9);k++) {
                        if(s[k]=='-') {
                            s[k]='(';
                            break;
                        }
                    }
                    f1=1;
                }
                else if((S[j]=='0')&&(f1)) {
                    for(k=((10*j)+8);k>=(10*j);k--) {
                        if(s[k]=='-') {
                            s[k]=')';
                            break;
                        }
                    }
                    f1=0;
                }
            }
            f2=1;
            for(j=0;j<l;j++) {
                if(S[j]!='0') {
                    S[j]--;
                    f2=0;
                }
            }
            if(f2) break;
        }
        
        printf("Case #%d: ",i);
        for(j=0;j<l2;j++) if(s[j]!='-') printf("%c",s[j]);
        printf("\n");
    }
    
    return 0;
}
