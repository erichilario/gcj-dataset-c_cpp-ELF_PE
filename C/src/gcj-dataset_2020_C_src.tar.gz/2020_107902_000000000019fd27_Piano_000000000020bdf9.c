#include<stdio.h>
#include<stdlib.h>

typedef struct event{
    int time;
    int no;
    char type;
} event;

int cmp(const void *a, const void *b){
    event *x = (event*)a, *y = (event*)b;
    if (x->time > y->time)return 1;
    if (x->time < y->time)return -1;
    if (x->type > y->type)return 1;
    if (x->type < y->type)return -1;
    return 0;
}

int main(){
    int t, u;
    event e[2000];
    char a[1001];

    scanf("%d", &t);
    for (u = 1; u <= t; ++u){
        int n, i, c = - 1, j = -1;
        memset(a, 0, 1001);

        scanf("%d", &n);
        for (i = 0; i < n; ++i){
            int l, r;
            scanf("%d%d", &l, &r);
            e[i * 2].time = l, e[i * 2].no = i, e[i * 2].type = 's';
            e[i * 2 + 1].time = r, e[i * 2 + 1].no = i, e[i * 2 + 1].type = 'e';
        }
        qsort(e, n * 2, sizeof(event), cmp);

        for (i = 0; i < n * 2; ++i){
            if (e[i].type == 's'){
                if (c < 0){
                    c = e[i].no;
                    a[e[i].no] = 'C';
                }
                else if (j < 0){
                    j = e[i].no;
                    a[e[i].no] = 'J';
                }
                else break;
            }
            else {
                if (a[e[i].no] == 'C')
                    c = -1;
                else j = -1;
            }
        }

        printf("Case #%d: ", u);
        if (i < n * 2)
            puts("IMPOSSIBLE");
        else puts(a);
    }
    return 0;
}

