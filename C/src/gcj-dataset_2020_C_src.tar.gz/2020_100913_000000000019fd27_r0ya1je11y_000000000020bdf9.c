#include <stdio.h>
#include <stdlib.h>
typedef struct _ACTIVITY{
    short index;
    int start_time;
    int end_time;
} Activity;

Activity sorted[1000];

void Merge(Activity* list, int left, int mid, int right){
    int i=left, j=mid+1, k=left;

    while(i<=mid && j<=right){
        if(list[i].start_time < list[j].start_time){
            sorted[k++] = list[i++];
        }
        else if(list[i].start_time > list[j].start_time){
            sorted[k++] = list[j++];
        }
        else{
            if(list[i].end_time < list[j].end_time){
                sorted[k++] = list[i++];
            }
            else{
                sorted[k++] = list[j++];
            }
        }
    }

    if(i>mid){
        for(int l=j; l<=right; l++)
            sorted[k++] = list[l];
    }
    else{
        for(int l=i; l<=mid; l++)
            sorted[k++] = list[l];
    }

    for(int l=left; l<=right; l++){
        list[l] = sorted[l];
    }
    return;
}

void MergeSort(Activity* list, int left, int right){
    if(left < right){
        int mid = (left+right) / 2;
        MergeSort(list, left, mid);
        MergeSort(list, mid+1, right);
        Merge(list, left, mid, right);
    }
    return;
}

int main(){
    int t, n;
    scanf("%d", &t);

    for(int cnt=1; cnt<=t; cnt++){
        scanf("%d", &n);

        int c_end = 0, j_end = 0;
        Activity* arr = (Activity*)malloc(sizeof(Activity) * n);
        char* seq = (char*)malloc(sizeof(char) * n);

        for(int i=0; i<n; i++){
            arr[i].index = i;
            scanf("%d%d", &arr[i].start_time, &arr[i].end_time);
        }

        MergeSort(arr, 0, n-1);

        printf("Case #%d: ", cnt);
        for(int i=0; i<n; i++){
            if(arr[i].start_time >= c_end ){
                seq[arr[i].index] = 'C';
                c_end = arr[i].end_time;
            }
            else if(arr[i].start_time >= j_end){
                seq[arr[i].index] = 'J';
                j_end = arr[i].end_time;
            }
            else{
                printf("IMPOSSIBLE");
                goto label;
            }
        }

        for(int i=0; i<n; i++){
            printf("%c", seq[i]);
        }
    
    label:
        printf("\n");
        free(arr);
    }
}
