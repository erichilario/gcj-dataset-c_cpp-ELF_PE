// C++ program to pritn Latin Square
#include<stdio.h>


// Driver program to test above function
int main()
{
	int T;
	scanf("%d",&T);
    int a[T][2];

    //Take Input from User
    for(int i=0;i<T;i++)
    {
        for(int j=0;j<2;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }

    //---------------------------------------------------

    for(int i=0;i<T;i++)
    {
        int size = a[i][0];
        int sum = a[i][1];
        int arr[size][size];



        for(int i=0;i<size;i++)
        {
            int temp=size-i;
            int flag=0;
            for(int j=0;j<size;j++)
            {
                //int count=0;
                if(flag==0 && temp!=0)
                   {
                       arr[i][j]=temp--;
                       //count++;
                   }
                else if(temp==0)
                {
                    flag =1;
                    temp=size;
                    arr[i][j]=size;

                }
                else
                    {arr[i][j]=--temp;

                    }

            }
        }

        int trace=0;
        for(int i=0;i<size;i++)
            trace+= arr[i][i];

        //printf("\n Trace =%d\n",trace);

        if(a[i][1]==trace)
            {

                printf("Case #%d: POSSIBLE",i+1);

                for(int i=0;i<size;i++)
                    {
                        printf("\n");
                        for(int j=0;j<size;j++)
                        {
                            printf("%d ",arr[i][j]);
                        }
                    }
            }
        else
            {
                printf("\nCase #%d: IMPOSSIBLE",i+1);

            }


    }



	return 0;
}

