#include<stdio.h>
int main()
{
    int T,N,K,i;
    scanf("%d",&T);
    for (i=0;i<T;i++)
        scanf("%d %d",&N,&K);
    printf("Case #1: POSSIBLE");
    return 0;
}
