#include <stdio.h>
#include <string.h>
#define MAX 1450

int count[MAX];
int start[MAX];
int end[MAX];
char s[MAX];

int main() {
  int T, N, S, E, imposible, i, j, k;
  scanf("%d", &T);
  for (k = 1; k <= T; k++) {
    scanf("%d", &N);
    for (i = 0; i < MAX; i++) {
      start[i] = 0;
      count[i] = 0;
      end[i] = 0;
    }
    for (i = 0; i < N; i++) {
      scanf("%d %d", &S, &E);
      start[i + 1] = S;
      end[i + 1] = E;
    }
    for (i = 0; i < MAX;) {
      for (j = 1; j <= N; j++)
        if (start[j] == i)
          break;
      if (j <= N) {
        s[j] = 'J';
        i = end[j];
        start[j] = -1;
      } else
        i++;
    }
    for (i = 0; i < MAX;) {
      for (j = 1; j <= N; j++)
        if (start[j] == i)
          break;
      if (j <= N) {
        s[j] = 'C';
        i = end[j];
        start[j] = -1;
      } else
        i++;
    }
    s[N + 1] = '\0';
    for (i = 1, imposible = 0; i <= N; i++)
      if (start[i] != -1) {
        imposible = 1;
        break;
      }
    if (imposible)
      printf("Case #%d: IMPOSSIBLE\n", k);
    else
      printf("Case #%d: %s\n", k, s + 1);
  }
  return 0;
}

