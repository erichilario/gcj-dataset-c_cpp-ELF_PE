#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#define rep(E, F) for (E = 0; E < (F); E++)
int get_int();
double get_double();
int get_string(char*, char);
int min(int a, int b) { if (a > b) { return b; } return a; }
int max(int a, int b) { if (a < b) { return b; } return a; }
typedef struct { int x, y, z; } par;
int cmp(const void* p1, const void* p2)
{
	return ((par*)p1)->x - ((par*)p2)->x;
}

int main()
{
	int t = get_int(), cc = 1;
	while (t--)
	{
		int i, n = get_int();
		int b[n];
		rep(i, n) b[i] = -1;
		par a[n];
		rep(i, n) a[i].x = get_int(), a[i].y = get_int(), a[i].z = i;
		qsort(a, n, sizeof(a[0]), cmp);
		int f[2] = {-1, -1};
		rep(i, n)
		{
			if (f[0] != -1 && f[0] <= a[i].x) f[0] = -1;
			if (f[1] != -1 && f[1] <= a[i].x) f[1] = -1;
			if (f[0] == -1) f[0] = a[i].y, b[a[i].z] = 0;
			else if (f[1] == -1) f[1] = a[i].y, b[a[i].z] = 1;
			else break;
		}
		printf("Case #%d: ", cc++);
		if (i < n) printf("IMPOSSIBLE\n");
		else
		{
			rep(i, n) printf("%c", b[i] == 0 ? 'C' : 'J'); printf("\n");
		}
	}

	return 0;
}

int get_string(char* b, char t)
{
	int i = 0;
	b[i++] = getchar();
	while (b[i - 1] != t) b[i++] = getchar();
	b[i - 1] = '\0';
	return i - 1;
}

double get_double()
{
	double ret = 0;
	char c = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF) return EOF;
		if (c >= '0' && c <= '9') { sgn = 1; break; }
		if (c == '-')
		{
			c = getchar();
			if (c < '0' || c > '9') continue;
			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = ret*10 + c - '0';
		c = getchar();
		if (c == '.')
		{
			double pos = 0.1;
			c = getchar();
			while (c >= '0' && c <= '9')
			{
				ret += pos*(c - '0');
				pos /= 10;
				c = getchar();
			}
			return sgn*ret;
		}
		else if (c < '0' || c > '9') return sgn*ret;
	}
}

int get_int()
{
	int ret = 0;
	char c = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF) return EOF;
		if (c >= '0' && c <= '9') { sgn = 1; break; }
		if (c == '-')
		{
			c = getchar();
			if (c < '0' || c > '9') continue;
			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = ret*10 + c - '0';
		c = getchar();
		if (c < '0' || c > '9') return sgn*ret;
	}
}

