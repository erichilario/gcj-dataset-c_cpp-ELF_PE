#include<stdio.h>

int main()
{
    int T,cases=0;
    char i=0,pre=-1,ch=1;
    scanf("%d%*c",&T);
    printf("Case #%d: ",++cases);
    while(ch!=EOF)
    {
        ch=getchar();
        ch-='0';
        if(ch!=pre)
        {
            for(i=1;i<pre;i++)
                putchar(')');
            if(pre!=-1 && ch==0 || ch+'0'=='\n' && pre!=0)
                putchar(')');

            if(ch+'0'=='\n')
            {
                pre=-1,ch=1;
                cases++;
                printf("\n");
                if(cases<=T)printf("Case #%d: ",cases);
                continue;
            }

            if((pre==0||pre==-1||pre==-38) && ch+'0'!='\n' && ch!=0)
                putchar('(');
            for(i=1;i<ch;i++)
                putchar('(');
        }
        putchar(ch+'0');
//        for(i=0;i<ch;i++)
//            putchar(')');
//            printf("[pre=%d]",pre);
            pre=ch;
//            printf("[pre=%d]",pre);
    }
    return 0;
}

