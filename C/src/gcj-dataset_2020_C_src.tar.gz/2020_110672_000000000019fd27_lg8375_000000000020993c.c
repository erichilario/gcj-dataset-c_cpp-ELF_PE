#include<stdio.h>
//#pragma warning(disable:4996)

int tc;
int N;
int map[102][102];
int chk[102], check;
void input()
{
	scanf("%d", &N);
	for (int i = 0; i < N; i++) {
		for (int k = 0; k < N; k++) {
			scanf("%d", &map[i][k]);
		}
	}

	tc++;
}
void solution()
{
	int K = 0, R = 0, C = 0;
	for (int i = 0; i < N; i++) {
		K += map[i][i];
	}
	for (int i = 0; i < N; i++) {
		++check;
		for (int k = 0; k < N; k++) {
			if (chk[map[i][k]] != check) {
				chk[map[i][k]] = check;
			}
			else {
				R++;
				break;
			}
		}
	}
	for (int k = 0; k < N; k++) {
		++check;
		for (int i = 0; i < N; i++) {
			if (chk[map[i][k]] != check) {
				chk[map[i][k]] = check;
			}
			else {
				C++;
				break;
			}
		}
	}
	printf("Case #%d: %d %d %d\n", tc, K, R, C);
}
int main()
{
	int T;
	scanf("%d", &T);
	while (T--) {
		input();
		solution();
	}
}
