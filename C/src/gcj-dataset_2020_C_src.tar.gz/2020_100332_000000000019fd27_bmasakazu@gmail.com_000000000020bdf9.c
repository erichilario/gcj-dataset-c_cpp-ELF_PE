#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define XSTR(x) #x
#define STR(x) XSTR(x)

FILE * input_source = NULL;
char* buffer = NULL;
char* cursor;
size_t read_size;

#ifdef INPUT_FILE
void open_input() {
  input_source = fopen(STR(INPUT_FILE), "r"); 
}

void close_input() {
  fclose(input_source);
}

#else
void open_input() {
  input_source = stdin;
}

void close_input() {

}
#endif

#define BUFFER_SIZE 1000

char output_buffer[BUFFER_SIZE];
size_t output_buffer_index;

struct sched
{
  int start;
  int end;
  int original_index;
};
typedef struct sched sched;

struct person
{
  bool is_free;
  char name;
  int busy_til;
  struct person *next;
};
typedef struct person person;

sched *scheds;
int scheds_size;
int sched_index;
int iter_index;

void init_scheds()
{
  scheds_size = BUFFER_SIZE;
  scheds = malloc(scheds_size*sizeof(sched));
}

void clear_sched()
{
  sched_index = 0;
}

void add_sched(sched * sch)
{
  if (sched_index == scheds_size)
  {
    scheds_size *= 2;
    scheds = realloc(scheds, scheds_size*sizeof(sched));
  }
  scheds[sched_index] = *sch;
  sched_index++;
}

int size_sched()
{
  return sched_index;
}

void start_iter_sched()
{
  iter_index = 0;
}

sched* iter_sched()
{
  sched* s;
  if (iter_index == sched_index)
  {
    return NULL;
  }
  s = &scheds[iter_index];
  iter_index++;
  return s;
}

int compare_sched(const void * a, const void* b)
{
  return ((sched*)a)->start - ((sched*)b)->start;
}

void sort_sched()
{
  qsort(scheds, sched_index, sizeof(sched), compare_sched);
}

void line_to_sched(sched * sch, char * line)
{
  char* begin = line;
  char* cursor = begin;

  /* start time */
  while (*cursor != ' ')
  {
    cursor++;
  }
  *cursor = '\0';
  cursor++;

  sch->start = atoi(begin);
  
  /* end time */
  begin = cursor;
  while (*cursor != '\n')
  {
    cursor++;
  }
  *cursor = '\0';

  sch->end = atoi(begin);
} 

void fast_forward_time(int time, person * ppl)
{
  person * p = ppl;
  while (p != NULL)
  {
    /* person is free now */
    if (!p->is_free && time >= p->busy_til)
    {
      p->is_free = true;
    }
    p = p->next;
  }
}

person* assign_sched(sched *sch, person * ppl)
{
  person * p = ppl;
  while (p != NULL)
  {
    if (p->is_free)
    {
      p->is_free = false;
      p->busy_til = sch->end;
      return p;
    }
    p = p->next;
  }
  /* everyones busy */
  return NULL;
}

void test_case(int t)
{
  sched sch;
  person ppl[2];
  int num_ppl = 2;
  person *assigned;
  output_buffer_index = 0;

  ppl[0].is_free = true;
  ppl[0].name = 'C';
  ppl[0].next = &ppl[1];

  ppl[1].is_free = true;
  ppl[1].name = 'J';
  ppl[1].next = NULL;

  clear_sched();

  getline(&buffer,&read_size,input_source);

  int num_sched = atoi(buffer);
  int index = 0;
  while (index < num_sched)
  {
    getline(&buffer,&read_size,input_source);
    line_to_sched(&sch, buffer);
    sch.original_index = index;
    add_sched(&sch);

    index++;
  }

  /* sort */
  sort_sched();

  /* assign */
  start_iter_sched();
  sched *cur = iter_sched();
  while (cur)
  {
    fast_forward_time(cur->start, ppl);
    assigned = assign_sched(cur, ppl);

    /* just early exit */
    if (!assigned)
    {
      fprintf(stdout, "Case #%d: IMPOSSIBLE\n", t);
      return;
    }

    output_buffer[cur->original_index] = assigned->name;

    cur = iter_sched();
  }

  output_buffer[num_sched] = '\0';
  fprintf(stdout, "Case #%d: %s\n", t, output_buffer);
}

int main()
{
    open_input();

    getline(&buffer,&read_size,input_source);

    int num_tests = atoi(buffer);

    init_scheds();

    /* 1 index testcase number*/
    for (int t = 1; t <= num_tests; t++)
    {
       test_case(t);
    }

    free(buffer);
    free(scheds);
    close_input();
    return 0;
}

