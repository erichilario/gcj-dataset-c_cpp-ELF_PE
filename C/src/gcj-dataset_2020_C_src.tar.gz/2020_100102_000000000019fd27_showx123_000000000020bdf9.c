#include <stdio.h>
#include <stdlib.h>

typedef struct act{
	int s;
	int e;
	int idx;
}Act;

Act arr[1005];
int N;
char ans[1005];

int compare(const void * first, const void * second) {
	int a = ((Act *)first)->s;
	int b = ((Act *)second)->s;

	if (a > b)
		return 1;
	else if (a == b)
		return 0;
	else
		return -1;
}


int main(void) {
	int t, T;
	int i;

	scanf("%d", &T);

	for (t = 1; t <= T; t++) {
		scanf("%d", &N);
		int C = 0;
		int J = 0;
		int idx = 0;

		for (i = 1; i <= N; i++) {
			arr[i].idx = i - 1;
			scanf("%d%d", &arr[i].s, &arr[i].e);
		}

		qsort(&arr[1], N, sizeof(Act), compare);

		for (i = 1; i <= N; i++) {
			if (C <= arr[i].s) {
				ans[arr[i].idx] = 'C';
				C = arr[i].e;
			}
			else if (J <= arr[i].s) {
				ans[arr[i].idx] = 'J';
				J = arr[i].e;
			}
			else {
				break;
			}
		}

		if(i <= N)
			printf("Case #%d: IMPOSSIBLE\n", t);
		else {
			ans[N] = 0;
			printf("Case #%d: %s\n", t, ans);
		}
	}
}
