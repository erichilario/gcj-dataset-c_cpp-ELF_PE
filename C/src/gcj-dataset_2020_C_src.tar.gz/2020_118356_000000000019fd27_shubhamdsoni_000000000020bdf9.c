#include<stdio.h>

int main()
{
	int T, _T,N,I,E,S,J,impossible,value;
	int CJ[1441][3];
	int data[1001][3];
	scanf("%d", &T);
	_T = T;
	while(T--)
	{
		for(I=0;I<=1440;I++)
		{
			CJ[I][0] = 0;
			CJ[I][1] = -1;
			CJ[I][2] = -1;
		}
		scanf("%d", &N);
		impossible = 0;
		printf("Case #%d: ",_T-T);
		for(I=0;I<N;I++)
		{
			scanf("%d %d", &data[I][0], &data[I][1]);
			if(impossible ==1) continue;
			data[I][2]=0;
			if(CJ[data[I][0]][1] == -1)
			{
				CJ[data[I][0]][1] = I;
			}	
			else if (CJ[data[I][0]][2] == -1)
			{
				CJ[data[I][0]][2] = I;
			}
			else
			{
				impossible = 1;
			}
		}
		if(impossible ==1) {printf("IMPOSSIBLE\n"); continue;}
		for(I=0;I<=1440;I++)
		{
			if(CJ[I][1] == -1) continue;

			if(CJ[I][1] != -1)
			{
			  if(CJ[I][0]==0) value=1;
			  else if(CJ[I][0]==1) value=2;
			  else if(CJ[I][0]==2) value=1;
			  else { impossible = 1; break;}
                          for(J=I; J< data[CJ[I][1]][1]; J++)
			  {
			    if((CJ[J][0] & value )) {impossible =1 ; break;}
			    CJ[J][0] |= value; 
			  }
			  data[CJ[I][1]][2] = value;
			}
			if(impossible ==1) {break;}
			if(CJ[I][2] != -1)
			{
			  if(CJ[I][0]==0) value=1;
			  else if(CJ[I][0]==1) value=2;
			  else if(CJ[I][0]==2) value=1;
			  else { impossible = 1; break;}
                          for(J=I; J< data[CJ[I][2]][1]; J++)
			  {
			    if((CJ[J][0] & value )) {impossible =1 ;break;}
			    CJ[J][0] |= value; 
			  }
			  data[CJ[I][2]][2] = value;
			}
			if(impossible ==1) {break;}
		}
		if(impossible ==1) {printf("IMPOSSIBLE\n"); continue;}
                for(I=0;I<N;I++)
		{
			printf("%c",(data[I][2]==1)?'C':'J');
		}
		printf("\n");
	}
	return 0;
}

