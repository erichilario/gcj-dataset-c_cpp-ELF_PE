#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<limits.h>
int main()
{
    int t;
    scanf("%d",&t);
    int i;
    for(i=1;i<=t;i++)
    {
        int n;
        scanf("%d",&n);
        int arr[n][n];
        int a,b,trace=0;
        for(a=0;a<n;a++)
        {
            for(b=0;b<n;b++)
            {
                scanf("%d",&arr[a][b]);
                if(b==a)
                trace+=arr[a][b];
            }
        }
        int cr,cc;
        cr=cc=0;
        for(a=0;a<n;a++)
        {
            int count[n+5];
            memset(count,0,sizeof(count));
            for(b=0;b<n;b++)
            {
                if(count[arr[a][b]]==0)
                count[arr[a][b]]=1;
                else
                {
                    cr++;
                    break;
                }
            }
        }
        for(b=0;b<n;b++)
        {
            int count[n+5];
            memset(count,0,sizeof(count));
            for(a=0;a<n;a++)
            {
                if(count[arr[a][b]]==0)
                count[arr[a][b]]=1;
                else
                {
                    cc++;
                    break;
                }
            }
        }
        printf("Case #%d: %d %d %d\n",i,trace,cr,cc);
    }
    return 0;
}
