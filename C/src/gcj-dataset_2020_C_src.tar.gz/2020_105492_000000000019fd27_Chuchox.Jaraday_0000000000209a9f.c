#include <stdio.h>

int main(void){
    char c;
    int profundidad;
    int cases, casos;

    scanf("%d\n",&cases);
    for(casos=1;casos<=cases;casos++){
        printf("Case #%d: ",casos);
        profundidad = 0;
        while((c = getchar())<='9' && c>='0'){
            while(profundidad < (c - '0')){
                  putchar('(');
                  profundidad++;
            }
            while(profundidad > (c - '0')){
                  putchar(')');
                  profundidad--;
            }
            putchar(c);
        }
        while(profundidad){
            putchar(')');
            profundidad--;
        }
        putchar('\n');
    }

    return(0);
}
