#include<stdio.h>
int main()
{
    printf("IMPOSSIBLE");
    return 0;
}
