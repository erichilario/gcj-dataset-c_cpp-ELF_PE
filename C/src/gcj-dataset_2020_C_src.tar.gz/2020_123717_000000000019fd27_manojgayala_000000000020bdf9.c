#include <stdio.h>
#include <stdlib.h>

struct slot
{
	int id;
	int start;
	int end;
	char person;
};


int main()
{
	int i,t;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		int n,i1,i2;
		scanf("%d",&n);
		
		struct slot a[n];
		for(i1=0;i1<n;i1++)
		{
			scanf("%d %d",&a[i1].start,&a[i1].end);
			a[i1].id=i1;
		}		
		
		struct slot temp;
		
		for(i1=0;i1<n;i1++)
		for(i2=i1+1;i2<n;i2++)
		{
			if(a[i1].start>a[i2].start)
			{
				temp=a[i1];
				a[i1]=a[i2];
				a[i2]=temp;
			}
			
		}
		
		int c_busy=0;
		int j_busy=0;
		int check=1;
		
		for(i1=0;i1<n;i1++)
		{
			if(a[i1].start>=c_busy)
			{
				a[i1].person='C';
				c_busy=a[i1].end;
			}
			else
			if(a[i1].start>=j_busy)
			{
				a[i1].person='J';
				j_busy=a[i1].end;
			}
			else
			{
				check=0;
				break;
			}
		}
		
		printf("Case #%d: ",i+1);
		
		if(check==0)	printf("IMPOSSIBLE");
		else
		{
			for(i1=0;i1<n;i1++)
			for(i2=0;i2<n;i2++)
			{
				if(a[i2].id==i1)
				{
					printf("%c",a[i2].person);
					break;
				}
			}
		}
	
		printf("\n");
	}
	
	
	return(0);
}
