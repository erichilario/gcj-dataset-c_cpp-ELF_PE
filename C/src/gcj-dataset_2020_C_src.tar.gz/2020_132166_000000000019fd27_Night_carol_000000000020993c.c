#include<stdio.h>
void main()
{
  int i,j,N,mat[20][20],row=0,col=0;
  int r,c,k,x,T,f=0,t=0;
  printf("enter how many times want cases to be print ie.,value of T");
   scanf("%d",&T);
   for(x=0;x<T;x++)
 {  
   printf("enter size of matrix");
   scanf("%d",&N);
   for(i=0;i<N;i++)
   {
       for(j=0;j<N;j++)
    {
        printf("enter numbers in matrix ");
        scanf("%d",mat[i][j]);
        
    }
   }
    for(i=0;i<N;i++)
   {
       for(j=0;j<N;j++)
    {
        if(mat[i][j]>N)
        printf("matrix is not natural latin square");
        else
        printf("matrix is natural latin square");

    }
   }
   t=mat[row][col];
 for(i=0;i<N;i++)
{
   for(j=0;j<N;j++)
 { 
    if(t==mat[i][j+1])
    {
       f =f+1;
    }
    if(j==N)
    {   col=col+1;
        t=mat[row][col];
        j=0;
        
     }
  } 
  if(f>1)
   r=r+1;
   f=0;
   
}
  row=0;col=0;f=0;
  t=mat[row][col];
   for(j=0;j<N;j++)
{
      for(i=0;i<N;i++)
  { 
    if(t==mat[i+1][j])
    {
       f =f+1;
    }
    if(i==N)
    {   row=row+1;
        t=mat[row][col];
        i=0;
     }
   }
   if(f>1)
   c=c+1;
   f=0;
 } 
   for(i=0;i<N;i++)
   {
       for(j=0;j<N;j++)
       {
           if(i==j)
           k=k+mat[i][j];
       }
   }
   printf("case  #%d: %d %d %d",x,k,r,c);
  }
 }  
