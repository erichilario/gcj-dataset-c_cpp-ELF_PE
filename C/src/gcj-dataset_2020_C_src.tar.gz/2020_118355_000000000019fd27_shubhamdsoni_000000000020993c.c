#include<stdio.h>

int main()
{
	int T,_T;
	scanf("%d", &T);
	_T = T;
	while(T--)
	{
          int N,i,j,temp,trace=0;
	  int rt=0,ct=0;
	  scanf("%d",&N);
	  int C[N][N+1];
          int CF[N];
	  int RF[N];
	  int scanRF[N];
	  for(i=0;i<N;i++)
	  {
		  CF[i] = 0;
		  RF[i] = 0;
		  for(j=0;j<=N;j++)
		  {
			  C[i][j]=0;
		  }
	  }
	  for(i=0;i<N;i++)
	  {
		  for(j=0;j<=N;j++)
		  {
			  scanRF[j]=0;
		  }
		  for(j=0;j<N;j++)
		  {
			  scanf("%d", &temp);
			  if(i==j) trace +=temp;
			  if(RF[i]==0)
			  {
				  if(scanRF[temp] != 0)
				  {
					  RF[i] = 1;
					  rt++;
				  }
				  else
				  {
					  scanRF[temp]=1;
				  }
			  }
			  if(CF[j]==0)
			  {
				  if(C[j][temp] != 0)
				  {
					  CF[j] = 1;
					  ct++;
				  }
				  else
				  {
					  C[j][temp]=1;
				  }
			  }
		  }
	  }
          printf("Case #%d: %d %d %d\n", _T-T,trace, rt,ct);
	}
	return 0;
}

