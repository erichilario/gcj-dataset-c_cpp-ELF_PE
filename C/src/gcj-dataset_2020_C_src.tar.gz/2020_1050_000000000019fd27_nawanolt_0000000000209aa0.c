#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

int A[50][50], B[50][50];

int diff(int a, int b)
{
	if(a > b) return a - b;
	else return b - a;
}

void print_matrix(int n)
{
	int r, c;
	for(r = 0; r < n; r++)
	{
		printf("%d", A[r][0]);
		for(c = 1; c < n; c++)
			printf(" %d", A[r][c]);
		printf("\n");
	}
}

void swap_rows(int r1, int r2, int n)
{
	int t, c;

	for(c = 0; c < n; c++)
	{
		t = A[r1][c];
		A[r1][c] = A[r2][c];
		A[r2][c] = t;
	}
}

void process_test_case_bad1(int test_case_number)
{
	int n, k, r, c, cur_trace, best, best_row1, best_row2, r1, r2, x;

	scanf("%d%d", &n, &k);
	cur_trace = n;
	for(r = 0; r < n; r++)
		for(c = 0; c < n; c++)
			A[r][c] = (n - r + c) % n + 1;
	while(cur_trace != k)
	{
		best = diff(cur_trace, k);
		for(r1 = 0; r1 < n && best > 0; r1++)
			for(r2 = 0; r2 < n && best > 0; r2++)
			{
				if(r1 == r2) continue;
				x = cur_trace - A[r1][r1] - A[r2][r2] + A[r2][r1] + A[r1][r2];
				if(diff(x, k) < best)
				{
					best = diff(x, k);
					best_row1 = r1;
					best_row2 = r2;
				}
			}
		if(best == diff(cur_trace, k)) break;//impossible
		cur_trace = cur_trace - A[best_row1][best_row1] - A[best_row2][best_row2] + 
			A[best_row2][best_row1] + A[best_row1][best_row2];
		swap_rows(best_row1, best_row2, n);
	}
	printf("Case #%d: %sPOSSIBLE\n", test_case_number + 1, cur_trace != k ? "IM" : "");
	if(cur_trace == k)
		print_matrix(n);
}

void check_answer(int trace, int n)
{
	int r, c, sum = 0, used[50];

	for(r = 0; r < n; r++)
		sum += B[r][r];
	if(sum != trace)
	{
		printf("Answer is wrong (%d != %d)!\n", sum, trace);
		return;
	}
	for(r = 0; r < n; r++)
	{
		for(c = 0; c < n; c++)
			used[c] = 0;
		for(c = 0; c < n; c++)
		{
			used[B[r][c] - 1]++;
			if(used[B[r][c] - 1] > 1)
			{
				printf("Answer is wrong (%d on row %d)!\n", B[r][c], r + 1);
				return;
			}
		}
	}
	for(c = 0; c < n; c++)
	{
		for(r = 0; r < n; r++)
			used[r] = 0;
		for(r = 0; r < n; r++)
		{
			used[B[r][c] - 1]++;
			if(used[B[r][c] - 1] > 1)
			{
				printf("Answer is wrong (%d on col %d)!\n", B[r][c], c + 1);
				return;
			}
		}
	}
	printf("Answer is correct\n");
}

void process_test_case(int test_case_number)
{
	int n, k, r, c, x, col_used[50][50], row_used[50], t;
	int low, high, num_low, num_high, next, map[50], map_used[50];
	int switch_1_2;

	scanf("%d%d", &n, &k);
	low = k / n;
	high = low + 1;
	for(x = 0; x < n; x++)
		map_used[x] = 0;
	map[0] = low - 1;//1
	map[1] = high - 1;//2
	map_used[low - 1] = 1;
	map_used[high - 1] = 1;
	next = 0;
	for(x = 2; x < n; x++)
	{
		while(map_used[next] && next < n) next++;
		if(next >= n)
		{
			printf("Error\n");
			return;
		}
		map[x] = next++;
	}
	num_high = k % n;
	num_low = n - num_high;
	if(num_low < num_high)
	{
		t = num_low;
		num_low = num_high;
		num_high = t;
		switch_1_2 = 1;
	}
	else switch_1_2 = 0;
	//every cell = -1
	for(r = 0; r < n; r++)
		for(c = 0; c < n; c++)
			A[r][c] = -1;
	//sequential for first num_low - 1 rows
	for(r = 0; r < num_low - 1; r++)
		for(c = 0; c < n; c++)
			A[r][c] = (n - r + c) % n + 1;
	//print_matrix(n);

	//initialize col_used
	for(c = 0; c < n; c++)
		for(x = 0; x < n; x++)
			col_used[c][x] = 0;
	//row num_low - 1 is special v2
	for(r = 0; r < num_low - 1; r++)
		for(c = 0; c < n; c++)
			col_used[c][A[r][c] - 1]++;
	for(x = 0; x < n; x++)
		row_used[x] = 0;
	r = num_low - 1;
	A[r][r] = 1;
	col_used[r][0]++;
	row_used[0] = 1;
	for(c = r + 1; c < n; c++)
	{
		if(c != r + 1)
			col_used[c][0]++;
		col_used[c][1]++;
	}
	for(c = r + 1; c < n; c++)
	{
		for(x = 0; x < n; x++)
			if(col_used[c][x] == 0 && row_used[x] == 0) break;
		if(x >= n)
		{
			printf("Case #%d: IMPOSSIBLE\n", test_case_number);
			return;
		}
		A[r][c] = x + 1;
		col_used[c][x] = 1;
		row_used[x] = 1;
	}
	for(c = 0; c < r; c++)
	{
		for(x = 0; x < n; x++)
			if(col_used[c][x] == 0 && row_used[x] == 0) break;
		if(x >= n)
		{
			printf("Case #%d: IMPOSSIBLE\n", test_case_number);
			return;
		}
		A[r][c] = x + 1;
		col_used[c][x] = 1;
		row_used[x] = 1;
	}
	//print_matrix(n);
	for(r = num_low; r < n; r++)
	{
		for(x = 0; x < n; x++)
			row_used[x] = 0;
		A[r][r] = 2;
		row_used[1] = 1;
		if(r != n - 1)
		{
			A[r][r + 1] = 1;
			row_used[0] = 1;
		}
		for(c = r + 2; c < n; c++)
		{
			x = c - r - 2 + 3;
			A[r][c] = x;
			row_used[x - 1] = 1;
		}
		for(c = 0; c < r; c++)
		{
			for(x = 0; x < n; x++)
				if(col_used[c][x] == 0 && row_used[x] == 0) break;
			if(x >= n)
			{
				print_matrix(n);
				printf("Case #%d: IMPOSSIBLE\n", test_case_number);
				return;
			}
			A[r][c] = x + 1;
			col_used[c][x] = 1;
			row_used[x] = 1;
		}
	}
	printf("Case #%d: POSSIBLE\n", test_case_number);
	if(switch_1_2)
	{
		t = map[0];
		map[0] = map[1];
		map[1] = t;
	}
	for(r = 0; r < n; r++)
	{
		printf("%d", map[A[r][0] - 1] + 1);
		B[r][0] = map[A[r][0] - 1] + 1;
		for(c = 1; c < n; c++)
		{
			printf(" %d", map[A[r][c] - 1] + 1);
			B[r][c] = map[A[r][c] - 1] + 1;
		}
		printf("\n");
	}
	//check_answer(k, n);
}

int main()
{
	int num_test_cases, test_case;

	scanf("%d", &num_test_cases);
	for(test_case = 0; test_case < num_test_cases; test_case++)
		process_test_case(test_case);

	return 0;
}

