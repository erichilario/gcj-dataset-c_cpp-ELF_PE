#include<stdio.h>

int appeared[150] = {};

void clearAppeared(int n){
	for(int i = 0; i <= n; i++)
		appeared[i] = 0;
	return;
}

int main(){
	int testCases;
	int n;
	int square[150][150] = {};
	int traceCount, rowCount, colCount;

	scanf("%d", &testCases);
	for(int t = 0; t < testCases; t++){
		traceCount = rowCount = colCount = 0;
		scanf("%d", &n);
		for(int i = 0; i < n; i++)
			for(int j = 0; j < n; j++)
				scanf("%d", &square[i][j]);


		for(int i = 0; i < n; i++)
			traceCount = traceCount + square[i][i];

		for(int i = 0; i < n; i++){
			clearAppeared(n);
			for(int j = 0; j < n; j++){
				if(appeared[square[i][j]] == 0)
					appeared[square[i][j]] = 1;
				else{
					rowCount++;
					break;
				}
			}
		}

		for(int i = 0; i < n; i++){
			clearAppeared(n);
			for(int j = 0; j < n; j++){
				if(appeared[square[j][i]] == 0)
					appeared[square[j][i]] = 1;
				else{
					colCount++;
					break;
				}
			}
		}

		printf("Case #%d: %d %d %d\n", t+1, traceCount, rowCount, colCount);
	}

	return 0;
}

