#include <iostream>
#include <string.h>

using namespace std;

int main()
{
	string open = "(";
	string close = ")";

	int T;
	cin >> T;

	for (int i = 1; i <= T; i++) {
		string s;
		cin >> s;

		string ans;

		int current_depth = s[0]-'0';
		for (int j = 0; j < current_depth; j++) {
			ans += open;
		}
		ans += s[0];
		for (int j = 1; j < s.length(); j++) {
			if ((s[j] - '0') > (s[j-1] - '0')) {
				int diff = (s[j]-'0') - (s[j - 1]-'0');
				for (int k = 0; j < diff; k++) {
					ans += open;
					current_depth++;
				}
				ans += s[j];
			}
			else if ((s[j] - '0') < (s[j-1] - '0')) {
				int diff = (s[j-1] - '0') - (s[j] - '0');
				for (int k = 0; k < diff; k++) {
					ans += close;
					current_depth--;
				}
				ans += s[j];
			}
			else {
				ans += s[j];
			}
		}

		for (int k = 0; k < current_depth; k++) {
			ans += close;
		}

		cout << "Case #";
		cout << i;
		cout << ": " << ans << endl;
	}



	return 0;
}
