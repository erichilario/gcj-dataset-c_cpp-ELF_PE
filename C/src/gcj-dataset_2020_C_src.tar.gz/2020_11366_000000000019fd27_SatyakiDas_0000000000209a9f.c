#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main() {
    int tc,k=0;
    scanf("%d",&tc);
    getchar();
    while(tc--)
    {
        int bc=0;
        char str[100],str1[2];
        gets(str);
        char fl[1000]="";
        for(int j=0;j<(int)str[0]-48;j++)
        {
            strcat(fl,"(");
            bc++;
        }
        str1[0]=str[0];
        str1[1]='\0';
        strcat(fl,str1);
        for(int i=1;str[i]!='\0';i++)
        {
            if(str[i]==str[i-1])
            {
                str1[0]=str[i];
                str1[1]='\0';
                strcat(fl,str1);
            }
            else if((int)str[i]>(int)str[i-1])
            {
                for(int j=0;j<(int)(str[i])-(int)(str[i-1]);j++)
                {
                    strcat(fl,"(");
                    bc++;
                }
                str1[0]=str[i];
                str1[1]='\0';
                strcat(fl,str1);
            }
            else
            {
                for(int j=0;j<(int)str[i-1]-(int)str[i];j++)
                {
                    strcat(fl,")");
                    bc--;
                }
                str1[0]=str[i];
                str1[1]='\0';
                strcat(fl,str1);
            }
        }
        for(int i=0;i<bc;i++)
        {
            strcat(fl,")");
        }
        printf("Case #%d: %s\n",++k,fl);
    }
    return 0;
}

