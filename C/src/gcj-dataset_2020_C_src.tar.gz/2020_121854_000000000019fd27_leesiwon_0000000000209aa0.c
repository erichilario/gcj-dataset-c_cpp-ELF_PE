#include<stdio.h>
int main(){
	int n,k;
	int t;
	scanf("%d",&t);
	for(int a=1;a<=t;a++){
		scanf("%d%d",&n,&k);
		int count=k%n;
		if(k%2==0&&n%2==0&&k<=(1+n)*(n/2))count=-1;
	    printf("Case #%d: ",a);
	    if(count>0){
	    	printf("IMPOSSIBLE\n");
	    	continue;
		}
		int x=k/n;
		printf("POSSIBLE\n");
		if(count==-1){
			k/=n/2;
			int b,c;
			if(k>n)b=n;
			else b=1;
			c=k-b;
			int arr[n+1];
			arr[1]=b;
			arr[3]=c;
			int num=1;
			for(int i=1;i<=n;i++){
				while(num==b||num==c)num++;
				if(i!=1&&i!=3)arr[i]=num++;
			}
			for(int i=1;i<=n;i++){
				for(int j=1;j<=n;j++){
					printf("%d ",arr[(i+j-1)%n==0?n:(i+j-1)%n]);
				}
				puts("");
			}
		}
		else {for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				int ans=x-(j-i);
				ans%=n;
				if(ans==0)ans=n;
				if(i==j)printf("%d ",x);
				else printf("%d ",ans);
			}
			puts("");
		}
	}
	}
}
