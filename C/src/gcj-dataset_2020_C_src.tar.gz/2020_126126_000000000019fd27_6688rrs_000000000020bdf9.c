#include <stdio.h>
int main()
{
    int testnum;
    scanf("%d",&testnum);
    int test=1;
    while(test<=testnum)//case
    {
        int SEtime[1000][2];
        int i,j,k,t;
        int acnum;
        char result[10];//紀錄順序
        int current;//目前做的row
        int J=0,C=0;

        scanf("%d",&acnum);
        for(i=0; i<acnum; i++)
        {
            for(j=0; j<2; j++)
            {
                scanf("%d",&SEtime[i][j]);
            }
        }
        ///////////////////////////////////////
         int flag;
        for(j=0; j<acnum; j++)//有j行做j次
        {
            flag=0;
            int startmin=1442;
            for(i=0; i<acnum; i++) //找一次startmin最小值
            {
                if(SEtime[i][0]<=startmin)
                {
                    startmin=SEtime[i][0];
                    current=i;
                }
            }
            if(J<=startmin)
            {
                J=SEtime[current][1];//讓j=作完的時間
                result[current]=74;//把J填入第current個
                SEtime[current][0]=1441;
            }
            else if(C<=startmin)
            {
                C=SEtime[current][1];
                result[current]=67;
                SEtime[current][0]=1441;
            }
            else
            {
                printf("Case #%d: IMPOSSIBLE\n",test);
                flag=1;
                break;
            }
        }
        if(flag==0)
        {
            printf("Case #%d: ",test);
            for(t=0; t<acnum; t++)
            {
                printf("%c",result[t]);
            }
            printf("\n");
        }


        test++;
    }
}

