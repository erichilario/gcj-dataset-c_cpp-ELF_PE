#include <stdlib.h>
#include <stdio.h>

#define BUF_SIZE 20

int main()
{
    char* buffer = (char*) malloc(BUF_SIZE);
    int read_size;

    getline(&buffer,&read_size,stdin);

    int num_tests = atoi(buffer);
    printf(buffer);
    for (int t = 0; t < num_tests; t++)
    {
       getline(buffer, BUF_SIZE,stdin);
       printf(buffer);
    }
}
