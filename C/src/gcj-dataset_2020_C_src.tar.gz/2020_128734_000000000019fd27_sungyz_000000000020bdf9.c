#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

int main()
{
    int T, t;
    int N, time[2][1440], empty[2];
    char    act[1001];
    int st, et;
    int i, j;

    scanf( "%d\n", &T );
    for( t = 1 ; t <= T ; t++ )
    {
        memset( time[0], -1, sizeof(int)*1440 );
        memset( time[1], -1, sizeof(int)*1440 );
        memset( act, 0, sizeof(char)*1001 );

        scanf( "%d\n", &N );
        for( i = 0 ; i < N ; i++ )
        {
            scanf( "%d %d\n", &st, &et );
            empty[0] = empty[1] = 1;
            for( j = st ; j < et ; j++ )
            {
                if( time[0][j] != -1 )
                    empty[0] = 0;
                if( time[1][j] != -1 )
                    empty[1] = 0;
            }

            if( empty[0] )
            {
                for( j = st ; j < et ; j++ )
                    time[0][j] = i;
                act[i] = 'C';
            }
            else if( empty[1] )
            {
                for( j = st ; j < et ; j++ )
                    time[1][j] = i;
                act[i] = 'J';
            }
            else
            {
                strcpy( act, "IMPOSSIBLE" );
                break;
            }
        }

        printf( "Case #%d: %s\n", t, act );
    }

    return 0;
}

