#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define MALLOC(X,Y)\
if(((X) = malloc((Y)))==NULL){\
fprintf(stderr, "heap memory allocation fails\n");\
exit(EXIT_FAILURE);\
}
#define MAX_N 100

typedef int (*I2ARR100)[100];

int trace(I2ARR100 matrix, size_t n);
void duplicated(I2ARR100 matrix, size_t n, int * r);
int is_duplicated(const int* arr, size_t size);

int main(void) {
    int i, j, q, t, n, k, r, c;
    int matrix[MAX_N][MAX_N], matrix2[MAX_N][MAX_N];
    scanf("%d", &t);
    for(i=0;i<t;i++){
        
        scanf("%d", &n);
        
        for(j=0;j<n;j++){
            for(q=0;q<n;q++){
                scanf("%d", &matrix[j][q]);
                matrix2[q][j] = matrix[j][q];
            }
        }
        
        k = trace(matrix, n);
        
        duplicated(matrix, n, &r);
        duplicated(matrix2, n, &c);
        
        printf("Case #%d: %d %d %d\n", i+1, k, r, c);
    }
	return 0;
}

int trace(I2ARR100 matrix, size_t n){
    int sum=0, i;
    for(i=0;i<n;i++){
        sum += matrix[i][i];
    }
    return sum;
}

void duplicated(I2ARR100 matrix, size_t n, int * r){
    int i, r_sum=0;
    
    for(i=0;i<n;i++){
        r_sum += is_duplicated(matrix[i], n);
    }
    
    
    *r = r_sum;
}

int is_duplicated(const int* arr, size_t size) {
	int i, j;
	for (i = 0; i < size - 1; i++) {
		for (j = i + 1; j < size; j++) {
			if (arr[i] == arr[j]) {
				return 1;
			}
		}
	}
	
	return 0;
}
