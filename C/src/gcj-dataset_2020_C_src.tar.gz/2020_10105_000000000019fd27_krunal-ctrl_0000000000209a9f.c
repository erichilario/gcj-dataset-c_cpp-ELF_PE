#include<stdio.h>
#include<string.h>
int main() {
    int t;
    scanf("%d",&t);
    while(t>0) {
        char s[100];
        scanf("%s",s);
        int j=0;
        printf("(%c",s[0]);
        for(int i=0;i<strlen(s)-1;i++) {
            if(s[i]==s[i+1]) {
                goto a; 
            }
            else {
                goto b;
            }
            a:;
                {
                    printf("%c",s[i+1]);
                    continue;
                }
            b:;
                {
                    printf(")(%c",s[i+1]);
                    continue;
                }
        }
        printf(")\n");
        
        t--;
    }
    return 0;
}
