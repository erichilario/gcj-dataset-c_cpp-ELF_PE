#include<stdio.h>
#include<string.h>

int main(){
    int t, n;
    int k, r, c;
    scanf("%d", &t);
    for(int i=0; i<t; i++){
        scanf("%d", &n);
        int m[n][n];
        int tmp[n+1];
        k = 0;
        r = 0;
        c = 0;
        for(int i=0; i<n; i++){
            for(int j=0; j<n; j++){
                scanf("%d", &m[i][j]);                
            }
        }

        for(int i=0; i<n; i++){
            memset(tmp, 0, sizeof(tmp));
            for(int j=0; j<n; j++){
                if(tmp[m[i][j]]>0){
                    r++;
                    break;
                }
                tmp[m[i][j]]++;
            }
            k += m[i][i];
        }

        for(int j=0; j<n; j++){
            memset(tmp, 0, sizeof(tmp));
            for(int i=0; i<n; i++){
                if(tmp[m[i][j]]>0){
                    c++;
                    break;
                }
                tmp[m[i][j]]++;
            }
        }

        printf("Case #%d: %d %d %d\n", i+1, k, r, c);
    }

    return 0;
}
