#include<stdio.h>
int main()
{
    int t=0,n=0,i,j,k;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d",&n);
        int st[n],et[n],in[n],tmp=0,f=0,x=0,stJ=-1,stC=0,etJ=0,etC=0; char ans[n+1];
        for(j=0;j<n;j++)
        {scanf("%d %d",&st[j],&et[j]); in[j]=j;}
        for(j=0;j<n;j++)
        {
            for(k=0;k<n-j-1;k++)
            {
                if(st[k]>st[k+1])
                {
                    tmp=st[k];
                    st[k]=st[k+1];
                    st[k+1]=tmp;
                    tmp=et[k];
                    et[k]=et[k+1];
                    et[k+1]=tmp;
                    tmp=in[k];
                    in[k]=in[k+1];
                    in[k+1]=tmp;
                }
            }
        }
        stC=st[0]; etC=et[0]; ans[in[0]]='C';
        for(j=1;j<n;j++)
        {
            if(st[j]>=etC)
            {
                etC=(et[j]>etC)?et[j]:etC; 
                ans[in[j]]='C';
            }
            else if(st[j]>=etJ)
            {
                if(stJ==-1) stJ=st[j];
                etJ=(et[j]>etJ)?et[j]:etJ;
                ans[in[j]]='J';
            }
            else
            {
                f=1; break;
            }
        }
        ans[n]='\0';
        if(f==1) printf("Case #%d: IMPOSSIBLE\n",i);
        else printf("Case #%d: %s\n",i,ans);
        
    }
    return 0;
}
