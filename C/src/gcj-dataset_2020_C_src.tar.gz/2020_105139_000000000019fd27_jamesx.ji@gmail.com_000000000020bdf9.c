#include <stdio.h>
#include <string.h>

int main(void) {
    int t; // number of test cases
    int tno = 1; // #case
    scanf("%d", &t);

    while (tno <= t) {
        int n; // number of activities
        scanf("%d", &n);
        // Scan in start and end times
        int start[1000];
        int end[1000];
        for (int i = 0; i < n; i++) {
            scanf("%d %d", &start[i], &end[i]);
        }

        int assign[1000] = { 0 }; // 1 = c, 2 = j
        int impossible = 0;

        // Go through all activities
        // Assign c to first activity
        assign[0] = 1;
        for (int i = 1; i < n && impossible == 0; i++) {
            // Check if c is free
            int c_free = 1;
            for (int k = 0; k < i && c_free == 1; k++) {
                // Compare to past activities assigned to c
                if (assign[k] == 1) {
                    if (!(end[i] <= start[k] || end[k] <= start[i])) {
                        // C is not free
                        c_free = 0;
                    }
                }
            }
            if (c_free == 1) {
                assign[i] = 1;
            } else {
                // Check if j is free
                int j_free = 1;
                for (int k = 0; k < i && j_free == 1; k++) {
                    if (assign[k] == 2) {
                        if (!(end[i] <= start[k] || end[k] <= start[i])) {
                            // J is not free
                            j_free = 0;
                        }
                    }
                }
                if (j_free == 1) {
                    assign[i] = 2;
                } else {
                    impossible = 1; // No valid assignments
                }
            }
        }
        printf("Case #%d: ", tno);

        // Check if impossible
        if (impossible == 1) {
            printf("IMPOSSIBLE");
        } else {
            for (int i = 0; i < n; i++) {
                if (assign[i] == 1) {
                    printf("C");
                } else if (assign[i] == 2) {
                    printf("J");
                }
            }
        }

        printf("\n");
        tno++;
    } 

    return 0;
}
