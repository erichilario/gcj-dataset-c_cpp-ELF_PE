#include <stdio.h>

int main() {
    int T,N,i,j,k,M[100][100],t,r,c,n[100],f1;
    
    scanf("%d",&T);
    
    for(i=1;i<=T;i++) {
        scanf("%d",&N);
        
        for(j=0;j<N;j++)
            for(k=0;k<N;k++)
                scanf("%d",&M[j][k]);
        
        t=0;
        for(j=0;j<N;j++) t=t+M[j][j];
        
        r=0;
        for(j=0;j<N;j++) {
            f1=0;
            for(k=0;k<N;k++) n[k]=0;
            for(k=0;k<N;k++) n[M[j][k]-1]++;
            for(k=0;k<N;k++) {
                if(n[k]>1) {
                    f1=1;
                    break;
                }
            }
            if(f1) r++;
        }
        
        c=0;
        for(j=0;j<N;j++) {
            f1=0;
            for(k=0;k<N;k++) n[k]=0;
            for(k=0;k<N;k++) n[M[k][j]-1]++;
            for(k=0;k<N;k++) {
                if(n[k]>1) {
                    f1=1;
                    break;
                }
            }
            if(f1) c++;
        }
        printf("Case #%d: ",i);
        printf("%d %d %d\n",t,r,c);
    }
    return 0;
}
