#include<stdio.h>
int main(){
    int T;
    scanf("%d",&T);
    for(int t=1;t<=T;t++){
        int N,s,e;
        scanf("%d",&N);
        int time[24*60+1][6];
        int rec[N+1][2];
        for(int i = 0;i<=24*60;i++){
            time[i][0]= 0;
            time[i][1]= 0;
            time[i][2]= 0;
            time[i][3]= 0;
            time[i][4]= 0;
            time[i][5]= 0;
            if(i<=N){
             rec[i][0]=0;
              rec[i][1]=0;
            }
        }
        for(int i = 1;i<=N;i++){
            scanf("%d %d",&s,&e);
            // for(int j = s;j<=e;j++){
            //     time[j]++;
            // }
            for(int j = 0;j<=5;j++){
                if(time[s][j] == 0){
                    time[s][j] =i;
                    break;
                }
            }
             for(int j = 0;j<=5;j++){
                if(time[e][j] == 0){
                    time[e][j] =i;
                    break;
                }
            }
        }
      int p[3],i,f=0;
      p[1] = 1;
      p[2] = 1;
      char per[4] = {'0','C','J','\0'};
      char result[N+2];
       result[N+1] = '\0';
      for(int j = 0;j<=1440;j++){
          for(int k=0;k<6;k++){ 
              if(time[j][k] > 0){
            i = time[j][k];
            if(rec[i][1] == 0){
                if(p[1] == 1){
                rec[i][1] = p[1];
                p[1] = 0;
                result[i] = per[1];
            }else if(p[2] == 1){
                rec[i][1] = 2;
                p[2] = 0;
                 result[i] = per[2];
            }else{
                f=1;
                break;
                
            }
            }else if(rec[i][1]>0){
              p[rec[i][1]] = 1;
              rec[i][1] = 0;
                
            }
          }else{
              break;
          }}
          if(f!=0){
              break;
          }
      }
      if(f!=1){
          printf("Case #%d: %s\n",t,result+1); 
      }else{
          printf("Case #%d: IMPOSSIBLE\n",t);
      }
        // int read = 0,count = 0,f =0;
        // for(int j =1;j<=1440;j++){
        //     if(time[j] >0){
        //         if(time[j] > 2 && count<1){
        //             count++;
        //         }else if(time[j] >2 && count == 1){
        //             f = 1;
        //             break;
        //         }else if(time[j]<3){
        //             if(read<time){
        //                 for(int k = )
        //             }
        //         }
        //     }
        // }
    }
}
