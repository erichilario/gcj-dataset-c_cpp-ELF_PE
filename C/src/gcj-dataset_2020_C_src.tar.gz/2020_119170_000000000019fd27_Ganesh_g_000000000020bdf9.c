#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
struct node
{
    int in,s,e,d;
};
int cmp(const void *a,const void *b)
{
    return ((struct node *)a)->s-((struct node *)b)->s;
}
int comp(const void *a,const void *b)
{
    return ((struct node *)a)->in-((struct node *)b)->in;
}
int main()
{
    int t,n,q,s,e,i,pe,f=0;
    scanf("%d",&t);
    for(q=1;q<=t;q++)
    {
        scanf("%d",&n);
        struct node a[n];
        f=0;
        for(i=0;i<n;i++)
        {
            scanf("%d %d",&a[i].s,&a[i].e);
            a[i].in=i;
            a[i].d=-1;
        }
        qsort(a,n,sizeof(struct node),cmp);
        pe=0;
        for(i=0;i<n;i++)
        {
            if(a[i].s>=pe)
            {
                a[i].d=0;
                pe=a[i].e;
            }
        }
        pe=0;
        for(i=0;i<n;i++)
        {
            if(a[i].d==-1 && a[i].s>=pe)
            {
                a[i].d=1;
                pe=a[i].e;
            }
        }
        printf("Case #%d: ",q);
        for(i=0;i<n;i++)
        if(a[i].d==-1)
        {
            printf("IMPOSSIBLE\n");
            f=1;
            break;
        }
        if(f==1)
        continue;
        qsort(a,n,sizeof(struct node),comp);
        for(i=0;i<n;i++)
        if(a[i].d==0)
        printf("C");
        else
        printf("J");
        printf("\n");
    }
    return 0;
}
