#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i,k,tc,n,q,flagj,flagc,out;
    char c,j;
    c='C';
    j='J';
    scanf("%d",&tc);
    for(q=0;q<tc;q++)
    {
        scanf("%d",&n);
        int ar[n][3];
        for(i=0;i<n;i++)
        {
            scanf("%d",&ar[i][0]);
            scanf("%d",&ar[i][1]);
        }
        out=1;
        ar[0][2]=c;
        for(i=1;i<n;i++)
        {
            flagc=0;flagj=0;
            for(k=0;k<i;k++)
            {
                if(ar[k][1]>ar[i][0] && ar[k][0]<ar[i][1] && ar[k][2]==j) flagj=1;
                if(ar[k][1]>ar[i][0] && ar[k][0]<ar[i][1] && ar[k][2]==c) flagc=1;
            }
            if(flagj==1 && flagc==1)
            {
                out=0;
                break;
            }
            else if(flagc==0) ar[i][2]=c;
            else if(flagj==0) ar[i][2]=j;
        }
        
        printf("Case #%d: ",q+1);
        if(out)
        {
            for(i=0;i<n;i++)
            {
                printf("%c",ar[i][2]);
            }
        }
        else
        printf("IMPOSSIBLE");
        printf("\n");
        
    }
    return 0;
}
