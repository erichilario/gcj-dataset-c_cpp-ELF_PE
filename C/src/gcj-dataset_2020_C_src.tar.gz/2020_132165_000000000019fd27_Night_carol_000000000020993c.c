

#include<stdio.h>
void
main ()
{
  int i, j, N, mat[20][20], row = 0, col = 0;
  int r = 1, c = 1, k = 0, x, T, f = 0, t = 0;
  scanf ("%d", &T);
  for (x = 1; x < T; x++)
    {
      scanf ("%d", &N);
      for (i = 0; i < N; i++)
	{
	  for (j = 0; j < N; j++)
	    {
	      scanf ("%d", &mat[i][j]);

	    }
	}


      t = mat[row][col];

      for (j = 0; j < N - 1; j++)
	{
	  if (t == mat[row][j + 1])
	    {
	      f = f + 1;
	    }
      t=mat[row][j+1];

	  if ((j == N - 2) && (row != N - 1))
	    {
	      if (f > 0)
		r = r + 1;
	      f = 0;
	      row = row + 1;
	      t = mat[row][col];
	      j = 0;

	    }

	}


      row = 0;
      col = 0;
      f = 0;
      t = mat[row][col];

      for (i = 0; i < N - 1; i++)
	{
	  if (t == mat[i + 1][col])
	    { 
	      f = f + 1;
	    }
      t=mat[i+1][col];
	  if ((i == N - 2) && (col != N - 1))
	    {
	      if (f > 0)
	    	c = c + 1;
	      f = 0;
	      col = col + 1;
	      t = mat[row][col];
	      i = 0;

	    }
	   
	
	   
	}
	



      for (i = 0; i < N; i++)
	{
	  for (j = 0; j < N; j++)
	    {
	      if (i == j)
		k = k + mat[i][j];
	    }
	}
      printf ("case  #%d: %d %d %d", x, k, r, c);
    }
}

