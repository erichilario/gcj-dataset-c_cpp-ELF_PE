#include<stdio.h>

int main() 
{ 
	int t,k=1; 
	scanf("%d",&t); 
	while(k<=t) 
	{ 
		int n,i,j,c,count=0,count1=0;
		scanf("%d",&n); 
		int a[n][n],s=0; 
		for(i=0;i<n;++i) 
		{ 
			int f[1000]={0},c=0;
			for(j=0;j<n;++j) 
			{ 
				scanf("%d ",&a[i][j]); 
				if(i==j) s+=a[i][j];
				f[a[i][j]]++;
				if(f[a[i][j]]==2) 
				{ 
					c++; 
				} 
			}
			if(c>=1) count++;
		} 
		for(j=0;j<n;++j)
		{ 
			int f[1000]={0};
			for(i=0;i<n;++i) 
			{ 
				f[a[i][j]]++; 
				if(f[a[i][j]]==2) 
				{ 
					count1++; 
					break; 
				} 
			} 
		}
		printf("Case #%d: %d %d %d\n",k,s,count,count1); 
		k++;
	}
}

