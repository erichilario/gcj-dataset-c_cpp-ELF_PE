#include<stdio.h>
#include<string.h>

void main()
{
    int t,k=0;
    scanf("%d",&t);
    while(t--){
        int d, first, num = 0, brackets = 0;
        char ch = '(', ch1 = ')';
        char str1[100],str2[100]={};
        scanf("%s",&str1);

        first = str1[0] - '0';
        num = first;
        brackets = first;

        for(int i = 0; i < first; i++)
        {
            strncat(str2,&ch,1);
        }
        strncat(str2,&str1[0],1);

        for(int i = 1; i < strlen(str1); i++)
        {
            d = str1[i] - '0';

            if(d == num)
            {
                strncat(str2,&str1[i],1);
            }
            else if(d > num)
            {
                int diff = d - num;
                for(int j = 0; j < diff; j++)
                {
                    strncat(str2,&ch,1);
                    brackets++;
                }
                strncat(str2,&str1[i],1);
            }
            else
            {
                int diff = num - d;
                for(int j = 0; j < diff; j++)
                {
                    strncat(str2,&ch1,1);
                    brackets--;
                }
                strncat(str2,&str1[i],1);
            }
            num = str1[i] - '0';
        }


        while(brackets > 0)
        {
            strncat(str2,&ch1,1);
            brackets--;
        }

        k++;
        printf("Case #%d: %s\n",k,str2);
    }
}
