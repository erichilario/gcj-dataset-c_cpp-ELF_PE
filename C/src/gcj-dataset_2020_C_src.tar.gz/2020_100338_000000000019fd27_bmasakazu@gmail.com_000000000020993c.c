#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define XSTR(x) #x
#define STR(x) XSTR(x)

#define BUF_SIZE 20
#define N_MAX    100

FILE * input_source = NULL;

#ifdef INPUT_FILE
void open_input() {
  input_source = fopen(STR(INPUT_FILE), "r"); 
}

void close_input() {
  fclose(input_source);
}

#else
void open_input() {
  input_source = stdin;
}

void close_input() {

}
#endif

int main()
{
    char* buffer = NULL;
    size_t read_size;
    int matrix_size;
    bool seen_in_row[N_MAX][N_MAX];
    bool seen_in_col[N_MAX][N_MAX];

    bool dup_in_row[N_MAX];
    bool dup_in_col[N_MAX];

    open_input();

    getline(&buffer,&read_size,input_source);

    int num_tests = atoi(buffer);

    /* 1 index testcase number*/
    for (int t = 1; t <= num_tests; t++)
    {
       int diag_sum = 0;
       memset(seen_in_row, false, sizeof(seen_in_row));
       memset(seen_in_col, false, sizeof(seen_in_col));
       memset(dup_in_row, false, sizeof(dup_in_row));
       memset(dup_in_col, false, sizeof(dup_in_col));
       int num_dup_rows = 0;
       int num_dup_cols = 0;

       getline(&buffer,&read_size,input_source);

       matrix_size = atoi(buffer);

       /* Process row */
       for (int row = 0; row < matrix_size; row++)
       {
         getline(&buffer,&read_size,input_source);
         char *cursor = buffer;
         char *element;

         /* Process elements in row */
         for (int col = 0; col < matrix_size; col++)
         {
           element = cursor;
           while(*cursor != ' ' && *cursor != '\n')
           {
             cursor++;
           }
           *cursor = '\0';
           int entry = atoi(element);

           /* diagnol entry*/
           if (row == col)
           {
             diag_sum += entry;
           }

           /* we found duplicate in row */
           if (seen_in_row[row][entry])
           {
             /* first time duplicate in row */
             if (!dup_in_row[row])
             {
               num_dup_rows++;
               dup_in_row[row] = true;
             }
           }
           seen_in_row[row][entry] = true;

           /* we found duplicate in col */
           if (seen_in_col[col][entry])
           {
             /* first time duplicate in col */
             if (!dup_in_col[col])
             {
               num_dup_cols++;
               dup_in_col[col] = true;
             } 
           }
           seen_in_col[col][entry] = true;

           cursor++;
         }
       }

       fprintf(stdout, "Case #%d: %d %d %d\n", t, diag_sum, num_dup_rows, num_dup_cols);
    }

    free(buffer);
    close_input();
    return 0;
}

