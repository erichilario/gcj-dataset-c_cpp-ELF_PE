#include <stdio.h>
#include <string.h>

int tcase,n,MAP[110][110];
int K,R,C;

short vis[110];

int main()
{
    int cas,i,j;

    scanf("%d",&tcase);
    for(cas=1;cas<=tcase;cas++)
    {
        scanf("%d",&n);
        for(i=1;i<=n;i++) for(j=1;j<=n;j++) scanf("%d",&MAP[i][j]);

        K = R = C = 0;
        for(i=1;i<=n;i++) K += MAP[i][i];
        for(i=1;i<=n;i++)
        {
            memset(vis,0,sizeof(short)*(n+3));
            for(j=1;j<=n;j++)
            {
                if(vis[MAP[i][j]]) { R++; break; }
                vis[MAP[i][j]] = 1;
            }
        }
        for(j=1;j<=n;j++)
        {
            memset(vis,0,sizeof(short)*(n+3));
            for(i=1;i<=n;i++)
            {
                if(vis[MAP[i][j]]) { C++; break; }
                vis[MAP[i][j]] = 1;
            }
        }

        printf("Case #%d: %d %d %d\n",cas,K,R,C);
    }

    return 0;
}

