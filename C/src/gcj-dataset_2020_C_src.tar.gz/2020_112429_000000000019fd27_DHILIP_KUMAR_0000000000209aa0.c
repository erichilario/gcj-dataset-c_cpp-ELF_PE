#include<stdio.h>
int main()
{
    int T,N,K;
    scanf("%d",&T);
    for (i=0;i<T;i++0)
        scanf("%d %d",&N,&K);
    printf("POSSIBLE");
    return 0;
}
