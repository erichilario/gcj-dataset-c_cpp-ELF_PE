#include<stdio.h>
int main()
{
    int i,t,j,n,ri,ci,r,c;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        r=0;
        c=0;
        scanf("%d",&n);
        int mat[n][n],check[n],k=0;
        for(ri=0;ri<n;ri++)
        {
            for(ci=0;ci<n;ci++)
            {
                scanf("%d",&mat[ri][ci]);
            }
        }
        for(ri=0;ri<n;ri++)
            k+=mat[ri][ri];
        for(ri=0;ri<n;ri++)
        {
            for(j=0;j<n;j++)
                 check[j]=0;
            for(ci=0;ci<n;ci++)
            {
                if(check[(mat[ri][ci])-1]==0)
                    check[(mat[ri][ci])-1]=1;
                 else if(check[(mat[ri][ci])-1]==1)
                 {
                   r++;
                   break;
                 }
            }
        }
        for(ci=0;ci<n;ci++)
        {
            for(j=0;j<n;j++)
                 check[j]=0;
            for(ri=0;ri<n;ri++)
            {
                if(check[(mat[ri][ci])-1]==0)
                    check[(mat[ri][ci])-1]=1;
                 else if(check[(mat[ri][ci])-1]==1)
                 {
                   c++;
                   break;
                 }
            }
        }
        printf("Case #%d: %d %d %d\n",(i+1),k,r,c);
    }
}
