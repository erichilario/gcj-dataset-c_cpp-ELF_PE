#include <stdio.h>
#include <memory.h>

int B;
int arr[105];

void reverse() {
	int tmp;

	for (int i = 1; i <= B / 2; i++) {
		tmp = arr[i];
		arr[i] = arr[B - i + 1];
		arr[B - i + 1] = tmp;
	}
}

void complement() {
	for (int i = 1; i <= B; i++) {
		arr[i] = (arr[i] + 1) % 2;
	}

}

int main(void) {
	int t, T;
	int i;
	int rev_chk_idx = -1;
	int comp_chk_idx = -1;
	int tmp;

	scanf("%d%d", &T, &B);

	for (t = 1; t <= T; t++) {
		memset(arr, -1, sizeof(arr));
		int idx = 1;

		while (idx <= B/2) {
			int count = 0;

			//fluctuation  happens
			if (rev_chk_idx != -1) {
				printf("%d", rev_chk_idx);
				fflush(stdout);
				scanf("%d", &tmp);
				count++;

				if (tmp != arr[rev_chk_idx])
					reverse();
			}

			if (comp_chk_idx != -1) {
				printf("%d", comp_chk_idx);
				fflush(stdout);
				scanf("%d", &tmp);
				count++;

				if (tmp != arr[comp_chk_idx])
					complement();
			}

			for (i = 0; i < 4; i++) {
				if (idx > B / 2)
					goto out;

				printf("%d", idx);
				fflush(stdout);
				scanf("%d", &arr[idx]);
		
				printf("%d", B - idx + 1);
				fflush(stdout);
				scanf("%d", &arr[B - idx + 1]);
				

				if (rev_chk_idx == -1) {
					if (arr[idx] == arr[B - idx + 1])
						rev_chk_idx = idx;
				}

				if (comp_chk_idx == -1) {
					if (arr[idx] != arr[B - idx + 1])
						comp_chk_idx = idx;
				}

				count+=2;
				idx++;
			}

			// useless query
			while (count < 10) {
				printf("1");
				fflush(stdout);
				scanf("%d", &tmp);
				count++;
			}
		}
out:
		for (i = 1; i <= B; i++)
			printf("%d", arr[i]);
		printf("\n");
		fflush(stdout);

		char c;
		scanf("%c", &c);

		if (c == 'N')
			break;
	}
}
