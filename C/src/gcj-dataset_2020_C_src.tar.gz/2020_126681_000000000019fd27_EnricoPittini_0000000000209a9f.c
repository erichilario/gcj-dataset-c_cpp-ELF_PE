#include<stdio.h>
#include<string.h>
#include<stdlib.h>

/*void stampa(char *S){
    int i;
    for(i=0;S[i]!='\0';i++)
      printf("%c",S[i]);

}*/
char *compute(char *S){
  int dimRes=2*strlen(S);
    char *res=(char *)malloc(sizeof(char)*(dimRes));
    int i=0,j=0;
    memset(res,0,dimRes);
    //printf("res: %s\n",res);
    while(S[i]!='\0'){
        int k=i;
        while(S[k]!='\0' && S[k]!='0')
          k++;
        if(i==k){
          if(j+2>dimRes){
              res=realloc(res,sizeof(char)*2*dimRes);
              dimRes=dimRes*2;
          }
          res[j]='0';
          j++;
          i++;
        }
        else{
          int min=S[i];
          int index;
          char *news=(char *)malloc(sizeof(char)*(k+1));
          char *rec;
          for(index=i;index<k;index++){
              if(S[index]<min)
                min=S[index];
          }
          min=min-'0';
          for(index=0;index<k-i;index++)
            news[index]=S[index+i]-min;
          news[index]='\0';
          //printf("news: %s\n",news);
          rec=compute(news);
          //printf("rec: %s\n",rec);
          if(j+2*min+strlen(rec)+1>dimRes){
              dimRes=dimRes*2+strlen(rec)+2*min+1;
              res=realloc(res,sizeof(char)*dimRes);
          }
          for(index=0;index<min;index++,j++)
            res[j]='(';
          for(index=0;index<strlen(rec);index++,j++){
              res[j]=(rec[index]!='(' && rec[index]!=')')?rec[index]+min:rec[index];
          }
          for(index=0;index<min;index++,j++)
            res[j]=')';
          free(rec);
          free(news);

          i=k;
        }
      //  printf("res: %s\n",res);
    }
    /*if(res[j-1]=='1'){
      if(j+2>dimRes)
          res=realloc(res,sizeof(char)*2*dimRes);
      res[j]=')';
      j++;
    }*/

    res[j]='\0';
    return res;

}
int main(){
      int T,i;
      char S[101];
      char *res;
      scanf("%d",&T);
      for(i=1;i<=T;i++){
          scanf("%s",S);
          res=compute(S),
          printf("Case #%d: %s\n",i,res);
          free(res);
      }
      return 0;
}

