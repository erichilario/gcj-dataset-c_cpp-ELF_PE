#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

int main()
{
    int T, t;
    int N, mat[100][100], dup[100];
    int k, r, c;
    int i, j;

    scanf( "%d\n", &T );
    for( t = 1 ; t <= T ; t++ )
    {
        k = r = c = 0;

        scanf( "%d\n", &N );
        for( i = 0 ; i < N ; i++ )
        {
            for( j = 0 ; j < N ; j++ )
                scanf( "%d ", &mat[i][j] );
        }

        for( i = 0 ; i < N ; i++ )
            k += mat[i][i];

        for( i = 0 ; i < N ; i++ )
        {
            memset( dup, 0, sizeof(int)*100 );
            for( j = 0 ; j < N ; j++ )
            {
                if( ++dup[mat[i][j]] > 1 )
                {
                    r++;
                    break;
                }
            }
        }

        for( i = 0 ; i < N ; i++ )
        {
            memset( dup, 0, sizeof(int)*100 );
            for( j = 0 ; j < N ; j++ )
            {
                if( ++dup[mat[j][i]] > 1 )
                {
                    c++;
                    break;
                }
            }
        }

        printf( "Case #%d: %d %d %d\n", t, k, r, c );
    }

    return 0;
}

