#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

void process_test_case(int test_case_number)
{
	char s[101];
	int i, c = 0, j;

	scanf(" %s", s);
	printf("Case #%d: ", test_case_number + 1);
	for(i = 0; s[i] != 0; i++)
	{
		if(s[i] - '0' > c)
			for(j = 0; j < s[i] - '0' - c; j++)
				printf("(");
		if(s[i] - '0' < c)
			for(j = 0; j < c - (s[i] - '0'); j++)
				printf(")");
		printf("%c", s[i]);
		c = s[i] - '0';
	}
	for(j = 0; j < c; j++)
		printf(")");
	printf("\n");
}

int main()
{
	int num_test_cases, test_case;

	scanf("%d", &num_test_cases);
	for(test_case = 0; test_case < num_test_cases; test_case++)
		process_test_case(test_case);

	return 0;
}

