#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(void) {
    int test_cases,k=0;
    scanf("%d",&test_cases);
    getchar();
    while(test_cases--)
    {
        int b_count=0;
        char str[100],str1[2];
        gets(str);
        char final[1000]="";
        for(int j=0;j<(int)str[0]-48;j++)
        {
            strcat(final,"(");
            b_count++;
        }
        str1[0]=str[0];
        str1[1]='\0';
        strcat(final,str1);
        for(int i=1;str[i]!='\0';i++)
        {
            if(str[i]==str[i-1])
            {
                str1[0]=str[i];
                str1[1]='\0';
                strcat(final,str1);
            }
            else if((int)str[i]>(int)str[i-1])
            {
                for(int j=0;j<(int)(str[i])-(int)(str[i-1]);j++)
                {
                    strcat(final,"(");
                    b_count++;
                }
                str1[0]=str[i];
                str1[1]='\0';
                strcat(final,str1);
            }
            else
            {
                for(int j=0;j<(int)str[i-1]-(int)str[i];j++)
                {
                    strcat(final,")");
                    b_count--;
                }
                str1[0]=str[i];
                str1[1]='\0';
                strcat(final,str1);
            }
        }
        for(int i=0;i<b_count;i++)
        {
            strcat(final,")");
        }
        printf("Case #%d: %s\n",++k,final);
    }
    return 0;
}
