#include <stdio.h>

int main()
{
    int cas;
    scanf("%d",&cas);
    for (int k = 1; k <=cas; k++){
        int n;
        scanf("%d", &n);
        int copy[n][3];
        for (int i = 0; i < n; i++){
            for (int j = 0; j < 2; j++){
                scanf("%d", &copy[i][j]);
            }
            copy[i][2] = i;
        }
        char result[n];
        for (int i = 0; i<n; i++)
            copy[i][2] = i;
        for (int i = 1; i<n; i++)
        {
            int j = i;
            while (j>0 && copy[j][0]<copy[j-1][0]){
                int swap[1][3];
                for (int k =0; k<3; k++){
                    swap[0][k] = copy[j][k];
                    copy[j][k] = copy[j-1][k];
                    copy[j-1][k] = swap[0][k];
                }
                j--;
            }
        }

        int c = 0;int j = 0;int Error=0;
        for (int s = 0; s < n; s++)
        {
            if (copy[s][0] >= c){
                result[copy[s][2]] = 'C';
                c = copy[s][1];
            }
            else if (copy[s][0] >= j){
                result[copy[s][2]] = 'J';
                j = copy[s][1];
            }
            else
            {
                Error = 1;
                break;
            }
            
        }
        if (Error) printf("Case #%d: IMPOSSIBLE\n", k);
        else{
            printf("Case #%d: ", k);
            for (int s=0; s<n; s++) printf("%c", result[s]);
            printf("\n");
        }
    
    }
    return 0;
}


