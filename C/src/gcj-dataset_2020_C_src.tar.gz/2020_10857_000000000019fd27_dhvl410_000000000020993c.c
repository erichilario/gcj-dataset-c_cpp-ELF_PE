#include<stdio.h>
int main() {
    int t;
    scanf("%d",&t);
    while(t>0) {
        int n;
        scanf("%d",&n);
        int a[n][n];
        
        for(int i=0;i<n;i++) {
            for(int j=0;j<n;j++) {
                scanf("%d",&a[i][j]);
            }
        }
        int sum=0,r=0,c=0;
        for(int i=0;i<n;i++) {
            sum+=a[i][i];
        }
        int cntr[n+1];
        int cntc[n+1];
        for(int z=0 ; z<=n ; z++)
        {
            cntr[z]=0;
            cntc[z]=0;
        }
        for(int i=0 ; i<n ; i++)
        {
            for(int j=0 ; j<n ; j++)
            {
                cntr[ a[i][j] ]++;
                cntc[ a[j][i] ]++;
            }
            int flag1=1,flag2=1;
            for(int k=1 ;k<=n ; k++)
            {
                if(cntr[k]>1 && flag1)
                {
                    r++;
                    flag1=0;
                }

                if(cntc[k]>1 && flag2)
                {
                    c++;
                    flag2=0;
                }

                cntc[k]=0;
                cntr[k]=0;
            }
        printf("%d %d %d",sum,r,c);
        
        printf("\n");
        t--;
    }
    return 0;
}
