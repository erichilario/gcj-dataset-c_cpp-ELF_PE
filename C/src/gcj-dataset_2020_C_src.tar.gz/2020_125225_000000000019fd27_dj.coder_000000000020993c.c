#include<stdio.h>

// solve
void solve(int (*A)[100], int N, int *track, int *k, int *r, int *c) {
    int i, j, t, a, dr, dc;
    t = 0;
    i = j = 0;
    // trace computation
    while(i < N && j < N) {
        t += A[i][j];
        i++;
        j++;
    }
    *k = t;
    // row wise scan
    dr = 0;
    for(i = 0; i < N; i++) {
        memset(track, 0, (N + 1) * sizeof(int));
        for(j = 0; j < N; j++) {
            a = A[i][j];
            track[a]++;
            if(track[a] > 1) {
                // duplicates
                dr++;
                break;
            }
        }
    }
    *r = dr;
    // column wise scan
    dc = 0;
    for(j = 0; j < N; j++) {
        memset(track, 0, (N + 1) * sizeof(int));
        for(i = 0; i < N; i++) {
            a = A[i][j];
            track[a]++;
            if(track[a] > 1) {
                // duplicates
                dc++;
                break;
            }
        }
    }
    *c = dc;
}

int main() {
    
    int T, tc, N, k, r, c, i, j;
    int A[100][100], track[101];
    
    scanf("%d", &T);
    tc = 0;
    while(++tc <= T) {
        scanf("%d", &N);
        for(i = 0; i < N; i++) {
            for(j = 0; j < N; j++) {
                scanf("%d", &A[i][j]);
            }
        }
        // solve
        solve(A, N, track, &k, &r, &c);
        printf("Case #%d: %d %d %d\n", tc, k, r, c);
    }
    
    return 0;
}
