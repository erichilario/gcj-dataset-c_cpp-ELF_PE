#include<stdio.h>
int main()
{
    int t,ti=0;
    scanf("%d",&t);
    while(t--)
    {
        ti++;
        int n,s;
        scanf("%d %d",&n,&s);
        if(n==2)
        {
            if(s==2)
            {
                printf("Case #%d: POSSIBLE\n1 2\n2 1\n",ti);
            }
            else if(s==4)
            {
                printf("Case #%d: POSSIBLE\n2 1\n1 2\n",ti);
            }
            else
            {
                printf("Case #%d: IMPOSSIBLE\n",ti);
            }
            continue;
        }
        int a[n][n],i,j,st=0;
        for(i=0;i<n;i++)
        a[0][i]=i+1;
        for(i=1;i<n;i++)
        {
            a[i][0]=a[i-1][n-1];
            for(j=1;j<n;j++)
            {
                a[i][j]=a[i-1][j-1];
            }
        }
        
        int cc1,cc2,rc1,ta[n][n],ca[n][n],ra[n][n];
        for(cc1=0;cc1<n;cc1++)
        {
            for(i=0;i<n;i++)
            {
                ta[i][n-1]=a[i][0];
                for(j=0;j<n-1;j++)
                {
                    ta[i][j]=a[i][j+1];
                }
            }
            st=0;
            for(i=0;i<n;i++)
            st+=ta[i][j];
            if(st==s)
            {
                printf("Case #%d: POSSIBLE\n",ti);
                for(i=0;i<n;i++)
                {
                    for(j=0;j<n;j++)
                        {
                            printf("%d ",ta[i][j]);
                        }
                    printf("\n");
                }
                goto out;
            }
            for(i=0;i<n;i++)
            {
                for(j=0;j<n;j++)
                {
                a[i][j]=ta[i][j];
                }
            }
            for(rc1=0;rc1<n;rc1++)
            {
            for(j=0;j<n;j++)
            {
                ra[n-1][j]=ta[0][j];
            }
            for(i=0;i<n-1;i++)
            {
                for(j=0;j<n;j++)
                {
                    ra[i][j]=ta[i+1][j];
                }
            }
            st=0;
            for(i=0;i<n;i++)
            st+=ra[i][j];
            if(st==s)
            {
                printf("Case #%d: POSSIBLE\n",ti);
                for(i=0;i<n;i++)
                {
                    for(j=0;j<n;j++)
                        {
                            printf("%d ",ra[i][j]);
                        }
                    printf("\n");
                }
                goto out;
            }
            for(i=0;i<n;i++)
            {
                for(j=0;j<n;j++)
                {
                ta[i][j]=ra[i][j];
                }
            }
            
            for(cc2=0;cc2<n;cc2++)
            {
            for(i=0;i<n;i++)
            {
                ca[i][n-1]=ra[i][0];
            }
            for(i=0;i<n;i++)
            {
                for(j=0;j<n-1;j++)
                {
                    ca[i][j]=ra[i][j+1];
                }
            }
            st=0;
            for(i=0;i<n;i++)
            st+=ca[i][j];
            if(st==s)
            {
                printf("Case #%d: POSSIBLE\n",ti);
                for(i=0;i<n;i++)
                {
                    for(j=0;j<n;j++)
                        {
                            printf("%d ",ca[i][j]);
                        }
                    printf("\n");
                }
                goto out;
            }
            for(i=0;i<n;i++)
            {
                for(j=0;j<n;j++)
                {
                ra[i][j]=ca[i][j];
                }
            }
            }
            
            }
        }
        
        printf("Case #%d: IMPOSSIBLE\n",ti);
        out:
        continue;
    }
    return 0;
}
