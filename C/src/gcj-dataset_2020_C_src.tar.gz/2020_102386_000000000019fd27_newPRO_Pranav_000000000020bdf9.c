#include <stdio.h>

void swap(int *a,int*b) {
    int t=*a; *a=*b; *b=t; 
}

int main() {
    int T,N,S[1000],E[1000],n[1000],y[1000],i,j,k,min,f1,f2,f3;
    
    scanf("%d",&T);
    for(i=1;i<=T;i++) {
        scanf("%d",&N);
        
        for(j=0;j<N;j++) {
            scanf("%d %d",&S[j],&E[j]);
            n[j]=j;
        }
        
        for(j=0;j<N;j++) {
            min=S[j];
            for(k=j;k<N;k++) {
                if(S[k]<min) {
                    min=S[k];
                    swap(&S[j],&S[k]);
                    swap(&E[j],&E[k]);
                    swap(&n[j],&n[k]);
                }
            }
        }
        
        y[n[0]]=1; f3=0;
        for(j=1;j<N;j++) {
            f1=0; f2=0;
            for(k=j-1;k>=0;k--) {
                if(S[j]<E[k]) {
                    if(y[n[k]]==1) f1=1;
                    else if(y[n[k]]==2) f2=1;
                }
            }
            if(f1&&f2) {
                f3=1;
                break;
            }
            else if(f1) y[n[j]]=2;
            else y[n[j]]=1;
        }
        printf("Case #%d: ",i);
        if(f3) printf("IMPOSSIBLE");
        else {
            for(j=0;j<N;j++) {
                if(y[j]==1) printf("C");
                else if(y[j]==2) printf("J");
                else printf("%d",y[j]);
            }
        }
        printf("\n");
    }
    return 0;
}
