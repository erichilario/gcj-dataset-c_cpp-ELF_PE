#include <stdio.h>
#include <stdlib.h>

int compare(const void *a, const void *b){
    int aa = *(int*)a;
    int bb = *(int*)b;
    return aa - bb;
}

int main(){
    int T;
    scanf("%d", &T);
    for(int I = 1; I <= T; I++){
        int N;
        int act[1001][3] = {0};
        printf("Case #%d: ", I);
        scanf("%d", &N);
        for(int J = 0; J < N; J++){
            int start, end;
            scanf("%d %d", &start, &end);
            act[J][0] = start;
            act[J][1] = end;
            act[J][2] = J;
        }
        qsort(act, N, sizeof(act[0]), compare);
        /*
        for(int J = 0; J < N; J++){
            printf("%d %d\n", act[J][0], act[J][1]);
        }
        */
        int jStart = -1, jEnd = 0;
        jStart = act[0][0];
        int jMark[1001] = {0};
        
        int cStart = -1, cEnd = 0;
        int cMark[1001] = {0};
        
        int impossible = 0;
        
        for(int i = 0; i < N; i++){
            if( act[i][0] >= jEnd ){
                // Jamie can take this job
                jEnd = act[i][1];
                jMark[act[i][2]] = 1;
            }
            else{
                if( act[i][0] >= cEnd ){
                    // Cameraon can take this job
                    cEnd = act[i][1];
                    cMark[act[i][2]] = 1;
                    if( cStart < 0 ){
                        cStart = act[i][0];
                    }
                }
                else{
                    impossible = 1;
                    printf("IMPOSSIBLE");
                    break;
                }
            }
        }
        if(!impossible){
            for(int i = 0; i < N; i++){
                if( jMark[i] ){
                    printf("J");
                }
                if( cMark[i] ){
                    printf("C");
                }
            }
        }
        printf("\n");
    }
    return 0;
}
