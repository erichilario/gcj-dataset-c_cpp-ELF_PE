#include<stdio.h>
#include<string.h>
int main()
{
	int n;
	int x=1;
	scanf("%d",&n);
	while(n--)
	{
		char s[102];
		memset(s,0,102*sizeof(char));
		scanf("%s",s);
		int i=0,kuohao=0;
		printf("Case #%d: ",x);
		while(s[i]!='\0')
		{
			if(s[i]-'0'>kuohao)
			{
				for(int m=1;m<=s[i]-'0'-kuohao;m++)
				{
					printf("(");
				}
				printf("%c",s[i]);
				kuohao=s[i]-'0';
			}
			else if(s[i]-'0'<kuohao)
			{
				for(int m=1;m<=kuohao-(s[i]-'0');m++)
				{
					printf(")");
				}
				printf("%c",s[i]);
				kuohao=s[i]-'0';
			}
			else if(s[i]-'0'==kuohao)
			{
				printf("%c",s[i]);
			}
			i++;
		}
		for(int m=kuohao;m>0;m--)
			printf(")");
		printf("\n");
		 x++;
	}
	return 0;
}
