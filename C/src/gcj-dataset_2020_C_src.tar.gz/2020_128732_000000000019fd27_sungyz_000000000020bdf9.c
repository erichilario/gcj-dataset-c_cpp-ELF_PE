#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

int main()
{
    int T, t;
    int N, time[2][1440], empty[2];
    typedef struct
    {
        int index;
        int st, et;
        char    cj;
    } Act;
    Act     act[1000];
    char    y[1001];
    int st, et;
    int i, j, k, impossible;

    scanf( "%d\n", &T );
    for( t = 1 ; t <= T ; t++ )
    {
        memset( time[0], -1, sizeof(int)*1440 );
        memset( time[1], -1, sizeof(int)*1440 );
        memset( y, 0, sizeof(char)*1001 );
        memset( act, 0, sizeof(Act)*1000 );
        impossible = 0;

        scanf( "%d\n", &N );
        for( i = 0 ; i < N ; i++ )
        {
            scanf( "%d %d\n", &st, &et );
            act[i].index = i;
            act[i].st = st;
            act[i].et = et;
            for( j = 0 ; j < i ; j++ )
            {
                if( act[j].st < st )
                    continue;
                if( act[j].st == st && act[j].et > et )
                    continue;
                for( k = i-1 ; k >= j ; k-- )
                    memcpy( &act[k+1], &act[k], sizeof(Act) );
                act[j].index = i;
                act[j].st = st;
                act[j].et = et;
                break;
            }
        }

        for( i = 0 ; i < N ; i++ )
        {
            empty[0] = empty[1] = 1;
            for( j = act[i].st ; j < act[i].et ; j++ )
            {
                if( time[0][j] != -1 )
                    empty[0] = 0;
                if( time[1][j] != -1 )
                    empty[1] = 0;
            }

            if( empty[0] )
            {
                for( j = act[i].st ; j < act[i].et ; j++ )
                    time[0][j] = i;
                act[i].cj = 'C';
            }
            else if( empty[1] )
            {
                for( j = act[i].st ; j < act[i].et ; j++ )
                    time[1][j] = i;
                act[i].cj = 'J';
            }
            else
            {
                impossible = 1;
                break;
            }
        }

        if (impossible)
            strcpy( y, "IMPOSSIBLE" );
        else
        {
            for( i = 0 ; i < N ; i++ )
                y[act[i].index] = act[i].cj;
        }

        printf( "Case #%d: %s\n", t, y );
    }

    return 0;
}

