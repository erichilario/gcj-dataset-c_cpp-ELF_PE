#include <stdio.h>

int l[1003];
int r[1003];
int c[1003];
int n;

int dfs( int i, int col ) {
	c[i] = col;
	int ans = 1;
	for( int j=0; j<n; ++j ) {
		if( j == i ) continue;
		if(  r[i]<l[j] || r[j]<l[i] ) continue;
		if( c[j] == -1 ) {
			if( dfs(j, 1-col) == 0 )
				ans = 0;
			continue;
		}
		if( c[j] == 1-c[i] ) continue;
		// printf("%d %d intersect wit diff colors\n", i, j);
		ans = 0;
	}
	return ans;
}

int main() {
	int t;
	scanf("%d", &t);
	for( int tt=1; tt<=t; ++tt ) {
		scanf("%d", &n);
		for( int i=0; i<n; ++i ) {
			scanf("%d%d", l+i, r+i);
			r[i] -= 1;
		}
		for( int i=0; i<n; ++i )
			c[i] = -1;
		int ans = 1;
		for( int i=0; i<n; ++i ) {
			if( c[i] == -1 ) {
				if( dfs(i,0) == 0 )
					ans = 0;
			}
		}
		if( ans == 0 ) printf("Case #%d: IMPOSSIBLE\n", tt);
		else {
			printf("Case #%d: ", tt);
			for( int i=0; i<n; ++i )
				printf("%c", "CJ"[c[i]]);
			printf("\n");
		}
	}
}
