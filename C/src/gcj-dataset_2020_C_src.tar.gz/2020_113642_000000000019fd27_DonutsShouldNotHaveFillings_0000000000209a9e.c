#include <stdio.h>
#include <stdlib.h>

int main(void) {
    setbuf(stdout, NULL);
    int ncases;
    int len;
    scanf("%d %d", &ncases, &len);

    return 0;
}
