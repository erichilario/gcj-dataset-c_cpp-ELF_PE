#include<stdio.h>
int main(){
    int T;
    scanf("%d",&T);
    for(int t =1;t<=T;t++){
        char S[101];
        scanf("%s",S);
        char set[1801];
        int p = 0,c = 0,index = 0;
        for(int i = 0;i<=100;i++){
           c = S[i] - 48;
         if(c>=0 && c<=9){
             if(c>p){
               for(int j = 1;j<=c-p;j++){
                   set[index] = '(';
                   index++;
                   
               }
               set[index] = S[i];
               index++;
               p = c;
           }else if(c<p){
               for(int j =1;j<=p-c;j++){
                    set[index] = ')';
                   index++;
                   
               }
               set[index] = S[i];
               index++;
               p =c;
           }else if(c == p){
               set[index] = S[i];
               index++;
           }
             
         }else{
             for(int j =1;j<=p;j++){
                    set[index] = ')';
                   index++;
                   
               }
             set[index] = '\0';
             break;
         }
        }
        printf("Case #%d: %s\n",t,set);
    }
}
