#include<stdio.h>
#include<string.h>
#define ll long long int

int main()
{
        int t,T;
        scanf("%d",&T);
        t=1;
        while(t<=T)
        {
                char str[200];
                scanf("%s",str);

                int len=strlen(str);

                int arr[len];
                for(int i=0;i<len;i++)
                        arr[i]=(int)str[i]-(int)'0';

                printf("Case #%d: ",t);
                int i= arr[0];
                while(i--)
                        printf("(");
                printf("%d",arr[0]);

                int OB=arr[0];

                for(int i=1;i<len;i++)
                {
                        if(arr[i]==arr[i-1])
                                printf("%d",arr[i]);
                        else if(arr[i]<arr[i-1])
                        {
                                int k=arr[i-1]-arr[i];
                                OB -= k;
                                while(k--)
                                        printf(")");
                                printf("%d",arr[i]);
                        }
                        else
                        {
                                int k=arr[i]-arr[i-1];
                                OB += k;
                                while(k--)
                                        printf("(");
                                printf("%d",arr[i]);
                        }
                }

                while(OB--)
                        printf(")");
                printf("\n");
                t++;
        }

        return 0;
}

