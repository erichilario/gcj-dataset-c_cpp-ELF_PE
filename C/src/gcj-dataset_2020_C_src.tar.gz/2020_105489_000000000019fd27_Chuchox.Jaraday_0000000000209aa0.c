#include <stdio.h>

int main(void){
    int cases, casos, i, j, l, m, sal;
    int n, k, x, y;
    int indice, encontrado;
    int matriz[51][51];
    int intentos[51];
    unsigned int s;

    scanf("%d\n",&cases);
    for(casos=1;casos<=cases;casos++){
        scanf("%d %d\n",&n,&k);
        if((k<n)||(k>n*n)){
            printf("Case #%d: IMPOSSIBLE\n",casos);
            continue;
        }
        if((k == (n+1))||(k == (n*n - 1))){
            printf("Case #%d: IMPOSSIBLE\n",casos);
            continue;
        }
        printf("Case #%d: POSSIBLE\n",casos);
        if((k % n)==0){
            sal = k / n;
            for(i=0;i<n;i++){
                for(j=0;j<n;j++){
                    printf("%d",sal);
                    sal++;
                    if(sal == (n+1)){
                        sal = 1;
                    }
                    if(j == (n-1)){
                        printf("\n");
                    }else{
                        printf(" ");
                    }
                }
                sal--;
                if(sal == 0){
                    sal = n;
                }
            }
            continue;
        }

        //inicializamos
        for(i=0;i<n;i++){
            for(j=0;j<n;j++){
                matriz[i][j] = -1;
            }
        }
        //calculamos la traza
        if((k % n) == 1){
            s = k/n - 1;
        }else{
            s = k/n;
        }
        for(i=0;i<n;i++){
            matriz[i][i] = s;
        }
        s = k%n;
        if(s == 1){
            s += n;
        }
        j=n-1;
        while(s){
            matriz[j][j]++;
            s--;
            j--;
            if(j == (n/2)-1){
                j=n-1;
            }
        }
        //reyenamos lo facil
        s = matriz[0][0];
        indice = 0;
        while(s == matriz[indice][indice]){
            indice++;
        }
        for(i=indice;i<(n-1);i++){
            matriz[i][i+1] = s;
        }
        matriz[n-1][indice] = s;
        matriz[0][1] = matriz[indice][indice];
        if(matriz[indice][indice] != matriz[n-1][n-1]){
            matriz[0][2] = matriz[n-1][n-1];
            indice = 3;
        }else{
            indice = 2;
        }
        //reyenamos el primer renglon
        for(i=1;i<=n;i++){
            for(j=0;j<indice;j++){
                if(matriz[0][j] == i){
                    break;
                }
            }
            if(j==indice){
                matriz[0][indice] = i;
                indice++;
            }
        }
        //////
        /*printf("Tenemos el primer renglon\n");
        for(i=0;i<n;i++){
            for(j=0;j<n;j++){
                if(matriz[i][j] == -1){
                    printf("x");
                }else{
                    printf("%d",matriz[i][j]);
                }
                if(j == (n-1)){
                    printf("\n");
                }else{
                    printf(" ");
                }
            }
        }*/
        //////
        //los de abajo
        for(y=1;y<n;y++){
            s = matriz[0][y];
            //printf("Terminamos de reyenar %d\n",s);
            for(l=0;l<n;l++){
                intentos[l] = 1;
            }
            i = 1;
            j = y+1;
            if(j == n){
                j = 0;
            }
            while(i<n){
                while(matriz[i][j] != -1){
                    j++;
                    if(j==n){
                        j=0;
                    }
                }
                //vemos que no este ya en la fila
                encontrado = 0;
                for(l=0;l<n;l++){
                    if(s == matriz[i][l]){
                        encontrado = 1;
                        break;
                    }
                }
                if(encontrado){
                    i++;
                    continue;
                }
                //vemos que no este ya en la columna
                for(l=0;l<n;l++){
                    if(s == matriz[l][j]){
                        encontrado = 1;
                        break;
                    }
                }
                if(encontrado){
                    l = 0;
                    intentos[l]++;
                    //printf("\tl0=%d l1=%d",intentos[0],intentos[1]);
                    while(intentos[l]==n){
                        i--;
                        //printf("\tEstamos buscando un error en %d, nivel %d\n",i,l);
                        for(m=0;m<n;m++){
                            //printf("\t\tmatriz(%d,%d)=%d\n",i,m,matriz[i][m]);
                            if(s == matriz[i][m]){
                                //printf("\thacia atras en %d-niveles, quitamos en %d %d\n",l,i,m);
                                j=m;
                                matriz[i][j] = -1;
                                break;
                            }
                        }
                        intentos[l] = 1;
                        l++;
                        intentos[l] += 1;
                    }
                    j++;
                    if(j == n){
                        j = 0;
                    }
                    continue;
                }
                    //no aparecio ni por filas ni por columnas

                matriz[i][j] = s;
                //printf("\tcolocamos en %d %d\n",i,j);

                i++;
                j++;
                if(j == n){
                    j = 0;
                }
            }
            /////
            /*for(i=0;i<n;i++){
            for(j=0;j<n;j++){
                if(matriz[i][j] == -1){
                    printf("x");
                }else{
                    printf("%d",matriz[i][j]);
                }
                if(j == (n-1)){
                    printf("\n");
                }else{
                    printf(" ");
                }
            }
            }*/
            /////
        }

        //imprimimos
        //printf("Final\n");
        for(i=0;i<n;i++){
            for(j=0;j<n;j++){
                printf("%d",matriz[i][j]);
                if(j == (n-1)){
                    printf("\n");
                }else{
                    printf(" ");
                }
            }
        }

    }

    return(0);
}

