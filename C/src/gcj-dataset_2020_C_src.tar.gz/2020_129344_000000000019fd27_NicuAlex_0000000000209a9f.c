#include <stdio.h>
#include <stdlib.h>
char ch1[101];
int main()
{
    int n, i, poz, depth, j;
    char ch;
    scanf( "%d", &n );
    for ( i = 1; i <= n; i++ ) {
        ch = fgetc(stdin);
        while ( !isdigit(ch) )
          ch = fgetc(stdin);
        poz = 0;
        do{
            ch1[poz++] = ch;
            ch = fgetc(stdin);
        }while ( isdigit(ch) );
        printf( "Case #%d: ", i );
        depth = 0;
        for ( j = 0; j < poz; j++ ) {
            while ( depth < ch1[j] - '0' ) {
              fputc( '(', stdout );
              depth++;
            }
            while ( depth > ch1[j] - '0' ) {
              fputc( ')', stdout );
              depth--;
            }
            fputc( ch1[j], stdout );
        }
        while( depth > 0 ) {
            fputc( ')', stdout );
            depth--;
        }
        fputc('\n', stdout );
    }
    return 0;
}

