#include <stdio.h>
int main()
{
    int testnum;
    scanf("%d",&testnum);
    int p=1;
    while(p<=testnum)
    {
        int matrix;
        int sum;
        scanf("%d %d",&matrix,&sum);
        switch (matrix)
        {
        case 2:
            if(sum!=2 && sum!=4)
            {
                printf("Case #%d: IMPOSSIBLE\n",p);
            }
            else if(sum==2)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("1 2\n2 1\n");
            }
            else if(sum==4)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("2 1\n1 2\n");
            }
        break;

        case 3:
            if(sum!=1 && sum!=6 && sum!=7 && sum!=9)
            {
                 printf("Case #%d: IMPOSSIBLE\n",p);
            }
            else if(sum==3)
            {
                printf("Case #%d: POSSIBLE",p);
                printf("1 2 3\n3 1 2\n2 3 1\n");
            }
            else if(sum==6)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("2 1 3\n3 2 1\n1 3 2\n");
            }
            else if(sum==7)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("1 3 2\n3 2 1\n2 1 3\n");
            }
            else if(sum==9)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("1 3 2\n3 2 1\n2 1 3\n");
            }
        break;

        case 4:
            if(sum==4)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("1 2 3 4\n4 1 2 3\n3 4 1 2\n2 3 4 1\n");
            }
            if(sum==6)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("1 2 3 4\n2 1 4 3\n4 3 2 1\n3 4 1 2\n");
            }
            if(sum==8)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("3 4 1 2\n2 1 4 3\n1 2 3 4\n4 3 2 1\n");
            }
            if(sum==10)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("4 3 2 1\n2 1 4 3\n1 2 3 4\n3 4 1 2");
            }
            if(sum==12)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("4 3 2 1\n1 2 3 4\n2 1 4 3\n3 4 1 2\n");
            }
            if(sum==14)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("3 4 1 2\n4 3 2 1\n2 1 4 3\n1 2 3 4\n");
            }
            if(sum==16)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("4 3 2 1\n3 4 1 2\n2 1 4 3\n1 2 3 4\n");
            }
            else
            {
                 printf("Case #%d: IMPOSSIBLE\n",p);
            }
        break;

        case 5:
            if(sum==5)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("1 2 3 4 5\n5 1 2 3 4\n4 5 1 2 3\n3 4 5 1 2\n2 3 4 5 1\n");
            }
            if(sum==10)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("2 3 4 5 1\n1 2 3 4 5\n5 1 2 3 4\n4 5 1 2 3\n3 4 5 1 2\n");
            }
            if(sum==15)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("3 4 5 1 2\n2 3 4 5 1\n1 2 3 4 5\n5 1 2 3 4\n4 5 1 2 3\n");
            }
            if(sum==20)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("4 5 1 2 3\n3 4 5 1 2\n2 3 4 5 1\n1 2 3 4 5\n5 1 2 3 4\n");
            }
            if(sum==25)
            {
                printf("Case #%d: POSSIBLE\n",p);
                printf("5 1 2 3 4\n4 5 1 2 3\n3 4 5 1 2\n2 3 4 5 1\n1 2 3 4 5\n");
            }
            else
            {
                 printf("Case #%d: IMPOSSIBLE\n",p);
            }
        break;
        }
        p++;

    }

}

