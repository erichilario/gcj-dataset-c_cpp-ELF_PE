#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

int main()
{
    int T, t;
    char    S[101], y[2000];
    int len, opend, prev, now;
    int i, j, idx;

    scanf( "%d\n", &T );
    for( t = 1 ; t <= T ; t++ )
    {
        scanf( "%s\n", S );

        memset( y, 0, sizeof(char)*2000 );
        opend = prev = idx = 0;
        len = strlen( S );

        for( i = 0 ; i < len ; i++ )
        {
            now = S[i] - '0';
            if( prev < now )
            {
                for( j = 0 ; j < now-prev ; j++ )
                    y[idx++] = '(';
                y[idx++] = S[i];
                opend += now-prev;
            }
            else if( prev > now )
            {
                for( j = 0 ; j < prev-now ; j++ )
                    y[idx++] = ')';
                y[idx++] = S[i];
                opend += now-prev;
            }
            else
            {
                y[idx++] = S[i];
            }
            prev = now;
        }

        for( i = 0 ; i < opend ; i++ )
            y[idx++] = ')';
        y[idx] = 0;

        printf( "Case #%d: %s\n", t, y );
    }

    return 0;
}

