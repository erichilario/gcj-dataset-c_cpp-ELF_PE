#include<stdio.h>
int main()
{
    int t,n,k,q,i,j,x,a[100];
    scanf("%d",&t);
    for(q=1;q<=t;q++)
    {
        scanf("%d%d",&n,&k);
        if(k%n)
        {
            printf("Case #%d: IMPOSSIBLE\n",q);
        }
        else
        {
           printf("Case #%d: POSSIBLE\n",q);
           x=k/n-1;
           for(i=0;i<n;i++)
           a[i]=(x+i)%n+1;
           for(i=0;i<n;i++)
           {
               j=x=(n-i)%n;
               do
               {
                   printf("%d ",a[j%n]);
                   j++;
               }while(j%n!=x);
               printf("\n");
           }
        }
    }
}
