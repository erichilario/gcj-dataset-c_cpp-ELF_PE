#include <stdlib.h>
#include <stdio.h>

#define BUF_SIZE 20

char* buffer = malloc(BUF_SIZE);

getline(buffer,BUF_SIZE,stdin);

int num_tests = atoi(buffer);

for (int t = 0; t < num_tests; t++)
{
    getline(buffer, BUF_SIZE,stdin);
    printf(buffer);
}
