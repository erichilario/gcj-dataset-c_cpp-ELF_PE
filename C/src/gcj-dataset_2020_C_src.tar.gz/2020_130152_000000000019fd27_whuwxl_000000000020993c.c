#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int t;
    scanf("%d", &t);
    for (int k = 1; k <= t; k++) {
        int n;
        scanf("%d", &n);
        int a[n][n];
        int sum = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                scanf("%d", &a[i][j]);
                if (i == j) {
                    sum += a[i][j];
                }
            }
        }

        int r = 0;
        int c = 0;
        for (int i = 0; i < n; i++) {
            char m[n];
            memset(m, 0, sizeof(m));
            for (int j = 0; j < n; j++) {
                if (m[a[i][j] - 1] == 1) {
                    r++;
                    break;
                }
                m[a[i][j] - 1] = 1;
            }
        }

        for (int j = 0; j < n; j++) {
            char m[n];
            memset(m, 0, sizeof(m));
            for (int i = 0; i < n; i++) {
                if (m[a[i][j] - 1] == 1) {
                    c++;
                    break;
                }
                m[a[i][j] - 1] = 1;
            }
        }

        printf("Case #%d: %d %d %d\n", k, sum, r, c);

    }
    return 0;
}

