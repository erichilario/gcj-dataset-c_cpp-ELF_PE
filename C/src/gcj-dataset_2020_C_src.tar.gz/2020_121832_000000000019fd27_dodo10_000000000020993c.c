#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int toIdx(int row, int col, int n) {
    return (row*n) + col;
}

int main(void) { 

    int cases;
    scanf("%d", &cases);
    int i = 0;


    int* grid = malloc(sizeof(int) * 101 * 101);


    while (cases--) {
        i++; 
        int n;
        scanf("%d", &n);
        
        int j = 0;
        while (j < n*n) {
            scanf("%d", &grid[j]);
            j++;
        }
        int kResult = 0;
        for (int ii =0; ii<n*n; ii+=n+1) {
           kResult += grid[ii]; 
        }

        int rResult = 0;
        for (int ii =0; ii < n; ii++) {
            int* seen = calloc(n+1, sizeof(int));
            for (int jj = 0; jj < n; jj++) {
                int x = grid[toIdx(ii, jj, n)];
                if (seen[x] == 0){
                    seen[x] += 1;
                } else {
                    rResult += 1;
                    break;
                }
            }
            free(seen);
        }
        int cResult = 0;
        for (int ii =0; ii < n; ii++) {
            int* seen = calloc(n+1, sizeof(int));
            for (int jj = 0; jj < n; jj++) {
                int x = grid[toIdx(jj, ii, n)];
                if (seen[x] == 0){
                    seen[x] += 1;
                } else {
                    cResult += 1;
                    break;
                }
            }
            free(seen);
        }

        // Print results
        printf("Case #%d: %d %d %d\n", i, kResult, rResult, cResult);

    }

    return 0;
}

