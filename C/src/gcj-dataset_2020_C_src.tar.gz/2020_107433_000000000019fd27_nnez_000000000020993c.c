#include <stdio.h>


int main(){
    int T;
    scanf("%d", &T);
    for(int I = 1; I <= T; I++){
        int N;
        scanf("%d", &N);
        int matrix[101][101] = {0};
        // i row, j col
        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                scanf("%d", &matrix[i][j]);
            }
        }
        int R = 0, C = 0;
        for(int i = 0; i < N; i++){
            int H_r[101] = {0};
            for(int j = 0; j < N; j++){
                int e = matrix[i][j];
                H_r[e] += 1;
                if( H_r[e] > 1 ){
                    R++;
                    break;
                }
            }
        }
        for(int i = 0; i < N; i++){
            int H_c[101] = {0};
            for(int j = 0; j < N; j++){
                int e = matrix[j][i];
                H_c[e] += 1;
                if( H_c[e] > 1 ){
                    C++;
                    break;
                }
            }
        }
        int trace = 0;
        for(int i = 0; i < N; i++){
            trace += matrix[i][i];
        }
        printf("Case #%d: %d %d %d\n", I, trace, R, C);
    }
    return 0;
}
