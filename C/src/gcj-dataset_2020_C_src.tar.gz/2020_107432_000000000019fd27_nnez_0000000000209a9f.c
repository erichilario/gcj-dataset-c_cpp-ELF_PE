#include <stdio.h>
#include <string.h>
int main(){
    int T;
    scanf("%d", &T);
    for(int I = 1; I <= T; I++){
        char s[121];
        scanf("%s", s);
        printf("Case #%d: ", I);
        int l = strlen(s);
        int sum_depth = 0;
        for(int i = 0; i < l; i++){
            int d = s[i] - '0';
            if( sum_depth < d ){
                for(int j = 0; j < d - sum_depth; j++){
                    printf("(");
                }
                sum_depth = d;
            }
            else if( sum_depth > d ){
                for(int j = 0; j < sum_depth - d; j++){
                    printf(")");
                }
                sum_depth = d;
            }
            printf("%d", d);
        }
        for(int i = 0; i < sum_depth; i++){
            printf(")");
        }
        printf("\n");
    }
    return 0;
}
