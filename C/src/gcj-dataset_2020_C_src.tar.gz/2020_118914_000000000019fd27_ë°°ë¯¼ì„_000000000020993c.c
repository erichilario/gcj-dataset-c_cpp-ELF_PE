#include<Stdio.h>

int main()
{
    int T,N,t,k,r,c;
    scanf("%d",&T);
    for(int cs=1 ; cs<=T ; cs++)
    {
        int table[110][110][2]={}; //[order][boolean][row/column]
        k = r = c = 0;
        scanf("%d",&N);
        for(int i=0 ; i<N ; i++)
            for(int j=0 ; j<N ; j++)
            {
                scanf("%d",&t);
                k += (i==j) ? t : 0;
                table[i][0][0] |= table[i][t][0]>0;
                table[j][0][1] |= table[j][t][1]>0;
                table[i][t][0] = 1;
                table[j][t][1] = 1;
            }
        for(int i=0 ; i<N ; i++)
        {
            r += table[i][0][0];
            c += table[i][0][1];
        }
        printf("case #%d: %d %d %d\n", cs, k, r, c);
    }
}

