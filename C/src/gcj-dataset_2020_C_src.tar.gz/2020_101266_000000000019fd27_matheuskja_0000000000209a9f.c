#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(){
    char s[100], c;
    int aux[10];
    int a,i,j=0,aux_int,m=0,k;
    for(i=0;i<10;i++){
        aux[i]=0;
    }
    scanf("%d",&a);
    for(i=0;i<a;i++){
        printf("Case #%d: ",i+1);
        scanf("%s",s);
        j=0;
        c = s[0];
        m=0;
        
        while(c!='\0'){
            c = s[j];
            if(c == '\0'){
                while(m>0){
                    printf(")");
                    m=m-1;
                }break;
            }
            aux_int = atoi(&c);
            if(m>aux_int){
                while(m>aux_int){
                    printf(")",c);
                    m=m-1;
                }printf("%c",c);
            }else if(m<aux_int){
                while(m<aux_int){
                    printf("(");
                    m = m+1;
                }printf("%c",c);
            }else{
                printf("%c",c);
            }
            
            j++;
        }printf("\n");
    }
}
