#include <bits/stdc++.h>
using namespace std;

void solve() {
    int n;
    cin >> n;
    using T = tuple<int, int, int>;
    priority_queue<T, vector<T>, greater<T>> que;
    for (int i = 0; i < n; i++) {
        int a, b;
        cin >> a >> b;
        que.emplace(a, 1, i);
        que.emplace(b, 0, i);
    }
    bool ok_c = true;
    int c_idx = -1;
    string ans(n, ' ');
    int cnt = 0;
    while (!que.empty()) {
        T top = que.top();
        que.pop();
        int time, type, idx;
        tie(time, type, idx) = top;
        if (type == 0) {
            cnt--;
            if (c_idx == idx) {
                ok_c = true;
            }
        } else {
            cnt++;
        }
        if (cnt > 2) {
            cout << "IMPOSSIBLE" << endl;
            return;
        }
        if (ok_c) {
            ans[idx] = 'C';
            ok_c = false;
            c_idx = idx;
        } else {
            ans[idx] = 'J';
        }
    }
    cout << ans << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cout << "Case #" << i << ": ";
        solve();
    }
}

