#include<stdio.h>
#include<string.h>
int main()
{
    int t,q,i,sl,x,j,a[100][2],op,cl;
    char s[101];
    scanf("%d",&t);
    for(q=1;q<=t;q++)
    {
        scanf("%s",s);
        //puts(s);
        sl=strlen(s);
        memset(a,0,sizeof(s));
        x='0';
        for(i=0;i<sl;)
        {
            if(x<=s[i])
            a[i][0]=s[i]-x;
            else
            a[i-1][1]=x-s[i];
            x=s[i];
            while(i<sl && s[i]==x)
            {
                i++;
            }
        }
        op=cl=0;
        printf("Case #%d: ",q);
        for(i=0;i<sl;i++)
        {
            for(j=0;j<a[i][0];j++){
            printf("(");op++;}
            printf("%c",s[i]);
            for(j=0;j<a[i][1];j++){
            printf(")");cl++;}
        }
        for(i=0;i<op-cl;i++)
        printf(")");
        printf("\n");
    }
    return 0;
}
