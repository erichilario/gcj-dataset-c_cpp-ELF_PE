#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

void flip(int A[100], int b)
{
	int i;

	for(i = 0; i < b; i++)
		A[i] = !A[i];
}

void reverse(int A[100], int b)
{
	int i, t;

	for(i = 0; i < b / 2; i++)
	{
		t = A[i];
		A[i] = A[b - i - 1];
		A[b - i - 1] = t;
	}
}

//returns 1 if correct, 0 if wrong
int process_test_case(int test_case_number)
{
	int b, i, x, A[100], covered, first_same = -1, first_diff = -1;
	int is_reversed = 0, is_flipped = 0, just_flipped, just_reversed, num_to_ask;
	int left, right;
	char s[100];

	scanf("%d", &b);
	if(b <= 10)
	{
		for(i = 0; i < b; i++)
		{
			printf("%d\n", i + 1);
			fflush(stdout);
			scanf("%d", &A[i]);
		}
		for(i = 0; i < b; i++)
			printf("%d", A[i]);
		printf("\n");
		return;
	}
	//b > 10
	for(i = 0; i < 5; i++)
	{
		printf("%d\n", i + 1);
		fflush(stdout);
		scanf("%d", &A[i]);
		printf("%d\n", b - i);
		fflush(stdout);
		scanf("%d", &A[b - i - 1]);
		if(first_same == -1 && A[i] == A[b - i - 1])
			first_same = i;
		if(first_diff == -1 && A[i] != A[b - i - 1])
			first_diff = i;
	}
	covered = 10;
	while(covered < b)
	{
		if(first_same != -1 && first_diff != -1)
		{
			printf("%d\n", first_same + 1);
			fflush(stdout);
			scanf("%d", &x);
			if(x != A[first_same])
			{
				is_flipped = !is_flipped;//just got flipped
				just_flipped = 1;
			}
			else just_flipped = 0;
			printf("%d\n", first_diff + 1);
			fflush(stdout);
			scanf("%d", &x);
			if((x != A[first_diff] && just_flipped == 0) || (x == A[first_diff] && just_flipped == 1))
			{
				is_reversed = !is_reversed;//just got reversed
				just_reversed = 1;
			}
			else just_reversed = 0;
			//intf("Just flipped %d just reversed %d\n", just_flipped, just_reversed);
			if(just_flipped) flip(A, b);
			if(just_reversed) reverse(A, b);
		}
		else if(first_same != -1 && first_diff == -1)
		{
			printf("%d\n", first_same + 1);
			fflush(stdout);
			scanf("%d", &x);
			if(x != A[first_same])
			{
				is_flipped = !is_flipped;//just got flipped
				just_flipped = 1;
			}
			else just_flipped = 0;
			if(just_flipped) flip(A, b);
			//ask again to make sure we always ask twice
			printf("%d\n", first_same + 1);
			fflush(stdout);
			scanf("%d", &x);
			//intf("Just flipped %d\n", just_flipped);
		}
		else if(first_same == -1 && first_diff != -1)
		{
			printf("%d\n", first_diff + 1);
			fflush(stdout);
			scanf("%d", &x);
			if(x != A[first_diff])
			{
				//can't tell what happened but just assume it just got flipped and not reversed
				is_flipped = !is_flipped;//just got flipped
				just_flipped = 1;
			}
			else just_flipped = 0;
			if(just_flipped) flip(A, b);
			//ask again to make sure we always ask twice
			printf("%d\n", first_diff + 1);
			fflush(stdout);
			scanf("%d", &x);
			//printf("Just flipped %d\n", just_flipped);
		}
		//now ask 8 more times
		num_to_ask = b - covered;
		if(num_to_ask > 8) num_to_ask = 8;
		for(i = 0; i < num_to_ask / 2; i++)
		{
			left = covered / 2 + i;
			printf("%d\n", left + 1);
			fflush(stdout);
			scanf("%d", &A[left]);
			right = b - left - 1;
			printf("%d\n", right + 1);
			fflush(stdout);
			scanf("%d", &A[right]);
			if(first_same == -1 && A[left] == A[right])
				first_same = left;
			if(first_diff == -1 && A[left] != A[right])
				first_diff = left;
		}
		covered += num_to_ask;
	}
	//answer
	for(i = 0; i < b; i++)
		printf("%d", A[i]);
	printf("\n");
	fflush(stdout);
	scanf(" %s", s);
	return s[0] == 'Y';
}

int main()
{
	int num_test_cases, test_case;

	scanf("%d", &num_test_cases);
	for(test_case = 0; test_case < num_test_cases; test_case++)
		if(process_test_case(test_case) == 0) break;

	return 0;
}

