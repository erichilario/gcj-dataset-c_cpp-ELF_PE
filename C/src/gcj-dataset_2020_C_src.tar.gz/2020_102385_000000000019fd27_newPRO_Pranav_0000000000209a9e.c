#include <stdio.h>

int main() {
    int T,B,i,s[100];
    char t,temp;
    
    scanf("%d %d",&T,&B);
    scanf("%c",&temp);
    
    if(B<=10) {
        while(T--) {
            for(i=1;i<=B;i++) {
                printf("%d\n",i);
                scanf("%c",&t);
                scanf("%c",&temp);
                if(t=='N') return 0;
                s[i-1]=((int)(t))-48;
            }
            for(i=0;i<B;i++) printf("%d",s[i]);
            printf("\n");
            scanf("%c",&t);
            scanf("%c",&temp);
            if(t=='N') return 0;
        }
    }
    return 0;
}
