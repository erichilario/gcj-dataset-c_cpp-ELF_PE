#include <stdio.h>
#include <string.h>

int main(){
	int t;
	scanf("%d",&t);
	for (int m = 1; m <= t; ++m)
	{
		char s[120];
		scanf("%s",s);
		int n = strlen(s);
		int arr[n+2];
		arr[0] = 0;
		arr[n+1] = 0;
		for (int i = 0; i < n; ++i)
		{
			arr[i+1] = (int)(s[i]) - 48;
		}
		printf("Case #%d: ",m );
		for (int i = 0; i < n; ++i)
		{
			int diff = arr[i+1] - arr[i];
			if(diff < 0){
				diff = -diff;
				for (int j = 0; j < diff; ++j)
				{
					printf(")");
				}
			}
			else{
				for (int j = 0; j < diff; ++j)
				{
					printf("(");
				}
			}
			printf("%d",arr[i+1]);
		}
		for (int i = 0; i < arr[n]-arr[n+1]; ++i)
		{
			printf(")");
		}
		printf("\n");
	}
}
