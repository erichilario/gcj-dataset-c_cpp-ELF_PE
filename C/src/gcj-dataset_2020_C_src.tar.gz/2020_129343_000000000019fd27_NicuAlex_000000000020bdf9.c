#include <iostream>
#include <algorithm>
using namespace std;
struct EL {
  int t;
  bool ok;
  int poz;
}f[2001];
bool cmp ( EL a, EL b ) {
  if ( a.t == b.t )
    return a.ok < b.ok;
  return a.t < b.t;
}
char ans[1001];
int main() {
  int n, t, i, j, open, impossible, t1, t2, pers;
  cin >> t;
  for ( i = 1; i <= t; i++ ) {
    cin >> n;
    for ( j = 0; j < n; j++ ) {
      cin >> t1 >> t2;
      f[j * 2].t = t1;
      f[j * 2].ok = 1;
      f[j * 2].poz = j;
      f[j * 2 + 1].t = t2;
      f[j * 2 + 1].ok = 0;
      f[j * 2 + 1].poz = j;
    }
    sort( f , f + 2 * n, cmp );
    j = 0;
    impossible = 0;
    pers = 0;
    open = 0;
    while ( j < 2 * n && impossible == 0 ) {
      while ( j < 2 * n && f[j].ok == 1 ) {
        if ( pers == 0 )
          ans[f[j].poz] = 'C';
        else
          ans[f[j].poz] = 'J';
        pers = 1 - pers;
        open++;
        j++;
      }
      if ( open > 2 )
        impossible = 1;
      while ( j < 2 * n && f[j].ok == 0 ) {
        open--;
        if ( ans[f[j].poz] == 'C' )
          pers = 0;
        else
          pers = 1;
        j++;
      }
    }
    cout << "Case #" << i << " ";
    if ( impossible == 0 ) {
      for ( j = 0; j < n; j++ )
        cout << ans[j];
    }
    else
      cout << "IMPOSSIBLE";
    cout << "\n";
  }
  return 0;
}

