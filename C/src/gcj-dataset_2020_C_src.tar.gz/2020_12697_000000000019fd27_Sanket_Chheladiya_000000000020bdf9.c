#include<stdio.h>
int main()
{
	long int k,w,i,j,a[1000][1000],n,max,min,r[1000];
	scanf("%ld",&k);
	for(w=0;w<k;w++)
	{
		scanf("%ld",&n);
		for(i=0;i<n;i++)
		{
			for(j=0;j<2;j++)
			{
				scanf("%ld",&a[i][j]);
			}
		}
		max=a[0][0];
		for(i=0;i<n;i++)
		{
			for(j=0;j<2;j++)
			{
				if(a[i][j]>max)
					max=a[i][j];
			}
		}
		min=a[0][0];
		for(i=0;i<n;i++)
		{
			for(j=0;j<2;j++)
			{
				if(a[i][j]<min)
					min=a[i][j];
			}
		}
		int t=1;
		int y=0;
		for(i=0;i<n;i++)
		{
			if(a[0][0]==min && a[0][1]==max)
			{
				printf("Case #%d: IMPOSSIBLE\n",w+1);
				goto end;
			}
			else if(a[i+1][0]<a[i][1])
			{
				t=t;
				r[y]=t;
				y++;
			}
			else if(a[i+1][0]>=a[i][1])
			{
				t=(-t);
				r[y]=t;
				y++;
			}
		}
		printf("Case #%ld: ",w+1);
		for(i=0;i<y;i++)
		{
			if(r[i]<0)
				printf("C");
			else
				printf("J");
		}
		printf("\n");
		end:
			printf("");
	}
}
