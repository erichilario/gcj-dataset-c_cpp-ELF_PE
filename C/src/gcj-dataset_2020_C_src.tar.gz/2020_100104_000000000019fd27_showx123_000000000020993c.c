#include <stdio.h>

int N;
int arr[105][105];

int check_row(int idx) {
	int map[105] = { 0, };
	for (int i = 1; i <= N; i++) {
		if (map[arr[idx][i]])
			return 0;

		map[arr[idx][i]]++;
	}

	return 1;
}

int check_col(int idx) {
	int map[105] = { 0, };
	for (int i = 1; i <= N; i++) {
		if (map[arr[i][idx]])
			return 0;

		map[arr[i][idx]]++;
	}

	return 1;
}

int main(void) {
	int t, T;
	int k;
	int r;
	int c;
	int i, j;

	scanf("%d", &T);

	for (t = 1; t <= T; t++) {
		scanf("%d", &N);
		k = r = c = 0;
		

		for (i = 1; i <= N; i++)
			for (j = 1; j <= N; j++)
				scanf("%d", &arr[i][j]);

		for (i = 1; i <= N; i++) {
			if (!check_row(i))
				r++;

			if (!check_col(i))
				c++;

			k += arr[i][i];
		}



		printf("Case #%d: %d %d %d\n", t,k,r,c);
	}
}
