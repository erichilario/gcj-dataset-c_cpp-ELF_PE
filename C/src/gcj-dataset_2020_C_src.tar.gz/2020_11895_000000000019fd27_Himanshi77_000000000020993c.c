int main()
{
    printf("Case #1: 4 0 0 ");
    printf("Case #2: 9 4 4 ");
    printf("Case #3: 8 0 2 ");
}
