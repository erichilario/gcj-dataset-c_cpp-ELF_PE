#include <stdio.h>
#include <stdlib.h>

int main(void) {
    setbuf(stdout, NULL);
    int ncases;
    int len;
    scanf("%d %d", &ncases, &len);
    for(int i=0; i<1; i++) {
        char solution[len+1];
        solution[len] = '\0';
        
        char c;
        for (int a=0; a<10; a++) {
            printf("%d", a+1);
            scanf("%c", &c);
            solution[a] = c;
            if (c == 'N') {
                return 0;
            }
        }
        
        
    }
    return 0;
}
