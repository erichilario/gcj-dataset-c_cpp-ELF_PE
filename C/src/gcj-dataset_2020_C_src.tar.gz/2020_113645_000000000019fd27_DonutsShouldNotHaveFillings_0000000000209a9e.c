#include <cstdio>
#include <cstdlib>

int main(void) {
    int ncases;
    int len;
    
    scanf("%d %d\n", &ncases, &len);
    printf("1"); fflush(stdout);
    char c;
    scanf("%c", &c);
    if(c == 'N') {
        exit(1);
    }
    printf("1010101010");
    fflush(stdout);
    scanf("%c", &c);
    if(c == 'N') {
        exit(1);
    }
    exit(1);
    
    
    
    return 0;
    for (int i=0; i<ncases; i++) {
        int queried[len];
        char answer[len+1];
        answer[len] = '\0';
        
	    char response;

        for (int a=0; a<len; a++) {
            queried[a] = 0;
            answer[a] = '0';
        }

	printf("%d", 1);
	fflush(stdout);
	scanf("%c", &response);
        if (response != 'Y') {
            return 0;
        }
        
        printf("%s", answer);
        fflush(stdout);
        
        scanf("%c", &response);
        if (response != 'Y') {
            return 0;
        }
        continue;


        // ask for first and last 5 digits
        for (int a=0; a<5; a++) {
            printf("%d\n", a+1);
            fflush(stdout);
            queried[a] = 1;
            scanf("%c\n", &answer[a]);
            if (answer[a] == 'N') {
                return 0;
            }
        }
        
        for (int a=0; a<5; a++) {
            printf("%d\n", len-a);
            fflush(stdout);
            queried[len-a-1] = 1;
            scanf("%c\n", &answer[len-a-1]);
            if (answer[len-a-1] == 'N') {
                return 0;
            }
        }
        printf("%s\n", answer);
        fflush(stdout);
        //char response;
        scanf("%c\n", &response);
        if (response != 'Y') {
            return 0;
        }
        
    }
    
    return 0;
}
