

#include <stdio.h>
int main()
{
    int cas;
    scanf("%d",&cas);
    for (int k = 1; k <=cas; k++){
        int n;
        scanf("%d", &n);
        int mat[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                scanf("%d", &mat[i][j]);
    
        int trace = 0;
        int r = 0;
        int c = 0;
        for (int i = 0; i < n; i++){
            trace += mat[i][i];
        }
        int HaveSeen[n];
        for (int k = 0; k<n; k++){
            for (int i = 0; i<n; i++) HaveSeen[i] = 0;
            for (int j = 0; j<n; j++){
                HaveSeen[mat[k][j]-1] += 1;
                if (HaveSeen[mat[k][j]-1] >= 2){
                    r += 1;
                    break;
                }
            }
            
        }
        for (int k = 0; k<n; k++){
            for (int i = 0; i<n; i++) HaveSeen[i] = 0;
            for (int j = 0; j<n; j++){
                HaveSeen[mat[j][k]-1] += 1;
                if (HaveSeen[mat[j][k]-1] >= 2){
                    c += 1;
                    break;
                }
            }
            
        }
    printf("Case #%d: %d %d %d\n", k, trace, r, c);
    
    }
    
    return 0;
}
