#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int compare(const void *pa, const void *pb){
	const int* a = pa;
	const int* b = pb;
	if(a[0] == b[0])
		return a[1] - b[1];
	else
		return a[0] - b[0];
}

int main(){
	int testCases;
	int n;
	int event[1500][5];
	int endC, endJ;
	char answer[1500];
	int j, flag;

	scanf("%d", &testCases);
	for(int t = 0; t < testCases; t++){
		scanf("%d", &n);
		for(int i = 0; i < n; i++)
			scanf("%d %d", &event[i][0], &event[i][1]);

		qsort(event, n, sizeof(event[0]), compare);

		flag = 0;
		j = 0;
		// C first
		answer[j++] = 'C';
		endC = event[0][1];
		// J
		answer[j++] = 'J';
		endJ = event[1][1];
		// Alternating jobs
		for(int i = 2; i < n; i++){
			if(event[i][0] < endC && event[i][0] < endJ){
				strcpy(answer, "IMPOSSIBLE");
				flag = 1;
				break;
			}
			if(endC < endJ){
				answer[j++] = 'C';
				endC = event[i][1];
			}
			else{
				answer[j++] = 'J';
				endJ = event[i][1];
			}
		}
		if(flag == 0)
			answer[j] = '\0';

		printf("Case #%d: %s\n", t+1, answer);
	}
	return 0;
}

