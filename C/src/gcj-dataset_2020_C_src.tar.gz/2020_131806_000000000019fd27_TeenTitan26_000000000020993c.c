#include<stdio.h>



void main()
{
    int i,j,k=0,q=0,r=0,c=0,sum=0,l=0,ki;
    int t,n;
    int a[100][100],row[100],col[100];
    static int chkr[101],chkc[100];
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(i=0;i<n;i++){
            for(j=0;j<n;j++){
                scanf("%d",&a[i][j]);
                if(i==j){
                    sum+=a[i][j];
                }
            }
        }
        for(i=0;i<n;i++){
            for(j=0;j<n;j++){
                row[j]=a[i][j];
                chkr[row[j]]+=1;
                col[j]=a[j][i];
                chkc[col[j]]+=1;
            
                
            }
            
            for(ki=1;ki<=n;ki++){
                if(chkr[ki]>1 && k==0){
                    r++;k=1;
                }
                if(chkc[ki]>1 && q==0){
                    c++;q=1;
                }
                
                chkr[ki]=0;
                chkc[ki]=0;
               
            }
             k=0;q=0;
            
        }
        l++;
        printf("Case #%d: %d %d %d\n",l,sum,r,c);
        sum=0;
        r=0;
        c=0;
        
        
    }
}
