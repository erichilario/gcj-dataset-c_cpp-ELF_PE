#include <stdio.h>

int main(void) {
    unsigned int ncases;
    scanf("%u\n", &ncases)
    
    for (unsigned int i=0; i<ncases; i++) {
        unsigned int dim;
        scanf("%u\n", &dim);
        
        unsigned int mat[dim][dim];
    }
    
    
    
    return 0;
}
