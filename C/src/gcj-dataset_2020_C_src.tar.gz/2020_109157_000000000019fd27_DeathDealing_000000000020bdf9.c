#include <stdio.h>

void swap(int* a, int* b){
	int temp = *a;
	*a = *b;
	*b = temp;
}

void sort(int n, int arr[n], int arr2[n], int arr3[n], int arr4[n]){
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n-i-1; ++j)
		{
			if(arr[j] > arr[j+1]){
				swap(arr+j,arr+j+1);
				swap(arr2+j,arr2+j+1);
				swap(arr3+j,arr3+j+1);
				swap(arr4+j,arr4+j+1);
			}
			else if(arr[j] == arr[j+1]){
				if(arr2[j] > arr2[j+1]){
					swap(arr+j,arr+j+1);
					swap(arr2+j,arr2+j+1);
					swap(arr3+j,arr3+j+1);
					swap(arr4+j,arr4+j+1);
				}
			}
		}
	}
}

int main(){
	int t;
	scanf("%d",&t);
	for (int m = 1; m <= t; ++m)
	{
		int n;
		scanf("%d",&n);
		int s[n], e[n], num[n], alloc[n];
		for (int i = 0; i < n; ++i)
		{
			alloc[i] = -1;
			num[i] = i;
			scanf("%d%d",&s[i],&e[i]);
		}
		sort(n,s,e,num,alloc);
		int flag = 1;
		int c_occ = 0;
		int j_occ = 0;
		for (int i = 0; (i < n) && flag; ++i)
		{
			if(s[i] >= c_occ){
				alloc[i] = 0;
				c_occ = e[i];
			}
			else if(s[i] >=j_occ){
				alloc[i] = 1;
				j_occ = e[i];
			}
			else{
				flag = 0;
			}
		}
		if(flag == 0){
			printf("Case #%d: IMPOSSIBLE\n",m);
		}
		else{
			sort(n,num,s,e,alloc);
			for (int i = 0; i < n; ++i)
			{
				if(alloc[i] == 0){
					printf("C");
				}
				else if(alloc[i] == 1){
					printf("J");
				}
			}
			printf("\n");
		}
	}
}
