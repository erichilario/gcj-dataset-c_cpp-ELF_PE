#include <stdio.h>
#define SIZE 100

int main ()
{
    int t, d, l = 0;
    char a [SIZE];
    scanf ("%d", &t);
    while (l != t)
    {
        scanf ("%s", a);
        d = 48;
        printf ("Case #%d: ", l + 1);
        
        for (int i = 0; a [i]; i ++)
        {
            int temp = (int) a [i];
            if (d < temp)
                for (int j = d; j < temp; j ++)
                    printf ("(");
            else if (d > temp)
                for (int j = temp; j < d; j ++)
                    printf (")");
            d = temp;
            printf ("%c", a [i]);
        }
        for (int i = 48; i < d; i ++)
            printf (")");
        printf ("\n");
        l ++;
    }
}
