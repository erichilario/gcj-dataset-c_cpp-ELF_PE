#include<stdio.h>
int TestCase(int t)
{
    int i, j, depth=0;
    char d[100];
    scanf("%s",d);
	
    printf("Case #%d: ",t);
	for(i=0;d[i]!=0;i++)
	{
		d[i]-='0';
		if(depth<d[i])
		{
			for(;d[i]>depth;depth++)printf("(");
		}
		else if(depth>d[i])
		{
			for(;depth>d[i];depth--)printf(")");
		}
		printf("%d",d[i]);
	}
	for(;depth>0;depth--)printf(")");
    printf("\n");
}
int main()
{
    int t,i;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        TestCase(i+1);
    }
}
