#include <stdio.h>

int main(void) {
    int ncases;
    scanf("%d\n", &ncases);
    
    for (int i=0; i<ncases; i++) {
        int nact;
        scanf("%d\n", &nact);
        int act[nact][3];
        for (int a=0; a<nact; a++) {
            scanf("%d %d\n", &act[a][0], &act[a][1]);
            act[a][2] = a;
        }
        
        // sort activities by startdate first
        for (int a=0; a<nact; a++) {
            for (int b=0; b<nact; b++) {
                if (act[a][0] > act[b][0]) {
                    int temp[3];
                    temp[0] = act[a][0];
                    temp[1] = act[a][1];
                    temp[2] = act[a][2];
                    act[a][0] = act[b][0];
                    act[a][1] = act[b][1];
                    act[a][2] = act[b][2];
                    act[b][0] = temp[0];
                    act[b][1] = temp[1];
                    act[b][2] = temp[2];
                }
            }
        }
        
        char assignment[nact+1];
        int tcam = 0;
        int tjam = 0;
        int imp = 0;
        for (int a=0; a<nact; a++) {
            // assign to cam if possible
            if (tcam <= act[a][0]) {
                assignment[act[a][2]] = 'C';
                tcam = act[a][1];
            } else if (tjam <= act[a][0]) {
                assignment[act[a][2]] = 'J';
                tjam = act[a][1];
            } else {
                imp = 1;
                break;
            }
            
        }
        assignment[nact] = '\0';
    
        if (imp == 1) {
            printf("Case #%d: IMPOSSIBLE\n", i+1);
        } else {
            printf("Case #%d: %s\n", i+1, assignment);
        }
        
    }
    
    return 0;
}
