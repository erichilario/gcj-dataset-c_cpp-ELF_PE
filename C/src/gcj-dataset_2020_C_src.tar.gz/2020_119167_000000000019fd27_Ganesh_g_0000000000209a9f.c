#include<stdio.h>
#include<string.h>
int main()
{
    int t,q,i,sl,x,j,a[1000][2],op,cl;
    char s[1001];
    scanf("%d",&t);
    for(q=1;q<=t;q++)
    {
        scanf("%s",s);
        //puts(s);
        sl=strlen(s);
        memset(a,0,sizeof(s));
        for(i=0;i<sl;i++)
        {
            x=s[i];
            a[i][0]=s[i]-'0';
            while(i<sl && s[i]==x)
            {
                i++;
            }
            a[i-1][1]=s[i-1]-'0';
            i--;
        }
        op=cl=0;
        printf("Case #%d: ",q);
        for(i=0;i<sl;i++)
        {
            for(j=0;j<a[i][0];j++){
            printf("(");op++;}
            printf("%c",s[i]);
            for(j=0;j<a[i][1];j++){
            printf(")");cl++;}
        }
        for(i=0;i<op-cl;i++)
        printf(")");
        printf("\n");
    }
    return 0;
}
