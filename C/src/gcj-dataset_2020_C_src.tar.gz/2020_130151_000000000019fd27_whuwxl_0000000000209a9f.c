#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    int t;
    scanf("%d", &t);
    for (int k = 1; k <= t; k++) {
        char a[128];
        char result[1024];
        scanf("%s", a);
        int len = strlen(a);
        memset(result, 0, sizeof(result));
        int j = 0;
        int in_one = 0;
        for (int i = 0; i < len; i++) {
            if (a[i] == '0') {
                if (in_one) {
                    result[j++] = ')';
                    in_one = 0;
                }
                result[j++] = '0';
            } else {
                if (!in_one) {
                    result[j++] = '(';
                    in_one = 1;
                }
                result[j++] = '1';
            }
        }
        if (in_one) {
            result[j++] = ')';
        }

        printf("Case #%d: %s\n", k, result);
    }
    return 0;
}

