#include<stdio.h>
void SORT(int arr[][3], int n)  
{  
    int i,j,t1,t2,t3;  
    for (i = 0; i < n-1; i++)      
    {
        for (j = 0; j < n-i-1; j++)  
        {   
                if (arr[j][0] > arr[j+1][0])  
                {
            	    t1=arr[j][0];
            	    t2=arr[j][1];
            	    t3=arr[j][2];
            	    arr[j][0]=arr[j+1][0];
            	    arr[j][1]=arr[j+1][1];
            	    arr[j][2]=arr[j+1][2];
            	    arr[j+1][0]=t1;
            	    arr[j+1][1]=t2;
            	    arr[j+1][2]=t3;
			    }
        }
    }
}  
int main()
{
	int n,k,a[1000][3],cam,jam,f,T;
	char final[1000];
	scanf("%d",&T);
	for(int i=0;i<T;i++)
	{
	    jam=0;
		cam=0;
		f=0;
		scanf("%d",&n);
		final[n]='\0';
		for(int j=0;j<n;j++)
		{
			scanf("%d%d",&a[j][0],&a[j][1]);
			a[j][2]=j;
		}
		
		SORT(a,n);
		
		for(int j=0;j<n;j++)
		{
			if(a[j][0]>=cam)
			{
				cam=a[j][1];
				final[a[j][2]]='C';
			}
			else if(a[j][0]>=jam)
			{
				jam=a[j][1];
				final[a[j][2]]='J';
			}
			else 
			{
				f=1;
				break;
			}
		}
		if(f==0)
			printf("Case #%d: %s\n",i+1,final);
		else
			printf("Case #%d: IMPOSSIBLE\n",i+1);
	}
}
