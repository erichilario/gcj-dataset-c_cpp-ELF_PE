#include <stdio.h>

int main() {
  int testCases;
  char strings[101][101];
  scanf("%d", &testCases);
  for (int x = 0; x < testCases; x++)
    scanf("%100s", strings[x]);

  for (int x = 0; x < testCases; x++) {
    int numPar = 0;
    printf("Case #%d: ", x);
    for (int y = 0; y < 101; y++) {
      if (strings[x][y] == '\0')
        break;
      while (numPar != strings[x][y] - '0') {
        if (numPar > strings[x][y] - '0') {
          numPar--;
          printf(")");
        }
        else {
          numPar++;
          printf("(");
        }
      }
      printf("%c", strings[x][y]);
    }
    while (numPar > 0) {
      numPar--;
      printf(")");
    }
    if(x == testCases - 1)
        break;
    printf("\n");
  }
}
