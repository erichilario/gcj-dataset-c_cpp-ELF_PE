#include<stdio.h>
#include<conio.h>
int main()
{
    int rows,cols,a[10],temp;
    scanf("%d %d",&rows,&cols);
    for(int i=0;i<rows;i++)
    {
        for (int j=0;j<cols;j++){
            scanf("%d",&a[i][j]);
        }
    }
    for(int i=0;i,rows;i++)
    {
        temp=temp+a[i][i];
    }
    printf("\n%d",temp);
    return 0;
}
