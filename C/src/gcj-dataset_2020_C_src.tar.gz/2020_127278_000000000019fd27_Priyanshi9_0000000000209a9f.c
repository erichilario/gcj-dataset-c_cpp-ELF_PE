#include<stdio.h>
int main(){
int t; 
scanf("%d", &t); 
getchar();

for(int x=1; x<=t; ++x)
{
printf("Case #%d: ", x);
int d = 0;
for(char c; c=getchar(), c>='0'; putchar(c))
{

if(d != c-'0'){
for(;d<c-'0';++d) putchar('(');
for(;d>c-'0';--d) putchar(')');
}
}
for(; d--;) putchar(')');
puts("");
}

return 0;
}
