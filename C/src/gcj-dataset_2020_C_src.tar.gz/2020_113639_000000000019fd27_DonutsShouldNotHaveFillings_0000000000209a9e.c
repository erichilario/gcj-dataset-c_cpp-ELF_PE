#include <stdio.h>
#include <stdlib.h>

int main(void) {
    setbuf(stdout, NULL);
    int ncases;
    int len;
    scanf("%d %d", &ncases, &len);
    for(int i=0; i<1; i++) {
        char c;
        printf("1");
        scanf("%c", &c);
    }
    return 0;
}
