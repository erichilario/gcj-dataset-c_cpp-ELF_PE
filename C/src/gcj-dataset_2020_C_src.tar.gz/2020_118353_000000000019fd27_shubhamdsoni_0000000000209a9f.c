#include<stdio.h>

int main()
{
	int T,_T;
	scanf("%d", &T);
	_T = T;
	while(T--)
	{
          char S[101];
	  char F[2000];
	  int start = 0;
	  scanf("%s",S);
          printf("Case #%d: ", _T-T);
	  int i=0,p=0,left=0,j,diff;
	  while(S[i]!='\0')
	  {
		  if(p==(S[i]-'0'))
		  {
			  F[start++]=S[i];
		  }
		  else
		  {
			  diff = p - (S[i] - '0');
			  if(diff>0)
			  {
				  for(j=0;j<diff;j++)
					  F[start++]=')';
				  left -= diff;
			  }
			  else
			  {
				  for(j=0;j<(0-diff);j++)
					  F[start++]='(';
				  left += (0-diff);
			  }
			  F[start++]=S[i];
		  }
		  p = S[i] - '0';
		  i++;
	  }
	  for(j=0;j<left;j++)
		  F[start++]=')';
	  F[start]='\0';
	  printf("%s\n",F);
	}
	return 0;
}

