include <stdio.h>

int main()
{
    int t,n,i,j,r,c,d,f,x,in,l,m,k,q=0;
    scanf("%d",&t);
    while(t--)
    {
        q++;
        d=0;
        scanf("%d",&n);
        int a[n][n];
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                scanf("%d",&a[i][j]);
                if(i==j)
                {
                    d=d+a[i][j];
                }
            }
        }
        r=0;
        c=0;
        for(i=0;i<n;i++)
        {
            int b[100]={0};
            in=0;
            f=0;
            for(j=0;j<n;j++)
            {
                b[in++]=a[i][j];
            }
            for (l=0;l<in;l++)
            {
 
            for (m=l+1;m<in;m++)
            {
 
                if (b[l]>b[m])
                {
 
                    x=b[l];
                    b[l]=b[m];
                    b[m]=x;
 
                }
 
            }
        }
        for(k=0;k<in;k++)
        {
            if(b[k]==b[k+1])
            {
                f=1;
                break;
            }
        }
        if(f==1)
        {
            r++;
        }
    }
    for(i=0;i<n;i++)
        {
            int b[100]={0};
            in=0;
            f=0;
            for(j=0;j<n;j++)
            {
                b[in++]=a[j][i];
            }
            for (l=0;l<in;l++)
            {
 
            for (m=l+1;m<in;m++)
            {
 
                if (b[l]>b[m])
                {
 
                    x=b[l];
                    b[l]=b[m];
                    b[m]=x;
 
                }
 
            }
        }
        for(k=0;k<in;k++)
        {
            if(b[k]==b[k+1])
            {
                f=1;
                break;
            }
        }
        if(f==1)
        {
            c++;
        }
    }
    printf("Case #%d: %d %d %d\n",q,d,r,c);
    }
    return 0;
}

