#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define size 1001

typedef struct {

    int start, end;
}Schedule;

 int compareStruct (const void * a, const void * b) { 
     Schedule * v1 = (Schedule *)a; 
     Schedule * v2 = (Schedule *)b; 
     return ( v1->start - v2->start ); 
    }



Schedule sch[size];
char out[size];


int main(){
    int i, N, test, t, tag;
    int c_start, c_end, j_start, j_end;
 
    scanf("%d",&test);
   

    for(t=1;t<=test;t++){
      scanf("%d",&N);

      for(i=0;i<N;i++)
       scanf("%d %d",&sch[i].start, &sch[i].end);

      qsort(&sch[0], N, sizeof(Schedule), compareStruct);

      c_start = c_end = j_start = j_end = -1;  
      tag = 0;
      for(i=0;i<N;i++){
          if(c_end <= sch[i].start){
            out[i] = 'C';
            c_end = sch[i].end;
          }
           else if(j_end <= sch[i].start){
            out[i] = 'J';
            j_end = sch[i].end;
           }
           else{
               tag = 1;
               break;
           }

      }
      
      out[N] = '\0';
      if(tag == 0){
          printf("Case #%d: %s\n",t,out);
      }
      else
      {
          printf("Case #%d: IMPOSSIBLE\n",t);
      }
      


     
        
        
    }


    return 0;
}
