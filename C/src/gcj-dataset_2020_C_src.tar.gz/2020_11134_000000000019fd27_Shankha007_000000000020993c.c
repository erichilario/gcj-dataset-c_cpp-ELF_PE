#include<stdio.h>
#include<stdlib.h>

int main(void) {
    int test,k=0;
    
    scanf("%d",&test);
    while(test--){
        int n;
        scanf("%d",&n);

        int a[n][n];

        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)
                scanf("%d",&a[i][j]);

        int trace_sum=0;

        for(int i=0;i<n;i++){
            trace_sum += a[i][i];
        }

        int r_count=0, c_count=0;

        for(int k=0;k<n;k++)
        {
            for(int i=0;i<n;i++)
            {
                for(int j=i+1;j<n;j++)
                {
                    if(a[k][i]==a[k][j]){
                        r_count++;
                        i=n;
                        j=n;
                    }
                }
            }
        }
        for(int k=0;k<n;k++)
        {
            for(int i=0;i<n;i++)
            {
                for(int j=i+1;j<n;j++)
                {
                    if(a[i][k]==a[j][k]){
                        c_count++;
                        i=n;
                        j=n;
                    }
                }
            }
        }
        printf("\nCase #%d: %d",++k,trace_sum);
        printf(" %d ",r_count);
        printf("%d",c_count);
    }
    return 0;
}
