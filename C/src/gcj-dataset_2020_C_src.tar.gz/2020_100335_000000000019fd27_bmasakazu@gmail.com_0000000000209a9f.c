#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define XSTR(x) #x
#define STR(x) XSTR(x)

FILE * input_source = NULL;
char* buffer = NULL;
char* cursor;
size_t read_size;

#ifdef INPUT_FILE
void open_input() {
  input_source = fopen(STR(INPUT_FILE), "r"); 
}

void close_input() {
  fclose(input_source);
}

#else
void open_input() {
  input_source = stdin;
}

void close_input() {

}
#endif

#define BUFFER_INITIAL_SIZE 100

char* output_buffer, output_cursor;
size_t output_buffer_size;
size_t output_buffer_index;

void new_output()
{
  output_buffer_index = 0;
}

void append_to_output(char c)
{
  if (output_buffer_index == output_buffer_size)
  {
    output_buffer_size *= 2;
    output_buffer = realloc(output_buffer, output_buffer_size*sizeof(char));
  }
  output_buffer[output_buffer_index] = c;
  output_buffer_index++;
}

char* get_output()
{
  return output_buffer;
}

int ctoi(char c)
{
  return c - '0';
}

void test_case(int t)
{
  getline(&buffer,&read_size,input_source);

  int cur_num = 0;
  int new_num;
  new_output();
  cursor = buffer;
  while (*cursor != '\n')
  {
      new_num = ctoi(*cursor); 

      while (new_num < cur_num)
      {
        /* close enough openings */
        append_to_output(')');
        cur_num--;
      }

      while (new_num > cur_num)
      {
        /* place enough openings */ 
        append_to_output('(');
        cur_num++;
      }

      /* add digit */
      append_to_output(*cursor);
      cursor++;
  }

  /* close all current unbalanced */
  while (cur_num > 0)
  {
        append_to_output(')');
        cur_num--;
  }

  /* null terminate */
  append_to_output('\0');

  fprintf(stdout, "Case #%d: %s\n", t, get_output());
}

int main()
{
    output_buffer = malloc(BUFFER_INITIAL_SIZE*sizeof(char));
    output_buffer_size = BUFFER_INITIAL_SIZE;

    open_input();

    getline(&buffer,&read_size,input_source);

    int num_tests = atoi(buffer);

    /* 1 index testcase number*/
    for (int t = 1; t <= num_tests; t++)
    {
       test_case(t);
    }

    free(buffer);
    free(output_buffer);
    close_input();
    return 0;
}

