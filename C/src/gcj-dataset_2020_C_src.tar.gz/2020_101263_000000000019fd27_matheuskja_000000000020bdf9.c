#include <stdlib.h>
#include <stdio.h>

void bubble(int* a,int* b,int n){
    int i,j,aux_a,aux_b;
    for(i=0;i<n;i++){
        for(j=n-1;j>i;j--){
            if(a[j]<a[j-1]){
                aux_a = a[j];
                aux_b = b[j];
                a[j] = a[j-1];
                b[j] = b[j-1];
                a[j-1] = aux_a;
                b[j-1] = aux_b;
            }
        }
    }
}

int main(){
    int i,j,k,a,b,in,en,end_max=0,imposs=0;
    scanf("%d",&a);
    int n = 100;
    int init[n], end[n],p[2];
    char act[n];
    p[0] = 0;
    p[1] = 0;
    for(i=0;i<a;i++){
        printf("Case #%d: ",i+1);
        p[0] = 0;
        p[1] = 0;
        scanf("%d",&b);
        //printf("B = %d\n",b);
        imposs = 0;
        for(j=0;j<b;j++){
            scanf("%d",&in);
            scanf("%d",&en);
            init[j] = in;
            end[j] = en;
        }
        bubble(init,end,b);
        for(j=0;j<b;j++){
            
            if(j==0){
                p[0] = end[j];
                act[j] = 'c';
            }else{
                if(p[0] <= init[j]){
                    act[j] = 'c';
                    p[0] = end[j];
                }else if(p[1] <= init[j]){
                    act[j] = 'j';
                    p[1] = end[j];
                }else{
                    imposs = 1;
                }
            }
        }
        if(imposs == 1){
            printf("IMPOSSIBLE");
        }else{
            for(j=0;j<b;j++){
                printf("%c",act[j]);
            }
        }printf("\n");
    }
}
