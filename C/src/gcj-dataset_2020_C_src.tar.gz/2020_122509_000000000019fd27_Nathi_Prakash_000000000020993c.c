#include<stdio.h>
#include<stdlib.h>

int main()
{
    int x,t=0;
    scanf("%d",&x);
    while(x--)
    {
        t++;
        int a[100][100],i,j,n,k,rr=0,cc=0,ss=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {scanf("%d",&a[i][j]);
            if(i==j)
            {
                ss+=a[i][j];
            }
            }
        }
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                for(k=j+1;k<n;k++)
                {
                    if(a[i][j]==a[i][k])
                        break;
                }
                if(k!=n)
                {
                    rr++;
                    break;
                }
            }
        }
        for(j=0;j<n;j++)
        {
            for(i=0;i<n;i++)
            {
                for(k=i+1;k<n;k++)
                {
                    if(a[i][j]==a[k][j])
                    break;
                }
                if(k!=n)
                {
                    cc++;
                    break;
                }
            }
        }
        printf("Case #%d: %d %d %d\n",t,ss,rr,cc);
    }
    return 0;
}
