#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<limits.h>
int main()
{
    int T,B;
    scanf("%d %d",&T,&B);
    while(T--)
    {
        char str[B+5];
        if(B!=10)
        {
            memset(str,'1',sizeof(str));
        }
        else
        {
            for(i=1;i<=B;i++)
            {
                printf("%d\n",i);
                scanf("%c",str[i-1]);
            }
            str[B]='\0';
        }
        printf("%s\n",str);
    }
}
