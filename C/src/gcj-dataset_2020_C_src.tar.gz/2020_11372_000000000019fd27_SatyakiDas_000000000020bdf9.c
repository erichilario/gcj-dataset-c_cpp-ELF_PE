#include<stdio.h>
void bubbleSort(int a[][3], int n)  
{  
    int i, j,temp1,temp2,temp3;  
    for (i = 0; i < n-1; i++)      
      
    // Last i elements are already in place  
    for (j = 0; j < n-i-1; j++)  
        if (a[j][0] > a[j+1][0])  
            {
            	temp1=a[j][0];
            	temp2=a[j][1];
            	temp3=a[j][2];
            	a[j][0]=a[j+1][0];
            	a[j][1]=a[j+1][1];
            	a[j][2]=a[j+1][2];
            	a[j+1][0]=temp1;
            	a[j+1][1]=temp2;
            	a[j+1][2]=temp3;
			}  
}  
int main()
{
	int test_case,i,n,j,k,a[1000][3],c,ja,flag=0;
	char b[1000];
	scanf("%d",&test_case);
	for(i=0;i<test_case;i++)
	{
		c=0;
		ja=0;
		flag=0;
		scanf("%d",&n);
		b[n]='\0';
		for(j=0;j<n;j++)
		{
			scanf("%d%d",&a[j][0],&a[j][1]);
			a[j][2]=j;
		}
		bubbleSort(a,n);
		for(j=0;j<n;j++)
		{
			if(a[j][0]>=c)
			{
				c=a[j][1];
				b[a[j][2]]='C';
			}
			else if(a[j][0]>=ja)
			{
				ja=a[j][1];
				b[a[j][2]]='J';
			}
			else 
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
			printf("Case #%d: %s\n",i+1,b);
		else
			printf("Case #%d: IMPOSSIBLE\n",i+1);
	}
}
