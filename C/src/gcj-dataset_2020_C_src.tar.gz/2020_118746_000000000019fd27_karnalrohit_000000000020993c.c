#include <stdio.h>
#include<stdlib.h>

int main() {
	int t,n,arr[200][200];
	scanf("%d",&t);
	int m=1;
	while(t--){
	    scanf("%d",&n);
	    int count1=0,count2=0,trace=0,flag;
	   for(int i=0;i<n;i++){
	       int *hash=(int *)malloc(sizeof(int)*(n+1));
	          flag=1;
	       for(int j=0;j<n;j++){
	      
	           scanf("%d",&arr[i][j]);
	           
	           hash[arr[i][j]]++;
	            if(i==j) trace=trace+arr[i][j];
	             if(hash[arr[i][j]]==2&&flag){ count1++;flag=0;}
	             
	             
	       }
	       
	   }
	   for(int i=0;i<n;i++){
	        int *hash=(int *)malloc(sizeof(int)*(n+1));
	       for(int j=0;j<n;j++){
	           hash[arr[j][i]]++;
	           if(hash[arr[j][i]]==2){
	               count2++;break;
	           }
	           
	       }
	   }
	   printf("Case #%d: %d %d %d\n",m,trace,count1,count2);
	   m++;

	}
	return 0;
}
