#include <stdio.h>

int main(void){
    int cases, casos, actividades, quedan, possible;
    int inf, next;
    int inic, inij, finc, finj;
    int i, j;
    int act[1000][2];
    char sol[1000];

    scanf("%d\n",&cases);
    for(casos=1;casos<=cases;casos++){

        scanf("%d\n",&actividades);
        for(i=0;i<actividades;i++){
            scanf("%d %d\n",&act[i][0],&act[i][1]);
        }
        inic = finc = inij = finj = 0;
        possible = 1;

        quedan = actividades;
        while(quedan && possible){
            inf = 1441;
            for(i=0;i<actividades;i++){
                if((act[i][0] >= 0)&&(act[i][0] < inf)){
                    inf=act[i][0];
                    next=i;
                }
            }
            if(finc<=act[next][0]){
                sol[next]='C';
                inic = act[next][0];
                finc = act[next][1];
            }else if(finj<=act[next][0]){
                sol[next]='J';
                inij = act[next][0];
                finj = act[next][1];
            }else{
                possible = 0;
            }
            act[next][0] = -1;
            quedan--;
        }

        if(possible){
            printf("Case #%d: ",casos);
            for(i=0;i<actividades;i++){
                putchar(sol[i]);
            }
            putchar('\n');
        }else{
            printf("Case #%d: IMPOSSIBLE\n",casos);
        }
    }

    return(0);
}

