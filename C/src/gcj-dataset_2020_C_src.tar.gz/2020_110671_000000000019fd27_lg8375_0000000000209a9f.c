#include<stdio.h>
//#pragma warning(disable:4996)

int ans[110];
char arr[110];
int idx;
int tc;
void input()
{
	arr[0] = 0;
	scanf("%s", &arr[1]);
	idx = 1;
	while (arr[idx] != '\0')idx++;
	arr[idx] = 0;

	for (int i = 1; i < idx; i++)arr[i] -= '0';

	tc++;
}
void solution()
{
	for (int i = 0; i < idx; i++) {
		ans[i] = arr[i + 1] - arr[i];
	}
	
	printf("Case #%d: ",tc);
	for (int i = 0; i < idx; i++) {
		if (ans[i] > 0) {
			for (int k = 0; k < ans[i]; k++) {
				printf("(");
			}
		}
		else {
			ans[i] *= -1;
			for (int k = 0; k < ans[i]; k++) {
				printf(")");
			}
		}

		if (i + 1 != idx) {
			printf("%d", arr[i + 1]);
		}
	}
	printf("\n");
}
int main()
{
	int T;
	scanf("%d", &T);
	while (T--) {
		input();
		solution();
	}
}
