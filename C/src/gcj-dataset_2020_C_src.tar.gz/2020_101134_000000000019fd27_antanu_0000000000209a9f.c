#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define size 102

char s[size];


int main(){
    int i,j, len, test, t;
    int num, p;
    scanf("%d",&test);
    fgets(s, sizeof(s), stdin);

    for(t=1;t<=test;t++){
      
        fgets(s, sizeof(s), stdin);
        len = strlen(s) - 1;
    
        printf("Case #%d: ",t);
        p = 0;    
        for(i=0;i<len;i++){
            num = s[i] - '0';

            if(num > 0){
                if(p>num){
                  for(j=1;j<=p-num;j++)
                    printf(")");
                    printf("%c",s[i]);
                  p -= p-num;  
                }
                else if(p==num){
                    printf("%c",s[i]);
                }
                else if(p<num){
                    for(j=1;j<=num-p;j++)
                        printf("(");
                  p += num-p;
                   printf("%c",s[i]);
                }
                 
            }
            else
            {
                for(j=1;j<=p;j++)
                printf(")");
                p=0;
                printf("0");
            }
            
        }
        for(j=1;j<=p;j++)
                printf(")");
        printf("\n");
        
    }


    return 0;
}
