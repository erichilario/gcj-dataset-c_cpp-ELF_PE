#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

int A[100][100];

void process_test_case(int test_case_number)
{
	int n, r, c, num_rows_with_dup = 0, num_cols_with_dup = 0, trace = 0;
	int freq[100];

	scanf(" %d", &n);
	for(r = 0; r < n; r++)
		for(c = 0; c < n; c++)
			scanf("%d", &A[r][c]);
	for(r = 0; r < n; r++)
		trace += A[r][r];
	
	for(r = 0; r < n; r++)
	{
		memset(freq, 0, sizeof(int) * n);
		for(c = 0; c < n; c++)
		{
			if(freq[A[r][c] - 1]) break;
			freq[A[r][c] - 1]++;
		}
		num_rows_with_dup += c < n;
	}
	for(c = 0; c < n; c++)
	{
		memset(freq, 0, sizeof(int) * n);
		for(r = 0; r < n; r++)
		{
			if(freq[A[r][c] - 1]) break;
			freq[A[r][c] - 1]++;
		}
		num_cols_with_dup += r < n;
	}

	printf("Case #%d: %d %d %d\n", test_case_number + 1, trace, num_rows_with_dup, num_cols_with_dup);
}

int main()
{
	int num_test_cases, test_case;

	scanf("%d", &num_test_cases);
	for(test_case = 0; test_case < num_test_cases; test_case++)
	{
		process_test_case(test_case);
	}

	return 0;
}

