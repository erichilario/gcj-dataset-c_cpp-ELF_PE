#include <stdio.h>
#include <stdlib.h>
#define N 1000

void quicksort(int left,int right);
int partition(int ,int );

int assignJob(int jobNo,int freec,int freej);

int tasks[N][2],job[N];
char str[N+1]={'\0'};
int n;
int main()
{
    int i,k=0,test_cases,flag;
    scanf("%d",&test_cases);
    while(k<test_cases)
    {
        k++;
        flag=0;
        scanf("%d",&n);
        scanf("%d %d",&tasks[0][0],&tasks[0][1]);
        job[0]=0;

        for(i=1;i<n;i++)
        {
            scanf("%d %d",&tasks[i][0],&tasks[i][1]);
            job[i]=i;
            if(tasks[i-1][0]>tasks[i][0])
                flag=1;
        }
        if(flag)
            quicksort(0,n-1);
        i=assignJob(0,0,0);
        if(!i)
        {
            str[n]='\0';
            printf("Case #%d: %s\n",k,str);
        }
        else
            printf("Case #%d: IMPOSSIBLE\n",k);
    }
    return 0;
}
int assignJob(int jobNo,int freec,int freej)
{
    int result=1;
    if(jobNo==n)
    {
        return 0;
    }
    else
    {
        if(freec<=tasks[job[jobNo]][0])
        {
            str[job[jobNo]]='C';
            result=assignJob(jobNo+1,tasks[job[jobNo]][1],freej);
        }
        else if(freej<=tasks[job[jobNo]][0] && result==1)
        {
            str[job[jobNo]]='J';
            result=assignJob(jobNo+1,freec,tasks[job[jobNo]][1]);
        }
        return result;
    }
}
void quicksort(int left,int right)
{
	int part;

	if(left<right)
	{
		part=partition(left,right);
        if(left<part)
            quicksort(left,part-1);
		if(part<right)
            quicksort(part+1,right);
	}
}
int partition(int left,int right)
{
	int pivot=tasks[job[right]][0],i=left-1,j,temp;

	for(j=left;j<right;j++)
	{
		if(tasks[job[j]][0]<=pivot)
		{
			i++;
            temp=job[i];
            job[i]=job[j];
            job[j]=temp;
		}
	}
	temp=job[i+1];
    job[i+1]=job[right];
    job[right]=temp;
	return(i+1);
}

