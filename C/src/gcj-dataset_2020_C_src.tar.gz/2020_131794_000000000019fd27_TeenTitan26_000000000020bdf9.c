#include<stdio.h>
void swap(int * x,int * y){
    int temp;
    temp=*x;
    *x=*y;
    *y=temp;
}

void main(){
    
    int t,n,st[1000],et[1000],p[1000];
    int i,j,k=0,q,l=0,c;
    char a[1000];
    scanf("%d",&t);
    while(t--){
        l++;
        scanf("%d",&n);
        for(i=0;i<n;i++){
            scanf("%d %d",&st[i],&et[i]);
            p[i]=i;
            a[i]='X';
        }
        for(i=0;i<n;i++){
            for(j=0;j<n;j++){
                if(st[i]<st[j]){
                    swap(&st[i],&st[j]);
                    swap(&et[i],&et[j]);
                    swap(&p[i],&p[j]);
                }   
            }
        }
        
        c=et[0];
        a[p[0]]='C';
        for(i=1;i<n && k!=1;i++){
             
            if(st[i]<c){
                for(j=i+1;st[j]<c && a[p[j]]=='X';j++){
                    if(st[j]<et[j-1] ){
                        printf("Case #%d: IMPOSSIBLE\n",l);
                        k=1;
                        break;
                    }
                }
                if(a[p[i]]=='X'){
                a[p[i]]='J';
                
                
                }
                
               
            }
            else{
                
                c=et[i];
               
                if(a[p[i]]=='X'){
                a[p[i]]='C';
                }
            }
            if(k==1){
                break;
            }
            
           
        }
        
        if(k!=1){
            printf("Case #%d: ",l);
            for(i=0;i<n;i++){
                printf("%c",a[i]);
            }
            printf("\n");
        }
        k=0;
        
        
    }
}
