#include <stdio.h>
#include <stdlib.h>

typedef struct activity {
	int start_h, end_h, order;
} activity;

int compar(const void *a, const void *b) {
	activity *a1, *b1;

	a1 = (activity *) a;
	b1 = (activity *) b;

	return a1->start_h - b1->start_h;
}

void read_data(activity *v, int *N) {
	int i = 0;

	scanf("%d", N);
	for(i = 0; i < *N; i++) {
		scanf("%d %d", &(v[i].start_h), &(v[i].end_h));
		v[i].order = i;
	}
}


void solve(activity *v, int N, int case_no) {
	int i;
	char s[1001];

	printf("Case #%d: ", case_no);

	qsort(v, N, sizeof(activity), compar);

	activity C, J, current;
	C.start_h = C.end_h = -1; J.start_h = J.end_h = -1;
	for(i = 0; i < N; i++) {
		if(v[i].start_h >= C.end_h) {
			C = v[i];
			s[v[i].order] = 'C';
		}
		else {
			if(v[i].start_h >= J.end_h) {
				J = v[i];
				s[v[i].order] = 'J';
			}
			else {
				printf("IMPOSSIBLE\n");
				return;
			}
		}
	}
	s[i] = '\0';
	printf("%s\n",s);
}


int main() {
	activity v[1001];
	int N, T, i;

	scanf("%d", &T);

	for(i = 1; i <= T; i++) {
		read_data(v, &N);
		solve(v, N, i);
	}

	return 0;
}
