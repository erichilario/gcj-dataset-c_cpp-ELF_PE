#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

int A[1000][4], B[1000];

int sf(const void *a, const void *b)
{
	int *A = (int *)a, *B = (int *)b;

	if(*A < *B) return -1;
	if(*A > *B) return 1;
	return 0;
}

int sf2(const void *a, const void *b)
{
	int *A = (int *)a, *B = (int *)b;

	if(A[2] < B[2]) return -1;
	if(A[2] > B[2]) return 1;
	return 0;
}

void process_test_case(int test_case_number)
{
	int n, i, av[2] = { 0, 0 };

	scanf("%d", &n);
	for(i = 0; i < n; i++)
	{
		scanf("%d%d", &A[i][0], &A[i][1]);
		A[i][2] = i;
	}
	qsort(A, n, sizeof(A[0]), sf);
	for(i = 0; i < n; i++)
	{
		if(av[0] <= A[i][0])
		{
			A[i][3] = 0;
			av[0] = A[i][1];
		}
		else
		{
			if(av[1] <= A[i][0])
			{
				A[i][3] = 1;
				av[1] = A[i][1];
			}
			else break;//impossible
		}
	}
	if(i < n)
	{
		printf("Case #%d: IMPOSSIBLE\n", test_case_number + 1);
		return;
	}
	qsort(A, n, sizeof(A[0]), sf2);
	printf("Case #%d: ", test_case_number + 1);
	for(i = 0; i < n; i++)
		printf("%c", A[i][3] ? 'J' : 'C');
	printf("\n");
}

int main()
{
	int num_test_cases, test_case;

	scanf("%d", &num_test_cases);
	for(test_case = 0; test_case < num_test_cases; test_case++)
		process_test_case(test_case);

	return 0;
}

