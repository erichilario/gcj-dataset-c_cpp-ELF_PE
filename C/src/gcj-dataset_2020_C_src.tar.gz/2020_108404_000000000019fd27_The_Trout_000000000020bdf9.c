#include <stdio.h>
#include <string.h>
#define MAX 1450

int count[MAX];
int start[MAX];
int end[MAX];
char s[MAX];

int main() {
  int T, N, S, E, imposible;
  scanf("%d", &T);
  for (int k = 1; k <= T; k++) {
    scanf("%d", &N);
    for (int i = 0; i < MAX; i++) {
      start[i] = 0;
      count[i] = 0;
      end[i] = 0;
    }
    for (int i = 0; i < N; i++) {
      scanf("%d %d", &S, &E);
      for (int j = S; j <= E; j++)
        count[j]++;
      start[S] = i + 1;
      end[i + 1] = E;
    }
    imposible = 0;
    for (int i = 0; i < MAX; i++)
      if (count[i] > 2 && count[i + 1] > 2) {
        imposible = 1;
        break;
      }
    if (imposible)
      printf("Case #%d: IMPOSSIBLE\n", k);
    else {
      for (int i = 0; i < MAX;) {
        if (start[i]) {
          s[start[i]] = 'C';
          int tmp = start[i];
          start[i] = 0;
          i = end[tmp];
        } else
          i++;
      }
      for (int i = 0; i < MAX; i++)
        if (start[i])
          s[start[i]] = 'J';
      s[N + 1] = '\0';
      printf("Case #%d: %s\n", k, s + 1);
    }
  }
  return 0;
}

