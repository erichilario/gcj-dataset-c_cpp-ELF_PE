#include<stdio.h>

int main()
{
    int t;
    scanf("%d",&t);
    for(int t=1 ; t<=t ; t++)
    {
        int n;
        scanf("%d",&n);
        int arr[n][n],sum=0;
        for(int i=0 ; i<n ; i++)
        {
            for(int j=0 ; j<n ; j++)
            {
                scanf("%d",&arr[i][j]);
                if(i==j)
                    sum+=arr[i][j];
            }
        }

        int row[n+1];
        int col[n+1];
        for(int z=0 ; z<=n ; z++)
        {
            row[z]=0;
            col[z]=0;
        }
        int r=0,c=0;
        for(int i=0 ; i<n ; i++)
        {
            for(int j=0 ; j<n ; j++)
            {
                row[ a[i][j] ]++;
                col[ a[j][i] ]++;
            }
            int flag1=1,flag2=1;
            for(int k=1 ;k<=n ; k++)
            {
                if(row[k]>1 && flag1)
                {
                    r++;
                    flag1=0;
                }

                if(col[k]>1 && flag2)
                {
                    c++;
                    flag2=0;
                }

                col[k]=0;
                row[k]=0;
            }
        }
        printf("Case #%d: %d %d %d\n",t,sum,r,c);
    }
    return 0;
}
