#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(){
    char s[100], c;
    int a,i,j=0,aux;
    scanf("%d",&a);
    for(i=0;i<a;i++){
        scanf("%s",s);
        c = s[0];
        aux = 0;
        if(c == '1'){
            printf("(1");
            aux = 1;
        }else{
            printf("0");
        }
        j=0;
        while(c!='\0'){
            c = s[j+1];
            if(c == '0'){
                if(aux == 1){
                    printf(")0");
                    aux = 0;
                }else{
                    printf("0");
                    
                }
            }else if(c == '1'){
                if(aux == 0){
                    printf("(1");
                    aux =1;
                }else{
                    printf("1");
                }
            }
            
            if(c == '\0'){
                if(aux == 1){
                    printf(")");
                }
            }
            
            j++;
        }printf("\n");
    }
}
