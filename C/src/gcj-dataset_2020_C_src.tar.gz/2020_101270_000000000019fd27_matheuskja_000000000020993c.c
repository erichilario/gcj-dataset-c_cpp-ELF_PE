#include <stdio.h>
#include <stdlib.h>

int main(){
    int a,i,j,k,linhas=0,colunas=0,trace = 0,n,element;
    scanf("%d",&a);
    
    for(i=0;i<a;i++){
        scanf("%d",&n);
        int matrix_linhas[100][100];
        int matrix_colunas[100][100];
        int lins[100],cols[100];
        for(j=0;j<n;j++){
            lins[j] = 0;
            cols[j] = 0;
            for(k=0;k<n;k++){
                matrix_linhas[j][k] = 0;
                matrix_colunas[j][k] = 0;
            }
        }
        colunas = 0;
        linhas = 0;
        trace = 0;
        for(j=0;j<n;j++){
            for(k=0;k<n;k++){
                scanf("%d",&element);
                matrix_linhas[j][element-1] = matrix_linhas[j][element-1]+1;
                matrix_colunas[k][element-1] = matrix_colunas[k][element-1]+1;
                if(matrix_colunas[k][element-1] > 1){
                    cols[k] = 1;
                    
                }
                if(matrix_linhas[j][element-1] > 1){
                    lins[j] = 1;
                }
                if(k==j){
                    trace = trace + element;
                }
            }
        }
        for(j=0;j<n;j++){
            if(lins[j] == 1){
                linhas = linhas+1;
                //printf("%d\n", linhas);
            }
            if(cols[j] == 1){
                colunas = colunas+1;
            }
        }
        printf("Case #%d: %d %d %d\n",i+1,trace,linhas,colunas);
        colunas = 0;
        linhas = 0;
    }
}
