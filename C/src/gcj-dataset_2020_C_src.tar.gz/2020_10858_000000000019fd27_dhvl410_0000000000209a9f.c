#include<stdio.h>
void main() {
    int t;
    scanf("%d",&t);
    while(t>0) {
        char[100] s;
        scanf("%d",s);
        int j=0;
        printf("(");
        for(int i=0;i!=null;i++) {
            if(s[i]=s[i+1]) {
                goto a; 
            }
            else {
                goto b;
            }
            a:;
                {
                    printf("%c"s[i]);
                    continue;
                }
            b:;
                {
                    printf(")(%c",s[i]);
                    continue;
                }
        }
        printf("\n");
        
        t--;
    }
}
