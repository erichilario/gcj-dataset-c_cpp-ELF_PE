#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    int x;
    for(x = 1;x <= t;x += 1)
    {
        int n;
        scanf("%d",&n);
        int a[n][n],i,j,k;
        for(i = 0;i < n;i += 1)
        {
            for(j = 0;j < n;j += 1)
            {
                scanf("%d",&a[i][j]);
            }
        }
        int trace = 0,rc = 0,cc = 0,flag1 = 0,flag2 = 0;
        for(i = 0;i < n;i += 1)
        {
            for(j = 0;j < n;j += 1)
            {
                if(i == j)
                {
                    trace += a[i][j];
                }
            }
        }
        for(i = 0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                for(k = j+1;k<n;k++)
                {
                    if(a[i][j] == a[i][k])
                    {
                        flag1 = 1;
                    }
                }
            }
            if(flag1 == 1)
            {
                rc++;
                flag1 = 0;
            }
        }
        for(i = 0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                for(k = j+1;k<n;k++)
                {
                    if(a[j][i] == a[k][i])
                    {
                        flag1 = 1;
                    }
                }
            }
            if(flag1 == 1)
            {
                cc++;
                flag1 = 0;
            }
        }
        printf("Case #%d: %d %d %d\n",x,trace,rc,cc);
    }
}
