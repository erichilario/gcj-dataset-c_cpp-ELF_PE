#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define MALLOC(X,Y)\
if(((X) = malloc((Y)))==NULL){\
fprintf(stderr, "heap memory allocation fails\n");\
exit(EXIT_FAILURE);\
}

#define COMPARE(X, Y) ((X) > (Y)) ? 1 : (((X) == (Y)) ? 0 : -1)

#define MAX_S 100
#define MAX_S_dash 1000

void solution(const char * s, char * s_dash);
int char_to_int(char a);
char int_to_char(int a);

int main(void){
    int i,t;
    char S[MAX_S], S_dash[MAX_S_dash];
    
    scanf("%d", &t);
    
    for(i=0;i<t;i++){
        
        scanf("%s", S);
        
        solution(S, S_dash);
        
        printf("Case #%d: %s\n", i+1, S_dash);
    }
}

void solution(const char * s, char * s_dash){
    int i, j, len_s = strlen(s), len_s_dash = 0;
    int prev = 0, match_parenth = 0;
    for(i=0;i<len_s;i++){
        match_parenth = char_to_int(s[i]);
        if(match_parenth == 0){
            for(j=0;j<prev;j++){
                s_dash[len_s_dash++] = ')';
            }
        } else switch(COMPARE(prev, match_parenth)){
            case 1:
                for(j=0;j<prev-match_parenth;j++){
                    s_dash[len_s_dash++] = ')';
                }
                break;
            case 0:
                break;
            case -1:
                for(j=0;j<match_parenth-prev;j++){
                    s_dash[len_s_dash++] = '(';
                }
                break;
        }
        s_dash[len_s_dash++] = int_to_char(match_parenth);
        prev = match_parenth;
    }
    
    if(prev != 0){
        for(i=0;i<prev;i++){
            s_dash[len_s_dash++] = ')';
        }
    }
    
    s_dash[len_s_dash] = '\0';
}

int char_to_int(char a){
    return a + 1 - '1';
}

char int_to_char(int a){
    return a + '1' - 1;
}
