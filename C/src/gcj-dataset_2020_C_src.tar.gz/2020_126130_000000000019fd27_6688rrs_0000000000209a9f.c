#include <stdio.h>
int main()
{
    int testnum;
    int p=1;
    scanf("%d\n",&testnum);
    while(testnum-p>=0)
    {
        int i,j;
        int length=0;
        char str[100];
        gets(str);
        for(i=0; i<100; i++)
        {
            if(str[i]!=NULL)
            {
                length++;
            }
            else
            {
                break;
            }
        }
        printf("Case #%d: ",p);
        int left=str[0]-48;
        for(i=0; i<left; i++)
        {
            printf("(");
        }
        printf("%d",left);

        for(i=1; i<length; i++)
        {
            if(str[i]-48-left<0)
            {
                for(j=0; j<(left-str[i]+48); j++)
                {
                    printf(")");
                }
                printf("%c",str[i]);
                left=left-(left-str[i]+48);
            }
            else if(str[i]-48-left==0)
            {
                printf("%c",str[i]);
            }
            if(str[i]-48-left>0)
            {
                for(j=0; j<(str[i]-48-left); j++)
                {
                    printf("(");
                }
                printf("%c",str[i]);
                left=left+(str[i]-48-left);
            }
        }
        for(j=0; j<left; j++)
        {
            printf(")");
        }
        printf("\n");
        p++;
    }
}

