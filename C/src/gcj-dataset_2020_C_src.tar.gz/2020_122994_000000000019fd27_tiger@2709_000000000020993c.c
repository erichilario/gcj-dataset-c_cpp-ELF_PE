#include<stdio.h>
int main()
{
    int test_cases,k=0,i,j,row,col,n,trace;
    scanf("%d",&test_cases);

    while(k<test_cases)
    {
        trace=0;
        row=0;
        col=0;
        scanf("%d",&n);
        int rownum[n],colnum[n];
        int matrix[n][n];
        
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                scanf("%d",&matrix[i][j]);
                if(i==j)
                    trace+=matrix[i][j];
            }
        }
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                rownum[j]=0;
                colnum[j]=0;
            }
            for(j=0;j<n;j++)
            {
                rownum[matrix[i][j]-1]++;
                colnum[matrix[j][i]-1]++;
            }
            for(j=0;j<n;j++)
            {
                if(rownum[j]>1)
                {
                    row++;
                    break;
                }
            }
            for(j=0;j<n;j++)
            {
                if(colnum[j]>1)
                {
                    col++;
                    break;
                }
            }
        }
        k++;
        printf("Case #%d: %d %d %d\n",k,trace,row,col);
    }
    return 0;
}

