#include <stdio.h>
#include <stdlib.h>

int main(){
    int t, n;
    scanf("%d", &t);
    for(int cnt=1; cnt<=t; cnt++){
        scanf("%d", &n);
        
        int arr[110][110] = {0};
        
        for(int i=0; i<n; i++){
        	for(int j=0; j<n; j++){
        		scanf("%d", &arr[i][j]);
        	}
        }
        
        int k=0, r=0, c=0;
        for(int i=0; i<n; i++){
        	k += arr[i][i];
        }
        
    	for(int i=0; i<n; i++){
    		int tmp_r[110] = {0};
    		for(int j=0; j<n; j++){
    			if(tmp_r[arr[i][j]]){
    				r++;
    				break;
    			}
    			tmp_r[arr[i][j]]++;
    		}
    	}
    	
    	for(int i=0; i<n; i++){
    		int tmp_c[110] = {0};
    		for(int j=0; j<n; j++){
    			if(tmp_c[arr[j][i]]){
    				c++;
    				break;
    			}
    			tmp_c[arr[j][i]]++;
    		}
    	}
    	
    	printf("Case #%d: %d %d %d\n", cnt, k, r, c);
    }
}
