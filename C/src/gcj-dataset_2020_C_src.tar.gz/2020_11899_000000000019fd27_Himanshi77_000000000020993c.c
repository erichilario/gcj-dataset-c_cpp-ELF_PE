#include"stdio.h"
int main()
{
 int T,N,i,j,k;
 scanf("%d",&T);
 for(i=0;i<T;i++)
 {
   int sum=0;
   int temp,p,c=0,r=0;
   scanf("%d",&N);
   int arr[N][N];
   for(j=0;j<N;j++)
   {
     for(k=0;k<N;k++)
     {
       scanf("%d",&arr[j][k]);
     }
   }
   for(j=0;j<N;j++)
   {
     for(k=0;k<N;k++)
     {
       if(j==k)
       {
        sum=sum+arr[j][k];
        }
    }
    }
    for(j=0;j<N;j++)
   {
     for(k=0;k<N;k++)
     {
          temp=arr[j][k];
          
              for(p=k+1;p<N;p++)
              {
                  if(temp==arr[j][p])
                  {
                      r=r+1;
                      break;
                  }
              }
              for(p=j+1;p<N;p++)
              {
                  if(temp==arr[p][k])
                  {
                      c=c+1;
                      break;
                  }
                  
              }
    }
    }
    
    printf("Case #%d: %d %d %d\n", T,sum,r,c);
 }
}
    
   
