#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	int testCases;
	char stringIn[150], stringOut[5000];
	int len, j;
	int paraCount;

	scanf("%d", &testCases);
	for(int t = 0; t < testCases; t++){
		scanf(" %s", stringIn);
		len = strlen(stringIn);

		paraCount = 0;
		j = 0;
		for(int i = 0; i < len; i++){
			if(paraCount < stringIn[i] - '0')
				while(paraCount < stringIn[i] - '0'){
					stringOut[j++] = '(';
					paraCount++;
				}
			else if(paraCount > stringIn[i] - '0')
				while(paraCount > stringIn[i] - '0'){
					stringOut[j++] = ')';
					paraCount--;
				}
			stringOut[j++] = stringIn[i];
		}
		while(paraCount > 0){
					stringOut[j++] = ')';
					paraCount--;
		}

		stringOut[j] = '\0';
		printf("Case #%d: %s\n", t+1, stringOut);
	}
	return 0;
}

