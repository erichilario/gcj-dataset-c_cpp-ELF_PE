#include<stdio.h>
int d[6][6];
int n,k,count;
bool checkAns;
void f(int x,int y)
{
	if(checkAns)return;
	int i,j;
	if(x>n)
	{
		int sum=0;
		for(i=1;i<=n;i++)
		{
			sum+=d[i][i];
		}
		if(sum==k)
		{
			printf("Case #%d: POSSIBLE\n",count);
			checkAns = true;
			for(i=1;i<=n;i++)
			{
				for(j=1;j<=n;j++)
				{
					printf("%d ",d[i][j]);
				}
				printf("\n");
			}
		}
	}
	int temp=0;
	for(int kk=1;kk<=n;kk++)
	{
		bool check=true;
		for(i=1;i<x;i++)
		{
			if(d[i][y]==kk)check=false;
		}
		for(i=1;i<y;i++)
		{
			if(d[x][i]==kk)check=false;
		}
		if(check)
		{
			d[x][y]=kk;
			f((y==n?x+1:x),(y==n?1:y+1));
		}
	}
}
int main()
{
	int t;
	scanf("%d",&t);
	for(count=1;count<=t;count++)
	{
		scanf("%d %d",&n,&k);
		checkAns=false;
		f(1,1);
		if(!checkAns)printf("Case #%d: IMPOSSIBLE\n",count);
	}
    return 0;
}
