#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
struct timeline{
    int start;
    int end;
    int cnt;
} node[1010];

int compare(const void *s1,const void* s2)
{
	struct timeline *e1 = (struct timeline *) s1;
	struct timeline *e2 = (struct timeline *) s2;
  return e1->start>e2->start;
}
int sort2(const void *s1,const void* s2)
{
	struct timeline *e1 = (struct timeline *) s1;
	struct timeline *e2 = (struct timeline *) s2;
  return e1->cnt>e2->cnt;
}
int main()
{
    int T;
    scanf("%d",&T);
    for(int i=1;i<=T;i++)
    {
        printf("Case #%d: ",i);
        int N;
        scanf("%d",&N);
        
        for(int j=0;j<N;j++)
        {
            scanf("%d %d",&node[j].start,&node[j].end);
            node[j].cnt=j;
        }
        qsort(node, N, sizeof(struct timeline), compare);
        bool imp=false;
        int on_act[1010]={0,};
        int off_act[1010]={0,};
        char who_is_working[1010];
        char rst[1010];
        int on_head=0,on_tail=0,off_head=0,off_tail=0,cnt=0;
        int work_head=0,work_tail=0;
        
        for(int j=0;j<N;j++)
        {
        	/*for(int a=on_head;a<on_tail;a++)
        	{
        		printf("%d ",on_act[a]);
        	}
        	printf("\n");
        	for(int a=off_head;a<off_tail;a++)
        	{
        		printf("%d ",off_act[a]);
        	}
        	printf("\n\n");
        	printf("%d %d is coming\n",node[j].start, node[j].end);*/
            while((node[j].start >= off_act[off_head])&&off_head!=off_tail)
            {
                off_head++;
                on_head++;
                work_head++;
            }
            if(on_head==on_tail){
                on_act[on_tail++]=node[j].start;
                off_act[off_tail++]=node[j].end;
                who_is_working[work_tail++]='C';
                rst[cnt++]='C';
            }
            else{
                if(node[j].start >= off_act[off_tail-1]){
                    on_tail--;
                    off_tail--;
                    work_tail--;
                }
                on_act[on_tail++]=node[j].start;
                off_act[off_tail++]=node[j].end;
                if((on_tail-on_head)>2){
                    printf("IMPOSSIBLE\n");
                    imp=true;
                    break;
                }
                else{
                    if(who_is_working[work_tail-1]=='C'){
                        who_is_working[work_tail++]='J';
                        rst[cnt++]='J';
                    }
                    else{
                        who_is_working[work_tail++]='C';
                        rst[cnt++]='C';
                    }
                }
            }
        }
        if(!imp){
            qsort(node, N, sizeof(struct timeline), compare);
            for(int a=0;a<N;a++)
            {
                printf("%c",rst[node[a].cnt]);
            }
            printf("\n");
        }
    }
}
