#include <stdio.h>
#include <stdlib.h>

int main(){
	int t;
	scanf("%d",&t);
	for (int m = 1; m <= t; ++m)
	{
		int n;
		scanf("%d",&n);
		int mat[n][n];
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
			{
				scanf("%d",&mat[i][j]);
			}
		}
		int n_row = 0;
		int n_col = 0;
		int trace = 0;
		int expect = (n*(n+1))/2;
		for (int i = 0; i < n; ++i)
		{
			trace += mat[i][i];
		}
		for (int i = 0; i < n; ++i)
		{
			int sum_row = 0;
			int sum_col = 0;
			for (int j = 0; j < n; ++j)
			{
				sum_row += mat[i][j];
				sum_col += mat[j][i];
			}
			if(sum_row != expect){
				n_row++;
			}
			if (sum_col != expect)
			{
				n_col++;
			}
		}
		printf("Case #%d: %d %d %d\n",m,trace,n_row,n_col);
	}
}
