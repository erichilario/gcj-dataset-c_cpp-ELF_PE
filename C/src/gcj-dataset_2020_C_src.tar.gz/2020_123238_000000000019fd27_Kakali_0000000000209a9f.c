#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#define rep(E, F) for (E = 0; E < (F); E++)
int get_int();
int min(int a, int b) { if (a > b) { return b; } return a; }
int max(int a, int b) { if (a < b) { return b; } return a; }

int main()
{
	int t = get_int(), cc = 1;
	while (t--)
	{
		printf("Case #%d: ", cc++);
		int n = 0;
		char c = getchar();
		while (c != 10)
		{
			c -= '0';
			while (n < c) putchar('('), n++;
			while (n > c) putchar(')'), n--;
			putchar(c + '0');
			c = getchar();
		}
		while (n > 0) putchar(')'), n--;
		putchar(10);
	}

	return 0;
}

int get_int()
{
	int ret = 0;
	char c = getchar();
	int sgn;

	while (1)
	{
		if (c == EOF) return EOF;
		if (c >= '0' && c <= '9') { sgn = 1; break; }
		if (c == '-')
		{
			c = getchar();
			if (c < '0' || c > '9') continue;
			sgn = -1;
			break;
		}
		c = getchar();
	}

	while (1)
	{
		ret = ret*10 + c - '0';
		c = getchar();
		if (c < '0' || c > '9') return sgn*ret;
	}
}

