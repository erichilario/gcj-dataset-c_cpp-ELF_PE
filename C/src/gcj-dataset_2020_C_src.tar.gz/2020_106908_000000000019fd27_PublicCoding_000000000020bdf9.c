#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define MALLOC(X,Y)\
if(((X) = malloc((Y)))==NULL){\
fprintf(stderr, "heap memory allocation fails\n");\
exit(EXIT_FAILURE);\
}

#define COMPARE(X, Y) ((X) > (Y)) ? 1 : (((X) == (Y)) ? 0 : -1)

#define MAX_N 1000

typedef struct __task{
    int start;
    int end;
    int task_no;
    int assignee;
}task;

int solution(task* tasks, size_t size);
int key_start(const void* ptr1, const void* ptr2);
int key_no(const void* ptr1, const void* ptr2);
void turn_change(int * turn);

int main(void){
    int i, j, t, n;
    task tasks[MAX_N];
    
    scanf("%d", &t);
    
    for(i=0;i<t;i++){
        
        scanf("%d", &n);
        
        for(j=0;j<n;j++){
            scanf("%d", &tasks[j].start);
            scanf("%d", &tasks[j].end);
            tasks[j].task_no = j;
        }
        
        if(solution(tasks, n) == 0){
            
            printf("Case #%d: IMPOSSIBLE\n", i+1);
            
        } else{
            
            printf("Case #%d: ", i+1);
            
            for(j=0;j<n;j++){
                printf("%C", tasks[j].assignee);
            }
            
            printf("\n");
        
            
        }
    }
}

int solution(task* tasks, size_t size){
    int i, last_overlap_start=0, last_overlap_end=0, turn='C';
    int start_now = 0, end_prev = 0, others=0;
    qsort(tasks, size, sizeof(task), key_start);
    
    for(i=0;i<size;i++){
        start_now = tasks[i].start;
        if(start_now > last_overlap_start && start_now < last_overlap_end){
            return 0;
        } else switch(COMPARE(start_now, end_prev)){
            case 1: case 0:
                tasks[i].assignee = turn;
                end_prev = tasks[i].end;
                last_overlap_start = 0;
                last_overlap_end = 0;
                break;
            case -1:
                turn_change(&turn);
                tasks[i].assignee = turn;
                if(end_prev < tasks[i].end){
                    last_overlap_end = end_prev;
                    end_prev = tasks[i].end; 
                } else{
                    last_overlap_end = tasks[i].end;
                    turn_change(&turn);
                }
                
                last_overlap_start = start_now;
                break;
        }
    }
    
    qsort(tasks, size, sizeof(task), key_no);
    
    return 1;
}

int key_start(const void* ptr1, const void* ptr2){
    int start1 = ((task*)ptr1)->start;
    int start2 = ((task*)ptr2)->start;
    
    return start1 - start2;
}

int key_no(const void* ptr1, const void* ptr2){
    int task_no1 = ((task*)ptr1)->task_no;
    int task_no2 = ((task*)ptr2)->task_no;
    
    return task_no1 - task_no2;
}

void turn_change(int * turn){
    if(*turn == 'J'){
        *turn = 'C';
    } else{
        *turn = 'J';
    }
}
