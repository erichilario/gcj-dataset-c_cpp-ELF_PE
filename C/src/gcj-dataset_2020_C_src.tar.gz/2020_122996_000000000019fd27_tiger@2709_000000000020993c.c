#include<stdio.h>
#define N 100
#define T 100

//int rownum[N],colnum[N];
//int matrix[N][N+2];
//int out[3][T];    
int main()
{
    int test_cases,k=0,i,j,row,col,n,trace,sum;
    scanf("%d",&test_cases);
    
    while(k<test_cases)
    {
        trace=0;
        row=0;
        col=0;
        scanf("%d",&n);
        sum=(int)(n*(n+1)/2);
        int matrix[n][n+2];
        for(i=0;i<n;i++)
        {
            matrix[i][n]=0;
            matrix[i][n+1]=0;
        }
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                scanf("%d",&matrix[i][j]);
                if(i==j)
                    trace+=matrix[i][j];
                matrix[i][n]+=matrix[i][j];
                matrix[j][n+1]+=matrix[i][j];
            }
        }
        for(i=0;i<n;i++)
        {
            if(matrix[i][n]!=sum)
                row++;
            if(matrix[i][n+1]!=sum)
                col++;
        }
        k++;
        printf("Case #%d: %d %d %d\n",k,trace,row,col);
    }
    return 0;
}
