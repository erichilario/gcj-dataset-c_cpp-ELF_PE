#include<stdio.h>
#include<stdbool.h>
void main()
{
	int t;
	scanf("%d",&t);
	for(int l=0;l<t;++l)
	{
		int n;
		scanf("%d",&n);
		int matrix[n][n];
		bool flag[n];
		int trace=0;
		int rows=0;
		for(int i=0;i<n;++i)
		{
			for(int k=0;k<n;k++)
			{
				flag[k]=false;
			}
			int f=0;
			for(int j=0;j<n;++j)
			{
				scanf("%d",&matrix[i][j]);
				if(flag[matrix[i][j]-1]==true && f==0)
				{
					rows++;
					f=1;
				}
				flag[matrix[i][j]-1]=true;
				if(i==j)
					trace=trace+matrix[i][j];
			}
		}
		int columns=0;
		for(int j=0;j<n;j++)
		{
			for(int k=0;k<n;k++)
			{
				flag[k]=false;
			}
			for(int i=0;i<n;++i)
			{
				if(flag[matrix[i][j]-1]==true)
				{
					columns++;
					break;
				}
				flag[matrix[i][j]-1]=true;
			}
		}
		printf("%d %d %d\n",trace,rows,columns);
	}
		
}
