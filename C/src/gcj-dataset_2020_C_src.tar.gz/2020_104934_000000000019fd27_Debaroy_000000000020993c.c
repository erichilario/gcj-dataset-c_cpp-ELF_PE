#include<stdio.h>
int main()
{
    int t=0,n=0,i,j,k;
    scanf("%d",&t);
    for(k=1;k<=t;k++)
    {
        scanf("%d",&n);
        int a[n][n],s=0,r[n],nrr=0,nrc=0;
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {scanf("%d",&a[i][j]);
             if(i==j) s+=a[i][j];}
        }
        for(i=0;i<n;i++)
        {r[i]=0; }
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                if(r[a[i][j]-1]==1) {nrr++; break;}
                else r[a[i][j]-1]=1;
            }
            for(j=0;j<n;j++) r[j]=0;
        }
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                if(r[a[j][i]-1]==1) {nrc++; break;}
                else r[a[j][i]-1]=1;
                
            }
            for(j=0;j<n;j++) r[j]=0;
        }
        printf("Case #%d: %d %d %d\n",k,s,nrr,nrc);
    }
    return 0;
}
