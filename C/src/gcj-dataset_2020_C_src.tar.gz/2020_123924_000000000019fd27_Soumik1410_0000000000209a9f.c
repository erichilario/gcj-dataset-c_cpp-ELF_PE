#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<limits.h>

int main()
{
    int T;
    scanf("%d",&T);
    int i;
    for(i=1;i<=T;i++)
    {
        char str[105];
        scanf("%s",str);
        int j;
        int count=0;
        int open=0;
        int len=strlen(str);
        char str2[100000];
        int k=0;
        for(j=0;j<len;j++)
        {
            int x=str[j]-48;
            if(x>=open)
            {
                //printf("case1\n");
                int d=x-open;
                while(d--)
                {
                    str2[k++]='(';   
                }
                str2[k++]=(char)(x+48);
                open+=x-open;
            }
            else
            {
                //printf("case 2\n");
                int d=open-x;
                while(d--)
                {
                    str2[k++]=')';
                }
                str2[k++]=(char)(x+48);
                open-=open-x;
            }
            if(j==len-1)
            {
                while(open--)
                {
                    str2[k++]=')';
                }
            }
        }
        str2[k]='\0';
        printf("Case #%d: %s\n",i,str2);
    }
    return 0;
}
