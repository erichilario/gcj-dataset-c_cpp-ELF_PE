#include <stdio.h>
#include <stdlib.h>

struct node 
{
	char c;
	struct node *next;	
};

struct node *head;

char pop(void)
{
	struct node *temp;
	temp=head;
	head=head->next;
	char c=temp->c;
	free(temp);
	return(c);
}

void push(char c)
{
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->c=c;
	temp->next=head;
	head=temp;
}

void reverse(void)
{
	if(head->next!=NULL)
	{
	char c=pop();
	reverse();
	printf("%c",c);
	}
}

int main()
{
	int i,t;
	scanf("%d",&t);
	
	char c;
	scanf("%c",&c);
	for(i=0;i<t;i++)
	{
		head=(struct node *)malloc(sizeof(struct node));
		head->c='\0';
		head->next=NULL;
		
		scanf("%c",&c);
		int x;
		int i1;
		while(c>=48&&c<=57)
		{
			int d=c-48;
			if(head->c=='\0')
			{
				for(i1=0;i1<d;i1++)
				push('(');
				
				push(c);
				x=d;
			}
			else
			{
				if(x==d)
				{
					push(c);
				}
				else
				if(x<d)
				{
					for(i1=0;i1<d-x;i1++)
					push('(');
					
					push(c);
					
					x=d;
				}
				else
				if(x>d)
				{
					for(i1=0;i1<x-d;i1++)
					push(')');
					
					push(c);
					
					x=d;
				}
			}
			scanf("%c",&c);
		}
		
		for(i1=0;i1<x;i1++)
		push(')');
		
		printf("Case #%d: ",i+1);
		reverse();
		printf("\n");
		free(head);
	}
	return(0);
}
