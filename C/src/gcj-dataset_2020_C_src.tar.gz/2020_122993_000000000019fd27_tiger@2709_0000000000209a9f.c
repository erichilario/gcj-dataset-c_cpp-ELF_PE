#include <stdio.h>

char s[102],so[2000]={'\0'};
int main()
{
    int test_cases,k=0,len,i,j,unmatched,curso,l;
    char prev;
    scanf("%d",&test_cases);
    while(k<test_cases)
    {   
        k++;
        scanf("%s",s);
        i=0;
        while(s[i++]!='\0');
        len=i-1;
        prev='0';
        curso=0;
        unmatched=0;
        for(i=0;i<len;i++)
        {
            if(prev<s[i])
            {
                l=0;
                for(j=0;j<(s[i]-prev);j++)
                {
                    l++;
                    so[curso++]='(';
                }
                unmatched+=l;
            }
            else
            {
                l=0;
                for(j=0;j<prev-s[i];j++)
                {
                    l++;
                    so[curso++]=')';
                }
                unmatched-=l;
            }
            so[curso++]=s[i];
            prev=s[i];
        }
        for(j=unmatched;j>0;j--)
        {
            so[curso++]=')';
        }
        so[curso++]='\0';
        printf("Case #%d: %s\n",k,so);
    }
    return 0;
}

