#include<stdio.h>
#include<stdlib.h>
int main()
{
    int t,ti=0;
    scanf("%d",&t);
    while(t--)
    {
        ti++;
        int a[100][100],i,j,n,k,r=0,c=0,s=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                scanf("%d",&a[i][j]);
                if(i==j)
                s+=a[i][j];
            }
        }
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                for(k=j+1;k<n;k++)
                {
                    if(a[i][j]==a[i][k])
                    break;
                }
                if(k!=n)
                {
                r++;
                break;
                }
            }
        }
        for(j=0;j<n;j++)
        {
            for(i=0;i<n;i++)
            {
                for(k=i+1;k<n;k++)
                {
                    if(a[i][j]==a[k][j])
                    break;
                }
                if(k!=n)
                {
                c++;
                break;
                }
            }
        }
        printf("Case #%d: %d %d %d\n",ti,s,r,c);
    }
    return 0;
}
