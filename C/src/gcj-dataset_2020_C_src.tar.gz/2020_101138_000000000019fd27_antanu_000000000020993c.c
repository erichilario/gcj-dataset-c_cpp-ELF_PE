#include <stdio.h>
#include <stdlib.h>
#define size 102

int mat[size][size];


int main(){
    int i,j,k,tag, test;
    int t,dim;
    int dsum;
    int row, col;

 
    scanf("%d",&test);
  
    for(t=1;t<=test;t++){
        scanf("%d",&dim);
       
        row = 0;
        col = 0;
        dsum = 0;        

        for(i=1;i<=dim;i++){
            for(j=1;j<=dim;j++){
                scanf("%d",&mat[i][j]);
                if(i == j)
                    dsum+=mat[i][j];
            }
        }

        
        for(i=1;i<=dim;i++){
            tag = 0;
            for(j=1;j<=dim;j++){
                for(k=j+1;k<=dim;k++){

                if(mat[j][i] == mat[k][i]){
                    col++;
                    tag = 1;
                    break;
                }
               
            }
             if(tag == 1)
                 break;
            }     
        }

        for(i=1;i<=dim;i++){
            tag = 0;
            for(j=1;j<=dim;j++){
                for(k=j+1;k<=dim;k++){

                if(mat[i][j] == mat[i][k]){
                    row++;
                    tag = 1;
                    break;
                }
               
            }
             if(tag == 1)
                 break;
            }     
        }
    

        printf("Case #%d: %d %d %d\n",t,dsum,row,col);
    }


    return 0;
}
