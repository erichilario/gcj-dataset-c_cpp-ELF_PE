//
 //  war.c
 //  CodeJam
 //
 //  Created by Huzefa on 4/12/14.
 //  Copyright (c) 2014 Huzefa. All rights reserved.
 //
 //
 //  main.c
 //  CodeJam
 //
 //  Created by Huzefa on 4/11/14.
 //  Copyright (c) 2014 Huzefa. All rights reserved.
 //
 
 #include <stdio.h>
 #include <stdlib.h>
 
 typedef struct weights{
     double w;
     int isUsed;
     int isWarUsed;
 } Weights;
 
 int
 compare_fn (const Weights *c1, const Weights *c2)
 {
     if(c1->w > c2->w){
         return 1;
     }else if( c1->w==c2->w){
         return 0;
     }
     return -1;
 }
 int main(int argc, const char * argv[])
 {
     int noOfTestcases=0;
     Weights *a,*b;
     FILE *fp;
     int lowerCounter=0;
     int higherCounter=0;
     FILE *out= fopen("/Users/admin/Desktop/output.txt","w");
     int counter=0;
     double noOfWeights=0;
     int warPoint=0;
     int deceitPoint=0;
     fp = fopen("/Users/admin/Desktop/input.txt","r");
     // insert code here...
     fscanf(fp,"%d\n",&noOfTestcases);
     while(counter<noOfTestcases){
         
         warPoint=0;
         deceitPoint=0;
         lowerCounter=0;
         fscanf(fp,"%lf\n",&noOfWeights);
         higherCounter=noOfWeights-1;
         a=malloc(sizeof(Weights) * noOfWeights);
         b=malloc(sizeof(Weights) * noOfWeights);
         for(int i=0;i<noOfWeights;i++){
             fscanf(fp,"%lf",&(a[i].w));
             a[i].isUsed=0;
             a[i].isWarUsed=0;
         }
         for(int i=0;i<noOfWeights;i++){
             fscanf(fp,"%lf",&(b[i].w));
             b[i].isUsed=0;
             b[i].isWarUsed=0;
         }
         qsort(a,noOfWeights,sizeof(Weights),compare_fn);
         qsort(b,noOfWeights,sizeof(Weights),compare_fn);
         
         for(int i=noOfWeights-1;i>=0;i--){
             b[i].isUsed=1;
             for(int j=noOfWeights-1;j>=0;j--){
                 if(b[i].w>a[j].w && a[j].isUsed!=1){
                     a[j].isUsed=1;
                     break;
                 }
             }
         }
         for(int i=0;i<noOfWeights;i++){
                if(a[i].isUsed==0)
                    warPoint++;
         }
         
         ///// a - Naomi
         ////  b - ken
         for(int i=noOfWeights-1;i>=0;i--){
             if(b[i].w>a[higherCounter].w){
                 a[lowerCounter++].isWarUsed=1;
             }else{
                 a[higherCounter--].isWarUsed=1;
                 deceitPoint++;
             }
             
         }
         
         fprintf(out,"Case #%d: %d %d\n",counter+1,deceitPoint,warPoint);
         free(a);
         free(b);
         counter++;
     }
     return 0;
 }
 

