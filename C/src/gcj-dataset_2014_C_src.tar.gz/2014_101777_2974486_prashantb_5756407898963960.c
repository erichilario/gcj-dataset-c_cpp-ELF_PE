#include<stdio.h>
 
 int main()
 {
   int test,n,t,a[4][4],b[4][4],c,d,count,i,j;
   scanf("%d",&t);	// No. of test cases
   test=t;
   while(t--)
   {
     // INPUT
     scanf("%d",&c);	// Row 1 -> c
     c--;
     for(i=0;i<4;i++)
       for(j=0;j<4;j++)
 	scanf("%d",&a[i][j]);
     scanf("%d",&d);	// Row 2 -> d
     d--;
     for(i=0;i<4;i++)
       for(j=0;j<4;j++)
 	scanf("%d",&b[i][j]);
       
     count=0;
     for(i=0;i<4;i++)
       for(j=0;j<4;j++)
       {
 	//printf("\n %d %d",a[c][i],b[d][j]);
 	if(a[c][i]==b[d][j])
 	{
 	  count++;
 	  //printf("\n%d",count);
 	  n=a[c][i];
 	}
 	
       }
     // OUTPUT  
     printf("Case #%d: ",test-t);
     if(count==1)
       printf("%d\n",n);
     else if(count==0)
       printf("Volunteer cheated!\n");
     else
       printf("Bad magician!\n");
   }
   return 0;
 }
