#include<stdio.h>
 int main()
 {
 int a[4],b[4],i,j,l,testcase,r1,r2,dummy,inc=0,val,p;
 FILE *fin, *fout;
 fin=fopen("A-small-attempt0.in","r");
 fout=fopen("A-small-attempt0.txt","w");
 
 
 fscanf(fin,"%d",&testcase);
 
 for(p=0;p<testcase;p++)
 {
 inc=0;
 fscanf(fin,"%d",&r1);
 for(i=0;i<16;i++){
 fscanf(fin,"%d",&dummy);
 if(i<r1*4 && i>=(r1-1)*4)
 a[inc++]=dummy; 
 }
 
 
 inc=0;
 fscanf(fin,"%d",&r2);
 for(i=0;i<16;i++){
 fscanf(fin,"%d",&dummy);
 if(i<r2*4 && i>=(r2-1)*4)
 b[inc++]=dummy;
 }
 
 
 
 
 l=0;
 for(i=0;i<4;i++)
 for(j=0;j<4;j++)
 if(a[i]==b[j]){
 l++;
 val=a[i];
 }
 
 if(l==1)
 fprintf(fout,"case #%d: %d\n",p+1,val);
 
 else if(l==0)
 fprintf(fout,"case #%d: Volunteer cheated!\n",p+1);
 
 else
 fprintf(fout,"case #%d: Bad magician!\n",p+1);
 
 
 }
 
 fclose(fin);
 fclose(fout);
 
 return 0;
 }
 

