#include <stdio.h>
 #include <string.h>
 #define MAX 25
 
 // global variables
 int R, C, M, tot;
 int top = -1, n, m, picked[MAX], success;
 char board[MAX][MAX];
 int revealed[MAX][MAX], cR, cC, numR;
 int cache[MAX][MAX];
 
 // function declarations
 void push(int n);
 int pop();
 void pick(int n, int* picked, int toPick);
 void makeBoard(char board[][10], int* picked);
 void makeRevealed();
 void check(int row, int col);
 
 int main()
 {
 	FILE* fp = fopen("C-small2.out", "w");
 	int T, t, i, j, row, col;
 
 	scanf("%d", &T);
 	for(t = 1; t <= T; t++) {
 		// input
 		scanf("%d %d %d", &R, &C, &M);
 
 		// initialize
 		top = -1;
 		success = 0;
 		tot = R * C - M;
 
 		// solve the problem recursively
 		pick(R * C, picked, M);
 
 		// output
 		fprintf(fp, "Case #%d:\n", t);
 		if(success == 0)
 			fprintf(fp, "Impossible\n");
 		else {
 			row = cR;
 			col = cC;
 			board[row][col] = 'c';
 			for(i = 0; i < R; i++) {
 				for(j = 0; j < C; j++) {
 					fprintf(fp, "%c", board[i][j]);
 				}
 				fprintf(fp, "\n");
 			}
 		}
 	}
 
 	return 0;
 }
 
 void push(int n) {
 	picked[++top] = n;
 }
 
 int pop() {
 	return picked[top--];
 }
 
 void pick(int n, int* picked, int toPick) {
 	int smallest, next, tmp, i, j;
 
 	// base case
 	if(toPick == 0) {
 		for(i = 0; i < R; i++)
 			for(j = 0; j < C; j++)
 				board[i][j] = '.';
 		makeBoard(board, picked);
 		makeRevealed();
 		// exception
 		if(M == R * C - 1) {
 			cR = R - 1;
 			cC = C - 1;
 			success = 1;
 			return;
 		}
 		for(cR = 0; cR < R; cR++) {
 			for(cC = 0; cC < C; cC++) {
 				if(revealed[cR][cC] == 0) {
 					memset(cache, -1, sizeof(cache));
 					numR = 1;
 					cache[cR][cC] = 1;
 					check(cR, cC);
 					if(numR == tot) {
 						success = 1;
 						return;
 					}
 				}
 			}
 		}
 		return;
 	}
 
 	smallest = (top == -1)? 0 : picked[top] + 1;
 	
 	for(next = smallest; next < n; next++) {
 		push(next);
 		pick(n, picked, toPick - 1);
 		if(success == 1)
 			return;
 		tmp = pop();
 	}
 }
 
 void makeBoard(char board[][25], int* picked) {
 	int row, col, i;
 
 	for(i = 0; i <= top; i++) {
 		row = picked[i] / C;
 		col = picked[i] % C;
 		board[row][col] = '*';
 	}
 }
 
 void makeRevealed() {
 	int rowPlus[8] = {-1, -1, -1, 0, 0, 1, 1, 1};
 	int colPlus[8] = {-1, 0, 1, -1, 1, -1, 0, 1};
 	int i, j, r, c, k, cnt;
 
 	for(i = 0; i < R; i++) {
 		for(j = 0; j < C; j++) {
 			if(board[i][j] == '*')
 				revealed[i][j] = -1;
 			else {
 				cnt = 0;
 				r = i;
 				c = j;
 				for(k = 0; k < 8; k++) {
 					r = i + rowPlus[k];
 					c = j + colPlus[k];
 					if(r >= 0 && r < R && c >= 0 && c < C) {
 						if(board[r][c] == '*')
 							cnt++;
 					}
 				}
 				revealed[i][j] = cnt;
 			}
 		}
 	}
 }
 void check(int row, int col) {
 	int rowPlus[8] = {-1, -1, -1, 0, 0, 1, 1, 1};
 	int colPlus[8] = {-1, 0, 1, -1, 1, -1, 0, 1};
 	int i, r, c;
 
 	for(i = 0; i < 8; i++) {
 		r = row + rowPlus[i];
 		c = col + colPlus[i];
 		if(r >= 0 && r < R && c >= 0 && c < C) {
 			if(revealed[r][c] != -1) {
 				if(cache[r][c] == -1) {
 					cache[r][c] = 1;
 					numR++;
 					if(revealed[r][c] == 0)
 						check(r, c);
 				}
 			}
 		}
 	}
 }
