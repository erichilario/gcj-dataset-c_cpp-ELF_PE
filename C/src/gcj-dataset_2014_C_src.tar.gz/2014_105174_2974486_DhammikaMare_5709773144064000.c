/*
  * Problem B. Cookie Clicker Alpha - Qualification Round 2014 - Google Code Jam
  *
  * Author : Marasinghe, M.M.D.B. | dhammikammdb123@gmail.com
  * Date : 2014/04/12 07:18:32
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 int main(){
 	int T = 1, cases;
 	double C, F, X, totalTime1, totalTime2, time1, time2, timetoX, productionRate;
 	
 	scanf("%d", &cases);
 	
 	while(T<=cases){
 		time1 = 0; time2 = 0; totalTime1 = 0; totalTime2 = 0; timetoX = 0; productionRate = 2;
 		
 		scanf("%lf", &C);
 		scanf("%lf", &F);
 		scanf("%lf", &X);
 
 		time1 = X/productionRate;
 		totalTime1 = time1;
 		time2 = C/productionRate;
 		productionRate+=F;
 		timetoX= X/productionRate;
 		totalTime2 = time2 + timetoX;
 		while(totalTime2 < totalTime1){
 			totalTime1 = totalTime2;
 			time2 = C/productionRate;
 			productionRate+=F;
 			totalTime2 = totalTime2 - timetoX + time2 + (X/productionRate);
 			timetoX= X/productionRate;
 		}
 		printf("Case #%d: %.7lf\n", T, totalTime1);
 	
 		T++;
 	}
 	
 	return EXIT_SUCCESS;
 }

