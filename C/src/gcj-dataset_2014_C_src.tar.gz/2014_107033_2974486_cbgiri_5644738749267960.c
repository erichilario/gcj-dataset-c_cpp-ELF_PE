
 #include<stdio.h>
 int mergesort(float a[],int low,int high);
 int merge2(float a[],int low,int mid,int high);
 float temp[1008];
 int main()
 {
 	int t,xxx=1;
 	scanf("%d",&t);
 	while(t--)
 	{
 		float a1[1008],a2[1008],b1[1008],b2[1008];
 		int i,n;
 		scanf("%d",&n);
 		for(i=1;i<=n;i++)
 		{
 			scanf("%f",&a1[i]);
 		}
 		for(i=1;i<=n;i++)
 		{
 			scanf("%f",&b1[i]);
 		}
 		mergesort(a1,1,n);
 		mergesort(b1,1,n);
 		for(i=1;i<=n;i++)
 		{
 			a2[i]=a1[i];
 			b2[i]=b1[i];
 		}
 /*		for(i=1;i<=n;i++)
 		printf("%.3f ",a1[i]);
 		printf("\n");
 		for(i=1;i<=n;i++)
 		printf("%.3f ",b1[i]);
 		printf("\n");
 */		printf("Case #%d: ",xxx);
 	//	j=1;
 		int x1=1,y1=1,j=1,flag=1,k11=1,x2=n,y2=n,s=0;
 		while(x1<=x2)
 		{
 			if(a2[x2]>b2[y2])
 			{
 				s++;
 				x2--;
 				y2--;
 			}
 			else
 			{
 				x1++;
 				y2--;
 			}
 if(x1>=1 && x1<=n && y1>=1 && y1<=n && x2>=1 && x2<=n && y2>=1 && y2<=n);
 else
 break;
    
 		}
 		printf("%d ",s);
 		x1=1,y1=1,j=1,flag=1,k11=1,x2=n,y2=n,s=0;
 		while(flag)
 		{
 			if(a1[x1]<=b1[y1])
 			{
 				a1[x1]=-1;
 				x1++;
 				y1++;
 				if(x1<=n &&  y1<=n)
 				flag=1;
 				else
 				flag=0;
 			}
 			else
 			{
 				y1++;
 				if(y1<=n)
 				flag=1;
 				else
 				flag=0;
 			}
 		}
 		for(i=1;i<=n;i++)
 		{
 			if(a1[i]!=-1)
 			s++;
 		}
 		printf("%d\n",s);
 		xxx++;
 	}
 	return 0;
 }
 
 
 int mergesort(float a[],int low,int high)
 {
 int mid;
 if(low<high)
 {
 mid=(low+high)/2;
 
 mergesort(a,low,mid);
 mergesort(a,mid+1,high);
 
 merge2(a,low,mid,high);
 }
 return 0;
 
 }
 
 int merge2(float a[],int low,int mid,int high)
 {
     int ac=low, bc=mid+1, cc=0,i;
     while(ac<=mid && bc<=high)
     {
           if(a[ac]<=a[bc])
             temp[cc++]=a[ac++];
           else
             temp[cc++]=a[bc++];
     }
 
     while(ac<=mid)
         temp[cc++]=a[ac++];
     while(bc<=high)
         temp[cc++]=a[bc++];
         cc--;
     while(cc>=0)
     {
         a[low+cc]=temp[cc];
         cc--;
     }
         return 0;
 
 }
 

