#include<stdio.h>
 
 double f,x,c,ans;
 
 double get(int t){
 	int i;
 	double time=0,e=2;
 	
 	for (i=0;i<t;i++){
 		time+=c/e;
 		e+=f;	
 	}
 	time+=x/e;
 	return time;
 }
 
 int main(){
 	int n;
 	int i;
 	FILE *in,*out;
 	in=fopen("cookie.in","r");
 	out=fopen("cookie.out","w");
 	
 	fscanf(in,"%d",&n);
 	for(i=0;i<n;i++){
 		int st,en,mi;
 		fscanf(in,"%lf%lf%lf",&c,&f,&x);
 		st=0;
 		en=x/c+1;
 		while (st<en){
 			int mi=(st+en)/2;
 			if (get(mi)>get(mi+1)){
 				st=mi+1;
 			}
 			else{
 				en=mi;
 			}
 		}
 		ans=get(st);
 		fprintf(out,"Case #%d: %.7f\n",i+1,ans);	
 	}
 	return 0;
 }
