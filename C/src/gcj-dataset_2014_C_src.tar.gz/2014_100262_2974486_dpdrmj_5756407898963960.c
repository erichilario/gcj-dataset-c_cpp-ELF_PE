#include<stdio.h>
 long long int a[20],b[20],c[20];
 int main()
 {
     long long int i,j,k,n,m,x,inx;
     long long int t;
     FILE* f1=fopen("abc.in","r");
     FILE* f2=fopen("ab.in","w");
     fscanf(f1,"%lld",&t);
     for(i=1;i<=t;i++)
     {
         fscanf(f1,"%lld",&n);
         x=0;inx=0;
         for(j=1;j<=16;j++)
             fscanf(f1,"%lld",&a[j]);
         fscanf(f1,"%lld",&m);
         for(j=1;j<=16;j++)
             fscanf(f1,"%lld",&b[j]);
         for(j=(n-1)*4+1;j<=(n)*4;j++)
         {
             for(k=(m-1)*4+1;k<=(m)*4;k++)
                 if(a[j]==b[k])
                     {x++;inx=j;}
 
         }
         if(x==1)
             fprintf(f2,"Case #%lld: %lld\n",i,a[inx]);
         else if(x>1)
             fprintf(f2,"Case #%lld: Bad magician!\n",i);
         else
             fprintf(f2,"Case #%lld: Volunteer cheated!\n",i);
 
     }
     return 0;
 }

