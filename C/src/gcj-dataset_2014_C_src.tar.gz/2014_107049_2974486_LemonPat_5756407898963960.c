#include <stdio.h>
 #include <stdlib.h>
 int m[5][5],e[5][5];
 int main()
 {
     freopen("magic.in","r",stdin);
     freopen("magic.out","w",stdout);
     int i,j,n,k,f,r,l,a,s,o;
     scanf("%d",&r);
     for(l=1;l<=r;l++)
     {
         if(l!=1)
         {
             printf("\n");
         }
         f=0;
         scanf("%d",&a);
         for(i=1;i<=4;i++)
         {
             for(j=1;j<=4;j++)
             {
                 scanf("%d",&m[i][j]);
             }
         }
         scanf("%d",&s);
         for(i=1;i<=4;i++)
         {
             for(j=1;j<=4;j++)
             {
                 scanf("%d",&e[i][j]);
             }
         }
         for(k=1;k<=4;k++)
             for(n=1;n<=4;n++)
             if(m[a][n]==e[s][k])
             {
                 o=m[a][n];
                 f++;
             }
         if(f==1)
         {
             printf("Case #%d: %d",l,o);
         }
         if(f>1)
         {
             printf("Case #%d: Bad Magician!",l);
         }
         if(f==0)
         {
             printf("Case #%d: Volunteer cheated!",l);
         }
     }
     return 0;
 }

