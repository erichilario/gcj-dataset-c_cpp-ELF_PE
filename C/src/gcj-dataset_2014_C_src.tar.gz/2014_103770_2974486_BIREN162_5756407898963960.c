#include<stdio.h>
 #include<conio.h>
 //using namespace std;
 int main()
 {
     int t,n,a[4][4],n2,a2[4][4],z[100],o[100],f=1,m=0,u;
    
     scanf("%d",&t);
      u=t;
      int i;
      for(i=0;i<100;i++)
         {z[i]=0;}
     while(t>0)
  {     int i,j,k,y;
         
     scanf("%d",&n);
     
     for( i=0;i<4;i++)
     {
         for( j=0;j<4;j++)
         {
             scanf("%d",&a[i][j]);
         }
     }
     scanf("%d",&n2);
     for(i=0;i<4;i++)
     {
         for(j=0;j<4;j++)
         {
             scanf("%d",&a2[i][j]);
         }
     }
      i=n-1,k=n2-1;
         for( j=0;j<4;j++)
         {
             for( y=0;y<4;y++)
        
             {
                 if(a[i][j]==a2[k][y])         
                   {z[m]++;
                   o[m]=a[i][j];
                  
                 }
              }
             
         }
        
         t--; m++;
         
   }
   int w;
 for(w=0;w<u;w++)
 {
     printf("\n");
  if(z[w]==1)
         printf("Case #%d: %d",f,o[w]);
          if(z[w]>1)
          printf("Case #%d: Bad magician!",f);
         //cout<<"Case #"<<f<<": "<<"Bad magician!"<< endl;
         if(z[w]==0)
          printf("Case #%d: Volunteer cheated!",f);
       //  cout<<"Case #"<<f<<": "<<"Volunteer cheated!"<< endl;
    f++;
 } getch();
   return 0;
 }

