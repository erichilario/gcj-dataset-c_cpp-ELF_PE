#include<stdio.h>
 
 int main()
 {
     double x,c,f,temp,actm1,actm2,rate,tm,ans;
     int tc=1,t;
     scanf("%d",&t);
     while(tc<=t)
     {
         scanf("%lf%lf%lf",&c,&f,&x);
 
         rate=2.0;tm=0;
         while(1)
         {
             actm1=tm+(x/rate);
 
             tm=tm+(c/rate);
 
             rate=rate+f;
 
             actm2=tm+(x/rate);
 
 
 
             if(actm1<actm2)
             {
                 ans=actm1;
                 break;
 
             }
 
 
 
         }
 
         printf("Case #%d: %.7lf\n",tc,ans);
 
         tc++;
     }
 
 	return 0;
 
 }

