#include <stdio.h>
 
 int main()
 {
 	int t,i;
 	scanf("%d", &t);
 	double c[t], f[t], x[t], nofarms[t],cookierate[t],answer1[t],answer2[t];
 	for(i=0;i<t;i++)
 	{
 		scanf("%lf %lf %lf", &c[i], &f[i], &x[i]);
 		nofarms[i]=0;
 		cookierate[i]=2.0;
 		answer1[i] = 0.0;
 		answer2[i] = 0.0;
 	}	nofarms[i] = 0.0;
 	// Time at which you can first buy cookie farm is c/2
 	for(i=0;i<t;i++)
 	{
 	while(1)
 	{
 		answer1[i] = answer1[i] + x[i]/cookierate[i];
 		answer2[i] = answer2[i] + c[i]/cookierate[i] + x[i]/(cookierate[i]+f[i]);
 		if (answer1[i] > answer2[i])
 		{
 			answer1[i] = answer1[i] - x[i]/cookierate[i];
 			answer1[i] = answer1[i] + c[i]/cookierate[i];
 			answer2[i] = answer2[i] - (c[i]/cookierate[i] + x[i]/(cookierate[i]+f[i]));
 			answer2[i] = answer2[i] + c[i]/cookierate[i];
 			cookierate[i]=cookierate[i]+f[i];
 		}
 		else
 		{
 			printf("Case #%d: %lf\n",i+1,answer1[i]);
 			break;
 		}
 	}
 	}
 	return 0;
 }
