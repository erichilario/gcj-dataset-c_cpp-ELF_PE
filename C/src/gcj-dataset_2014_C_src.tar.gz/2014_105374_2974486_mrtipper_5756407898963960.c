#include <stdio.h>
 #include <stdlib.h>
 
 int
 readWord( FILE* fi, char* const buf, int const bufSize ) {
   int c;
   int len = 0;
   while( 1 ) {
     c = fgetc( fi );
     if( c == EOF || c == '\n' || c == ' ' ) {
       *( buf + len ) = '\0';
       break;
     } else {
       *( buf + len ) = c;
       ++len;
     }
   }
   return len;
 }
 
 int
 readNum( FILE* fi ) {
   char buf[ 100 ];
   readWord( fi, buf, sizeof( buf ) );
   return atoi( buf );
 }
 
 void
 testCase( FILE* fi, FILE* fo, int n ) {
   int line;
   int i;
   int card;
   int cards[ 17 ] = {};
   int found = -1;
 
   printf( "testCase: %d\n", n );
 
   line = readNum( fi );
   printf( "line: %d\n", line );
   for( i = 0; i < 16; ++i ) {
     if( i >= 4 * ( line - 1 ) && i < ( 4 * line ) ) { 
       card = readNum( fi );
       cards[ card ] = 1;
       printf( "card %d\n", card );
     } else {
       card = readNum( fi );
       cards[ card ] = 0;
     }
   }
 
   line = readNum( fi );
   printf( "line: %d\n", line );
   for( i = 0; i < 16; ++i ) {
     if( i >= 4 * ( line - 1 ) && i < ( 4 * line ) ) { 
       card = readNum( fi );
       cards[ card ] += 1;
       printf( "card %d\n", card );
     } else {
       card = readNum( fi );
     }
   }
 
   for( i = 1; i < 17; ++i ) {
     printf( "%d ", cards[ i ] );
   }
   printf( "\n" );
 
   for( i = 1; i < 17; ++i ) {
     if( cards[ i ] == 2 ) {
       if( found > 0 ) {
 	found = 0;
 	break;
       } else {
 	found = i;
       }
     }
   }
 
   switch( found ) {
   case -1:
     fprintf( fo, "Case #%d: Volunteer cheated!\n", n );
     break;
   case 0:
     fprintf( fo, "Case #%d: Bad magician!\n", n );
     break;
   default:
     fprintf( fo, "Case #%d: %d\n", n, found );
     break;
   }
 }
 
 int
 main( int argc, char** argv ) {
   int numCases ;
   int i;
   FILE* fo = fopen( "output.txt", "w");
   FILE* fi = stdin;
   char buf[100];
 
   numCases = readNum( fi );
   printf( "numCases: %d\n", numCases );
   for( i = 0; i < numCases; ++i ) {
     testCase( fi, fo, i + 1 );
   }
   return 0;
 }

