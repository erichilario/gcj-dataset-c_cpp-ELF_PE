#include <stdio.h>
 
 int main()
 {
 	int t,k=0,i,j;
 	double c,f,x,time_cps,time_buy,time,cps;
 	scanf("%d",&t);
 	while(t--)
 	{
 		k+=1;
 		cps=2;
 		time=0;
 		scanf("%lf%lf%lf",&c,&f,&x);
 		while(1)
 		{
 			time_cps = x/cps;
 			time_buy = c/cps + x/(cps+f);
 			if(time_cps>time_buy)
 			{
 				time+=c/cps;
 				cps+=f;
 			}
 			else
 			{
 				time+=time_cps;
 				break;
 			}
 		}
 		printf("Case #%d: %.7lf\n",k,time);
 	}
 }

