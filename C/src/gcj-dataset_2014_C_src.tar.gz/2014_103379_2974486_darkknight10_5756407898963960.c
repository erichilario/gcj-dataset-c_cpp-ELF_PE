#include<stdio.h>
 int main()
 {
 int T,r1,r2,a[4][4],j,k,b[4][4],count=0,i,temp;
 scanf("%d",&T);
 for(i=0;i<T;i++)
 {
     count=0;
 scanf("%d",&r1);
 for(j=0;j<4;j++)
 {
 for(k=0;k<4;k++)
 {
 scanf("%d",&a[j][k]);
 }
 }
 scanf("%d",&r2);
 for(j=0;j<4;j++)
 {
 for(k=0;k<4;k++)
 {
 scanf("%d",&b[j][k]);
 }
 }
 for(j=0;j<4;j++)
 {
 for(k=0;k<4;k++)
 {
 if(a[r1-1][j]==b[r2-1][k])
 {
 count++;
 if(count>1)
     break;
 temp=a[r1-1][j];
 }
 }
 }
 if(count==1)
 printf("Case #%d: %d\n",i+1,temp);
 else if(count==0)
 printf("Case #%d: Volunteer cheated!\n",i+1);
 else
 printf("Case #%d: Bad magician!\n",i+1);
 }
 return 0;
 }

