#include <stdlib.h>
 #include <stdio.h>
 
 char* solve(int p1, int p2, int* grid1, int* grid2) {
 	int answer;
 	int answered = 0;
 	for (int i=0; i<4; i++) {
 		for (int j=0; j<4; j++) {
 			if (grid1[4*p1+i] == grid2[4*p2+j]) {
 				if (answered) return "Bad Magician!";
 				answered = !answered;
 				answer = grid1[4*p1+i];
 			}
 		}
 	}
 	if (!answered) return "Volunteer cheated!";
 	char* sanswer = (char*) malloc (2*sizeof(char));
 	sprintf(sanswer, "%d", answer);
 	return sanswer;
 }
 
 int main(int argc, char** argv) {
 	int T;
 	scanf("%d", &T);
 	for (int t=0; t<T; t++) {
 		int p1, p2;
 		int grid1 [16], grid2 [16];
 		scanf("%d", &p1);
 		for (int i=0; i<16; i++) {
 			scanf("%d", &grid1[i]);
 		}
 		scanf("%d", &p2);
 		for (int i=0; i<16; i++) {
 			scanf("%d", &grid2[i]);
 		}
 		printf("Case #%d: %s\n", t+1, solve(p1-1, p2-1, grid1, grid2));
 	}
 }
