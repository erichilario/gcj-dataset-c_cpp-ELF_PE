#include <stdio.h>
 
 int main()
 {
     int T;
     int i,j,k;
     int arrangement1[4][4],arrangement2[4][4];
     int ans1,ans2;
     int number;
     freopen("inp.txt", "r", stdin);
     freopen("out.txt", "w+", stdout);
     scanf("%d",&T);
     int countt;
     for(i=0;i<T;i++){
         countt = 0;
         number = 0;
         scanf("%d",&ans1);
         for(j=0;j<4;j++){
             for(k=0;k<4;k++){
                 scanf("%d",&arrangement1[j][k]);
             }
         }
 
         scanf("%d",&ans2);
         for(j=0;j<4;j++){
             for(k=0;k<4;k++){
                 scanf("%d",&arrangement2[j][k]);
             }
         }
 
 
         for(j=0;j<4;j++){
             for(k=0;k<4;k++){
                 if(arrangement1[ans1-1][j]==arrangement2[ans2-1][k]){
                     number = arrangement1[ans1-1][j];
                     countt++;
                 }
             }
         }
 
 
         if(countt == 1) printf("Case #%d: %d\n",i+1,number);
         else if(countt == 0) printf("Case #%d: Volunteer cheated!\n",i+1);
         else if(countt > 1) printf("Case #%d: Bad magician!\n",i+1);
 
     }
     return 0;
 }

