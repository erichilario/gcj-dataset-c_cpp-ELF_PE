#include<stdio.h>
 
 double tentativemin, c, f, x;
 
 double leastime(double, double);
 
 int main()
 {
 	int t, j;
 	double rate, time;
 	
 	j = 1;
 	rate = 2;
 	scanf("%d", &t);
 	while(t--) {
 		scanf("%lf%lf%lf", &c, &f, &x);
 		tentativemin = x / 2;
 		if(x <= c)
 			time = x / rate;
 		else
 			time = leastime(0.0, rate);
 		printf("Case #%d: %.7lf\n", j++, time);
 	}
 	return 0;
 }
 
 double leastime(double t, double rate)
 {
 	double k1, k2;
 	k2 = t + x / rate;
 	if(k2 < tentativemin)
 		tentativemin = k2;
 	if(t + c / rate < tentativemin)	// recursion breaking condition
 		if((k1 = leastime(t + c / rate, rate + f)) < k2)	//either buy farmhouse or don't
 			return k1;
 		else
 			return k2;
 	else
 		return k2;
 }

