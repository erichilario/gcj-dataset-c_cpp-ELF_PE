#include <stdio.h>
 void mergeSort(float arr[],int low,int mid,int high);
 void partition(float arr[],int low,int high);
 void partition(float arr[],int low,int high){
     int mid;
     if(low<high){
          mid=(low+high)/2;
          partition(arr,low,mid);
          partition(arr,mid+1,high);
          mergeSort(arr,low,mid,high);
     }
 }
 void mergeSort(float arr[],int low,int mid,int high){
     int i,m,k,l;
     float temp[1020];
     l=low;
     i=low;
     m=mid+1;
     while((l<=mid)&&(m<=high)){
          if(arr[l]<=arr[m]){
              temp[i]=arr[l];
              l++;
          }
          else{
              temp[i]=arr[m];
              m++;
          }
          i++;
     }
 
     if(l>mid){
          for(k=m;k<=high;k++){
              temp[i]=arr[k];
              i++;
          }
     }
     else{
          for(k=l;k<=mid;k++){
              temp[i]=arr[k];
              i++;
          }
     }
 
     for(k=low;k<=high;k++){
          arr[k]=temp[k];
     }
 }
 
 int main(void) {
 	int i,t,p,n,j,count,count1,k;
 	float x[1020],y[1020],z[1020];
 	scanf("%d",&t);
 	for(p=1;p<=t;p++)
 	{
 		count=0;count1=0;
 		scanf("%d",&n);
 		for(i=0;i<n;i++) scanf("%f",&x[i]);
 		for(i=0;i<n;i++) {scanf("%f",&y[i]);z[i]=y[i];}
 		partition(x,0,n-1);
 		partition(y,0,n-1);
 		partition(z,0,n-1);
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<n;j++)
 			{
 				if(z[j]>x[i]) {z[j]=0;count++;break;}
 			}
 		}
 		count=n-count;
 		k=0;
 		for(i=0;i<n;i++)
 		{
 			if(x[i]>y[k]) {count1++;k++;}
 		}
 		if(p!=t) printf("Case #%d: %d %d\n",p,count1,count);
 		else printf("Case #%d: %d %d",p,count1,count);
 	}
 	return 0;
 }

