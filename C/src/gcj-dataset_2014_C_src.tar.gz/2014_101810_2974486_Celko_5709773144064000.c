#include <stdio.h>
 #include <stdlib.h>
 
 //Constants
 
 #define T_MAX 100
 #define C_MAX 500
 #define F_MAX 4
 #define X_MAX 2000
 
 double answer[T_MAX];
 
 int main(){
 	double C, F, X, f = 2, time, newTime, oldTime;
 	int T, t;
 	int opt = 0;
 
 	scanf("%d", &T);
 	for(t = 0; t < T; t++){
 		time = 0; newTime = 0; oldTime = 0; opt =0; f=2;
 		scanf("%lf %lf %lf", &C, &F, &X);
 		while(!opt) {
 			oldTime = time + X/f;
 			newTime = time + C/f + X/(f+F);
 			if(oldTime < newTime){
 				answer[t] = oldTime;
 				opt = 1;
 			} else {
 				time = time + C/f;
 				f = f + F;
 			}
 		}
 	}
 
 	for(t = 0; t < T; t++) {
 		printf("Case #%d: %.7f\n", t+1, answer[t]);
 	}
 
     return 0;
 }
 

