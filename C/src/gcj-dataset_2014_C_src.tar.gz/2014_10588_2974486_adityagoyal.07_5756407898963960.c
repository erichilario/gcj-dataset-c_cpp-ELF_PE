#include<stdio.h>
 #include <stdlib.h>
 
 int main(){
     int t,n1,z,n2,i,j,match,ans;
     int a[4][4]={0};
     int b[4][4]={0};
     FILE *fp;
     fp = fopen ("jam1.out", "a");
 
     scanf("%d",&t);
     for (z = 1; z <= t; z++) {
                match=0;
                scanf("%d",&n1);
                for(i=0;i<4;i++){
                                  for(j=0;j<4;j++){
                                                    scanf("%d",&a[i][j]);
                                                    }
                                  }
                scanf("%d",&n2);
                for(i=0;i<4;i++){
                                  for(j=0;j<4;j++){
                                                    scanf("%d",&b[i][j]);
                                                    }
                                  }
                for(i=0;i<4;i++){
                                  for(j=0;j<4;j++){
                                                    if(a[n1-1][j] == b[n2-1][i]){
                                                                match++;
                                                                ans = a[n1-1][j];
                                                                }
                                                    }
                                  }
                //printf("%d",match);
                if(match==0){
                             fprintf(fp,"Case #%d: Volunteer cheated!\n",z);
                             }
                else if(match==1){
                             fprintf(fp,"Case #%d: %d\n",z,ans);
                     }
                else
                     fprintf(fp,"Case #%d: Bad magician!\n",z);
                }
     fclose(fp);
     return 0;
     }

