#include<stdio.h>
 #include<stdlib.h>
 int compare (const void * a, const void * b)
 {
    if( *(float*)a > *(float*)b )
    			return -1;
    	else
 	   		return 1;		
 }
 
 int main()
 {
 	int i,c,d,j,y,z,p,q,t,k,h[1500],n;
 	float a[1500],b[1500];
 	freopen("D-small-attempt0.in","r",stdin);
 	freopen("test_out2.txt","w",stdout);
 	scanf("%d",&t);
 	for(k=1;k<=t;k++)
 	{
 		c=0;
 		d=0;
 		j=0;
 		y=0;
 		z=0;
 		scanf("%d",&n);
 		p=n-1;
 		q=n-1;
 	//	printf("%d\n",n);
 		for(i=0;i<n;i++)
 			scanf("%f",&a[i]);
 		for(i=0;i<n;i++)
 			scanf("%f",&b[i]);
 			
 		/*	for(i=0;i<n;i++)
 			printf("%f ",a[i]);
 			printf("\n");
 		for(i=0;i<n;i++)
 			printf("%f ",b[i]);
 				printf("\n");*/
 		  qsort (a, n, sizeof(float), compare);
 		  qsort (b, n, sizeof(float), compare);
 		//for(i=0;i<n;i++)
 		//	printf("%f ",a[i]);
 		//	printf("\n");
 	//	for(i=0;i<n;i++)
 	//		printf("%f ",b[i]);
 	//			printf("\n");
 		 for(i=0;i<n;i++)
 		 {
 		// 	printf("p=%f q=%f\n",a[p],b[q]);
 			if(a[p]<b[q])
 		 	{
 		 		p--;
 		 		z++;
 		 	}
 		 	else
 		 	{
 		 		p--;
 		 		q--;
 		 		c++;
 		 	}
 		 
 		}
 		j=n-1;
 		for(i=0;i<n;i++)
 			h[i]=0;
 		for(i=n-1;i>=0;i--)
 		{
 			for(j=n-1;j>=0;j--)
 			{
 				if(a[i]<b[j]&&h[j]==0)
 				{
 					h[j]=1;
 					break;
 				}
 						
 			}
 			if(j==-1)
 			{
 				for(j=n-1;j>=0;j--)
 				{
 					if(h[j]==0)
 					{
 						h[j]=1;
 						d++;
 					}
 				}
 			}
 			
 		}
 		printf("Case #%d: %d %d\n",k,c,d);
 	}
 	
 	return 0;
 }

