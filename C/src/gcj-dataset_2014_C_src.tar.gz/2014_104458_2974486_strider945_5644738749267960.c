#include<stdio.h>
 
 int war(float[], float[], int);
 int dewar(float[], float[], int);
 void sort_asc(float*, int);
 
 int main()
 {
 	int i, t, n, j;
 
 	j = 1;
 	scanf("%d", &t);
 	while(t--) {
 		scanf("%d", &n);
 		float N[n], K[n];
 		for(i = 0;i < n;++i)
 			scanf("%f", &N[i]);
 		for(i = 0;i < n;++i)
 			scanf("%f", &K[i]);
 		sort_asc(N, n);
 		sort_asc(K, n);
 		printf("Case #%d: %d %d\n", j++, dewar(N, K, n), war(N, K, n));
 	}
 	return 0;
 }
 
 int war(float N[], float K[], int n)
 {
 	int i, j, Kn;
 
 	Kn = j = 0;
 	for(i = 0;i < n;++i)
 		for(;j < n;++j)
 			if(K[j] > N[i]) {
 				++j;
 				break;
 			}
 			else 
 				++Kn;
 	return Kn;
 }
 	
 int dewar(float N[], float K[], int n)
 {
 	int i, j, Kn;
 	
 	Kn = j = 0;
 	for(i = 0;i < n;++i)
 		if(N[i] > K[j]) {
 			++Kn;
 			++j;
 		}
 	return Kn;
 }
 
 void sort_asc(float *p, int n)
 {
 	int i, min, j;
 	float temp;
 
 	for(i = 0;i < n - 1;++i) {
 		min = i;
 		for(j = i + 1;j < n;++j)
 			if(p[min] > p[j])
 				min = j;
 		temp = p[i];
 		p[i] = p[min];
 		p[min] = temp;	
 	}
 }

