#include <stdio.h>
 
 int draw(int r,int c,int m) {
 	int i,j,cells,count;
 	cells = r*c - m;
 	count = 0;
 	for(i=0;i<r;i++) {
 		for(j=0;j<c;j++) {
 			if(cells > (c + 2)) {
 				if(count < cells) {
 					if((i == 0) && (j == 0)) {
 						printf("c");
 					}
 					else {
 						printf(".");
 					}
 					count++;
 				}
 				else {
 					printf("*");
 				}
 			}
 			else {
 				int var = cells-2;
 				if(count < var) {
 					if((i == 0) && (j == 0)) {
 						printf("c");
 					}
 					else {
 						printf(".");
 					}
 					count++;
 				}
 				else
 				if((i == 1) && ((j == 0) || (j == 1))) {
 					printf(".");
 					count++;
 				}
 				else {
 					printf("*");
 				}
 			}
 		}
 		printf("\n");
 	}
 }
 
 int drawsec(int r,int c,int m) {
 	int cells,count,i,j;
 	cells = r*c - m;
 	count=0;
 	for(i=0;i<r;i++) {
 		for(j=0;j<c;j++) {
 			if(count < cells) {
 				if((i == 0) && (j == 0)) {
 					printf("c");
 				}
 				else {
 					printf(".");
 				}
 				count++;
 			}
 			else {
 				printf("*");
 			}
 		}
 		printf("\n");
 	}
 }
 
 int main() {
 	int t,p,r,c,m;
 	scanf("%d",&t);
 	for(p=1;p<=t;p++) {
 		scanf("%d %d %d",&r,&c,&m);
 		if(m == 0) {
 			printf("Case #%d:\n",p);
 			drawsec(r,c,m);	
 		}
 		else
 		if((r == 1) || (c == 1)) {
 			if((r*c - m) >= 2) {
 				printf("Case #%d:\n",p);
 				drawsec(r,c,m);
 			}
 			else {
 				printf("Case #%d:\n",p);
 				printf("Impossible\n");
 			}
 		}
 		else
 		if((r*c - m) == 1){
 				printf("Case #%d:\n",p);
 				drawsec(r,c,m);
 		}
 		else 
 		if((r*c - m) <= 3 && (r*c - m) > 1){
 			printf("Case #%d:\n",p);
 			printf("Impossible\n");
 		}
 		else
 		if((r*c - m) >= 4) {
 			printf("Case #%d:\n",p);
 			draw(r,c,m);
 		}
 	}
 	return 0;
 }

