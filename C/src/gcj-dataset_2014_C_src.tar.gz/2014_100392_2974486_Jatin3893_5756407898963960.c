#include <stdio.h>
 
 int main()
 {
 	int t, iter;
 	scanf(" %d", &t);
 	int arr1[4][4];
 	int arr2[4][4];
 	
 	for(iter = 0; iter < t; iter++)
 	{
 		int n1, n2, i, j;
 
 		scanf(" %d", &n1);
 		for(i = 0; i < 4; i++)
 		{
 			for(j = 0; j < 4; j++)
 			{
 				scanf(" %d", &arr1[i][j]);
 			}
 		}
 
 		scanf(" %d", &n2);
 		for(i = 0; i < 4; i++)
 		{
 			for(j = 0; j < 4; j++)
 			{
 				scanf(" %d", &arr2[i][j]);
 			}
 		}
 		n1--;
 		n2--;
 		int count = 0;
 		int pos = -1;
 
 		for(i = 0; i < 4; i++)
 		{
 			for(j = 0; j < 4; j++)
 			{
 				if(arr1[n1][i] == arr2[n2][j])
 				{
 					pos = arr1[n1][i];
 					count++;
 				}
 			}
 		}
 
 		if(count == 1)
 			printf("Case #%d: %d\n", iter + 1, pos);
 		else if(count > 1)
 			printf("Case #%d: Bad magician!\n", iter + 1);
 		else if(count < 1)
 			printf("Case #%d: Volunteer cheated!\n", iter + 1);
 	}
 	return 0;
 }
