#include <stdio.h>
 
 int main()
 {
 	int i,j,k,m,n;
 	int ks, ns;
 	int T;
 	long double a[1000], b[1000];
 	int bv[1000];
 	long double tmp;
 	
 	fscanf(stdin, "%d", &T);
 	for(k=0;k<T;k++)
 	{
 		fscanf(stdin, "%d", &n);
 		for(i=0;i<n;i++) fscanf(stdin, "%Lf", &a[i]);
 		for(i=0;i<n;i++) 
 		{
 			fscanf(stdin, "%Lf", &b[i]);
 			bv[i]=0;
 		}
 		
 		for(i=0;i<n;i++)
 		for(j=0;j<i;j++)
 		{
 			if(a[i]<a[j])
 			{
 				tmp=a[i];
 				a[i]=a[j];
 				a[j]=tmp;
 			}
 
 			if(b[i]<b[j])
 			{
 				tmp=b[i];
 				b[i]=b[j];
 				b[j]=tmp;
 			}
 		}
 		
 		//for(i=0;i<n;i++) printf("%Lf ", a[i]); printf("\n");
 		//for(i=0;i<n;i++) printf("%Lf ", b[i]); printf("\n");		
 
 		ks=0;
 		for(i=0;i<n;i++)
 		for(j=0;j<n;j++)
 		{
 			if(b[j]>a[i] && bv[j]==0)
 			{
 				ks++;
 				bv[j]=1;
 				j=n;
 			}
 		}	
 		
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<n-i;j++)
 			{
 				if(a[j+i]<b[j]) break;
 			}
 			if(j==n-i) break;
 		}
 		
 		printf("Case #%d: %d %d\n", k+1, n-i, n-ks);
 	}	
 
 	return 0;
 }
 		
 			 
 		
