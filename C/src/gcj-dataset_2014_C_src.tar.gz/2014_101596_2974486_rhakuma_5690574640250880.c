#include <stdio.h>
 #include <stdlib.h>
 
 void compute(FILE* ofile, int r, int c, int m) {
     int *grid;
     int i, j, blank, need_blank;
     char ch;
     printf("r=%d, c=%d, m=%d\n", r, c, m);
 
     if (r == 1 && c == 1) {
         need_blank = 1;
     } else if (r == 1 || c == 1) {
         need_blank = 2;
     } else {
         need_blank = 4;
     }
 
     blank = (r*c - m);
     if (blank < need_blank) {
         fprintf(ofile, "Impossible\n");
     } else {
         grid = (int *) malloc(sizeof(int) * r * c);
         for (i=r-1; i>=0; i--) {
             for (j=c-1; j>=0; j--) {
                 if (i == 0 && j == 0) {
                     ch = 'c';
                 } else if (i < 2 && j <2) {
                     ch = '.';
                 } else {
                     if (m > 0) {
                         ch = '*';
                         m--;
                     } else {
                         ch = '.';
                     }
                 }
                 *(grid + c*i + j) = ch;
             }
         }
         for (i=0; i<r; i++) {
             for (j=0; j<c; j++) {
                 ch = *(grid + c*i + j);
                 fprintf(ofile, "%c", ch);
                 //printf("%c", ch);
             }
             fprintf(ofile, "\n");
             //printf("\n");
         }
         free(grid);
         grid = NULL;
     }
 }
 
 int main(int argc, char* argv[]) {
     FILE *ifile;
     FILE *ofile;
     char* filename = NULL;
     char* outfile = "output.txt";
 
     int i, count;
     int r, c, m;
     
     if (argc != 2) {
         printf("usage: problem_a input.txt\n");
         return 1;
     }
 
     filename = argv[1];
     printf("filename: %s\n", filename);
 
     ifile = (FILE *) fopen(filename, "r");
     ofile = (FILE *) fopen(outfile, "w");
 
     fscanf(ifile, "%d", &count);
     for (i=0; i<count; i++) {
         fscanf(ifile, "%d %d %d", &r, &c, &m); 
 
         fprintf(ofile, "Case #%d:\n", (i+1));
         compute(ofile, r, c, m);
     }
 
     fclose(ifile);
     fclose(ofile);
 
     return 0;
 }
 

