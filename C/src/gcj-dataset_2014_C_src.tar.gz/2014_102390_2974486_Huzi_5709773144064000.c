//
 //  main.c
 //  CodeJam
 //
 //  Created by Huzefa on 4/11/14.
 //  Copyright (c) 2014 Huzefa. All rights reserved.
 //
 
 #include <stdio.h>
 
 int main(int argc, const char * argv[])
 {
     int noOfTestcases=0;
     FILE *fp;
     FILE *out= fopen("/Users/admin/Desktop/output.txt","w");
     int counter=0;
     double firsttime=0.0,secondtime=0.0;
     double totalSeconds=0;
     double C=0,F=0,X=0;
     double totalRate=2;
     double noOfCookies=0;
     fp = fopen("/Users/admin/Desktop/input.txt","r");
     // insert code here...
     fscanf(fp,"%d\n",&noOfTestcases);
     while(counter<noOfTestcases){
         printf("%d\n",counter);
         totalSeconds=0;
         totalRate=2;
         noOfCookies=0;
         firsttime=secondtime=0.0;
         fscanf(fp,"%lf %lf %lf\n",&C,&F,&X);
         while(noOfCookies+0.000001<X){
              //printf("2\n");
             firsttime=((double)X)/totalRate;
             secondtime=((double)C/totalRate)+((double)X/(totalRate+F));
             if(firsttime<=secondtime){
                 noOfCookies=firsttime*totalRate;
                 totalSeconds+=firsttime;
             }else{
                 secondtime = (C-noOfCookies) / totalRate;
                 noOfCookies = (secondtime*totalRate)-C;
                 totalSeconds+=(double)secondtime;
                 totalRate+=F;
             }
         }
         fprintf(out, "Case #%d: %lf\n",counter+1,totalSeconds);
         counter++;
     }
     return 0;
 }

