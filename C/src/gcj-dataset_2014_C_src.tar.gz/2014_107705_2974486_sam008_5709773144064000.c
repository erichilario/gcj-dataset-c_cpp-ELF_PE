// Codejam2.cpp : Defines the entry point for the console application.
 //
 
 //#include "stdafx.h"
 #include "stdlib.h"
 #include "stdio.h"
 
 int buyCookieFarm(double c,double *noOfCookies_sec, double f,double *result)
 {
 	*result += (c / (*noOfCookies_sec));
 	*noOfCookies_sec += f;
 	return 0;
 }
 
 int check(double *result, double noOfcookies_sec, double c, double f,double x)
 {
 	double printResult, buyFarm;
 	printResult = *result + x / noOfcookies_sec;
 	buyFarm = *result + (c / noOfcookies_sec) + (x / (noOfcookies_sec + f));
 	if (printResult < buyFarm)
 	{
 		*result = printResult;
 		return 0;
 	}
 	else
 	{
 		return 1;
 	}
 }
 
 int main(int argc, char* argv[])
 {
 	FILE *fin, *fout;
 	int noOfCases,currentCase=1;
 	double result, c, f, x, noOfCookies_sec = 2;
 	fin=fopen("B-large.in", "rb");
 
 	if (fin == NULL)
 		printf("null");
 	fscanf(fin, "%d", &noOfCases);
 	while (noOfCases)
 	{
 		result = 0;
 		noOfCookies_sec = 2;
 		fscanf(fin, "%lf%lf%lf", &c, &f, &x);
 		if (x < c)
 		{
 			result = x / 2;
 		}
 		else
 		{
 			while (check(&result, noOfCookies_sec, c, f, x))
 			{
 				buyCookieFarm(c, &noOfCookies_sec, f, &result);
 			}
 		}
 		fout=fopen("A-small-output.in", "ab");
 		fprintf(fout, "Case #%d: %f\n", currentCase++,result);
 		fclose(fout);
 		noOfCases--;
 	}
 	return 0;
 }
 

