#include<stdio.h>
 int main()
 {
 	FILE *ipf=fopen("B-large.in","r");
 	FILE *opf=fopen("output4.txt","w");
 	int t=0,test;
 	fscanf(ipf,"%d",&test);
 	while(test--)
 	{
 		t=t+1;
 		double c,f,x;
 		fscanf(ipf,"%lf",&c);
 		fscanf(ipf,"%lf",&f);
 		fscanf(ipf,"%lf",&x);
 		
 	double telasped=0,temp=0,time=0,at=0,r=2;
 	 double arr[1000];
 		do
 		{
 			if(telasped==0)
 			telasped=x/r;
 			else
 			telasped=temp;
 			
 			time=c/r;
 			at=at+time;
 			r+=f;
 			temp=at+x/r;
 		
 		}while(temp<telasped);
 		
 		fprintf(opf,"Case #%d: %.7lf\n",t,telasped);
 	}
 	return 0;
 }

