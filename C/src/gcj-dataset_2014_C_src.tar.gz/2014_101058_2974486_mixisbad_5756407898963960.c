/*
  * trick.c
  *
  *  Created on: Apr 11, 2014
  *      Author: pxp943
  */
 
 
 #include<stdio.h>
 
 
 
 int first[4][4];
 int second[4][4];
 
 int isItIn(int number,int row);
 
 int main()
 {
 	int testcase;
 	int i,j,k;
 	int firstChoice;
 	int secondChoice;
 	int count;
 	int firstAnswer;
 
 
 	scanf("%d",&testcase);
 
 	for(i=0;i<testcase;++i)
 	{
 		scanf("%d",&firstChoice);
 
 		scanf("%d %d %d %d", &first[0][0],&first[0][1],&first[0][2],&first[0][3]);
 		scanf("%d %d %d %d", &first[1][0],&first[1][1],&first[1][2],&first[1][3]);
 		scanf("%d %d %d %d", &first[2][0],&first[2][1],&first[2][2],&first[2][3]);
 		scanf("%d %d %d %d", &first[3][0],&first[3][1],&first[3][2],&first[3][3]);
 
 		scanf("%d",&secondChoice);
 
 		scanf("%d %d %d %d", &second[0][0],&second[0][1],&second[0][2],&second[0][3]);
 		scanf("%d %d %d %d", &second[1][0],&second[1][1],&second[1][2],&second[1][3]);
 		scanf("%d %d %d %d", &second[2][0],&second[2][1],&second[2][2],&second[2][3]);
 		scanf("%d %d %d %d", &second[3][0],&second[3][1],&second[3][2],&second[3][3]);
 
 		firstChoice--;
 		secondChoice--;
 
 		count=0;
 		for(j=0;j<4;++j)
 		{
 			if(isItIn(second[secondChoice][j],firstChoice))
 				{
 					if(count==0)firstAnswer = second[secondChoice][j];
 					count++;
 				}
 		}
 
 		if(count == 1) printf("Case #%d: %d\n",i+1,firstAnswer);
 		else if( count > 1) printf("Case #%d: Bad magician!\n",i+1);
 		else printf("Case #%d: Volunteer cheated!\n",i+1);
 
 	}
 
 	return 0;
 }
 
 int isItIn(int number,int row)
 {
 	int i;
 
 	for(i = 0 ; i  < 4; ++i)
 	{
 		if(number == first[row][i])return 1;
 	}
 
 	return 0;
 }
 

