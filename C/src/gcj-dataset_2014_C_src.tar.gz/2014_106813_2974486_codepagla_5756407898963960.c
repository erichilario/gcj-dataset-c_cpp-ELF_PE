#include<stdio.h>
 int main(){
 	int T,t,cnt,x[5],y[5],a,b,c,d,row1,row2,i,j,card;
 	scanf("%d",&T);
 	for(t=1;t<=T;t++){
 		scanf("%d",&row1);
 		for(i=1;i<=4;i++){
 			if(i==row1){
 				scanf("%d %d %d %d",&x[1],&x[2],&x[3],&x[4]);
 			}
 			else
 				scanf("%d %d %d %d",&a,&b,&c,&d);
 		}
 		scanf("%d",&row2);
 		for(i=1;i<=4;i++){
                         if(i==row2){
                                 scanf("%d %d %d %d",&y[1],&y[2],&y[3],&y[4]);
                         }
                         else
                                 scanf("%d %d %d %d",&a,&b,&c,&d);
                 }
 		cnt=0;
 		for(i=1;i<=4;i++){
 			for(j=1;j<=4;j++){
 				if(x[i]==y[j]){
 					cnt++;
 					card=x[i];
 				}
 			}
 		}
 		if(cnt==0){
 			printf("Case #%d: Volunteer cheated!\n",t);
 		}
 		else if(cnt==1){
 			printf("Case #%d: %d\n",t,card);
 		}
 		else
 			printf("Case #%d: Bad magician!\n",t);
 	}
 	return 0;
 }
 		
 

