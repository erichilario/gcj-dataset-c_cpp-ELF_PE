#include <stdio.h>
 
 int main()
 {
 	int T;
 	double C,F,X;
 	int i;
 	int n;
 	double t;
 	scanf("%d", &T);
 	for(i=1; i<=T; i++) {
 		scanf("%lf %lf %lf", &C, &F, &X);
 		printf("Case #%d: ", i);
 		t=0;
 		for(	n=0;
 			X/(2+n*F)>X/(2+(n+1)*F)+C/(2+n*F);
 			n++) {
 			t+= C/(2+n*F);
 		}
 /* printf("n=%d, t=%.2lf\n", n, t); */
 		t += X/(2+n*F);
 		printf("%.7lf\n", t);
 	}
 	return 0;
 }

