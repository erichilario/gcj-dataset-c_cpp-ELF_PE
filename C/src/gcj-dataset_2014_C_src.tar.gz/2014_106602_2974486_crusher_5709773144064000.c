#include<stdio.h>
  main() {
  	FILE *fp;
  	fp=fopen("output.txt","w");
   float c,f,x;
   int t,i;
   float numCoo,counter,time,tot,inix; 
   scanf("%d",&t); 
   int flag=0;
   for(i=0;i<t;i++){
   	  scanf("%f %f %f",&c,&f,&x); 
   	  inix=x; numCoo=0; counter=2; time=0; tot=0; 
     	while(inix>=0){ 
     		if(numCoo+c>=x){ 
 		   		if(flag==0){tot=1;break;}
 		    	tot+=x/counter; 
 	        	
     		 	break; 
     		 }
  		flag=2;
    		time=c/counter; 
     	
    		numCoo+=c; 
     	tot=tot+time;
   	    inix=inix-c; 
        counter+=f; }
      //  printf("Case #%d: %.7f\n",i+1,tot);
     fprintf(fp,"Case #%d: %.7f\n",i+1,tot);
         } 
   }

