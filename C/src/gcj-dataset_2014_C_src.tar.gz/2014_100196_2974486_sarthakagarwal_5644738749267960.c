#include<stdio.h>
 double a[15],b[15];
 int find1(int n){
      int i=0,j=0,k=0,flag,count=0;
    while(i<n && j<n ){
      flag=0;
      if(a[i]>b[j])
        j++; 
      else
      {
          flag=1;
          count+=(j-k);
          j++;
          k=j;
          i++;   
      }
    }
    if(flag==0)
      count+=(j-k);
    return count;  
 }
 
 void sort(double a[],int n)
 {
 	double temp;
 	int i,j;
 	for(i=0;i<n;i++)
 	{
 		for(j=0;j<n;j++)
 		{
 			if(a[i]<a[j])
 			{
 				temp=a[j];
 				a[j]=a[i];
 				a[i]=temp;
 			}
 		}
 	}
 }
     
 int find2(int n){
            int i=0,j=0,flag=0,lim,count=0;
     
            while(i<n && j<n)
             if(a[i]>b[j]){
               i++;
               j++;
               count++;
             }
             else
              i++;                           
             return count;
 }
 int main(){
     int t,k,n,i,j,count1,count2;
     scanf("%d",&t);
     for(k=1;k<=t;k++)
     {
        count1=0;
        count2=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
          scanf("%lf",&a[i]);
        for(i=0;i<n;i++)
          scanf("%lf",&b[i]);
        sort(a,n);
        sort(b,n);
        printf("Case #%d: %d %d\n",k,find2(n),find1(n));
      }     
      return 0;
 }
 
 

