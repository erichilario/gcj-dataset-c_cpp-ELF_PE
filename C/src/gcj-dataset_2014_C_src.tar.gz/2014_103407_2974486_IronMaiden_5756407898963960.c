#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
     FILE *fp,*ofp;
     fp=fopen("input.txt", "r");
     ofp=fopen("output.txt","w");
     int test,t;
     fscanf(fp,"%d",&test);
     for(t=1;t<=test;t++)
     {
         int a[4][4],ans1,ans2,b[4],cd=0,i,j,fin=0,c[4][4];
         ans1=ans2=45;
         fscanf(fp,"%d",&ans1);
         ans1--;
         for(i=0; i<4; i++)
         {
 
             for(j=0; j<4; j++)
                 fscanf(fp,"%d",&a[i][j]);
 
         }
 
 
         for(i=0; i<4; i++)
         {
             b[i]=a[ans1][i];
         }
 
 
         fscanf(fp,"%d",&ans2);
         ans2--;
         for(i=0; i<4; i++)
         {
 
             for(j=0; j<4; j++)
                 fscanf(fp,"%d",&c[i][j]);
 
         }
 
         for(i=0; i<4; i++)
         {
             for(j=0; j<4; j++)
             {
                 if(b[i]==c[ans2][j])
                 {
                     cd++;
                     fin=b[i];
                 }
 
 
             }
         }
         if(cd==1)
         {
             fprintf(ofp,"Case #%d: %d\n",t,fin);
         }
         if(cd==0)
             fprintf(ofp,"Case #%d: Volunteer cheated!\n",t);
         if(cd>1)
             fprintf(ofp,"Case #%d: Bad magician!\n",t);
 
 
     }
 
 
 return 0;
 
 }

