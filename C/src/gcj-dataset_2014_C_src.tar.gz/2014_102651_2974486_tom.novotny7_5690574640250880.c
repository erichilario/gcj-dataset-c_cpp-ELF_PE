#include <stdio.h>
 #include <stdlib.h>
 
 void repeat(char c, int times);
 void repeatArr(char c[], int times);
 void repeatEndline(char c, int times);
 void repeatArrEndline(char c[], int times);
 
 FILE *f, *g;
 
 int main()
 {
     int numOfTests;
     int r, c, m;
 
 //    f = stdin;
 //    g = stdout;
     f = fopen("input.in", "r");
     g = fopen("output.out", "w");
 
     fscanf(f, "%d", &numOfTests);
 
     for(int i = 1; i <= numOfTests; i++){
         fscanf(f, "%d%d%d", &r, &c, &m);
         fprintf(g, "Case #%d:\n", i);
 
         int min = (r > c)?c:r;
         int max = (r < c)?c:r;
         int freeSpots = r*c - m;
 
         if(min == 1){
             if(c > r){
                 repeat('c', 1);
                 repeat('.', freeSpots - 1);
                 repeat('*', m);
                 repeat('\n', 1);
             }
             else{
                 repeatEndline('c', 1);
                 repeatEndline('.', freeSpots - 1);
                 repeatEndline('*', m);
             }
             continue;
         }
         if(m == 2){
                 fprintf(g, "Impossible\n", i);
                 continue;
             }
         if(min == 2){
             if(m % 2 == 1){
                 fprintf(g, "Impossible\n", i);
                 continue;
             }
             if(c > r){
                 repeat('c', 1);
                 repeat('.', (freeSpots - 2)/2);
                 repeat('*', m/2);
                 repeat('\n', 1);
                 repeat('.', freeSpots/2);
                 repeat('*', m/2);
                 repeat('\n', 1);
             }
             else{
                 repeat('c', 1);
                 repeatEndline('.', 1);
                 for(int j = 0; j < (freeSpots - 2)/2; j++){
                     repeat('*', 2);
                     repeat('\n', 1);
                 }
                 for(int j = 0; j < m/2; j++){
                     repeat('*', 2);
                     repeat('\n', 1);
                 }
             }
             continue;
         }
         if(freeSpots >= 9 || (freeSpots % 2 == 0 && freeSpots >= 4)){ //only for 5 or less lines
             if(freeSpots % 2 == 0){
                 repeat('c', 1);
                 if(freeSpots >= 2*c){
                     repeat('.', c-1);
                     repeat('\n', 1);
                     repeat('.', c);
                     repeat('\n', 1);
                     if(freeSpots >= 4*c){
                         repeat('.', c);
                         repeat('\n', 1);
                         repeat('.', c);
                         repeat('\n', 1);
                     }
                     for(int j = freeSpots/c; j < r; j++){
                         repeat('*', c);
                         repeat('\n', 1);
                     }
                 }
                 else{
                     repeat('.', freeSpots/2 - 1);
                     repeat('*', c - freeSpots/2);
                     repeat('\n', 1);
                     repeat('.', freeSpots/2);
                     repeat('*', c - freeSpots/2);
                     repeat('\n', 1);
                     for(int j = 2; j < r; j++){
                         repeat('*', c);
                         repeat('\n', 1);
                     }
                     continue;
                 }
             }
             else{
                 /*if(freeSpots == 9){
                     repeat('c', 1);
                     repeat('.', 2);
                     if(c > 3) repeat('*', c-3);
                     repeat('\n', 1);
                     repeat('.', 3);
                     if(c > 3) repeat('*', c-3);
                     repeat('\n', 1);
                     repeat('.', 3);
                     if(c > 3) repeat('*', c-3);
                     repeat('\n', 1);
                     if(r >= 4){
                         repeat('*', c);
                         repeat('\n', 1);
                     }
                     if(r == 5){
                         repeat('*', c);
                         repeat('\n', 1);
                     }
                 }
                 if(freeSpots == 11){
                     if(c > 3){
                         repeat('c', 1);
                         repeat('.', 3);
                         if(c > 3) repeat('*', c-4);
                         repeat('\n', 1);
                         repeat('.', 4);
                         if(c > 3) repeat('*', c-4);
                         repeat('\n', 1);
                         repeat('.', 3);
                         if(c > 3) repeat('*', c-3);
                         repeat('\n', 1);
                         if(r >= 4){
                             repeat('*', c);
                             repeat('\n', 1);
                         }
                         if(r == 5){
                             repeat('*', c);
                             repeat('\n', 1);
                         }
                     }
                     else{
                         repeat('c', 1);
                         repeat('.', 2);
                         if(c > 3) repeat('*', c-3);
                         repeat('\n', 1);
                         repeat('.', 3);
                         if(c > 3) repeat('*', c-3);
                         repeat('\n', 1);
                         repeat('.', 3);
                         if(c > 3) repeat('*', c-3);
                         repeat('\n', 1);
                         if(r >= 4){
                             repeat('.', 2);
                             repeat('*', c-2);
                             repeat('\n', 1);
                         }
                         if(r == 5){
                             repeat('*', c);
                             repeat('\n', 1);
                         }
                     }
                 }*/
                 if(c == 3){
                     repeat('c', 1);
                     repeat('.', 2);
                     repeat('\n', 1);
                     repeat('.', 3);
                     repeat('\n', 1);
                     repeat('.', 3);
                     repeat('\n', 1);
                     if(r >= 4){
                         if(freeSpots > 9){
                             repeat('.', freeSpots - 9);
                             repeat('*', c + 9 - freeSpots);
                         }
                         else repeat('*', c);
                         repeat('\n', 1);
                     }
                     if(r == 5){
                         if(freeSpots > 12){
                             repeat('.', freeSpots - 12);
                             repeat('*', c + 12 - freeSpots);
                         }
                         else repeat('*', c);
                         repeat('\n', 1);
                     }
                 }
                 if(c == 4){
                     repeat('c', 1);
                     repeat('.', 2);
                     (freeSpots > 9)?repeat('.', 1):repeat('*', 1);
                     repeat('\n', 1);
                     repeat('.', 3);
                     (freeSpots > 9)?repeat('.', 1):repeat('*', 1);
                     repeat('\n', 1);
 
                     repeat('.', 3);
                     (freeSpots > 13)?repeat('.', 1):repeat('*', 1);
                     repeat('\n', 1);
                     if(r >= 4){
                         (freeSpots > 11)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 11)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 13)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 17)?repeat('.', 1):repeat('*', 1);
                         repeat('\n', 1);
                     }
                     if(r == 5){
                         (freeSpots > 15)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 15)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 17)?repeat('.', 1):repeat('*', 1);
                         repeat('*', 1);
                         repeat('\n', 1);
                     }
                 }
                 if(c == 5){
                     repeat('c', 1);
                     repeat('.', 2);
                     (freeSpots > 9)?repeat('.', 1):repeat('*', 1);
                     (freeSpots > 11)?repeat('.', 1):repeat('*', 1);
                     repeat('\n', 1);
                     repeat('.', 3);
                     (freeSpots > 9)?repeat('.', 1):repeat('*', 1);
                     (freeSpots > 11)?repeat('.', 1):repeat('*', 1);
                     repeat('\n', 1);
 
                     repeat('.', 3);
                     (freeSpots > 13)?repeat('.', 1):repeat('*', 1);
                     (freeSpots > 13)?repeat('.', 1):repeat('*', 1);
                     repeat('\n', 1);
                     if(r >= 4){
                         (freeSpots > 15)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 15)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 17)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 17)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 23)?repeat('.', 1):repeat('*', 1);
                         repeat('\n', 1);
                     }
                     if(r == 5){
                         (freeSpots > 19)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 19)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 21)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 21)?repeat('.', 1):repeat('*', 1);
                         (freeSpots > 23)?repeat('.', 1):repeat('*', 1);
                         repeat('\n', 1);
                     }
                 }
             }
         }
         else{
             fprintf(g, "Impossible\n", i);
             continue;
         }
     }
 
     fclose(f);
     fclose(g);
     return 0;
 }
 
 void repeat(char c, int times){
     char arr[2];
     arr[0] = c;
     arr[1] = 0;
     repeatArr(arr, times);
 }
 void repeatArr(char c[], int times){
     for(int i = 0; i < times; i++) fprintf(g, "%s", c);
 }
 void repeatEndline(char c, int times){
     char arr[2];
     arr[0] = c;
     arr[1] = 0;
     repeatArrEndline(arr, times);
 }
 void repeatArrEndline(char c[], int times){
     for(int i = 0; i < times; i++) fprintf(g, "%s\n", c);
 }

