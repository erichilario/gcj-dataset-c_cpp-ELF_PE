// @AUTHOR ajay yadav//
 #include<stdio.h>
 #define SIZE 1010
 #define MUL 100000
 typedef struct
 {
     long long value;
     int flag;
 } NUMTYPE;
 NUMTYPE naomi[SIZE],ken[SIZE];
 int cmp(const void *a, const void *b)
 {
     NUMTYPE *ia = (NUMTYPE *)a;
     NUMTYPE *ib = (NUMTYPE *)b;
     return (ia->value)-(ib->value);
     /* strcmp functions works exactly as expected from
     comparison function */
 }
 int main()
 {
     int t,z=1,n,i,l,m;
     double x;
     scanf("%d",&t);
     while(z<=t)
     {
         printf("Case #%d: ",z);
         scanf("%d ",&n);
         for(i=0; i<n; i++)
         {
             scanf("%lf",&x);
             naomi[i].value=(long long)MUL*(x+1e-6);
             naomi[i].flag=0;
         }
         for(i=0; i<n; i++)
         {
             scanf("%lf",&x);
             ken[i].value=(long long)MUL*(x+1e-6);
             ken[i].flag=0;
         }
         qsort(naomi,n,sizeof(NUMTYPE),cmp);
         qsort(ken,n,sizeof(NUMTYPE),cmp);
         /*for(i=0;i<n;i++)
         {
             printf("%lld  %d\n",naomi[i].value,naomi[i].flag);
         }*/
         int count1=0;
         for(l = 0; l < n; l++)
         {
             for(m = 0; m < n; m++)
             {
                 if(naomi[l].value > ken[m].value && ken[m].flag == 0)
                 {
                     ken[m].flag = 1;
                     count1++;
                     break;
                 }
             }
         }
         for(m = 0; m < n; m++)
             ken[m].flag = 0;
 
         int count2=0,firstcheck=0;
         for(l = 0; l < n; l++)
         {
             firstcheck = 0;
             for(m = 0; m < n; m++)
             {
                 if(naomi[l].value < ken[m].value && ken[m].flag == 0)
                 {
                     firstcheck = 1;
                     ken[m].flag = 1;
                     break;
                 }
             }
             if(!firstcheck) count2++;
         }
         printf("%d %d\n",count1,count2);
         z++;
     }
     return 0;
 }

