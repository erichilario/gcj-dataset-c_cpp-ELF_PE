#include <stdio.h>
 
 double C, F, X, r, rtemp, accum;
 int T, i, j;
 
 int main(){
 	scanf("%d", &T);
 	for(i = 0; i < T; i++){
 		scanf("%lf %lf %lf", &C, &F, &X);
 		accum = 0;
 		j = 0;
 		r = X/2;
 		while(1){
 			accum += C/(2 + j*F);
 			rtemp = X/(2 + (j + 1)*F) + accum; 
 			if(r < rtemp) break;
 			else r = rtemp;
 			j++;
 		}		
 		printf("Case #%d: %lf\n", i + 1, r);
 	}
 	return 0;
 }
