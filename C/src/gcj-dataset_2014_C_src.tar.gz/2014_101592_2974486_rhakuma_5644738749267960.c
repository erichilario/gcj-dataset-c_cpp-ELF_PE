#include <stdio.h>
 #include <stdlib.h>
 
 void sort(int size, double* target) {
     int i, j;
     double swap;
     for (i=0; i<size-1; i++) {
         for (j=i+1; j<size; j++) {
             if (*(target+i) > *(target+j)) {
                 swap = *(target+i);
                 *(target+i) = *(target+j);
                 *(target+j) = swap;
             }
         }
     }
 }
 
 int get_deceitful_war_result(int size, double* me, double* other) {
     int i;
     int pos_f1, pos_l1, pos_f2, pos_l2;
     int score = 0;
     pos_f1 = pos_f2 = 0;
     pos_l1 = pos_l2 = (size-1);
 
     for (i=0; i<size; i++) {
         if (me[pos_f1] < other[pos_f2]) {
             pos_f1++;
             pos_l2--;
         } else if (me[pos_l1] < other[pos_l2]) {
             pos_f1++;
             pos_l2--;
         } else {
             pos_f1++;
             pos_f2++;
             score++;
         }
     }
     return score;
 }
 
 int get_war_result(int size, double* me, double* other) {
     int i, j;
     int pos_f1, pos_l1, pos_f2, pos_l2;
     int score = 0;
     pos_f1 = pos_f2 = 0;
     pos_l1 = pos_l2 = (size-1);
 
     for (i=0; i<size; i++) {
         if (me[pos_f1] < other[pos_f2]) {
             pos_f1++;
             pos_f2++;
         } else {
             for (j=pos_f2; j<size; j++) {
                 if (me[pos_f1] < other[j]) {
                     pos_f2 = j;
                     break;
                 }
             }
             if (j != size) {
                 pos_f1++;
                 pos_f2++;
             } else {
                 pos_f2 = j;
             }
         }
         if (pos_f2 == size) {
             return (size-pos_f1);
         }
     }
     return score;
 }
 
 int main(int argc, char* argv[]) {
     FILE *ifile;
     FILE *ofile;
     char* filename = NULL;
     char* outfile = "output.txt";
 
     int i, j, count;
     int n, result1, result2;
 
     double *block_naomi;
     double *block_ken;
     
     if (argc != 2) {
         printf("usage: problem_a input.txt\n");
         return 1;
     }
 
     filename = argv[1];
     printf("filename: %s\n", filename);
 
     ifile = (FILE *) fopen(filename, "r");
     ofile = (FILE *) fopen(outfile, "w");
 
     fscanf(ifile, "%d", &count);
     for (i=0; i<count; i++) {
         fscanf(ifile, "%d", &n); 
 
         block_naomi = (double*) malloc(sizeof(double) * n);
         block_ken = (double*) malloc(sizeof(double) * n);
 
         for (j=0; j<n; j++) {
             fscanf(ifile, "%lf", (block_naomi+j));
         }
         sort(n, block_naomi);
 
         for (j=0; j<n; j++) {
             fscanf(ifile, "%lf", (block_ken+j));
         }
         sort(n, block_ken);
 
         result1 = get_deceitful_war_result(n, block_naomi, block_ken);
         result2 = get_war_result(n, block_naomi, block_ken);
 
         fprintf(ofile, "Case #%d: %d %d\n", i+1, result1, result2);
 
         free(block_naomi);
         free(block_ken);
     }
 
     fclose(ifile);
     fclose(ofile);
 
     return 0;
 }
 

