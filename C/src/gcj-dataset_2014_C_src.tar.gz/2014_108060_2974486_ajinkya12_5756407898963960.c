//Google Code Jam
 #include<stdio.h>
 
 
 int main()
 {
 	int i,j,flag,s;
 	int a[4][4],b[4][4],r1,r2,t;
 	FILE *fp,*fm;
 	
 	fp = fopen("A-small-attempt0.in","r");
 	fm = fopen("outputMT.txt","w");
 	fscanf(fp,"%d\n",&t);
 	//printf("test %d\n",t);
 	t=1;
 	
 	while(!feof(fp))
 	{
 		fscanf(fp,"%d\n",&r1);
 		for(i=0;i<4;i++)
 			fscanf(fp,"%d %d %d %d\n",&a[i][0],&a[i][1],&a[i][2],&a[i][3]);
 		fscanf(fp,"%d\n",&r2);
 		
 		for(i=0;i<4;i++)
 			fscanf(fp,"%d %d %d %d\n",&b[i][0],&b[i][1],&b[i][2],&b[i][3]);
 			
 		r1--;
 		r2--;
 		
 		flag=0;
 		for(i=0;i<4 && flag <2;i++)
 		{
 			for(j=0;j<4 && flag <2;j++)
 			{
 				if(a[r1][i] == b[r2][j])
 				{
 					s = a[r1][i];
 					flag++;	
 				}
 			}
 		}
 		fprintf(fm,"Case #%d: ",t);
 		if(flag==1)
 			fprintf(fm,"%d\n",s);
 		else if(flag==0)
 			fprintf(fm,"Volunteer cheated!\n");
 		else
 			fprintf(fm,"Bad magician!\n");
 		
 		t++;		
 	}
    
    
    fclose(fp);
    fclose(fm);
    return 0;
 }

