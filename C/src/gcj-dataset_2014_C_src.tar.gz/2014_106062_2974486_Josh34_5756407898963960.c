#include <stdio.h>
 
 int temp[4], cards[4], cards2[4];
 int T, g, i, j, k, sol;
 
 int main(){
 	scanf("%d", &T);
 	for(k = 0; k < T; k++){
 		scanf("%d", &g);
 		for(i = 0; i < 4; i++)
 			for(j = 0; j < 4; j++){
 				scanf("%d", &temp[j]);
 				if(g - 1 == i)	
 					cards[j] = temp[j];
 			}
 		scanf("%d", &g);
 		for(i = 0; i < 4; i++)
 			for(j = 0; j < 4; j++){
 				scanf("%d", &temp[j]);
 				if(g - 1 == i)	
 					cards2[j] = temp[j];
 			}
 		g = 0;
 		for(i = 0; i < 4; i++)	
 			for(j = 0; j < 4; j++)
 				if(cards[i] == cards2[j]){
 					g++;
 					sol = cards[i];
 				}
 		if(g == 0) printf("Case #%d: Volunteer cheated!\n", k + 1);
 		if(g > 1) printf("Case #%d: Bad magician!\n", k + 1);
 		if(g == 1) printf("Case #%d: %d\n", k + 1, sol);
 	}
 	return 0;
 }
