#include<stdio.h>
 
 void takein(int*);
 int cmpare(int[], int[]);
 
 int main()
 {
 	int t, a1[4], a2[4], i, j, c;
 
 	j = 1;
 	scanf("%d", &t);
 	c = getchar();
 	while(t--) {
 		takein(a1);
 		takein(a2);
 		i = cmpare(a1, a2);
 		if(i == 25)
 			printf("Case #%d: Bad magician!\n", j++); 
 		else if(i == 0)
 			printf("Case #%d: Volunteer cheated!\n", j++);
 		else
 			printf("Case #%d: %d\n", j++, i);
 	}
 	return 0; 
 }
 
 void takein(int *p)
 {
 	int ch, c, ch1, i;
 
 	scanf("%d", &ch1);
 	ch = ch1;
 	c = getchar();
 	while(--ch)
 		while((c = getchar()) != '\n');
 	for(i = 0;i < 4;++i)
 		scanf("%d", p++);
 	c = getchar();
 	ch = 5 - ch1;
 	while(--ch)
 		while((c = getchar()) != '\n');
 }
 
 int cmpare(int a1[], int a2[])
 {
 	int i, j, no, val;
 
 	no = 0;
 	for(i = 0;i < 4;++i)
 		for(j = 0;j < 4;++j)
 			if(a1[i] == a2[j]) {
 				++no;
 				if(no > 1)
 					return 25;
 				val = a1[i];
 			}
 	if(!no)
 		return no;
 	return val;
 }

