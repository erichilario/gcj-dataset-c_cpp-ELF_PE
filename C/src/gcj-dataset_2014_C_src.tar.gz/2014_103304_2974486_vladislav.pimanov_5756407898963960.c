#define _CRT_SECURE_NO_WARNINGS
 #include <stdio.h>
 int main(void){
 	FILE* in = fopen("A-small-attempt1.in", "r");
 	FILE* out = fopen("out.txt", "w");
 	int count_of_cases = 0;
 	int row = 0;
 	int j = 1;
 	int tmp = 0;
 	int arr1[4] = { 0 };
 	int arr2[4] = { 0 };
 	fscanf(in, "%d", &count_of_cases);
 	while (j <= count_of_cases){
 		int counter = 0;
 		int number = 0;
 		int i = 0;
 		fscanf(in, "%d", &row);
 		i = (row - 1) * 4;
 		while (i > 0){
 			fscanf(in, "%d", &tmp);
 			i--;
 		}
 		i = 0;
 		while (i < 4){
 			fscanf(in, "%d", &arr1[i]);
 			i++;
 		}
 		i = (4 - row) * 4;
 		while (i > 0){
 			fscanf(in, "%d", &tmp);
 			i--;
 		}
 
 		fscanf(in, "%d", &row);
 		i = (row - 1) * 4;
 		while (i > 0){
 			fscanf(in, "%d", &tmp);
 			i--;
 		}
 		i = 0;
 		while (i < 4){
 			fscanf(in, "%d", &arr2[i]);
 			i++;
 		}
 		i = (4 - row) * 4;
 		while (i > 0){
 			fscanf(in, "%d", &tmp);
 			i--;
 		}
 		{
 			int i = 0;
 			int j = 0;
 			while (i < 4){
 				j = 0;
 				while (j < 4){
 					if (arr1[i] == arr2[j]){
 						counter++;
 						number = arr1[i];
 						break;
 					}
 					j++;
 				}
 				i++;
 			}
 		}
 		if (!counter){
 			fprintf(out, "Case #%d: Volunteer cheated!", j);
 		}
 		else if (1 == counter){
 			fprintf(out, "Case #%d: %d", j, number);
 		}
 		else{
 			fprintf(out, "Case #%d: Bad magician!", j);
 		}
 		fprintf(out, "\n");
 		j++;
 	}
 	return 0;
 }
