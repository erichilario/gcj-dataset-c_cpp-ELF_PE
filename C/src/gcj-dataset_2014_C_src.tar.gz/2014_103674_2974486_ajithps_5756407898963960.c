#include<stdio.h>
 int answer;
 int possible[16];
 int matrix[4][4];
 void getmatrix()
 {
     int i,j;
     for(i=0;i<4;i++)
     {
         for(j=0;j<4;j++)
         {
             scanf("%d",&matrix[i][j]);
         }
     }
 }
 void process()
 {
     int i;
     for(i=0;i<4;i++)
     {
         possible[matrix[answer-1][i]-1]=1;
     }
 }
 void process2()
 {
     int i,j;
     for(i=0;i<4;i++)
     {
         if(i==answer-1)
         continue;
 
         for(j=0;j<4;j++)
         {
             possible[matrix[i][j]-1]=0;
         }
     }
 }
 void init()
 {
     int i;
     for(i=0;i<16;i++)
     {
         possible[i]=0;
     }
 }
 int getans()
 {
     int i,j,ans;
     j=0;
     for(i=0;i<16;i++)
     {
        if(possible[i]==1)
        {
            if(j!=1)
            {
                j=1;
                ans=i+1;
            }
            else
            {
                return -1;
            }
        }
     }
     if(j==0)
     {
         return -2;
     }
     else
     return ans;
 }
 int main()
 {
     int T,i,r;
     scanf("%d",&T);
     for(i=1;i<=T;i++)
     {
         init();
         scanf("%d",&answer);
         getmatrix();
         process();
         scanf("%d",&answer);
         getmatrix();
         process2();
         r=getans();
 
         if(r==-1)
         {
             printf("Case #%d: Bad magician!\n",i);
         }
         else if(r==-2)
         {
             printf("Case #%d: Volunteer cheated!\n",i);
         }
         else
         {
             printf("Case #%d: %d\n",i,r);
         }
 
     }
     return 0;
 }

