#include <stdio.h>
 #ifdef D
 #define print_line() printf("%d\n",__LINE__)
 #define print_int(a) printf("%d\n",a)
 #define print_float(a) printf("%.7f\n",a)
 #define print_char(a) printf("%c\n",a)
 #else
 #define print_line()
 #define print_int(a)
 #define print_float(a)
 #define print_char(a)
 #endif
 
 void bsort(double *, int);
 int main()
 {
 	int t,T,N, i,j,fair_score, cheat_score;
 	double ken[1000], naomi[1000];
 	scanf("%d\n",&T);
 	print_int(T);
 	for (t=1;t<=T;t++)
 	{
 		scanf("%d",&N);
 		print_int(N);
 		for(i=0;i<N; i++)
 		{
 			scanf("%lf",&naomi[i]);
 		}
 		bsort(naomi,N);
 		for(i=0;i<N; i++)
 		{
 			scanf("%lf",&ken[i]);
 		}
 		bsort(ken,N);
 #ifdef D		
 		for (i=0;i<N; i++)
 			printf("%.5lf ",naomi[i]);
 		printf("\n");
 		for (i=0;i<N; i++)
 			printf("%.5lf ",ken[i]);
 		printf("\n");
 #endif
 		fair_score=cheat_score=0;
 		i=j=0;
 		while (i<N && j<N)
 		{
 			while (naomi[i] < ken[j] && i<N)
 			{
 				i++;
 				cheat_score++;
 			}
 			i++; j++;
 		}
 		cheat_score=N-cheat_score;
 		i=j=0;
 		while (i<N && j<N)
 		{
 			while(naomi[i] > ken[j] && j<N)
 			{
 				j++;
 				fair_score++;
 			}
 			i++; j++;
 		}
 		printf("Case #%d: %d %d\n",t,cheat_score,fair_score);
 	}
 	return 0;
 }
 
 void bsort(double *A, int n)
 {
 	int i, nN;
 	double tmp;
 	do
 	{
 		nN=0;
 		for (i=1; i<n; i++)
 			if (A[i-1] > A[i])
 			{
 				tmp = A[i-1];
 				A[i-1]= A[i];
 				A[i] = tmp;
 				nN=i;
 			}
 		n=nN;
 	} while(n);
 }
