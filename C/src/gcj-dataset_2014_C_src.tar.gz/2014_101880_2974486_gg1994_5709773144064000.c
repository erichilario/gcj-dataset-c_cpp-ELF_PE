#include <stdio.h>
 
 int main ()
 {
     int t;
     scanf("%d", &t);
     int j = 0;
     while (t--) {
         j++;
         double c, f, x;
         scanf("%lf%lf%lf", &c, &f, &x);
 //        printf("%f\n%f\n%f\n", c, f, x);
         double cnt = 0;
         while (1) {
 //            printf("lhs  %f\n", x / (2 + (cnt + 1) * f));
 //            printf("rhs  %f\n",(x - c) / (2 + (cnt) * f));
             if (x / (2 + (cnt + 1) * f)  < (x - c) / (2 + (cnt) * f)) {
                 cnt = cnt + 1.0;
 //                printf("im here\n");
             } else {
                 break;
             }
         }
 //        printf("cnt = %f\n", cnt);
         double time = 0;
         int i;
         for (i = 0; i < cnt; ++i) {
             time += c / (2 + i * f);
 //            printf("time = %f\n", time);
         }
         time += x /  (2 + cnt * f);
         printf("case #%d: %.7lf\n", j, time);
     }
     return 0;
 }

