//
 //  main.c
 //  cj_magician
 //
 //  Created by Hoyoon on 2014. 4. 13..
 //  Copyright (c) 2014년 SNU. All rights reserved.
 //
 
 #include <stdio.h>
 #include <stdlib.h>
 
 void calculate(FILE *fp, int caseno)
 {
     int grid[2][4][4], ans[2];
     for(int k =0; k < 2; k++) {
         fscanf(fp, "%d", &ans[k]);
         for(int i = 0; i < 4; i++) {
             for(int j = 0; j < 4; j++) {
                 fscanf(fp, "%d", &grid[k][i][j]);
             }
         }
     }
     int sw = 0, result = -1;
  //   printf("ans 1 : %d ans 2 : %d\n", ans[0], ans[1]);
     for(int i = 0; i < 4; i++) {
         for(int j = 0; j < 4; j++) {
             if(grid[0][ans[0]-1][i] == grid[1][ans[1]-1][j]) {
                 if(sw == 0) {
                     sw = 1;
                     result = grid[0][ans[0]-1][i];
 //                    printf("%d %d %d\n", i, j, result);
                 } else {
                     sw++;
                     result = -1;
                     break;
                 }
             }
         }
     }
     printf("Case #%d: ", caseno+1);
     switch(sw) {
         case 0:
             printf("Volunteer cheated!\n");
             break;
         case 1:
             printf("%d\n", result);
             break;
         default:
             printf("Bad magician!\n");
             break;
     }
 }
 
 int main(int argc, const char * argv[])
 {
 
     // insert code here...
     FILE *fp;
     int ctest = 0;
     fp = fopen("input", "r");
     if(!fp || fscanf(fp, "%d", &ctest) == EOF) {
         printf("wrong input file \n");
         exit(-1);
     }
     for(int i = 0; i < ctest; i++) {
         calculate(fp, i);
     }
 }
 

