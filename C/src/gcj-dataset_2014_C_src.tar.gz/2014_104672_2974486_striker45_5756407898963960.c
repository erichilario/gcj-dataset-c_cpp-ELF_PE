#include<stdio.h>
 
 int main()
 {
 	int T,testcase=0;
 	scanf("%d",&T);
 	while(testcase != T)
 	{
 		int index1,index2,i,j,count=0,temp;
 		scanf("%d",&index1);
 		int a[4][4]={0},b[4][4]={0};
 		
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 				scanf("%d",&a[i][j]);
 		}
 		
 		scanf("%d",&index2);
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 				scanf("%d",&b[i][j]);
 		}
 		
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				if(a[index1-1][i] == b[index2-1][j])
 				{
 					temp=a[index1-1][i];
 					count++;	
 				}
 			}
 		}
 		
 		testcase++;
 		printf("Case #%d: ",testcase);
 		if(count == 0)
 			printf("Volunteer cheated!\n");
 		else if(count > 1)
 			printf("Bad magician!\n");
 		else if(count == 1)
 			printf("%d\n",temp);
 		
 		//testcase++;
 	}
 	return 0;
 }

