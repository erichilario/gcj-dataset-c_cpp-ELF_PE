#include <stdio.h>
 
 int main(){
 	int t,k,i;
 	double c,f,x,ans,rate,temp;
 
 	scanf("%d",&t);
 
 	for(i = 1;i<=t;i++){
 		ans = 0.0;
 		rate = 2.0;
 		
 		scanf("%lf %lf %lf",&c,&f,&x);
 
 		while(1){
 
 			if((x/rate) <= (c/rate + x/(rate+f))){
 				ans += (x/rate);
 				break;
 			}
 			else{
 				ans += (c/rate);
 				rate += f;
 			}
 		}
 
 		printf("Case #%d: %.10f\n",i,ans);
 	}
 	return 0;
 }
