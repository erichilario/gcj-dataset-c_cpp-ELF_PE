#include<stdio.h>
 
 int main()
 {
 	int T, i, j, found;
 	double C, F, X, t, t1, t2, t3;
 	scanf("%d", &T);
 	for(i=1; i<=T; i++)
 	{
 		scanf("%lf %lf %lf", &C, &F, &X);
 		found=0, j=0;		
 		t = 0.0, t1 = 0.0, t2 = 0.0, t3 = 0.0;
 		while(found==0)
 		{
 			t1 = X/(2+j*F);
 			t2 = C/(2+j*F);
 			t3 = X/(2+(j+1)*F);
 			if(t1<(t2+t3))
 			{
 				t = t+t1;
 				printf("Case #%d: %.7lf\n", i, t);
 				found = 1;
 			}
 			t = t+t2;
 			j++;			
 		}
 	}
 	return 0;
 }

