#include <stdio.h>
 
 #define MAX_LINE_BUFFER 1024
 #define ERROR_BAD (-1)
 #define ERROR_CHEAT (-2)
 
 int compare(int* first, int* second);
 
 int main(int argc, char* argv[]) {
     FILE *ifile;
     FILE *ofile;
     char* filename = NULL;
     char* outfile = "output.txt";
     char linebuffer[MAX_LINE_BUFFER];
 
     int count;
     int selected[2];
     int grid[2][4][4] = { };
     int i, j, k, ret;
     
     if (argc != 2) {
         printf("usage: problem_a input.txt\n");
         return 1;
     }
 
     filename = argv[1];
     printf("filename: %s\n", filename);
 
     ifile = (FILE *) fopen(filename, "r");
     ofile = (FILE *) fopen(outfile, "w");
 
     fscanf(ifile, "%d", &count);
     for (i=0; i<count; i++) {
         for (j=0; j<2; j++) {
             fscanf(ifile, "%d", &selected[j]);
             for (k=0; k<4; k++) {
                 fscanf(ifile, "%d %d %d %d", &grid[j][k][0], &grid[j][k][1],
                         &grid[j][k][2], &grid[j][k][3]);
             }
         }
 
         ret = compare(grid[0][selected[0]-1], grid[1][selected[1]-1]);
         if (ret == ERROR_CHEAT) {
             fprintf(ofile, "Case #%d: Volunteer cheated!\n", i+1);
         } else if (ret == ERROR_BAD) {
             fprintf(ofile, "Case #%d: Bad magician!\n", i+1);
         } else {
             fprintf(ofile, "Case #%d: %d\n", i+1, ret);
         }
     }
 
     fclose(ifile);
     fclose(ofile);
 
     return 0;
 }
 
 int compare(int first[], int second[]) {
     int i, j;
     int found = -1;
 
     for (i=0; i<4; i++) {
         for (j=0; j<4; j++) {
             if (first[i] == second[j]) {
                 if (found == -1) {
                     found = first[i];
                 } else {
                     return ERROR_BAD;
                 }
             }
         }
     }
     
     return (found != -1) ? found : ERROR_CHEAT;
 }

