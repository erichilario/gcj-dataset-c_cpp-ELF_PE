#include <stdio.h>
 #include <stdlib.h>
 
 //Constants
 
 #define T_MAX 50
 #define N_MAX 10
 
 int answer[T_MAX][2];
 double Ken[N_MAX], Naomi[N_MAX], dKen[N_MAX], dNaomi[N_MAX];
 
 int war(int N) {
 	double chn=0, chk=0;
 	int n, indiceNaomi=0, indiceKen=0, b=0;
 
 	//printf("War !");
 
 	for (n=0; n<N; n++){
 		if(Naomi[n]>chn){
 			chn = Naomi[n];
 			indiceNaomi = n;
 		}
 	}
 	Naomi[indiceNaomi] = 0;
 	//printf("Naomi said : %f \n", chn);
 
 	for (n=0; n<N; n++){
 		if( (Ken[n]>chn) && (chk<Ken[n])){
 			chk = Ken[n];
 			indiceKen = n;
 			b=1;
 		}
 	}
 	//printf("Ken said : %f \n", chk);
 	if(b == 0){
 		for (n=0; n<N; n++){
 			if(Ken[n]!= 0){
 				if(chk == 0){
 					chk = Ken[n];
 					indiceKen = n;
 				}
 				else {
 					if(chk>Ken[n]) {
 						chk = Ken[n];
 						indiceKen = n;
 					}
 				}
 			}
 		}
 	}
 	Ken[indiceKen] = 0;
 	//printf("Ken said : %f \n", chk);
 	
 	if(chn>chk){
 		//printf("Naomi win \n");
 		return 1;
 	}
 	else{
 		//printf("Naomi lose \n");
 		return 0;
 	}
 	//return 1;
 }
 
 int deceithfulWar(int N) {
 	double chn=0, tln=0, chk=0;
 	int n, indiceNaomi=0, indiceKen=0, b=0;
 
 	//printf("deceithfulWar !\n");
 
 	for (n=0; n<N; n++){		
 		// On cherche le max de Ken pour annonce au dessus et le faire jouer son min
 		if(dKen[n]>tln){
 			tln = dKen[n];
 			tln = tln + 0.000001;
 		}
 
 		// On cherche le min de Ken car on sait que c'est ce qu'il va jouer
 		if(((dKen[n]<chk) || (chk == 0)) && (dKen[n]!=0)){
 			chk = dKen[n];
 			indiceKen = n;
 		}
 	}
 
 	for (n=0; n<N; n++){
 		if((dNaomi[n]>chk) && ((dNaomi[n]<chn) || (chn == 0))){
 			chn = dNaomi[n];
 			indiceNaomi = n;
 			b = 1;
 		}
 	}	
 	if(b == 0){
 		for (n=0; n<N; n++){		
 			// Si on trouve pas on balance le min de Naomi
 			if(((dNaomi[n]<chn) || (chn == 0)) && (dNaomi[n]!=0)){
 				chn = dNaomi[n];
 				tln = chn;
 				indiceNaomi = n;
 			}
 		}
 	}
 
 	//printf("Naomi said %.6f but she chose %f\n", tln, chn);
 	//printf("Ken chose %f\n", chk);
 
 	dNaomi[indiceNaomi] = 0;
 	dKen[indiceKen] = 0;
 
 	if(chn>chk){
 		//printf("Naomi win \n");
 		return 1;
 	}
 	else{
 		//printf("Naomi lose \n");
 		return 0;
 	}
 	
 	
 	//return 1;	
 }
 
 int main(){
 	int T, t;
 	int N,n;
 	int y=0,z=0;
 	double tmp;
 
 	scanf("%d", &T);
 	for(t = 0; t < T; t++){
 		//Reinitialisation
 		y=0; z=0;
 		
 		// On recupere le nombre de block
 		scanf("%d", &N);
 		// On recupere les poids des blocks
 		for (n=0; n<N;n++){
 			scanf("%lf", &tmp);
 			Naomi[n] = tmp;
 			dNaomi[n] = tmp;
 		}
 		for (n=0; n<N; n++){
 			scanf("%lf", &tmp);
 			Ken[n] = tmp;
 			dKen[n] = tmp;
 		}
 
 
 		for (n=0; n<N; n++){
 			y = y + war(N);
 			z = z + deceithfulWar(N);
 		}
 
 		answer[t][0] = z;
 		answer[t][1] = y;
 	}
 
 	for(t = 0; t < T; t++) {
 		printf("Case #%d: %d %d \n", t+1, answer[t][0], answer[t][1]);
 		/*for (n=0; n<N; n++){
 			printf("%lf\n", dKen[n]);
 			printf("%lf\n", dNaomi[n]);
 		}*/
 	}
 
     return 0;
 }
 

