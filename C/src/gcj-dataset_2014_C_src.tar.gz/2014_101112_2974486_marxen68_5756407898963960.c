#include <stdio.h>
 
 int result = 0;
 
 int intersect(int a[], int b[]) {
   int i = 0, j = 0;
   int value = 0;
   result = 0;
   while(i < 4) {
     j = 0;
     while(j < 4) {
       if(a[i] == b[j]) {
         result++;
         value = a[i];
       }
       j++;
     }
     i++;
   }
   return value;
 }
 
 void solve(int n_case) {
   int q1, q2, i;
   int a[4][4], b[4][4];
   fscanf(stdin, "%d", &q1);
   //fprintf(stdout, "%d\n", q1);
   for(i = 0; i < 4; i++) {
     fscanf(stdin, "%d %d %d %d", &a[i][0], &a[i][1], &a[i][2], &a[i][3]);
   }
   fscanf(stdin, "%d", &q2);
   for(i = 0; i < 4; i++) fscanf(stdin, "%d %d %d %d", &b[i][0], &b[i][1], &b[i][2], &b[i][3]);
   if(q1 < 1 || q2 < 1 || q1 > 4 || q2 > 4) {
     fprintf(stdout, "Case #%d: Volunteer cheated!\n", n_case);
     return;
   }
   int ret = intersect(a[q1-1], b[q2-1]);
   switch(result) {
     case 1:
     fprintf(stdout, "Case #%d: %d\n", n_case, ret);
     break;
     case 0:
     fprintf(stdout, "Case #%d: Volunteer cheated!\n", n_case);
     break;
     default:
     fprintf(stdout, "Case #%d: Bad magician!\n", n_case);
     break;
   }
 
   return;
 }
 
 int main(void) {
   int T, n_case = 1;
   fscanf(stdin, "%d", &T);
   while(T>0) {
     solve(n_case++);
     T--;
   }
 
   return(0);
 }

