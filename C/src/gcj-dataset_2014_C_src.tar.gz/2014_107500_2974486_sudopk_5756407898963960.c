#include<stdio.h>
 #include<stdint.h>
 #include<math.h>
 #include<string.h>
 #include<stdlib.h>
 
 int main()
 {
 	int a[4][4];
 	int b[4][4];
 	int c[4];
 	int ans1,ans2;
 	int t,count,i,j,k=1;
 	scanf("%d",&t);
 	while(t--)
 	{
 		scanf("%d",&ans1);
 		for(i=0;i<4;i++)
 			for(j=0;j<4;j++)
 				scanf("%d",&a[i][j]);
 		scanf("%d",&ans2);
 		for(i=0;i<4;i++)
 			for(j=0;j<4;j++)
 				scanf("%d",&b[i][j]);
 		count=0;
 		for(i=0;i<4;i++)
 			for(j=0;j<4;j++)
 				if(a[ans1-1][i]==b[ans2-1][j])
 				{
 					c[count]=a[ans1-1][i];
 					count++;
 				}
 
 		if(count==1)
 		{
 			printf("Case #%d: %d\n",k,c[0]);
 		}
 		else if(count==0)
 		{
 			printf("Case #%d: Volunteer cheated!\n",k);
 
 
 		}
 		else
 		{
 			printf("Case #%d: Bad magician!\n",k);
 		}
 		k++;
 	}
 
 	return 0;
 }

