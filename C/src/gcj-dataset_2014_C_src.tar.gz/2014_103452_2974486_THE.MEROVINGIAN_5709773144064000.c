#include<stdio.h>
 void main(){
 FILE *in_file=fopen("B-large.in","r");
 FILE *out_file=fopen("Data.txt","w");
 int t;
 double c,f,x,time,n;
 fscanf(in_file,"%d",&t);
 int i=1;
 while(i<=t){
         time=0;n=0.0;
     fscanf(in_file,"%lf %lf %lf",&c,&f,&x);
     while((x/(2+n*f))>((c/(2+n*f))+(x/(2+(n+1)*f)))){
 
 
         time+=(c/(2+n*f));
         n++;
         }
        // printf("%f\n",time);
     time+=(x/(2+n*f));
     fprintf(out_file,"Case #%d: %.7lf\n",i,time);
     i++;
 }}
 

