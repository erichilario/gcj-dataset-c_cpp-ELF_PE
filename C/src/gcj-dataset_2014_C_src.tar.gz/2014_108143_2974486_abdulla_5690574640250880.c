#include<stdio.h>
 #include<stdlib.h>
 
 
 
 
 typedef struct
 {
 int row,col;
 }offset;
 
 typedef struct
 {
 int row,col;
 }check;
 
 
 void fill(char a[51][51],int b[51][51],int r,int c, int rf, int cf,check q[],int val,offset dir[]){
 int back=0,front=0;
     q[back].row=r;
     q[back].col=c;
     back++;
 
 int row=rf;
 int col=cf;
 int nrow,ncol,k=0;
 int count=0;
 
  
 
   while(count<val) //(row<r &&col<c))
   {
     
 
     while(k<8)
       {
          nrow=row+dir[k].row;
          ncol=col+dir[k].col;
 
             if(((nrow>=0 && nrow<r) && (ncol>=0 && ncol<c)))
              {
                 
                    if(b[nrow][ncol]==0)
                       {   
                           b[nrow][ncol]=1;
                           a[nrow][ncol]='.';
                           count++;
                           q[back].row=nrow;
                           q[back].col=ncol;
                           back++;
                           if(count>=val)
                           goto here;
                       }
                
              }
             k++;
        
      }
     k=0;
     front++;
     row=q[front].row;
     col=q[front].col;
    }
 
 here:
 for(row=0;row<r;row++)
 for(col=0;col<c;col++)
 if(b[row][col]==0)
 a[row][col]='*';
 }
 
 
 
 int main()
 {
 
 offset dir[8]={{-1,0},{0,-1},{1,0},{0,1},{-1,-1},{1,-1},{1,1},{-1,1}};
 check q[100];
 int flag=1;
 int testcase,p,r,c,m,val,x,i,j,dummy,rf,cf;
 char a[51][51];
 int b[51][51]={0};
 
 
 FILE *fin, *fout;
 fin=fopen("C-small-attempt2.in","r");
 fout=fopen("C-small-attempt2.txt","w");
 
 
 fscanf(fin,"%d",&testcase);
 
 for(p=0;p<testcase;p++)
 {
 flag=1;
 
 fscanf(fin,"%d",&r);
 fscanf(fin,"%d",&c);
 fscanf(fin,"%d",&m);
 
 for(i=0;i<r;i++)
 for(j=0;j<c;j++)
 b[i][j]=0;
 
 val=r*c-m;
 
 
 
 if(val>=9){
 dummy=r*c;
 x=rand()%dummy;
 rf=r/2; cf=c/2;
 
 a[rf][cf]='c';
 b[rf][cf]=1; 
 fill(a,b,r,c,rf,cf,q,val-1,dir);
 
 }
 
 
 else if(val>=6){
 x=rand()%r;
 rf=r/2;  cf=0;
 a[rf][cf]='c';
 b[rf][cf]=1; 
 fill(a,b,r,c,rf,cf,q,val-1,dir);
 }
 
 else if(val>=4){
 rf=r-1;  cf=c-1;
 a[rf][cf]='c';
 b[rf][cf]=1; 
 fill(a,b,r,c,rf,cf,q,val-1,dir);
 }
 
 else if(val>=2){
 if(r==1 || c==1){
 rf=0; cf=0;
 a[rf][cf]='c';
 b[rf][cf]=1; 
 fill(a,b,r,c,rf,cf,q,val-1,dir);}
 
 else
 flag=0;
 }
 
 else
 flag=0;
 
 if(flag==0)
 fprintf(fout,"case #%d:\nImpossible\n",p+1);
 else{
 fprintf(fout,"case #%d:\n",p+1);
 
 for(i=0;i<r;i++){
 for(j=0;j<c;j++)
 fprintf(fout,"%c",a[i][j]);
 fprintf(fout,"\n");
 }
 
 
 
 }
 
 
 }
 fclose(fin);
 fclose(fout);
 
 return 0;
 }

