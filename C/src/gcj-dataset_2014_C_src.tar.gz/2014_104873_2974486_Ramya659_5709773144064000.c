#include<stdio.h>
 #include<stdlib.h>
 #include<conio.h>
 double sec(double,double,double,int);
 void main()
 {
 	int n,i,z,t,cookie;
 	double t1,t2,c,f,x,res;
 	FILE*fp,*fp1;
 	fp=fopen("cookie ip.txt","r");
 	fp1=fopen("cookie op.txt","w");
 	fscanf(fp,"%d",&n);
 	for(i=0;i<n;i++)
 	{
 		z=1;
 		t=1;
 		cookie=2;
 		fscanf(fp,"%lf",&c);
 		fscanf(fp,"%lf",&f);
 		fscanf(fp,"%lf",&x);
 		t1=x/cookie;
 		while(z)
 		{
 			res=sec(c,f,x,t);
 			if(t1<res)
 			{
 				fprintf(fp1,"Case #%d: %lf\n",i+1,t1);
 				z=0;
 			}
 			t1=res;
 			t++;
 		}
 	}
 	fclose(fp1);
 	fclose(fp);
 	getch();
 }
 double sec(double c,double f,double x,int t)
 {
 	double t2=0,res,cookie=2;
 	int i;
 	for(i=0;i<t;i++)
 	{
 		t2=t2+(c/cookie);
 		cookie=cookie+f;
 	}
 	res=(x/cookie)+t2;
 	return res;
 }

