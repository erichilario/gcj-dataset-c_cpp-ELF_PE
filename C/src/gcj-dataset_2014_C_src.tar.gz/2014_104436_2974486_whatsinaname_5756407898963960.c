#include<stdio.h>
 #define DEBUG if(0)
 int main()
 {
     int T,i,j=1,flag,x1,x2,x3,x4,r,ro,flag2;
     int a[16];
     scanf("%d",&T);
     while(T--)
     {
         for(i=0;i<16;i++)
         {
             a[i]=0;
         }
         scanf("%d",&r);
         for(i=0;i<4;i++)
         {
             scanf("%d %d %d %d",&x1,&x2,&x3,&x4);
             if(r==i+1)
             {
                 a[x1-1]=1;
                 a[x2-1]=1;
                 a[x3-1]=1;
                 a[x4-1]=1;
             }
         }
         scanf("%d",&r);
         flag=0;
         flag2=0;
         printf("Case #%d: ",j++);
 
         for(i=0;i<4;i++)
         {
             scanf("%d %d %d %d",&x1,&x2,&x3,&x4);
             if(r==i+1)
             {
                 if(a[x1-1]==1){flag2=(flag==1)?1:0;flag=1;ro=x1;}
                 if(a[x2-1]==1){flag2=(flag==1)?1:0;flag=1;ro=x2;}
                 if(a[x3-1]==1){flag2=(flag==1)?1:0;flag=1;ro=x3;}
                 if(a[x4-1]==1){flag2=(flag==1)?1:0;flag=1;ro=x4;}
             }
         }
         DEBUG
         {
             for(i=0;i<16;i++)
             {
                 printf("\n%d = %d",i+1,a[i]);
             }
         }
         if(flag2==1)printf("Bad magician!");
         else if(flag==0)printf("Volunteer cheated!");
         else printf("%d",ro);
         if(T!=0)printf("\n");
 
     }
 
         return 0;
 }

