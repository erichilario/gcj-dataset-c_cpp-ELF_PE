#include<stdio.h>
 
 void merge(double a[],int l, int m, int u){
 	int i=l,j=m+1,k=l;
 	double b[1000];
 	while(i<=m && j<=u){
 		if(a[i]<a[j]){
 			b[k++]=a[i++];
 		}
 		else
 			b[k++]=a[j++];
 	}
 	while(i<=m){
 		b[k++]=a[i++];
 	}
 	while(j<=u){
 		b[k++]=a[j++];
 	}
 	for(i=l;i<=u;i++){
 		a[i]=b[i];
 	}
 }
 
 void msort(double a[], int l, int u){
 	int m;
 	if(l<u){
 		m=(u+l)/2;
 		msort(a,l,m);
 		msort(a,m+1,u);
 		merge(a,l,m,u);
 	}
 }
 
 int main(){
 	int T,N,t,i,j,y,z,cnt1;
 	scanf("%d",&T);
 	for(t=1;t<=T;t++){
 		cnt1=0;
 		scanf("%d",&N);
 		double a[N],b[N];
 		for(i=0;i<N;i++){
 			scanf("%lf",&a[i]);
 		}
 		for(i=0;i<N;i++){
 			scanf("%lf",&b[i]);
 		}
 		msort(a,0,N-1);
 		msort(b,0,N-1);
 		for(i=0;i<N;i++){
 			if(a[i]<b[0]){
 				cnt1++;
 			}
 			else
 				break;
 		}	
 		y=N-cnt1;
 		i=0;
 		j=0;
 		while(i<N && j<N){
 			if(j==N-1){
 				if(a[i] < b[j]){
 					i++;
 					break;
 				}
 				else{
 					break;
 				}
 			}
 
 			if(a[i]<b[j]){
 				i++;
 			}
 			else
 				j++;
 						
 		}
 		if(i==N){
 			z=0;
 		}
 		else 
 			z=N-i;
 		printf("Case #%d: %d %d\n",t,y,z);
 	}
 	return 0;
 }
 		

