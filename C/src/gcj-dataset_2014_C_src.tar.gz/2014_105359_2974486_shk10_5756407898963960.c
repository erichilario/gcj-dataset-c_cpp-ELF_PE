#include<stdio.h>
 
 int main()
 {
 	int caseNo,totalCases;
 	scanf("%d",&totalCases);
 	for(caseNo=1; caseNo<=totalCases; caseNo++)
 	{
 		printf("Case #%d: ",caseNo);
 		int f[17]={0},row,i,j,k;
 		for(k=1;k<=2;k++)
 		{
 			scanf("%d",&row);
 			for(i=1;i<=4;i++) for(j=1;j<=4;j++)
 			{
 				int v; scanf("%d",&v);
 				if(i==row) f[v]++;
 			}
 		}
 		int res,count=0;
 		for(i=1;i<=16;i++) if(f[i]==2) { count++; res=i; }
 		if(count==0) printf("Volunteer cheated!");
 		else if(count==1) printf("%d",res);
 		else printf("Bad magician!");
 		if(caseNo!=totalCases) printf("\n");
 	}
 	return 0;
 }
