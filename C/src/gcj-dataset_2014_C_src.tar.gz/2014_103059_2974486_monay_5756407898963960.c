#include <stdio.h>
 
 int main()
 {
     FILE *fin;
     FILE *fout;
     fin = fopen("in.txt","r");
     fout = fopen("out.txt","w");
     int first,second,n,i,j,k,x,truth=0,number;
     int matrix[5][5];
     int matrix2[5][5];
     fscanf(fin,"%d",&n);
     for(k=1; k<=n; k++)
     {
         fscanf(fin,"%d",&first);
         for(i=1; i<=4; i++)
         {
             for(j=1; j<=4; j++)
             {
                 fscanf(fin,"%d",&matrix[i][j]);
             }
         }
         fscanf(fin,"%d",&second);
         for(i=1; i<=4; i++)
         {
             for(j=1; j<=4; j++)
             {
                 fscanf(fin,"%d",&matrix2[i][j]);
             }
         }
         truth=0;
         for(j=1;j<=4;j++)
         {
             for(x=1;x<=4;x++)
             {
                 if(matrix[first][j]==matrix2[second][x])
                     {
                         truth++;
                         number=matrix[first][j];
                     }
             }
         }
         if(truth==1)fprintf(fout,"Case #%d: %d\n",k,number);
         if(truth>1)fprintf(fout,"Case #%d: Bad Magician!\n",k);
         if(truth==0)fprintf(fout,"Case #%d: Volunteer cheated!\n",k);
     }
     fclose(fin);
     fclose(fout);
 }

