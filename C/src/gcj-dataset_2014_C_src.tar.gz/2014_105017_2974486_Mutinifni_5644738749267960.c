#include<stdio.h>
 
 int main()
 {
 int t,a,b,c,war,dwar,i;
 scanf("%d", &t);
 int n[t];
 float p1[t][10], p2[t][10], m;
 for(a=0; a<t; a++)
 {
 	scanf("%d", &n[a]);
 	for(b=0; b<n[a]; b++)
 		scanf("%f", &p1[a][b]);
  	for(b=0; b<n[a]; b++)
 		scanf("%f", &p2[a][b]);
 }
 for(a=0; a<t;)
 {
 	//sort p1
 	for(b=0; b<n[a]; b++)
 	{
 		m=p1[a][b];
 		for(c=b+1; c<n[a]; c++)
 			if(m<p1[a][c])
 			{
 				m=p1[a][c];
 				i=c;
 			}
 		if(m==p1[a][b])
 			continue;
 		p1[a][i]=p1[a][b];
 		p1[a][b]=m;
 	}
 
 	//sort p2
 	for(b=0; b<n[a]; b++)
 	{
 		m=p2[a][b];
 		for(c=b+1; c<n[a]; c++)
 			if(m<p2[a][c])
 			{
 				m=p2[a][c];
 				i=c;
 			}
 		if(m==p2[a][b])
 			continue;
 		p2[a][i]=p2[a][b];
 		p2[a][b]=m;
 	}
 		
 	for(c=0, war=0, b=0; b<n[a]; b++)
 	{
 		if(p1[a][b]>p2[a][c])
 			war++;
 		else c++;
 	}
 
 	for(c=0, dwar=0, b=0; b<n[a]; b++)
 		if(p1[a][c]>p2[a][b])
 		{
 			dwar++;
 			c++;
 		}
 	
 	printf("Case #%d: %d %d\n", ++a, dwar, war);
 	}
 return 0;
 }
