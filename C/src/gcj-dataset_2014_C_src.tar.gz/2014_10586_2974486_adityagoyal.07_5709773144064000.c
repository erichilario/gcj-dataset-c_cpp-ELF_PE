#include<stdio.h>
 #include<stdlib.h>
 int main(){
     int t,z;
     double initial,c,i,j,time,f,x,t1,t2,t3;
     FILE *fp;
     fp = fopen ("jam2.out", "a");
 
     scanf("%d",&t);
     for(z = 1; z <=t; z++) {
                initial = 2;
                time=0;
                scanf("%lf%lf%lf",&c,&f,&x);
                if(x<=c){
                        fprintf(fp,"Case #%d: %0.7lf\n",z, x/initial);
                        }
                else{
                     while((1.0*x)/initial > (1.0*c)/initial + (1.0*x)/(initial+f) ){
                                           i= 1.0*(c/initial);
                                           time= time+i;
                                           initial += f;
                                           }
                     time = time + (1.0*x)/initial;
                     fprintf(fp,"Case #%d: %0.7lf\n",z,time);
                }
     }
     fclose(fp);
     return 0;
 }

