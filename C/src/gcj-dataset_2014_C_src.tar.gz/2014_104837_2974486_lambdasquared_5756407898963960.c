#include<stdio.h>
 
 int A1[4][4], A2[4][4];
 int r1, r2, row1=0, row2=0;
 
 int main()
 {
 	int T=0, i, j, k, flag, card;
 	scanf("%d", &T);
 	for(i=1; i<=T; i++)
 	{
 		scanf("%d", &r1);
 		row1 = r1-1; //adjusting for 0
 		for(j=0; j<4; j++)
 		{
 			for(k=0; k<4; k++)
 				scanf("%d", &A1[j][k]);
 		}
 		scanf("%d", &r2);
 		row2 = r2-1; //adjusting for 0
 		for(j=0; j<4; j++)
 		{
 			for(k=0; k<4; k++)
 				scanf("%d", &A2[j][k]);
 		}
 		flag = 0;
         for(j=0 ; j<4; j++)
         {
             for(k=0; k<4; k++)
             {
                 if(A1[row1][j] == A2[row2][k])
                 {
                     flag++;
                     card = A1[row1][j];
                 }
             }
             
         }
 
         if(flag==0)
             printf("Case #%d: Volunteer cheated!\n",i);
         if(flag==1)
             printf("Case #%d: %d\n", i,card);
         if(flag>1)
             printf("Case #%d: Bad magician!\n",i);
     }
 	return 0;
 }

