#include <stdio.h>
 
 #define N 4
 
 int main(int argc, char *argv[])
 {
 	FILE* in = fopen(argv[1], "r+");
 	FILE* out = fopen("out", "w+");
 	int T;
 	fscanf(in, "%d", &T);
 	int row1, row2;
 	int cards1[N][N];
 	int cards2[N][N];
 	for(int t = 1; t <= T; t++)
 	{
 		fscanf(in, "%d", &row1);
 		for(int i = 0; i < N; i++)
 		{
 			for(int j = 0; j < N; j++)
 			{
 				fscanf(in, "%d", &cards1[i][j]);
 			}
 		}
 		fscanf(in, "%d", &row2); 
 		for(int i = 0; i < N; i++)
 		{
 			for(int j = 0; j < N; j++)
 			{
 				fscanf(in, "%d", &cards2[i][j]);
 			}
 		}
 		int nb = 0;
 		int match = 0;
 		for(int i = 0; i < N; i++)
 		{
 			for(int j = 0; j < N; j++)
 			{
 				if(cards1[row1-1][i] == cards2[row2-1][j])
 				{
 					nb = cards1[row1-1][i];
 					match++;
 				}
 			}
 		}
 		if(match == 0)
 			fprintf(out, "Case #%d: Volunteer cheated!\n", t);
 		else if(match == 1)
 			fprintf(out, "Case #%d: %d\n", t, nb);
 		else
 			fprintf(out, "Case #%d: Bad magician!\n", t);
 	}
 }
 

