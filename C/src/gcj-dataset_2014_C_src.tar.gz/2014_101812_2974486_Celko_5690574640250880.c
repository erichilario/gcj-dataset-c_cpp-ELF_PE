#include <stdio.h>
 #include <stdlib.h>
 
 int toplel[1000][7];
 
 int ceiling(int a, int b){
 	if (a%b == 0) return a/b;
 	else return (a/b +1);
 }
 
 void possible(int r, int c, int m, int t){
 	
 	toplel[t][2] = r;
 	toplel[t][3] = c;
 	toplel[t][4] = m;
 	toplel[t][5] = r;
 	toplel[t][6] = c;
 
 	//Cas spécial non réducible où une des dim est 1:
 	if(c == 1){
 		toplel[t][0] = 1;
 		toplel[t][1] = 0;
 		return;
 	}
 	if(r == 1){
 		toplel[t][0] = 1;
 		toplel[t][1] = 1;
 		return;		
 	}	
 	
 	//Réduction
 	while (((m >= r) || (m >= c)) && (r>2) && (c>2)) {
 		
 		if ((m > r) && (c>2)){
 			m -= r;
 			c--;		
 		}else{
 			m -= c;
 			r--;
 		}
 
 	}
 	
 	toplel[t][5] = r;
 	toplel[t][6] = c;
 	
 	//Si on est arrivé à une matrice 2xc ou rx2 c'est trivial
 	if((c == 2) || (r == 2)){
 	
 		//Soit il n'y a qu'une seule case non minée.
 		if (m == (r*c -1)){
 			toplel[t][0] = 1;
 			toplel[t][1] = 0;
 			return;
 		}
 	
 		//Sinon si m est impair ou si m est égal à c*r-2
 		if ((m%2 == 1) || (m == (c*r-2))){
 			toplel[t][0] = 0;
 			return;
 		}
 		
 		//Sinon si c'est possible selon l'orientation
 		if (c == 2){
 			toplel[t][0] = 1;
 			toplel[t][1] = 1;
 			return;
 		}else{
 			toplel[t][0] = 1;
 			toplel[t][1] = 0;
 			return;
 		}
 	}
 	
 	//Sinon m < r et m < c
 	//Si possible de compléter un row ou une colonne sans rien toucher
 	
 	if (m < (r-1)){
 		toplel[t][0] = 1;
 		toplel[t][1] = 0;
 		return;
 	}else if (m < (c-1)){
 		toplel[t][0] = 1;
 		toplel[t][1] = 1;
 		return;
 	}
 	
 	//Sinon on est dans un cas où m = r-1 et m = c-1
 	//Peut etre possibilité de compléter en triangle si un des côtés est supérieur à 3
 	if ((c > 3) || (r > 3)){
 		toplel[t][0] = 1;
 		toplel[t][1] = 2;
 		return;
 	}else{
 		toplel[t][0] = 0;
 		return;
 	}
 	
 	
 }
 
 void affichage(char tmp[50][50], int t, int r, int c){
 	int i, j;
 	
 	printf("Case #%d:\n", t);
 	for (i = 0; i < r; i++){
 		for(j = 0; j < c; j++){
 			if (tmp[i][j] == 'c' || tmp[i][j] == '.') printf("%c", tmp[i][j]);
 			else printf("*");
 		}
 		printf("\n");
 	}
 }
 
 
 int main(){
 
 	int row, column, mine;
 	int T, i;
 	char tmp[50][50];
 	int currentT = 1;
 	int new;
 	
 	scanf("%d", &T);
 	
 	do{
 		//Read input
 		scanf("%d %d %d", &row, &column, &mine);
 
 		//Test possibilité
 		possible(row, column, mine, currentT);
 		
 		currentT++;
 		
 	}while (currentT <= T);
 	
 	for (i = 1; i <= T; i++){
 		if (toplel[i][0] == 0) printf("Case #%d:\nImpossible\n", i);
 		else{
 			
 			//Reinit du tableau
 			int top, kek;
 
 				for (top = 0; top < toplel[i][2]; top++){
 					for(kek = 0; kek < toplel[i][3]; kek++){
 						tmp[top][kek] = 'a';
 					}
 				}
 				
 			//CAS COLUMN
 			if (toplel[i][1] == 1){
 				int j = 0, k = 0;
 				int m = toplel[i][2]*toplel[i][3]-toplel[i][4];
 				while(m > 0){
 					if (j == 0 && k == 0) tmp[j][k] = 'c';
 					else tmp[j][k] = '.';
 					m--;
 					new = (k+1)%toplel[i][6];
 					if (new < k) j++;
 					k = new;
 				}
 				affichage(tmp, i, toplel[i][2], toplel[i][3]);
 			}
 			
 			//CAS ROW
 			if (toplel[i][1] == 0){
 				int j = 0, k = 0;
 				int m = toplel[i][2]*toplel[i][3]-toplel[i][4];
 				while(m > 0){
 					if (j == 0 && k == 0) tmp[j][k] = 'c';
 					else tmp[j][k] = '.';
 					m--;
 					new = (j+1)%toplel[i][5];
 					if (new < j) k++;
 					j = new;
 				}
 				affichage(tmp, i, toplel[i][2], toplel[i][3]);
 			}
 			
 			//Cas Triangle
 			if (toplel[i][1] == 2){
 				int j = 0, k = 0;
 				int m = toplel[i][2]*toplel[i][3]-toplel[i][4];
 				int tri = 1;
 				while(m>0){
 					for (j=0; j < toplel[i][5]; j++){
 						for(k=0; k< toplel[i][6]; k++){
 							if (j == 0 && k == 0) {tmp[j][k] = 'c'; if(m == toplel[i][2]*toplel[i][3]-toplel[i][4])m--;}
 							else if(tmp[j][k] == '.'){}
 							else if((j+k) < tri) {tmp[j][k] = '.'; m--; if(m == 0) break;}
 						}
 						if (m ==0) break;
 					}
 					tri++;
 				}
 				affichage(tmp, i, toplel[i][2], toplel[i][3]);
 			}
 			
 
 		}
 	}
 	
 
 
 	return 0;
 }

