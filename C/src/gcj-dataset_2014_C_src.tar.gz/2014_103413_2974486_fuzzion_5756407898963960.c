#include <stdio.h>
 
 unsigned int ttt[2][4][4];
 
 int main(void) {
   unsigned casen=1,t,l,c;
   int rc;
   unsigned a[2];
 
   //  char X, O, D, T, DD;
   //  int Xwon, Owon; 
  
   // get num cases
   scanf("%u\n",&t);
 
   while(t--) { 
 	unsigned sol=0;
 	unsigned match=0;
 	unsigned ac;
 	for(ac=0; ac <= 1; ac++) {
 	  // get answer
 	  scanf("%u\n", &a[ac]);
     
 	  for(l=0; l<4; l++) {
 		for (c=0; c<4; c++) {
 		  rc=scanf("%u", &ttt[ac][l][c]);
 		  if ((rc == 0) || (rc == EOF)) {
 			printf("scanf error!\n");
 			break;
 		  }
 		}
 	  }
 	}
 
 	printf("Case #%u: ", casen++);
 
 	for(l=0; l<4; l++) {
 	  for (c=0; c<4; c++) {
 		if (ttt[0][a[0]-1][c] == ttt[1][a[1]-1][l]) {
 		  match++;
 		  sol=ttt[0][a[0]-1][c];
 		}
 	  }
 	}
 
 
 	if (match == 1) printf("%u\n", sol); 
 	else if (match > 0) printf("Bad magician!\n"); 
 	else printf("Volunteer cheated!\n");
   }
   return 0;
 }

