#include<stdio.h>
 
 int main()
 {
 	int t,l=1;
 	int n1,n2,i,j;
 	int arr1[5][5],arr2[5][5];
 	scanf("%d",&t);
 	while(l<=t)
 	{
 		scanf("%d",&n1);
 		for(i=0;i<4;i++)
 			for(j=0;j<4;j++)
 				scanf("%d",&arr1[i][j]);
 		
 		scanf("%d",&n2);
 		for(i=0;i<4;i++)
 			for(j=0;j<4;j++)
 				scanf("%d",&arr2[i][j]);
 		
 		int count=0;
 		int ans;
 		for(i=0;i<4;i++)
 			for(j=0;j<4;j++)
 				if(arr1[n1-1][i] == arr2[n2-1][j])
 				{
 					ans = arr1[n1-1][i];
 					count++;
 				}
 		if(count==1)
 			printf("Case #%d: %d\n",l,ans);
 		else if(count>1)
 			printf("Case #%d: Bad magician!\n",l);
 		else
 			printf("Case #%d: Volunteer cheated!\n",l);
 		l++;
 	}
 	return 0;
 }

