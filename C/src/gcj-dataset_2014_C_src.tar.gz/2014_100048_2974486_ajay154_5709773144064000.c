// @AUTHOR ajay yadav//
 #include<stdio.h>
 int main()
 {
 int t,z=1;
 double c,f,x,time_taken,cookie_rate;
 scanf("%d",&t);
 while(z<=t)
 {
     printf("Case #%d: ",z);
     scanf("%lf %lf %lf",&c,&f,&x);
     cookie_rate=2.0;
     time_taken=(double)c/cookie_rate;
     for( ; ((x-c)/cookie_rate)>(x/(f+cookie_rate)); )
     {
         cookie_rate+=f;
         time_taken+=(c/cookie_rate);
     }
     printf("%.9lf\n",time_taken+(x-c)/cookie_rate);
     z++;
 }
 return 0;
 }

