#include<stdio.h>
 int main()
 {
 	int i,t;
     float c,f,x,y=0,z=0,a=0,b=0,q=0,temp=0;
 
 	scanf("%d",&t);
 	for(i=0;i<t;i++)
 	{
 
 		scanf("%f %f %f",&c,&f,&x);
 		while(1)
 	{
 		y=c/(2.0+q);
 		z=x/(2.0+q);
         b=a+z;
 		a=a+y;
 		if(b>temp&&temp!=0)
 		{
 			printf("Case #%d: %.7f\n",i+1,temp);
 			break;
 		}
 		temp=b;
 		q=q+f;
 
 	}
 
 		temp=0;
 		q=0;
 		a=0;
 		b=0;
 		y=0;
 		z=0;
 
 	}
 	return 0;
 }
 
  
