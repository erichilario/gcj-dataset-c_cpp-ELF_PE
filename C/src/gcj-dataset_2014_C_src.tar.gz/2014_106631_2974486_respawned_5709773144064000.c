#include <stdio.h>
 
 #define RATE 2.f
 
 int main()
 {
 	int t, it = 1, k;
 	double C, F, X, time, t_time;
 	scanf("%d", &t);
 	while (t > 0) {
 		scanf("%lf %lf %lf", &C, &F, &X);
 		k = 0;
 		t_time = X/RATE;
 		do {
 			time = t_time;
 			t_time += ((C - X)*F + C * (2 + k*F))/((RATE +  k*F)*(RATE + (k + 1)*F));
 			k++;
 		} while (t_time < time);
 		printf("Case #%d: %.7f\n", it, time);
 		it++; t--;
 	}
 	return 0;
 }

