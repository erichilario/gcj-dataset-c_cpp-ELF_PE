#include<stdio.h>
 
 void main()
 {
     FILE *fin,*fout;
     fin=fopen("cookies.txt","r");
     fout = fopen("cookies.out","w");
     int n,i;
     double C,F,X,generationRate,elapsedTime;
     fscanf(fin,"%d",&n);
 
     for(i=1;i<=n;i++)
     {
 
         fscanf(fin,"%lf%lf%lf",&C,&F,&X);
         generationRate = 2;
         elapsedTime =0;
         while (1)
             {
 
                 if(X/generationRate < C/generationRate)
                 {
                     elapsedTime += X/generationRate;
                     break;
                 }
                 else
                 {
                     elapsedTime += C/generationRate;
                 }
                 if((X-C)/generationRate < X/(generationRate + F))
                 {
                     elapsedTime += (X-C)/generationRate;
                     break;
                 }
                 else
                 {
                     generationRate += F;
                 }
 
             }
             fprintf(fout,"Case #%d: %.7lf\n",i,elapsedTime);
     }
     fclose(fin);
     fclose(fout);
 
 }

