#include <stdio.h>
 void solution1(long long int ,long long int );
 void solution2(long long int ,long long int ,long long int );
 
 void solution1(long long int r,long long int c)
 {
 	long long int index1,index2;
 	for(index1=0;index1<r;index1++)
 	{
 		for (index2=0;index2<c;index2++)
 		{
 			if(index2==c-1 && index1==r-1)
 			{
 				printf("c");
 			}
 			else
 			{
 				printf("*");
 			}
 		}
 		printf("\n");
 	}
 }
 
 void solution2(long long int r,long long int c,long long int m)
 {
 	long long int index1,index2;
 		for(index1=0;index1<r;index1++)
 		{
 			for (index2=0;index2<c;index2++)
 			{
 				if(m>0 && !((index1==r-1 && index2==c-2)  || (index1==r-2 && index2==c-1) || (index1==r-2 && index2==c-2) ))
 				{
 					printf("*");
 					m--;
 				}
 				else if(index1==r-1 && index2==c-1)
 				{
 					printf("c");
 				}
 				else
 				{
 					printf(".");
 				}
 			}
 			printf("\n");
 		}
 	
 }
 
 int main()
 {
 	long long int test_case,index1,r,c,m;
 	scanf("%lld",&test_case);
 	for(index1=0;index1<test_case;index1++)
 	{
 		printf("Case #%lld:\n",index1+1);
 		scanf("%lld %lld %lld",&r,&c,&m);
 		if(r>1 && c>1)
 		{
 			if(r*c-m==2 || r*c-m==3 || r*c-m==0)
 			{
 				printf("Impossible\n");
 			}
 			else
 			{
 				if(r*c-m==1)
 				{
 					solution1(r,c);
 				}
 				else
 				{
 					solution2(r,c,m);
 				}
 			}
 		}
 		else if((int)(r==1) + (int)(c==1) ==1)
 		{
 			if(r*c-m==1)
 			{
 				solution1(r,c);
 			}
 			else if(r*c-m>1)
 			{
 				solution2(r,c,m);
 			}
 			else
 			{
 				printf("Impossible\n");
 			}
 		}
 		else
 		{
 			if(m!=0)
 			{
 				printf("Impossible\n");
 			}
 			else
 			{
 				printf("c\n");
 			}
 		}
 	}
 	return 0;
 }
