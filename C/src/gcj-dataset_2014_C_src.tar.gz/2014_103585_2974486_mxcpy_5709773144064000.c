#include <stdio.h>
 
 void solve(double C, double F, double X)
 {
     /*
     double ans = 0;
     double sum = 0;
     double v = 2;
     double t;
     while (sum < X)
     {
         t = C / v;
         sum += C;
         printf("time cost : %lf\n", t);
         ans += t;
         v += F;
         printf("v : %lf\n", v);
     }
     */
     double ans = 1 << 30;
     double sum = 0, v = 2, t;
     int i, j;
     for (i = 0; i <= 10000000; ++ i)
     {
         if (sum + X / v < ans)
         {
             ans = sum + X / v;
         }
         t = C / v;
         sum += t;
         v += F;
     }   
     printf("%.7lf\n", ans);
 }
 
 int main()
 {
     int T, i;
     double C, F, X;
     freopen("input", "r", stdin);
     freopen("output", "w", stdout);
     scanf("%d", &T);
     for (i = 1; i <= T; ++ i)
     {
         printf("Case #%d: ", i);
         scanf("%lf%lf%lf", &C, &F, &X);
         solve(C, F, X);
     }
     fclose(stdin);
     fclose(stdout);
     return 0;
 }
 

