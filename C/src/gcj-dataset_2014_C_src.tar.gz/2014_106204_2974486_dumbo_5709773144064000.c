#include <stdio.h>
 #include <math.h>
 
 main()
 {
   double C, F, X;
   int T;
   double TimeX[100];
 
   const double epsilon = 0.000001;
 
   int i;
 
   printf("Input\n\n");
   
   readT:
     scanf("%d", &T);
   // Sanity check
     if((T < 1) || (T > 100)) {
       printf("Invalid test cases count. Limit 1<=T<=100\n");
       goto readT;
     }
 
   // For each test case
   for(i = 0; i < T; i++) {
     double gainRate = 2.0;
     double timeX = 0.0;
     double newtimeX = 0.0;
 
     double timeC = 0.0;
 
     int loop = 1;
     // Read the values
     scanf("%lf %lf %lf", &C, &F, &X);
     timeX = X/2;
     
     while(loop) {
       timeC = timeC + C/gainRate;
       newtimeX = timeC + X/(gainRate+F);
       //printf("timeX=%f timeC=%f gainRate=%f newtimeX=%f\n", timeX, timeC, gainRate, newtimeX);
       if((timeX-newtimeX) <= epsilon) {
         TimeX[i] = timeX;
         loop = 0;
       } else {
         timeX = newtimeX;
         gainRate = gainRate + F;
       //  printf("gainRate=%f timeX=%f\n", gainRate, timeX);
       }
     }
   }
   
   // Output
   printf("\n\n");
   for(i = 0; i < T; i++) {
     printf("Case #%0d: %f\n", i+1, TimeX[i]);
   }
 }

