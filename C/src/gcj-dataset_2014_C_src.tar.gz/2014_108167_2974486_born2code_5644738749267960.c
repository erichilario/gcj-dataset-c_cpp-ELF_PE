#include<stdio.h>
 #include<stdlib.h>
 
 void quicksort(float x[1001],float first,float last)
 {   int pivot, j,i;
    float temp;
 
 if(first<last){
          pivot=first;
          i=first;
          j=last;
 
 
          while(i<j){
              while(x[i]<=x[pivot]&&i<last)
                  i++;
              while(x[j]>x[pivot])
                  j--;
              if(i<j){
                  temp=x[i];
                   x[i]=x[j];
                   x[j]=temp;
              }
          }
 
          temp=x[pivot];
          x[pivot]=x[j];
          x[j]=temp;
          quicksort(x,first,j-1);
          quicksort(x,j+1,last);
     }
 }
 
 void fair(float A[1000],float B[1000],int n)
 {
 	int i,j,k,wins=0;
 	int h=n-1,l=0;
 	for( i = n-1; i>=0;i--)
 	{	if(A[i] > B[h])
 		{	l++;
 			wins++;
 		}
 		else
 		{	h--;
 		}			
 	}
 	printf("%d\n",wins);
 }
 
 void unfair(float A[1000],float B[1000], int n)
 {	int ha,hb,la,lb,k=0,i;
 	int wins =0;
 	ha=hb=n-1; la=lb=0;
 	/*while(k<n && A[la] < B[lb])
 	{	k++;
 		la++;
 		hb--;
 	}
 	while(k<n)
 	{
 		if(A[ha] > B[hb])
 		{	wins++;
 			ha--;
 			lb++;
 			k++;
 		}
 		if(A[ha] < B[hb])
 		{	A[ha-1] = A[ha];
 			ha--;
 			hb--;
 			k++;
 		}
 	}*/
 	for( i = 0 ; i < n ; i++)
 	{	if(A[i] >B[lb])
 		{	wins++;
 			lb++;
 		}
 		if(A[i] < B[lb])
 		{	hb--;
 		}
 	}
 	printf("%d ",wins);
 	
 }
 int main()
 {	
 	int t,T,n,i,j,k,l;
 	float A[1001],B[1001];
 	
 	scanf("%d",&T);
 	for(t=1;t<=T;t++)
 	{
 		scanf("%d",&n);
 		for(i=0;i<n;i++)
 		{	scanf("%f",&A[i]);
 		}
 		for(i=0;i<n;i++)
 		{	scanf("%f",&B[i]);
 		}
 		quicksort(A,0,n-1);
 		quicksort(B,0,n-1);
 		
 		printf("Case #%d: ",t);
 		/*
 		for(i=0;i<n;i++)
 		{	printf("%f\t%f\n",A[i],B[i]);
 		}*/
 		unfair(A,B,n);
 		fair(A,B,n);
 		
 	}
 	return 0;
 }

