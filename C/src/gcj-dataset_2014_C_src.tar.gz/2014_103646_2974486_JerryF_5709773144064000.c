/*
   Problem B. Cookie Clicker Alpha
 
   Can buy a farm every C cookies.
   But if you do, you'll never save up to reach goal, so at some point
   need to stop buying farms and let production accumulate.
 */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 int main (int argc, char *argv[])
 {
     FILE *fin = NULL;
     FILE *fout = NULL;
     int n_test_cases = 0;
     int i_test;
 
     double cost_per_farm = 0.0;
     double farm_production_rate = 0.0;  // C
     double goal = 0.0;                  // F
     const double base_rate = 2.0;       // X
     double total_time = 0.0;
     int   number_of_farms;
     double time_to_goal, next_time_to_goal, time_to_farm;
 
     int done = 0;
 
 
 
     if (argc<2) {
         printf("provide input file name\n");
         return 1;
     }
 
     fin = fopen(argv[1],"r");
     fscanf(fin, "%d", &n_test_cases);
 
     fout = fopen("output.txt","w");
 
     for (i_test = 1; i_test <= n_test_cases; i_test++) {
 
         fscanf(fin, "%lf %lf %lf", &cost_per_farm, &farm_production_rate, &goal);
 
         total_time = 0.0;
         number_of_farms = 0;
 
         done = 0;
         while (!done) {
 
             /* How long to goal at current production rate */
             time_to_goal = goal / (base_rate + number_of_farms * farm_production_rate);
 
             /* How long to goal if we buy another farm */
             time_to_farm = cost_per_farm / (base_rate + number_of_farms * farm_production_rate);
             next_time_to_goal = time_to_farm +
                 goal / (base_rate + (number_of_farms+1) * farm_production_rate);
 
             if (time_to_goal <= next_time_to_goal) {
               /* Quicker to just wait */
               total_time = total_time + time_to_goal;
               done = 1;
             } else {
               /* Quicker to buy another farm */
               number_of_farms = number_of_farms + 1;
               total_time = total_time + time_to_farm;
             }
 
         }
 
         fprintf(fout, "Case #%d: %.7f\n", i_test, total_time);
 
     }  /* i_test */
 
 	fclose(fin);
 	fclose(fout);
 	return 0;
 }

