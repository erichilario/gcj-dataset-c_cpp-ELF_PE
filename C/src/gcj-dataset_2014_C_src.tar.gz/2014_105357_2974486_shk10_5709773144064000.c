#include<stdio.h>
 #define EPS (1e-9)
 
 double solve(double C, double F, double X)
 {
 	double time=0, cookie=0, curRate=2;
 	while(cookie<X-EPS)
 	{
 		double time1=(X-cookie)/curRate, time2=(C/curRate)+((X-cookie)/(curRate+F));
 		if(time1<time2+EPS)
 		{
 			time += time1;
 			cookie = X;
 		}
 		else
 		{
 			time += C/curRate;
 			curRate += F;
 		}
 	}
 	return time;
 }
 
 int main()
 {
 	int caseNo,totalCases;
 	scanf("%d",&totalCases);
 	for(caseNo=1; caseNo<=totalCases; caseNo++)
 	{
 		printf("Case #%d: ",caseNo);
 		double C,F,X;
 		scanf("%lf%lf%lf",&C,&F,&X);
 		printf("%.7f",solve(C,F,X));
 		if(caseNo!=totalCases) printf("\n");
 	}
 	return 0;
 }
