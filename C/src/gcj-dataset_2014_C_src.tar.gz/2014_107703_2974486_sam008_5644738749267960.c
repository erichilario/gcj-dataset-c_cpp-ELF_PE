// Codejam4.cpp : Defines the entry point for the console application.
 //
 
 //#include "stdafx.h"
 #include"stdio.h"
 #include"stdlib.h"
 
 int quick_sort(double *arr, int first, int last)
 {
 	int i, j, pivot;
 	double temp;
 		if (first < last)
 		{
 			pivot = first;
 			i = first;
 			j = last;
 			while (i<j)
 			{
 				while (arr[i]<= arr[pivot] && i<last)
 					i++;
 				while (arr[j] > arr[pivot])
 					j--;
 				if (i<j)
 				{
 					temp = arr[i];
 					arr[i] = arr[j];
 					arr[j] = temp;
 				}
 			}
 			temp = arr[pivot];
 			arr[pivot] = arr[j];
 			arr[j] = temp;
 			arr[pivot];
 			quick_sort(arr, first, j - 1);
 			quick_sort(arr, j + 1, last);
 		}
 		return 0;
 }
 int findResult(double *N, double *K,int size)
 {
 	int result=0,i,j;
 	for (i = 0; i<size;)
 	{
 		for (j = 0; j < size&&i<size;)
 		{
 			if (N[i]>K[j])
 			{
 				result++;
 				i++;
 				j++;
 			}
 			else
 			{
 				i++;
 			}
 		}
 	}
 	return result;
 }
 int main(int argc, char* argv[])
 {
 	FILE *fin, *fout;
 	int noOfCases, currentCase = 1,noOfBlocks;
 	int deceitfulResult, actualResult,i;
 	double N[1000], K[1000];
 	fin=fopen("D-large.in", "rb");
 
 	if (fin == NULL)
 		printf("null");
 	fscanf(fin, "%d", &noOfCases);
 	while (noOfCases)
 	{
 		fscanf(fin, "%d", &noOfBlocks);
 		for (i = 0; i < noOfBlocks; i++)
 			fscanf(fin, "%lf", &N[i]);
 		for (i = 0; i < noOfBlocks; i++)
 			fscanf(fin, "%lf", &K[i]);
 		quick_sort(K, 0, noOfBlocks-1);
 		quick_sort(N, 0, noOfBlocks-1);
 		deceitfulResult = findResult(N, K,noOfBlocks);
 		actualResult = findResult(K, N, noOfBlocks);
 		fout=fopen("A-small-output.in", "ab");
 		fprintf(fout, "Case #%d: %d %d\n", currentCase++, deceitfulResult, noOfBlocks-actualResult);
 		fclose(fout);
 		noOfCases--;
 	}
 	return 0;
 }
 
 

