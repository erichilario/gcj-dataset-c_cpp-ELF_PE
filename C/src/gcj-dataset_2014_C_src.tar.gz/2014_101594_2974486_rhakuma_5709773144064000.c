#include <stdio.h>
 
 double compute(double c, double f, double x) {
     int i, j;
     double max_time = x/2;
     double ret_time = max_time;
     double current_time;
     double produce;
     printf("c=%lf, f=%lf, x=%lf\n", c, f, x);
     i = 0;
     while (ret_time <= max_time) {
         produce = 2;
         current_time = 0;
         for (j=0; j<i; j++) {
             current_time += c/produce;
             produce += f;
         }
         current_time += (x/produce);
         //printf("current_time=%lf\n", current_time);
 
         if (ret_time >= current_time) {
             ret_time = current_time;
         } else {
             return ret_time;
         }
         i++;
     }
     return ret_time;
 }
 
 int main(int argc, char* argv[]) {
     FILE *ifile;
     FILE *ofile;
     char* filename = NULL;
     char* outfile = "output.txt";
 
     int i, count;
     double c, f, x, result;
     
     if (argc != 2) {
         printf("usage: problem_a input.txt\n");
         return 1;
     }
 
     filename = argv[1];
     printf("filename: %s\n", filename);
 
     ifile = (FILE *) fopen(filename, "r");
     ofile = (FILE *) fopen(outfile, "w");
 
     fscanf(ifile, "%d", &count);
     for (i=0; i<count; i++) {
         fscanf(ifile, "%lf %lf %lf", &c, &f, &x);
 
         result = compute(c, f, x);
 
         fprintf(ofile, "Case #%d: %lf\n", (i+1), result);
     }
 
     fclose(ifile);
     fclose(ofile);
 
     return 0;
 }
 

