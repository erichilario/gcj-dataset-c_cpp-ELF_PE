#include <stdio.h>
 #include <stdlib.h>
 double max,coins;
 double ipotesi(double bs)
 {
     double time=0.0;
     time=max/bs;
     return time;
 }
 double ipotesi_click(double bs)
 {
     double time=0.0;
     time=(max-coins)/bs;
     return time;
 }
 int main()
 {
     int ciclo=1,casi;
     FILE *in,*out;
     in=fopen("input.in","r");
     out=fopen("output.txt","w");
     fscanf(in,"%d",&casi);
     double fabbrica;//costo della fabbrica
     double resa_f;//resa di una fabbrica
     double bs=2.0;//biscotti al secondo
     double time;
     double time_new_farm,time_std;
     int fatto,i=0;
     double delta;
     double divisione=0.000001;//ogni quanto aumenta il ciclo
     while(ciclo<=casi)
     {
         fatto=0;
         coins=0.0;
         time=0.0;
         bs=2.0;
         fscanf(in,"%lf %lf %lf",&fabbrica,&resa_f,&max);
         while(coins<max)
             {
                 if((ipotesi(bs+resa_f)+((fabbrica-coins)/bs))<ipotesi_click(bs))
                   {
                       time+=(fabbrica-coins)/bs;
 
                       if((fabbrica-coins)<(max-coins))
                       {
                            time+=(fabbrica-coins)/bs;
                            coins+=fabbrica;
                       }
                       else
                        {
                            time+=(max-coins)/bs;
                            coins+=max;
                        }
                   }
                 else
                  {
                      time+=(max-coins)/bs;
                      coins=max;
                  }
             }
         fprintf(out,"Case #%d: %lf\n",ciclo,time);
         ciclo++;
     }
     fclose(in);
     fclose(out);
 
 return 0;
 }

