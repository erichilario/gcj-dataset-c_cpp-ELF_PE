#include<stdio.h>
 
 int printMap(int r, int c, int m, int special);
 FILE *f;
 int main() {
 	int testcase;
 	int i;
 	int m, r, c;
 
 	f = fopen("output.txt", "w");
 
 	scanf("%d", &testcase);
 
 	for (i = 1; i <= testcase; ++i) {
 		scanf("%d %d %d", &r, &c, &m);
 
 		//special case when only 1 space is not mine
 		/*if (r * c - m == 1) {
 			//possible
 			fprintf(f, "Case #%d:\n", i);
 			printMap(r, c, m, 1);
 		}*/
 		//regular case need at least 2*2 at the corner
 		if (r >= 2 && c >= 2) {
 			if ((r * c) - 4 >= m) {
 				//posible
 				fprintf(f, "Case #%d:\n", i);
 				printMap(r, c, m, 0);
 			} else {
 				//impossible
 				fprintf(f, "Case #%d:\nImpossible\n", i);
 			}
 
 		} else if (r >= 2 && c < 2) {
 			if ((r * c) - (2 * c) >= m) {
 				//posible
 				fprintf(f, "Case #%d:\n", i);
 				printMap(r, c, m, 0);
 			} else {
 				//impossible
 				fprintf(f, "Case #%d:\nImpossible\n", i);
 			}
 
 		} else if (r < 2 && c >= 2) {
 			if ((r * c) - (r * 2) >= m) {
 				//posible
 				fprintf(f, "Case #%d:\n", i);
 				printMap(r, c, m, 0);
 			} else {
 				//impossible
 				fprintf(f, "Case #%d:\nImpossible\n", i);
 			}
 
 		} else if (r <= 2 && c <= 2) {
 			if (m == 0) {
 				//possible
 				fprintf(f, "Case #%d:\n", i);
 				printMap(r, c, m, 0);
 			} else {
 				//impossible
 				fprintf(f, "Case #%d:\nImpossible\n", i);
 			}
 		}
 
 	}
 	fclose(f);
 	return 0;
 
 }
 
 int printMap(int r, int c, int m, int special) {
 	int countMine = 0;
 	int i, j, bomb;
 
 	bomb = 0;
 
 	if (special) {
 		for (i = 0; i < r; ++i) {
 			for (j = 0; j < c; ++j) {
 				if (i != r - 1 || j != c - 1)
 					fprintf(f, "*");
 				else
 					fprintf(f, "c");
 			}
 			fprintf(f, "\n");
 		}
 	}
 
 	else {
 
 		for (i = 0; i < r - 2; ++i) {
 			for (j = 0; j < c; ++j) {
 				if (bomb < m) {
 					fprintf(f, "*");
 					bomb++;
 				} else
 					fprintf(f, ".");
 			}
 			fprintf(f, "\n");
 		}
 
 		for (i = r - 2 >= 0 ? r - 2 : 0; i < r; ++i) {
 			for (j = 0; j < c - 2; ++j) {
 
 				if (bomb < m) {
 					fprintf(f, "*");
 					bomb++;
 				} else
 					fprintf(f, ".");
 
 			}
 			for (j = c - 2 >= 0 ? c - 2 : 0; j < c; ++j) {
 
 				if (i != r - 1 || j != c - 1)
 					fprintf(f, ".");
 				else
 					fprintf(f, "c");
 
 			}
 
 			fprintf(f, "\n");
 		}
 
 	}
 }

