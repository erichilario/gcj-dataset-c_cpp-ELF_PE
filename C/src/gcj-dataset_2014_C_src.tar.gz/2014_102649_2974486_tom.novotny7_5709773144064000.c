#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int main()
 {
     int numOfTests;
     double c, f, x;
     long maxIncome;
     long long int numOfFarms;
     double time, time2, time3;
 
     FILE *h, *g;
     h = fopen("input.in", "rw");
     g = fopen("output.out", "w");
 //    h = stdin;
 //    g = stdout;
 
     fscanf(h, "%d", &numOfTests);
 
     for(int i = 1; i <= numOfTests; i++){
         //fscanf(h, "%lf%lf%lf", &c, &f, &x);
         fscanf(h, "%lf %lf %lf", &c, &f, &x);
 //        printf("%f %f %f", c, f, x);
 
         maxIncome = x * f / c;
         if(maxIncome < 2) maxIncome = 2;
         numOfFarms = (maxIncome - 2) / f;
 
         //maxIncome = numOfFarms * f + 2;
 
         time = 0;
         for(int j = 0; j < numOfFarms; j++) time += 1/(2+j*f);
         //time = (tgamma(numOfFarms + 2/f /*+ 1*/) - tgamma(2/f)) / f;
         time *= c;
         time += x/(2+numOfFarms*f);
 
         //fprintf(g, "case #%i: %.7f\n", i, time);
 
         numOfFarms++;
 
         time2 = 0;
         for(int j = 0; j < numOfFarms; j++) time2 += 1/(2+j*f);
         //time = (tgamma(numOfFarms + 2/f /*+ 1*/) - tgamma(2/f)) / f;
         time2 *= c;
         time2 += x/(2+numOfFarms*f);
 
         if(time > time2) time = time2;
 
         numOfFarms -= 2;
         if(numOfFarms < 0) numOfFarms = 0;
 
         time2 = 0;
         for(int j = 0; j < numOfFarms; j++) time2 += 1/(2+j*f);
         //time = (tgamma(numOfFarms + 2/f /*+ 1*/) - tgamma(2/f)) / f;
         time2 *= c;
         time2 += x/(2+numOfFarms*f);
 
         fprintf(g, "case #%i: %.7f\n", i, (time > time2)?time2:time);
 
     }
 
     fclose(h);
     fclose(g);
 
     return 0;
 }

