#include <stdio.h>
 
 int main()
 {
 	int k = 0;
 	int t;
 	scanf("%d", &t);
 	while (t--) {
 		int ans[17] = {0};
 		int i, j;
 		int a[4][4];
 		int r1;
 		scanf("%d", &r1);
 		for (i = 0; i < 4; i++) {
 			for (j = 0; j < 4; ++j) {
 				scanf("%d", &a[i][j]);	
 			}
 		}
 		for (i = 0; i < 4; i++) {
 			ans[a[r1 - 1][i]]++;
 		}
 		int r2;
 		scanf("%d", &r2);
 		for (i = 0; i < 4; i++) {
 			for (j = 0; j < 4; ++j) {
 				scanf("%d", &a[i][j]);	
 			}
 		}
 		for (i = 0; i < 4; i++) {
 			ans[a[r2 - 1][i]]++;
 		}
 		int x, y = 0;
 		for (i = 1; i <= 16; i++) {
 			if (ans[i] == 2) {
 				x = i;
 				y++;
 			}
 		}
 		k++;
 		if (y == 0) {
 			printf("case #%d: Volunteer cheated!\n", k);
 		} else if (y > 1) {
 			printf("case #%d: Bad magician!\n", k);
 		} else {
 			printf("case #%d: %d\n", k, x);
 		}
 		
 	}
 	return 0;
 }

