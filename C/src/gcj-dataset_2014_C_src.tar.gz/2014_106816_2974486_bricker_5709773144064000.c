#include <stdio.h>
 
 int main()
 {
     int round;
     scanf("%d", &round);
     int count = 1;
     while(count <= round)
     {
         double farm_price;
         double farm_plus;
         double goal;
         double time_buy_farm;
         double time_not_buy;
         int total_buy_farm;
         double time;
         int i;
 
         scanf("%lf %lf %lf", &farm_price, &farm_plus, &goal);
         if (goal <= farm_price)
         {
             printf("Case #%d: %.7lf\n", count, goal/2.0);
             count++;
             continue;
         }
         else
         {
             for (i=0; i< (int) (goal/farm_price); i++)
             {
                  time_not_buy = (goal - farm_price)/(2.0 + i * farm_plus);
                  time_buy_farm = (goal) / (2.0 + (i+1) * farm_plus);
                  if (time_not_buy < time_buy_farm)
                  {
                      //printf("From %d stop buying farm\n", i+1);
                      break;
                  }
             }
             total_buy_farm = i;
 
             // Calculate time
             time = 0.0;
             for (i=0; i <= total_buy_farm; i++)
             {
                 if (i == total_buy_farm)
                 {
                     time += goal / (2.0 + farm_plus*i);
                     printf("Case #%d: %.7lf\n", count, time);
                     continue;
                 }
                 time += farm_price / (2.0 + farm_plus * i);
             }
         }
         count++;
     }
     return 0;
 }

