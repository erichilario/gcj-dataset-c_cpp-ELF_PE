#include<stdio.h>
 
 int main()
 {
      freopen("C:\\Users\\ARNAB BANERJEE\\google\\qns.txt","r",stdin);
     freopen("C:\\Users\\ARNAB BANERJEE\\google\\ans1.txt","w",stdout);
     int t;
     scanf("%d",&t);
     int case1=0;
     while(t--)
     {
         case1++;
         double c,f,x;
         scanf("%lf %lf %lf",&c,&f,&x);
         double limit=((((double)x)/c)-1)*f;
         double i=2.0;
         double time=0.0;
         double j;
         if(i>limit)
         {
            time=x/2;
            printf("Case #%d: ",case1);
            printf("%lf\n",time);
         }
         else
         {
          while((i+f)<limit)
          {
            i=i+f;
          }
         //double time=0.0;
          for(j=2;j<=i;j=j+f)
          {
             time=time+(c/j);
             //printf("%lf\n",time);
          }
        // printf("here time=%lf",time);
           double not_buy=i+f;
           time=time+(x/not_buy);
           printf("Case #%d: ",case1);
           printf("%lf\n",time);
           }
     }
     //getch();
     return 0;
 }

