#include<stdio.h>
 int main()
 {
     int T;
     scanf("%d",&T);
     double c,f,x,left,right,total;
     int i;
     for(i=1;i<=T;i++)
     {
         scanf("%lf%lf%lf",&c,&f,&x);
         double b=2;
         double count=0;
         if(x<c)
         {
             double temp=x/b;
             printf("Case #%d: %0.7lf\n",i,temp);
         }
         else
         {
             count=x/b;
             left=0;
             while(1)
             {
                      left+=c/b;
                     b+=f;
                     double right=x/b;
 
                     double total=left+right;
                     if(total<count)
                     {
                         count=total;
                     }
                     else
                         break;
             }
             printf("Case #%d: %0.7lf\n",i,count);
         }
     }
     return 0;
 }

