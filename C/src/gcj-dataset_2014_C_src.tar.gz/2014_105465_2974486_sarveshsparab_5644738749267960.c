#include<stdio.h>
 #include<stdlib.h>
 void sortarr(float [],int);
 int truegame(float [],float [],int);
 int fakegame(float [],float [],int);
 main()
 {
    int t,n,i,k,truewar,fakewar;
    float a[10],b[10];
    FILE *fp,*fpo;
    fp=fopen("w.in","r");
    fpo=fopen("output.txt","w");
    fscanf(fp,"%d",&t);
    for(k=0;k<t;k++)
    {
        fscanf(fp,"%d",&n);
        for(i=0;i<n;i++)
        {
            fscanf(fp,"%f",&a[i]);
        }
        for(i=0;i<n;i++)
        {
            fscanf(fp,"%f",&b[i]);
        }
        sortarr(a,n);
        sortarr(b,n);
        fakewar=fakegame(a,b,n);
        truewar=truegame(a,b,n);
        fprintf(fpo,"Case #%d: %d %d\n",k+1,fakewar,truewar);
    }
    fclose(fpo);
    fclose(fp);
 }
 void sortarr(float arr[],int n)
 {
     int c,d,done=0;
     float temp;
     for (c = 0 ; c < ( n - 1 ) && !done; c++)
     {
         done=1;
         for (d = 0 ; d < n - c - 1; d++)
         {
             if (arr[d] > arr[d+1])
             {
                 temp=arr[d];
                 arr[d]=arr[d+1];
                 arr[d+1]=temp;
                 done=0;
             }
         }
     }
 }
 int truegame(float a[],float b[],int n)
 {
     int lost=0,i,j,k,done,len=n;
     for(i=0;i<len;i++)
     {
         done=0;
         for(j=0;j<n && !done;j++)
         {
             if(a[i]<b[j])
             {
                 lost++;
                 done=1;
                 for(k=j;k<n-1;k++)
                 {
                     b[k]=b[k+1];
                 }
                 b[k]='\0';
                 n--;
             }
         }
     }
     return(len-lost);
 }
 int fakegame(float a[],float b[],int n)
 {
     int minInA=0,i=0,amt=0,j=0;
     while(a[i]<b[0] && i<n)
     {
         minInA++;
         i++;
     }
     while(a[i]>b[j] && i<n)
     {
         amt++;
         i++;
         j++;
     }
     return(amt);
 }

