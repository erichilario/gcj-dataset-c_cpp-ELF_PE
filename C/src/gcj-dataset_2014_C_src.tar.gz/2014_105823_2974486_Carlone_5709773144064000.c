#include <stdio.h>
 #include <math.h>
 
 int main(int argc, char *argv[])
 {
 	FILE* in = fopen(argv[1], "r+");
 	FILE* out = fopen("out", "w+");
 	int T;
 	fscanf(in, "%d", &T);
 	for(int t = 1; t <= T; t++)
 	{
 		double C, F, X;
 		fscanf(in, "%lf%lf%lf", &C, &F, &X);
 		double k = (double)X/C - 2.0/F - 1.0;
 		if(k < 0.0)
 			k = 0.0;
 		int times = ceil(k);
 		double re = 0.0;
 		for(int i = 0; i < times; i++)
 		{
 			re += (double)C/(2+i*F);
 		}
 		re += (double)X/(2+times*F);
 		fprintf(out, "Case #%d: %.7lf\n", t, re);
 	}
 }	

