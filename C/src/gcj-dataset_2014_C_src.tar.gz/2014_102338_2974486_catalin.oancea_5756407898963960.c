#include <stdio.h>
 #define MaxN 100
 
 int intersectie(int a[MaxN], int b[MaxN])
 {
 	int k=0, nr=0, i, j;
 	for(i=1; i<=4; i++)
 	{
 		for(j=1; j<=4; j++)
 			if(a[i]==b[j]){
 				nr++;
 				k=a[i];
 				if(nr>1)
 					return -2;
 				break;
 			}
 
 	}
 	if(nr==0)
 		return -1;
 	return k;
 }
 int main()
 {
 	FILE *f, *g;
 	f = fopen("fisier.in", "r");
 	g = fopen("fisier.out", "w");
 	int t, guess1, guess2, something, X;
 	int i, j, row;
 	int a[MaxN], b[MaxN];
 
 	fscanf(f, "%d", &t);
 	for(i=1; i<=t; i++){
 		fprintf(g, "Case #%d: ", i );
 		fscanf(f, "%d", &guess1);
 		for(row=1; row<=4; row++)
 		{
 			if(row == guess1)
 				for(j=1; j<=4; j++)
 					fscanf(f, "%d", &a[j]);
 			else
 				for(j=1; j<=4; j++)
 					fscanf(f, "%d", &something);//useless
 		}
 		fscanf(f, "%d", &guess2);
 		for(row=1; row<=4; row++)
 		{
 			if(row == guess2)
 				for(j=1; j<=4; j++)
 					fscanf(f, "%d", &b[j]);
 			else
 				for(j=1; j<=4; j++)
 					fscanf(f, "%d", &something);//useless
 		}
 		X = intersectie(a,b);
 		if(X==-2)
 			fprintf(g, "Bad magician!\n");
 		else if(X==-1)
 			fprintf(g, "Volunteer cheated!\n");
 		else
 			fprintf(g, "%d\n", X);
 	}
 
 }
