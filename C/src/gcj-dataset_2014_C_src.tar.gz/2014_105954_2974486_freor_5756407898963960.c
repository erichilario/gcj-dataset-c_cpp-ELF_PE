#include <stdio.h>
 
 int main(){
 	
 	FILE* fp1=fopen("A-small-attempt4.in","r");
 	FILE* fp2=fopen("A-small-attempt4.out","w");
 
 	int T;
 	int cas=1;
 	fscanf(fp1,"%d",&T);
 	while(T--){
 		int a,b, i,j;
 		int num=0;
 		int result;
 		int arr1[4][4];
 		int arr2[4][4];
 		fscanf(fp1,"%d",&a);
 		for(i=0;i<4;i++)
 			fscanf(fp1,"%d%d%d%d",&arr1[i][0],&arr1[i][1],&arr1[i][2],&arr1[i][3]);
 		fscanf(fp1,"%d",&b);
 		for(i=0;i<4;i++)
 			fscanf(fp1,"%d%d%d%d",&arr2[i][0],&arr2[i][1],&arr2[i][2],&arr2[i][3]);
 
 		for(i=0;i<4;i++){
 			for(j=0;j<4;j++){
 				if(arr1[a-1][i]==arr2[b-1][j]){
 					num++;
 					result=arr1[a-1][i];
 				}
 			}
 		}
 		fprintf(fp2,"Case #%d: ",cas++);
 		if(num==0)
 			fprintf(fp2,"Volunteer cheated!\n");
 		else if(num==1)
 			fprintf(fp2,"%d\n",result);
 		else if(num>1)
 			fprintf(fp2,"Bad magician!\n");				
 	}
 	fclose(fp1);
 	fclose(fp2);
 	return 0;
 }
