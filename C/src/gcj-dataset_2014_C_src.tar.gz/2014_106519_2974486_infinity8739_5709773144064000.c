#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, char *argv[])
 {
      int tcasenum;
 
      double waktu_jika_beli,waktu_jika_tunggu,waktu_capai_c,waktu_total;
      
      int tcaseloop;
      
      int factory_num;
      
      double C, F, X;
      
      
      FILE *fin,*fout;
   fin=fopen("data.in","r");
   fout=fopen("data.out","w");
 
   fscanf(fin,"%d",&tcasenum);
   
   for(tcaseloop=0;tcaseloop<tcasenum;tcaseloop++)
   {
      fscanf(fin,"%lf %lf %lf",&C,&F,&X);
      
      factory_num=0;
      
      if (C >= X)
      {
         fprintf(fout,"Case #%d: %.7lf\n",tcaseloop+1,X/((double)2+F*(float)factory_num));
         continue;
      }   
      
      waktu_total=0;
      
      while(1)
      {
        waktu_capai_c=C/((float)2+F*(float)factory_num);
        
        waktu_total+=waktu_capai_c;
        
        waktu_jika_tunggu=(X-C)/((double)2+F*(double)factory_num);
        waktu_jika_beli=X/((double)2+F*(double)(factory_num+1));
        
        if (waktu_jika_tunggu<waktu_jika_beli)
        {
           waktu_total+=waktu_jika_tunggu;
           break;                 
        } 
        else
        {
            factory_num++;
        }
        
        
      }
      
      fprintf(fout,"Case #%d: %.7lf\n",tcaseloop+1,waktu_total);
               
      
   }
 
   
   
   fclose(fin);
   fclose(fout);
    
   return 0;
 }

