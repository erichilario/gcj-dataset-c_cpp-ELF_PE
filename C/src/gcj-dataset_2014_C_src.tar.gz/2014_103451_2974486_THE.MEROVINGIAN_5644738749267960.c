#include<stdio.h>
 void BubbleSort(float a[], int array_size)
  {
  int i, j;
  float temp;
  for (i = 0; i < (array_size - 1); ++i)
  {
       for (j = 0; j < array_size - 1 - i; ++j )
       {
            if (a[j] > a[j+1])
            {
                 temp = a[j+1];
                 a[j+1] = a[j];
                 a[j] = temp;
            }
       }
  }
  }
 void main(){
     int t,n,j,k,l,m,a,b;
     float N[11],K[11];
 FILE *in_file=fopen("D-small-attempt0.in","r");
 FILE *out_file=fopen("Data.txt","w");
 fscanf(in_file,"%d",&t);
 int i=1;
 while(i<=t){
         int nao=0,ken=0,na=0,ke=0;
         fscanf(in_file,"%d",&n);
         for(j=0;j<n;j++)fscanf(in_file,"%f",&N[j]);
         BubbleSort(N,n);
         for(k=0;k<n;k++)fscanf(in_file,"%f",&K[k]);
         BubbleSort(K,n);
     l=m=n;
     a=b=0;
     while(a<l&&b<m){
         if(N[a]<K[b]){
             a++;
             m--;
             ken++;
 
         }
         else{
             a++;
             b++;
             nao++;
         }
     }
     l=m=n;
     a=b=0;
     while(a<l&&b<m){
         if(N[a]<K[b]){
             a++;
             b++;
             ke++;
         }
         else{
             b++;
         }
 
     }na=n-ke;
     fprintf(out_file,"Case #%d: %d %d\n",i,nao,na);i++;
 }
 }

