#include<stdio.h>
 #include<stdlib.h>
 
 int sort(const void *a, const void *b){
   if(*(long double*)a == *(long double*)b)
     return 0;
   if(*(long double*)a < *(long double*)b)
     return -1;
   return 1;
 }
 
 int main(void){
 
   int i, j, t, n, first_naomi, last_naomi, first_ken, last_ken;
   int d_war_score, war_score;
   long double *naomi, *ken;
 
   scanf("%d", &t);
 
   for(i=1; i<=t; i++){
 
     scanf("%d", &n);
 
     naomi = malloc(n*sizeof(long double));
     ken = malloc(n*sizeof(long double));
     d_war_score = 0;
     war_score = 0;
 
     for(j=0; j<n; j++){
       scanf("%Lf", &naomi[j]);
     }
     for(j=0; j<n; j++){
       scanf("%Lf", &ken[j]);
     }
 
     qsort(naomi, n, sizeof(long double), &sort);
     qsort(ken, n, sizeof(long double), &sort);
 
     first_naomi = 0;
     last_naomi = n-1;
     first_ken = 0;
     last_ken = n-1;
     //war:
     for(j=0; j<n; j++){
       if(naomi[last_naomi] > ken[last_ken]){
         last_naomi--;
         war_score++;
       }else{
         last_ken--;
         last_naomi--;
       }
     }
 
     first_naomi = 0;
     last_naomi = n-1;
     first_ken = 0;
     last_ken = n-1;
     //d-war
     for(j=0; j<n; j++){
       //printf("comparing %Lf > %Lf\n", naomi[last_naomi], ken[last_ken]);
       if(naomi[first_naomi] > ken[first_ken]){
         first_naomi++;
         first_ken++;
         d_war_score++;
         //printf("score\n");
       }else{
         first_naomi++;
         last_ken--;
         //printf("no score\n");
       }
     }
     printf("Case #%d: %d %d\n", i, d_war_score, war_score);
 
     free(naomi);
     free(ken);
   }
 }

