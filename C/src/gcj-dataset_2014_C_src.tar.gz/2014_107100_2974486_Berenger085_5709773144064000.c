#include <stdio.h>
 #include <stdlib.h>
 
 FILE *ouvriroutFILE(char *ch)
 {
     return fopen(ch, "w");
 }
 FILE *ouvririnFILE(char *ch)
 {
     return fopen(ch, "r");
 }
 
 double donnerTemps(double C,double F,double X)
 {
     double TP = 0.0,CPS = 2.0,DTF =0.0;
     TP = C/CPS;
     while(X/CPS > (X/(CPS+F))+TP)
     {
         CPS = CPS + F;
         DTF = DTF + TP;
         TP = C / CPS;
     }
     return DTF + X / CPS;
 }
 
 
 
 int main(int Argv,char **Argc)
 {
     FILE *input = ouvririnFILE(Argc[1]);
     FILE *output = ouvriroutFILE("output.in");
     int taille,i=1;
     fscanf(input,"%d",&taille);
     while(taille!=0)
     {
         double X,C,F,DTF;
         fscanf(input,"%lf",&C);
         fscanf(input,"%lf",&F);
         fscanf(input,"%lf",&X);
         DTF = donnerTemps(C,F,X);
         fprintf(output,"Case #%d: %.7lf\n",i,DTF);
         i++;
         taille--;
     }
     return 0;
 }

