#include <stdio.h>
 
 int main(void) {
 	int i,k,a,t,count,ans,j,p;
 	int x[16],y[4];
 	scanf("%d",&t);
 	for(p=1;p<=t;p++)
 	{
 		count=0;
 		scanf("%d",&a);
 		for(i=0;i<16;i++)
 			scanf("%d",&x[i]);
 		k=4*(a-1);
 		for(i=0;i<4;i++)
 			{y[i]=x[k];k++;}
 		scanf("%d",&a);
 		for(i=0;i<16;i++)
 			scanf("%d",&x[i]);
 		k=4*(a-1);
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				if(y[j]==x[k])
 				{
 					count++;
 					ans=y[j];
 					break;
 				}
 			}
 			k++;
 		}
 		if(p!=t)
 		{if(count==1) printf("Case #%d: %d\n",p,ans);
 		else if(count>1) printf("Case #%d: Bad magician!\n",p);
 		else if(count==0) printf("Case #%d: Volunteer cheated!\n",p);}
 
 		else
 		{if(count==1) printf("Case #%d: %d",p,ans);
 		else if(count>1) printf("Case #%d: Bad magician!",p);
 		else if(count==0) printf("Case #%d: Volunteer cheated!",p);}
 
 	}
 	return 0;
 }

