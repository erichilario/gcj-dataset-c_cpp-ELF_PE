#include<stdio.h>
 int main(){
 	int T,t;
 	long double C,F,X,time,rate;
 	scanf("%d",&T);
 	for(t=1;t<=T;t++){
 		time=0.0;
 		rate=2.0;
 		scanf("%Lf %Lf %Lf",&C,&F,&X);
 		while(1){
 			if(C/rate + X/(rate+F) < X/rate){
 				time += C/rate;
 				rate += F;
 			}
 			else {
 				time += X/rate;
 				break;
 			}
 		}
 		printf("Case #%d: %.7Lf\n",t,time);
 	}
 	return 0;
 }
 	

