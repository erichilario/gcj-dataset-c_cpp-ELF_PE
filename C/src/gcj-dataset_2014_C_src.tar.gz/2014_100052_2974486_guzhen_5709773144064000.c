//
 //  main.c
 //  codejam2
 //
 //  Created by 谷大人 on 14-4-12.
 //  Copyright (c) 2014年 guzhen. All rights reserved.
 //
 
 #include <stdio.h>
 int i = 1;
 
 void handle(){
     double c, f, x;
     double current = 0, time = 0;
     double speed = 2;
     scanf("%lf%lf%lf", &c, &f, &x);
     while (current < x) {
         if (current >= c) {
             if ((x/(speed+f)) < ((x-current)/speed)) {
                 current -= c;
                 speed += f;
             } else {
                 time += (x-current)/speed;
                 current = x;
             }
         } else if (c > x){
             time = x / speed;
             current += c;
         } else {
             time += c/speed;
             current += c;
         }
     }
     printf("%lf\n", time);
 }
 
 int main(int argc, const char * argv[])
 {
     freopen("a.in.txt", "r", stdin);
     freopen("a.out.txt", "w", stdout);
     int cases;
     scanf("%d", &cases);
     for (; i <= cases; i++) {
         printf("Case #%d: ", i);
         handle();
     }
     return 0;
 }
 

