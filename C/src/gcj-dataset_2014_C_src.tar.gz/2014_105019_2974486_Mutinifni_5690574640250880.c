#include <stdio.h>
 #include <math.h>
 int main()
 {
 	int t, i, j, k, p=0,r=0,c=0,q=0, flag=0, n, count=0, bottom_most_row, right_most_column, left_most_column, top_most_row;
 	scanf("%d",&t);
 	int row[t], col[t], m[t];
 	for(i=0; i<t; i++)
 	{
 		scanf("%d %d %d", &row[i], &col[i], &m[i]);
 	}
 
 	for(i=0;i<t;i++)
 	{
 		char board[row[i]][col[i]];
 		r=row[i];
 		c=col[i];
 		count = 0;
 		q=0;
 		for(j=0;j<row[i];j++)
 		{
 			for(k=0;k<col[i];k++)
 			{
 				board[j][k]='.';
 			}
 		}
 		if(r==1)
 		{
 			for(j=0;j<m[i];j++)
 			{
 				board[0][j]='*';
 			}
 			board[0][c-1]='c';
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<row[i];j++)
 			{
 				for(k=0;k<col[i];k++)
 				{
 					printf("%c",board[j][k]);
 				}
 				printf("\n");
 			}
 			continue;
 		}
 		if(c==1)
 		{
 			for(j=0;j<m[i];j++)
 			{
 				board[j][0]='*';
 			}
 			board[r-1][0]='c';
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<row[i];j++)
 			{
 				for(k=0;k<col[i];k++)
 				{
 					printf("%c",board[j][k]);
 				}
 				printf("\n");
 			}
 			continue;
 		}
 		board[0][0]='c';
 		if(r*c==m[i]+1)
 		{
 			for(j=r-1;j>=0;j--)
 			{
 				for(k=c-1;k>=0;k--)
 				{
 					if(j==0 && k == 0) continue;
 					board[j][k] = '*';
 					
 				}
 			}
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<row[i];j++)
 			{
 				for(k=0;k<col[i];k++)
 				{
 					printf("%c",board[j][k]);
 				}
 				printf("\n");
 			}
 			continue;		
 		}
 
 		if(row[i]*col[i]==m[i]+2 || row[i]*col[i] == m[i]+3)
 		{
 			printf("Case #%d:\n",i+1);
 			printf("Impossible\n");
 			continue;
 		}
 
 		if((row[i] == 2 && m[i]%2 == 1) || (col[i] == 2 && m[i]%2 == 1))
 		{
 			printf("Case #%d:\n",i+1);
 			printf("Impossible\n");
 			continue;			
 		}
 		p=0;
 		if((r == 2 && m[i]%2 == 0))
 		{
 			while(p < m[i])
 			{
 				for(j=c-1;j>=0;j--)
 				{
 					if(p< m[i])
 					{
 						board[1][j] = '*'; p++;
 					}
 					if(p<m[i])
 					{
 						board[0][j] = '*'; p++;
 					}
 				}
 			}
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<row[i];j++)
 			{
 				for(k=0;k<col[i];k++)
 				{
 					printf("%c",board[j][k]);
 				}
 				printf("\n");
 			}
 			continue;
 		}
 
 		if((c == 2 && m[i]%2 == 0))
 		{
 			while(p < m[i])
 			{
 				for(k=r-1;k>=0;k--)
 				{
 					if(p< m[i])
 					{
 						board[k][0] = '*'; p++;
 					}
 					if(p<m[i])
 					{
 						board[k][1] = '*'; p++;
 					}
 				}
 			}
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<row[i];j++)
 			{
 				for(k=0;k<col[i];k++)
 				{
 					printf("%c",board[j][k]);
 				}
 				printf("\n");
 			}
 			continue;
 		}
 
 		if(m[i]+1 == c + r)
 		{
 			for(j=0;j<r;j++)
 			{
 				board[j][c-1]='*';
 			}
 			for(k=0;k<c;k++)
 			{
 				board[r-1][k]='*';
 			}
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<row[i];j++)
 			{
 				for(k=0;k<col[i];k++)
 				{
 					printf("%c",board[j][k]);
 				}
 				printf("\n");
 			}
 			continue;
 		}
 
 		if(m[i] == c)
 		{
 			for(j=0;j<c;j++)
 			{
 				board[r-1][j]='*';
 			}
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<row[i];j++)
 			{
 				for(k=0;k<col[i];k++)
 				{
 					printf("%c",board[j][k]);
 				}
 				printf("\n");
 			}
 			continue;
 		}
 
 		if(m[i] == r)
 		{
 			for(j=0;j<r;j++)
 			{
 				board[j][c-1]='*';
 			}
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<row[i];j++)
 			{
 				for(k=0;k<col[i];k++)
 				{
 					printf("%c",board[j][k]);
 				}
 				printf("\n");
 			}
 			continue;
 		}
 
 		board[0][0]='c';
 		right_most_column = c-1;
 		bottom_most_row = r-1;
 		j=r-1; k=c-1;
 		while(p < m[i])
 		{
 			while(j>=0)
 			{	
 				if(p<m[i] && board[j][right_most_column] != '*' && !((j == 1 && right_most_column==1) || (j==0 && right_most_column == 1) || (j==0 && right_most_column == 0) || (j==0 && right_most_column ==0))) 
 				{
 					//if(j == 1 && p==m[i]-1 && right_most_column >= 2 && bottom_most_row >=) {board[bottom_most_row-1][right_most_column-1] = '*'; p++;j--;break;}
 					board[j][right_most_column]='*';
 					p++;
 					j--;
 					break;
 				}
 				j--;
 			}
 			while(k>=0)
 			{
 				if(p<m[i] && board[bottom_most_row][k] != '*' && !((k == 1 && bottom_most_row==1) || (k==0 && bottom_most_row == 1) || (k == 1 && bottom_most_row == 0) || (k==0 && bottom_most_row == 0)))
 				{
 					//if(k == 1 && p==m[i]-1 && bottom_most_row >= 2) {board[bottom_most_row-1][right_most_column-1] = '*'; p++;k--;break;}
 					board[bottom_most_row][k]='*';
 					p++;
 					k--;
 					break;
 				}
 				k--;
 			}
 			//if(k == 0 && p<m[i]) {board[bottom_most_row][k] = '*'; p++;}
 			//if(j == 0 && p<m[i]) {board[j][right_most_column] = '*'; p++;}
 
 		
 			if(k == -1) {bottom_most_row--; k=c-1;}
 			if(j == -1) {right_most_column--; j=r-1;}
 		}
 		flag = 0;
 		for(j=0;j<r;j++)
 		{
 			for(k=0;k<c;k++)
 			{
 				if(board[0][k] == '.' && board[1][k] == '*' && board[j][0] == '.' && board[j][1] == '*')
 				{
 					board[0][k] = '*'; board[j][1] = '.';
 					flag = 1;
 					break;
 				}
 			}
 			if(board[j][0] == '.' && board[j][1] == '*' && flag == 0)
 			{
 				if(!((bottom_most_row == 1 && right_most_column==1) || (bottom_most_row==0 && right_most_column == 1) || (bottom_most_row==0 && right_most_column == 0) || (bottom_most_row==0 && right_most_column ==0) || (bottom_most_row == j && right_most_column == 1) || (bottom_most_row == 0) || (right_most_column == 0)))
 				{
 					board[j][1] = '.';
 					if(board[bottom_most_row][right_most_column] != '*')
 					{
 						board[bottom_most_row][right_most_column] = '*';
 					}
 					else if(board[bottom_most_row][right_most_column-1] != '*')
 					{
 						board[bottom_most_row][right_most_column-1] = '*';
 					}
 					else if(board[bottom_most_row-1][right_most_column] != '*')
 					{
 						board[bottom_most_row-1][right_most_column] != '*';
 					}
 					else if(board[bottom_most_row-1][right_most_column-1] != '*')
 					{
 						board[bottom_most_row-1][right_most_column-1] = '*';
 					}		
 					for(k=0;k<r;k++)
 					{
 						if(board[k][0] == '.' && board[k][1] == '*')
 						{
 							q = 1;
 						}
 					}
 				}
 				else
 				{
 					q = 1;
 				}
 			}
 		}
 		for(j=0;j<c;j++)
 		{
 			if(board[0][j] == '.' && board[1][j] == '*' && flag == 0)
 			{
 				if(!((bottom_most_row == 1 && right_most_column==1) || (bottom_most_row==0 && right_most_column == 1) || (bottom_most_row==0 && right_most_column == 0) || (bottom_most_row==0 && right_most_column ==0) || (bottom_most_row == 1 && right_most_column == j) || (bottom_most_row == 0) || (right_most_column == 0)))
 				{
 					board[1][j] = '.';
 					if(board[bottom_most_row][right_most_column] != '*')
 					{
 						board[bottom_most_row][right_most_column] = '*';
 					}
 					else if(board[bottom_most_row-1][right_most_column] != '*')
 					{
 						board[bottom_most_row-1][right_most_column] = '*';
 					}
 					else if(board[bottom_most_row][right_most_column-1] != '*')
 					{
 						board[bottom_most_row][right_most_column-1] = '*';
 					}
 					else if(board[bottom_most_row-1][right_most_column-1] != '*')
 					{
 						board[bottom_most_row-1][right_most_column-1] = '*';
 					}									
 					for(k=0;k<c;k++)
 					{
 						if(board[0][k] == '.' && board[1][k] == '*')
 						{
 							q = 1;
 						}
 					}
 				}
 				else
 				{
 					q = 1;
 				}
 			}
 		}
 		count = 0;
 		if(q == 1)
 		{
 			printf("Case #%d:\n",i+1);
 			q=0;
 			printf("Impossible\n");
 			continue;			
 		}
 		for(j=0;j<row[i];j++)
 		{
 			for(k=0;k<col[i];k++)
 			{
 				if(board[j][k]=='*')
 					{count++;}
 			}
 			//printf("\n");
 		}
 		if(count == m[i])
 		{
 			printf("Case #%d:\n",i+1);
 			for(j=0;j<row[i];j++)
 			{
 				for(k=0;k<col[i];k++)
 				{
 					printf("%c",board[j][k]);
 				}
 				printf("\n");
 			}
 		}
 		else
 		{ 
 			printf("Case #%d:\n",i+1);
 			printf("Impossible\n");
 			continue;
 		}
 	}
 	return 0;
 }
