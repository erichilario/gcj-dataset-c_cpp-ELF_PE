#include<stdio.h>
 
 int main()
 {
 	int arr[4][4],card1[4],card2[4],opt,t,flag,hash[17],i,j,k=0;
 	scanf("%d",&t);
 	while(t--)
 	{
 		k+=1;
 		for(i=1;i<17;i++)
 			hash[i]=0;
 		flag=0;
 		scanf("%d",&opt);
 		opt-=1;
 		for(i=0;i<4;i++)
 			for(j=0;j<4;j++)
 				scanf("%d",&arr[i][j]);
 		for(i=0;i<4;i++)
 			hash[arr[opt][i]] = 1;
 		scanf("%d",&opt);
 		opt-=1;
 		for(i=0;i<4;i++)
 			for(j=0;j<4;j++)
 				scanf("%d",&arr[i][j]);
 		for(i=0;i<4;i++)
 			if(hash[arr[opt][i]]==1)	
 			{
 				flag+=1;
 				j=arr[opt][i];
 			}
 		if(flag==0)
 			printf("Case #%d: Volunteer cheated!\n",k);
 		else if(flag==1)
 			printf("Case #%d: %d\n",k,j);
 		else
 			printf("Case #%d: Bad magician!\n",k);
 	}
 }

