#include <stdio.h>
 
 int main() {
 	int t,c,i,j,a,b,arr[4][4],brr[4][4],m;
 	scanf("%d",&t);
 	for(c=0;c<t;c++) {
 		scanf("%d",&a);
 		for(i=0;i<4;i++) {
 			for(j=0;j<4;j++) {
 				scanf("%d",&arr[i][j]);
 			}
 		}
 		scanf("%d",&b);
 		for(i=0;i<4;i++) {
 			for(j=0;j<4;j++) {
 				scanf("%d",&brr[i][j]);
 			}
 		}
 		m=0;
 		int check[4] = {0};
 		
 		for(i=0;i<4;i++) {
 			for(j=0;j<4;j++) {
 				if(arr[a-1][i] == brr[b-1][j]) {
 					check[m++] = arr[a-1][i];
 				}
 			}
 		}
 		printf("Case #%d: ",c+1);
 		if(m == 1) {
 			printf("%d\n",check[0]);
 		}
 		else
 		if(m == 0) {
 			printf("Volunteer cheated!\n");
 		}
 		else
 		if(m > 1) {
 			printf("Bad magician!\n");
 		}
 	}
 	return 0;
 }

