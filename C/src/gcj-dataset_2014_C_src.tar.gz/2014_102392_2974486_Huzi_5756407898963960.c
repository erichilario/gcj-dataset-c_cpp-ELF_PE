//
 //  main.c
 //  CodeJam
 //
 //  Created by Huzefa on 4/11/14.
 //  Copyright (c) 2014 Huzefa. All rights reserved.
 //
 
 #include <stdio.h>
 
 int main(int argc, const char * argv[])
 {
     int noOfTestcases=0;
     int a[4][4],b[4][4];
     int firstAns,secondAns;
     int correctAnswer=-1;
     //int p=0,q=0;
     FILE *fp;
     FILE *out= fopen("/Users/admin/Desktop/output.txt","w");
     int counter=0;
     int isbadMagician=0;
     fp = fopen("/Users/admin/Desktop/input.txt","r");
     // insert code here...
     fscanf(fp,"%d\n",&noOfTestcases);
     while(counter<noOfTestcases){
     fscanf(fp,"%d\n",&firstAns);
     for(int i=0;i<4;i++){
         for(int j=0;j<4;j++){
             fscanf(fp,"%d",&a[i][j]);
         }
     }
     fscanf(fp,"%d\n",&secondAns);
     for(int i=0;i<4;i++){
         for(int j=0;j<4;j++){
             fscanf(fp,"%d",&b[i][j]);
         }
     }
     for(int i=0;i<4;i++){
         for(int j=0;j<4;j++){
             if(a[firstAns-1][i]==b[secondAns-1][j]){
                 if(correctAnswer==-1){
                     correctAnswer=a[firstAns-1][i];
                 }else{
                     isbadMagician=1;
                 }
             }
         }
     }
         if(correctAnswer==-1){
             fprintf(out,"Case #%d: Volunteer cheated!\n",counter+1);
         }else if(isbadMagician){
             fprintf(out,"Case #%d: Bad magician!\n",counter+1);
         }else{
              fprintf(out,"Case #%d: %d\n",counter+1,correctAnswer);
         }
         counter++;
         correctAnswer=-1;
         isbadMagician=0;
     }
     return 0;
 }
 

