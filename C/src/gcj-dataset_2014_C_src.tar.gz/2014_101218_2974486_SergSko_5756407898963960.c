#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, char ** argv)
 {
     int n_cases, case_nr, answer_i, row_nr, column_nr;
     int answer, card_nr, bitmask, n_results, result;
     
     scanf("%d", &n_cases);
     for (case_nr = 1; case_nr <= n_cases; case_nr++) 
     {
         bitmask = n_results = result = 0;
         for (answer_i = 0; answer_i < 2; answer_i++) 
         {
             scanf("%d", &answer);
             for (row_nr = 1; row_nr <= 4; row_nr++) 
             {
                 for (column_nr = 1; column_nr <= 4; column_nr++) 
                 {
                     scanf("%d", &card_nr);
                     if (row_nr == answer) {
                         if (answer_i) {
                             if (bitmask & (1 << (card_nr-1))) {
                                 result = card_nr;
                                 n_results++;
                             }
                         } else {
                             bitmask |= 1 << (card_nr-1);
                         }
                     }
 
                 } /* column */
 
             } /* row */
 
         } /* answer */
 
         printf("Case #%d: ", case_nr);
 
         if (n_results != 1)
             printf("%s!\n", n_results ? "Bad magician" : "Volunteer cheated");
         else
             printf("%d\n", result);
 
     } /* case */
 
     return 0;
 }

