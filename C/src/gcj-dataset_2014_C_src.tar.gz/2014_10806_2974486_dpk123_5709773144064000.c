#include<stdio.h>
 int main()
 {
      freopen("input.txt", "rt", stdin);
      freopen("output.txt", "wt", stdout);
      int t,k;
      scanf("%d",&t);
      for(k=1;k<=t;k++)
      {
          double c,f,x,r=2,t1,t2,t3,i;
          scanf("%lf%lf%lf",&c,&f,&x);
          t1=x/r;
          t2=0.00000000000;
          for(i=0.0000000000;;i++)
          {
                       t2= t2 + c/(r+i*f) ;
                       t3= t2 + x/(r+(i+1)*f);
                       if (t3<t1)
                          t1=t3;
                       else
                           break;
          }            
          printf("case #%d: %.7f\n",k,t1);
      }
      return 0;
 }

