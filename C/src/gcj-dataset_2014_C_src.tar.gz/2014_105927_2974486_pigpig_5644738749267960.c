#include <stdio.h>
 #include <stdlib.h>
 #include <float.h>
 
 int compare(const void* n1,const void* n2)
 {
 	double d1 = *(double*)n1;
 	double d2 = *(double*)n2;
 
 	if (d1 < d2)
 		return -1;
 	else if (d1 == d2)
 		return 0;
 	else
 		return 1;
 }
 
 int cal(double* naomi, double* ken, int num)
 {
 	int i, j, wins = num;
 
 	qsort(naomi, num, sizeof(double), compare);
 	qsort(ken, num, sizeof(double), compare);
 
 	for (i = num - 1; i > -1; --i)
 	{
 		for (j = num - 1; j > -1; --j)
 			if (naomi[i] > ken[j])
 			{
 				ken[j] = DBL_MAX;
 				break;
 			}
 		if (j == -1)
 			wins -= 1;
 	}
 
 	return wins;
 }
 
 
 int cal_war(double* naomi, double* ken, int num)
 {
 	int i, j, wins = num;
 
 	qsort(naomi, num, sizeof(double), compare);
 	qsort(ken, num, sizeof(double), compare);
 
 	for (i = 0; i < num; ++i)
 	{
 		for (j = 0; j < num; ++j)
 			if (naomi[i] < ken[j])
 			{
 				ken[j] = -1;
 				break;
 			}
 		if (j == num)
 			wins -= 1;
 	}
 
 	return num - wins;
 }
 
 int main()
 {
 	int n, i;
 	scanf("%d", &n);
 
 	for (i = 1; i < n + 1; ++i)
 	{
 		int num, j, dec, war;
 		double* naomi1, *ken1, *naomi2, *ken2;
 		
 		scanf("%d", &num);
 		naomi1 = (double*)malloc(sizeof(double) * num);
 		ken1 = (double*)malloc(sizeof(double) * num);
 		naomi2 = (double*)malloc(sizeof(double) * num);
 		ken2 = (double*)malloc(sizeof(double) * num);
 
 		for (j = 0; j < num; ++j)
 		{
 			scanf("%lf", &naomi1[j]);
 			naomi2[j] = naomi1[j];
 		}
 
 		for (j = 0; j < num; ++j)
 		{
 			scanf("%lf", &ken1[j]);
 			ken2[j] = ken1[j];
 		}
 
 		dec = cal(naomi1, ken1, num);
 		war = cal_war(naomi2, ken2, num);
 
 		printf("Case #%d: %d %d\n", i, dec, war);
 		free(naomi1);
 		free(naomi2);
 		free(ken1);
 		free(ken2);
 	}
 	return 0;
 }
