#include <stdio.h>
 
 int main()
 {
     FILE *fin;
     FILE *fout;
     fin = fopen("in.txt","r");
     fout = fopen("out.txt","w");
     int n,k;
     fscanf(fin,"%d",&n);
     for(k=1;k<=n;k++)
     {
         double t=0;
         double C,F,X;
         int farms;
         fscanf(fin,"%lf %lf %lf",&C,&F,&X);
         farms=(X/C)-(2.0/F);
         if(farms<0)farms=0;
         int f;
         for(f=0;f<farms;f++)
         {
             t+=(C/(f*F+2));
         }
         t+=X/(farms*F+2);
         fprintf(fout,"Case #%d: %.7f\n",k,t);
 
 
     }
     fclose(fin);
     fclose(fout);
 }

