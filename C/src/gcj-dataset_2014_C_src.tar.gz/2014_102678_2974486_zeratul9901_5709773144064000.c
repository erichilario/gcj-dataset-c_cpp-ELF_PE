//
 //  main.c
 //  cj_cookie
 //
 //  Created by Hoyoon on 2014. 4. 13..
 //  Copyright (c) 2014년 SNU. All rights reserved.
 //
 
 #include <stdio.h>
 #include <stdlib.h>
 
 void calculate(FILE *fp, int caseno)
 {
     int count = 0, bestf = 0;
     double c, f, x;
     double besttime = -1, time = 0;
     fscanf(fp, "%lf %lf %lf", &c, &f, &x);
     do {
         time = x / (f * count + 2.0);
         for(int i = count; i >= 1; i--) {
             time += c / (f * (i-1) + 2.0);
         }
         //printf("%f %f\n", besttime, time);
         if(besttime < 0 || besttime > time) {
             besttime = time;
             bestf = count;
         } else
             break;
         count++;
     } while(1);
     printf("Case #%d: %.7f\n", caseno+1, besttime);
  }
 
 int main(int argc, const char * argv[])
 {
 
     // insert code here...
     FILE *fp;
     int ctest = 0;
     fp = fopen("input", "r");
     if(!fp || fscanf(fp, "%d", &ctest) == EOF) {
         printf("wrong input file \n");
         exit(-1);
     }
     for(int i = 0; i < ctest; i++) {
         calculate(fp, i);
     }
     return 0;
 }
 

