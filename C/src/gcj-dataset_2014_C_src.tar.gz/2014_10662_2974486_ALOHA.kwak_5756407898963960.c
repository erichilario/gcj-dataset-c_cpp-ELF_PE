#include <stdio.h>
 #include <stdlib.h>
 int main(){
 	int t,n,i,j,a[4][4],b[4][4],c,d,m,e[4]={0,0,0,0};
 	FILE *f2,*f1;
 	f2=fopen("A-small-attempt0 (1).in","r");
 	f1=fopen("re.txt","w");
 	fscanf(f2, "%d\n",&t);
 	for(n=0;n<t;n++){
 		m=0;
 		fscanf(f2, "%d\n",&c);
 		for(i=0;i<4;i++){
 			for(j=0;j<4;j++){
 				if(j==3)
 					fscanf(f2, "%d\n",&a[i][j]);
 				else
 					fscanf(f2, "%d ",&a[i][j]);
 			}
 		}
 		fscanf(f2, "%d\n",&d);
 		for(i=0;i<4;i++){
 			for(j=0;j<4;j++){
 				if(j==3)
 					fscanf(f2, "%d\n",&b[i][j]);
 				else
 					fscanf(f2, "%d ",&b[i][j]);
 			}
 		}
 		for(i=0;i<4;i++){
 			for(j=0;j<4;j++){
 				if(a[c-1][i]==b[d-1][j]){
 					m+=1;
 					e[0]=a[c-1][i];
 				}
 			}
 		}
 		if(m==0)
 			fprintf(f1, "Case #%d: Volunteer cheated!\n",n+1);
 		else if(m==1)
 			fprintf(f1, "Case #%d: %d\n",n+1,e[0]);
 		else
 			fprintf(f1, "Case #%d: Bad magician!\n",n+1);
 			
 		}
 	fclose(f1);
 	fclose(f2);
 }
