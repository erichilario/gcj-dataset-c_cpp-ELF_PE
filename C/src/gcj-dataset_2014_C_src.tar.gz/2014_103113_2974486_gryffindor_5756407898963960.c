#include<stdio.h>
 int main()
 {
     int i,j,k,l,n,m,val,t,y;
     int a[4][4];
     int b[17];
     scanf("%d",&t);
     for(y=1;y<=t;y++)
     {
         scanf("%d",&n);
         for(i=0;i<4;i++)
         {
             for(j=0;j<4;j++)
                 scanf("%d",&a[i][j]);
         }
         scanf("%d",&m);
         for(i=0;i<16;i++)
         {
             scanf("%d",&k);
             b[k]=(i/4);
         }
         l=0;
         for(i=0;i<4;i++)
         {
             if(b[a[n-1][i]]==(m-1))
             {
                 l++;
                 val=a[n-1][i];
             }
         }
         if(l==0)
         {
             printf("Case #%d: Volunteer cheated!\n",y);
         }
         else if(l==1)
         {
             printf("Case #%d: %d\n",y,val);
         }
         else if(l>1)
         {
             printf("Case #%d: Bad magician!\n",y);
         }
     }
     return 0;
 }

