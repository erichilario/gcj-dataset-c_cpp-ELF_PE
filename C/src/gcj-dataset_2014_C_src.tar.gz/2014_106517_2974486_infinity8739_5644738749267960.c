#include <stdio.h>
 #include <stdlib.h>
 
 void quickSort( double a[], int l, int r)
 {
    int j;
 
    if( l < r ) 
    {
  
         j = partition( a, l, r);
        quickSort( a, l, j-1);
        quickSort( a, j+1, r);
    }
 	
 }
 
 
 
 int partition( double a[], int l, int r) {
    int i, j;
    double pivot;
    double t;
    
    pivot = a[l];
    i = l; j = r+1;
 		
    while( 1)
    {
    	do ++i; while( a[i] <= pivot && i <= r );
    	do --j; while( a[j] > pivot );
    	if( i >= j ) break;
    	t = a[i]; a[i] = a[j]; a[j] = t;
    }
    t = a[l]; a[l] = a[j]; a[j] = t;
    return j;
 }
 
 
 
 int main(int argc, char *argv[])
 {
      int tcasenum;
 
 
      
      int tcaseloop;
      
      int block_num;
      
      int p_ken,p_naomi,poin_naomi_deceit,poin_naomi_war;
   
      int i;
      
      double ken[1000], naomi[1000];   
      
      FILE *fin,*fout;
   fin=fopen("data.in","r");
   fout=fopen("data.out","w");
 
   fscanf(fin,"%d",&tcasenum);
   
   
   
   
   
   
   for(tcaseloop=0;tcaseloop<tcasenum;tcaseloop++)
   {
      fscanf(fin,"%d",&block_num);
      
      for(i=0;i<block_num;i++)
      {
        fscanf(fin,"%lf",&naomi[i]);
      }
      
      for(i=0;i<block_num;i++)
      {
        fscanf(fin,"%lf",&ken[i]);
      }
      
      quickSort(naomi,0,block_num-1);
      quickSort(ken,0,block_num-1);
      
      //war optimized
      
      p_naomi=0;
      p_ken=0;
      
      poin_naomi_war=0;
      
      while(p_ken<block_num)
      {
        if (naomi[p_naomi] > ken[p_ken])
        {
          p_ken++;
          poin_naomi_war++;                   
        }     
        else
        {
          p_ken++;
          p_naomi++;         
        }
      }
      
      //war deceit optimized
      
      p_naomi=0;
      p_ken=0;
      
      poin_naomi_deceit=block_num;
      
      while(p_naomi<block_num)
      {
        if (naomi[p_naomi] < ken[p_ken])
        {
          p_naomi++;
          poin_naomi_deceit--;                   
        }     
        else
        {
          p_ken++;
          p_naomi++;         
        }
      }
      
      fprintf(fout,"Case #%d: %d %d\n",tcaseloop+1,poin_naomi_deceit,poin_naomi_war);
      
      
   }
   
   
   
   fclose(fin);
   fclose(fout);
    
   return 0;
 }
 

