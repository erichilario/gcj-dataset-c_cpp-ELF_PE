#include<stdio.h>
 
 main()
 {
   int T;
   int ArrChRow[2];
   int Arr[2][16];
   int numMatches[100];
   int cardChosen[100];
 
   int i, j, k;
   int p1, p2;
 
   for(i = 0; i < 100; i++) {
     numMatches[i] = 0;
   }
 
   printf("Input\n\n");
   
   readT:
     scanf("%d", &T);
   // Sanity check
     if((T < 1) || (T > 100)) {
       printf("Invalid test cases count. Limit 1<=T<=100\n");
       goto readT;
     }
   // For each test case
   for(i = 0; i < T; i++) {
     int tmp1, tmp2;
     // For each arrangement
     for(j = 0; j < 2; j++) {
       // Choose row
       readArrChRow:
         scanf("%d", &ArrChRow[j]);
         if((ArrChRow[j] < 1) || (ArrChRow[j] > 4)) {
           printf("Invalid answer to Qs#1. Limit 1<=ans1<=4\n");
           goto readArrChRow;
         }
       // Read matrix
       for(k = 0; k < 4; k++) {
         int numCards;
         numCards = 4*(k+1);
         // Read each row
         readEachRow:
           scanf("%d %d %d %d", &Arr[j][(4*k)], &Arr[j][(4*k)+1], &Arr[j][(4*k)+2], &Arr[j][(4*k)+3]);
           if(   Arr[j][(4*k)] < 1 || Arr[j][(4*k)] > 16
             ||  Arr[j][(4*k)+1] < 1 || Arr[j][(4*k)+1] > 16
             || Arr[j][(4*k)+2] < 1 || Arr[j][(4*k)+2] > 16
             || Arr[j][(4*k)+3] < 1 || Arr[j][(4*k)+3] > 16
             ) {
             printf("Invalid card number. Valid cards: 1 to 16. Re-enter the row.\n");
             goto readEachRow;
           }
           for(tmp1 = 0; tmp1 < numCards-1; tmp1++) {
             for(tmp2 = tmp1+1; tmp2 < numCards; tmp2++) {
               if(Arr[j][tmp1] == Arr[j][tmp2]) {
                 printf("Invalid card numbers. Valid cards: 1 to 16 and unique. Re-enter the row.\n");
                 goto readEachRow;
               }
             }
           }
       }  // Read matrix
     }  // For each arrangement
 
     // Calculate output for this test case
     for(tmp1 = 0; tmp1 < 4; tmp1++) {
       for(tmp2 = 0; tmp2 < 4; tmp2++) {
         if(Arr[0][4*(ArrChRow[0]-1)+tmp1] == Arr[1][4*(ArrChRow[1]-1)+tmp2]) {
           numMatches[i]++;
           cardChosen[i] = Arr[0][4*(ArrChRow[0]-1)+tmp1];
           break;
         }
       }
     }
 /*
     //printf("T=%0d ArrChRow[0]=%0d ArrChRow[1]=%0d\n", T, ArrChRow[0], ArrChRow[1]);
     for(p1 = 0; p1 < 2; p1++) {
       printf("Arrangement%0d\n", p1+1);
       for(p2 = 0; p2 < 4; p2++) {
         printf("%0d %0d %0d %0d\n", Arr[p1][(4*p2)], Arr[p1][(4*p2)+1], Arr[p1][(4*p2)+2], Arr[p1][(4*p2)+3]);
       }
     }
 */
   }  // For each test case
   // Output
 //  printf("\n\nOutput\n\n");
   printf("\n\n");
   for(i = 0; i < T; i++) {
 //    printf("numMatches[%0d]=%0d", i+1, numMatches[i]);
     if(numMatches[i] == 0) {
       printf("Case #%0d: Volunteer cheated!\n", i+1); 
     }
     else if(numMatches[i] == 1) {
        printf("Case #%0d: %0d\n", i+1, cardChosen[i]);
     } 
     else if(numMatches[i] > 1 && numMatches[i] < 5) {
       printf("Case #%0d: Bad magician!\n", i+1);
     }
   } 
 }

