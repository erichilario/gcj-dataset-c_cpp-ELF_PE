#include <stdio.h>
 
 
 int main()
 {
 	int T,i,j,k;
 	long double C,F,X;
 	long double t,p;
 	long double best;
 	
 	fscanf(stdin, "%d", &T);
 	for(k=0;k<T;k++)
 	{
 		fscanf(stdin, "%Lf%Lf%Lf", &C, &F, &X);
 		//printf("%lf %lf %lf\n", C,F,X);
 		
 		best = X/2;
 		p = best;
 
 		for(i=1;;i++)
 		{
 			t = C/2;
 			for(j=1;j<i;j++)
 			{
 				//printf("%lf ", t);
 				t = t + C/(2+j*F);
 				//printf("%lf ", t);				
 			}
 			t = t + X/(2+i*F);
 			if(t<best) best=t;
 			if(t>p) break;
 			p=t;
 		}
 		printf("Case #%d: %.7Lf\n", k+1, best);
 	}
 	
 	return 0;
 }
