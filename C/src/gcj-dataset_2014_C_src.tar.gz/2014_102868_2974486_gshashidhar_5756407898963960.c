#include <stdio.h>
 #include <stdlib.h>
 //#define DEBUG
 
 #ifdef DEBUG
 #define print(...) printf(__VA_ARGS__)
 #else
 #define print(...) ;
 #endif
 
 #define outs(...) printf(__VA_ARGS__)
 int arr1[4][4], arr2[4][4];
 int main() {
 
     int i, test = 0, row1, row2, j, match = 0, elem, num, run = 1, found = 0;
 
     scanf("%d", &test);
 
     while (test != 0) {
 
         scanf("%d", &row1);
         i = 0;
         while (i != 4) {
             scanf("%d %d %d %d", &arr1[i][0], &arr1[i][1], &arr1[i][2], &arr1[i][3]);
             i++;
         }
         scanf("%d", &row2);
         i = 0;
         while (i != 4) {
             scanf("%d %d %d %d", &arr2[i][0], &arr2[i][1], &arr2[i][2], &arr2[i][3]);
             i++;
         }
         print("Print Arr1: Row1 = %d\n", row1);
         i = 0;
         while (i != 4) {
             print("%d %d %d %d\n", arr1[i][0], arr1[i][1], arr1[i][2], arr1[i][3]);
             i++;
         }
         print("Print Arr2: Row2 = %d\n", row2);
         i = 0;
         while (i != 4) {
             print("%d %d %d %d\n", arr2[i][0], arr2[i][1], arr2[i][2], arr2[i][3]);
             i++;
         }
         found = 0;
         match = 0;
         for (i = 0; i < 4; i++) {
             elem = arr1[row1-1][i];
             for (j = 0; j < 4; j++) {
                 //print("Match %d and %din row %d\n", arr2[row2][j], elem, row1);
                 if (arr2[row2-1][j] == elem) {
                     match++;
                     num = elem;
                     found = 1;
                 }
             }
         }
         if (match == 1) {
             printf("Case #%d: %d\n", run, num);
         }else if (match > 1) {
             printf("Case #%d: Bad magician!\n", run);
         }else if (match == 0) {
             printf("Case #%d: Volunteer cheated!\n", run);
         }
         test--;
         run++;
     }
 }

