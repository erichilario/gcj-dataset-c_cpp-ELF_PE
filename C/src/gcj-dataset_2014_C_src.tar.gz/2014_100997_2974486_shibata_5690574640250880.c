#include <stdio.h>
 
 int main () {
 	int t, i;
 	scanf("%d", &t);
 	for (i = 1; i <= t; i++) {
 		printf("Case #%d:\n", i);
 		int r, c, m, j;
 		scanf("%d%d%d", &r, &c, &m);
 		if (r == 1) {
 			for (j = 0; j < m; j++) {
 				printf("*");
 			}
 			for (; j < (c - 1); j++) {
 				printf(".");
 			}
 			printf("c\n");
 		} else if (c == 1) {
 			for (j = 0; j < m; j++) {
 				printf("*\n");
 			}
 			for (; j < (r - 1); j++) {
 				printf(".\n");
 			}
 			printf("c\n");
 		} else {
 			if ((r * c - 4) < m) {
 				printf("Impossible\n");
 			} else {
 				int linha = 0;
 				while (m != 0) {
 					int minas_coluna;
 					if (m > c) {
 						m -= c;
 						minas_coluna = c;
 					} else {
 						minas_coluna = m;
 						m = 0;
 					}
 					for (j = 0; j < minas_coluna; j++) {
 						printf("*");
 					}
 					if (m != 0)
 						printf("\n");
 					linha++;
 				}
 				
 				int k;
 				while (linha < r) {
 					for (k = j; k < c; k++) {
 						printf(".");
 					}
 					printf("\n");
 					linha++;
 					j = 0;
 				}
 				
 				for (k = j; k < c - 1; k++)
 					printf(".");
 				printf("c\n");
 				
 			}
 		}
 	}
 	return 0;
 }

