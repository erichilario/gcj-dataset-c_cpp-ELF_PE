#include <stdio.h>
 
 int main()
 {
 	int T,i,j,k,l;
 	scanf("%d",&T);
 	int answer1[T];
 	int answer2[T];
 	int arrangement1[T][4][4];
 	int arrangement2[T][4][4];
 	int output[T];
 	for(i=0;i<T;i++)
 	{
 		scanf("%d",&answer1[i]);
 		for(j=0;j<4;j++)
 		{
 			for(k=0;k<4;k++)
 			{
 				scanf("%d",&arrangement1[i][j][k]);
 			}
 		}
 		scanf("%d",&answer2[i]);
 		for(j=0;j<4;j++)
 		{
 			for(k=0;k<4;k++)
 			{
 				scanf("%d",&arrangement2[i][j][k]);
 			}
 		}
 	}
 
 		for(k=0;k<T;k++)
 		{
 			output[k] = 0;
 			for(j=0;j<4;j++)				
 			{
 				for(l=0;l<4;l++)
 				{
 					if(arrangement1[k][answer1[k]-1][j] == arrangement2[k][answer2[k]-1][l])
 					{
 						if(output[k] == 0)
 						{
 							output[k] = arrangement1[k][answer1[k]-1][j];
 						}
 						else output[k] = 20;
 					}
 				}
 			}
 		}
 
 	for(i=0;i<T;i++)
 	{
 		if(output[i] != 0 && output[i] != 20)
 		{
 			printf("Case #%d: %d\n",i+1,output[i]);
 		}
 		if(output[i] == 0)
 		{
 			printf("Case #%d: Volunteer cheated!\n",i+1);
 		}
 		if(output[i] == 20)
 		{
 			printf("Case #%d: Bad magician!\n", i+1);
 		}
 	}
 	return 0;
 }
