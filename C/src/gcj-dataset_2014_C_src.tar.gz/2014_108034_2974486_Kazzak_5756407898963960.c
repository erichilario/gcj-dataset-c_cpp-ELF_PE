#include <stdio.h>
 int main() {
 	int caseNum;
 	int i, j, k;
 	
 	int saveInput[4][4];
 	int ansList[16] = {};
 	int rowAns1, rowAns2;
 	int ansCount, ans;
 	
 	scanf("%d", &caseNum);
 	for(i = 0; i < caseNum; i++) {
 		scanf("%d", &rowAns1);
 		for(j = 0; j < 4; j++) {
 			for(k = 0; k < 4; k++) {
 				scanf("%d", &saveInput[j][k]);
 				if(j + 1 == rowAns1)
 					ansList[saveInput[j][k] - 1]++;
 			}
 		}
 		scanf("%d", &rowAns2);
 		for(j = 0; j < 4; j++) {
 			for(k = 0; k < 4; k++) {
 				scanf("%d", &saveInput[j][k]);
 				if(j + 1 == rowAns2)
 					ansList[saveInput[j][k] - 1]++;
 			}
 		}
 		ans = 0; ansCount = 0;
 		for(j = 0; j < 16; j++) {
 			if(ansList[j] == 2) {
 				ans = j + 1;
 				ansCount++;
 			}
 		}
 		if(ansCount == 1)
 			printf("Case #%d: %d\n", i + 1, ans);
 		else if(ansCount == 0)
 			printf("Case #%d: Volunteer cheated!\n", i + 1);
 		else
 			printf("Case #%d: Bad magician!\n", i + 1);
 		for(j = 0; j < 16; j++) {
 			ansList[j] = 0;
 		}
 	}
 	return 0;
 }
