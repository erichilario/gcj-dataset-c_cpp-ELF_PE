#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 
 char fname[255];
 
 char m[5][5];
 int rows,cols,mines;
 int transpon=0;
 
 int res=0;
 int nok=0;
 int anum,bnum;
 int numcases;
 FILE * fpin,*fpout;
 
 
 void printres(){
 	int i, j;
 //	printf("print begin\n");
 	if(!transpon){
 		for(i=0;i< rows; i++){
 			for(j=0;j < cols ; j++){
 				printf("%c", m[i][j]);
 				fprintf(fpout,"%c", m[i][j]);
 			}
 			printf("\n");
 			fprintf(fpout,"\n");
 		}
 	}
 	else{
 		for(i=0;i< cols; i++){
 			for(j=0;j < rows ; j++){
 				printf("%c", m[j][i]);
 				fprintf(fpout,"%c", m[j][i]);
 			}
 			printf("\n");
 			fprintf(fpout,"\n");
 		}
 	}
 
 #if 0
 	printf("full\n");
 	for(i=0;i< 5; i++){
 		for(j=0;j < 5 ; j++)
 			printf("%c", m[i][j]);
 		printf("\n");
 	}
 #endif
 
 }
 
 void fill(){
 	int i,j;
 	int free=cols*rows-mines;
 	int minesleft=mines;
 	
 	//printf("free :%d\n", free);
 	if(2 == cols && ((free%2 && free!=1)|| 2 == free )  ){
 		printf("Impossible\n");
 		fprintf(fpout,"Impossible\n");
 		return;
 	}
 	if(cols > 2){
 		if(2 == free || 3 == free || 5 == free || 7 == free ){
 			printf("Impossible\n");
 			fprintf(fpout,"Impossible\n");
 			return;
 		}
 	}
 
 	memset(m,'.',25);
 	m[rows-1][cols-1]='c';
 	
 	int rowneed= minesleft/cols;
 	if(1==free){
 		
 		memset(m,'*',25);
 		m[rows-1][cols-1]='c';
 		printres();
 		return;
 
 	}
 
 	if(1==cols  || 2==cols) {
 		//printf("rowneed: %d\n",rowneed);
 		memset(m, '*', rowneed*5);
 		printres();
 		return;
 	}
 
 	if(3==cols){
 		if(4==free){
 			memset(m, '*', 25);
 			m[rows-2][cols-2]='.';
 			m[rows-2][cols-1]='.';
 			m[rows-1][cols-2]='.';
 			m[rows-1][cols-1]='c';
 		}
 		else if(6==free){
 			memset(m, '*', rowneed*5);
 		}
 		else{
 			memset(m, '*', rowneed*5);
 			minesleft-=rowneed*cols;
 			for(i=0; i <  minesleft; i++)
 				m[rowneed][i]='*';
 			if(2==i){
 				m[rowneed][i-1]='.';
 				m[rowneed+1][0]='*';
 			}
 		}
 		printres();
 		return;
 	}
 	if(4==cols){
 		if(4==free){
 			memset(m, '*', 25);
 			m[rows-2][cols-2]='.';
 			m[rows-2][cols-1]='.';
 			m[rows-1][cols-2]='.';
 			m[rows-1][cols-1]='c';
 		}
 		else if(6==free){
 			memset(m, '*', 25);
 			m[rows-3][cols-1]='.';
 			m[rows-3][cols-2]='.';
 			m[rows-2][cols-2]='.';
 			m[rows-2][cols-1]='.';
 			m[rows-1][cols-2]='.';
 			m[rows-1][cols-1]='c';
 		}
 		else if(9==free){
 			memset(m, '*', 25);
 			m[rows-3][cols-3]='.';
 			m[rows-3][cols-2]='.';
 			m[rows-3][cols-1]='.';
 			m[rows-2][cols-3]='.';
 			m[rows-2][cols-2]='.';
 			m[rows-2][cols-1]='.';
 			m[rows-1][cols-3]='.';
 			m[rows-1][cols-2]='.';
 			m[rows-1][cols-1]='c';
 		}
 		else{
 			memset(m, '*', rowneed*5);
 			minesleft-=rowneed*cols;
 			for(i=0; i <  minesleft; i++)
 				m[rowneed][i]='*';
 			if(3==i){
 				m[rowneed][i-1]='.';
 				m[rowneed+1][0]='*';
 			}
 		}
 		printres();
 		return;
 	}
 	if(5==cols){
 		if(4==free){
 			memset(m, '*', 25);
 			m[rows-2][cols-2]='.';
 			m[rows-2][cols-1]='.';
 			m[rows-1][cols-2]='.';
 			m[rows-1][cols-1]='c';
 		}
 		else if(6==free){
 			memset(m, '*', 25);
 			m[rows-3][cols-1]='.';
 			m[rows-3][cols-2]='.';
 			m[rows-2][cols-2]='.';
 			m[rows-2][cols-1]='.';
 			m[rows-1][cols-2]='.';
 			m[rows-1][cols-1]='c';
 		}
 		else if(8==free){
 			memset(m, '*', 25);
 			m[rows-4][cols-2]='.';
 			m[rows-4][cols-1]='.';
 			m[rows-3][cols-2]='.';
 			m[rows-3][cols-1]='.';
 			m[rows-2][cols-2]='.';
 			m[rows-2][cols-1]='.';
 			m[rows-1][cols-2]='.';
 			m[rows-1][cols-1]='c';
 		}
 		else if(9==free){
 			memset(m, '*', 25);
 			m[rows-3][cols-3]='.';
 			m[rows-3][cols-2]='.';
 			m[rows-3][cols-1]='.';
 			m[rows-2][cols-3]='.';
 			m[rows-2][cols-2]='.';
 			m[rows-2][cols-1]='.';
 			m[rows-1][cols-3]='.';
 			m[rows-1][cols-2]='.';
 			m[rows-1][cols-1]='c';
 		}
 		else{
 			memset(m, '*', rowneed*5);
 			minesleft-=rowneed*cols;
 			for(i=0; i <  minesleft; i++)
 				m[rowneed][i]='*';
 			if(4==i){
 				m[rowneed][i-1]='.';
 				m[rowneed+1][0]='*';
 			}
 		}
 		printres();
 		return;
 	}
 	
 }
 
 int main (int argc, char **argv ){
 
 	int i=0, j=0, cases;
 
 	if(argc != 2){
 		printf ("Usage: %s input_file_name\n", argv[0]);
 		return 1;
 	}
 	printf("in : %s\n", argv[1]);
 	fpin=fopen(argv[1],"r");
 	sprintf(fname,"%s.out",argv[1]);
 	if(!(fpout=fopen(fname,"w")))
 		printf("severe error\n");
 	fscanf(fpin,"%d\n", &numcases);
 	printf("numcases: %d\n", numcases);
 	for(i=0;i< numcases; i++){
 		fscanf(fpin,"%d %d %d\n" ,&rows, &cols, &mines);
 		printf("Case #%d, rows %d cols %d mines %d\n", i+1,rows,cols,mines  );
 		fprintf(fpout,"Case #%d:\n", i+1);
 		if(cols>rows)
 		{
 			transpon=1;
 			j=rows;
 			rows=cols;
 			cols=j;
 		}
 		else{
 			transpon=0;
 		}
 
 		fill();
 	}
 
 	 
 
 	#if 0
 	for(cases=0;cases < numcases; cases++){
 		fscanf(fpin,"%d\n", &anum);
 		for(i=0 ; i < 4 ; i++){
 			if(i+1 == anum)
 				fscanf(fpin,"%d %d %d %d\n",&a[0], &a[1],&a[2],&a[3]  );
 			else
 				fscanf(fpin,"%d %d %d %d\n",&t[0], &t[1],&t[2],&t[3]  );
 		}
 		printf("anum: %d, row: %d %d %d %d\n",anum, a[0], a[1],a[2],a[3] );
 		fscanf(fpin,"%d\n", &bnum);
 		for(i=0 ; i < 4 ; i++){
 			if(i+1 == bnum)
 				fscanf(fpin,"%d %d %d %d\n",&b[0], &b[1],&b[2],&b[3]  );
 			else
 				fscanf(fpin,"%d %d %d %d\n",&t[0], &t[1],&t[2],&t[3]  );
 		}
 		printf("bnum: %d, row: %d %d %d %d\n",bnum, b[0], b[1],b[2],b[3] );
 		res=0;
 		nok=0;
 		for(i=0;i<4 ;i++){
 			for(j=0; j<4 ; j++){
 				if(a[i] == b[j]){
 					if(0==res)
 						res=a[i];
 					else
 						nok=1;
 				}
 			}
 		}
 		printf ("Case #%d: ",cases+1);
 		fprintf (fpout,"Case #%d: ",cases+1);
 		if(nok){
 			printf("Bad magician!\n");
 			fprintf(fpout,"Bad magician!\n");
 		}
 		else{
 			if(res){
 				printf("%d\n",res);
 				fprintf(fpout,"%d\n",res);
 			}
 			else{
 				printf("Volunteer cheated!\n");
 				fprintf(fpout,"Volunteer cheated!\n");
 			}
 		}
 	}
 
 
 	#endif
 
 	fclose(fpin);
 	fclose(fpout);
 	return 0;
 
 
 
 }
 

