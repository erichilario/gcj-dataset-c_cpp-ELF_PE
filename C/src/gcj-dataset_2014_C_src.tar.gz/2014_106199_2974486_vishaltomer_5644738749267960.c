#include <stdio.h>
 
 int compfn(const void *a,const void *b)
 {
     if (*(double*)a > *(double*)b) return 1;
   else if (*(double*)a < *(double*)b) return -1;
   else return 0;
 }
 
 int main()
 {
     int t;
     scanf ("%d",&t);
     int i;
     for (i=1;i<=t;++i)
     {
         double A[10000],B[10000];
         int n,j,k,a,b,af,al,bf,bl,w=0,dw=0;
         scanf ("%d",&n);
         for (j=0;j<n;++j)
             scanf ("%lf",&A[j]);
         for (j=0;j<n;++j)
             scanf ("%lf",&B[j]);
         qsort(A,n,sizeof(double),compfn);
         qsort(B,n,sizeof(double),compfn);
         af=0;
         al=n-1;
         bf=0;
         bl=n-1;
         for(j=0;j<n;++j)
         {
             if (A[al]>B[bl])
             {
                 w++;
                 al--;
                 bf++;
             }
             else
             {
                 al--;
                 bl--;
             }
         }
         af=0;
         al=n-1;
         bf=0;
         bl=n-1;
         for (j=0;j<n;++j)
         {
             if (A[af]>B[bf])
             {
                 dw++;
                 af++;
                 bf++;
             }
             else
             {
                 bl--;
                 af++;
             }
         }
         printf("Case #%d: %d %d\n",i,dw,w);
     }
     return (0);
 }

