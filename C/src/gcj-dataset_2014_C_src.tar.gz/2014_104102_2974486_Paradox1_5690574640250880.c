#include <stdio.h>
 
 int main(void) {
 	int p,t,a,b,m,m1,x,y,i,j;
 	scanf("%d",&t);
 	for(p=1;p<=t;p++)
 	{
 		printf("Case #%d:\n",p);
 		scanf("%d",&a);
 		scanf("%d",&b);
 		scanf("%d",&m);
 		m1=a*b-m;
 		if(a==1)
 		{
 			printf("c");
 			for(i=0;i<b-1-m;i++) printf(".");
 			for(i=0;i<m;i++) printf("*");
 			printf("\n");
 			continue;
 		}
 		if(b==1)
 		{
 			printf("c\n");
 			for(i=0;i<a-1-m;i++) printf(".\n");
 			for(i=0;i<m;i++) printf("*\n");
 			continue;
 
 		}
 
 		if(m1==7 || m1==5 || m1==3 || m1==2 || (a==2 && b==5 && m==1) || (a==5 && b==2 && m==1)) {printf("Impossible\n");continue;}
 
 		if(m1>=2*b)
 		{
 			if(m%b!=(b-1))
 			{
 				x=m/b;
 				y=m-x*b;
 				for(i=0;i<x;i++)
 				{
 					for(j=0;j<b;j++)
 					{
 						printf("*");
 					}
 					printf("\n");
 				}
 				for(i=0;i<b;i++)
 				{
 					if(i<b-y) printf(".");
 					else printf("*");
 				}
 				printf("\n");
 
 				for(i=0;i<a-2-x;i++)
 				{
 					for(j=0;j<b;j++)
 					{
 						printf(".");
 					}
 					printf("\n");
 				}
 				for(i=0;i<b;i++)
 				{
 					if(i==0) printf("c");
 					else printf(".");
 				}
 				printf("\n");
 			}
 			else
 			{
 				x=m/b;
 				for(i=0;i<x;i++)
 				{
 					for(j=0;j<b;j++)
 					{
 						printf("*");
 					}
 					printf("\n");
 				}
 				if(b!=3){for(i=0;i<b;i++)
 				{
 					if(i<3) printf(".");
 					else printf("*");
 				}
 				printf("\n");}
 				for(i=0;i<2;i++)
 				{
 					for(j=0;j<b;j++)
 					{
 						if(j<b-1) printf(".");
 						else printf("*");
 					}
 					printf("\n");
 				}
 				if(b!=3){for(i=0;i<a-m-4;i++)
 				{
 					for(j=0;j<b;j++)
 					{
 						printf(".");
 					}
 					printf("\n");
 				}}
 				else
 				{for(i=0;i<a-3;i++)
 				{
 					for(j=0;j<b;j++)
 					{
 						printf(".");
 					}
 					printf("\n");
 				}}
 
 				for(j=0;j<b;j++)
 				{
 					if(j==0) printf("c");
 					else printf(".");
 				}
 				printf("\n");
 			}
 		}
 		else if(m1!=1)
 		{
 			for(i=0;i<a-3;i++)
 			{
 				for(j=0;j<b;j++)
 				{
 					printf("*");
 				}
 				printf("\n");
 			}
 			if(m1%2)
 			{
 				for(i=0;i<b;i++)
 				{
 					if(i<3) printf(".");
 					else printf("*");
 				}
 				printf("\n");
 				for(j=0;j<b;j++)
 				{
 					if(j<((m1-3)/2)) printf(".");
 					else printf("*");
 				}
 				printf("\n");
 				for(j=0;j<b;j++)
 				{
 					if(j==0) printf("c");
 					else if(j<((m1-3)/2)) printf(".");
 					else printf("*");
 				}
 				printf("\n");
 			}
 			else
 			{
 				if(a>2){for(i=0;i<b;i++)
 				{
 					printf("*");
 				}
 				printf("\n");}
 				for(i=0;i<b;i++)
 				{
 					if(i<(m1/2)) printf(".");
 					else printf("*");
 				}
 				printf("\n");
 				for(i=0;i<b;i++)
 				{
 					if(i==0) printf("c");
 					else if(i<(m1/2)) printf(".");
 					else printf("*");
 				}
 				printf("\n");
 			}
 		}
 		else
 		{
 			for(i=0;i<a-1;i++)
 			{
 				for(j=0;j<b;j++)
 				{
 					printf("*");
 				}
 				printf("\n");
 			}
 			for(i=0;i<b;i++)
 			{
 				if(i==0) printf("c");
 				else printf("*");
 			}
 			printf("\n");
 		}
 
 
 	}
 	return 0;
 }

