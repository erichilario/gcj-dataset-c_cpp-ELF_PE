#include <stdio.h>
 
 int main(){
 
     FILE *fp;
     FILE *fp2;
     int table1[4][4], table2[4][4], i, j, cases, line1, line2, magic, cont, number;
     cont = 0;
     magic = 0;
     fp = fopen("A-small-attempt6.in", "r");
     fscanf (fp,"%d\n", &cases);
     while(cont<cases){
     fscanf (fp,"%d\n", &line1);
 
 
     for(i=0;i<4;i++){
         for(j=0;j<4;j++){
             fscanf(fp,"%d", &table1[i][j]);
         }
     }
     fscanf(fp, "%d\n", &line2);
     for(i=0;i<4;i++){
         for(j=0;j<4;j++){
             fscanf(fp,"%d", &table2[i][j]);
         }
     }
     for(i=0; i<4; i++){
         for(j=0; j<4; j++){
             if(table1[line1-1][i] == table2[line2-1][j]){
                 number = table1[line1-1][i];
                 magic++;
             }
         }
     }
 
         fp2 = fopen("output.in" , "a");
         if (magic == 0) {
             fprintf (fp2, "Case #%d: Volunteer cheated!\n" ,cont+1);
         }else if (magic == 1) {
             fprintf (fp2, "Case #%d: %d \n" , cont+1 ,number);
         }else if (magic > 1) {
             fprintf (fp2, "Case #%d: Bad magician!\n" ,cont+1);
         }
         fclose(fp2);
         cont++;
         magic = 0;
 
     }
 
     fclose(fp);
     return (0);
 }

