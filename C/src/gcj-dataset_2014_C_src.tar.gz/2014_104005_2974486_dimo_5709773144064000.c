#include <stdio.h>
 
 int main (void) {
 	float	c, f, x,
 			mod,
 			aux,
 			a,
 			time;
 	short int w, q;
 
 		scanf("%hd", &w);
 		for (q = 1; q <= w; q++) {
 			mod = 0.0;	
 			time = 0.0;
 			a = 1;
 			aux = 0.0;
 			scanf("%f%f%f", &c, &f, &x);
 			while (2 + f * mod != x && aux < x * 0.75) {
 				a++;
 				time += c / (2 + f * mod);
 				aux += c;
 				mod++;
 			}
 			time += (x / (2 + f * mod));
 			printf("Case #%hd: %.7f\n", q, time);
 		}
 		return 0;
 }

