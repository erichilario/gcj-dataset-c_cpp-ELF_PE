#include <stdio.h>
 
 int main () {
 	int t, i;
 	double c, f, x, best, prod, time;
 	scanf("%d", &t);
 	for (i = 1; i <= t; i++) {
 		scanf("%lf%lf%lf", &c, &f, &x);	//cost, farm prod, end
 		prod = 2.;
 		time = 0.;
 		best = x / 2.;
 		for (;;) {
 			time = time + (c / prod);
 			prod += f;
 			double next = x / prod + time;
 			if (next > best)
 				break;
 			best = next;
 		}
 		printf("Case #%d: %lf\n", i, best);
 	}
 	return 0;
 }

