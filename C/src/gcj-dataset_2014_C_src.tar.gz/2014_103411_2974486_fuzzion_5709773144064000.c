#include <stdio.h>
 
 int main(void) {
   unsigned casen=1,t;
   //int rc;
 
   // get num cases
   scanf("%u\n",&t);
 
   while(t--) { 
 	double C=0, F=0, X=0;
 	double seconds=0, seconds_next=0;
 	double delta=0, deltaX=0, deltaX_next = 0;
 	double rate = 2;
 
 	// Cost, Rate, Target
 	scanf("%lf %lf %lf\n", &C, &F, &X);
 
 
 	//if (X <2)///
 	while(1) {
 	  // How long will it take at current rate to reach X?
 	  deltaX = X/rate;
 
 	  // Seconds to get a farm of cost C at current rate
 	  delta = C/rate;
 
 	  if (casen == 0) {
 		static unsigned iteration=0;
 		printf("%2d %03.2lf %03.2lf %03.2lf %04.2lf %04.2lf\n", 
 			   iteration++, rate, deltaX, delta, seconds+deltaX, seconds+delta);
 	  }
 
 	  deltaX_next = X/(rate+F);
 	  seconds_next = seconds + delta;
 
 	  // If it takes less time to reach X than buying we are done
 	  if (deltaX < delta) {
 		//printf("condition 1 met\n");
 		seconds += deltaX;
 		break;
 	  }
 
 	  // have we reached a bottom where it would take more time
 	  // to
 	  if ((seconds + deltaX) <= (seconds_next + deltaX_next))
 	  {
 		//printf("condition 2 met\n");
 		seconds += deltaX;
 		break;
 	  }
 
 	  seconds += delta;
 	  rate += F;
 	}	
 
 	printf("Case #%u: ", casen++);
 	printf("%.7lf\n", seconds);
   }
   return 0;
 }

