#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     int t,n;
     int a[4][4],i,j,ans1,ans2;
     int b[4][4];
     scanf("%d",&t);      //-----no. of test cases------//
     n=t;
 while(t!=0)
 {
     
     scanf("%d",&ans1);
     for(i=0;i<4;i++)    //----input  1----//
         {
             scanf("%d %d %d %d",&a[i][0],&a[i][1],&a[i][2],&a[i][3]);
         }
     scanf("%d",&ans2);
     for(i=0;i<4;i++)    //----input  2----//
         {
             scanf("%d %d %d %d",&b[i][0],&b[i][1],&b[i][2],&b[i][3]);
         }
 
 t=t-1;
 int rowa=ans1-1,no;
 int rowb=ans2-1,flag=0;
 //------comparing the numbers---------//
     for(i = 0 ; i < 4;i++)
     {
         for (j = 0 ; j < 4;j++)
         {
                 if(a[rowa][i]==b[rowb][j])
             {
                 no=a[rowa][i];
                 flag=flag+1;
             }
         }
     }
 
     if(flag==1)
     {
         printf("Case #%d: %d\n",n-t,no);
     }
     else if(flag>1)
     {
         printf("Case #%d: Bad magician!\n",n-t);
     }
     else if(flag<1)
     {
         printf("Case #%d: Volunteer cheated!\n",n-t);
     }
 
  /*  for(i=0;i<4;i++)
     {
     for(j=0;j<4;j++)
     {
     printf("%d ",a[i][j]);
     }
     printf("\n");
     }
 */
 
 }
     return 0;
 }

