#include <stdio.h>
 #include <stdlib.h>
 #define INPUT_FILE_NAME "B-small-attempt0.in"
 #define OUTPUT_FILE_NAME  "Output.txt"
 /*
 Code Jam: Qualification round 1.
 */
 typedef long double floatingType;
 int readInt(FILE*);
 floatingType readfloatingType(FILE*);
 void compute(floatingType,floatingType,floatingType,FILE *);
 
 typedef enum
 {
     READ_TEST_CASE = 0,
     READ_C,
     READ_F,
     READ_X,
     COMPUTE,
     QUIT
 } _sm;
 
 int main()
 {
     FILE *inputFile = NULL;
     FILE *outputFile = NULL;
     _sm sm = READ_TEST_CASE;
     int testCase=0, doneCase=0;
     floatingType c,f,x;
     if((inputFile=fopen(INPUT_FILE_NAME,"r")) == NULL)
     {
            printf("File not found");
            return 0;
     }
     if((outputFile=fopen(OUTPUT_FILE_NAME,"w")) == NULL)
     {
            printf("File not found");
            return 0;
     }
     while(!feof(inputFile))
     {
         switch (sm )
         {
             case READ_TEST_CASE:
                 testCase=readInt(inputFile);
                 if(testCase == 0)
                     sm = QUIT;
                 else
                     sm = READ_C;
                 break;
             case READ_C:
                 c=readfloatingType(inputFile);
                 sm = READ_F;
                 break;
             case READ_F:
                 f=readfloatingType(inputFile);
                 sm = READ_X;
                 break;
             case READ_X:
                 x=readfloatingType(inputFile);
                 sm = COMPUTE;
                 break;
             case COMPUTE:
                 compute(c,f,x,outputFile);
                 sm = READ_C;
                 doneCase++;
                 break;
             default:
                 break;
         }
         if(testCase == doneCase)
             break;
     }
     fclose(inputFile);
     fclose(outputFile);
     return 0;
 }
 int readInt(FILE* file)
 {
     char c;
     int parseStatus = 0;
     int value = 0;
     // Read first integer from file pointer and return.
     if(file == NULL)
         return 0;
     do{
          c=fgetc(file);
          if (feof(file))
             parseStatus = 0;
          else if( !(c<='9' && c>='0') )
          {
             if(parseStatus == 2 )
                 parseStatus= 0;
             else
                 parseStatus = 1;
          }
          else
             parseStatus = 2;
          if(parseStatus == 2)
          {
             value = (value*10) + c-'0';
          }
     }while(parseStatus);
     return value;
 }
 floatingType readfloatingType(FILE* file)
 {
     char c;
     int parseStatus = 0;
     char buf[20]={0};
     int bufIndex=0;
     floatingType value = 0.0;
     // Read first integer from file pointer and return.
     if(file == NULL)
         return 0;
     do{
          c=fgetc(file);
          if (feof(file))
             parseStatus = 0;
          else if( !((c<='9' && c>='0') || c == '.') )
          {
             if(parseStatus == 2 )
                 parseStatus= 0;
             else
                 parseStatus = 1;
          }
          else
             parseStatus = 2;
          if(parseStatus == 2)
          {
            buf[bufIndex++]=c;
          }
     }while(parseStatus);
     buf[bufIndex] = '\0';
     value = atof(buf);
     return value;
 }
 void compute(floatingType c,floatingType f,floatingType x,FILE* file)
 {
     floatingType s=0.0; // Spent cookies
     floatingType t=0; // time
     floatingType b= (floatingType)2.0; // couting cookies
     static int caseNumber = 0;
     while ( (x-s) > c  )
     {
         s+=c;
         t+= ((floatingType)c/b);
         b += f;
     }
     t+= ((floatingType)x/b);
     caseNumber++;
     fprintf(file,"Case #%d: %.7f\n",caseNumber,t);
 }

