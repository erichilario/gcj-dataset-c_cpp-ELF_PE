#include <stdio.h>
 #include <stdlib.h>
 int main(){
 	int t,n,i,j,p,x,y;
 	double *a,*b,d;
 	FILE *f1,*f2;
 	f1=fopen("D-large.in","r");
 	f2=fopen("ouu.txt","w");
 	fscanf(f1,"%d",&t);
 	for(n=0;n<t;n++){
 		x=0;
 		y=0;
 		fscanf(f1,"%d",&p);
 		a=(double*)malloc(sizeof(double)*p);
 		b=(double*)malloc(sizeof(double)*p);
 		for(i=0;i<p;i++){
 				fscanf(f1,"%lf",&a[i]);
 		}
 		for(i=0;i<p;i++){	
 				fscanf(f1,"%lf",&b[i]);
 		}
 		for(i=0;i<p;i++){
 			for(j=0;j<p;j++){
 				if(a[i]>a[j]){
 					d=a[i];
 					a[i]=a[j];
 					a[j]=d;
 				}
 				if(b[i]>b[j]){
 					d=b[i];
 					b[i]=b[j];
 					b[j]=d;
 				}
 			}
 		}
 		i=0;
 		for(j=0;j<p;){
 			if(a[i]<b[j])
 				j++;
 			else{
 				y++;
 				i++;
 				j++;
 			}
 		}
 		fprintf(f2,"Case #%d: %d",n+1,y);
 		j=0;
 		for(i=0;i<p;){
 			if(a[i]>b[j])
 				i++;
 			else{
 				x++;
 				i++;
 				j++;
 			}
 		}
 		fprintf(f2," %d\n",p-x);
 	}
 	fclose(f1);
 	fclose(f2);
 	return 0;
 }
