#include <stdio.h>
 #include <string.h>
 
 #define RSIZE 4
 #define NUM 16
 
 static int candidate[NUM];
 
 int main()
 {
 	int t, it = 1, i, j, row, ans, count, elem;
 	scanf("%d", &t);
 	while(t > 0) {
 		count = 0;
 		memset(candidate, 0, sizeof(int) * NUM); 
 		scanf("%d", &row);
 		for (i = 0; i < RSIZE; i++) {
 			for (j = 0; j < RSIZE; j++) {
 				scanf("%d", &elem);
 				if (i + 1 == row) {
 					candidate[elem - 1] = 1;
 				}
 			}
 		}
 		scanf("%d", &row);
 		for (i = 0; i < RSIZE; i++) {
 			for (j = 0; j < RSIZE; j++) {
 				scanf("%d", &elem);
 				if (i + 1 == row) {
 					if (candidate[elem - 1]) {
 						count++;
 						if (count == 1) ans = elem;
 					}
 				}
 			}
 		}
 		if (count == 1) {
 			printf("Case #%d: %d\n", it, ans);
 		}
 		else if (count > 0) {
 			printf("Case #%d: Bad magician!\n", it); 
 		}
 		else {
 			printf("Case #%d: Volunteer cheated!\n", it);
 		}
 		it++;
 		t--;
 	}
 	return 0;
 }

