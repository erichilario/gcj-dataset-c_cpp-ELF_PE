#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
 #define eps (1.0e-6)
 
 int compareTo (const void* a, const void* b) {
     double da = *((double*)a);
     double db = *((double*)b);
     if (da > db) return  1;
     if (da < db) return -1;
     return 0;
 }
 
 int Deceitful_War(int N, double* Naomi, double* Ken) {
 	int i=0;
 	for (int i=0; i<N; i++) {
 		int win = 1;
 		for  (int j=i; j<N; j++) {
 			if (Naomi[j] < Ken[j-i]) {
 				win = 0;
 				break;
 			}
 		}
 		if (win) {
 			return N-i;
 		}
 	}
 	return 0;
 }
 
 int War(int N, double* Naomi, double* Ken) {
 	char* Ken_used = (char*) malloc (N*sizeof(char));
 	memset(Ken_used,   0, N*sizeof(char));
 	int Naomi_score = 0;
 	for (int i=0; i<N; i++) {
 		int Naomi_scores = 1;
 		for (int j=0; j<N; j++) {
 			if (!Ken_used[j] && Ken[j] > Naomi[i]) {
 				Ken_used[j] = 1;
 				Naomi_scores = 0;
 				break;
 			}
 		}
 		if (Naomi_scores) {
 			Naomi_score++;
 			for (int j=0; j<N; j++) {
 				if (!Ken_used[j]) {
 					Ken_used[j] = 1;
 					break;
 				}
 			}
 		}
 	}
 	free(Ken_used);
 	return Naomi_score;
 }
 
 int main(int argc, char** argv) {
 	int T;
 	scanf("%d", &T);
 	for (int t=0; t<T; t++) {
 		int N;
 		double *Naomi, *Ken;
 		scanf("%d", &N);
 		Naomi = (double*) malloc (N*sizeof(double));
 		Ken   = (double*) malloc (N*sizeof(double));
 		for (int i=0; i<N; i++) {
 			scanf("%lf", &Naomi[i]);
 		}
 		for (int i=0; i<N; i++) {
 			scanf("%lf", &Ken[i]);
 		}
 		qsort(Naomi, N, sizeof(double), compareTo);
 		qsort(Ken,   N, sizeof(double), compareTo);
 		printf("Case #%d: %d %d\n", t+1, Deceitful_War(N, Naomi, Ken), War(N, Naomi, Ken));
 	}
 }
