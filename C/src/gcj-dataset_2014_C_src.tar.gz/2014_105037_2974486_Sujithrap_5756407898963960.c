#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 FILE *ip = NULL, *op = NULL;
 
 char get_answer(int a1, int t1[4][4], int a2, int t2[4][4], int *res)
 {
   int j = 0, k = 0, num = 0, count = 0, save = 0;
 
   for(j = 0; j < 4; j++) {
     num = t1[a1][j];
     for (k = 0; k < 4; k++) {
       if (num == t2[a2][k]) {
 	count++;
 	save = num;
       }
     }
   }
 
   if (count == 1) {
     *res = save;
     return 's';
   }
   else if (count > 1) {
     return 'b';
   }
   else {
     return 'c';
   }
 
 }
 
 void output_answer(char a, int tc, int num)
 {
 
   char ops[100];
 
   switch(a) {
 
     case 's':
       sprintf(ops, "Case #%d: %d\n", tc+1, num);
       break;
 
     case 'b':
       sprintf(ops, "Case #%d: Bad magician!\n", tc+1);
       break;
 
     case 'c':
       sprintf(ops, "Case #%d: Volunteer cheated!\n", tc+1);
       break;
   }
   fputs(ops, op);
 }
 
 int main()
 {
   int T, a1, a2, i, j, res = 0;
   int table1[4][4], table2[4][4];
   char c;
   char line[80];
 
   ip = fopen("input.txt", "r");
   op = fopen("output.txt", "w");
 
   fscanf(ip, "%d\n", &T);
 
   for (i = 0; i < T; i++) {
     fscanf(ip, "%d\n", &a1);
     for (j = 0; j < 4; j++) {
       fgets(line, 100, ip);
       sscanf(line, "%d %d %d %d", &(table1[j][0]), &(table1[j][1]), &(table1[j][2]), &(table1[j][3]));
     }
     fscanf(ip, "%d\n", &a2);
     for (j = 0; j < 4; j++) {
       fgets(line, 100, ip);
       sscanf(line, "%d %d %d %d", &(table2[j][0]), &(table2[j][1]), &(table2[j][2]), &(table2[j][3]));
     }
 
     c = get_answer(a1-1, table1, a2-1, table2, &res);
     output_answer(c, i, res);
   }
 
   fclose(ip);
   fclose(op);
 
   return 0;
 }

