#include <stdio.h>
 #include <stdlib.h>
 #define INPUT_FILE_NAME "A-small-attempt1.in"
 #define OUTPUT_FILE_NAME    "Output1.txt"
 /*
 Code Jam: Qualification round 1.
 */
 int readNumber(FILE*);
 void readMagicArray(FILE*, int**);
 void findCommonNumber(int*, int, int*,int,FILE*);
 typedef enum
 {
     READ_TEST_CASE = 0,
     READ_MAGIC_ROW_ONE,
     READ_MAGIC_ARRAYONE,
     READ_MAGIC_ROW_TWO,
     READ_MAGIC_ARRAYTWO,
     PERFORM_MAGIC,
     QUIT
 } _sm;
 int main()
 {
     FILE *inputFile = NULL;
     FILE *outputFile = NULL;
     _sm sm = READ_TEST_CASE;
     int testCase=0, doneCase=0, magicRow1=0, magicRow2=0;
     int *magicArray1 = malloc(sizeof (int) * 16);
     int *magicArray2 = malloc(sizeof (int) * 16);
     if((inputFile=fopen(INPUT_FILE_NAME,"r")) == NULL)
     {
            printf("File not found");
            return 0;
     }
     if((outputFile=fopen(OUTPUT_FILE_NAME,"w")) == NULL)
     {
            printf("File not found");
            return 0;
     }
 //    fprintf(outputFile,"Output\n\n");
     while(!feof(inputFile))
     {
         switch (sm )
         {
             case READ_TEST_CASE:
                 testCase=readNumber(inputFile);
                 if(testCase == 0)
                     sm = QUIT;
                 else
                     sm = READ_MAGIC_ROW_ONE;
                 break;
             case READ_MAGIC_ROW_ONE:
                 magicRow1=readNumber(inputFile);
                 sm = READ_MAGIC_ARRAYONE;
                 break;
             case READ_MAGIC_ARRAYONE:
                 readMagicArray(inputFile,(int **)&magicArray1);
                 sm = READ_MAGIC_ROW_TWO;
                 break;
             case READ_MAGIC_ROW_TWO:
                 magicRow2=readNumber(inputFile);
                 sm = READ_MAGIC_ARRAYTWO;
                 break;
             case READ_MAGIC_ARRAYTWO:
                 readMagicArray(inputFile,(int **)&magicArray2);
                 sm = PERFORM_MAGIC;
                 break;
             case PERFORM_MAGIC:
                 findCommonNumber(magicArray1,magicRow1,magicArray2,magicRow2,outputFile);
                 sm = READ_MAGIC_ROW_ONE;
                 doneCase++;
             default:
                 break;
         }
         // Perform only 100 test cases.
         if(testCase == doneCase || doneCase == 100)
             break;
     }
     fclose(inputFile);
     free(magicArray1);
     free(magicArray2);
     return 0;
 }
 int readNumber(FILE* file)
 {
     char c;
     int parseStatus = 0;
     int value = 0;
     // Read first integer from file pointer and return.
     if(file == NULL)
         return 0;
     do{
          c=fgetc(file);
          if (feof(file))
             parseStatus = 0;
          else if( !(c<='9' && c>='0') )
          {
             if(parseStatus == 2 )
                 parseStatus= 0;
             else
                 parseStatus = 1;
          }
          else
             parseStatus = 2;
          if(parseStatus == 2)
          {
             value = (value*10) + c-'0';
          }
     }while(parseStatus);
     return value;
 }
 void readMagicArray(FILE* file, int** arrptr)
 {
     int *ptr= (int *)*arrptr;
     int i,j;
     if(ptr == NULL)
         return;
     for (i=0; i< 4; i++)
     {
         for(j=0; j < 4; j++)
         {
            *(ptr+(i*4)+j) = readNumber(file);
         }
     }
 }
 void findCommonNumber(int* arr1, int row1, int* arr2,int row2,FILE* file)
 {
     int matchedNumber= 0;
     int validResult=0;
     int i,j;
     static caseNumber=0;
     // Array boundary check.
     if(row1 > 4 || row2 > 4)
         return ;
     for(i= 0; i<4 ; i++)
         for(j=0 ; j<4 ; j++)
         {
             if( *(arr1+(row1-1)*4+i) ==  *(arr2+(row2-1)*4+j) )
             {
                 if(matchedNumber == 0)
                     validResult = 1;
                 else
                     validResult = 0;
                 matchedNumber = *(arr1+(row1-1)*4+i);
             }
         }
     caseNumber++;
     if(validResult && matchedNumber )
     {
         fprintf(file,"Case #%d: %d\n",caseNumber,matchedNumber);
     }
     else if (!validResult && !matchedNumber )
     {
         fprintf(file,"Case #%d: Volunteer cheated!\n",caseNumber);
     }
     else if(!validResult && matchedNumber )
     {
         fprintf(file,"Case #%d: Bad magician!\n",caseNumber);
     }
 }

