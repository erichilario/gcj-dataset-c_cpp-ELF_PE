#include <stdio.h>
 
 int cal(int col1[4], int col2[4])
 {
 	int i, j;
 	int ans = -2;
 
 	for (i  = 0; i < 4; ++i)
 		for (j = 0; j < 4; ++j)
 			if (col1[i] == col2[j])
 			{
 				if (ans == -2)
 					ans = col1[i];
 				else
 				{
 					ans = -1;
 					break;
 				}
 			}
 	return ans;
 }
 
 int main()
 {
 	int n, i;
 	scanf("%d", &n);
 
 	for (i = 1; i < n + 1; ++i)
 	{
 		int a1, a2, j, k, rubbish, res;
 		int col1[4], col2[4];
 
 		scanf("%d", &a1);
 
 		for (j = 0; j < 4; ++j)
 			if (j != a1 - 1)
 				for (k = 0; k < 4; ++k)
 					scanf("%d", &rubbish);
 			else
 				for (k = 0; k < 4; ++k)
 					scanf("%d", &col1[k]);
 
 		scanf("%d", &a2);
 		for (j = 0; j < 4; ++j)
 			if (j != a2 - 1)
 				for (k = 0; k < 4; ++k)
 					scanf("%d", &rubbish);
 			else
 				for (k = 0; k < 4; ++k)
 					scanf("%d", &col2[k]);
 
 		res = cal(col1, col2);
 		//for (j = 0; i < 4; ++j)
 		//	printf(" %d ", col1[j]);
 		//for (j = 0; i < 4; ++j)
 		//	printf(" %d ", col2[j]);
 
 		if (res == -1)
 			printf("Case #%d: Bad magician!\n", i);
 		else if (res == -2)
 			printf("Case #%d: Volunteer cheated!\n", i);
 		else
 			printf("Case #%d: %d\n", i, res);
 	}
 	return 0;
 }
