#include <stdio.h>
 #ifdef D
 #define print_line() printf("%d\n",__LINE__)
 #define print_int(a) printf("%d\n",a)
 #define print_float(a) printf("%f\n",a)
 #define print_char(a) printf("%c\n",a)
 #else
 #define print_line()
 #define print_int(a)
 #define print_float(a)
 #define print_char(a)
 #endif
 int main(){
 	int t,T;
 	int i,j,x,y,k, a[4][4],b[4][4],found,value;
 	scanf("%d\n",&T);
 	print_int(T);
 	for (t=1;t<=T;t++)
 	{
 		scanf("%d\n",&x);
 		print_int(x);
 		x--;
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				scanf("%d", &a[i][j]);
 				print_int(a[i][j]);
 				}
 		}
 		scanf("%d\n",&y);
 		y--;
         found=0;
 		value=0;
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				scanf ("%d", &b[i][j]);
 				print_int(b[i][j]);
 				if (i==y && value != -1)
 				{
 
 					for (k=0;k<4;k++)
 					{
 						if(b[i][j] == a[x][k])
 						{
 							if(!found)
 							{
 								found=1;
 								value=a[x][k];
 							}
 							else
 							{
 								value=-1;
 							}
 							break;
 						}
 					}
 				}
 			}
 		}
 		switch (value)
 		{
 			case -1:
 				printf("Case #%d: Bad magician!\n",t);
 				break;
 			case 0:
 				printf("Case #%d: Volunteer cheated!\n",t);
 				break;
 			default:
 				printf("Case #%d: %d\n",t,value);
 				break;
 		}
 	}
 	return 0;
 }
 	
