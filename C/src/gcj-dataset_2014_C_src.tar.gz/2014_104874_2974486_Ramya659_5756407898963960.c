#include<stdio.h>
 #include<stdlib.h>
 #include<conio.h>
 void main()
 {
 	FILE*fp,*fp1;
 	int i,c=0,a,r=0,n,p,q,m1[4][4],m2[4][4],b;
 	fp=fopen("magic trick.txt","r");
 	fp1=fopen("magic trick op.txt","w");
 		fscanf(fp,"%d",&n);
 		for(i=0;i<n;i++)
 		{
 			c=0;
 			fscanf(fp,"%d",&a);
 			for(p=0;p<4;p++)
 			{
 				for(q=0;q<4;q++)
 				{
 					fscanf(fp,"%d",&m1[p][q]);
 				}
 			}
 			fscanf(fp,"%d",&b);
 			for(p=0;p<4;p++)
 			{
 				for(q=0;q<4;q++)
 				{
 					fscanf(fp,"%d",&m2[p][q]);
 				}
 			}
 			for(p=0;p<4;p++)
 			{
 			for(q=0;q<4;q++)
 				{
 					if(m1[a-1][p]==m2[b-1][q])
 					{
 						c++;
 						if(c==1)
 						r=m1[a-1][p];
 					}
 				}
 			}
 					if(c==1)
 					{
 						fprintf(fp1,"Case #%d: %d\n",i+1,r);
 					}
 						else if(c>1)
 						{
 							fprintf(fp1,"Case #%d: Bad magician!\n",i+1);
 						}
 						else
 							{
 								fprintf(fp1,"Case #%d: Volunteer cheated!\n",i+1);
 							}
 		}
 		fclose(fp1);
 		fclose(fp);
 	getch();
 		}
 					
 

