#include <stdio.h>
 #include <stdlib.h>
 
 int main(){
 	int T, i, j, farms;
 	double *timebuy, timefinishmin, timefinishtemp;
 	double c, f, x;
 	scanf("%d", &T);
 	for (i = 1; i <= T; i++){
 		printf("Case #%d: ", i);
 		scanf("%lf%lf%lf", &c, &f, &x);
 		farms = (int)(2.0 * x / c) + 1;
 		timebuy = (double*)malloc(sizeof(double) * farms);
 //		timefinish = (double*)malloc(sizeof(double) * farms);
 		timebuy[0] = 0.0;
 		for (j = 1; j < farms; j++){
 			timebuy[j] = timebuy[j - 1] + c / ((double)(j - 1) * f + 2.0);
 		}
 		timefinishmin = timebuy[0] + x / 2.0;
 		for (j = 1; j < farms; j++){
 			timefinishtemp = timebuy[j] + x / ((double)(j) * f + 2.0);
 			if (timefinishtemp < timefinishmin) timefinishmin = timefinishtemp;
 		}
 		printf("%.7lf\n", timefinishmin);
 		free(timebuy);
 	}
 	return 0;
 }
