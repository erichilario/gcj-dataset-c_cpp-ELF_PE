#include<stdio.h>
 int main()
 {
    int test,t,i,j,n,remain, flag1=0,flag2=0,first=0;
    double temp, temp1,new, delta=0.000001;
    scanf("%d",&test);
    t= test;
    while(test--)
 {
  	scanf("%d",&n);
 	int last=n;
 	double arr1[n],arr2[n];
 	for (i=0;i<n;i++)
 	{
 	scanf("%lf",&arr1[i]);
 	}
 	for (i=0;i<n;i++)
 	{
 	scanf("%lf",&arr2[i]);
 	}
 for(i=0;i<n;i++){
       for(j=i+1;j<n;j++){
            if(arr1[i]>arr1[j])
 	   {
                temp=arr1[i];
               arr1[i]=arr1[j];
               arr1[j]=temp;
            }
       }
   }
 for(i=0;i<n;i++){
       for(j=i+1;j<n;j++){
            if(arr2[i]>arr2[j])
 	   {
                temp1=arr2[i];
               arr2[i]=arr2[j];
               arr2[j]=temp1;
            }
       }
 }
 for (i=0;i<n;i++)
 {
 	remain= n-i;
 	if (arr1[0]>arr2[n-1])
 	{
 		flag1=n;
 		flag2=n;
 	}
 	else if (arr1[n-1]<arr2[0])
 	{
 		flag1=0;
 		flag2=0;
 	}
 	else
 	{
 		if (remain!=1)
 		{
 			if (arr1[i]>arr2[i-1] && i>0)
   			{
 				flag1+=1;
   			}	
 		}
 		else
 		{
 			if (arr1[i]>arr2[i-1])
 			{
 				flag1++;
 			}
 		}
 	}
 
 }
 
 	for (i=n-1;i>=0;i--)
 	{
 		if (arr1[i]>arr2[last-1])
 		{
 			flag2++;
 			first++;
 		}
 		else
 		{
 			last--;
 		}
 
 
 
 	}
 
 printf("Case #%d: %d %d\n",t-test,flag1,flag2);
  
 
 
 flag1=0;
 first=0;
 flag2=0;
 }
  return 0;
 }
 

