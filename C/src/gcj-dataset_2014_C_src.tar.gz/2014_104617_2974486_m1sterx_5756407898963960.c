
 
 #include <stdio.h>
 
 int main() {
   int i, j, k;
   int T;
 
   scanf("%d", &T);
 
   for(i = 0; i < T; i++) {
     int answers[2];
     int boards[2][16];
 
     for(j = 0; j < 2; j++) {
       scanf("%d", &answers[j]);
       for(k = 0; k < 16; k++) scanf("%d", &boards[j][k]);
     }
 
     int coincidences = 0;
     int number = 0;
     for(j = 0; j < 4; j++) {
       for(k = 0; k < 4; k++) {
         if(boards[0][4*(answers[0]-1) + j] == boards[1][4*(answers[1]-1) + k]) {
           coincidences++;
           number = boards[0][4*(answers[0]-1) + j];
         }
       }
     }
 
     printf("Case #%d: ", i+1);
     if(coincidences == 0) printf("Volunteer cheated!\n");
     else if(coincidences == 1) printf("%d\n", number);
     else printf("Bad magician!\n");
   }
 
   return 0;
 }
 

