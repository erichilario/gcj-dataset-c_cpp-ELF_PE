#include <stdio.h>
 
 int main() {
         int n,k,i,j;
         scanf("%d",&n);
         for(k=1;k<=n;k++) {
                 int r,c,m;
                 scanf("%d%d%d", &r,&c,&m);
                 printf("Case #%d:\n",k);
                 if(r>=1&&r<=2&&c>=1&&c<=2) {
                         printf("Impossible\n");
                         continue;
                 }
                 if(r==1){
                         if((c-2)<m){
                                 printf("Impossible\n");
                                 continue;
                         }
                         else {
                                 printf("c");
                                 for(i=0;i<c-m-1;i++)
                                         printf(".");
                                 for(i=0;i<m;i++)
                                         printf("*");
                                 printf("\n");
                                 continue;
                         }
                 }
                 if(c==1){
                         if((r-2)<m){
                                 printf("Impossible\n");
                                 continue;
                         }
                         else {
                                 printf("c\n");
                                 for(i=0;i<r-m-1;i++)
                                         printf(".\n");
                                 for(i=0;i<m;i++)
                                         printf("*\n");
                                 continue;
                         }
                 }
                 //r>2&&c>2
                 int blank = r*c-m;
                 if(blank<4){
                         printf("Impossible\n");
                         continue;
                 }
                 else {
                         blank = blank-4;
                         for(i=0;i<r;i++) {
                                 for(j=0;j<c;j++) {
                                         if(i==0 && j==0){
                                                 printf("c");
                                                 continue;
                                         }
                                         if((i==0 && j==1)||(i==1&&j==0)||(i==1&&j==1)){
                                                 printf(".");
                                                 continue;
                                         }
                                         if(blank>0) {
                                                 printf(".");
                                                 blank--;
                                                 continue;
                                         }
                                         else{
                                                 printf("*");
                                                 continue;
                                         }
                                 }
                                 printf("\n");
                         }
                 }
 
         }
         return 0;
 }
