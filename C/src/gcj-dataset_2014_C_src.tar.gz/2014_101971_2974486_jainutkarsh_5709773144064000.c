#include<stdio.h>
 int main()
 {
     double C,X,F,t1,t2=0.0,a[2]={0.0,0.0};
     int i,j,T,b=0,s=0;
     double cookies=2;
     scanf("%d",&T);
     double w[T];
     j=T;
     while(T!=0)
     {
         scanf("%lf%lf%lf",&C,&F,&X);
         do
         {
             a[0]=a[1];
             t1 = X/cookies;
             a[1] = t1 + t2;
             t2 = t2 +(C/cookies);
             cookies = cookies + F;
             b++;
         }while(a[0]>a[1]||(b==1));
         w[s]=a[0];
         t2=0,b=0,cookies=2;
         T--;
         s++;
 
     }
     for(i=0;i<j;i++)
     {
         printf("\nCase #%d: %.7lf",i+1,w[i]);
     }
     return 0;
 }

