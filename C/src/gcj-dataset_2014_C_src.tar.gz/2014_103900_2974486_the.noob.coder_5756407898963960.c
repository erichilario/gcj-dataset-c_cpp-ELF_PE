#include<stdio.h>
 #include<stdlib.h>
 int main(void)
 {
 	int test_number,ans_1,ans_2,counter,counter_1,counter_2,equal_number,chosen_number;
 	int *answer;
 	scanf("%d",&test_number);
 	answer=(int *)malloc(test_number*sizeof(int));
 	for(counter=0;counter<test_number;counter++)
 	{
 		int pos_1[4][4];
 		int pos_2[4][4];
 		scanf("%d",&ans_1);
 		for(counter_1=0;counter_1<=3;counter_1++)
 		{
 			for(counter_2=0;counter_2<=3;counter_2++)
 				scanf("%d",&pos_1[counter_1][counter_2]);
 		}
 		
 		scanf("%d",&ans_2);
 		for(counter_1=0;counter_1<=3;counter_1++)
 		{
 			for(counter_2=0;counter_2<=3;counter_2++)
 				scanf("%d",&pos_2[counter_1][counter_2]);
 		}
 		if(ans_1==0 || ans_2==0)
 				answer[counter]=-1;
 		else 
 		{
 			equal_number=0;
 			for(counter_1=0;counter_1<=3;counter_1++)
 			{
 				for(counter_2=0;counter_2<=3;counter_2++)
 				{
 					if(pos_1[ans_1-1][counter_1]==pos_2[ans_2-1][counter_2])
 					{
 						chosen_number=pos_1[ans_1-1][counter_1];
 						equal_number++;
 					}
 				}
 			}
 			if(equal_number==0)
 				answer[counter]=-1;
 			else if(equal_number==1)
 				answer[counter]=chosen_number;
 			else
 				answer[counter]=0;
 		}
 	}
 	
 	for(counter=0;counter<test_number;counter++)
 	{
 		if(answer[counter]==-1)
 			printf("Case #%d: Volunteer cheated!\n",counter+1);
 		else if(answer[counter]==0)
 			printf("Case #%d: Bad magician!\n",counter+1);
 		else
 			printf("Case #%d: %d\n",counter+1,answer[counter]);
 	}
 	
 
 	return 0;
 }

