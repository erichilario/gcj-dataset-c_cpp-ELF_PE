#include<stdio.h>
 
 
 void search(int arr[4][4],int arr2[4][4],int t1, int t2, int test){
 
    FILE *f;
 
    //	Search purpose
    static int search1[4],search2[4];
    int flag=0, count=0,i,j,k;
    for(i=0;i<4;i++){
    	search1[i]=arr[t1-1][i];
    }
    for(i=0;i<4;i++){
 		search2[i]=arr2[t2-1][i];
    }
 
 
    for(i=0;i<4;i++){
    	for(j=0;j<4;j++){
       	if(search1[i]==search2[j]){
 
          	flag=1;
             count++;
             k=i;	//search1[i] will be the element
          }
       }
    }
    f = fopen("a.txt", "a");
    if(count==1){
    	fprintf(f, "Case #%d: %d\n",test+1,search1[k]);
    }
    if(count>1){
    	fprintf(f,"Case #%d: Bad magician!\n",test+1);   //Bad magician
    }
 
    if(count<1){
    	fprintf(f,"Case #%d: Volunteer cheated!\n",test+1);
    }
    fclose(f);
    return;
 }
 
 
 int main(){
    // Input purpose variable
 	int arr[401][4],arr2[401][4],t1[100],t2[100];
 
    FILE* file = fopen ("A-small-attempt0(1).in", "r");
 
    int i, j, k, n=0,test;
    // test purpose
    int a[4][4], a1[4][4],z;
 
 
    fscanf (file, "%d", &test);
    while (!feof (file)){
 	for(i=0;i<test;i++){
    	fscanf (file, "%d", &t1[i]);
       for(j=n;j<(n+4);j++){
       	for(k=0;k<4;k++){
          	fscanf (file, "%d", &arr[j][k]);
          }
 		}
       fscanf (file, "%d", &t2[i]);
       for(j=n;j<(n+4);j++){
       	for(k=0;k<4;k++){
          	fscanf (file, "%d", &arr2[j][k]);
          }
 		}
       n=j;
    }
    }
 	//	Search for the intputs
    n=0;
    for(i=0;i<test;i++){
 
       for(j=n,z=0;j<(n+4);j++,z++){
       	for(k=0;k<4;k++){
          	a[z][k]=arr[j][k];
          }
 		}
 
       for(j=n,z=0;j<(n+4);j++,z++){
       	for(k=0;k<4;k++){
          	a1[z][k]=arr2[j][k];
          }
 		}
 
       search(a,a1,t1[i],t2[i],i);
 
 
       n=j;
    }
 
 
 
 	return 0;
 }
