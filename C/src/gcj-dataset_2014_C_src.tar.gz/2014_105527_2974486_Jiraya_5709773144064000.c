#include<stdio.h>
 
 void output(double C, double F, double X, int test){
 
 	FILE *f;
 
 	double buy_now,buy_later;
    int flag=0,counter=0,i,j;
    double cookie_rate=2.0;
    double total_time=0.0F;
    int count=0;
 
 
 
 	while(1){
             buy_now=X/cookie_rate;
             buy_later=C/cookie_rate + X/(cookie_rate+F);
         		if(buy_now>buy_later){
                total_time+=C/cookie_rate;
                cookie_rate+=F;
             }
 
             else
             {   f = fopen("a.txt", "a");
                 total_time+=buy_now;
                 fprintf(f, "Case #%d: %.7lf\n",test+1,total_time);
                 count++;
 
                 break;
             }
 
         }
 
 	
 
    fclose(f);
    return;
 }
 
 int main(){
 	double input[101][3], arr[3];
 
    int flag=0,counter=0,i,test,j;
 
    FILE* file = fopen ("B-small-attempt0.in", "r");
 
    fscanf (file, "%d", &test);
 
 
    while (!feof (file)){
    	for(i=0;i<test;i++){
         for(j=0;j<3;j++){
         		fscanf (file, "%lf", &input[i][j]);
 			}
       }
    }
 
 
    for(i=0;i<test;i++){
 
       output(input[i][0],input[i][1],input[i][2],i);
    }
 
 
    return 0;
 }

