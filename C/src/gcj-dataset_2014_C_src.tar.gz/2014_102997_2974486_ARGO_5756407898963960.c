#include <stdio.h>
 
 int row1, row2;
 int grid1[5][5], grid2[5][5];
 
 int numSameCards(int* same);
 
 int main()
 {
 	FILE* fp = fopen("A-small.out", "w");
 	int T, t, i, j, numSame, same;
 
 	scanf("%d", &T);
 	for(t = 1; t <= T; t++) {
 		scanf("%d", &row1);
 		for(i = 1; i <= 4; i++)
 			for(j = 0; j < 4; j++)
 				scanf("%d ", &grid1[i][j]);
 
 		scanf("%d", &row2);
 		for(i = 1; i <= 4; i++)
 			for(j = 0; j < 4; j++)
 				scanf("%d ", &grid2[i][j]);
 
 		numSame = numSameCards(&same);
 		fprintf(fp, "Case #%d: ", t);
 		if(numSame == 1)
 			fprintf(fp, "%d\n", same);
 		else if(numSame > 1)
 			fprintf(fp, "Bad magician!\n");
 		else if(numSame == 0)
 			fprintf(fp, "Volunteer cheated!\n");
 	}
 
 	return 0;
 }
 
 int numSameCards(int* same) {
 	int i, j, ret = 0;
 
 	for(i = 0; i < 4; i++) {
 		for(j = 0; j < 4; j++) {
 			if(grid1[row1][i] == grid2[row2][j]) {
 				*same = grid1[row1][i];
 				ret++;
 			}
 		}
 	}
 
 	return ret;	
 }
