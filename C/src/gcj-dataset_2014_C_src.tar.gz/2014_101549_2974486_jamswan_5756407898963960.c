#include <stdio.h>
 int mat1[4][4];
 int mat2[4][4];
 
 int main() {
         int t,r1,r2;
         scanf("%d",&t);
         int i,j,k;
         int count = 0,ans;
         for(k=1;k<=t;k++) {
                 count = 0;
                 scanf("%d", &r1);
                 r1--;
                 for( i=0;i<4;i++ ) {
                         for(j=0;j<4;j++) {
                                 scanf("%d", &mat1[i][j]);
                         }
                 }
                 scanf("%d", &r2);
                 r2--;
                 for( i=0;i<4;i++ ) {
                         for(j=0;j<4;j++) {
                                 scanf("%d", &mat2[i][j]);
                         }
                 }
                 
                 for( i=0;i<4;i++) {
                         for(j=0;j<4;j++) {
                                 if(mat1[r1][i]==mat2[r2][j]){
                                         count++;
                                         ans = mat1[r1][i];
                                 }
                         }
                 }
                 
                 
                 if(count == 1)
                         printf("Case #%d: %d\n", k, ans);
                 else if(count == 0)
                         printf("Case #%d: Volunteer cheated!\n", k);
                 else
                         printf("Case #%d: Bad magician!\n", k);
         }
         return 0;
 }
