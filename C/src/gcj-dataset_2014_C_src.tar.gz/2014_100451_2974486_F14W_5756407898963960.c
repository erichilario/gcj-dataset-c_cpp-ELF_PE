#include <stdio.h>
 #include <stdlib.h>
 
 int main(){
 	int T, a;
 	int i, j;
 	int result = 0, mask = 0, current;
 	int padding[4];
 
 	scanf("%d", &T);
 	for (i = 1; i <= T; i++){
 		result = mask = 0;
 		printf("Case #%d: ", i);
 		scanf("%d",&a);
 		for (j = 1; j < a; j++){
 			scanf("%d%d%d%d", padding, padding + 1, padding + 2, padding + 3);
 		}
 		for (j = 0; j < 4; j++){
 			scanf("%d", &current);
 			result |= 0x1 << (current - 1);
 		}
 		for (j = a + 1; j <= 4; j++){
 			scanf("%d%d%d%d", padding, padding + 1, padding + 2, padding + 3);
 		}
 		scanf("%d", &a);
 		for (j = 1; j < a; j++){
 			scanf("%d%d%d%d", padding, padding + 1, padding + 2, padding + 3);
 		}
 		for (j = 0; j < 4; j++){
 			scanf("%d", &current);
 			mask |= (0x1 << (current - 1));
 		}
 		result &= mask;
 		if (!result) printf("Volunteer cheated!\n");
 		else{
 			current = 0;
 			for (j = 0; j < 16; j++){
 				if ((result & (0x1 << j)) != 0){
 					if (current != 0){
 						printf("Bad magician!\n");
 						goto next;
 					}
 					else{
 						current = j + 1;
 					}
 				}
 			}
 			printf("%d\n", current);
 		}
 next:	for (j = a + 1; j <= 4; j++){
 			scanf("%d%d%d%d", padding, padding + 1, padding + 2, padding + 3);
 		}
 	}
 //	system("pause");
 	return 0;
 }
