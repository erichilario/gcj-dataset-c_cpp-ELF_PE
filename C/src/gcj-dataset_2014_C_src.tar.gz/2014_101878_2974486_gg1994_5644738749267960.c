#include <stdio.h>
 #include <stdlib.h>
 
 double a[1010];
 double b[1010];
 
 int partition(double a[], int p, int r)
 {
         int i;
         int j;
         double pivot;
         double temp;
 
         i = p - 1;
         j = p;
         pivot = a[r];
 
 
         for(j; j <= r - 1; j++) {
                 if(a[j] <= pivot) {
                         i++;
                         temp = a[i];
                         a[i] = a[j];
                         a[j] = temp;
                 }
         }
         temp = a[i + 1];
         a[i + 1] = a[r];
         a[r] = temp;
 
         return (i + 1);
 }
 
 void quicksort(double a[], int p, int r)
 {
         int q;
 
         if(p >= r) {
 			return;
         }
         q = partition(a, p, r);
         quicksort(a, p, q - 1);
         quicksort(a, q + 1, r);
 }
 
 
 
 
 int deceitful(double a[], double b[], int n)
 {
 	int i;
 	int cnt = 0;
 	int min_a = 0;
 	int min_b = 0;
 	int max_b = n - 1;
 	int max_a = n - 1;
 	for (i = 0; i < n; ++i) {
 		if (a[min_a] > b[min_b]) {
 			min_b++;
 			cnt++;
 			min_a++;
 		} else if (a[min_a] < b[min_b]){
 			max_b--;
 			min_a++;
 		}
 	}
 	return cnt;
 }
 
 int war(double a1[], double b1[], int n)
 {
 	int i;
 	int cnt = 0;
 	int max_b1 = n - 1;
 	for (i = n - 1; i >= 0; --i) {
 		if (a1[i] > b1[max_b1]) {
 			cnt++;
 		} else {
 			max_b1--;
 		}
 	}
 	return cnt;
 	
 }
 
 int main()
 {
 	int t;
 	int i;
 	int j = 0;
 	scanf("%d", &t);
 	while (t--) {
 		int n;
 		j++;
 		scanf("%d", &n);
 		for (i = 0; i < n; ++i) {
 			scanf("%lf", &a[i]);
 		}	
 		for (i = 0; i < n; ++i) {
 			scanf("%lf", &b[i]);
 		}
 		quicksort(a, 0, n - 1);
 		//for (i = 0; i < n; ++i) {
 		//	printf("%lf ", a[i]);
 		//}
 		quicksort(b, 0, n - 1);
 		//printf("\n");
 		//for (i = 0; i < n; ++i) {
 		//	printf("%lf ", b[i]);
 		//}
 		//printf("\n");
 		int ans, ans1;
 		ans = deceitful(a, b, n);
 		ans1 = war(a, b, n);
 		printf("case #%d: %d %d\n", j, ans, ans1);
 	}
 	return 0;
 }

