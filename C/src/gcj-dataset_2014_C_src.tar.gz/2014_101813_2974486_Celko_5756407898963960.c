#include <stdio.h>
 #include <stdlib.h>
 
 //Constants
 
 #define T_MAX 100
 #define GRID_SIZE 4
 
 int toplel[100][2];
 
 
 void intersection(int a[4],int b[4], int t)
 {
 	int result[5];
 	int i, j;
 	int nb = 0;
 	
 	for (i = 0; i< 4; i++){
 		for (j = 0; j < 4; j++){
 			if (b[j] == a[i]){
 				result[nb] = b[j];
 				nb ++;
 				break;
 			}
 		}
 		
 	}
 	
 	if (nb == 0) toplel[t][0] = 0;
 	if (nb == 1) {toplel[t][0] = 1; toplel[t][1] = result[0];}
 	if (nb > 1) toplel[t][0] = 2;
 }
 
 
 
 
 int main(){
 
 	int tab[4][4];
 	int index1;
 	int index2;
 	int line1[4];
 	int line2[4];
 	int i = 0;
 	int T;
 	int currentT = 1;
 	int output[5];
 	
 	scanf("%d", &T);
 	
 	do{
 		//Read input 1
 		scanf("%d\n", &index1);
 		index1--;
 		
 		//Read input 2
 		for(i =0; i < 4; i++){
 			scanf("%d %d %d %d", &tab[i][0], &tab[i][1], &tab[i][2], &tab[i][3]);
 		}
 		for(i = 0; i < 4; i++){
 			line1[i] = tab[index1][i];
 		}
 		
 		//Read input 3
 		scanf("%d\n", &index2);
 		index2--;
 		
 		//Read input 4
 		for(i =0; i < 4; i++){
 			scanf("%d %d %d %d", &tab[i][0], &tab[i][1], &tab[i][2], &tab[i][3]);
 		}
 		for(i = 0; i < 4; i++){
 			line2[i] = tab[index2][i];
 		}
 	
 		intersection(line1, line2, currentT);
 		currentT++;
 	}while (currentT <= T);
 	
 	for (i = 1; i <= T; i++){
 		if (toplel[i][0] == 0) printf("Case #%d: Volunteer cheated!\n", i);
 		if (toplel[i][0] == 1) printf("Case #%d: %d\n", i, toplel[i][1]);
 		if (toplel[i][0] == 2) printf("Case #%d: Bad magician!\n", i);
 	}
 	
 
 
 	return 0;
 }

