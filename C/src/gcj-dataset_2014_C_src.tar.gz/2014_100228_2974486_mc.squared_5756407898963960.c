#include<stdio.h>
 int main()
 {
 	int a[100][4][4],a1[100][4][4],t,n[100],n1[100],i,j,k,res[100],r[4],flag[100];
 	for(i=0;i<100;i++)
 	{
 		flag[i]=0;
 	}
 	scanf("%d",&t);
 	for(i=0;i<t;i++)
 	{
 		scanf("%d",&n[i]);
 		for(j=0;j<4;j++)
 		{
 			for(k=0;k<4;k++)
 				{
 					scanf("%d",&a[i][j][k]);
 				}
 		}
 	scanf("%d",&n1[i]);
 	for(j=0;j<4;j++)
 	{
 		for(k=0;k<4;k++)
 			{
 				scanf("%d",&a1[i][j][k]);
 			}
 	}
 	}			
 	k=0;
 	do
 	{
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 				{
 					if(a[k][((n[k])-1)][i]==a1[k][((n1[k])-1)][j])
 						{		res[k]=a[k][n[k]-1][i];
 								flag[k]++;
 						}
 				}
 		}k++;
 	}while(k<t);
 		for(i=0;i<t;i++)
 {
 if(flag[i]==0)
 {
 printf("Case #%d: Volunteer cheated!",i+1);
 }
 else if(flag[i]==1)
 {
 printf("Case #%d: %d",i+1,res[i]);
 }
 else
 {
 printf("Case #%d: Bad magician!",i+1);
 }
 printf("\n");
 }
 }

