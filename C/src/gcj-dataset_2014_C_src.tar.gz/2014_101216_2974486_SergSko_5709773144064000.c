#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, char ** argv)
 {
     int n_cases, case_nr;
     float C, F, X;
     double cur_income, cur_farm_time, build_time;
     double new_income, new_farm_time, time_sum;
 
     scanf("%d", &n_cases);
     for (case_nr = 1; case_nr <= n_cases; case_nr++) {
         scanf("%f %f %f", &C, &F, &X);
         time_sum   = 0.0;
         cur_income = 2.0;
         while (1) {
             new_income    = cur_income + (double)F;
             build_time    = (double)C / cur_income;
             cur_farm_time = (double)X / cur_income;
             new_farm_time = (double)X / new_income + build_time;
             if (cur_farm_time <= new_farm_time) {
                 time_sum += cur_farm_time;
                 break;
             }
             time_sum  += build_time;
             cur_income = new_income;
         }
         printf("Case #%d: %.7f\n", case_nr, time_sum);
     }
     return 0;
 }

