#include<stdio.h>
 
 int main() {
 	int testcase;
 	double rate;
 	double c, f, x;
 	double time,presenttime,newtime,basetime;
 	FILE * file;
 	int i;
 	file = fopen("output.txt", "w");
 
 	scanf("%d",&testcase);
 
 	for (i = 1; i <= testcase; ++i) {
 		rate = 2.0;
 		scanf("%lf %lf %lf", &c, &f, &x);
 		basetime = 0;
 		do {
 			presenttime = x/rate;
 			newtime = c/rate + x/(rate+f);
 			if(newtime < presenttime)
 			{
 				basetime += c/rate;
 				rate += f;
 			}
 		} while (newtime < presenttime);
 
 		fprintf(file,"Case #%d: %.7f\n",i,basetime + x/rate);
 	}
 
 	fclose(file);
 
 	return 0;
 }

