#include<stdio.h>
 int main()
 {
     int a,b,y[4][4],z[4][4],i,j,c=0,k,t,T,p;
     scanf("%d",&T);
     for(p=0;p<T;p++)
     {
     scanf("%d",&a);
     for(i=0;i<4;i++)
     {
         for(j=0;j<4;j++)
         {
             scanf("%d",&y[i][j]);
         }
     }
     scanf("%d",&b);
     for(i=0;i<4;i++)
     {
         for(j=0;j<4;j++)
         {
             scanf("%d",&z[i][j]);
         }
     }
     for(j=0;j<4;j++)
     {
         for(k=0;k<4;k++)
         {
             if(y[a-1][j]==z[b-1][k])
             {
 
                 c++;
                 t=j;
             }
         }
     }
     if(c==1)
     {
         printf("Case #%d: %d\n",p+1,y[a-1][t]);
     }
     else if(c>1)
     {
         printf("Case #%d: Bad magician!\n",p+1);
     }
     else
     {
         printf("Case #%d: Volunteer cheated!\n",p+1);
     }
     c=0;
     }
 
     return 0;
 }

