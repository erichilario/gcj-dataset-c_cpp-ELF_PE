#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
  int test,i,j,k;
  int flag=0,row1,row2,new;
  int arr1[4][4], arr2[4][4];
  scanf("%d",&test);
  for (k=1;k<=test;k++)
  {
     scanf("%d",&row1);
     for(i=0;i<4;i++)
   {
   for(j=0;j<4;j++)
   {
    scanf("%d",&arr1[i][j]);
   }
   }
   scanf("%d",&row2);
    for(i=0;i<4;i++)
   {
   for(j=0;j<4;j++)
   {
    scanf("%d",&arr2[i][j]);
   }
   }
   
   
   for (i=0;i<4;i++)
   {
   for (j=0;j<4;j++)
   {
   if ( arr1[row1-1][i] == arr2[row2-1][j])
   {
         new= arr1[row1-1][i];
   flag+=1;
   }
   }
   }  
 if (flag==0)
 {
 printf("\nCase #%d: Volunteer cheated!",k);
 }
 else if (flag>1)
 {
 printf("\nCase #%d: Bad magician!",k);
 }
 else
 {
 printf("\nCase #%d: %d",k,new);
 }
 	
     flag=0;
     }
     return 0;
   } 

