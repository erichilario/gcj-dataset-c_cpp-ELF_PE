#include <stdio.h>
 
 void extract(char *line, int *arr) {
     int i;
     char *cp, *ep;
     for (i = 0, cp = line; i < 4; i++, cp = ep) {
         ep = strchr(cp, ' ');
         if (ep) {
             *ep++ = '\0';
         }
         arr[i] = atoi(cp);
     }
 }
 
 void compare(char *line1, char *line2) {
     int arr1[4], arr2[4];
     int count = 0, num = 0, i, j;
     static int tcase = 0;
     
     tcase++;
     
     /*
      * Extract numbers from lines
      */
     extract(line1, arr1);
     extract(line2, arr2);
     
     for (i = 0; i < 4; i++) {
         for (j = 0; j < 4; j++) {
             if (arr1[i] == arr2[j]) {
                 count++;
                 num = arr1[i];
             }
             if (count > 1) {
                 printf("Case #%d: Bad magician!\n", tcase);
                 return;
             }
         }
     }
     
     if (count == 0) {
         printf("Case #%d: Volunteer cheated!\n", tcase);
     } else {
         printf("Case #%d: %d\n", tcase, num);
     }
 }
 
 int main(int argc, char *argv[]) {
     int ans1 = 0, ans2 = 0, tcases = 0, i;
     char line[1024], line1[1024], line2[1024];
     /*
      * Get number of testcases
      */
     if (gets(line)) {
         tcases = atoi(line);
     }
     
     while (tcases > 0) {
         /*
          * Get answer 1
          */
         ans1 = atoi(gets(line));
         for (i = 1; i <= 4; i++) {
             if (ans1 == i) {
                 gets(line1);
             } else {
                 gets(line);
             }            
         }
         
         /*
          * Get answer 2
          */
         ans2 = atoi(gets(line));
         for (i = 1; i <=4; i++) {
             if (ans2 == i) {
                 gets(line2);
             } else {
                 gets(line);
             }
         }
         
         /*
          * Send to compare
          */
         compare(line1, line2);
         tcases--;
     }
     getch();
 }

