#include <stdio.h>
 #include <string.h>
 
 char grid[55][55];
 int T, R, C, M, i, j, k, r, c, pos, temp;
 
 char CountNeighbors(int i, int j){
 	int r = 0;
 	if(grid[i - 1][j - 1] == '*') r++;
 	if(grid[i - 1][j] == '*') r++;
 	if(grid[i - 1][j + 1] == '*') r++;
 	if(grid[i][j - 1] == '*') r++;
 	if(grid[i][j + 1] == '*') r++;
 	if(grid[i + 1][j - 1] == '*') r++;
 	if(grid[i + 1][j] == '*') r++;
 	if(grid[i +1][j + 1] == '*') r++;
 	return r + 48;
 }
 
 void Print(){
 	for(i = 0; i < R; i++){
 		for(j = 0; j < C; j++)
 			printf("%c", grid[i][j]);
 		printf("\n");
 	}
 }
 
 void Print2(){
 	for(i = 0; i < C; i++){
 		for(j = 0; j < R; j++)
 			printf("%c", grid[j][i]);
 		printf("\n");
 	}
 }
 
 int Fill(){
 	for(i = 0; i < r; i++)
 		for(j = 0; j < C; j++)
 			grid[i][j] = '*';
 	for(j = 0; j < c; j++)
 		grid[r][j] = '*';
 
 	for(j = c; j < C; j++){
 		grid[r][j] = CountNeighbors(i, j);
 		if(grid[i][j] == '0') return 1;
 	}
 
 	for(i = r + 1; i < R; i++)
 		for(j = 0; j < C; j++){
 			grid[i][j] = CountNeighbors(i, j);
 			if(grid[i][j] == '0') return 1;
 		}
 	return 0;
 }
 
 void Fill2(int pos){
 	for(j = c; j < C; j++)
 		grid[r][j] = '.';
 	for(i = r + 1; i < R; i++)
 		for(j = 0; j < C; j++)
 			grid[i][j] = '.';	
 	grid[R - 1][C - 1] = 'c';
 	if(pos == 0) Print();
 	else Print2();
 }
 
 void Init(){
 	for(i = 0; i < R; i++)
 		memset(grid[i], '.', C);
 }
 
 void Clear(){
 	for(i = 0; i < 55; i++)
 		memset(grid[i], '\0', 55);
 }
 
 int main(){
 	scanf("%d", &T);
 	for(k = 0; k < T; k++){		
 		Clear();
 		scanf("%d %d %d", &R, &C, &M);
 		if(R > C) pos = 0;
 		else{
 			pos = 1;
 			temp = R;
 			R = C;
 			C = temp;				
 		}	
 		Init();
 		r = M/C, c = M % C;				
 		printf("Case #%d:\n", k + 1);
 		if(Fill() == 1) Fill2(pos);	
 		else printf("Impossible\n");
 	}
 	return 0;
 }

