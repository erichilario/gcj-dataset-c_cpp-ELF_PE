#include<stdio.h>
 
 int main(void){
 
   int i, t;
   long double c, f, x;
   long double time_with, time_without, income_rate, time;
 
   scanf("%d", &t);
 
   for(i=1; i<= t; i++){
 
     income_rate = 2.0;
     time = 0.0;
 
     scanf("%Lf %Lf %Lf", &c, &f, &x);
 
     while(1){
 
       time_without = x/income_rate;
       time_with = c/income_rate + x/(income_rate + f);
 
       if(time_without < time_with){
         printf("Case #%d: %.7Lf\n", i, time + time_without);
         break;
       }
 
       time += c/income_rate;
       income_rate += f;
     }
   }
 
   return 1;
 }

