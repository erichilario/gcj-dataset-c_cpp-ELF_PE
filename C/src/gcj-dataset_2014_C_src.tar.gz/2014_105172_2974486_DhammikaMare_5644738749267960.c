/*
  * Problem D. Deceitful War - Qualification Round 2014 - Google Code Jam
  *
  * Author : Marasinghe, M.M.D.B. | dhammikammdb123@gmail.com
  * Date : 2014/04/12 13:28:31
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 #define SIZE 1000
 
 void scanArray(double array[], double array2[], int size);
 void sortArray(double array[], int size);
 void printArray(double array[], int size);
 
 int main(){
 	int T = 1, cases, blocks, nDeceitfulMarks, nWarMarks, i;
 	
 	scanf("%d", &cases);
 	
 	while(T<=cases){
 		nDeceitfulMarks = 0; nWarMarks = 0;
 		double naomisBlocks[SIZE] = {}, kensBlocks[SIZE] = {};
 		double naomisBlocksW[SIZE] = {}, kensBlocksW[SIZE] = {};
 		
 		scanf("%d", &blocks);
 		scanArray(naomisBlocks, naomisBlocksW, blocks);
 		scanArray(kensBlocks, kensBlocksW, blocks);
 		
 		sortArray(naomisBlocks, blocks);
 		sortArray(kensBlocks, blocks);
 		sortArray(naomisBlocksW, blocks);
 		sortArray(kensBlocksW, blocks);
 		
 		for(i=0; i<blocks; i++){
 			if(kensBlocks[0] < naomisBlocks[0]){
 				kensBlocks[0] = 0;
 				naomisBlocks[0] = 0;
 				nDeceitfulMarks++;
 			}else{
 				kensBlocks[0] = 0;
 				naomisBlocks[blocks-1] = 0;
 			}
 			sortArray(naomisBlocks, blocks);
 			sortArray(kensBlocks, blocks);
 		}
 		for(i=0; i<blocks; i++){
 			if(kensBlocksW[0] < naomisBlocksW[0]){
 				kensBlocksW[blocks-1] = 0;
 				naomisBlocksW[0] = 0;
 				nWarMarks++;
 			}else{
 				kensBlocksW[0] = 0;
 				naomisBlocksW[0] = 0;
 			}
 			sortArray(naomisBlocksW, blocks);
 			sortArray(kensBlocksW, blocks);	
 		}
 		
 		printf("Case #%d: %d %d\n", T, nDeceitfulMarks, nWarMarks);
 		
 		T++;
 	}
 	
 	return EXIT_SUCCESS;
 }
 
 void scanArray(double array[], double array2[], int size){
 	int i;
 	for(i=0; i<size; i++){
 		scanf("%lf", &array[i]);
 		array2[i] = array[i];
 	}
 }
 
 void sortArray(double array[], int size){
 	int i, j;
 	double temp;
 	for(i=0; i<SIZE; i++){
 		for(j=i+1; j<SIZE; j++){
 			if(array[i] < array[j]){
 				temp = array[i];
 				array[i] = array[j];
 				array[j] = temp;
 			}
 		}
 	}
 }

