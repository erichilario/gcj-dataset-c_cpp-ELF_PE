#include<stdio.h>
 #include<stdlib.h>
 
 int compare (const void * a, const void * b)
 {
   double da = *(double*) a;
   double db = *(double*) b;
   return (da > db) - (da < db);
 }
 
 
 int main()
 {
 	
 	int t, k, i, j, n, x, y;
 	double nao[1000], ken[1000];
 	
 	freopen("D-small-attempt2.in", "r+", stdin);
 	freopen("output.txt", "w+", stdout);
 	
 	
 	scanf("%d",&t);
 	
 	for(k=1; k<=t; k++)
 	{
 		
 		scanf("%d",&n);
 		
 		for(i=0; i<n; i++)
 			scanf("%lf",&nao[i]);
 		for(i=0; i<n; i++)
 			scanf("%lf",&ken[i]);
 		
 		
 		qsort(nao, n, sizeof(double), compare);
 		qsort(ken, n, sizeof(double), compare);
 		
 		
 /*
 		printf("\n");
 		for(i=0; i<n; i++)
 			printf("%.2lf  ",nao[i]);
 		printf("\n");
 		for(i=0; i<n; i++)
 			printf("%.2lf  ",ken[i]);
 		printf("\n");
 	// */
 		
 		i = 0;
 		j = n - 1;
 		x = 0;
 		
 		while(i<n)
 		{
 			if(nao[i]>ken[i])
 			{
 				i++;
 			}
 			else if(i<n && j>=0 && nao[i]<ken[j])
 			{
 				x++;
 				i++;
 				j--;
 			}
 			else
 				break;
 			
 		}
 		
 		x = n - x;
 		
 		
 		i = 0;
 		j = 0;
 		y = 0;
 		
 		while(i<n && j<n)
 		{
 			while(i<n && j<n && nao[i]>ken[j])
 				j++;
 			
 			if(i<n && j<n)
 				y++;
 			
 			i++;
 			j++;
 			
 		}
 		
 		
 		y = n - y;
 		
 		for(i=n-1; i>=0; i--)
 		{
 			if(nao[i]>ken[n-1])
 				y--;
 			else
 				break;
 		}
 		
 		printf("Case #%d: %d %d\n", k, x, y);
 		
 	}
 	
 	
 	return 0;
 }

