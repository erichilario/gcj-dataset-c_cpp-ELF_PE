#include <stdio.h>
 
 int main(void) {
 	int t,p;
 	double c,x,f,ans,a;
 
 	scanf("%d",&t);
 	for(p=1;p<=t;p++)
 	{
 		ans=0;
 		scanf("%lf",&c);
 		scanf("%lf",&f);
 		scanf("%lf",&x);
 		a=2;
 		for(;;)
 		{
 			if(((c/a)+(x/(a+f)))<(x/a))
 			{
 				ans+=c/a;
 				a+=f;//printf("if-%lf %d\n",ans,a);
 			}
 			else
 			{
 				ans+=x/a;//printf("else-%lf\n",ans);
 				break;
 			}
 		}
 		if(p!=t) printf("Case #%d: %.7lf\n",p,ans);
 		else printf("Case #%d: %.7lf",p,ans);
 	}
 	return 0;
 }

