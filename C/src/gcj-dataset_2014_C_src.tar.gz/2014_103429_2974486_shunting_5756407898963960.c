#include <stdio.h>
 
 int grid1[4][4];
 int grid2[4][4];
 int ans1;
 int ans2;
 int *candlist;
 int ncand;
 
 int 
 main(void) {
 	int ncases;
 	int seq;
 	int i, j;
 	
 	scanf("%d", &ncases);
 	for (seq = 0; seq < ncases; seq++) {
 		scanf("%d", &ans1);
 		for (i = 0; i < 4; i++) {
 			for (j = 0; j < 4; j++) {
 				scanf("%d", &grid1[i][j]);
 			}
 		}
 		scanf("%d", &ans2);
 		for (i = 0; i < 4; i++) {
 			for (j = 0; j < 4; j++) {
 				scanf("%d", &grid2[i][j]);
 			}
 		}
 		candlist = grid1[ans1 - 1];
 		ncand = 0;
 		int val = 0;
 		for (i = 0; i < 4; i++) {
 			int v = candlist[i];
 			for (j = 0; j < 4; j++) {
 				if (v == grid2[ans2 - 1][j]) {
 					ncand++;
 					val = v;
 					break;
 				}
 			}
 		}
 
 		printf("Case #%d: ", seq + 1);
 		if (ncand == 0) {
 			printf("Volunteer cheated!");
 		} else if (ncand == 1) {
 			printf("%d", val);
 		} else {
 			printf("Bad magician!");
 		}
 		printf("\n");
 	}
 	return 0;
 }

