#include<stdio.h>
 int main()
 {
     double c,f,x;
     int m,n,i=0,e=0;
     scanf("%d",&n);
     m=n;
 double b[n];
     while(n>=1&&n<=100)
     {
         scanf("%lf %lf %lf",&c,&f,&x);
 
      double a[1000];
      double t=0,t1;
      for(i=0;i<1000;i++)
      {   t1=t+(x/(2+(i*f)));
          a[i]=t1;
          if(t1>x/2)break;
          else t=t+(c/(2+(i*f)));
     }
 
 
            int j;
       double min;
       min=a[0];
       for(j=1;j<i;j++)
       {
       if(min>a[j])min=a[j];
       }
 b[e]=min;
 e++;
  n--;
     }
     for(i=0;i<m;i++)
      {printf("Case #%d: %lf\n",i+1,b[i]);
      }
 
 
 
       return 0;
 
     }
 

