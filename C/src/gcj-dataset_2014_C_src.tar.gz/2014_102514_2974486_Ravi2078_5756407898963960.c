#include <stdio.h>
 
 #define DECK 16
 
 int solution(int s1, int a1[], int s2, int a2[])
 {
     int i1 = (s1-1)*4;
     int i2 = (s2-1)*4;
     int c = 0, ele = 0;
     int i, j;
     for (i = 0; i < 4; ++i)
         for (j = 0; j < 4; ++j)
             if (a1[i1+i] == a2[i2+j])
             {
                 c++;
                 ele = a1[i1+i];
                 // printf("%d, %d\n", c, ele);
             }
 
     if (c == 1)
         return ele;
     else if (c == 0)
         return -1;
     else
         return 0;
 }
 
 int main(int argc, char const *argv[])
 {
     int cases = 0;
     scanf("%d", &cases);
     int i;
     for (i = 0; i < cases; ++i)
     {
         int s1, s2, a1[DECK], a2[DECK];
         scanf("%d", &s1);
         int j;
         for (j = 0; j < DECK; ++j)
         {
             scanf("%d", &a1[j]);
         }
         scanf("%d", &s2);
         for (j = 0; j < DECK; ++j)
         {
             scanf("%d", &a2[j]);
         }
 
         int solve = solution(s1, a1, s2, a2);
         printf("Case #%d: ", i+1);
         switch (solve) {
             case 0:
                 printf("Bad magician!\n");
                 break;
             case -1:
                 printf("Volunteer cheated!\n");
                 break;
             default:
                 printf("%d\n", solve);
                 break;
         }
     }
     return 0;
 }

