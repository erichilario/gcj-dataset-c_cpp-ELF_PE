#include <stdio.h>
 
 double C, F, X;
 
 int main()
 {
 	FILE* fp = fopen("B-small.out", "w");
 	int T, t;
 	double rate;
 	double totT, stopT, goT, buyT, waitT;
 
 	scanf("%d", &T);
 	for(t = 1; t <= T; t++) {
 		// input
 		scanf("%lf %lf %lf", &C, &F, &X);
 
 		// initialize
 		rate = 2.0;
 		totT = 0.0;
 
 		// for the 1st choice
 		stopT = totT + (X / rate);
 		buyT = (C / rate);
 		rate = rate + F;
 		waitT = (X / rate);
 		goT = totT + buyT + waitT;
 
 		// find the minimum total time
 		while(stopT > goT) {
 			totT = totT + buyT;
 			stopT = goT;
 			buyT = (C / rate);
 			rate = rate + F;
 			waitT = (X / rate);
 			goT = totT + buyT + waitT;
 		}
 
 		// output
 		fprintf(fp, "Case #%d: %.7lf\n", t, stopT);
 	}
 
 	return 0;
 }
