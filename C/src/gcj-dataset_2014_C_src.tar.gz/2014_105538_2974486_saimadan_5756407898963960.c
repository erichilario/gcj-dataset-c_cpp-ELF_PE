#include<stdio.h>
    FILE *fp;
 int fileinput()
 {
     int c;
         int temp=0;
         while((c=(char)fgetc(fp))==' '||c=='\n');
         while(c!='\n'&&c!=' ')
         {
             temp=temp*10+c-'0';
             c=(char)fgetc(fp);
         }
       //  printf("%d",temp);
     return temp;
 }
 void fun(int *a)
 {
     int i,j;
     int t;
     for(i=1;i<=4;i++)
         {
          for(j=0;j<4;j++)
          {
              t=fileinput();
     //         scanf("%d",&t);
              a[t]=i;
          }
         }
 }
 int main()
 {
     int t;
         fp=fopen("a.in","r");
     FILE *fop;
     fop=fopen("out.txt","w");
     t=fileinput();
     //printf("%d",t);
     //scanf("%d",&t);
     int m,n;
     int I,i,j;
     for(I=1;I<=t;I++)
     {
         int a[17]={0},b[17]={0};
         m=fileinput();
         //scanf("%d",&m);
         fun(a);
         n=fileinput();
         //scanf("%d",&n);
         fun(b);
 
 
         int count=0;
         int val;
         for(i=1;i<=16;i++)
         {
             if(a[i]==m&&b[i]==n)
           {
               val=i;
                  count++;
               if(count>1)
                  break;
           }
         }
         if(count==0)
         {
             fprintf(fop,"Case #%d: Volunteer cheated!\n",I);
         }
         else if(count==2)
         {
             fprintf(fop,"Case #%d: Bad magician!\n",I);
         }
         else
         {
             fprintf(fop,"Case #%d: %d\n",I,val);
         }
 
     }
     return 0;
 }

