
 #include <stdio.h>
 
 int main(void)
 {
     FILE* fp = fopen("input", "r");
 
     if(fp == NULL)
         return 0;
 
     int numCases;
     fscanf(fp, "%d\n", &numCases);
 
     for(int c = 0; c < numCases; c++)
     {    
         int a1;
         int a2;
 
         int a1cards[4];
         int a2cards[4];
 
         fscanf(fp, "%d\n", &a1);
 
         a1--;
 
         for(int i = 0; i < 4; i++)
         {
             if(i == a1)
             {
                 fscanf(fp, "%d %d %d %d\n", &a1cards[0], &a1cards[1], &a1cards[2], &a1cards[3]);
             }
             else
             {
                 fscanf(fp, "%*d %*d %*d %*d\n");
             }
         }
 
         fscanf(fp, "%d\n", &a2);
         
         a2--;
 
         for(int i = 0; i < 4; i++)
         {
             if(i == a2)
             {
                 fscanf(fp, "%d %d %d %d\n", &a2cards[0], &a2cards[1], &a2cards[2], &a2cards[3]);
             }
             else
             {
                 fscanf(fp, "%*d %*d %*d %*d\n");
             }
         }
 
         int numMatches = 0;
         int answer;
         for(int i = 0; i < 4; i++)
             for(int j = 0; j < 4; j++)
             {
                 if(a1cards[i] == a2cards[j])
                 {
                     numMatches++;
                     answer = a1cards[i];
                 }
             }
 
         printf("Case #%d: ", (c+1));
         if(numMatches == 0)
         {
             printf(" Volunteer cheated!\n");
         }
         else if(numMatches == 1)
         {
             printf(" %d\n", answer);
         }
         else
         {
             printf(" Bad magician!\n");
         }
     }
 
     fclose(fp);
 }
 

