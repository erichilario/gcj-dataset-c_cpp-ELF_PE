#include<stdio.h>
 #include<math.h>
 #define DEBUG if(0)
 int main()
 {
     double C,F,X,t;
     int n,T,i,j=0;
     scanf("%d",&T);
     while(T--)
     {   j++;
         scanf("%lf %lf %lf",&C,&F,&X);
         if(C<=X)
             n=ceil( ((X-C)/C) - 2.0/F  );
         else
             n=0;
         t=0;
         if(n<0)n=0;
         for(i=0;i<n;i++)
         {
             t+=(C/(2.0+((double)i)*F));
         }
         t+=(X/(2.0+((double)n)*F));
         printf("Case #%d: %0.7lf",j,t);
         DEBUG printf("Case #%d: %d",j,n);
         if(T!=0)printf("\n");
     }
 
         return 0;
 }

