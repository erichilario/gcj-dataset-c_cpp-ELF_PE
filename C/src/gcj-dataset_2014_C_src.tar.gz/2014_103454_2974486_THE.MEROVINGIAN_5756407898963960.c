#include<stdio.h>
 void main(){
     FILE *in_file=fopen("A-small-attempt4.in","r");
     FILE *out_file=fopen("Data.txt","w");
 int a,l,j,k,m,b1,b2,c[4][5],d[4][5],e,n;
 fscanf(in_file,"%d",&a);
 
 if(a<1||a>100)return;
 int i=1;
 while(i<=a){
     fscanf(in_file,"%d",&b1);
     //printf("%d\n",b1);
     if(b1<1||b1>4)return;
     for(l=0;l<4;l++)
     fscanf(in_file,"%d %d %d %d",&c[l][0],&c[l][1],&c[l][2],&c[l][3]);
     //printf("%d %d %d %d\n",&c[l][0],&c[l][1],&c[l][2],&c[l][3]);
     fscanf(in_file,"%d",&b2);
     //printf("%d\n",b2);
     if(b2<1||b2>4)return;
     for(m=0;m<4;m++)
     fscanf(in_file,"%d %d %d %d",&d[m][0],&d[m][1],&d[m][2],&d[m][3]);
     //printf("%d %d %d %d\n",&d[m][0],&d[m][1],&d[m][2],&d[m][3]);
 int count=0;
 for(j=0;j<4;j++){
     for(k=0;k<4;k++){
         if(c[b1-1][j]==d[b2-1][k]){
             count++;
             e=c[b1-1][j];
         }
     }
 }
 if(count==0)fprintf(out_file,"Case #%d: Volunteer cheated!\n",i);
 else if(count>1)fprintf(out_file,"Case #%d: Bad magician!\n",i);
 else fprintf(out_file,"Case #%d: %d\n",i,e);
 i++;
 }
 
 }

