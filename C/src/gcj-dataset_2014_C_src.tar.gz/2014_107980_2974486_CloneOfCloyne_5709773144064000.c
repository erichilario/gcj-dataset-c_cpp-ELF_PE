#include <stdlib.h>
 #include <stdio.h>
 
 double solve(double C, double F, double X) {
 	double time = 0.0;
 	double rate = 2.0;
 	while (1) {
 		if ((C/rate) + X/(rate+F) < (X/rate)) {
 			time += C/rate;
 			rate += F;
 		} else {
 			return time + (X/rate);
 		}
 	}
 }
 
 int main(int argc, char** argv) {
 	int T;
 	scanf("%d", &T);
 	for (int t=0; t<T; t++) {
 		double C, F, X;
 		scanf("%lf", &C);
 		scanf("%lf", &F);
 		scanf("%lf", &X);
 		printf("Case #%d: %.16lf\n", t+1, solve(C, F, X));
 	}
 }
