#include<stdio.h>
 int main()
 {
     int T;
     scanf("%d",&T);
     double c,f,x,left,right,total;
     int i;
     double ans[T];
     for(i=0;i<T;i++)
     {
         scanf("%lf%lf%lf",&c,&f,&x);
         double b=2;
         double count=0;
         if(x<c)
         {
            ans[i]=x/b;
             //printf("Case #%d: %0.7lf\n",i,temp);
         }
         else
         {
             count=x/b;
             left=0;
             while(1)
             {
               //  printf("bruce %d",i);
                 getchar();
                      left+=c/b;
                     b+=f;
                     double right=x/b;
 
                     double total=left+right;
                     if(total<=count)
                     {
                         count=total;
                     }
                     else
                         break;
             }
             ans[i]=count;
         }
     }
     for(i=0;i<T;i++)
     {
         printf("Case #%d: %0.7lf\n",i+1,ans[i]);
     }
     return 0;
 }

