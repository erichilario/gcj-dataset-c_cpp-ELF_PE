#include <stdio.h>
 int main()
 {
     int t;
     scanf ("%d",&t);
     int i;
     for (i=1;i<=t;i++)
     {
         int A[4][4],B[4][4],j,k,a,b,l,m=0;
         scanf("%d",&a);
         for (j=0;j<4;++j)
             for (k=0;k<4;++k)
             scanf("%d",&A[j][k]);
         scanf ("%d",&b);
         for (j=0;j<4;++j)
             for (k=0;k<4;++k)
             scanf("%d",&B[j][k]);
         for (j=0;j<4;++j)
         {
             for (k=0;k<4;++k)
             {
                 if (A[a-1][j]==B[b-1][k])
                 {
                     l=A[a-1][j];
                     m++;
                 }
             }
         }
         if (m==1)
             printf("Case #%d: %d\n",i,l);
         else if (m>1)
             printf("Case #%d: Bad magician!\n",i);
         else
             printf("Case #%d: Volunteer cheated!\n",i);
     }
     return (0);
 }

