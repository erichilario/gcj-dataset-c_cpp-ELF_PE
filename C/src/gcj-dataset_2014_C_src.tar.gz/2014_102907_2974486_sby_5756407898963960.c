#include <stdio.h>
 #define MAX 4
 
 int main(){
 	int t,n,m,a[MAX],b[MAX],i,j,k,temp,count;
 
 	scanf("%d",&t);
 
 	for(k = 1;k<=t;k++){
 		scanf("%d",&n);
 
 		for(i = 0;i<MAX;i++)
 			for(j = 0;j<MAX;j++){
 				scanf("%d",&temp);
 
 				if(i == n-1)
 					a[j] = temp;
 			}
 
 		scanf("%d",&m);
 
 		for(i = 0;i<MAX;i++)
 			for(j = 0;j<MAX;j++){
 				scanf("%d",&temp);
 
 				if(i == m-1)
 					b[j] = temp;
 			}
 
 		count = 0;
 
 		for(i = 0;i<MAX;i++)
 			for(j = 0;j<MAX;j++)
 				if(a[i] == b[j]){
 					temp = a[i];
 					count++;
 				}
 
 		printf("Case #%d: ",k);
 
 		if(count == 1)
 			printf("%d\n",temp);
 		else if(count == 0)
 			printf("Volunteer cheated!\n");
 		else 
 			printf("Bad magician!\n");
 	}
 
 	return 0;
 }
