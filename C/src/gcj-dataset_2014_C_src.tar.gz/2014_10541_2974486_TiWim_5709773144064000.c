#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
   int k=0,i,j;
   
   double* time;
   int nbCases;
   double farm,gain,maxCookies;
   double tmp;
   //number of cases
   scanf("%d",&nbCases);
   time=(double*)malloc(nbCases * sizeof(double));
   while(k<nbCases)
     {
       scanf("%lf %lf %lf",&farm,&gain,&maxCookies);
       tmp=maxCookies;
       time[k]=tmp/2.0;
       i=0;
       while(time[k]<tmp)
 	{
 	  tmp=time[k];
 	  i++;	 
 	  time[k]=0;
 	  for(j=0;j<i;j++)
 	    time[k]+=farm/(j*gain +2.0);
 	  time[k]+=maxCookies/(i*gain+2.0);
 	}
       time[k]=tmp;
       k++;
     }
   //printing
   for(k=0;k<nbCases;k++)
     printf("Case #%d: %.7lf\n",k+1,time[k]);
   return 0;
 }

