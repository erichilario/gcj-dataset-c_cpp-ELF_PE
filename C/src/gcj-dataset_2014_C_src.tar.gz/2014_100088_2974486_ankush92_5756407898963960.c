#include<stdio.h>
 
 int main()
 {
 	
 	int i, j, k, t, count, ans;
 	int val1, val2;
 	int inp1[4][4];
 	int inp2[4][4];
 	
 	freopen("A-small-attempt1.in", "r+", stdin);
 	freopen("output.txt", "w+", stdout);
 	
 	scanf("%d",&t);
 	
 	
 	for(k=1; k<=t; k++)
 	{
 		scanf("%d",&val1);
 		for(i=0; i<4; i++)
 			for(j=0; j<4; j++)
 				scanf("%d",&inp1[i][j]);
 				
 		scanf("%d",&val2);
 		for(i=0; i<4; i++)
 			for(j=0; j<4; j++)
 				scanf("%d",&inp2[i][j]);
 		
 			
 		count = 0;
 		
 		for(i=0; i<4; i++)
 		{
 			for(j=0; j<4; j++)
 			{
 				if(inp1[val1-1][i]==inp2[val2-1][j])
 				{
 					count++;
 					ans = inp1[val1-1][i];
 				}
 			}
 		}
 		
 		
 		
 		if(count==0)
 			printf("Case #%d: Volunteer cheated!\n",k);
 		else if(count==1)
 			printf("Case #%d: %d\n", k, ans);
 		else
 			printf("Case #%d: Bad magician!\n", k);
 		
 	}
 	
 	
 	
 	
 	return 0;
 }
 

