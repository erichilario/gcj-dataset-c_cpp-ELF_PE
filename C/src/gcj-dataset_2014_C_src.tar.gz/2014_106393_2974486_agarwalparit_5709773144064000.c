#include<stdio.h>
 
 int main()
 {
 	int t,l=1;
 	int i,j;
 	double c,f,x;
 	scanf("%d",&t);
 	while(l<=t)
 	{
 		scanf("%lf %lf %lf",&c,&f,&x);
 		int count=0;
 		double ans=0;
 		while(1)
 		{
 			if( x/(2+f*count) - (c/(2+f*count) + x/(2+f*(count+1)) ) > 0  )
 			{
 				ans += c/(2+f*count);
 				count++;
 			}
 			else
 				break;
 		}
 		ans+= x/(2+f*count);
 		printf("Case #%d: %.7lf\n",l,ans);
 		
 		l++;
 	}
 	return 0;
 }

