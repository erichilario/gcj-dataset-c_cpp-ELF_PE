
 #include<stdio.h>
 int main()
 {
 	int cnt=0,w,n,c1[4][4],c2[4][4],i,j,r1,r2,f[16],card=0;
 	scanf("%d",&n);
 	while(cnt<100)
 	{
 		for(i=0;i<16;i++)
 			f[i]=0;
 		w=0,card=0;
 		scanf("%d",&r1);
 		for(i=0;i<4;i++)
 		for(j=0;j<4;j++)
 			scanf("%d",&c1[i][j]);
 		scanf("%d",&r2);
 		for(i=0;i<4;i++)
 		for(j=0;j<4;j++)
 			scanf("%d",&c2[i][j]);
 		i=(r1-1);
 		for(j=0;j<4;j++)
 			f[(c1[i][j])-1]=1;
 		i=r2-1;
 		for(j=0;j<4;j++)
 		{
 			if(f[(c2[i][j])-1]==1)
 			{
 				w++;
 				card=c2[i][j];
 			}		
 		}
 		cnt++;
 		printf("Case #%d: ",cnt);
 		if(w==0)
 			printf("Volunteer cheated!\n");
 		else if(w==1)
 			printf("%d\n",card);
 		else
 			printf("Bad magician!\n");
 	}
 }

