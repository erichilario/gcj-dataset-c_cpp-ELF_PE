#include<stdio.h>
 double C,F,X;
 #define min(a,b) (((a)<(b))?(a):(b))
 int main()
 {
     double rem,cur,one,two,time;
     int T,i;
     scanf("%d",&T);
 
     for(i=1;i<=T;i++)
     {
         scanf("%lf%lf%lf",&C,&F,&X);
 
         rem=X;
         cur=2;
         if(rem<=C)
         {
             time=X/cur;
         }
         else
         {
             cur=2.0;
             one=0;
             two=X/cur;
             time=one+two;
             do{
                 time=one+two;
                 one=one+C/cur;
                 two=X/(cur+F);
                 cur+=F;
             }while(time>one+two);
         }
         printf("Case #%d: %.7lf\n",i,time);
 
     }
     return 0;
 }
 

