#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
 int T;
 
 scanf("%d",&T);
 if((T>100)||(T<1))
 	perror("out of limit");
 int i;
 int choice[2*T];
 int grid[2*T][16];
 int j;
 for(i=0;i<2*T;i++)
 	{
 	scanf("%d",&choice[i]);	
 	for(j=0;j<16;j++)
 		{
 		scanf("%d",&grid[i][j]);
 
 		}
 	}
 
 int temp=0;
 int ans;
 int count=0;
 int gnum=0;
 for(i=0;i<2*T;i+=2)
 	{gnum++;
 	//if(choice[T])
 	for(j=4*(choice[i]-1);j<4*choice[i];j++)
 		{
 		for(temp=4*(choice[i+1]-1);temp<4*choice[i+1];temp++)
 			{
 			if(grid[i][j]==grid[i+1][temp])
 				{
 				ans=grid[i][j];
 				count++;
 				}
 			//printf("%d ",grid[T][j]);
 			}
 		//printf("count: %d, ans: %d\n",count, ans);
 		}
 	if(count!=1)
 		{
 		if(count==0)
 			printf("Case #%d: Volunteer cheated!\n",gnum);
 		else
 			printf("Case #%d: Bad magician!\n",gnum);	
 		}
 	else
 		printf("Case #%d: %d\n",gnum,ans);
 	count=0;
 	}
 	
 	//printf("\n");
 
 }

