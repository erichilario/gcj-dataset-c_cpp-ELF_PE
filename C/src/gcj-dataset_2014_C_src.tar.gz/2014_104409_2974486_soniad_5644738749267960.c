#include<stdio.h>
 #include<stdlib.h>
 
 struct player
 {
 long double wt;
 int iden;
 int vis;
 };
 
 struct player arr[20];
 
 void merge(struct player arr[],int min,int mid,int max)
 {
 struct player tmp[20];
 int i,j,k,m; 
 j=min;
 m=mid+1;
 for(i=min; j<=mid && m<=max ; i++)
 	{
 	if(arr[j].wt<=arr[m].wt)
 		{
 		tmp[i].wt=arr[j].wt;
 		tmp[i].iden=arr[j].iden;
 		tmp[i].vis=arr[j].vis;
 		j++;
      		}
      	else
      		{
          	tmp[i].wt=arr[m].wt;
 		tmp[i].iden=arr[m].iden;
 		tmp[i].vis=arr[m].vis;
 	        m++;
      		}
   	}
 if(j>mid)
 	{
 	for(k=m; k<=max; k++)
 		{
 	        tmp[i].wt=arr[k].wt;
 		tmp[i].iden=arr[k].iden;
 		tmp[i].vis=arr[k].vis;
         	i++;
      		}
   	}
 else
 	{
 	for(k=j; k<=mid; k++)
      		{
 	        tmp[i].wt=arr[k].wt;
 		tmp[i].iden=arr[k].iden;
 		tmp[i].vis=arr[k].vis;
         	i++;
      		}
   	}
 for(k=min; k<=max; k++)
 	{
 	arr[k].wt=tmp[k].wt;
 	arr[k].iden=tmp[k].iden;
 	arr[k].vis=tmp[k].vis;
 	}
 }
 
 void part(struct player arr[],int min,int max)
 {
 int mid;
 if(min<max)
 	{
    	mid=(min+max)/2;
    	part(arr,min,mid);
    	part(arr,mid+1,max);
    	merge(arr,min,mid,max);
  	}
 }
 
 int main()
 {
 int T;
 
 scanf("%d",&T);
 //if((T>100)||(T<1))
 
 int i,j,k;
 int input[T];
 struct player A[T][2000];
 
 for(i=0;i<T;i++)
 	{
 	scanf("%d",&input[i]);
 	for(j=0;j<input[i];j++)
 		{
 		scanf("%Lf",&A[i][j].wt);
 		A[i][j].iden=0;
 		A[i][j].vis=0;
 		//printf("A[%d][%d]:%d\n",i,j,A[i][j].iden);
 		}	
 	for(j=input[i];j<2*input[i];j++)
 		{
 		scanf("%Lf",&A[i][j].wt);
 		A[i][j].iden=1;
 		A[i][j].vis=0;
 		//printf("A[%d][%d]:%d\n",i,j,A[i][j].iden);
 		}
 	
 	}
 
 int gnum=0;
 int temp[2000];
 int dcount=0;
 int count=0;
 int end=0;
 int end1=0;
 int ciden=0;
 for(i=0;i<T;i++)
 	{
 	gnum++;
 	part(A[i],0,2*input[i]-1);
 	/*for(j=0;j<(2*input[i]);j++)
 		{
 		printf("A[%d][%d]:%Lf,%d,%d\n",i,j,A[i][j].wt,A[i][j].iden,A[i][j].vis);
 		}
 	*/
 	for(j=0;j<(2*input[i]);j++)
 		{
 		//printf("A[%d][%d]:%Lf\n",i,j,A[i][j].wt);
 		if(A[i][j].iden==0)
 			{
 			end++;
 			for(k=j;k>=0;k--)
 				{
 				if((A[i][k].iden==1)&&(A[i][k].vis==0))
 					{
 					A[i][k].vis=1;
 					dcount++;
 					break;
 					}
 				}
 			}
 		if(end==input[i])
 			break;
 
 		}
 	for(j=0;j<(2*input[i]);j++)
 		{
 		A[i][j].vis=0;
 		}
 	for(j=(2*input[i]-1);j>=0;j--)
 		{
 		//printf("j:%d,A[%d][%d]:%Lf\n",j,i,j,A[i][j].wt);
 
 			if(j==((2*input[i]-1))&&(A[i][j].iden==0))
 				{
 				count++;
 				}
 			else
 				{
 				//printf("A[i][j]:%Lf\n",A[i][j].wt);
 				if(A[i][j].iden==0)
 					{
 					for(k=j;k<(2*input[i]);k++)
 						{
 						//printf("**********A[%d][%d]:%Lf,%d,%d\n",i,k,A[i][k].wt,A[i][k].iden,A[i][k].vis);
 						if((A[i][k].iden==1)&&(A[i][k].vis==0))
 							{
 							//printf("###A[%d][%d]:%Lf\n",i,k,A[i][k].wt);
 							A[i][k].vis=1;
 							ciden++;
 							break;
 							}
 						}
 					if((!ciden))
 						{
 						//printf("______A[%d][%d]:%Lf\n",i,k,A[i][k].wt);
 						count++;
 						}
 					}
 				}
 				
 			ciden=0;
 	
 
 		}
 
 	printf("Case #%d: %d %d\n",gnum,dcount,count);
 	end=0;
 	dcount=0;
 	count=0;
 	}
 }

