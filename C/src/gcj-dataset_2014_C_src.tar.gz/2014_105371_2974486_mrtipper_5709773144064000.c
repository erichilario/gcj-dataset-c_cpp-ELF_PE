#include <stdio.h>
 #include <stdlib.h>
 
 double
 readNum() {
   double val;
   scanf( "%lf", &val );
   return val;
 }
 
 void
 testCase( FILE* fo, int n ) {
   double fCost, fRate, targetCookies;
   double rate = 2;
   double time = 0;
   double lastTime = 0;
   double newTime = 0;
 
   printf( "testCase: %d\n", n );
 
   fCost = readNum();
   fRate = readNum();
   targetCookies = readNum();
   printf( "fCost: %lf, fRate: %lf, tCookie: %lf\n", fCost, fRate, targetCookies );
 
   lastTime = targetCookies/rate;
 
   while( 1 ) {
     time += fCost/rate;
     rate += fRate;
     newTime = time + targetCookies/rate;
     if( newTime > lastTime ) {
       printf( "bestTime: %0.7lf\n", lastTime );
       fprintf( fo, "Case #%d: %0.7lf\n", n, lastTime );
       break;
     } else {
       lastTime = newTime;
     } 
   }
 }
 
 int
 main( int argc, char** argv ) {
   int numCases ;
   int i;
   FILE* fo = fopen( "output.txt", "w");
 
   scanf( "%d", &numCases );
   printf( "numCases: %d\n", numCases );
   for( i = 0; i < numCases; ++i ) {
     testCase( fo, i + 1 );
   }
   return 0;
 }

