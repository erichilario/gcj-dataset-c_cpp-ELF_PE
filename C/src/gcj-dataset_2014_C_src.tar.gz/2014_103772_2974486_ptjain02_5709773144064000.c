#include<stdio.h>
 int main()
 {
 	int t,i,j;
 	FILE *p;
 	double  output[100];
 	p=fopen("nik.txt","r");
 	fscanf(p,"%d",&t);
 	for(i=0;i<t;i++)
 	{
 	double c,f=0,x,time=0,rate=2;
 		fscanf(p,"%lf %lf %lf",&c,&f,&x);
 		while((x/rate) > (x/(rate+f)+c/rate))
 		{
 			time+=c/rate;
 			rate+=f;
 		}
 	time=time+x/rate;
 	output[i]=time;
 		
 		
 		
 	
 	}
 	fclose(p);
 	p=fopen("output2.txt","w");
 		for(i=0;i<t;i++)
 		fprintf(p,"Case #%d: %.7f\n",i+1,output[i]);
 		fclose(p);
 		return 0;
 	
 }

