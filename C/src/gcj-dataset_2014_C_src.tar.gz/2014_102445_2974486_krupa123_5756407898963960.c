#include<stdio.h>
 int main()
 {
 	int a[4],b[4],c1[4][4],c2[4][4];
 	int i=0,j=0,test,n1,n2;
 	FILE *ipf=fopen("A-small-attempt1.in","r");
 	FILE *opf=fopen("output.in","w+");
 	fscanf(ipf,"%d",&test);
 	int k=1;
 	while(test--)
 	{
 		int cnt=0,temp;
 		fscanf(ipf,"%d",&n1);
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				fscanf(ipf,"%d",&c1[i][j]);
 			}
 		}
 		for(j=0;j<4;j++)
 		{
 			a[j]=c1[n1-1][j];
 		}
 		fscanf(ipf,"%d",&n2);
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				fscanf(ipf,"%d",&c2[i][j]);
 			}
 		}
 		for(j=0;j<4;j++)
 		{
 			b[j]=c2[n2-1][j];
 		}
 			for(j=0;j<4;j++)
 			{
 				for(i=0;i<4;i++)
 				{
 					if(a[j]==b[i])
 					{
 						cnt++;
 						temp=a[j];
 					}
 				}
 			}
 			if(cnt==1)
 			{
 				fprintf(opf,"Case #%d: %d ",k,temp);
 				k++;
 				fprintf(opf,"\n");
 			}
 			else if(cnt==0)
 			{
 				fprintf(opf,"Case #%d: ",k);
 				fprintf(opf,"Volunteer cheated!");
 				k++;
 				fprintf(opf,"\n");
 			}
 			else if(cnt>1)
 			{
 				fprintf(opf,"Case #%d: ",k);
 				fprintf(opf,"Bad magician!");
 				k++;
 				fprintf(opf,"\n");
 			}
 	}
 	return 0;
 }

