#include <stdio.h>
 #include <stdlib.h>
 
 int main(int argc, char *argv[])
 {
      int tcasenum;
 
      int candidate_selected;
      
      int tcaseloop,row1,row2,item1[16],item2[16],selected[16];
      
      int i;
      
      FILE *fin,*fout;
   fin=fopen("data.in","r");
   fout=fopen("data.out","w");
 
   fscanf(fin,"%d",&tcasenum);
   
   for(tcaseloop=0;tcaseloop<tcasenum;tcaseloop++)
   {
      fscanf(fin,"%d",&row1);
      
      for(i=0;i<16;i++)
      {
        fscanf(fin,"%d",&item1[i]);
      }
      
        
      
      fscanf(fin,"%d",&row2);                                                                    
      
      for(i=0;i<16;i++)
      {
        fscanf(fin,"%d",&item2[i]);
      }
 
      for(i=0;i<16;i++)
      {     
      selected[i]=0;
      }
      
      
      for(i=0;i<4;i++)
      {     
      selected[item1[(row1-1)*4+i]-1]=1;
      }
      
      candidate_selected=0;
      
      for(i=0;i<4;i++)
      {     
          if(selected[item2[(row2-1)*4+i]-1]==1)
          {
            if (candidate_selected==0)
            {
                candidate_selected=item2[(row2-1)*4+i];
            }
            else
            {
                fprintf(fout,"Case #%d: Bad magician!\n",tcaseloop+1);
                candidate_selected=-1;
                break;
            }
          }
     
      }
      
      if (candidate_selected==0)
      {
           fprintf(fout,"Case #%d: Volunteer cheated!\n",tcaseloop+1);
      }
      else if (candidate_selected != -1)
      {
           fprintf(fout,"Case #%d: %d\n",tcaseloop+1,candidate_selected);
      }
               
      
   }
 
   
   
   fclose(fin);
   fclose(fout);
    
   return 0;
 }

