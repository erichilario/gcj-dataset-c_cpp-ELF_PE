#include<stdio.h>
 
 
 main(){
 int x;
 scanf("%d",&x);
 int row1,row2;
 int arr[4][4];
 int p,q,i;
 int combo1[4],combo2[4];
 int ans;
 
 
 
 int flag[x];
 int b=x;
 int a=0;
 while(x>0){
 	flag[a]=0;
 	ans=0;
 	q=0,i=0;
 	scanf("%d",&row1);
 	for(p=0;p<16;p++){
 		scanf("%d",&arr[p/4][i]);
 		i++;
 		if(i==4) i=0;
 	
 	}
 
 for(p=0;p<4;p++){
 	combo1[p]=arr[row1-1][p];
 	}
 
 scanf("%d",&row2);
 i=0;
 for(p=0;p<16;p++){
 	
 	scanf("%d",&arr[p/4][i]);
 	i++;
 	if(i==4) i=0;
 }
 
 for(p=0;p<4;p++){
 	combo2[p]=arr[row2-1][p];
 	}
 
 for(p=0;p<4;p++){
 	for(i=0;i<4;i++){
 		if(combo1[p]==combo2[i]){
 			
 			flag[a]++;
 			printf("%d %d ok\n",flag[a],combo1[p]);
 			ans=combo1[p];
 		}
 	}
 	
 }
 
 if(flag[a]==1)flag[a]=ans;
 	else if(flag[a]==0) flag[a]=0;
 	else flag[a]=-1;
 x--;
 a++;
 }
 FILE *fp;
 fp=fopen("output.txt","w");
 for(i=0;i<b;i++){
 	if(flag[i]==-1){fprintf(fp,"Case #%d: Bad magician!\n",i+1);}
 	else if(flag[i]==0){fprintf(fp,"Case #%d: Volunteer cheated!\n",i+1);}
 	else {fprintf(fp,"Case #%d: %d\n",i+1,flag[i]);}
 }
 
 }
