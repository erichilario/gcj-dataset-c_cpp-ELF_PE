#include <stdio.h>
 
 int main() {
         int n,k;
         scanf("%d",&n);
         for(k=1;k<=n;k++) {
                 double c,f,x, ck=0;
                 scanf("%lf%lf%lf",&c,&f,&x);
                 double t=0;
                 int fc = 0;
                 while(ck<x) {
                         double t1 = (x-ck)/(f*fc+2.0);
                         double t2 = (c-ck)/(2.0+f*fc);
                         double t3 = x/(2.0+f+f*fc);
                         if(t1 > t2+t3) {
                                 t += t2;
                                 ck = ck + t2*(2.0+f*fc)-c;
                                 fc++;
                         }
                         else {
                                 t += t1;
                                 ck = ck + (f*fc+2.0)*t1;
                         }
                 }
                 printf("Case #%d: %.7f\n", k, t);
         }
         return 0;
 }
