#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     int numOfTests, firstLine, secondLine;
     int firstMatrix[4][4], secondMatrix[4][4];
     int volunteerNumbers[17];
 
     FILE *f, *g;
 //    f = fopen("input.in", "rw");
 //    g = fopen("output.out", "rw");
     f = stdin;
     g = stdout;
 
     fscanf(f, "%d", &numOfTests);
 
     for(int i = 1; i <= numOfTests; i++){
         for(int j = 0; j <= 16; j++) volunteerNumbers[j] = 0;
 
         fscanf(f, "%d", &firstLine);
         for(int j = 0; j < 16; j++) fscanf(f, "%d", &firstMatrix[j/4][j%4]);
         fscanf(f, "%d", &secondLine);
         for(int j = 0; j < 16; j++) fscanf(f, "%d", &secondMatrix[j/4][j%4]);
 
         for(int j = 0; j < 4; j++){
             volunteerNumbers[firstMatrix[firstLine-1][j]]++;
             volunteerNumbers[secondMatrix[secondLine-1][j]]++;
         }
 
         int numOfNumbers = 0;
         int theNumber;
         for(int j = 1; j <= 16; j++){
             if(volunteerNumbers[j] == 2){
                 numOfNumbers++;
                 theNumber = j;
             }
         }
 
         switch(numOfNumbers){
             case 0: {
                 fprintf(g, "Case #%d: Volunteer cheated!\n", i);
                 continue;
             }
             case 1: {
                 fprintf(g, "Case #%d: %d\n", i, theNumber);
                 continue;
             }
             default: {
                 fprintf(g, "Case #%d: Bad magician!\n", i, theNumber);
                 continue;
             }
         }
     }
 
     fclose(f);
     fclose(g);
 
     return 0;
 }

