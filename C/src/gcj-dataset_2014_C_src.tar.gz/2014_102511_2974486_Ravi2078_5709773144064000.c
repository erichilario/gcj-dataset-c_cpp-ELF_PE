#include <stdio.h>
 
 #define PRODUCE 2.0
 
 double solution(double farm, double up_produce, double target)
 {
     double produce = PRODUCE;
     double time = 0.0;
 
     while (1)
     {
         double t1 = target/produce;
         double t2 = farm/produce + target/(produce+up_produce);
 
         if (t1<t2)
         {
             time += t1;
             break;
         } else {
             time += farm/produce;
             produce += up_produce;
         }
     }
 
     return time;
 }
 
 int main(int argc, char const *argv[])
 {
     int cases = 0;
     scanf("%d", &cases);
     int i;
     for (i = 0; i < cases; ++i)
     {
         double farm, up_produce, target;
         scanf("%lf %lf %lf", &farm, &up_produce, &target);
         double solve = solution(farm, up_produce, target);
         printf("Case #%d: %0.7lf\n", i+1, solve);
     }
     return 0;
 }

