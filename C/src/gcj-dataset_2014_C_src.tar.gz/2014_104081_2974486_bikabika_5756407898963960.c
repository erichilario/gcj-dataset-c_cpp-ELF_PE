#include<stdio.h>
 int main(){
 	int w[4][4];
 	int t,a,b,i,j;
 	FILE *infile,*outfile;
 	infile=fopen("magic.in","r");
 	outfile=fopen("magic.out","w");
 	fscanf(infile,"%d",&t);
 	int tot=0;
 	while(t--){
 		tot++;
 		int q[200000]={0};
 		int flag=0,ans=0;
 		fscanf(infile,"%d",&a);
 		for(i=0;i<4;i++){
 			for(j=0;j<4;j++){
 				fscanf(infile,"%d",&w[i][j]);
 				if (i==a-1) q[w[i][j]]=1;
 			}
 		}
 		fscanf(infile,"%d",&b);
 		for(i=0;i<4;i++){
 			for(j=0;j<4;j++){
 				fscanf(infile,"%d",&w[i][j]);
 				if ((i==b-1)&&(q[w[i][j]])) {
 					flag++;
 					ans=w[i][j];
 				}
 			}
 		}
 		switch(flag){
 			case 0:fprintf(outfile,"Case #%d: Volunteer cheated!\n",tot);break;
 			case 1:fprintf(outfile,"Case #%d: %d\n",tot,ans);break;
 			default:fprintf(outfile,"Case #%d: Bad magician!\n",tot);break;
 		}
 		
 	}
 	return 0;
 	fclose(infile);
 	fclose(outfile);
 }
