#include<stdio.h>
 void mergeSort(float arr[],int low,int mid,int high);
 void partition(float arr[],int low,int high);
 int main()
 {
     int t,N,m,i=0,z=0,y=0,r=0,j=0,mn,x=0;
     scanf("%d",&t);
 
 
     int c[t],d[t];
     m=t;
 
     while(t>=1&&t<=50)
     {
         scanf("%d",&N);
         if(N>=1&&N<=10)
         {float a[N],b[N];
         mn=N;
         z=0;
         for(i=0;i<N;i++)
         scanf("%f",&a[i]);
          for(i=0;i<N;i++)
         scanf("%f",&b[i]);
 
 partition(a,0,N-1);
 partition(b,0,N-1);
 
 for(i=0;i<mn;i++)
 {
    for(j=i;j<mn;j++)
         {
             if(a[i]>b[j])
 			{
 			    b[j]=10;
 			    b[j+1]=10;
 			z++;
 		}
         }
 
     }
     for(i=0;i<mn;i++)
     {
         if(a[i]>b[mn-1])
         x=i+1;
     }
 if(x=0)
 x=mn;
 
 d[r]=(mn-x-1);
 c[r]=z;
 r++;
 t--;
         }
     }
     for(i=0;i<m;i++)
     printf("Case #%d: %d %d\n",i+1,d[i],c[i]);
 return 0;
     }
 void partition(float arr[],int low,int high){
 int mid;
 if(low<high){
 mid=(low+high)/2;
 partition(arr,low,mid);
 partition(arr,mid+1,high);
 mergeSort(arr,low,mid,high);
 }
 }
 void mergeSort(float arr[],int low,int mid,int high){
 int i,m,k,l;
 float temp[high];
 l=low;
 i=low;
 m=mid+1;
 while((l<=mid)&&(m<=high)){
 if(arr[l]<=arr[m]){
 temp[i]=arr[l];
 l++;
 }
 else{
 temp[i]=arr[m];
 m++;
 }
 i++;
 }
 if(l>mid){
 for(k=m;k<=high;k++){
 temp[i]=arr[k];
 i++;
 }
 }
 else{
 for(k=l;k<=mid;k++){
 temp[i]=arr[k];
 i++;
 }
 }
 for(k=low;k<=high;k++){
 arr[k]=temp[k];
 }
 }
 
 
 
 

