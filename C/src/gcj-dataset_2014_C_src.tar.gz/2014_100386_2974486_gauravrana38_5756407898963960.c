#include<stdio.h>
 int main()
 {
     int i,j,k,l,m,n;
     freopen("A-small-attempt2.in","r",stdin);
     freopen("output.txt","w",stdout);
     int arr1[5][5];
     int flag[19] = {0};
     int arr2[5][5];
     int a,b;
     int test;
     int count = 0;
     int flag2;
     scanf("%d",&test);
     while(test--)
     {
         printf("Case #");
         printf("%d: ",++count);
         for(i=0;i<17;i++)
             flag[i] = 0;
         scanf("%d",&a);
         for(i=0;i<4;i++)
         for(j=0;j<4;j++)
             scanf("%d",&arr1[i][j]);
         i=a-1;
         for(j=0;j<4;j++)
             flag[arr1[i][j]] = 1;
 
 
         scanf("%d",&b);
         for(i=0;i<4;i++)
             for(j=0;j<4;j++)
             scanf("%d",&arr2[i][j]);
 
         i=b-1;
         for(j=0;j<4;j++)
         {
             if(flag[arr2[i][j]] == 1)
                 flag[arr2[i][j]]++;
         }
 
         flag2 = 0;
         for(i=0;i<=16;i++)
             if(flag[i] == 2)
             flag2++;
 
         if(flag2 == 0)
             printf("Volunteer cheated!");
         else if(flag2 > 1)
             printf("Bad magician!");
         else
         for(i=0;i<17;i++)
         {
             if(flag[i] == 2)
             {
                 printf("%d",i);
                 break;
             }
         }
         printf("\n");
     }
     return 0;
 }

