#include<stdio.h>
 int main()
 {
     double i,j,k,l,c,f,x,cr,tt;
     int t,m,n,y;
     scanf("%d",&t);
     cr=2.0;             //current rate
     for(y=1;y<=t;y++)
     {
         scanf("%lf",&c);
         scanf("%lf",&f);
         scanf("%lf",&x);
         cr=2;           //current rate
         tt=0;           //total time
         while(1)
         {
             k=x/cr;
             l=c/cr;
             l=l+(x/(cr+f));
             if(k<=l)
             {
                 tt=tt+k;
                 break;
             }
             else
             {
                 tt=tt+(c/cr);
                 cr=cr+f;
             }
         }
         printf("Case #%d: %lf\n",y,tt);
     }
     return 0;
 }

