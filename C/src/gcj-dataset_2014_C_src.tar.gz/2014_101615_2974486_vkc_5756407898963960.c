#include <stdio.h>
 
 int main(void) {
  int n;
  scanf("%d",&n);
  int as = 0;
  while(n--)
  {
  	as++;
  	int r1,r2;
  	int g1[4][4];
  	int g2[4][4];
  	int i,j;
  	scanf("%d",&r1);
  	for(i=0;i<4;i++)
  		for(j=0;j<4;j++)
  		{
  			scanf("%d",&g1[i][j]);
  		}
  	scanf("%d",&r2);
  	for(i=0;i<4;i++)
  		for(j=0;j<4;j++)
  		{
 			scanf("%d",&g2[i][j]);
  		}
  		int comm = 0;
  		int result;
  //for(i=0;i<4;i++)
  //		for(j=0;j<4;j++)
  //		printf("%d",g2[i][j]);
  	
  	for(i=0;i<4;i++)
  	{
  		for(j=0;j<4;j++)
  		{
  		//	printf("x%d la  %dx",g1[r1-1][i],g2[r2-1][j]);
  		if(g1[r1-1][i]==g2[r2-1][j])
  		{
  			comm = comm + 1;
  			result = g2[r2-1][j];
  		}
  		}
  		//printf("\n");
  	}
  	printf("Case #%d: ",as);
  	if(comm==1)
  	printf("%d\n",result);
  	else if(comm>0)
  	printf("Bad magician!\n");
  	else 
  	printf("Volunteer cheated!\n");
  }  
 	return 0;
 }

