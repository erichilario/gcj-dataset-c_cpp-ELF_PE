#include<stdio.h>
 
 int main()
 {
 	int a[4][4],b[4][4],i,j,k,first,second,count,t,f;
 	freopen("A-small-attempt1.in","r",stdin);
 	freopen("test_out1.txt","w",stdout);
 	
 	scanf("%d",&t);
 	for(k=1;k<=t;k++)
 	{
 		scanf("%d",&first);
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 				scanf("%d",&a[i][j]);
 		}
 		scanf("%d",&second);		
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 				scanf("%d",&b[i][j]);
 		}
 		count=0;
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				if(a[first-1][i]==b[second-1][j])
 				{
 					count++;
 					f=a[first-1][i];
 				}
 			}
 		}
 		printf("Case #%d: ",k);
 		if(count==1)
 			printf("%d\n",f);
 		else if(count!= 0)
 			printf("Bad magician!\n");
 		else
 			printf("Volunteer cheated!\n");		
 		
 		
 		
 	}
 	return 0;
 }

