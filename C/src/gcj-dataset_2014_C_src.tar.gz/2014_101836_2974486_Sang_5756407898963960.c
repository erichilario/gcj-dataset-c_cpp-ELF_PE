#include<stdio.h>
 #include<stdlib.h>
 
 int firstArrange[4][4];
 int secondArrange[4][4];
 int firstanswer, secondanswer;
 
 
 void init()
 {
 	int i,j;
 	firstanswer = secondanswer = 0;
 	for(i=0; i<4; i++)
 	{
 		for(j=0; j<4; j++)
 		{
 			firstArrange[i][j] = secondArrange[i][j] = 0;
 		}
 	}
 }
 void determines(FILE *inp, FILE *out)
 {
 	int count=0; 
 	int i,j;
 	int answer;
 	for(i=0; i<4; i++)
 	{
 		for(j=0; j<4; j++)
 		{
 			if(firstArrange[firstanswer-1][i] == secondArrange[secondanswer-1][j])
 			{
 				count++;
 				answer = secondArrange[secondanswer-1][j];
 			}
 		}
 	}
 
 	if(count == 0)
 	{
 		fprintf(out,"Volunteer cheated!\n");
 	}
 	else if(count == 1)
 	{
 		fprintf(out,"%d\n", answer);
 	}
 	else
 	{
 		fprintf(out, "Bad magician!\n");
 	}
 	
 }
 int main()
 {
 	int caseNumber;
 	int count=0;
 	int i,j,k;
 	char* openfilename = "A-small-attempt1.in";
 	char* writefilename = "A-small-attempt1.out";
 
 	FILE *inp;
 	FILE *out;
 
 	inp = fopen(openfilename, "r");
 	out = fopen(writefilename, "w");
 
 	fscanf(inp, "%d", &caseNumber);
 
 
 
 	for(i=0; i<caseNumber; i++)
 	{
 		count++;
 		init();
 		fscanf(inp, "%d", &firstanswer);
 		for(j=0; j<4; j++)
 		{
 			for(k=0; k<4; k++)
 			{
 				fscanf(inp, "%d", &firstArrange[j][k]);
 			}
 		}
 
 		fscanf(inp, "%d", &secondanswer);
 		for(j=0; j<4; j++)
 		{
 			for(k=0; k<4; k++)
 			{
 				fscanf(inp, "%d", &secondArrange[j][k]);
 			}
 		}
 		
 		fprintf(out, "Case #%d: ", count);
 		determines(inp, out);
 	}
 
 	
 	
 }
