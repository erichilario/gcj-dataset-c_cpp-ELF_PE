#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
     FILE *fp,*ofp;
     fp=fopen("input.txt", "r");
     ofp=fopen("output.txt","w");
     int t, i, k;
 	double c, f, x, a, b, m, f1, temp1, temp2;
 	fscanf(fp,"%d", &t);
 	for(k=1; k<=t; k++)
 	{
 		fscanf(fp,"%lf %lf %lf", &c, &f, &x);
 		f1=2.0;
 		a=c/f1;
 		b=x/c;
 		m=a*b;
 		while(1)
 		{
 			f1=f1+f;
 			temp1=c/f1;
 			temp2=temp1*b;
 			if((a+temp2) <= m)
 			{
 				m=a+temp2;
 				a+=temp1;
 			}
 			else
 				break;
 		}
 		fprintf(ofp,"Case #%d: %.7lf\n", k, m);
 	}
 
 return 0;
 
 }

