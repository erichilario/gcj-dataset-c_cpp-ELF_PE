//magic.c
 //written by Tony Ward
 
 #include <stdio.h>
 
 #define BOARD_SIZE 4
 #define TRUE 1;
 #define FALSE 0;
 
 #define BAD_MAGICIAN -1
 #define VOLUNTEER_CHEATED 0
 
 int checkCase(int arrange1[BOARD_SIZE][BOARD_SIZE], int answer1,
                int arrange2[BOARD_SIZE][BOARD_SIZE], int answer2);
 int contains(int array[BOARD_SIZE], int number);
 
 int main(int argc, char *argv[]) {
    int testCases = 0;
    int currCase = 1;
    int arrange1[BOARD_SIZE][BOARD_SIZE];
    int arrange2[BOARD_SIZE][BOARD_SIZE];
    int answer1 = 0;
    int answer2 = 0;
    int row = 0;
    int col = 0;
    int sol = 0;
    
    //answer each test case
    scanf("%d", &testCases);
    while(currCase <= testCases) {
       //read current testcase
       scanf("%d", &answer1);
       answer1--;
       for (row = 0; row < 4; row++) {
          for (col = 0; col < 4; col++) {
             scanf("%d", &arrange1[row][col]);
          }
       }
       scanf("%d", &answer2);
       answer2--;
       for (row = 0; row < 4; row++) {
          for (col = 0; col < 4; col++) {
             scanf("%d", &arrange2[row][col]);
          }
       }
       
       //print out solution for current test case
       sol = checkCase(arrange1, answer1, arrange2, answer2);
       printf("Case #%d: ", currCase);
       if (sol == BAD_MAGICIAN) {
          printf("Bad magician!\n");
       } else if (sol == VOLUNTEER_CHEATED) {
          printf("Volunteer cheated!\n");
       } else {
          printf("%d\n", sol);
       }
       currCase++;
    }
    
    return 0;
 }
 
 //given 2 arrangements of cards and the answer for each arrangement
 //determines the answer, if the magician is bad or the volunteer cheated
 //returns answer if there is one otherwise 0 for bad magician and -1 for cheat
 int checkCase(int arrange1[BOARD_SIZE][BOARD_SIZE], int answer1,
                int arrange2[BOARD_SIZE][BOARD_SIZE], int answer2) {
    int row = answer1;
    int col = 0;
    int possibles[BOARD_SIZE];
    
    //find possible solutions in the first arrangement
    while (col < BOARD_SIZE) {
       possibles[col] = arrange1[row][col];
       col++;
    }
    
    //now check for matching possible solutions in answer2
    row = answer2;
    col = 0;
    int sol = VOLUNTEER_CHEATED;      //assume cheating volunteer until we have 1 or more sol'ns
    
    while (col < BOARD_SIZE) {
       if (contains(possibles, arrange2[row][col])) {
          if (sol == VOLUNTEER_CHEATED) {
             sol = arrange2[row][col];
          } else {
             sol = BAD_MAGICIAN;
          }
       }
       col++;
    }
    
    return sol;
 }
 
 //checks if an array contains a specified number
 int contains(int array[BOARD_SIZE], int number) {
    int count = 0;
    while (count < BOARD_SIZE) {
       if (array[count] == number) {
          return TRUE;
       }
       count++;
    }
    
    return FALSE;
 }

