#include <stdio.h>
 int main()
 {
     FILE *in = fopen("A-small-attempt0.in","r");
     FILE *out = fopen("A-small-attempt0.out","w");
     int n;
     fscanf(in,"%d",&n);
     int o;
     for(o=1;n>=o;o++)
     {
         int temp;
         fscanf(in,"%d",&temp);
         int i,k,c;
         int bucket[100] = {0};
         for(i=1;4>=i;i++)
         {
             for(k=1;4>=k;k++)
             {
                 fscanf(in,"%d",&c);
                 if(i==temp)
                     bucket[c]++;
             }
         }
         fscanf(in,"%d",&temp);
         for(i=1;4>=i;i++)
         {
             for(k=1;4>=k;k++)
             {
                 fscanf(in,"%d",&c);
                 if(i==temp)
                     bucket[c]++;
             }
         }
         int count = 0;
         int p;
         for(i=1;16>=i;i++)
         {
             if(bucket[i]==2)
             {
                 count++;
                 p = i;
             }
         }
         if(count==1)
         {
             fprintf(out,"Case #%d: %d\n",o,p);
         }else if(count==0)
         {
             fprintf(out,"Case #%d: Volunteer cheated!\n",o);
         }else
         {
             fprintf(out,"Case #%d: Bad magician!\n",o);
         }
     }
 }

