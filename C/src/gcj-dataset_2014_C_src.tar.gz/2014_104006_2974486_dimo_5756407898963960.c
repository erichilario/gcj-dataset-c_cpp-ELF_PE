#include <stdio.h>
 
 int main (void) {
 	short int g1[4][4], g2[4][4], t, i, j, a, b, r, p, c;
 
 		scanf("%hd", &t);
 		for (c = 0; c < t; c++) { /* Bad pun */
 			scanf("%hd", &a);
 			for (i = 0; i < 4; i++)
 				for (j = 0; j < 4; j++)
 					scanf("%hd", &g1[i][j]);
 			scanf("%hd", &b);
 			for (i = 0; i < 4; i++)
 				for (j = 0; j < 4; j++)
 					scanf("%hd", &g2[i][j]);
 			a--;
 			b--;
 			r = 0;
 			for (i = 0; i < 4; i++)
 				for (j = 0; j < 4; j++)
 					if (g1[a][i] == g2[b][j]) {
 						p = i;
 						r++;
 					}
 			switch(r) {
 				case 0:
 					printf("case #%hd: Volunteer cheated!\n", c+1);
 					break;
 				case 1:
 					printf("case #%hd: %hd\n", c+1, g1[a][p]);
 					break;
 				default:
 					printf("case #%hd: Bad magician!\n", c+1);
 			}
 		}
 		return 0;
 }

