#include <stdio.h>
 #include <stdlib.h>
 
 double
 readNum() {
   double val;
   scanf( "%lf", &val );
   return val;
 }
 
 void
 bubbleSort( double* const buf, int const bufSize ) {
   int i, j;
   double temp;
   for( i = 0; i < bufSize; ++i ) {
     for( j = i + 1; j < bufSize; ++j ) {
       if( buf[ i ] > buf[ j ] ) {
 	temp = buf[ i ];
 	buf[ i ] = buf[ j ];
 	buf[ j ] = temp;
       }
     }
   }
 }
 
 void print( double* const buf, int const bufSize ) {
   int i;
   for( i = 0; i < bufSize; ++i ) {
     printf( "%lf ", buf[ i ] );
   }
   printf( "\n" );
 }
 
 void
 testCase( FILE* fo, int n ) {
   double naomi[ 1000 ];
   double ken[ 1000 ];
   int blocks = readNum();
   int i, j, k;
   int points = 0;
 
   printf( "testCase: %d\n", n );
   for( i = 0; i < blocks; ++i ) {
     naomi[ i ] = readNum();
   }
   bubbleSort( naomi, blocks );
   print( naomi, blocks );
 
   for( i = 0; i < blocks; ++i ) {
     ken[ i ] = readNum();
   }
   bubbleSort( ken, blocks );
   print( ken, blocks );
 
   // deceitful war
   printf( "deceitful war\n" );
   for( i = blocks - 1, j = blocks - 1, k = 0; i >= k; --i ) {
     if( j == -1 ) {
       ++points;
       printf( "dPoints: %d\n", points );
     }
     while( j >= 0 ) {
       printf( "naomi: %lf, ken: %lf\n", naomi[ i ], ken[ j ] );
       if( naomi[ i ] > ken[ j ] ) {
 	++points;
 	printf( "dPoints: %d\n", points );
 	--j;
 	break;
       } else {
 	++k;
 	--j;
       }
     }
   }
   printf( "ans: %d\n", points );
   fprintf( fo, "Case #%d: %d ", n, points );
 
   // reg war
   printf( "reg war\n" );
   for( points = 0, i = 0, j = 0; i < blocks; ++i ) {
     int addPoint = 1;
     while( j < blocks ) {
        printf( "naomi: %lf, ken: %lf\n", naomi[ i ], ken[ j ] );
       if( naomi[ i ] > ken[ j ] ) {
 	++j;
       } else {
 	addPoint = 0;
 	++j;
 	break;
       }
     }
     if( addPoint ) {
       ++points;
     }
     printf( "rPoints: %d\n", points );
   }
   printf( "ans: %d\n", points );
   fprintf( fo, "%d\n", points );
 }
 
 int
 main( int argc, char** argv ) {
   int numCases ;
   int i;
   FILE* fo = fopen( "output.txt", "w");
 
   numCases = readNum();
   printf( "numCases: %d\n", numCases );
   for( i = 0; i < numCases; ++i ) {
     testCase( fo, i + 1 );
   }
   return 0;
 }

