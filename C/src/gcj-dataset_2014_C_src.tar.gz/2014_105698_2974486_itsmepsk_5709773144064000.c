#include <stdio.h>
 
 int main() {
 	int t,p;
 	double c,f,x,r,timeb,sumb,timed,sumd,prev,count;
 	scanf("%d",&t);
 	for(p=1;p<=t;p++) {
 		scanf("%lf %lf %lf",&c,&f,&x);
 		r=2;
 		count=0;
 		sumb=0;
 		sumd=0;
 		while(1) {
 			prev = sumd;
 			timed = x/r;
 			sumd = sumb + timed;
 			timeb = c/r;
 			sumb = sumb + timeb;
 			r = r + f;
 			if(prev < sumd && count != 0) {
 				break;
 			}
 			count++;
 		}
 		printf("Case #%d: %.7lf\n",p,prev);
 	}
 	return 0;
 }

