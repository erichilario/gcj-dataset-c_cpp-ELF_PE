#include <stdio.h>
 
 int main() {
 	int t,p,n,i,j,s,x,y,count,count1,war,dwar;
 	double temp,arr[1010] = {0},brr[1010] = {0},crr[1010] = {0};
 	scanf("%d",&t);
 	for(p=1;p<=t;p++) {
 		scanf("%d",&n);
 		for(i=0;i<n;i++) {
 			scanf("%lf",&arr[i]);
 		}
 		for(i=0;i<n;i++) {
 			scanf("%lf",&brr[i]);
 		}
 		
 		for(x=0; x<n; x++) {
 			for(y=0; y<n-1; y++) {
 				if(arr[y]>arr[y+1])	{
 					temp = arr[y+1];
 					arr[y+1] = arr[y];
 					arr[y] = temp;
 				}
 			}
 		}
 		
 		for(x=0; x<n; x++) {
 			for(y=0; y<n-1; y++) {
 				if(brr[y]>brr[y+1])	{
 					temp = brr[y+1];
 					brr[y+1] = brr[y];
 					brr[y] = temp;
 				}
 			}
 		}
 		for(x=0;x<n;x++) {
 			crr[n-i-1] = arr[i];
 		}
 		s=0;
 		count=0;
 		for(i=0;i<n;i++) {
 			for(j=s;j<n;j++) {
 				if(brr[j] > arr[i]) {
 					count++;
 					s=j+1;
 					break;
 				}
 			}
 		}
 		war = n-count;
 		count1=0;
 		s = n-1;
 		for(i=n-1;i>=0;i--) {
 			for(j=s;j>=0;j--) {
 				if(arr[i] < brr[j]) {
 					count1++;
 				}
 				else {
 					s = j-1;
 					break;
 				}
 			}
 		}
 		dwar = n-count1;
 		printf("Case #%d: %d %d\n",p,dwar,war);
 	}
 }

