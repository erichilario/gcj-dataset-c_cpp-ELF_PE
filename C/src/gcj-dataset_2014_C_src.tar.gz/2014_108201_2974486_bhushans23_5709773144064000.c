#include <stdio.h>
 #include <string.h>
 #include <math.h>
 #include <stdlib.h>
 
 int main(){
 	int t,caseno;
 	double c,f,x,rate,rate2,sec,sec2,sec3; 
 	scanf("%d",&t);
 	caseno=0;
 	while(caseno++<t){
 		scanf("%lf %lf %lf",&c,&f,&x);
 		sec=0;
 		rate=2;
 		while(1){
 			rate2=rate+f;
 			sec2=sec+c/rate;
 
 			sec3=sec2+x/rate2;
 			
 			sec+=x/rate;
 			
 			if(sec3 < sec ){
 				sec=sec2;
 				rate=rate2;
 			}
 			else{
 
 				printf("Case #%d: %.7lf\n",caseno,sec);
 				break;
 			}
 
 		}
 
 	}
 
 	return 0;
 }
