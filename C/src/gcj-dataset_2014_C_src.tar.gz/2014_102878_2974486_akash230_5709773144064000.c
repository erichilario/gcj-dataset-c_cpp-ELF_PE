#include<stdio.h>
 
 int main()
 {
 	double t1,t2,c,x,f,total,curr_rate;
 	int i,j,k,t,d;
 	freopen("B-small-attempt1.in","r",stdin);
 	freopen("test_out1.txt","w",stdout);
 	scanf("%d",&t);
 	for(k=1;k<=t;k++)
 	{
 		scanf("%lf%lf%lf",&c,&f,&x);
 	//	printf("%lf %lf %lf",c,f,x);
 		d=0;
 		total=0;
 		curr_rate = 2;
 		while(d==0)
 		{
 			t1=c/curr_rate;
 			t2=x/curr_rate;
 		//	printf("t1=%f t2=%f    ",t1,t2);
 			if(t2<=t1+(x/(curr_rate+f)))
 			{
 				total+=t2;
 				d=1;
 			}
 			else
 			{
 				total+=t1;
 				curr_rate+=f;
 			}
 		}
 		printf("Case #%d: %lf\n",k,total);
 		
 	}
 	return 0;
 }

