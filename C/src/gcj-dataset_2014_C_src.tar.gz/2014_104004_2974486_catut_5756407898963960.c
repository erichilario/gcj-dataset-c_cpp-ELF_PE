/*
  * main.c
  *
  *  Created on: Apr 12, 2014
  *      Author: Admin
  */
 
 #include<stdio.h>
 void citire(int a[4][4],FILE *in)
 {
 	int i,j;
 	for(i=0;i<4;++i)
 	{
 		for(j=0;j<4;++j)
 			fscanf(in,"%d",&a[i][j]);
 	}
 }
 
 int main()
 {
 	int a[4][4],b[4][4],T,i,r1,r2,ok,k,j,nr;
 	FILE *in,*out;
 	in=fopen("A-small-attempt0.in","r");
 	out=fopen("A-small-attempt0.out","w");
 	fscanf(in,"%d",&T);
 	for(i=0;i<T;++i)
 	{
 		ok=0;
 		fscanf(in,"%d",&r1);
 		r1=r1-1;
 		citire(a,in);
 		fscanf(in,"%d",&r2);
 		r2=r2-1;
 		citire(b,in);
 		for(k=0;k<4;k++)
 		{
 			for(j=0;j<4;j++)
 			{
 				if(a[r1][k]==b[r2][j])
 				{
 					ok++;
 					nr=a[r1][k];
 				}
 			}
 		}
 		if(ok==0)
 			fprintf(out,"Case #%d: Volunteer cheated!\n",i+1);
 		else
 			if(ok>1)
 				fprintf(out,"Case #%d: Bad magician!\n",i+1);
 			else
 				fprintf(out,"Case #%d: %d\n",i+1,nr);
 
 	}
 	fclose(in);
 	fclose(out);
 	return 0;
 }

