//
 //  main.c
 //  codejam1
 //
 //  Created by 谷大人 on 14-4-12.
 //  Copyright (c) 2014年 guzhen. All rights reserved.
 //
 
 #include <stdio.h>
 
 int i = 1;
 
 void handle(){
     int first, second, current = 0;
     int tmp1[4] = {0,0,0,0}, tmp2[4] = {0,0,0,0}, unuse[4];
     printf("Case #%d: ", i);
     
     scanf("%d", &first);
     while (current != first) {
         int j = 0;
         for (; j < 4; j++) {
             scanf("%d", tmp1 + j);
         }
         current++;
     }
     while (current < 4) {
         scanf("%d%d%d%d",unuse, unuse+1,unuse+2,unuse+3);
         current++;
     }
     
     scanf("%d", &second);
     current = 0;
     while (current != second) {
         int j = 0;
         for (; j < 4; j++) {
             scanf("%d", tmp2 + j);
         }
         current++;
     }
     while (current < 4) {
         scanf("%d%d%d%d",unuse, unuse+1,unuse+2,unuse+3);
         current++;
     }
     
     int repeat = 0, tmp;
     for (current = 0; current < 4; current++) {
         for (int j = 0; j < 4; j++) {
             if (tmp1[current] == tmp2[j]) {
                 tmp = tmp2[j];
                 repeat++;
             }
         }
     }
     
     if (repeat == 1) {
         printf("%d\n", tmp);
     }else if (repeat == 0) {
         printf("Volunteer cheated!\n");
     }else {
         printf("Bad magician!\n");
     }
 }
 
 int main(int argc, const char * argv[])
 {
     freopen("a.in.txt", "r", stdin);
     freopen("a.out.txt", "w", stdout);
     int cases;
     scanf("%d", &cases);
     for (; i <= cases; i++) {
         handle();
     }
     return 0;
 }
 

