#include <stdio.h>
 
 double toFloat(char *num) {
     double c = 0, b, m;
     int i, t = 10;
     char *cp, *ep;
     cp = num;
     
     ep = strchr(num, '.');
     *ep++ = '\0';
     
     c += atoi(cp);
     
     for (i = 0; i < strlen(ep); i++) {
         c += (*ep++ - '0') / t;
         t *= 10;
     }
     return c;
 }
 
 void extract(char *line, double *arr) {
     int i;
     char *cp, *ep;
     for (i = 0, cp = line; i < 3; i++, cp = ep) {
         ep = strchr(cp, ' ');
         if (ep) {
             *ep++ = '\0';
         }
         arr[i] = toFloat(cp);
     }
 }
 
 int main(int argc, char *argv[]) {
     int tcases = 0, i;
     char line[1024];
     double arr[3];
     double c, f, x, r = 2, t;
     /*
      * Get number of testcases
      */
     if (gets(line)) {
         tcases = atoi(line);
     }
     
     for (i = 1; i <= tcases; i++) {
         gets(line);
         extract(line, arr);
         c = arr[0];
         f = arr[1];
         x = arr[2];
         r = 2;
         t = 0;
         
         while (x > 0) {
             if (x / r > (c / r) + x / (r + f)) {
                 t += c / r;
                 r += f;
             } else {
                 t += x / r;
                 break;
             }
         }
         printf("Case #%d: %.7f\n", i, t);
     }
     getch();
 }

