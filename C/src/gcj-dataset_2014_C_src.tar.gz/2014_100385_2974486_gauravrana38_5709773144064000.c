#include<stdio.h>
 int main()
 {
     int i,j,k,l,m,n;
     freopen("B-small-attempt0.in","r",stdin);
     freopen("output.txt","w",stdout);
     int test;
     double c,f,x;
     double ans;
     double base;
     double speed;
     int count = 0;
     scanf("%d",&test);
     while(test--)
     {
         printf("Case #");
         printf("%d: ",++count);
         base = 0.00;
         speed = 2.0;
         scanf("%Lf %Lf %Lf",&c,&f,&x);
         while(1)
         {
             ans = base + x/speed;
             if(ans <= base + c/speed + x/(speed+f))
                 break;
             else
                 base += c/speed,speed+=f;
 
         }
         printf("%0.7Lf\n",ans);
     }
 
 
 
 
     return 0;
 }

