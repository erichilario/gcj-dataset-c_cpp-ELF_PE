#include <stdio.h>
 
 int i, j, T, N;
 float naomi[1001], ken[1001];
 
 int Partition(float a[], int p, int r){
 	float x = a[r], temp;
 	int i = p - 1, j;
 	for(j = p; j < r; j++)
 		if(x > a[j]){
 			i++;
 			temp = a[i];
 			a[i] = a[j];
 			a[j] = temp;
 		}
 	i++;
 	temp = a[i];
 	a[i] = a[r];
 	a[r] = temp; 
 	return i;
 }
 
 void QuickSort(float a[], int p, int r){
 	if(p < r){
 		int q = Partition(a, p, r);
 		QuickSort(a, p, q - 1);
 		QuickSort(a, q + 1, r);
 	}
 }
 
 int War(){
 	int i = 0, j = -1, l;
 	for(i; i < N; i++){
 		j++;		
 		if(j > N - 1) break;		
 		while(j < N - 1 && naomi[i] > ken[j]) j++;
 		//printf("HOla %f %f %d %d\n", naomi[i], ken[j], i, j);
 		if(naomi[i] > ken[j]) l = 1;
 		else l = 0;				
 	}
 	//printf("HOla2 %f %f %d %d\n", naomi[i - 1], ken[j - 1], i, j);				
 	return N - i + l;
 }
 
 int DeceitfulWar(){
 	int c = 0, i = 0, ik = 0;
 	for(i; i < N; i++)
 		if(naomi[i] >= ken[c])
 			c++;	
 	return c;
 }
 
 void Print(float a[], int i, int j){
 	int u;
 	for(u = i; u < j; u++)
 		printf("%f ", a[u]);
 	printf("\n");
 }
 
 int main(){
 	scanf("%d", &T);
 	for(i = 0; i < T; i++){
 		scanf("%d", &N);
 		for(j = 0; j < N; j++) scanf("%f", &naomi[j]);
 		for(j = 0; j < N; j++) scanf("%f", &ken[j]);
 		QuickSort(naomi, 0, N - 1);
 		QuickSort(ken, 0, N - 1);
 		//Print(naomi, 0, N);
 		//Print(ken, 0, N);
 		printf("Case #%d: %d %d\n", i + 1, DeceitfulWar(), War());
 	}
 	return 0;
 }

