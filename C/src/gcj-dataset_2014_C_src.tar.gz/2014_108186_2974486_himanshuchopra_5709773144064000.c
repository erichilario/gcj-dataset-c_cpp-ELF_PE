#include<stdio.h>
 int main()
 {  int test,t;
    double c,f,x,a=2,sum=0;
    scanf("%d",&test);
    t= test;
    while(test--)
 {       
  	scanf("%lf""%lf""%lf",&c,&f,&x);
  	if (x<c)
 { 
  	printf("Case #%d: %.7lf\n",t-test,x/a);
 }
 	else 
 {
  	while (  (x/(a+f) + c/a)< (x/a) )
 {
 		sum= sum+ (c/a);
 		a= a+f;
   
 }
 /* 
 End of while
 */
 	 sum= sum+ (x/a);
          printf("Case #%d: %.7lf\n",t-test,sum);
  }
  sum=0;
  a=2;
 }
 return 0;
 }
 
 

