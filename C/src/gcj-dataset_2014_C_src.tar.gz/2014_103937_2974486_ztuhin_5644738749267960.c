#include <stdio.h>
 #include <stdlib.h>
 
 int cmpfunc (const void * a, const void * b)
 {
    if(*(double*)a > *(double*)b )
         return 1;
    else
         return -1;
 }
 
 int main()
 {
     int T,i,j,k;
     double N[1000],K[1000];
     int n;
     int war,decwar;
     freopen("D-large.in", "r", stdin);
     freopen("D-large.out", "w+", stdout);
     scanf("%d",&T);
     for(i=0;i<T;i++){
         scanf("%d",&n);
 
         war = n;
         decwar = 0;
 
 
         for(j=0;j<n;j++){
             scanf("%lf",&N[j]);
         }
         for(j=0;j<n;j++){
             scanf("%lf",&K[j]);
         }
 
         qsort(N,n,sizeof(double),cmpfunc);
         qsort(K,n,sizeof(double),cmpfunc);
 
         /*for(j=0;j<n;j++){
             printf("%lf ",N[j]);
         }
         printf("\n");
         for(j=0;j<n;j++){
             printf("%lf ",K[j]);
         }*/
 
 
         //war
         for(j=0,k=0;j<n&&k<n;){
             //printf("\nComparing %lf with %lf",N[j],K[k]);
             if(N[j] < K[k]){
                 war--;
                 j++;k++;
             }
             else    k++;
 
         }
 
         //decwar
         for(j=n-1,k=n-1;j>=0&&k>=0;){
             if(N[j] > K[k]){
                 decwar++;
                 j--;k--;
             }
             else    k--;
 
         }
 
 
         printf("Case #%d: %d %d\n",i+1,decwar,war);
     }
     return 0;
 }

