#include<stdio.h>
 main(){
 	int t,k,j,i,c,card[6][6],qcards[27],answer=0;
 	
 	scanf("%d",&t);
 	for (k=0;k<t;k++){
 	printf("Case #%d: ",k+1);
 	answer=0;
 	scanf("%d",&c);
 	for (i = 1;i <= 16; i++)
 	    qcards[i]=0;
 
 	for(i=1;i<=4;i++)
 	   for(j=1;j<=4;j++){
      	scanf("%d",&card[j][i]);
 	   	  if (i == c)
 	       qcards[card[j][i]]++;
 		}
 	scanf("%d",&c);
 	for(i=1;i<=4;i++)
 	   for(j=1;j<=4;j++){
      	scanf("%d",&card[j][i]);
 	   	  if (i == c)
 	       qcards[card[j][i]]++;
 		}
 	for(i=1;i<=16;i++){
 		if (qcards[i]>=2)
 		   if (answer == 0)
 		      answer = i;
 		   else{
 		      printf("Bad magician!\n");
 		      answer = -1;
 		      break;
 		  }
 	}
 	if (answer == 0)
 	   printf("Volunteer cheated!\n");
     else if (answer!=-1)
       printf("%d\n",answer);
    }
 
 }
 

