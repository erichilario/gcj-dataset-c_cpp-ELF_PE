#include<stdio.h>
 main(){
 	double r=2,c,f,x,t,min;
 	int k,T,p;
 	scanf("%d",&T);
 	for(k=1;k<=T;k++){
 	printf("Case #%d: ",k);
 	r=2;
 	p=0;
 	scanf("%lf%lf%lf",&c,&f,&x);
 	t = x/r;
 	min=t;
 	do{
 	if(t<min){
    	   min = t;
    	   p=0;
 	}
 	else
 	   p++;
 	t-=x/r;
 	t+=c/r;
 	r+=f;
 	t+=x/r;
 	}while(t<min||p<20);
 	printf("%.8f\n",min);
    }
 }
 

