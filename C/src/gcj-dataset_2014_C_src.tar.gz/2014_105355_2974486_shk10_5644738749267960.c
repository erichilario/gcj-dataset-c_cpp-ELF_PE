#include<stdio.h>
 #include<stdlib.h>
 
 int A[1000+5],B[1000+5],N;
 
 int normalPlay()
 {
 	int i,points=0;
 	for(i=0;i<N;i++)
 	if(B[0]<A[i]) points++;
 	else
 	{
 		int j; for(j=0;j<N-i;j++) if(B[j]<A[i]) break;
 		for(;j<N-i;j++) B[j-1]=B[j];
 	}
 	return points;
 }
 
 int deceitfulPlay()
 {
 	int i,j=N-1,points=0;
 	for(i=N-1;i>=0;i--)
 	{
 		for(;j>=0;j--) if(A[j]>B[i]) break;
 		if(j==-1) break;
 		points++;
 		j--;
 	}
 	return points;
 }
 
 int compare(const void *x, const void *y) { return *(int*)x > *(int*)y ? -1 : 1; }
 
 int getNumber(char s[10])
 {
 	int num=0,i;
 	for(i=2;s[i]!='\0';i++) num = num*10 + s[i]-'0';
 	for(;i<=6;i++) num=num*10;
 	return num;
 }
 
 int main()
 {
 	int caseNo,totalCases;
 	scanf("%d",&totalCases);
 	for(caseNo=1; caseNo<=totalCases; caseNo++)
 	{
 		printf("Case #%d: ",caseNo);
 		scanf("%d",&N);
 		int i; char num[10];
 		for(i=0;i<N;i++) { scanf("%s",num); A[i]=getNumber(num); }
 		for(i=0;i<N;i++) { scanf("%s",num); B[i]=getNumber(num); }
 		qsort(A,N,sizeof(int),compare);
 		qsort(B,N,sizeof(int),compare);
 		int dRes=deceitfulPlay(),nRes=normalPlay();
 		printf("%d %d",dRes,nRes);
 		if(caseNo!=totalCases) printf("\n");
 	}
 	return 0;
 }
