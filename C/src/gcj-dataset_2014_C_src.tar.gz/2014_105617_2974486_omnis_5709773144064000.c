#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     int t;
     double co=0,c,x,f;
     double time=0.0,n,s1,s2,s3;
     scanf("%d",&t);     //---------no. of test cases--------//
     int y=t+1;
     while(t!=0)
     {
         scanf("%lf %lf %lf",&c,&f,&x);     //--------values of c,f,x----------//
         co=2;
         time=0;
         while(1)
         {
             s1=c/co;
             s2=x/(co + f);
             s3=x/co;
             n=s1+s2;
             if(s3<n)
             {
             time= time + x/co;
             printf("case #%d: %0.7lf\n",y-t,time);
             break;
             }
             time= time + (c/co);
             co=co+f;
         }
     t--;
 
     }
     return 0;
 }

