#include <stdio.h>
 void compute(long double,long double,long double,long double,long double,long long int);
 
 void compute(long double cost,long double farm,long double destination,long double current_time,long double current_rate,long long int index1)
 {
 	if((destination-cost)/current_rate < destination/(current_rate+farm))
 	{
 		printf("Case #%lld: %.9Lf\n",index1+1,current_time + (destination-cost)/current_rate);
 	}
 	else
 	{
 		compute(cost,farm,destination,current_time+ cost/(current_rate+farm),current_rate+farm,index1);
 	}
 }
 int main()
 {
 	long long int test_case,index1;
 	scanf("%lld",&test_case);
 	long double f,c,x,current_time;
 	for(index1=0;index1<test_case;index1++)
 	{
 		scanf("%Lf %Lf %Lf",&c,&f,&x);
 		if(x<=c)
 		{
 			current_time=(x+0.0)/(2+0.0);
 			printf("Case #%lld: %.9Lf\n",index1+1,current_time);
 		}
 		else
 		{
 			compute(c,f,x,c/2.0,2,index1);
 		}
 	}
 	//long double ans=2/3.0;
 	//printf("%.9Lf\n",ans);
 	return 0;
 }
