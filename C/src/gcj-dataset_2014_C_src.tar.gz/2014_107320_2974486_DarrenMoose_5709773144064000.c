//cookies.c
 //written by Tony Ward
 
 #include <stdio.h>
 
 #define BASE_RATE 2     //base rate of cookie production
 
 double solve(double cookieRate, double factoryCost, double factoryRate, double goal);
 
 int main(int argc, char *argv[]) {
    int numCases = 0;
    int currCase = 1;
    double factoryCost = 0;
    double factoryRate = 0;
    double goal = 0;
    
    //read test cases
    scanf("%d", &numCases);
    while (currCase <= numCases) {
       printf("Case #%d: ", currCase);
       scanf("%lf", &factoryCost);
       scanf("%lf", &factoryRate);
       scanf("%lf", &goal);
       double sol = solve(BASE_RATE, factoryCost, factoryRate, goal);
       printf("%0.7f\n", sol);
       currCase++;
    }
    
    return 0;
 }
 
 //finds the shortest possible time to reach goal
 double solve(double cookieRate, double factoryCost, double factoryRate, double goal) {
    double goalTime = goal / cookieRate;                   //time required to reach goal
    double factoryTime = factoryCost / cookieRate;        //time required to buy factory
    double nextCookieRate = cookieRate + factoryRate;      //cookie rate after purchaseing a factory
    double nextGoalTime = goal / nextCookieRate;           //time required to reach goal after purchasing a factory
    
    //check if buying a factory saves us time
    if (factoryTime + nextGoalTime < goalTime) {
       //solve recursively
       //return solution + time to purchase factory
       //cookie rate => cookieRate + factoryRate
       return factoryTime + solve(cookieRate + factoryRate, factoryCost, factoryRate, goal);
    }
    
    //if buying a factory saves no time, return goalTime
    return goalTime;
 }

