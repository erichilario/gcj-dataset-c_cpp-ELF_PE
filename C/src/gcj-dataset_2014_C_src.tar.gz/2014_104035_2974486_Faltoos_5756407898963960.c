#include<stdio.h>
 int main()
 {
 	int test,i=1,arr1[10][10],arr2[10][10],mm,nn,k,j;
 	scanf("%d",&test);
 	for(i=1;i<=test;i++)
 	{
 		scanf("%d",&mm);
  		j=1;
 		int k;
 		for(j=1;j<=4;j++)
 		{
 		for(k=1;k<=4;k++)
 			{ 
 			   scanf("%d",&arr1[j][k]);
  			}
 		}
 		scanf("%d",&nn);
 		for(j=1;j<=4;j++)
 		{
 			for(k=1;k<=4;k++)
 			{
 				scanf("%d",&arr2[j][k]);
 			}
 		}
 		int count=50,ans;
 		for(j=1;j<=4;j++)
 		{
 			for(k=1;k<=4;k++)
 			{
 				if(arr1[mm][j]==arr2[nn][k])
 				{
 				        	count++;
 		    			        ans=arr1[mm][j];
                                 }
 			}
 		}
 		 if(count==50)
 			printf("Case #%d: Volunteer cheated!\n",i);
 		else if(count==51)
 			printf("Case #%d: %d\n",i,ans);
 		else if(count>=52)
 			printf("Case #%d: Bad magician!\n",i);
           }
 
 	return 0;
 }

