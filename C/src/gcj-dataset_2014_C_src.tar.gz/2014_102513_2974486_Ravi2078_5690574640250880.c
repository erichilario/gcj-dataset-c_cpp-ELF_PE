#include <stdio.h>
 
 void solution(int row, int column, int mines)
 {
     if (row == 1 && column == 1 && mines == 1)
     {
         printf("Impossible\n");
         return;
     }
     else if (row == 1 && column > 1 &&  column < mines+2)
     {
         printf("Impossible\n");
         return;
     }
     else if (row > 1 && column == 1 && row < mines+2)
     {
         printf("Impossible\n");
         return;
     }
     else if (row > 1 && column > 1 && column*row < mines+4)
     {
         printf("Impossible\n");
         return;
     }
 
 
     char grid[row][column];
     int i, j;
     int not_mines = row*column - mines - 1;
     // printf("Not mines=%d\n", not_mines);
 
     for (i = 0; i < row; ++i)
         for (j = 0; j < column; ++j)
             grid[i][j] = '*';
 
 
     int dimen = row<column ? row: column;
     // printf("%d\n", dimen);
 
     int c = 0;
     for (i = 0; i < dimen; ++i)
     {
         if (c <= not_mines)
         {
             grid[i][i] = '.';
             c++;
         }
         else
             break;
         for (j = i-1; j > -1; --j)
         {
             if (c <= not_mines)
             {
                 grid[i][j] = '.';
                 c++;
             }
             if (c <= not_mines)
             {
                 grid[j][i] = '.';
                 c++;
             }
         }
     }
 
     // printf("c=%d\n", c);
 
     if (dimen == row)
     {
         for (j = dimen; j < column; ++j)
         {
             for (i = 0; i < row; i++)
             {
                 if (c <= not_mines && grid[i][j] != '.')
                 {
                     grid[i][j] = '.';
                     c++;
                 }
             }
             if (c > not_mines)
                 break;
         }
     }
     else
     {
         for (i = dimen; i < row; i++)
         {
             for (j = 0; j < column; ++j)
             {
                 if (c <= not_mines && grid[i][j] != '.')
                 {
                     grid[i][j] = '.';
                     c++;
                 }
             }
             if (c > not_mines)
                 break;
         }
     }
 
     grid[0][0] = 'c';
 
 
     for (i = 0; i < row; ++i)
     {
         for (j = 0; j < column; ++j)
             printf("%c ", grid[i][j]);
 
         printf("\n");
     }
 
 }
 
 int main(int argc, char const *argv[])
 {
     int cases = 0;
     scanf("%d", &cases);
     int i;
     for (i = 0; i < cases; ++i)
     {
         int row, column, mines;
         scanf("%d %d %d", &row, &column, &mines);
         printf("Case #%d:\n", i+1);
         solution(row, column, mines);
     }
     return 0;
 }

