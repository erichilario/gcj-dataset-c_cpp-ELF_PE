#include<stdio.h>
 int main()
 {
 	int t,x=1;
 	scanf("%d",&t);
 	while(x<=t)
 	{
 		int c1[5][5],c2[5][5],c3[17],n,m,i,j,k;
 		for(k=1;k<=16;k++)
 		c3[k]=0;
 		scanf("%d",&n);
 		for(i=1;i<=4;i++)
 		{
 			for(j=1;j<=4;j++)
 			{
 				scanf("%d",&c1[i][j]);
 			}
 		}
 		scanf("%d",&m);
 		for(i=1;i<=4;i++)
 		{
 			for(j=1;j<=4;j++)
 			{
 				scanf("%d",&c2[i][j]);
 			}
 		}
 		for(j=1;j<=4;j++)
 		{
 			c3[c1[n][j]]++;
 		}
 		for(j=1;j<=4;j++)
 		{
 			c3[c2[m][j]]++;
 		}
 		int flag=0;
 		k=0;
 
 		for(j=1;j<=16;j++)
 		{
 			if(c3[j]==2)
 			{
 				flag++;
 				k=j;
 			}
 		}
 		if(flag==0)
 		printf("Case #%d: Volunteer cheated!\n",x);
 		else
 		if(flag==1)
 		printf("Case #%d: %d\n",x,k);
 		else
 		printf("Case #%d: Bad magician!\n",x);
 		
 		x++;
 	}
 	return 0;
 }

