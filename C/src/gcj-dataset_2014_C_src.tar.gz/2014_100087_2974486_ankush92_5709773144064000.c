#include<stdio.h>
 
 int main()
 {
 	
 	
 	double c, f, x, ans, temp;
 	int k, t, i, j;
 	
 	
 	freopen("B-small-attempt1.in", "r+", stdin);
 	freopen("output.txt", "w+", stdout);
 	
 	
 	scanf("%d",&t);
 	
 	
 	for(k=1; k<=t; k++)
 	{
 		scanf("%lf%lf%lf",&c, &f, &x);
 		
 		ans = x/(2.0);
 		
 		i=0;
 		while(1)
 		{
 			
 			temp = 0;
 			for(j=0; j<=i; j++)
 			{
 				temp += (c/(2+(f*j)));
 			}
 			
 			temp = temp + (x/(2+(f*(i+1))));
 			
 			
 			if(temp<ans)
 				ans = temp;
 			else
 			{
 				break;
 			}
 			
 			i++;
 		}
 		
 		
 		printf("Case #%d: %.7lf\n",k, ans);
 	}
 
 
 
 	return 0;
 }

