{
     int t,n,a[5][5],r1,r2,b[5][5],i,j,x,c,ans;
     x=1;
     scanf("%d",&t);
 	while(x<=t)
     {
         scanf("%d",&r1);
         for(i=1;i<=4;i++)
         {
             for(j=1;j<=4;j++)
             {
                scanf("%d",&a[i][j]);
             }
         }
         scanf("%d",&r2);
         for(i=1;i<=4;i++)
         {
             for(j=1;j<=4;j++)
             {
                scanf("%d",&b[i][j]);
             }
         }
         c=0,ans;
         
         for(i=1;i<=4;i++)
         {
         //	printf("a");
             for(j=1;j<=4;j++)
             {
              //   printf("%d %d                    %d\n", a[r1][i],b[r2][j],j);
 
                 if(a[r1][i] == b[r2][j])
                 {
                     c++;
                     ans=a[r1][i];
                     break;
                 }
             }
         }
 
         if(c==1)
             printf("Case #%d: %d\n",x,ans);
         else if(c>1)
             printf("Case #%d: Bad magician!\n",x);
         else
             printf("Case #%d: Volunteer cheated!\n",x);
 
 
        x++;
     }
 
 	return 0;
 
 }
