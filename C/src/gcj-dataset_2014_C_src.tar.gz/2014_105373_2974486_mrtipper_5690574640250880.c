#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int
 readNum() {
   int val;
   scanf( "%d", &val );
   return val;
 }
 
 void
 print( FILE* fo, char * const grid, int const rows, int const cols ) {
   int i;
   int offset = rows * cols;
   for( i = 0; i < offset; ++i ) {
     if( i > 0 && i % cols == 0 ) {
       fprintf( fo, "\n" );
     }
     fprintf( fo, "%c", grid[ i ] );
   }
   fprintf( fo, "\n" );
 }
 
 void
 fill( char * const grid, int const size ) {
   int i;
   memset( grid, '*', size );
 }
 
 int
 offset( int const rows, int const cols, int row, int col ) {
   return ( row * cols ) + col;
 }
 
 int
 clear( char * const grid, int const rows, int const cols, int const row, int const col, char marker ) {
   if( row >= 0 && col <= cols - 1 &&  row <= rows - 1  && col >= 0 ) {
     int pos = offset( rows, cols, row, col );
     if( grid[ pos ] == '*' ) {
       grid[ pos ] = marker;
       return 1;
     }
   }
   return 0;
 }
 int
 check( char * const grid, int const rows, int const cols, int const row, int const col, int const mines, int const click, int const numCleared ) {
   int numClear = 0;
   numClear += clear( grid, rows, cols, row - 1, col - 1, '.' );
   numClear += clear( grid, rows, cols, row - 1, col, '.' );
   numClear += clear( grid, rows, cols, row - 1, col + 1, '.' );
   numClear += clear( grid, rows, cols, row, col - 1, '.' );
   if( click ) {
      numClear += clear( grid, rows, cols, row, col, 'c' );
   } else {
     numClear += clear( grid, rows, cols, row, col, '.' );
   }    
   numClear += clear( grid, rows, cols, row, col + 1, '.' );
   numClear += clear( grid, rows, cols, row + 1, col - 1, '.' );
   numClear += clear( grid, rows, cols, row + 1, col, '.' );
   numClear += clear( grid, rows, cols, row + 1, col + 1, '.' );
 
   printf( "numClear: %d\n", numClear );
   if( ( rows * cols - numCleared - numClear ) == mines ) {
     return 0;
   } else if( ( rows * cols - numCleared - numClear ) < mines ) {
     return 1;
   } else if( numClear == 0 ) {
     return 1;
   } else {
     if( col == cols - 3 && row < 2 && mines % cols > cols - 2 ) {
       // leave corner
       return check( grid, rows, cols, row + 1, 0, mines, 0, numCleared + numClear );
     } else if( col == cols - 2 ) {
       return check( grid, rows, cols, row + 1, 0, mines, 0, numCleared + numClear );
     } else {
       return check( grid, rows, cols, row, col + 1, mines, 0, numCleared + numClear );
     }
   }
 }
 
 void
 testCase( FILE* fo, int n ) {
   int r = readNum();
   int c = readNum();
   int m = readNum();
   char grid[2500];
   int result;
 
   printf( "testCase: %d\n", n );
   printf( "r: %d, c: %d, m: %d\n", r, c, m );
   
   fill( grid, sizeof(grid)/sizeof(grid[0]) );
   result = check( grid, r, c, 0, 0, m, 1, 0 );
   print( stdout, grid, r, c );
   fprintf( fo, "Case #%d:\n", n );
   if( result ) {
     fprintf( fo, "Impossible\n" );
   } else {
     print( fo, grid, r, c );
   }
 }
 
 int
 main( int argc, char** argv ) {
   int numCases ;
   int i;
   FILE* fo = fopen( "output.txt", "w");
 
   numCases = readNum();
   printf( "numCases: %d\n", numCases );
   for( i = 0; i < numCases; ++i ) {
     testCase( fo, i + 1 );
   }
   return 0;
 }

