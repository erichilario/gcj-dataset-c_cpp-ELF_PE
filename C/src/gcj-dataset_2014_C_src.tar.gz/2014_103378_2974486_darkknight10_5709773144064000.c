#include<stdio.h>
 int main()
 {
 int t,i;
 double f,c,x,temp=0.0,time=0.0,rate=2.0;
 scanf("%d",&t);
 for(i=0;i<t;i++)
 {
     rate=2.0;
     time=0.0;
 scanf("%lf %lf %lf",&c,&f,&x);
 while(temp!=x)
 {
 if(x/rate<(c/rate)+(x/(rate+f)))
 {
 time=time+x/rate;
 break;
 }
 else
 {
 time=time+c/rate;
 rate=rate+f;
 temp=0.0;
 }
 }
 printf("Case #%d: %.7lf\n",i+1,time);
 }
 return 0;
 }

