#include <stdio.h>
 
 double cal(double c, double f, double x)
 {
 	double t = 0.0;
 	double speed = 2.0;
 
 	while (x / speed > (c / speed + x / (speed + f)))
 	{
 		t += c / speed;
 		speed += f;
 	}
 
 	t += x / speed;
 
 	return t;
 }
 
 int main()
 {
 	int n, i;
 	scanf("%d", &n);
 
 	for (i = 1; i < n + 1; ++i)
 	{
 		double C, F, X, res;
 		scanf("%lf%lf%lf", &C, &F, &X);
 
 		res = cal(C, F, X);
 		printf("Case #%d: %.7lf\n", i, res);
 	}
 	return 0;
 }
