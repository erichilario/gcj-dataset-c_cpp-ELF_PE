#include <stdio.h>
 
 int main()
 {
 	int T,i,j,k,c;
 	int card1[4][4];
 	int card2[4][4];
 	int a1,a2,ans;
 		
 	fscanf(stdin, "%d", &T);
 	for(k=0;k<T;k++)
 	{
 		fscanf(stdin, "%d", &a1);
 		a1--;
 		for(i=0;i<4;i++)
 		for(j=0;j<4;j++)
 		fscanf(stdin, "%d", &card1[i][j]);
 		
 		fscanf(stdin, "%d", &a2);
 		a2--;
 		for(i=0;i<4;i++)
 		for(j=0;j<4;j++)
 		fscanf(stdin, "%d", &card2[i][j]);
 		
 		c=0;
 		for(i=0;i<4;i++)
 		for(j=0;j<4;j++)
 		{
 			if(card1[a1][i] == card2[a2][j]) 
 			{
 				ans=card1[a1][i];
 				c++;
 			}
 		}
 		printf("Case #%d: ", k+1);
 		if(c==0) printf("Volunteer cheated!\n");
 		else if(c==1) printf("%d\n", ans);
 		else printf("Bad magician!\n");
 	}
 	
 	return 0;
 }
 			
 		
