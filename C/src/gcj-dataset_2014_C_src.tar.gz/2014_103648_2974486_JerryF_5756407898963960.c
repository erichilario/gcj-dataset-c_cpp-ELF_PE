/*
   Problem A. Magic Trick
 
   make magic
   ./magic
 */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 int main (int argc, char *argv[])
 {
     FILE *fin = NULL;
     FILE *fout = NULL;
     int n_test_cases = 0;
     int i_test;
     int answer1, answer2;
     int grid1[4][4];
     int grid2[4][4];
     int i,j;
     int card;
 
     if (argc<2) {
         printf("provide input file name\n");
         return 1;
     }
 
     fin = fopen(argv[1],"r");
     fscanf(fin, "%d", &n_test_cases);
 
     fout = fopen("output.txt","w");
 
     for (i_test = 1; i_test <= n_test_cases; i_test++) {
 
         fscanf(fin, "%d", &answer1);
         for (i=0; i<4; i++) {
             for (j=0; j<4; j++) {
                 fscanf(fin, "%d", &grid1[i][j]);
             }
         }
 
         fscanf(fin, "%d", &answer2);
         for (i=0; i<4; i++) {
             for (j=0; j<4; j++) {
                 fscanf(fin, "%d", &grid2[i][j]);
             }
         }
 
         /* make zero-referenced for array indexing */
         answer1--;
         answer2--;
 
         /*
           Search for cards that appear in both of the selected rows.
           There should be only one.
           If there is more than one, bad magician!
           If there are none, volunteer cheeted!
           More elegant would be to join the two rows, sort, and find duplicates.
         */
         card = 0;
         for (i=0; i<4; i++) {
             for (j=0; j<4; j++) {
                 if (grid1[answer1][i] == grid2[answer2][j]) {
                     if (card==0) {
                         card = grid1[answer1][i];
                     } else if (card>0) {
                         card = -1;
                     }
                 }
             }
         }
 
         if (card>0) {
             fprintf(fout, "Case #%d: %d\n", i_test, card);
         } else if (card == 0) {
             fprintf(fout, "Case #%d: Volunteer cheated!\n", i_test);
         } else {
             fprintf(fout, "Case #%d: Bad magician!\n", i_test);
         }
 
     }  /* i_test */
 
 	fclose(fin);
 	fclose(fout);
 	return 0;
 }

