#include<stdio.h>
 #include<stdlib.h>
 
 int main() {
 	int t, i;
 	double c,f,x;
 	scanf("%d", &t);
 	for(i=0; i < t;i++) {
 		scanf("%lf %lf %lf", &c, &f, &x);
 		double seconds = 0 , cookies = 0, rate = 2;
 		if(c >= x) {
 			seconds = x / rate;
 		}
 		else {
 			seconds += (c / rate);
 			while(((x-c)/rate) > (x/(rate+f))) {
 				rate += f;
 				seconds += c / rate;
 			}
 			seconds += (x-c)/rate; 				
 		}
 		printf("Case #%d: %lf\n", i+1 , seconds);
 	}
 	return 0;
 }
