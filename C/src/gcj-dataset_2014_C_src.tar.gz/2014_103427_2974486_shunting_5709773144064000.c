#include <stdio.h>
 
 #define GAP 0.00000000001
 
 int
 main(void) {
 	int T, seq;
 	double C, F, X;
 	int n;
 	double totTime = 0.0;
 
 	scanf("%d", &T);
 	for (seq = 1; seq <= T; seq++) {
 		scanf("%lf%lf%lf", &C, &F, &X);
 
 		double sol = (X / C - 2 / F) - 1;
 		if (sol <= 0) {
 			n = 0;
 		} else if (sol < (int) sol + GAP) {
 			n = (int) sol;
 		} else {
 			n = (int) sol + 1;
 		}
 
 		totTime = 0;
 		int i;
 		for (i = 0; i < n; i++) {
 			totTime += C / (2 + i * F);
 		}
 		totTime += X / (2 + n * F);
 		printf("Case #%d: %.7f\n", seq, totTime);
 	}
 	return 0;
 }

