#include <stdio.h>
 #include <stdlib.h>
 long long int size=1000;
 long long int temp[1000];
 void mergesort(long long int *,long long int,long long int);
 void merge(long long int *,long long int ,long long int);
 void compute_deceitfl_war(long long int *,long long int *, long long int);
 void compute_war(long long int *,long long int *, long long int);
 
 void compute_deceitfl_war(long long int *arr1,long long int *arr2, long long int len)
 {
 	long long int count,index1,index2;
 	index1=0;
 	index2=0;
 	count=0;
 	while(index1<len)
 	{
 		if(arr1[index1]>arr2[index2])
 		{
 			count++;
 			index1++;
 			index2++;
 		}
 		else
 		{
 			index1++;
 		}
 	}
 	printf("%lld ",count);
 }
 
 void compute_war(long long int *arr1,long long int *arr2, long long int len)
 {
 	long long int count,index1,index2;
 	index1=0;
 	index2=0;
 	count=0;
 	while(index2<len)
 	{
 		if(arr1[index1]>arr2[index2])
 		{
 			index2++;
 		}
 		else
 		{
 			count++;
 			index2++;
 			index1++;
 		}
 	}
 	count=len-count;
 	printf("%lld\n",count);
 	//return count;
 }
 
 void merge(long long int *array,long long int low,long long int high)
 {
 	long long int index1,index2,index=0;
 	index1=low;
 	index2=(low+high)/2 +1;
 	while(index<high-low+1)
 	{
 		if(index2<=high)
 		{
 			if(index1<=(high+low)/2)
 			{
 				if(array[index1]>array[index2])
 				{
 					temp[index]=array[index2];
 					index2++;
 				}
 				else
 				{
 					temp[index]=array[index1];
 					index1++;
 				}
 			}
 			else
 			{
 				temp[index]=array[index2];
 				index2++;
 			}
 		}
 		else
 		{
 			temp[index]=array[index1];
 			index1++;
 		}
 		index++;
 	}
 	index=0;
 	while(index<high-low+1)
 	{
 		
 		array[index+low]=temp[index];
 		index++;
 	}
 }
 
 void mergesort(long long int *array,long long int low ,long long int high)
 {
 	
 	if(low<high)
 	{
 		mergesort(array,low,(low+high)/2);
 		mergesort(array,(low+high)/2 +1,high);
 		merge(array,low,high);
 	}
 }
 
 int main()
 {
 	long double temp1;
 	long long int test_case,num,index1,arr1[size],arr2[size],index2;
 	scanf("%lld",&test_case);
 	//printf("%lld\n",test_case);
 	
 	for(index1=0;index1<test_case;index1++)
 	{
 		scanf("%lld",&num);
 		//printf("%lld\n",num);
 		
 		for(index2=0;index2<num;index2++)
 		{
 			scanf("%Lf",&temp1);
 			arr1[index2]=(int)(temp1*100000);
 		}
 
 		
 		for(index2=0;index2<num;index2++)
 		{
 			scanf("%Lf",&temp1);
 			arr2[index2]=(int)(temp1*100000);
 		}
 		
 		mergesort(arr1,0,num-1);
 		mergesort(arr2,0,num-1);
 		printf("Case #%lld: ",index1+1);
 		compute_deceitfl_war(arr1,arr2,num);
 		compute_war(arr1,arr2,num);
 	}
 	return 0;
 }
