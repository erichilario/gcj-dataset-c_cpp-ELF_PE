#include <stdio.h>
 
 void solve(double C, double F, double X, int n_case) {
   double temp = ((X-C)*F/C - 2)/F;
   int r = -1;
   double result = 0.0;
   if(temp >= 0) r = (int)temp;
   int i;
   for(i=0;i<=r;i++)
     result += C/((double)(i)*F+2);
   result += X/((double)(r+1)*F+2);
   fprintf(stdout, "Case #%d: %.7lf\n", n_case, result);
   return;
 }
 
 int main(void) {
   int T, n_case = 1;
   double C, F, X;
   fscanf(stdin, "%d", &T);
   while(T>0) {
     fscanf(stdin, "%lf %lf %lf", &C, &F, &X);
     solve(C,F,X,n_case++);
     T--;
   }
 
   return(0);
 }

