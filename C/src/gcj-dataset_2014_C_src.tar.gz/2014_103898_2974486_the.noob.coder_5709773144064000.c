#include<stdio.h>
 #include<stdlib.h>
 
 struct number
 {
 	long double farm_cost;
 	long double farm_output;
 	long double cookie_number;
 };
 	typedef struct number Number;
 
 int farm_number(long double farm_cost,long double farm_output,long double cookie_number);
 long double time_taken(long double farm_cost,long double farm_output,long double cookie_number);
 
 
 int main(void)
 {
 	int test_number,counter;
 	long double *time;
 	Number *arr; 
 	scanf("%d",&test_number);
 	arr=(Number *)malloc(test_number*sizeof(Number));
 	time=(long double *)malloc(test_number*sizeof(long double));
 	for(counter=0;counter<test_number;counter++)
 	{
 		scanf("%Lf",&arr[counter].farm_cost);
 		scanf("%Lf",&arr[counter].farm_output);
 		scanf("%Lf",&arr[counter].cookie_number);
 		
 	}
 	for(counter=0;counter<test_number;counter++)
 		time[counter]=time_taken(arr[counter].farm_cost,arr[counter].farm_output,arr[counter].cookie_number);	
 
 	for(counter=0;counter<test_number;counter++)
 	{
 		printf("Case #%d: %Lf \n",counter+1,time[counter]);
 	}
 	return 0;
 }
 
 int farm_number(long double farm_cost,long double farm_output,long double cookie_number)
 {
 	int dummy_2;
 	long double dummy;
 	dummy=(cookie_number*farm_output-2*farm_cost-farm_output*farm_cost)/(farm_cost*farm_output);
 	dummy_2=(int)((cookie_number*farm_output-2*farm_cost-farm_output*farm_cost)/(farm_cost*farm_output));
 	if(dummy<=0)
 		return 0;
 	else
 	{
 		if(dummy==dummy_2)
 			return dummy_2;
 		else
 			return (dummy_2+1);
 	}
 }
 
 long double time_taken(long double farm_cost,long double farm_output,long double cookie_number)
 {
 	long double time_t=0;
 	int farms=farm_number(farm_cost,farm_output,cookie_number);
 	int counter;
 	for(counter=0;counter<=farms-1;counter++)
 		time_t+=farm_cost*(1.0/(2+(counter*farm_output)));
 	time_t+=cookie_number/(2.0+farms*farm_output);
 	return time_t;
 } 

