#include<stdio.h>
 int main()
 {
     int a[18],t,test,i,j,flag,temp,res,ans;
     scanf("%d",&test);
     for(t=1;t<=test;t++)
     {
         flag=0,res=0,temp=0,ans=0;
         scanf("%d",&ans);
         for(i=0;i<18;i++)
             a[i]=0;
         for(i=0;i<4;i++)
         {
             for(j=0;j<4;j++)
             {
                 scanf("%d",&temp);
                 if(i+1==ans)
                 {
                     a[temp]=1;
                 }
             }
         }
         scanf("%d",&ans);
         for(i=0;i<4;i++)
         {
             for(j=0;j<4;j++)
             {
                 scanf("%d",&temp);
                 if(i+1==ans)
                 {
                     if(a[temp]==1)
                     {
                         if(flag==1)
                             flag=2;
                         if(flag==0)
                         {    res=temp;
                             flag=1;
                         }
                     }
                 }
             }
         }
         if(flag==2)
             printf("Case #%d: Bad magician!\n",t);
         if(flag==0)
             printf("Case #%d: Volunteer cheated!\n",t);
         if(flag==1)
             printf("Case #%d: %d\n",t,res);
         
     }
     
     
     return 0;
 }

