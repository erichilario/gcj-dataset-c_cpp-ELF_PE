#include<stdio.h>
 int main()
 {
     int T,i,j,x,a[4][4],b[4][4],c,d,out,counter=0;
     scanf("%d",&T);
     int Ti=T;
     int count[T],output[T];
     x=0;
     while(T!=0)
     {
         scanf("%d",&c);
         for(i=0;i<=3;i++)
         {
             for(j=0;j<=3;j++)
             {
                 scanf("%d",&a[i][j]);
             }
         }
         scanf("%d",&d);
         for(i=0;i<=3;i++)
         {
             for(j=0;j<=3;j++)
             {
                 scanf("%d",&b[i][j]);
             }
         }
         for(i=0;i<=3;i++)
         {
             for(j=0;j<=3;j++)
             {
                 if(a[c-1][i] == b[d-1][j])
                 {
                     out=a[c-1][i];
                     counter++;
                 }
 
             }
         }
 
         output[x]=out;
         count[x]=counter;
         counter=0;
         T--;
         x++;
     }
 
     for(i=0;i<Ti;i++)
     {
         if(count[i]==1)
             printf("\nCase #%d: %d",i+1,output[i]);
         else if(count[i]==0)
             printf("\nCase #%d: Volunteer Cheated!",i+1);
         else if(count[i]>1)
             printf("\nCase #%d: Bad Magician!",i+1);
     }
     return 0;
 }

