#include <stdio.h>
 
 double X = 2000;
 double F = 4;
 double C = 500;
 
 double getTime(double current, double rate)
 {
 	double timeWithoutPurchase, timeWithPurchase, currentAfterBuying, timeToPurchase;
 	if(current >= X)
 		return 0;
 	else
 	{
 		timeWithoutPurchase = (X - current) / rate;
 	}
 
 	if(current <= C)
 	{
 		timeToPurchase = (C - current) / rate;
 		currentAfterBuying = 0;
 	}
 	else
 	{
 		timeToPurchase = 0;
 		currentAfterBuying = current - C;
 	}
 
 	timeWithPurchase = timeToPurchase + (X - currentAfterBuying) / (rate + F);
 	if(timeWithPurchase < timeWithoutPurchase)
 	{
 		return timeToPurchase + getTime(currentAfterBuying, rate + F);
 	}
 	else
 		return timeWithoutPurchase;
 }
 
 int main()
 {
 	int t, iter;
 	scanf(" %d", &t);
 	for(iter = 0; iter < t; iter++)
 	{
 		scanf(" %lf %lf %lf", &C, &F, &X);
 		double timeTaken = getTime(0, 2);
 		printf("Case #%d: %.7lf\n", iter + 1, timeTaken);
 	}
 
 	return 0;
 }
