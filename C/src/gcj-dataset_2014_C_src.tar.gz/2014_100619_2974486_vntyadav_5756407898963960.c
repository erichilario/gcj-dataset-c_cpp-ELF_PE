#include <stdio.h>
 int main()
 {
 	long int test_case,index1,index2,index3,num1,num2,ans,count,temp;
 	scanf("%ld",&test_case);
 	long int arr1[4],arr2[4];
 	for(index1=0;index1<test_case;index1++)
 	{
 		count=0;
 		scanf("%ld",&num1);
 		//printf("%ld\n",num1);
 		for(index2=0;index2<4;index2++)
 		{
 			for(index3=0;index3<4;index3++)
 			{
 				if(index2+1==num1)
 				{
 					scanf("%ld",&arr1[index3]);
 				}
 				else
 				{
 					scanf("%ld",&temp);
 				}
 			}
 		}
 		scanf("%ld",&num2);
 		//printf("%ld\n",num2);
 		for(index2=0;index2<4;index2++)
 		{
 			for(index3=0;index3<4;index3++)
 			{
 				if(index2+1==num2)
 				{
 					scanf("%ld",&arr2[index3]);
 
 				}
 				else
 				{
 					scanf("%ld",&temp);
 				}
 			}
 		}
 		
 		
 		//scanf("%ld",&num1);
 		for(index2=0;index2<4;index2++)
 		{
 			for(index3=0;index3<4;index3++)
 			{
 				if(arr1[index2]==arr2[index3])
 				{
 					ans=arr1[index2];
 					count++;
 				}
 			}
 		}
 		if(count==1)
 		{
 			if(index1<test_case-1)
 			{
 				printf("Case #%ld: %ld\n",index1+1,ans);
 			}
 			else
 			{
 				printf("Case #%ld: %ld",index1+1,ans);
 			}
 		}
 		if(count>1)
 		{
 			if(index1<test_case-1)
 			{
 				printf("Case #%ld: Bad magician!\n",index1+1);
 			}
 			else
 			{
 				printf("Case #%ld: Bad magician!",index1+1);
 			}
 		}
 		if(count==0)
 		{
 			if(index1<test_case-1)
 			{
 				printf("Case #%ld: Volunteer cheated!\n",index1+1);
 			}
 			else
 			{
 				printf("Case #%ld: Volunteer cheated!",index1+1);
 			}
 		}
 	}
 	return 0;
 }

