#include<stdio.h>
 
 int main(void){
 
   int i, j, k, t, first_row, second_row;
   int counter, result;
   int first_array[4][4], second_array[4][4];
 
   scanf("%d", &t);
 
   for(i=1; i<=t; i++){
 
     counter = 0;
 
     scanf("%d", &first_row);
     first_row--;
     for(j=0; j<4; j++)
       scanf("%d %d %d %d", &first_array[j][0]
                          , &first_array[j][1]
                          , &first_array[j][2]
                          , &first_array[j][3]);
 
     scanf("%d", &second_row);
     second_row--;
     for(j=0; j<4; j++)
       scanf("%d %d %d %d", &second_array[j][0]
                          , &second_array[j][1]
                          , &second_array[j][2]
                          , &second_array[j][3]);
 
     for(j=0; j<4; j++){
       for(k=0; k<4; k++){
         if(first_array[first_row][j] == second_array[second_row][k]){
           counter++;
           result = first_array[first_row][j];
         }
       }
     }
 
     switch(counter){
       case 0:
         printf("Case #%d: Volunteer cheated!\n", i);
         break;
       case 1:
         printf("Case #%d: %d\n", i, result);
         break;
       default:
         printf("Case #%d:  Bad magician!\n", i);
     }
   }
 
   return 1;
 }

