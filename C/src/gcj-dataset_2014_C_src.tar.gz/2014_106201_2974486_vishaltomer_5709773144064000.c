#include <stdio.h>
 int main()
 {
     int t;
     scanf ("%d",&t);
     int i;
     for(i=1;i<=t;++i)
     {
         double a,b,c,d,j,k,f,x;
         scanf("%lf %lf %lf",&c,&f,&x);
         a=0.0;
         k=x/2;
         d=2.0;
         do
         {
             b=a+k;
             j=c/d;
             a=a+j;
             d=d+f;
             k=x/d;
         }while (a+k<b);
         printf("Case #%d: %.7lf\n",i,b);
     }
     return (0);
 }

