#include <stdio.h>
 
 int main(void) {
 	int k,i,ch,j;
 	float c,f,x,t1,t2,t,tmp,ans,m;
 	scanf("%d",&k);
 	for(i=1;i<=k;i++)
 	{
 		scanf("%f %f %f",&c,&f,&x);
 		ch=(x/c);
 		m=2;
 		t1=c/m;
 		t2=x/m;
 		ans=t2;
 		t=0;
 		tmp=0;
 		for(j=0;j<=ch;j++)
 		{
 			t+=t1;
 			m+=f;
 			t1=c/m;
 			t2=x/m;
 			tmp=t+t2;
 			if(tmp<ans)
 			ans=tmp;
 			else
 			break;
 		}
 		printf("Case #%d: %f\n",i,ans);
 	}
 	return 0;
 }

