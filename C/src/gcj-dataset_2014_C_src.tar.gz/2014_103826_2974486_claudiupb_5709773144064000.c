#include <stdio.h>
 #ifdef D
 #define print_line() printf("%d\n",__LINE__)
 #define print_int(a) printf("%d\n",a)
 #define print_float(a) printf("%.7f\n",a)
 #define print_char(a) printf("%c\n",a)
 #else
 #define print_line()
 #define print_int(a)
 #define print_float(a)
 #define print_char(a)
 #endif
 int main(){
 	int t,T;
 	double C,F,X,rate,time;
 	scanf("%d\n",&T);
 	print_int(T);
 	for (t=1;t<=T;t++)
 	{
 		scanf("%lf",&C);
 		scanf("%lf",&F);
 		scanf("%lf",&X);
 		print_float(C);
 		print_float(F);
 		print_float(X);
 		for(rate=2, time=0 ; (X/rate) > ( C/rate + X/(rate+F)) ; time+=C/rate, rate+=F);
 		time+=X/rate;
 		printf("Case #%d: %.7lf\n",t,time);
 	}
 	return 0;
 }
