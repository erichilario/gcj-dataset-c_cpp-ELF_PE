/*
  * Problem A. Magic Trick - Qualification Round 2014 - Google Code Jam
  *
  * Author : Marasinghe, M.M.D.B. | dhammikammdb123@gmail.com
  * Date : 2014/04/12 06:30:59
  */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 #define SIZE 16
 
 void scanArray(int array[SIZE]);
 
 int main(){
 	int T = 1, cases, firsrRow, secondRow, card, i, j, found;
 	int first[SIZE] = {}, second[SIZE] = {};
 	
 	scanf("%d", &cases);
 	
 	while(T<=cases){
 		card = 0;
 		found = 0;
 		
 		scanf("%d", &firsrRow);
 		scanArray(first);
 		scanf("%d", &secondRow);
 		scanArray(second);
 		
 		for(i=(4*(firsrRow-1)); i<(4*firsrRow); i++){
 			for(j=(4*(secondRow-1)); j<(4*secondRow); j++){
 				if(first[i] == second[j]){
 					card = first[i];
 					found++;
 				}
 			}
 		}
 		
 		if(found == 1){
 			printf("Case #%d: %d\n", T, card);
 		}else if(found > 1){
 			printf("Case #%d: Bad magician!\n", T);
 		}else if(found == 0){
 			printf("Case #%d: Volunteer cheated!\n", T);
 		}	
 		
 		T++;
 	}
 	
 	return EXIT_SUCCESS;
 }
 
 void scanArray(int array[SIZE]){
 	int i;
 	for(i=0; i<SIZE; i++){
 		scanf("%d", &array[i]);
 	}
 }

