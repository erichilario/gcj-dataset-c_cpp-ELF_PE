#define _CRT_SECURE_NO_WARNINGS
 #include <stdio.h>
 int main(void){
 	FILE* in = fopen("B-large.in", "r");
 	FILE* out = fopen("out.txt", "w");
 	int j = 1;
 	int count_of_cases = 0;
 	double result1 = 0;
 	double result2 = 0;
 	double C = 0;
 	double F = 0;
 	double X = 0;
 	fscanf(in, "%d", &count_of_cases);
 	while (j <= count_of_cases){
 		double i = 0;
 		double tmp = 0;
 		fscanf(in, "%lf", &C);
 		fscanf(in, "%lf", &F);
 		fscanf(in, "%lf", &X);
 		result1 = X / 2;
 		while (1){
 			tmp += (C / (2 + i * F));
 			result2 = tmp + (X / (2 + (i + 1) * F));
 			if (result2 > result1){
 				break;
 			}
 			result1 = result2;
 			i++;
 		}
 		fprintf(out, "Case #%d: %lf", j, result1);
 		fprintf(out, "\n");
 		j++;
 	}
 	return 0;
 }
