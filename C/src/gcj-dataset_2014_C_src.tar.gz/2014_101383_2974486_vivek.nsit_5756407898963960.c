#include <stdio.h>
 
 int main(void) {
 	int t,x,y,a[5][5],b[5][5],i,j,cnt,tmp,u,v,h;
 	scanf("%d",&t);
 	for(h=1;h<=t;h++)
 	{
 		scanf("%d",&x);
 		for(i=1;i<=4;i++)
 		{
 			for(j=1;j<=4;j++)
 			{
 				scanf("%d",&a[i][j]);
 			}
 		}
 		scanf("%d",&y);
 		for(i=1;i<=4;i++)
 		{
 			for(j=1;j<=4;j++)
 			{
 				scanf("%d",&b[i][j]);
 			}
 		}
 		cnt=0;
 		for(u=1;u<=4;u++)
 		{
 			for(v=1;v<=4;v++)
 			{
 				if(a[x][v]==b[y][u])
 				{
 					cnt++;
 					tmp=a[x][v];
 				}
 			}
 		}
 		if(cnt==0)
 		printf("Case #%d: Volunteer cheated!\n",h);
 		else if(cnt==1)
 		printf("Case #%d: %d\n",h,tmp);
 		else
 		printf("Case #%d: Bad magician!\n",h);
 	}
 	return 0;
 }

