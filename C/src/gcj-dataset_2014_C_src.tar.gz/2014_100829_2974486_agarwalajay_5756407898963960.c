#include<stdio.h>
 
 main()
 {
 
     int t;
     int n=0;
     scanf(" %d",&t);
     while(t--)
     {
         n++;
         int r1,r2,count=0,res,i,j;
         int old[4][4],ne[4][4];
         scanf(" %d",&r1);
         for(i=0;i<4;i++)
         {
             for(j=0;j<4;j++)
                 scanf(" %d",&old[i][j]);
         }
         scanf(" %d",&r2);
         for(i=0;i<4;i++)
         {
             for(j=0;j<4;j++)
                 scanf(" %d",&ne[i][j]);
         }
 
         for(i=0;i<4;i++)
         {
             for(j=0;j<4;j++)
             {
                 if(old[r1-1][i]==ne[r2-1][j])
                 {
                     count++;
                     res=old[r1-1][i];
                 }
 
 
 
             }
         }
         if(count==1)
             printf("Case #%d: %d\n",n,res);
         else if(count==0)
             printf("Case #%d: Volunteer cheated!\n",n);
         else
             printf("Case #%d: Bad magician!\n",n);
     }
     return 0;
 }

