#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
   int table[4][4];
   int i,j,k=0;
   
   int tmp[4];
   
   int* ans;
   int* choose;
   int request;
   int nbCases;
   
   //number of cases
   scanf("%d",&nbCases);
   ans=(int*)malloc(nbCases * sizeof(int));
   choose=(int*)malloc(nbCases * sizeof(int));
   while(k<nbCases)
     {
       for(i=0;i<4;i++)
 	tmp[i]=0;
 
       //row select
 	scanf("%d",&request);
 	
 	for(i=0;i<4;i++)
 	  for(j=0;j<4;j++)
 	    scanf("%d",&table[i][j]);
 	
 	for(i=0;i<4;i++)
 	  tmp[i]=table[request-1][i];
 	
 	scanf("%d",&request);
 	
 	for(i=0;i<4;i++)
 	  for(j=0;j<4;j++)
 	    scanf("%d",&table[i][j]);
 	
 	//solving
 	ans[k]=0;
 	for(i=0;i<4;i++)
 	  for(j=0;j<4;j++)
 	    if(tmp[i]==table[request-1][j])
 		{ 
 		  ans[k]++;
 		  choose[k]=tmp[i];
 		}
 	k++;
 	
     }
   //printing
   for(k=0;k<nbCases;k++)
     {
       if(ans[k]==0)
 	printf("Case #%d: Volunteer cheated!\n",k+1);
       else if(ans[k]==1)
 	printf("Case #%d: %d\n",k+1,choose[k]);
       else
 	printf("Case #%d: Bad magician!\n",k+1);
     }
   return 0;
 }

