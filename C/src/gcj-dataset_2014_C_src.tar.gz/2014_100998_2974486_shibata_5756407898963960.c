#include <stdio.h>
 
 int exist(int *list, int n) {
 	int i;
 	for (i = 0; i < 4; i++) {
 		if (list[i] == n)
 			return 1;
 	}
 	return 0;
 }
 
 int main () {
 	int t, i, j, escolha;
 	int possiveis[4], cartas[4];
 	scanf("%d", &t);
 	for (i = 1; i <= t; i++) {
 		scanf("%d", &escolha);
 		escolha--;
 		for (j = 0; j < 4; j++) {
 			if (j == escolha)
 				scanf("%d%d%d%d", &possiveis[0], &possiveis[1], &possiveis[2], &possiveis[3]);
 			else
 				scanf("%*d%*d%*d%*d");
 		}
 		scanf("%d", &escolha);
 		escolha--;
 		int existe = -1, ruim = 0;
 		for (j = 0; j < 4; j++) {
 			if (j == escolha) {
 				scanf("%d%d%d%d", &cartas[0], &cartas[1], &cartas[2], &cartas[3]);
 				int k;
 				for (k = 0; k < 4; k++) {
 					if (exist(possiveis, cartas[k])) {
 						if (existe != -1)
 							ruim = 1;
 						else
 							existe = cartas[k];
 					}
 				}
 			} else
 				scanf("%*d%*d%*d%*d");
 		}
 		printf("Case #%d: ", i);
 		if (ruim)
 			printf("Bad magician!\n");
 		else if (existe == -1)
 			printf("Volunteer cheated!\n");
 		else
 			printf("%d\n", existe);
 	}
 	return 0;
 }

