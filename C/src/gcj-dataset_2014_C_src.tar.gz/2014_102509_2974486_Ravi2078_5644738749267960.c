#include <stdio.h>
 #include <stdlib.h>
 
 int solution(double naomi[], double ken[], int size)
 {
     int i, j;
     int war = 0;
 
     double n[size], k[size];
 
     for (i = 0; i < size; ++i)
     {
         n[i] = naomi[i];
         k[i] = ken[i];
     }
 
     for (i = 0; i < size; ++i)
     {
         int imin = 0, imax = 0, iopti = 0;
         double opti = 1.0, max = 0.0, min = 1.0;
         for (j = 0; j < size; ++j) {
             if (k[j] > 0.0 && k[j] < 1.0)
             {
                 if(k[j] < min)
                 {
                     imin = j;
                     min = k[j];
                 }
                 if(k[j] > max)
                 {
                     imax = j;
                     max = k[j];
                 }
 
                 if((k[j] - n[i]) > 0.0 && (k[j] - n[i]) < opti)
                 {
                     iopti = j;
                     opti = k[j] - n[i];
                 }
             }
         }
         // printf("\n%lf\n", n[i]);
         // printf("%lf %lf %lf\n", k[imax], k[imin], k[iopti]);
         if (n[i] > k[imax])
         {
             war++;
             k[imin] == 0.0;
         }
         else
         {
             k[iopti] = 1.0;
         }
     }
 
     return war;
 }
 
 int main(int argc, char const *argv[])
 {
     int cases = 0;
     scanf("%d", &cases);
     int i;
     for (i = 0; i < cases; ++i)
     {
         int blocks;
         scanf("%d", &blocks);
         double *naomi = (double *) malloc(sizeof(double) * blocks);
         double *ken = (double *) malloc(sizeof(double) * blocks);
 
         int j;
         for (j = 0; j < blocks; ++j)
             scanf("%lf", &naomi[j]);
         for (j = 0; j < blocks; ++j)
             scanf("%lf", &ken[j]);
 
         int war = solution(naomi, ken, blocks);
         int deciet_war = blocks - solution(ken, naomi, blocks);
 
         printf("Case #%d: %d %d\n", i+1, deciet_war, war);
 
         free(naomi);
         free(ken);
     }
     return 0;
 }

