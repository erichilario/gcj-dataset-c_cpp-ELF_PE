#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
 int T;
 
 scanf("%d",&T);
 //if((T>100)||(T<1))
 //	perror("out of limit");
 int i;
 long double c[T];
 long double f[T];
 long double x[T];
 for(i=0;i<T;i++)
 	{
 	scanf("%Lf",&c[i]);	
 	scanf("%Lf",&f[i]);
 	scanf("%Lf",&x[i]);
 	}
 
 long double temp=0;
 long double temp2=0;
 long double ans;
 long double count=0;
 int gnum=0;
 long double n=2;
 long double t0=0;
 for(i=0;i<T;i++)
 	{
 	gnum++;
 	temp=x[i]/2;
 	t0=c[i]/2;
 	n=n+f[i];
 	temp2=x[i]/n;
 	temp2=temp2+t0;
 	//printf("temp=%Lf, temp2=%Lf\n",temp,temp2);
 	while(temp>temp2)
 		{
 		//printf("temp=%Lf, temp2=%7Lf\n",temp,temp2);
 		temp=temp2;
 		t0=t0+c[i]/n;
 		n=n+f[i];
 		temp2=x[i]/n;
 		temp2=temp2+t0;	
 		}
 	printf("Case #%d: %16.7Lf\n",gnum,temp);
 	temp=0.000000000;
 	temp2=0.00000000;
 	t0=0.000000000;
 	n=2;
 	}
 	
 	
 }

