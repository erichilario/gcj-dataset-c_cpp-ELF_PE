#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 
 FILE *ip = NULL, *op = NULL;
 
 double find_opt_time(double C, double F, double X)
 {
   double cok = 2.0;
   double sum = 0.0, last_val = 0.0, cur_val = 0.0;
 
   if (X < C) {
     return (X/cok);
   }
 
   last_val = X/cok;
   sum = C/cok;
   cok += F;
   cur_val = sum + X/cok;
   while(cur_val < last_val) {
     sum += C/cok;
     last_val = cur_val;
     cok += F;
     cur_val = sum + X/cok;
   }
 
   return last_val;
 }
 
 
 int main()
 {
   int T, i = 0;
   double C = 0, F = 0, X = 0, res;
   char line[80], ops[80];
   char val[50], *ptr = NULL, *ptr1=NULL;
 
   ip = fopen("input.txt", "r");
   op = fopen("output.txt", "w");
   fscanf(ip, "%d\n", &T);
 
   for(i = 0; i < T; i++) {
      memset(val, 50, 0);
      fgets(line, 80, ip);
      ptr = strchr(line, ' ');
      strncpy(val, line, ptr-line);
      val[ptr-line] = 0;
      C = atof(val);
      //printf("%f\n", C);
      ptr++;
      ptr1 = ptr;
      ptr = strchr(ptr1, ' ');
      strncpy(val, ptr1, ptr-ptr1);
      val[ptr-ptr1] = 0;
      F = atof(val);
      //printf("%f\n", F);
      ptr++;
      X = atof(ptr);
      //printf("%f\n", X);
      res = find_opt_time(C, F, X);
      sprintf(ops, "Case #%d: %.7f\n", i+1, res);
      fputs(ops, op);
   }
 
   fclose(ip);
   fclose(op);
   return 0;
 }

