#include<stdio.h>
 int main()
 {
 int t,x11=1;
 scanf("%d",&t);
 while(x11<=t)
 {
 	double c,f,x,z,s=0.0,x1=0.0,x2=0.0,x3=0.0,x4=0.0;
 	z=2.0;
 	scanf("%lf%lf%lf",&c,&f,&x);
 	//if(z==x)
 //	printf("Case #%d: 1.0000000\n",x11);
 //	else
 //	if(z>x)
 //	printf("Case #%d: 0.0000000\n",x11);
 //	else
 	{
 	int flag=1;
 	while(flag)
 	{
 		x1=x/z;
 		x2=c/z;
 		x3=(x)/(z+f);
 		x4=x2+x3;
 		if(x4<x1)
 		{
 			s+=x2;
 			flag=1;
 			z=z+f;
 		}
 		else
 		{
 			s+=x1;
 			flag=0;
 		}
 	}
 	printf("Case #%d: %.7lf\n",x11,s);
 	}
 x11++;
 }
 return 0;
 }

