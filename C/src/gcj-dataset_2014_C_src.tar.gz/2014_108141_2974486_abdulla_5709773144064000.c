#include<stdio.h>
 int main()
 {
 
 double c,f,x,v,nval,pval,t;
 v=2.0;
 int p,testcase;
 
 FILE *fin, *fout;
 fin=fopen("B-large.in","r");
 fout=fopen("B-large.txt","w");
 
 fscanf(fin,"%d",&testcase);
 
 for(p=0;p<testcase;p++)
 {
 v=2;
 fscanf(fin,"%lf",&c);
 fscanf(fin,"%lf",&f);
 fscanf(fin,"%lf",&x);
 
 
 nval=0;
 pval=x/v;
 t=0;
 nval=c/v + x/(v+f);
 
 while(nval<pval)
 {
 
 v=v+f;
 
 pval=nval;
 
 t=nval-x/v;
 
 nval=t+x/(v+f)+c/v;
 
 
 }
 
 fprintf(fout,"case #%d: %lf\n",p+1,pval);
 
 
 
 }
 
 fclose(fin);
 fclose(fout);
 
 
 return 0;
 
 }
 

