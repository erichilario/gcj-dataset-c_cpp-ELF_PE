#include<stdio.h>
 
 int main()
 {
 	int t,T,R,C,M,i,j,k,l,R1,C1,M1,lr,hr,lc,hc,r,c,p,q;
 	char A[50][50];
 
 	scanf("%d",&T);
 	for(t=1;t<=T;t++)
 	{	scanf("%d%d%d",&R,&C,&M);
 		R1=R;C1=C;M1=M,i=0;;
 		while(M1>0)
 		{	M1=M1-(2*R+2*C-4-i*8);
 			i++;
 		}
 		M1=M1+(2*R+2*C-4-(i-1)*8);
 		
 		r=R-2*(i-1); c = C-2*(i-1);
 		printf("Case #%d:\n",t);
 		p=i;
 		if(R-2*(i-1)==1||C-2*(i-1)==1)
 		{	for(i = 0 ; i <50;i++)
 			{	for(j=0;j<50;j++)
 				{	A[i][j] = '.';
 				}
 			}
 			lr=0;hr=R;lc=0;hc=C;
 			while(M>0)
 			{	for(i=lc;i<hc&&M>0;i++)
 				{	A[lr][i]='*';
 					M--;
 				}
 				for(i=lc;i<hc&&M>0;i++)
 				{	A[hr-1][i]='*';
 					M--;
 				}
 				lr++;hr--;
 				for(j=lr;j<hr&&M>0;j++)
 				{	A[j][lc] = '*';
 					M--;
 				}
 				for(j=lr;j<hr&&M>0;j++)
 				{	A[j][hc-1] = '*';
 					M--;
 				}
 				lc++;
 				hc--;
 			}
 			if(r==1)
 			{ A[p-1][p+1]='c';	
 			}
 			if(c==1)
 			{ A[p+1][p-1]='c';	
 			}
 			for(i=0;i<R;i++)
 			{	for(j=0;j<C;j++)
 				printf("%c ",A[i][j]);
 				printf("\n");
 			}
 		}
 		else if ( r>3&&c>3)
 		{	for(i = 0 ; i <50;i++)
 			{	for(j=0;j<50;j++)
 				{	A[i][j] = '.';
 				}
 			}
 			lr=0;hr=R;lc=0;hc=C;
 			while(M>0)
 			{	for(i=lc;i<hc&&M>0;i++)
 				{	A[lr][i]='*';
 					M--;
 				}
 				for(i=lc;i<hc&&M>0;i++)
 				{	A[hr-1][i]='*';
 					M--;
 				}
 				lr++;hr--;
 				for(j=lr;j<hr&&M>0;j++)
 				{	A[j][lc] = '*';
 					M--;
 				}
 				for(j=lr;j<hr&&M>0;j++)
 				{	A[j][hc-1] = '*';
 					M--;
 				}
 				lc++;
 				hc--;
 			}
 			r=(R+1)/2; c=(C+1)/2;
 			A[r-1][c-1]='c';
 			for(i=0;i<R;i++)
 			{	for(j=0;j<C;j++)
 				printf("%c ",A[i][j]);
 				printf("\n");
 			}
 		}
 		else
 		{	printf("Impossible\n");
 		}
 
 	}
 	return 0;
 }

