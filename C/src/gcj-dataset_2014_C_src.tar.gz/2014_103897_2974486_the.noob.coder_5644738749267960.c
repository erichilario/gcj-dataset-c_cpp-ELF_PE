#include<stdio.h>
 #include<stdlib.h>
 
 void sort(long double *arr,int size);
 int war(long double *naomi,long double *ken,int block_number);
 int deceit_war(long double *naomi,long double *ken,int block_number);
 
 int main(void)
 {
 	int test_number;
 	int block_number,counter,counter2;
 	int *war_result;
 	int *deceit_war_result;
 	scanf("%d",&test_number);
 	war_result=(int *)malloc(test_number*sizeof(int));
 	deceit_war_result=(int *)malloc(test_number*sizeof(int));
 	
 	for(counter2=0;counter2<test_number;counter2++)
 	{
 		long double *naomi;
 		long double *ken;
 		scanf("%d",&block_number);
 		naomi=(long double *)malloc(block_number*sizeof(long double));
 		ken=(long double *)malloc(block_number*sizeof(long double));
 		for(counter=0;counter<block_number;counter++)
 			scanf("%Lf",&naomi[counter]);
 		for(counter=0;counter<block_number;counter++)
 			scanf("%Lf",&ken[counter]);
 	
 		sort(naomi,block_number);
 		sort(ken,block_number);
 		
 		war_result[counter2]=war(naomi,ken,block_number);
 		deceit_war_result[counter2]=deceit_war(naomi,ken,block_number);
 	}
 	
 	for(counter=0;counter<test_number;counter++)
 		printf("Case #%d: %d %d\n",counter+1,deceit_war_result[counter],war_result[counter]);
 	
 	return 0;
 }
 
 int war(long double *naomi,long double *ken,int block_number)
 {
 	int naomi_counter;
 	int ken_counter;
 	int result=0;
 	for(ken_counter=block_number-1,naomi_counter=block_number-1;naomi_counter>=0;ken_counter--)
 	{	
 		//printf("\n");
 		while(naomi[naomi_counter]>ken[ken_counter] )
 		{
 		//	printf("%Lf compared with %Lf in war\n",ken[ken_counter],naomi[naomi_counter]);
 			if (naomi_counter==0)
 				break;
 			naomi_counter--;
 		}
 		
 		if(naomi_counter==0 && naomi[naomi_counter]>ken[ken_counter])
 			break;
 		else if(ken_counter==0 && ken[ken_counter]<naomi[naomi_counter])
 		{
 		//	printf(" %Lf compared with %Lf in war\n",ken[ken_counter],naomi[naomi_counter]);
 			result++;
 		//	printf("current ken's  result is:%d in war\n",result);
 			break;
 		}
 		
 		else if(naomi[naomi_counter]<ken[ken_counter])
 		{
 		//	printf(" %Lf compared with %Lf in war\n",ken[ken_counter],naomi[naomi_counter]);
 			result++;
 		//	printf("current ken's result is:%d in war\n",result);
 			naomi_counter--;
 		}
 	}
 	//printf("ken's final result is %d in war\n",result);
 	return block_number-result;
 }
 
 int deceit_war(long double *naomi,long double *ken,int block_number)
 {
 	int naomi_counter;
 	int ken_counter;
 	int result=0;
 	for(naomi_counter=block_number-1,ken_counter=block_number-1;ken_counter>=0;naomi_counter--)
 	{
 	//	printf("\n");
 		while(ken[ken_counter]>naomi[naomi_counter] )
 		{	
 	//		printf(" %Lf compared with %Lf in deceit_war\n",naomi[naomi_counter],ken[ken_counter]);
 			if(ken_counter==0)
 				break;
 			ken_counter--;
 		}
 		
 		if(ken_counter==0 && ken[ken_counter]>naomi[naomi_counter])
 			break;
 		else if(ken_counter==0 && ken[ken_counter]<naomi[naomi_counter])
 		{
 	//		printf(" %Lf compared with %Lf in deceit_war\n",naomi[naomi_counter],ken[ken_counter]);
 			result++;
 	//		printf("current naomi's  result is:%d in deceit_war\n",result);
 			break;
 		}
 		else if(ken[ken_counter]<naomi[naomi_counter])
 		{
 	//		printf(" %Lf compared with %Lf in deceit_war\n",naomi[naomi_counter],ken[ken_counter]);
 			result++;
 	//		printf("current naomi's  result is:%d in deceit_war\n",result);
 			ken_counter--;
 		}
 	}
 	//printf("naomi's final result is %d in deceit_war\n",result);
 	return result;
 }
 
 
 void sort(long double *arr,int size)
 {
 	int counter_1,counter_2;
 	long double dummy;
 	for(counter_1=0;counter_1<size-1;counter_1++)
 	{
 		for(counter_2=0;counter_2<size-1-counter_1;counter_2++)
 		{
 			if(arr[counter_2]>arr[counter_2+1])
 			{
 				dummy=arr[counter_2];
 				arr[counter_2]=arr[counter_2+1];
 				arr[counter_2+1]=dummy;
 			}
 		}
 	}	
 }
 

