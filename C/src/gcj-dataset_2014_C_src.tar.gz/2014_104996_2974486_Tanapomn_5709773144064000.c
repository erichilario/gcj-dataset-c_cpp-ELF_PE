#include <stdio.h>
 
 int main()
 {
     FILE *in = fopen("B-large.in","r");
     FILE *out = fopen("B-large.out","w");
     int o;
     int n;
     double c,f,x;
     fscanf(in,"%d",&n);
     for(o=1;n>=o;o++)
     {
         double cps = 2,time = 0;
         fscanf(in,"%lf %lf %lf",&c,&f,&x);
         int check = 0;
         while(!check)
         {
             if(x/cps<c/cps+x/(cps+f))
             {
                 check = 1;
                 time += x/cps;
             }else
             {
                 time += c/cps;
                 cps += f;
             }
         }
         fprintf(out,"Case #%d: %.7lf\n",o,time);
     }
 }

