// CodeJam1.cpp : Defines the entry point for the console application.
 //
 
 //#include "stdafx.h"
 #include"stdio.h"
 #include"stdlib.h"
 
 
 int getNumbers(FILE *fin, int rowSelected,int *rowElements)
 {
 	int presentRow=1,i;
 	while (presentRow != rowSelected)
 	{
 		while (fgetc(fin) != '\n');
 		presentRow++;
 	}
 	for (i = 0; i < 4; i++)
 		fscanf(fin, "%d", &rowElements[i]);
 	return 0;
 }
 
 int main(int argc, char* argv[])
 {
 	FILE *fin, *fout;
 
 	int noOfCases = 0, currentCase = 1 , rowSelected = 0, presentRow = 1, rowElements_set1[4], rowElements_set2[4], result,resultNo=0;
 	int i,f,j;
 	fin=fopen("A-small-attempt0.in", "rb");
 
 	if (fin == NULL)
 		printf("null");
 	fscanf(fin, "%d", &noOfCases);
 	while (noOfCases)
 	{
 		resultNo = 0;
 		fscanf(fin, "%d", &rowSelected);
 		fgetc(fin);
 		getNumbers(fin, rowSelected, rowElements_set1);
 		f = rowSelected;
 		while (f != 5)
 		{
 			while (fgetc(fin) != '\n');
 			f++;
 		}
 		fscanf(fin, "%d", &rowSelected);
 		fgetc(fin);
 		getNumbers(fin, rowSelected, rowElements_set2);
 		f = rowSelected;
 		while (f != 5)
 		{
 			while (fgetc(fin) != '\n');
 			f++;
 		}
 		for (i = 0; i < 4; i++)
 		{
 			for (j = 0; j < 4; j++)
 			{
 				if (rowElements_set1[i] == rowElements_set2[j])
 				{
 					resultNo++;
 					result = rowElements_set1[i];
 				}
 			}
 		}
 		if (!resultNo)
 		{
 			fout=fopen("A-large-output.in", "ab");
 			fprintf(fout, "Case #%d: Volunteer cheated!\n", currentCase++);
 			fclose(fout);
 		}
 		else if (resultNo == 1)
 		{
 			fout=fopen("A-large-output.in", "ab");
 			fprintf(fout, "Case #%d: %d\n", currentCase++,result);
 			fclose(fout);
 		}
 		else
 		{
 			fout=fopen("A-large-output.in", "ab");
 			fprintf(fout, "Case #%d: Bad magician!\n", currentCase++);
 			fclose(fout);
 		}
 		noOfCases--;
 	}
 	return 0;
 }
 
 

