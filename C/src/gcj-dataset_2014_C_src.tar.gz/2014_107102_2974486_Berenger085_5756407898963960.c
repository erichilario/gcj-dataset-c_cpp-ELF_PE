#include <stdio.h>
 #include <stdlib.h>
 FILE *ouvriroutFILE(char *ch)
 {
     return fopen(ch, "w");
 }
 FILE *ouvririnFILE(char *ch)
 {
     return fopen(ch, "r");
 }
 int * lireLigne(FILE *input,int lng,int pos)
 {
     int *T = (int *)malloc(sizeof(int)*4),*T1 = (int *)malloc(sizeof(int)*4),i,j;
     for(i=1;i<=4;i++)
     {
         if(i==pos) for(j=0;j<lng;j++) fscanf(input,"%d",&T[j]);
         else for(j=0;j<lng;j++) fscanf(input,"%d",&T1[j]);
     }
     return T;
 }
 int chrch(int *T,int motif,int lg)
 {
     int j;
     for(j=0;j<lg;j++)
         if(T[j]==motif) return 1;
     return 0;
 }
 int verif(int *T1,int *T2,int lng,int *ans)
 {
     int i,result=0;
     for(i=0;i<lng;i++)
     {
         if(chrch(T2,*(T1+i),lng))
         {
             result++;
             *ans = *(T1+i);
         }
     }
     return result;
 }
 int main(int Argv,char **Argc)
 {
     FILE *input = ouvririnFILE(Argc[1]);
     FILE *output = ouvriroutFILE("output.in");
     int taille;
     fscanf(input,"%d",&taille);
     system("pause");
     int ch1,ch2,lng=4,i=1;
     while(taille!=0)
     {
         taille--;
         fscanf(input,"%d",&ch1);
         int *T1 = lireLigne(input,lng,ch1);
         fscanf(input,"%d",&ch2);
         int *T2 = lireLigne(input,lng,ch2);
         int p,result = verif(T1,T2,lng,&p);
         if(!result) fprintf(output,"Case #%d: Volunteer cheated!\n",i);
         else if(result==1) fprintf(output,"Case #%d: %d\n",i,p);
         else fprintf(output,"Case #%d: Bad magician!\n",i);
         i++;
     }
     return 0;
 }

