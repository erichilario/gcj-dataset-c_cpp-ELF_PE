#include <stdio.h>
 
 int main()
 {
     int T,i;
     double C,F,X;
     double time,rate;
     freopen("B-small-attempt0.in", "r", stdin);
     freopen("B-small-attempt0.out", "w+", stdout);
     scanf("%d",&T);
     for(i=0;i<T;i++){
         C=0.0;F=0.0;X=0.0;time=0.0;rate=2.0;
         scanf("%lf",&C);
         scanf("%lf",&F);
         scanf("%lf",&X);
 
         while((X-C)/rate > X/(rate+F)){
             time += C/rate;
             rate += F;
         }
 
         time += X/rate;
 
         printf("Case #%d: %lf\n",i+1,time);
     }
     return 0;
 }

