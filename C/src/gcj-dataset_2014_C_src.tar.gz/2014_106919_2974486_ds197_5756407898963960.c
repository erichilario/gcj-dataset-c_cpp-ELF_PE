#include <stdio.h>
 #include <stdlib.h>
 int n,v1[4],v2[4];
 int trova_comune()
 {
     int comuni=0,i,j;
     for(i=0;i<4;i++)
      for(j=0;j<4;j++)
       if(v1[i]==v2[j])
       {
           comuni++;
           n=v1[i];
       }
     return comuni;
 }
 int main()
 {
     FILE *in,*out;
     in=fopen("input.in","r");
     out=fopen("output.txt","w");
     int ciclo=1,casi;
     fscanf(in,"%d",&casi);
     int riga,i,j,temp,comune;
     while(ciclo<=casi)
     {
         fscanf(in,"%d",&riga);
         riga--;
         for(i=0;i<4;i++)
          for(j=0;j<4;j++)
          {
              if(riga==i)
               fscanf(in,"%d",&v1[j]);
              else
               fscanf(in,"%d",&temp);
          }
         fscanf(in,"%d",&riga);
         riga--;
         for(i=0;i<4;i++)
          for(j=0;j<4;j++)
           {
               if(riga==i)
                fscanf(in,"%d",&v2[j]);
               else
                fscanf(in,"%d",&temp);
           }
         comune=trova_comune();
         fprintf(out,"Case #%d: ",ciclo);
         if(comune==0)
          fprintf(out,"Volunteer cheated!\n");
         else if(comune>1)
          fprintf(out,"Bad magician!\n");
         else
          fprintf(out,"%d\n",n);
         ciclo++;
     }
     fclose(in);
     fclose(out);
     return 0;
 }

