#include <stdio.h>
 #include <stdlib.h>
 #define MAXN 1000+10
 
 int comp(const void *, const void *);
 
 int main()
 {
     int round;
     scanf("%d", &round);
     
     int count = 1;
     int n;
     int i, j;
     double naomi[MAXN];
     double ken[MAXN];
     char c;
 
     while (count <= round)
     {
         i = 0;
         scanf("%d", &n);
         getchar();
 
         for (i=0; i < n; i++)
         {
             scanf("%lf", &naomi[i]);
         }
 
         for (i=0; i < n; i++)
         {
             scanf("%lf", &ken[i]);
         }
         
         qsort(naomi, n, sizeof(double), comp);
         qsort(ken, n, sizeof(double), comp);
          
         /*for (j=0; j<n; j++)
         {
             printf("%lf ", naomi[j]);
         }
         printf("\n");
         for (j=0; j<n; j++)
         {
             printf("%lf ", ken[j]);
         }*/
 
         int iterator = 0;
         int ken_iterator = 0;
         int ken_start = 0;
         int ken_end = n-1;
         int win_deceit = 0;
         int win_war = 0;
         double item;
 
         while(iterator < n)
         {
             //printf("naomi iteratr: %d\n", iterator);
             //printf("ken start: %d\n", ken_start);
             //printf("ken end: %d\n", ken_end);
             if (naomi[iterator] > ken[ken_start])
             {
                 //printf("deceit++\n");
                 win_deceit++;
                 ken_start++;
             }
             else if (naomi[iterator] < ken[ken_start])
             {
                 ken_end--;
             }
             iterator++;
         }
         ken_start = 0;
         ken_end = n-1;
         win_war = 0;
         iterator = 0;
 
 
         while (iterator < n)
         {
             item = naomi[iterator];
             for (ken_iterator = 0; ken_iterator < n; ken_iterator++)
             {
                 if (ken[ken_iterator] > item)
                 {
                     ken[ken_iterator] = 0.0;
                     break;
                 }
                 else
                 {
                     continue;
                 }
             }
             if (ken_iterator == n)
             {
                 win_war++;
             }
             iterator++;
         }
 
         printf("Case #%d: %d %d\n", count, win_deceit, win_war);
         count++;
     }
 
     return 0;
 }
 
 int comp( const void * p, const void * q) 
 { 
     double xx = *(double*)p, yy = *(double*)q;
     if (xx < yy) return -1;
     if (xx > yy) return  1;
     return 0;
 }

