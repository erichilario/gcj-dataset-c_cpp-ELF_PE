#include<stdio.h>
 int main()
{
  int i,n,t;
  scanf("%d",&n)
  for(i=0;i<n;i++)
  {
  } 
 }
