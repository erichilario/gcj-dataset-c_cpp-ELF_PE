import random
v = int(input())

for i in range(n):
    a,b = int(input()),int(input())
for j in range(a*b):
    r=random.randint(1,5)
    r1=random.randint(1,5)
    for k in range(a*b):
        c=random.randint(1,5)
        c1=random.randint(1,
