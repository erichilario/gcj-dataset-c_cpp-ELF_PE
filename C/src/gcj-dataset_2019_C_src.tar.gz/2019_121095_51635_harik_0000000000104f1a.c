#include<stdio.h>
int main()
{
 int i,m,n,t;
 scanf("%d %d %d",&m,&n,&t);
 for(i=0;i<t;i++)
 {
 }
} 
