#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    while(a--){
    int x,y;
    scanf("%d %d",&x,&y);
    if(x==y)
    {
        printf("IMPOSSIBLE");
    }
    else 
    printf("POSSIBLE");
    }
}
