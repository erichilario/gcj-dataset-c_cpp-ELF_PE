#incude <stdio.h>
#include <stdlib.h>
void main ()
{
    int i,n,m,t,g;
    scanf("%d %d",&n,&m);
    wind[18];
    for(i=2;i<=18;i++)
    {
    scanf("%d",&wind[i]);    
    }
}
