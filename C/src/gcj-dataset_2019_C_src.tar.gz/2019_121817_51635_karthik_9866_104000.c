#include<stdio.h>
int main(){
int t,r,c;
scanf("%d\n",&t);
scanf("%d %d",&r,&c);
if(r<c){
printf("POSSIBLE");}
else
printf("IMPOSSIBLE");
}
