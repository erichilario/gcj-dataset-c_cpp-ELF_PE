#include<stdio.h>

void  main()
{
int n;
int i;
scanf("%d",&n);
int a[n][n];
for(i=1;i<=n;i++)
{
for(j=1;j<=n;j++)
scanf("%d",&a[i][j]);
}


