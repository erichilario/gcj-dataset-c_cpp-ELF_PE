#include<stdio.h>
int main()
{
    int r;
    scanf("%d",&m,&n);
    while(r--){
        int p,q;
        scanf("%d %d",&p,&q);
        if(p==q)
        {
            printf("IMPOSSIBLE")
        }
        else
        printf("POSSIBLE")
    }
}
