#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&m,&n);
    while(t--){
        int m,n;
        scanf("%d %d",&m,&n);
        if(m==n)
        {
            printf("IMPOSSIBLE")
        }
        else
        printf("POSSIBLE")
    }
}
