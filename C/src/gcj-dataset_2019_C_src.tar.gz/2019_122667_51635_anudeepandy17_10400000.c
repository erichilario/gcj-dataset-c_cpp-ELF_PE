#include<stdio.h>
int main()
{
    int n,i,j,n1,str[1000];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&n1);
        for(j=0;j<n1;j++)
        {
            scanf("%s",str);
        }
    }
    
}

