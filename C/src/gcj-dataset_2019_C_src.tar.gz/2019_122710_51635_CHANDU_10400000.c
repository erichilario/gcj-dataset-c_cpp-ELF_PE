#include<stdio.h>
int main(
{
int N,T,i;
printf("enter the number of test cases you want");
scanf("%d",&N);
printf("enter the each test case");
printf("enter the number of  strings");
for(i=0;i<N;i++)
}
