 #include<stdio.h>
 int main()
{
 int r,c,t;
 scanf("%d",&t);
 while(t--)
 {
 scanf("%d %d",&r,&c);
 {if(r==c)
 print("IMPOSSIBLE");
 else
 print("POSSIBLE");
 }}
} 
 
