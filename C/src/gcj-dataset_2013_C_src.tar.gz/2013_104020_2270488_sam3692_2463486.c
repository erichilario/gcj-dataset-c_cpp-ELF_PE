# include<stdio.h>
 # include<conio.h>
 # include<string.h>
 # include<math.h>
 
 void main()
 {
 int b,t,i,j,k;
 char a;
 unsigned long int  n,m;
 FILE * fin = fopen("G:/WORK/SAMARTH JIIT/Placement Study/google/input.in", "r");
 FILE * out = fopen("G:/WORK/SAMARTH JIIT/Placement Study/google/out.txt", "w");
 fscanf(fin, "%d\n", &t);
 for(i=0;i<t;i++)
 {
 b=0;
 fscanf(fin, "%lu %lu\n", &n,&m);
 for(j=n;j<=m;j++)
 {
 if(abcd(j)==1)
 b++;
 }
 //printf("Case #%d: %d\n",i+1,b);
 fprintf(out, "Case #%d: %d\n",i+1,b);
 
 }
 fclose(fin);
 fclose(out);
 getch();
 }
 
 int abcd(int number)
     {
         int temp,reverse = 0;
 		float p = sqrt(number);
 			int m=p;
 			temp=number;
  		while( temp != 0 )
 			{
 			reverse = reverse * 10;
 			reverse = reverse + temp%10;
 			temp = temp/10;
 			}
 
 		if(m==p && reverse==number)
 		{
 			reverse = 0;
 			temp=m;
 			while( temp != 0 )
 			{
 			reverse = reverse * 10;
 			reverse = reverse + temp%10;
 			temp = temp/10;
 			}
 			if(reverse==m)
 			return 1;
 		}
 		else
 		return 0;
     }

