#include<stdio.h>
 
 void main()
 {
     int t, A, B, i, count, j;
     int arr[5] = {1,4,9,121,484};
     FILE *fin, *fout;
     fin = fopen("in.in","r");
     fout = fopen("out.txt","w");
     fscanf(fin,"%d",&t);
 
     for(j=1;j<=t;j++)
     {
         count=0;
         fscanf(fin,"%d%d",&A,&B);
         for(i=0;i<5;i++)
         {
             if(arr[i]>=A&&arr[i]<=B)
             {
                 count++;
             }
         }
         fprintf(fout,"Case #%d: %d\n",j,count);
     }
     fclose(fin);
     fclose(fout);
 }

