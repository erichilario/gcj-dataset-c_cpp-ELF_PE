#include<stdio.h>
 
 int main()
 {
 int i,j,k,cx,co,cdot,ct,t,flag,p;
 char array[6][6];
 
 scanf("%d\n",&t);
 p=0;
 while(t--)
 {
  p++;
  cx=0,co=0,cdot=0,ct=0,flag=0;
   for(i=1;i<=4;i++)
    {
      for(j=1;j<=4;j++)
       {
 
           scanf("%c",&array[i][j]);
       }
      scanf("\n");
    }
 scanf("\n");
  for(i=1;i<=4;i++)
   {
     cx=0,co=0,cdot=0,ct=0;
      for(j=1;j<=4;j++)
      {
        if(array[i][j]=='X')
          cx++;
        if(array[i][j]=='O')
         co++;
        if(array[i][j]=='T')
         ct++;
        if(array[i][j]=='.'){
         cdot++;
         flag=1;}
          
      }
      
     if(cdot>0)
      {
         continue;
      }
      else
       {
 
     if(cx==4 || (cx==3 && ct==1))
      {
         printf("Case #%d: X won\n",p);
         goto q;
      }
     if(co==4 || (co==3 && ct==1))
      {
         printf("Case #%d: O won\n",p);
         goto q;
      }
 
        }
       
     
 
  
   }
 
 
 for(i=1;i<=4;i++)
   {
     cx=0,co=0,cdot=0,ct=0;
      for(j=1;j<=4;j++)
      {
        if(array[j][i]=='X')
          cx++;
        if(array[j][i]=='O')
         co++;
        if(array[j][i]=='T')
         ct++;
        if(array[j][i]=='.'){
         cdot++;
         flag=1;}
          
      }
      
     if(cdot>0)
      {
         continue;
      }
      else
       {
 
     if(cx==4 || (cx==3 && ct==1))
      {
         printf("Case #%d: X won\n",p);
         goto q;
      }
     if(co==4 || (co==3 && ct==1))
      {
         printf("Case #%d: O won\n",p);
         goto q;
      }
 
        }
       
     
 
  
   }
 cx=0,co=0,cdot=0,ct=0;
 
 for(i=1;i<=4;i++)
  {
    if(array[i][i]=='X')
          cx++;
        if(array[i][i]=='O')
         co++;
        if(array[i][i]=='T')
         ct++;
        if(array[i][i]=='.'){
         cdot++;
         flag=1;}
  }
 
 if(cdot==0)
  {
    if(cx==4 || (cx==3 && ct==1))
      {
         printf("Case #%d: X won\n",p);
         goto q;
      }
     if(co==4 || (co==3 && ct==1))
      {
         printf("Case #%d: O won\n",p);
         goto q;
      }
 
  }
 
 j=4;
 cx=0,co=0,cdot=0,ct=0;
 for(i=1;i<=4;i++)
  {
    if(array[i][j]=='X')
          cx++;
        if(array[i][j]=='O')
         co++;
        if(array[i][j]=='T')
         ct++;
        if(array[i][j]=='.'){
         cdot++;
         flag=1;}
   j--;
  }
 
 if(cdot==0)
  {
    if(cx==4 || (cx==3 && ct==1))
      {
         printf("Case #%d: X won\n",p);
         goto q;
      }
     if(co==4 || (co==3 && ct==1))
      {
         printf("Case #%d: O won\n",p);
         goto q;
      }
 
  }
 if(flag==1)
  {
    printf("Case #%d: Game has not completed\n",p);
  }
 else
  {
    printf("Case #%d: Draw\n",p);  
  }
 
 
 
   
 q:
 continue;
 }
 
 
 
 
 
 return 0;
 }
