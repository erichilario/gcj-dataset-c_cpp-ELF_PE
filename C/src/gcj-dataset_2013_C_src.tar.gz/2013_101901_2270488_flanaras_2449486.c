#include <stdio.h>
 #include <stdlib.h>
 
 #define LEN 5
 
 int getCases(FILE**);
 int getUntil(FILE**,char);
 
 int main()
 {
 	FILE* fp,* FtS;
 	char cases,row,col,current,i,j,yes;
 	char* temp,* maxcol,* maxrow;
 	fp = fopen("B-small-attempt1.in","r");
 	if (fp != NULL)
 	{
 		FtS = fopen("Lawnmower Results.txt","w");
 		cases = getUntil(&fp,'\n');
 		for(current=0 ; current<cases ; current++)
 		{
 			yes = 1;
 			row = getUntil(&fp,' ');
 			col = getUntil(&fp,'\n');
 			temp = (char*)malloc(row*col*sizeof(char));
 			for(i=0 ; i<row ; i++)			//read
 			{
 				for(j=0 ; j<col ; j++)
 				{
 					temp[i*col + j] = fgetc(fp);
 					//printf("%c ",temp[i*col + j]);
 					fgetc(fp);
 				}
 				//printf("\n");
 			}
 			if (row == 1 || col == 1)		//check
 				yes = 1;
 			else
 			{
 				maxcol = (char*)calloc(col,sizeof(char));
 				maxrow = (char*)calloc(row,sizeof(char));
 				for(i=0 ; i<row ; i++)
 				{
 					for(j=0 ; j<col ; j++)
 					{
 						if (temp[i*col + j] > maxrow[i])	//max stis grammes
 							maxrow[i] = temp[i*col + j];
 						if (temp[i*col + j] > maxcol[j])
 							maxcol[j] = temp[i*col + j];
 					}
 				}
 				for(i=0 ; i<row ; i++)
 					for(j=0 ; j<col ; j++)
 						if (temp[i*col+j] < maxrow[i] && temp[i*col+j] < maxcol[j])
 						{
 							//printf(" NO reason:[%d][%d]\n",i,j);
 							yes = 0;
 							i = row *2;
 							break;
 						}
 				free(maxcol);
 				free(maxrow);
 			}
 			if (yes == 1 )
 			{
 				//printf("Case #%d: YES\n",current+1);
 				fprintf(FtS,"Case #%d: YES\n",current+1);
 			}
 			else
 			{
 				//printf("Case #%d: NO\n",current+1);
 				fprintf(FtS,"Case #%d: NO\n",current+1);
 			}
 			//system("pause");
 			free(temp);
 
 		}
 		fclose(FtS);
 		fclose(fp);
 	}
 	system("pause");
 }
 
 int getCases(FILE** fp)
 {
 	char ch,string[LEN];
 	char i;
 	for(i=0 ; i<LEN ; i++)
 		string[i] = 0;
 	ch = getc(*fp);
 	for(i=0 ; (ch != 'n') && (ch != EOF) ; i++)
 	{
 		string[i] = ch;
 		ch = getc(*fp);
 	}
 	return atoi(string);
 }
 
 int getUntil(FILE** fp,char until)
 {
 	char ch,string[LEN];
 	char i;
 	for(i=0 ; i<LEN ; i++)
 		string[i] = 0;
 	ch = getc(*fp);
 	printf("%c",ch);
 	for(i=0 ; (ch != until) && (ch != EOF) ; i++)
 	{
 		string[i] = ch;
 		ch = getc(*fp);
 		printf("%c",ch);
 	}
 	printf("\n");
 	return atoi(string);
 }
