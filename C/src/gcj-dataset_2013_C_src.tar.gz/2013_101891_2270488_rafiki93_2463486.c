//Fair and quare
 #include<stdio.h>
 #include<math.h>
 int main()
 {
 
     int n,a,b,count,times,k=0;
     FILE *fp,*fp1;
     fp=fopen("C-small-attempt0.in","r");
     fp1=fopen("C-small-attempt0.out","w");
     fscanf(fp,"%d",&times);
     while(times--)
     {
         count=0;
     fscanf(fp,"%d  %d",&a,&b);
     for(n=a;n<=b;n++)
     {
         if(checkifpalindrome(n))
         {
             if(checkifsquare(n))
             count++;
             //fair square number
         }
     }
     k++;
     fprintf(fp1,"Case #%d: %d\n",k,count);
 
     }
     fclose(fp);
     fclose(fp1);
     return 0;
 }
 
 int checkifpalindrome(int n)
 {
     int i,end,d=0,flag=0;
     int a[4];
     while(n>0)
     {
 
         a[d]=n%10;
         d++;
         n=n/10;
     }
     d--;
     if(d==0) return 1;
     end=(d-1)/2;
     //d no. of digits
     //array a stores those digits
 
         for(i=0;i<=end;i++)
     {
         if(a[i]!=a[d-i])
         return 0;
     }
 return 1;
 }
 
 
  int checkifsquare(int n)
   {
       float t1,t2;
       int num;
       t1=sqrt(n);
       t2=t1-floor(t1);
       if(t2==0||t2<0.00001)
       {
           num=(int)(t1);
         if(checkifpalindrome(num)) return 1;
 
       }
       return 0;
  }

