/*
  * =====================================================================================
  *
  *       Filename:  problemC.c
  *
  *    Description:  
  *
  *        Version:  1.0
  *        Created:  2013年04月13日 11时22分04秒
  *       Revision:  none
  *       Compiler:  gcc
  *
  *         Author:  梁涛 (suck_it), liangtao90s@gmail.com
  *   Organization:  
  *
  * =====================================================================================
  */
 #include <stdio.h>
 #include <math.h>
 static int is_pal(int n)
 {
 		char a[6];
 		int i = 0, j;
 		while (n > 0) {
 				a[i] = n % 10;
 				n /= 10;
 				i++;
 		}
 		for (j = 0; j <= (i-1) / 2; j++)
 				if (a[j] != a[i - j - 1])
 						return 0;
 		return 1;
 }
 
 int main()
 {
 		int T, A, B;
 		int i;
 		scanf("%d", &T);
 		for (i = 1; i <= T; i++) {
 				float root;
 				int count = 0;
 				scanf("%d%d", &A, &B);
 				root = sqrt(A);
 				A = (int)root;
 				if (root > A)
 						A++;
 				B = sqrt(B);
 				while (A <= B) {
 						if (is_pal(A) && is_pal(A*A))
 								count++;
 						A++;
 				}
 				printf("Case #%d: %d\n", i, count);
 		}
 		return 0;
 }
 

