#include <stdio.h>
 #include <string.h>
 #define MAX_SIZE 4
 
 int check (char board[][MAX_SIZE]) {
 	int result = 3;
 	int x_diag_l = 0, x_diag_r = 0;
 	int o_diag_l = 0, o_diag_r = 0;
 
 	int i, j;
 	for (i = 0, j = MAX_SIZE-1; i < MAX_SIZE; ++i, --j) {
 		if ('X' == board[i][i] || 'T' == board[i][i])
 			++x_diag_l;
 		if ('O' == board[i][i] || 'T' == board[i][i])
 			++o_diag_l;
 		
 		if ('X' == board[i][j] || 'T' == board[i][j])
 			++x_diag_r;
 		if ('O' == board[i][j] || 'T' == board[i][j])
 			++o_diag_r;
 	}
 
 	if (MAX_SIZE == x_diag_l || MAX_SIZE == x_diag_r)
 		return 1;
 	else if (MAX_SIZE == o_diag_l || MAX_SIZE == o_diag_r)
 		return 2;
 
 
 	for (i = 0; i < MAX_SIZE; ++i) {
 		int x_row = 0, x_col = 0; 
 		int o_row = 0, o_col = 0;
 		for (j = 0; j < MAX_SIZE; ++j) {
 			if ('.' == board[i][j] && 3 == result)
 				result = 0;
 
 			if ('X' == board[i][j] || 'T' == board[i][j])
 				++x_row;
 			if ('O' == board[i][j] || 'T' == board[i][j])
 				++o_row;
 
 			if ('X' == board[j][i] || 'T' == board[j][i])
 				++x_col;
 			if ('O' == board[j][i] || 'T' == board[j][i])
 				++o_col;
 		}
 
 		if (MAX_SIZE == x_row || MAX_SIZE == x_col) {
 			result = 1;
 			break;
 		} else if (MAX_SIZE == o_row || MAX_SIZE == o_col) {
 			result = 2;
 			break;
 		}
 	}
 
 	return result;
 }
 
 int main () {
 	char game_board[MAX_SIZE][MAX_SIZE];
 	int test_case;
 
 	while (EOF != scanf ("%d\n", &test_case)) {
 
 		int idx_test;
 		for (idx_test = 1; idx_test <= test_case; ++idx_test) {
 			int i, j;
 			for (i = 0; i < MAX_SIZE; ++i) {
 				for (j = 0; j < MAX_SIZE; ++j) {
 					scanf ("%c", &game_board[i][j]);
 				}
 				scanf ("%*c");
 			}
 			scanf ("%*c");
 			
 
 			int result = check (game_board);
 			printf ("Case #%d: ", idx_test);
 			switch (result) {
 				case 0:
 					puts ("Game has not completed");
 					break;
 				case 1:
 					puts ("X won");
 					break;
 				case 2:
 					puts ("O won");
 					break;
 				case 3:
 					puts ("Draw");
 					break;
 			}
 		}
 	}
 
 	return 0;
 }

