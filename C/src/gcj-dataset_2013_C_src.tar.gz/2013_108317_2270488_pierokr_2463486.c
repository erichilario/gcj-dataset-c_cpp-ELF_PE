#include <stdio.h>
 #include <math.h>
 int palin(int);
 int main() {
 	int k,i,count,k1,k2,num,c,A,B,T;
 	FILE *fp;
 	fp=fopen("C-small-attempt0.in","r");
 	fscanf(fp,"%d",&T);
 	for(i=1;i<=T;i++) {
 	count=0;
 	fscanf(fp,"%d %d",&A,&B);
 	c= sqrt(A);
 	if(c*c>=A)
 		num=c;
 	else
 		num=c+1;
 
 while(num*num<=B) {
 	k1=palin(num);
 	k2=palin(num*num);
 	if(k1==1 && k2==1)
 		count++;
 	num++;
 }
 printf("Case #%d: %d\n",i,count);
 }
 fclose(fp);
 return 0;
 }
 
 int palin(int x) {
 	int temp=0,reverse=0;
 	temp=x;
  	while(temp != 0)
     {
       reverse = reverse * 10;
       reverse = reverse + temp%10;
       temp=temp/10;
     }
    
  	if (x==reverse)
       return 1;
     else
       return 0;
 }
