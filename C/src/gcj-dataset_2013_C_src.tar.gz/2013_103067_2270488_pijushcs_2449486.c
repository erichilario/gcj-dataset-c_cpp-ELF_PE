#include<stdio.h>
 
 int lwn[104][104],m,n;
 
 int chk(int i1,int j1){
      int flg=1,i;
      for(i=0;i<n;i++){
        if(lwn[i1][i]!=lwn[i1][j1]){
          flg=0;
          break;
        }
      }
      
      if(flg)
        return 1;
      flg=1;
      
      for(i=0;i<m;i++){
        if(lwn[i][j1]!=lwn[i1][j1]){
          flg=0;
          break;
        }
      }
      
      if(flg)
        return 1;
      else return 0;
 }
        
     
 int main(){
     int i,j,k,t,i1,j1,min,flg=0;
     
     freopen("p3_2.in","r",stdin);
     freopen("pout.txt","w",stdout);
     scanf("%d",&t);
     
     for(k=0;k<t;k++){
       scanf("%d %d",&m,&n);
       for(i=0;i<m;i++)
          for(j=0;j<n;j++)
            scanf("%d",&lwn[i][j]);
       flg=0;
       for(i=0;i<m;i++){
         min=101;
         for(j=0;j<n;j++){
           if(lwn[i][j]<min){
             min=lwn[i][j];
           }
         }
         for(j=0;j<n;j++){
           if(min==lwn[i][j]){
             if(!chk(i,j)){
               flg=1;
               // printf("%d %d\n",i,i1);
               break;
             }
           }
         }
         if(flg)
           break;
       }
       
       
       if(!flg){
        for(j=0;j<n;j++){
          min=101;
          for(i=0;i<m;i++){
           if(lwn[i][j]<min){
             min=lwn[i][j];
           }
          }
          for(i=0;i<m;i++){
           if(min==lwn[i][j]){
             if(!chk(i,j)){
               flg=1;
               // printf("%d %d\n",i,i1);
               break;
             }
           }
         }
         if(flg)
           break;
        }
       }
       
       if(!flg)
         printf("Case #%d: YES\n",k+1);
       else printf("Case #%d: NO\n",k+1);
     }
     getch();
 }      
         
           
     
     

