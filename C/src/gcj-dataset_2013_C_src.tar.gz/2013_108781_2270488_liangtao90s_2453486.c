/*
  * =====================================================================================
  *
  *       Filename:  problemA.c
  *
  *    Description:  google code jam problem A. Tic-Tac-Toe-Tomek
  *
  *        Version:  1.0
  *        Created:  2013年04月13日 08时09分42秒
  *       Revision:  none
  *       Compiler:  gcc
  *
  *         Author:  梁涛 (suck_it), liangtao90s@gmail.com
  *   Organization:  
  *
  * =====================================================================================
  */
 #include <stdio.h>
 #include <string.h>
 
 struct _record{
 		char p;
 		char count;
 };
 
 static struct _record record[10];
 
 static char write_record_idx(char p, int idx)
 {
 		char res = 0;
 		if (record[idx].count == 0) {
 				record[idx].p = p;
 				record[idx].count = 1;
 		} else {
 				if (p == 'T') {
 						++record[idx].count;
 				} else {
 						if (record[idx].p == p || record[idx].p == 'T') {
 								record[idx].p = p;
 								++record[idx].count;
 						}
 				}
 				if (record[idx].count == 4)
 						res = record[idx].p;
 		}
 		return res;
 }
 static char write_record(char p, int i, int j)
 {
 		char res = 0;
 		if (res = write_record_idx(p, i-1))
 				return res;
 		if (res = write_record_idx(p, 4+j-1))
 					return res;
 		if (i == j)
 				if (res = write_record_idx(p, 8))
 						return res;
 		if (i + j == 5)
 					if (res = write_record_idx(p, 9))
 							return res;
 		return res;
 }
 
 int main()
 {
 		int T, i;
 		char buf[8], *p;
 		fgets(buf, 8, stdin);
 		sscanf(buf, "%d", &T);
 		for (i = 1; i <= T; i++) {
 				int j;
 				char ret, res = 0;
 				char hasdot = 0;
 				memset(record, 0, sizeof(record));
 				for (j = 1; j <= 4; j++) {
 						int k;
 						fgets(buf, 8, stdin);
 						for (k = 1, p = buf; k <= 4; k++, p++) {
 								if (res)
 										continue;
 								if (*p == '.') {
 										hasdot = 1;
 										continue;
 								}
 								ret = write_record(*p, j, k);
 								if (ret != 0)
 										res = ret;
 						}
 				}
 				fgets(buf, 8, stdin);
 				if (res)
 						printf("Case #%d: %c won\n", i, res);
 				else if (hasdot)
 						printf("Case #%d: Game has not completed\n", i);
 				else
 						printf("Case #%d: Draw\n", i);
 		}
 		return 0;
 }
 

