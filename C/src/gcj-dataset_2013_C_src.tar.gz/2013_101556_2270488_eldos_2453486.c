#include<stdio.h>
 #include<stdlib.h>
 
 int c,*sol;
 char game[4][5];
 
 void input()
 {
 	int i;
 	for(i=0;i<4;i++)
 	{
 			scanf("%s",game[i]);
 	}
 	return;
 }
 int cmp(char a,char b)
 {
 	if(a==b || a== 'T' || b== 'T')
 		return 1;
 	else
 		return 0;
 }
 void pro()
 {
 	int i,j;
 	for(i=0;i<4;i++)
 	{
 		if(cmp(game[i][0],game[i][1])&&cmp(game[i][2],game[i][3])&&cmp(game[i][0],game[i][2])&&cmp(game[i][1],game[i][3]))
 		{
 			if(game[i][0]=='X' || game[i][1]=='X')
 				*(sol+c)=1;
 			else if(game[i][0]=='O' || game[i][1]=='O')
 				*(sol+c)=-1;
 			break;
 		}
 		else if(cmp(game[0][i],game[1][i])&&cmp(game[2][i],game[3][i])&&cmp(game[0][i],game[2][i])&&cmp(game[1][i],game[3][i]))
 		{
 			if(game[0][i]=='X' || game[1][i]=='X')
 				*(sol+c)=1;
 			else if(game[0][i]=='O' || game[1][i]=='O')
 				*(sol+c)=-1;
 			break;
 		}
 	}
 	if(cmp(game[0][0],game[1][1])&&cmp(game[2][2],game[3][3])&&cmp(game[0][0],game[2][2])&&cmp(game[1][1],game[3][3]))
 	{
 			if(game[0][0]=='X' || game[1][1]=='X')
 				*(sol+c)=1;
 			else if(game[0][0]=='O' || game[1][1]=='O')
 				*(sol+c)=-1;
 	}
 	else if(cmp(game[0][3],game[1][2])&&cmp(game[2][1],game[3][0])&&cmp(game[0][3],game[2][1])&&cmp(game[1][2],game[3][0]))
 	{
 			if(game[0][3]=='X')
 				*(sol+c)=1;
 			else if(game[0][3]=='O')
 				*(sol+c)=-1;
 	}
 	if(*(sol+c)==0)
 	{
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				if(game[i][j]=='.')
 					*(sol+c)=10;
 			}
 		}
 	}
 } 
 
 int main ()
 {
 	int n,i;
 	scanf("%d\n",&n);
 	sol=(int*)malloc(n*sizeof(int));
 	for(c=0;c<n;c++)
 	{
 		*(sol+c)=0;
 		input();
 		//scanf("\n");
 		pro();
 	}
 	for(i=0;i<n;i++)
 	{
 		if(*(sol+i)==1)
 			printf("Case #%d: X won\n",i+1);
 		else if(*(sol+i)==0)
 			printf("Case #%d: Draw\n",i+1);
 		else if(*(sol+i)==-1)
 			printf("Case #%d: O won\n",i+1);
 		else if(*(sol+i)==10)
 			printf("Case #%d: Game has not completed\n",i+1);
 	}
 	return 0;
 }
 		

