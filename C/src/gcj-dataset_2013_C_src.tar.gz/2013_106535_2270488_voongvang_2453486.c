#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     int test, i, flag;
     char line1[10], line2[10], line3[10], line4[10],temp[1000];
     FILE *ifp, *ofp;
     ifp=fopen("problem_a.txt", "r");
     ofp=fopen("problem_a_output.txt", "w");
     scanf("%d",&test);
     gets(temp);
     //fscanf(ifp,"%d",&test);
     //scanf("%s", temp);
     for(i = 1; i <= test; i++) {
 
         gets(line1);
         gets(line2);
         gets(line3);
         gets(line4);
         gets(temp);
         /*
         gets(line1);
         gets(line2);
         gets(line3);
         gets(line4);
         gets(temp);
         */
         flag = 0;
 
         if((line1[0] ==  'X' || line1[0] == 'T') && (line1[1] ==  'X' || line1[1] == 'T') && (line1[2] == 'X' || line1[2] == 'T') && (line1[3] == 'X' || line1[3] == 'T'))
             flag = 1;
         else if((line1[0] ==  'O' || line1[0] == 'T') && (line1[1] ==  'O' || line1[1] == 'T') && (line1[2] == 'O' || line1[2] == 'T') && (line1[3] == 'O' || line1[3] == 'T'))
             flag = 2;
         else if((line2[0] ==  'X' || line2[0] == 'T') && (line2[1] ==  'X' || line2[1] == 'T') && (line2[2] == 'X' || line2[2] == 'T') && (line2[3] == 'X' || line2[3] == 'T'))
             flag = 1;
         else if((line2[0] ==  'O' || line2[0] == 'T') && (line2[1] ==  'O' || line2[1] == 'T') && (line2[2] == 'O' || line2[2] == 'T') && (line2[3] == 'O' || line2[3] == 'T'))
             flag = 2;
         else if((line3[0] ==  'X' || line3[0] == 'T') && (line3[1] ==  'X' || line3[1] == 'T') && (line3[2] == 'X' || line3[2] == 'T') && (line3[3] == 'X' || line3[3] == 'T'))
             flag = 1;
         else if((line3[0] ==  'O' || line3[0] == 'T') && (line3[1] ==  'O' || line3[1] == 'T') && (line3[2] == 'O' || line3[2] == 'T') && (line3[3] == 'O' || line3[3] == 'T'))
             flag = 2;
         else if((line4[0] ==  'X' || line4[0] == 'T') && (line4[1] ==  'X' || line4[1] == 'T') && (line4[2] == 'X' || line4[2] == 'T') && (line4[3] == 'X' || line4[3] == 'T'))
             flag = 1;
         else if((line4[0] ==  'O' || line4[0] == 'T') && (line4[1] ==  'O' || line4[1] == 'T') && (line4[2] == 'O' || line4[2] == 'T') && (line4[3] == 'O' || line4[3] == 'T'))
             flag = 2;
         else if((line1[0] ==  'X' || line1[0] == 'T') && (line2[1] ==  'X' || line2[1] == 'T') && (line3[2] == 'X' || line3[2] == 'T') && (line4[3] == 'X' || line4[3] == 'T'))
             flag = 1;
         else if((line1[0] ==  'O' || line1[0] == 'T') && (line2[1] ==  'O' || line2[1] == 'T') && (line3[2] == 'O' || line3[2] == 'T') && (line4[3] == 'O' || line4[3] == 'T'))
             flag = 2;
         else if((line4[0] ==  'X' || line4[0] == 'T') && (line3[1] ==  'X' || line3[1] == 'T') && (line2[2] == 'X' || line2[2] == 'T') && (line1[3] == 'X' || line1[3] == 'T'))
             flag = 1;
         else if((line4[0] ==  'O' || line4[0] == 'T') && (line3[1] ==  'O' || line3[1] == 'T') && (line2[2] == 'O' || line2[2] == 'T') && (line1[3] == 'O' || line1[3] == 'T'))
             flag = 2;
         else if((line1[0] ==  'X' || line1[0] == 'T') && (line2[0] ==  'X' || line2[0] == 'T') && (line3[0] == 'X' || line3[0] == 'T') && (line4[0] == 'X' || line4[0] == 'T'))
             flag = 1;
         else if((line1[0] ==  'O' || line1[0] == 'T') && (line2[0] ==  'O' || line2[0] == 'T') && (line3[0] == 'O' || line3[0] == 'T') && (line4[0] == 'O' || line4[0] == 'T'))
             flag = 2;
         else if((line1[1] ==  'X' || line1[1] == 'T') && (line2[1] ==  'X' || line2[1] == 'T') && (line3[1] == 'X' || line3[1] == 'T') && (line4[1] == 'X' || line4[1] == 'T'))
             flag = 1;
         else if((line1[1] ==  'O' || line1[1] == 'T') && (line2[1] ==  'O' || line2[1] == 'T') && (line3[1] == 'O' || line3[1] == 'T') && (line4[1] == 'O' || line4[1] == 'T'))
             flag = 2;
         else if((line1[2] ==  'X' || line1[2] == 'T') && (line2[2] ==  'X' || line2[2] == 'T') && (line3[2] == 'X' || line3[2] == 'T') && (line4[2] == 'X' || line4[2] == 'T'))
             flag = 1;
         else if((line1[2] ==  'O' || line1[2] == 'T') && (line2[2] ==  'O' || line2[2] == 'T') && (line3[2] == 'O' || line3[2] == 'T') && (line4[2] == 'O' || line4[2] == 'T'))
             flag = 2;
         else if((line1[3] ==  'X' || line1[3] == 'T') && (line2[3] ==  'X' || line2[3] == 'T') && (line3[3] == 'X' || line3[3] == 'T') && (line4[3] == 'X' || line4[3] == 'T'))
             flag = 1;
         else if((line1[3] ==  'O' || line1[3] == 'T') && (line2[3] ==  'O' || line2[3] == 'T') && (line3[3] == 'O' || line3[3] == 'T') && (line4[3] == 'O' || line4[3] == 'T'))
             flag = 2;
         else if(line1[0] ==  '.' || line1[1] == '.' || line1[2] == '.' || line1[3] == '.')
             flag = 3;
         else if(line2[0] ==  '.' || line2[1] == '.' || line2[2] == '.' || line2[3] == '.')
             flag = 3;
         else if(line3[0] ==  '.' || line3[1] == '.' || line3[2] == '.' || line3[3] == '.')
             flag = 3;
         else if(line4[0] ==  '.' || line4[1] == '.' || line4[2] == '.' || line4[3] == '.')
             flag = 3;
 
 
         if(flag == 3)
             printf("Case #%d: Game has not completed\n", i);
             //fprintf(ofp,"Case #%d: Game has not completed\n", i);
         else if(flag == 1)
             printf("Case #%d: X won\n", i);
             //fprintf(ofp,"Case #%d: X won\n", i);
         else if(flag == 2)
             printf("Case #%d: O won\n", i);
             //fprintf(ofp,"Case #%d: O won\n", i);
         else
             printf("Case #%d: Draw\n", i);
             //fprintf(ofp,"Case #%d: Draw\n", i);
     }
 
     return 0;
 }

