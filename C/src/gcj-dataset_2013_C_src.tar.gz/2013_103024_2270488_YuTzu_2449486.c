#include <stdio.h>
 #include <stdlib.h>
 
 int **lawn(int N, int M){
     int i;
     int **campo = (int**)malloc(N *sizeof(int*));
     for(i=0; i<N; i++)
         campo[i]=(int*)malloc(M *sizeof(int));
     return campo;
 }
 
 void carrega(int **campo, int N, int M){
     int i, j;
     for(i=0; i<N; i++)
         for(j=0; j<M; j++)
             scanf("%d", &campo[i][j]);
 }
 
 void inicial(int **campo, int N, int M){
     int i, j;
     for(i=0; i<N; i++)
         for(j=0; j<M; j++)
             campo[i][j]=100;
 }
 
 void desaloca(int **campo, int N, int M){
     int i;
     for(i=0; i<N; i++)
         free(campo[i]);
     free(campo);
 }
 
 int maximoLinha(int **campo, int M, int x){
     int m, i;
     m = campo[x][0];
     for(i=1; i<M; i++){
         if(campo[x][i]>m)
             m=campo[x][i];
     }
     return m;
 }
 
 int maximoColuna(int **campo, int N, int x){
     int m,i;
     m = campo[0][x];
     for(i=1; i<N; i++){
         if(campo[i][x]>m)
             m=campo[i][x];
     }
     return m;
 }
 
 void novaLinha(int **campo, int M, int x, int valor){
     int i;
     for(i=0; i<M; i++)
         if(campo[x][i]>valor)
             campo[x][i]=valor;
 }
 
 void novaColuna(int **campo, int N, int x, int valor){
     int i;
     for(i=0; i<N; i++)
         if(campo[i][x]>valor)
             campo[i][x]=valor;
 }
 
 void trabalho(int **campo, int **pattern, int N, int M){
     int i;
     int h;
     for(i=0; i<M; i++){
         h = maximoColuna(pattern, N, i);
         novaColuna(campo, N, i, h);
     }
     for(i=0; i<N; i++){
         h = maximoLinha(pattern, M, i);
         novaLinha(campo, M, i, h);
     }
 }
 
 int verifica(int **campo, int **pattern, int N, int M){
     int i,j;
     for(i=0; i<N; i++){
         for(j=0; j<M; j++){
             if(campo[i][j]!=pattern[i][j])
                 return 0;
         }
     }
     return 1;
 }
 
 void imprime(int i, int s){
     if(s)
         printf("Case #%d: YES\n", i);
     else
         printf("Case #%d: NO\n", i);
 }
 
 int main(){
     int T,N,M;
     int i,j,s;
     int **campo, **pattern;
 
     scanf("%d\n", &T);
 
     for(i=0; i<T; i++){
         scanf("%d %d\n", &N, &M);
         campo = lawn(N,M);
         pattern = lawn(N,M);
         carrega(pattern, N, M);
         inicial(campo, N, M);
         trabalho(campo, pattern, N, M);
         s = verifica(campo, pattern, N, M);
         imprime(i+1, s);
 
         desaloca(campo, N, M);
         desaloca(pattern, N, M);
     }
     return 0;
 }

