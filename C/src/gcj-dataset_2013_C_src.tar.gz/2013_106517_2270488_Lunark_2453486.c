//Problem A. Tic-Tac-Toe-Tomek
 #include<stdio.h>
 int main()
 {
     freopen("input_A_4.txt","r",stdin);
     freopen("output_A_4.txt","w",stdout);
 
     int i,j,k,n,T,p,l;
     int ans[1005]={};
     char x[5][5],a;
 
     scanf("%d",&T);
 
     for(k=0;k<T;k++)
     {
         for(j=0;j<4;j++)
         {
             scanf("%s",&x[j]);
         }
         ans[k] = 0;
 
             if(x[0][0]!='.')
             {
                 if(x[0][0]=='T') a = x[1][1];
                 else a = x[0][0];
                 if((a==x[1][1]||x[1][1]=='T')&&(a==x[2][2]||x[2][2]=='T')&&(a==x[3][3]||x[3][3]=='T'))
                 {
                     ans[k] = a;
                     //continue;
                 }
             }
 
             if(x[0][3]!='.')
             {
                 if(x[0][3]=='T') a = x[1][2];
                 else a = x[0][3];
                 if((a==x[1][2]||x[1][3]=='T')&&(a==x[2][1]||x[2][1]=='T')&&(a==x[3][0]||x[3][0]=='T'))
                 {
                     if(ans[k]==0)
                     {
                         ans[k] = a;
                     }
                     else
                     {
                         if(ans[k]!=a)
                         {
                             ans[k] = 3;
                             continue;
                         }
                     }
 
                 }
             }
 
             for(i=0;i<4;i++)
             {
                 if(x[i][0]=='.') continue;
                 if(x[i][0]=='T') a = x[i][1];
                 else a = x[i][0];
                 if((a==x[i][1]||x[i][1]=='T')&&(a==x[i][2]||x[i][2]=='T')&&(a==x[i][3]||x[i][3]=='T'))
                 {
                     if(ans[k]==0)
                     {
                         ans[k] = a;
                     }
                     else
                     {
                         if(ans[k]!=a)
                         {
                             ans[k] = 3;
                             break;
                         }
                     }
                 }
             }
 
             if(ans[k]==3)continue;
             for(i=0;i<4;i++)
             {
                 if(x[0][i]=='.') continue;
                 if(x[0][i]=='T') a = x[1][i];
                 else a = x[0][i];
                 if((a==x[1][i]||x[1][i]=='T')&&(a==x[2][i]||x[2][i]=='T')&&(a==x[3][i]||x[3][i]=='T'))
                 {
                     if(ans[k]==0)
                     {
                         ans[k] = a;
                     }
                     else
                     {
                         if(ans[k]!=a)
                         {
                             ans[k] = 3;
                             break;
                         }
                     }
                 }
             }
 
         if(ans[k]==0)
         {
             for(i=0;i<4;i++)
             {
                 for(j=0;j<4;j++)
                 {
                     if(x[i][j]=='.')
                     {
                         ans[k]=1;
                         break;
                     }
                 }
                 if(ans[k]==1) break;
             }
         }
 
     }
     for(i=0;i<T;i++)
     {
 
         printf("Case #%d: ",i+1);
         if(ans[i]==0||ans[i]==3)printf("Draw\n");
         else if(ans[i]==1) printf("Game has not completed\n");
         else printf("%c won\n",ans[i]);
 
     }
 
     return 0;
 }

