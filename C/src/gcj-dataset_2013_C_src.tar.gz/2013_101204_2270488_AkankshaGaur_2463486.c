#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 
 int CheckPallindrome(int n)
 {
     int n1, rev = 0, rem;
 
     n1 = n;
     /* logic */
     while (n > 0)
     {
 
         rem = n % 10;
         rev = rev * 10 + rem;
         n = n / 10;
 
     }
     if (n1 == rev)
     {
         return 1;
     }
     else
     {
         return 0;
     }
 }
 
 int IsPerfectSquare(int number)
 {
     if (number< 0)
         return 0;
     int root = (round(sqrt(number)));
     if(number == (root * root))
     {
         return 1;
     }
     else
     {
         return 0;
     }
 }
 
 void PrintOutput(FILE *outputFile,int testCaseNumber,int totalFnSFound)
 {
     fprintf(outputFile,"Case #%d: %d\n",testCaseNumber,totalFnSFound);
 }
 
 int main()
 {
     FILE *inputFile;
 
     inputFile = fopen("C-small-attempt0.in","r");
 
     FILE *outputFile;
 
     outputFile = fopen("C-small-attempt0.out","w");
 
     int totalTestCase;
     fscanf(inputFile,"%d\n",&totalTestCase);
 
     for(int testCase=1; testCase<=totalTestCase; testCase++)
     {
         int lowerLimit;
         int higherLimit;
         int totalFnSFound =0;
 
         fscanf(inputFile,"%d %d\n",&lowerLimit,&higherLimit);
 
         for(int number=lowerLimit; number<=higherLimit; number++)
         {
 
             //Check if Pallindrome
             if(CheckPallindrome(number)==1 && IsPerfectSquare(number)==1)
             {
                 int squareRoot=(round(sqrt(number)));
 
                 if(CheckPallindrome(squareRoot))
                 {
                     totalFnSFound++;
                 }
             }
         }
 
         PrintOutput(outputFile,testCase,totalFnSFound);
     }
 
     fclose(inputFile);
     fclose(outputFile);
     return 0;
 }

