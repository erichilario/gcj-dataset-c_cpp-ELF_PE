#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 #include <math.h>
 
 bool isFair(int a);
 bool isSquare(int a);
 
 int main(int argc, char **argv) {
   // Input file
   if (argc != 2) {
     printf("Wrong number of arguments.\n");
     return 1;
   }
   
   const char* filename = argv[1];
   FILE *fp;
   fp = fopen(filename, "r");
   
   // Output file
   const char* outfilename = "out.txt";
   FILE *fpout;
   fpout = fopen(outfilename, "w");
 
   char s[10];
   fscanf(fp, "%s\n", s);
   const int T = atoi(s);
   
   for (int t = 1; t <= T; t++) {
     fscanf(fp, "%s ", s);
     int A = atoi(s);
     fscanf(fp, "%s\n", s);
     int B = atoi(s);
 
     int nbFairSquare = 0;
     for (int k = A; k <= B; k++) {
       if (isSquare(k) && isFair(k) && isFair((int)sqrt(k)))
 	nbFairSquare++;
     }
 
     fprintf(fpout, "Case #%d: %d\n", t, nbFairSquare);
 
   }
 
   return 0;
 }
 
 bool isFair(int a) {
   int tab[101];
   const int M = 10;
 
   // Put figures of a in tab
   int i = 0;
   for (; a > 0; i++) {
     tab[i] = a % M;
     a /= M;
   }
   const int L = i - 1; 
 
   // Check if palindrome
   for (int j = 0; j <= L / 2; j++) {
     if (tab[j] != tab[L - j])
       return false;
   }
 
   return true;
 }
 
 bool isSquare(int a) {
   double d = sqrt((double) a);
   return (d == floor(d));
 }

