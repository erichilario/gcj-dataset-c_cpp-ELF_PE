#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
 	int test_case, row, column, i, j, k, flag, square, max, r, c, min;
 	int *lawn, *recover_row, *recover_column;
 	scanf("%d",&test_case);
 	getchar();
 	for (k=1; k<=test_case; k++)
 	{
 		flag=1, max=0, min=10, r=-1, c=-1;
 		scanf("%d",&row);
 		getchar();
 		scanf("%d",&column);
 		getchar();
 		lawn=(int *)calloc(row*column,sizeof(int));
 		recover_row=(int *)calloc(row,sizeof(int));
 		recover_column=(int *)calloc(column,sizeof(int));
 		for (i=0; i<row; i++)
 		{
 			for (j=0; j<column; j++)
 			{
 				scanf("%d",&lawn[column*i+j]);
 				if (max<lawn[column*i+j])	max=lawn[column*i+j];
 				if (min>lawn[column*i+j])	min=lawn[column*i+j];
 				getchar();
 			}
 		}
 		while (min!=max)
 		{
 			min++;
 			for (i=0; i<row; i++)
 			{
 				square=lawn[column*i];
 				for (j=0; j<column; j++)
 				{
 					if (square!=lawn[column*i+j])	break;
 					else if ((j+1)==column && square!=max)
 					{
 						r++;
 						recover_row[r]=i;
 					}
 				}
 			}
 			for (j=0; j<column; j++)
 			{
 				square=lawn[j];
 				for (i=0; i<row; i++)
 				{
 					if (square!=lawn[column*i+j])	break;
 					else if ((i+1)==row && square!=max)
 					{
 						c++;
 						recover_column[c]=j;					
 					}
 				}
 			}
 			while (r>=0)
 			{
 				i=recover_row[r];
 				for (j=0; j<column; j++)	lawn[i*column+j]=min;
 				r--;
 			}
 			while (c>=0)
 			{
 				j=recover_column[c];			
 				for (i=0; i<row; i++)	lawn[i*column+j]=min;
 				c--;
 			}
 		}
 		for (i=0; i<row; i++)
 		{
 			for (j=0; j<column; j++)
 			{
 				if (max!=lawn[column*i+j])
 				{
 					flag=0;
 				}
 			}
 		}
 		if (flag==1)	printf("Case #%d: YES\n",k);
 		else	printf("Case #%d: No\n",k);
 		free(lawn);
 		free(recover_row);
 		free(recover_column);
 	}
 	return 0;
 }

