        # include<stdio.h>
         # include<stdlib.h>
         # include<string.h>
         int checkrow(int ,int);
         int checkcol(int ,int);
         int setrow_temp(int,int);
         int setcol_temp(int,int);
          int n,m;
          int rect[100][100];
          int temp[100][100];
         int main()
         {
 
 FILE* fp1=fopen("/home/ajit/Downloads/aa.in","r+");
 FILE* fp2=fopen("/home/ajit/Downloads/ans.txt","w+");
 int i,j,k,l,no_of_cases,pp;
 fscanf (fp1,"%d", &no_of_cases);
 printf("no of cases=%d",no_of_cases);
 
 for(pp=0;pp<no_of_cases;pp++)
 {
   int big=0;
   fscanf(fp1,"%d %d",&n,&m);
   printf("n=%d..m=%d\n",n,m);
 
 int no,o_no=0,x_no=0;
 
 for(i=0;i<n;i++)
 {
   for(j=0;j<m;j++)
   {
     fscanf(fp1,"%d",&rect[i][j]);
     printf("%d ",rect[i][j]);
     if(big<rect[i][j])
     big=rect[i][j];
   }
   printf("\n");
 
 }
 
 for(i=0;i<n;i++)
 {
   for(j=0;j<m;j++)
   {
     temp[i][j]=big;
   }
 
 }
 printf("\nbig=%d",big);
 
 for(i=0;i<n;i++)
 {
   for(j=0;j<m;j++)
   {
    if(rect[i][j]<big)
    {
      int ret1;
 
      ret1=checkrow(i,rect[i][j]);
      if(ret1)
      setrow_temp(i,rect[i][j]);
 
 
      int ret2;
      ret2=checkcol(j,rect[i][j]);
      if(ret2)
      setcol_temp(j,rect[i][j]);
 
 
 
    }
 
 
   }
 
 
 }
 int check=0;
 for(i=0;i<n;i++)
 {
   for(j=0;j<m;j++)
   {
     if(rect[i][j]!=temp[i][j])
     {
       check=1;
       break;
     }
   }
   if(check)
   break;
 }
 
 if(check)
 fprintf(fp2,"Case #%d: NO\n",pp+1);
 else
 fprintf(fp2,"Case #%d: YES\n",pp+1);
 
 
 }
 //printf("\npp=%d",pp);
 fclose(fp1);
 fclose(fp2);
 
 return 0;
 
         }
 
 
   int checkrow(int row,int val)
   {
     printf("\ncheckrow:val=%d",val);
     int i,j=1,l;
     for(i=0;i<m;i++)
     {
       if(rect[row][i]>val)
       return 0;
     }
 return 1;
   }
 
   int checkcol(int col,int val)
   {
    int i,j=1,l;
     for(i=0;i<n;i++)
     {
       if(rect[i][col]>val)
       return 0;
     }
 return 1;
 
   }
   int setrow_temp(int row,int val)
   {
    int i,j;
    for(i=0;i<m;i++)
    temp[row][i]=val;
 
   }
 
   int setcol_temp(int col,int val)
   {
    int i,j;
    for(i=0;i<n;i++)
    temp[i][col]=val;
 
   }
 

