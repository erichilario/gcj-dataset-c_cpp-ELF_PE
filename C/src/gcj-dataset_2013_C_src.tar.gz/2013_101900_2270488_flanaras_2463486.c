#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 #define LEN 60
 
 int getUntil(FILE**,char);
 int isPalindrome(int);
 
 int main()
 {
 	FILE* fp,* FtS;
 	int cases,current,A,B,interval,squared,count = 0,temp;
 	double rootnum;
 	printf("%p\n",&interval);
 	system("pause");
 	fp = fopen("C-small-attempt0(1).in","r");
 	if (fp != NULL)
 	{
 		FtS = fopen("Fair and Square results.txt","w");
 		cases = getUntil(&fp,'\n');
 		for(current=0 ; current<cases ; current++)
 		{
 			count = 0;
 			A = getUntil(&fp,' ');
 			B = getUntil(&fp,'\n');
 			temp = (int)sqrt((double)B);
 			for(interval=sqrt((double)A) ; interval<=temp ; interval++)
 			{
 				if(isPalindrome(interval) == 1)
 				{
 					squared = pow((double)interval,2);
 					if (isPalindrome(squared))
 					{
 						if (squared>=A && squared<=B)
 						{
 							printf("%d %d\n",(int)pow((double)interval,2),interval);
 							count++;
 						}
 					}
 				}
 				//if (isPalindrome(interval) == 1)
 				//{
 				//	rootnum = sqrt((double)interval);
 				//	if ((int)rootnum == rootnum)
 				//	{
 				//	//	printf("%d %lf\n",interval,rootnum);
 				//		rooted = rootnum;
 				//		if (isPalindrome(rooted) == 1)
 				//		{
 				//			printf("%d %d\n",interval,(int)rootnum);
 				//			count++;
 				//		}
 				//	}
 				//}
 			}
 			fprintf(FtS,"Case #%d: %d\n",current+1,count);
 		}
 		fclose(FtS);
 		fclose(fp);
 	}
 	system("pause");
 }
 
 int getUntil(FILE** fp,char until)
 {
 	char ch,string[LEN];
 	char i;
 	for(i=0 ; i<LEN ; i++)
 		string[i] = 0;
 	ch = getc(*fp);
 	//	printf("%c",ch);
 	for(i=0 ; (ch != until) && (ch != EOF) ; i++)
 	{
 		string[i] = ch;
 		ch = getc(*fp);
 		//		printf("%c",ch);
 	}
 	//	printf("\n");
 	return atoi(string);
 }
 
 int isPalindrome(int num)
 {
 	char reversed[LEN],size,i;
 	for(size=0 ; num != 0 ; size++)
 	{
 		reversed[size] = num % 10;
 		num /= 10;
 	}
 	for(i=0 ; i<size/2 ; i++)
 		if(reversed[i] != reversed[size-1 - i])
 			return 0;
 	return 1;
 }
