#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 int main(void)
 {
   int t,count,i,j,xrow[4],xcol[4],xdiag[2],orow[4],ocol[4],odiag[2],iterator,nc;
   char ws,grid[4][4];
   FILE *fin,*fout;
   fin=fopen("A-large.in","r");
   fout=fopen("ojam.txt","w");
   
   //to get the number of test cases
   fscanf(fin,"%d",&t);
   //printf("no of test cases are %d",t);
   
   //initializing cases
   count=0;
   
   //looping
   while(fscanf(fin,"%c",&ws)!=EOF)
   {
     count++;
     //setting row and col
     i=0;
     j=0;
     nc=0;
     for(iterator=0;iterator<4;iterator++)
     {
       xrow[iterator]=0;
       xcol[iterator]=0;
       orow[iterator]=0;
       ocol[iterator]=0;
       if(iterator<2)
       {
 	xdiag[iterator]=0;
 	odiag[iterator]=0;
       }
     }
     
     //looping
     while(i!=4)
     {
       fscanf(fin,"%c",&ws);
       //printf("%c",ws);
       
       //case X
       if(ws == 'X')
       {
 	xrow[i]++;
 	xcol[j]++;
 	if(i==j)
 	  xdiag[0]++;
 	if(i+j==3)
 	  xdiag[1]++;
       }
       
       //case Y
       if(ws == 'O')
       {
 	orow[i]++;
 	ocol[j]++;
 	if(i==j)
 	  odiag[0]++;
 	if(i+j==3)
 	  odiag[1]++;
       }
       
       //case T
       if(ws == 'T')
       {
 	xrow[i]++;
 	xcol[j]++;
 	orow[i]++;
 	ocol[j]++;
 	if(i==j)
 	{
 	  xdiag[0]++;
 	  odiag[0]++;
 	}
 	if(i+j==3)
 	{
 	  xdiag[1]++;
 	  odiag[1]++;
 	}
       }
       
       //case .
       if(ws == '.')
 	nc=1;
       
       //update row and col
       if(ws == '\n')
       {
 	//printf("n");
 	j=0;
 	i++;
       }
       else
 	j++;
       
     }
     for(iterator=0;iterator<4;iterator++)
     {
       if(xrow[iterator]==4)
       {fprintf(fout,"Case #%d: X won",count);break;}
       if(xcol[iterator]==4)
       {fprintf(fout,"Case #%d: X won",count);break;}
       if(orow[iterator]==4)
       {fprintf(fout,"Case #%d: O won",count);break;}
       if(ocol[iterator]==4)
       {fprintf(fout,"Case #%d: O won",count);break;}
       if(iterator<2)
       {
 	if(xdiag[iterator]==4)
 	{fprintf(fout,"Case #%d: X won",count);break;}
 	if(odiag[iterator]==4)
 	{fprintf(fout,"Case #%d: O won",count);break;}
       }
     }
     if(iterator==4)
       if(!nc)
 	fprintf(fout,"Case #%d: Draw",count);
       else
 	fprintf(fout,"Case #%d: Game has not completed",count);
     fprintf(fout,"\n");
     if(count==t)
       break;
   } 
   
   return 0;
 }
