#include <stdio.h>
 #include <stdint.h>
 #include <stdbool.h>
 #include <math.h>
 #include <string.h>
 
 static uint64_t s_au64Table[] = {
    1,
    4,
    9,
    121,
    484,
    10201,
    12321,
    14641,
    40804,
    69696,
    1002001,
    1234321,
    4008004,
    100020001,
    102030201,
    104060401,
    121242121,
    123454321,
    125686521,
    400080004,
    10000200001,
    10221412201,
    12102420121,
    12345654321,
    40000800004,
    1000002000001,
    1002003002001,
    1004006004001,
    1020304030201,
    1022325232201,
    1024348434201,
    1210024200121,
    1212225222121,
    1214428244121,
    1232346432321,
    1234567654321,
    4000008000004,
 };
 
 static uint16_t s_u16Solve(uint64_t u64Min, uint64_t u64Max)
 {
    uint64_t u16Res = 0;
 
    for (uint16_t u16; u16 < sizeof(s_au64Table)/sizeof(uint64_t); ++u16)
    {
       if (s_au64Table[u16] >= u64Min &&
           s_au64Table[u16] <= u64Max)
       {
          u16Res++;
       }
    }
 
    return u16Res;
 }
 
 int main(int argc, char *argv[])
 {
    uint16_t u16Cases;
 
    scanf("%hu", &u16Cases);
 
    for (int i = 0; i < u16Cases; ++i)
    {
       uint64_t u64Min;
       uint64_t u64Max;
       
       scanf("%llu %llu", &u64Min, &u64Max);
 
       printf("Case #%d: %d\n", i + 1, s_u16Solve(u64Min, u64Max));
    }
 
    return 0;
 }

