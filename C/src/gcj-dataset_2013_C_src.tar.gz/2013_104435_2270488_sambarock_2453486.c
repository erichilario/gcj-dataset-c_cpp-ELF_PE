#include<stdio.h>
 //#include<files.h>
 
 /*
 void print(char a[][4])
 {
 	int i,j;
 	printf("\n");
 	for(i=0;i<4;i++)
 	{
 		for(j=0;j<4;j++)
 			printf("%c ",a[i][j]);
 			
 		printf("\n");
 	}
 }
 
 void intprint(int a[][4])
 {
 	int i,j;
 	printf("\n");
 	for(i=0;i<4;i++)
 	{
 		for(j=0;j<4;j++)
 			printf("%d ",a[i][j]);
 			
 		printf("\n");
 	}
 }
 */
 
 int main()
 {
 	char a[4][4];
 	int b[4][4];
 	FILE *ip=fopen("input.txt","r");
 	FILE *op=fopen("output.txt","w");
 	int n, i, j, k, res, stat=0;
 	
 	fscanf(ip,"%d",&n);
 	
 	for(i=1;i<=n;i++)
 	{
 		res=3;
 		stat=0;
 		
 		fscanf(ip,"%s",a[0]);
 		fscanf(ip,"%s",a[1]);
 		fscanf(ip,"%s",a[2]);
 		fscanf(ip,"%s",a[3]);
 		
 		//print(a);
 		
 		//printf("\ncheckpoint 1");
 		
 		for(j=0;j<4;j++)
 		{
 			for(k=0;k<4;k++)
 			{
 				if(a[j][k]=='.')
 				{
 					stat=1;
 					b[j][k]=200;
 					//break;
 				}
 				else if(a[j][k]=='X')
 				{
 					b[j][k]=1;
 				}
 				else if(a[j][k]=='O')
 				{
 					b[j][k]=-1;
 				}
 				else
 				{
 					b[j][k]=0;
 				}
 			}
 			
 		}
 		
 		//intprint(b);
 		
 		
 		for(k=0;k<4;k++)
 		{
 				if( ( (b[k][0]+b[k][1]+b[k][2]+b[k][3])>=3 && (b[k][0]+b[k][1]+b[k][2]+b[k][3])<=100 ) || ( (b[0][k]+b[1][k]+b[2][k]+b[3][k])>=3 && (b[0][k]+b[1][k]+b[2][k]+b[3][k])<=100 ) )
 				{
 					res=1;
 				}
 				
 				else if( ( (b[k][0]+b[k][1]+b[k][2]+b[k][3])<=-3 && (b[k][0]+b[k][1]+b[k][2]+b[k][3])<=100 ) || ( (b[0][k]+b[1][k]+b[2][k]+b[3][k])<=-3 && (b[0][k]+b[1][k]+b[2][k]+b[3][k])<=100 ) )
 				{
 					res=2;
 				}
 		}
 		
 		if( ( (b[0][0]+b[1][1]+b[2][2]+b[3][3])>=3 && (b[0][0]+b[1][1]+b[2][2]+b[3][3])<=100 ) || ( (b[0][3]+b[1][2]+b[2][3]+b[3][0])>=3 && (b[0][3]+b[1][2]+b[2][3]+b[3][0])<=100 ) )
 		{
 			res=1;
 		}
 		else if( ( (b[0][0]+b[1][1]+b[2][2]+b[3][3])<=-3 && (b[0][0]+b[1][1]+b[2][2]+b[3][3])<=100 ) || ( (b[0][3]+b[1][2]+b[2][1]+b[3][0])<=-3 && (b[0][3]+b[1][2]+b[2][1]+b[3][0])<=100 ) )
 		{
 			res=2;
 		}
 		
 		
 		if(res==1)
 		{
 			fprintf(op,"Case #%d: X won\n", i);
 			//printf("\n Case #%d: X won", i);
 		}
 		else if(res==2)
 		{
 			fprintf(op,"Case #%d: O won\n", i);
 		}
 		else if(res==3 && stat==0)
 		{
 			fprintf(op,"Case #%d: Draw\n", i);
 		}
 		else if(res==3 && stat==1)
 		{
 			fprintf(op,"Case #%d: Game has not completed\n", i);
 		}
 		
 	}
 	
 	fclose(ip);
 	fclose(op);
 	
 	
 }

