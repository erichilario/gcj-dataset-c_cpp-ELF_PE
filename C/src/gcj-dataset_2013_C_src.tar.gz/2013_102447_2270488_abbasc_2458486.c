#include <stdio.h>
 #include <stdbool.h>
 #include <stdlib.h>
 
 int ans[200];
 int position;
 int marker[21];
 
 struct chest
 {
 	bool done;
 	int count;
 	int open;
 	int key[41];
 }c[21];
 
 int openChest(int,int*);
 
 int main()
 {
 
 	freopen("D-small-attempt3.in", "r", stdin);
 	freopen("treasure.txt", "w", stdout);
 
 	int t,a;
 	scanf("%d", &t);
 	for(a = 1; a <= t; a++)
 	{
 		int k,n,i,j;
 		for(i = 0; i < 21; i++)
 			marker[i] = -1;
 		int keys[21] = {0};
 
 		scanf("%d %d", &k, &n);
 		position = n - 1;
 		for(i = 0; i < k; i++)
 		{
 			scanf("%d", &j);
 			keys[j]++;
 		}
 		for(i = 0; i < n; i++)
 		{
 			scanf("%d %d", &c[i].open, &c[i].count);
 			for(j = 0;j < c[i].count; j++)
 				scanf("%d", &c[i].key[j]);
 			c[i].done = false;
 		}
 		if(openChest(n,keys) == 1)
 		{
 			printf("Case #%d: ",a);
 			for(i = 0; i < n; i++)
 				printf("%d ", ans[i]);
 			printf("\n");
 		}
 		else	printf("Case #%d: IMPOSSIBLE\n", a);
 
 
 	}
 	return 0;
 }
 
 int openChest(int n,int a[])
 {
 	int allKey[21];
 	int i,j,index;
 	for(i = 0;i < 21;i++)
 	{
 		allKey[i] = a[i];
 	}
 
 	for(index = 0; index < n;index++)
 	{
 		if(allKey[c[index].open] > 0 && !c[index].done && marker[index] == -1)
 		{
 			allKey[c[index].open]--;
 			for(j = 0 ;j < c[index].count; j++)
 			{
 				allKey[c[index].key[j]]++;
 				for(i = 0; i < n; i++)
 					if(marker[i] == c[index].key[j])
 						marker[i] = -1;
 			}
 			c[index].done = true;
 			if(openChest(n,allKey))
 			{
 				ans[position--] = index+1;
 				return 1;
 			}
 			else
 			{
 					c[index].done = false;
 					allKey[c[index].open]++;
 					marker[index] = c[index].open;
 			}
 		}
 	}
 	for(i = 0; i < n;i++)
 	{
 		if(!c[i].done)
 			return 0;
 	}
 	return 1;
 }

