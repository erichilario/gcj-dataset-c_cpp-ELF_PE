#include <stdio.h>
 
 main()
 {
     freopen("B-large.in","r",stdin);
     freopen("lawnmoverout.txt","w",stdout);
     int t,test;
     scanf("%d",&test);
     for (t=1;t<=test;t++)
     {
         printf("Case #%d: ",t);
         int m,n;
         scanf("%d%d",&n,&m);
         int arr[n][m],start[n][m],fix[n][m],cutx,cuty;
         int i,j,max=-1,countfix=0,count=0;
         for (i=0;i<n;i++)
         {
             for (j=0;j<m;j++)
             {
                 scanf("%d",&arr[i][j]);
                 start[i][j] = 100;
                 fix[i][j] = 0;
             }
         }
         cut:;
         // check max size to be cut
         for (i=0;i<n;i++)
         {
             for (j=0;j<m;j++)
             {
                 if (arr[i][j] > max && fix[i][j] == 0)
                 {
                     max = arr[i][j];
                     cutx = j;
                     cuty = i;
                 }
             }
         }
 
         // cut horizontal line
         //check
         for(i=0;i<m;i++)
         {
             if (fix[cuty][i] == 1 && max != arr[cuty][i])
             {
                 count++;
                 goto skipcuthor;
             }
         }
         for (i=0;i<m;i++)
         {
             start[cuty][i] = max;
             if (start[cuty][i] == arr[cuty][i] && fix[cuty][i] != 1)
             {
                 fix[cuty][i] = 1;
                 countfix++;
             }
         }
         skipcuthor:;
         // cut vertical line
         //check
         for(i=0;i<n;i++)
         {
             if (fix[i][cutx] == 1 && max != arr[i][cutx])
             {
                 count++;
                 goto skipcutver;
             }
         }
         for (i=0;i<n;i++)
         {
             start[i][cutx] = max;
             if (start[i][cutx] == arr[i][cutx] && fix[i][cutx] != 1)
             {
                 fix[i][cutx] = 1;
                 countfix++;
             }
         }
         skipcutver:;
         // check if it's cutable
         if (count == 2) // can't cut anymore
         {
             printf("NO\n");
             goto end;
         }
         else
         {
             count = 0;
         }
         // check if it's end?
         max = -1;
         if (countfix == m*n)
         {
             printf("YES\n");
             goto end;
         }
         else goto cut;
         end:;
     }
 }

