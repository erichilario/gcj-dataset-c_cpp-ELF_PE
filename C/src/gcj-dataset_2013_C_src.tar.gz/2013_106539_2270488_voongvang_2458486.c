#include <stdio.h>
 #include <stdlib.h>
 
 int test, i, flag, n, k, keys[405], sol[405],c1,c2,k1,temp, chest_type[405], ck[405], ckeys[405][405], tkeys[405],  opened[405];
 
 void dfs(int start, int num) {
 
     if(num == n) {
         sol[num] = start;
         flag = 1;
         return;
     }
 
     opened[start] = 1;
 
     for(k1 = 1; k1 <= ck[start]; k1++)
         tkeys[ckeys[start][k1]]++;
 
     for(k1 = 1; k1 <= n; k1++) {
         if(opened[k1] == 0 && tkeys[chest_type[k1]] >0) {
             tkeys[chest_type[k1]]--;
             dfs(k1, num+1);
             if(flag == 1) {
                 sol[num] = start;
                 return;
             }
             tkeys[chest_type[k1]]++;
         }
     }
 
     for(k1 = 1; k1 <= ck[start]; k1++)
         tkeys[ckeys[start][k1]]--;
 
 }
 
 int main()
 {
 
     FILE *ifp, *ofp;
     //ifp=fopen("problem_b.in", "r");
     ofp=fopen("problem_d.out", "w");
     scanf("%d",&test);
     //fscanf(ifp,"%d",&test);
     for(i = 1; i <= test; i++) {
         flag = 0;
 
         for(c1 = 1; c1 < 405; c1++)
             keys[c1] = 0;
 
         scanf("%d %d", &k, &n);
 
         for(c1 = 0; c1 < k; c1++) {
             scanf("%d", &temp);
             keys[temp]++;
         }
 
         for(c1 = 1; c1 <= n; c1++) {
             scanf("%d %d", &chest_type[c1], &ck[c1]);
             for(c2 = 1; c2 <= ck[c1]; c2++)
                 scanf("%d", &ckeys[c1][c2]);
         }
         for(c1 = 1; c1 <= n; c1++) {
             if(flag == 1)
                 break;
             for(c2 = 1; c2 <= 405; c2++)
                 tkeys[c2] = keys[c2];
             for(c2 = 1; c2 <= n; c2++)
                 opened[c2] = 0;
             if(keys[chest_type[c1]] > 0) {
                 tkeys[chest_type[c1]]--;
                 dfs(c1, 1);
             }
 
         }
 
         if(flag == 0)
             fprintf(ofp,"Case #%d: IMPOSSIBLE\n", i);
             //printf("Case #%d: IMPOSSIBLE\n", i);
         else {
             fprintf(ofp,"Case #%d:", i);
             //printf("Case #%d:", i);
             for(c1 = 1; c1 <= n; c1++)
                 fprintf(ofp," %d", sol[c1]);
                 //printf(" %d", sol[c1]);
             fprintf(ofp,"\n");
             //printf("\n");
         }
 
     }
 
     return 0;
 }

