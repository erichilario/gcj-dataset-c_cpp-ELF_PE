#include <stdio.h>
 
 int pal(int x)
 {
     int k = 1, t = x;
     while(t)
         k *= 10, t /= 10;
     k /= 10;
     for(; x>9; x %= k, x /= 10, k /= 100)
         if(x / k != x % 10)
             return 0;
     return 1;
 }
 
 int main(int argc, const char *argv[])
 {
 	//freopen("input.txt", "r", stdin);
 	//freopen("output.txt", "w", stdout);
     int i, l, r, t, ans, k, o;
     for(scanf("%d%*c", &o), k = 1; k <= o; ++k)
     {
 		printf("Case #%d: ", k);
         scanf("%d%d", &l, &r);
         ans = 0;
         for(i = l; i <= r; ++i)
         {
             t = sqrt(i);
             if(t*t == i && pal(t) && pal(i))
                 ++ans;
         }
         printf("%d\n", ans);
     }
     return 0;
 }

