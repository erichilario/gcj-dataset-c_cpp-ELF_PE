#include <stdio.h>
 #include <stdlib.h>
 
 struct list_s {
 	int num;
 	int square;
 };
 
 int total_found = 0;
 struct list_s square_palindrome[128] = {0, 0, 0};
 
 int check_palindrome(int num) {
 	int palindrome = 0;
 	int tmp1 = 0;
 	int tmp2 = 0;
 	int tmp3 = 0;
 	int tmp4 = 0;
 
 	if(num > 10000) {
 		tmp1 = num % 10000;
 		tmp2 = tmp1 % 1000;
 		tmp3 = tmp2 % 100;
 		tmp4 = tmp3 % 10;
 		if((((num - tmp1) / 10000) == tmp4)) {
 			if((((tmp1 - tmp2) / 1000) == ((tmp3 - tmp4) / 10)))
 				palindrome = 1;
 		}
 	} else if(num > 1000) {
 		tmp1 = num % 1000;
 		tmp2 = tmp1 % 100;
 		tmp3 = tmp2 % 10;
 		if((((num - tmp1) / 1000) == tmp3) &&
 			(((tmp1 - tmp2) / 100) == ((tmp2 - tmp3) / 10)))
 			palindrome = 1;
 	} else if(num > 100) {
 		if(((num - (num % 100)) / 100) == (num % 10))
 			palindrome = 1;
 	} else if(num > 10) {
 		if((((num - (num % 10)) / 10) == (num % 10)))
 			palindrome = 1;
 	} else if(num != 10) {
 		palindrome = 1;
 	}
 	return palindrome;
 }
 
 int find_square_palindrome(int start, int end) {
 	int num = start;
 	int square = num * num;
 
 	for(; square < end; num++, square = num * num) {
 		if(check_palindrome(num)) {
 //			printf("%d => %d\n", num, check_palindrome(square));
 			if(check_palindrome(square)) {
 //				printf("%d %d => %d\n", num, square, check_palindrome(square));
 				square_palindrome[total_found].num = num;
 				square_palindrome[total_found].square = square;
 				total_found++;
 			}
 		}
 	}
 }
 
 int locate_square_palindrome(int start, int end) {
 	int count = 0;
 	int ctr = 0;
 
 	for(ctr = 0; ctr < total_found; ctr++) {
 		if((square_palindrome[ctr].square >= start) && (square_palindrome[ctr].square <= end))
 			count++;
 	}
 
 	return count;
 }
 
 void main(int argc, char** argv) {
 	int entries = 0;
 	FILE* fp = NULL;
 	int start = 0;
 	int end = 0;
 	int ctr = 0;
 	int ans = 0;
 
 	if(argc < 2) {
 		printf("Insufficient arguments\n");
 		return;
 	}
 
 	fp = fopen(argv[1], "r");
 	if(fp == NULL) {
 		printf("Unable to open input file\n");
 		return;
 	}
 
 	fscanf(fp, "%d\n", &entries);
 //	printf("Number of entries %d\n", entries);
 
 	find_square_palindrome(1, 65000);
 	while(1) {
 		ctr++;
 		fscanf(fp, "%d %d\n", &start, &end);
 		printf("Case #%d: ", ctr, start, end);
 		ans = locate_square_palindrome(start, end);
 		printf("%d\n", ans);
 
 		if(ctr >= entries)
 			break;
 	}
 }

