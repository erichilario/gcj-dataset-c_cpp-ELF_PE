#include<stdio.h>
 #include<stdlib.h>
 char *arr;
 
 int check_x(int ares)
 {
 int res,i,j,truec=0,sum;
 for(i=0;i<4;i++)
 	{
 	sum=arr[i]+arr[4+i]+arr[8+i]+arr[12+i];
 	if(sum==348 || sum==352)
 		truec=1;
 	}
 for(i=0;i<13;i=i+4)
 	{
 	sum=arr[i]+arr[1+i]+arr[2+i]+arr[3+i];
 	if(sum==348 || sum==352)
 		truec=1;
 	}
 	sum=arr[0]+arr[5]+arr[10]+arr[15];
 	if(sum==348 || sum==352)
 		truec=1;
 	sum=arr[3]+arr[6]+arr[9]+arr[12];
 	if(sum==348 || sum==352)
 		truec=1;
 
 if(truec==1)
 res=3;
 else
 res=ares;
 return res;
 }
 
 int check_o(int ares)
 {
 int res,i,j,truec=0,sum;
 for(i=0;i<4;i++)
 	{
 	sum=arr[i]+arr[4+i]+arr[8+i]+arr[12+i];
 	if(sum==316 || sum==321)
 		truec=1;
 	}
 for(i=0;i<13;i=i+4)
 	{
 	sum=arr[i]+arr[1+i]+arr[2+i]+arr[3+i];
 	if(sum==316 || sum==321)
 		truec=1;
 	}
 	sum=arr[0]+arr[5]+arr[10]+arr[15];
 	if(sum==316 || sum==321)
 		truec=1;
 	sum=arr[3]+arr[6]+arr[9]+arr[12];
 	if(sum==316 || sum==321)
 		truec=1;
 
 if(truec==1)
 res=4;
 else
 res=ares;
 
 return res;
 }
 int test_ttt()
 {
 int res=1,truec=0;//Game not done as default case.
 int i;
 for(i=0;i<16;i++)
 	if(arr[i]=='.')
 	{
 		truec=1;break;
 	}
 if(truec==0)
 	res=2;//Change Default case to Drawn
 
 res=check_x(res);
 if(res==2 || res==1)
 res=check_o(res);
 
 return res;
 }
 
 int main()
 {
 int i,N,res;
 
 arr=(char *)malloc(20*sizeof(char));
 
 scanf("%d",&N);
 for(i=0;i<N;i++)
 {
 scanf("%s",arr);
 scanf("%s",arr+4);
 scanf("%s",arr+8);
 scanf("%s",arr+12);
 res=test_ttt();
 //printf(" New %d ,\n",res);
 if(res==1)
 printf("Case #%d: Game has not completed\n",i+1);
 if(res==3)
 printf("Case #%d: X won\n",i+1);
 if(res==4)
 printf("Case #%d: O won\n",i+1);
 if(res==2)
 printf("Case #%d: Draw\n",i+1);
 }
 return 0;
 
 }

