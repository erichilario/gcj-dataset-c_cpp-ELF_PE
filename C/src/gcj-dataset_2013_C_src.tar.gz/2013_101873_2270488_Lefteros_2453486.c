#include <stdio.h>
 #include <stdlib.h>
 
 int main (int argc, const char * argv[]) {
     
 	
 	FILE *fid=fopen("A-large.in","r");
 	//FILE *fid=fopen("A.txt", "r");
 	if (fid==NULL) {
 		printf("Cannot open file\n");
 	}
 	
 	char buffer[100];
 
 	fgets(buffer, 100, fid);
 	int T=atol(buffer);
 	printf("T=%d\n",T);
 	int Status[T];
 	// CODE
 	for (int tau=0; tau<T; tau++) 
 	{
 		int Lambda[4][4];
 		int S1, S2, S3, S4;  //Win For X or O
 		
 		
 		for (int i=0; i<4; i++) {
 			
 			fgets(buffer, 100, fid);
 			//printf("%s",buffer);
 			
 			for (int j=0; j<4; j++) {
 				if (buffer[j]=='.')
 					Lambda[i][j]=-10;
 				
 				if (buffer[j]=='T')
 					Lambda[i][j]=0;
 				
 				if (buffer[j]=='X')
 					Lambda[i][j]=1;
 				
 				if (buffer[j]=='O')
 					Lambda[i][j]=-1;
 			}
 			
 			//printf("%d %d %d %d\n",Lambda[i][0],Lambda[i][1],Lambda[i][2],Lambda[i][3]);
 		}
 		fgets(buffer, 100, fid);
 		Status[tau]=0;
 		S3=0;
 		S4=0;
 		for (int i=0; i<4; i++) {
 			
 			
 			S1=Lambda[i][0]+Lambda[i][1]+Lambda[i][2]+Lambda[i][3];
 			S2=Lambda[0][i]+Lambda[1][i]+Lambda[2][i]+Lambda[3][i];
 			S3+=Lambda[i][i];
 			S4+=Lambda[i][3-i];
 			
 			if (S1<-5 || S2<-5)
 				Status[tau]=3;
 			if (S1>=3 || S2>=3) {
 				Status[tau]=1;
 				break;
 			}
 			if ((S1<=-3 && S1>=-4) || (S2<=-3 && S2>=-4)){
 				Status[tau]=2;
 				break;
 			}
 		}
 		if ((S3<=-3 && S3>=-4) || (S4<=-3 && S4>=-4))
 			Status[tau]=2;
 		if (S3>=3 && S4>=4)
 			Status[tau]=1;
 		
 			printf("Case #%d: ",tau+1);
 			if (Status[tau]==1)
 				printf("X won\n");
 			if (Status[tau]==2)
 				printf("0 won\n");
 			if (Status[tau]==3)
 				printf("Game has not completed\n");
 			if (Status[tau]==0)
 				printf("Draw\n");
 	}
 	fclose(fid);
 	FILE* fout;
 	fout=fopen("Output.txt", "w");
 	for (int m1=0; m1<T; m1++) {
 		fprintf(fout,"Case #%d: ",m1+1);
 		if (Status[m1]==1)
 			fprintf(fout,"X won\n");
 		if (Status[m1]==2)
 			fprintf(fout,"O won\n");
 		if (Status[m1]==3)
 			fprintf(fout,"Game has not completed\n");
 		if (Status[m1]==0)
 			fprintf(fout,"Draw\n");
 	}
     return 0;
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

