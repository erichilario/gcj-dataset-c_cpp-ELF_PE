#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 
 int palin(long long k){
     long long flg=0,i,j,len;
     char str[100];
     sprintf(str,"%lld",k);
     len=strlen(str);
     for(i=0,j=len-1;i<len/2;i++,j--)
       if(str[i]!=str[j]){
         flg=1;
         break;
       }
     if(flg)
       return 0;
     else{
      return 1;
     }
 }
 
 long long sqrtx(long long k){
     long long i;
     for(i=1;;i++){
       //printf("%lld %lld\n",i*i,k);
       if(i*i==k){
         //printf("<%lld>\n",i);
         return i;
         }
       else if(i*i>k)
         break;
     }
     return 0;
 }
 
 int main(){
     long long a,b,c=0,i,j,t,k;
     freopen("c1.in","r",stdin);
     freopen("cans.txt","w",stdout);
     scanf("%lld",&t);
     
     for(i=0;i<t;i++){
        c=0;
        scanf("%lld %lld",&a,&b);
        for(j=a;j<=b;j++)
         if(palin(j)){
            k=sqrtx(j);
            if(k)
              if(palin(k))
                c++;
            //printf("%lld %lld\n",j,sqrtx(j));
         }
        printf("Case #%lld: %d\n",i+1,c);
     }
     getch();
 }
        

