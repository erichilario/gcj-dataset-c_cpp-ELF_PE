//
 //  main.c
 //  Tic-Tac-Toe-Tomek－4
 //
 //  Created by zhangchi on 13-4-13.
 //  Copyright (c) 2013年 zhangchi. All rights reserved.
 //
 
 #include <stdio.h>
 
 int main(int argc, const char * argv[])
 {
     int n,i,q,m;
     char a[16],b[5],k;
 	FILE* p;
 	FILE* t;
     
 	p=fopen("A-large.in","r");
 	t=fopen("out.txt","w");
     fscanf(p,"%d",&n);
     fgetc(p);
     m=n;
     while(n--)
     {
         //input
         q=0;
         for(i=0;i<16;i++)
         {
             a[i]=fgetc(p);
             if(!q&&a[i]=='.') q=1;
             if(a[i]=='\n') i--;
            // printf("%c",a[i]);
         }
         fgetc(p);
         if(fgetc(p)==' ') fgets(b,5,p);
         
         //1,1-1,4
         if((a[0]==a[3]||a[0]=='T'||a[3]=='T')&&a[0]!='.'&&a[3]!='.')
         {
             if(a[0]=='T')  k=a[3];
             else k=a[0];
             if(a[1]==k||a[1]=='T')
             {
                 if(a[2]==k||a[2]=='T')
                 {
                     fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         //1,1-4,1
         if((a[0]==a[12]||a[0]=='T'||a[12]=='T')&&a[0]!='.'&&a[12]!='.')
         {
             if(a[0]=='T')  k=a[12];
             else k=a[0];
             if(a[4]==k||a[4]=='T')
             {
                 if(a[8]==k||a[8]=='T')
                 {
                     fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         //1,1-4,4
         if((a[0]==a[15]||a[0]=='T'||a[15]=='T')&&a[0]!='.'&&a[15]!='.')
         {
             if(a[0]=='T')  k=a[15];
             else k=a[0];
             if(a[5]==k||a[5]=='T')
             {
                 if(a[10]==k||a[10]=='T')
                 {
                     fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         //1,2-4,2
         if((a[1]==a[13]||a[1]=='T'||a[13]=='T')&&a[1]!='.'&&a[13]!='.')
         {
             if(a[1]=='T')  k=a[13];
             else k=a[1];
             if(a[5]==k||a[5]=='T')
             {
                 if(a[9]==k||a[9]=='T')
                 {
                     fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         //1,3-4,3
         if((a[2]==a[14]||a[2]=='T'||a[14]=='T')&&a[2]!='.'&&a[14]!='.')
         {
             if(a[2]=='T')  k=a[14];
             else k=a[2];
             if(a[6]==k||a[6]=='T')
             {
                 if(a[10]==k||a[10]=='T')
                 {
                     fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         //1,4-4,1
         if((a[3]==a[12]||a[3]=='T'||a[12]=='T')&&a[12]!='.'&&a[3]!='.')
         {
             if(a[3]=='T')  k=a[12];
             else k=a[3];
             if(a[6]==k||a[6]=='T')
             {
                 if(a[9]==k||a[9]=='T')
                 {
                     fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         //1,4-4,4
         if((a[3]==a[15]||a[15]=='T'||a[3]=='T')&&a[15]!='.'&&a[3]!='.')
         {
             if(a[3]=='T')  k=a[15];
             else k=a[3];
             if(a[7]==k||a[7]=='T')
             {
                 if(a[11]==k||a[11]=='T')
                 {
                    fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         //2,1-2,4
         if((a[4]==a[7]||a[7]=='T'||a[4]=='T')&&a[4]!='.'&&a[7]!='.')
         {
             if(a[4]=='T')  k=a[7];
             else k=a[4];
             if(a[5]==k||a[5]=='T')
             {
                 if(a[6]==k||a[6]=='T')
                 {
                     fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         //3,1-3,4
         if((a[8]==a[11]||a[8]=='T'||a[11]=='T')&&a[8]!='.'&&a[11]!='.')
         {
             if(a[8]=='T')  k=a[11];
             else k=a[8];
             if(a[9]==k||a[9]=='T')
             {
                 if(a[10]==k||a[10]=='T')
                 {
                     fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         //4,1-4,4
         if((a[12]==a[15]||a[12]=='T'||a[15]=='T')&&a[12]!='.'&&a[15]!='.')
         {
             if(a[12]=='T')  k=a[15];
             else k=a[12];
             if(a[13]==k||a[13]=='T')
             {
                 if(a[14]==k||a[14]=='T')
                 {
                     fprintf(t,"Case #%d: %c won\n",m-n,k);continue;
                 }
             }
         }
         
         //
         if(!q) fprintf(t,"Case #%d: Draw\n",m-n);
         else fprintf(t,"Case #%d: Game has not completed\n",m-n);
     }
     return 0; 
 }
 

