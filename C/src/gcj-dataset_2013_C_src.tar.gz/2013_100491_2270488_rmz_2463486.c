#include <stdio.h>
 #include <math.h>
 
 int pchecker(int n)
 {
 
     int n1, rev = 0, rem;
     n1 = n;
     while (n > 0)
     {
         rem = n % 10;
         rev = rev * 10 + rem;
         n = n / 10;
     }
     if (n1 == rev)
     {
         return 1;
     }
     else{
         return 0;
     }
 
 }
 
 int main(void)
 
 {
     int a,b,ctr=0,i,T=0,n,tr=1,e,number;
     double result;
     char line[50],ans[8],trc[8];
 
     FILE *f,*z;
 
     f=fopen("C-small-attempt2.in","r");
     z=fopen("a2.txt","w");
 
     fgets(line,50,f);
 
     for(i=0;line[i+1]!='\0';i++)
     {
         T*=10;
 
         T+=line[i]-48;
     }
 
     while(tr<=100)
     {
         char cased[]={"Case #"};
         a=0;
         b=0;
         ctr=0;
         //printf("%d. ",tr);
         fgets(line,50,f);
         //printf("%s ",line);
 
         for(i=0;line[i]!=' ';i++)
             {
 
                 if(line[i]>=48&&line[i]<=58)
                 {
                     a*=10;
                     a+=line[i]-48;
                 }
 
             }
         i++;
 
         for(;line[i]!='\0';i++)
             {
 
                 if(line[i]>=48&&line[i]<=58)
                 {
                     b*=10;
                     b+=line[i]-48;
                 }
 
             }
 
         e=0;
         for(i=a;i<=b;i++)
             {
                 result= sqrt (i);
                 if ((result * result)== i)
                     {
                         if(pchecker(i)==1)
                             {
                                 if(pchecker(result)==1)
                                     {
                                         ctr++;
                                         }
                                 }
                         }
                 }
 
         e=0;
         if(tr<10)
             {
                 trc[e++]=48+tr;
             }
         else if(tr<100)
             {
                 trc[e++]=48+(tr/10);
                 trc[e++]=48+(tr%10);
             }
         else if(tr<1000)
             {
                 trc[e++]=48+(tr/100);
                 trc[e++]=48;
                 trc[e++]=48+(tr%10);
             }
         trc[e]='\0';
         e=0;
         if(ctr<10)
             {
                 ans[e++]=48+ctr;
             }
         else if(ctr<100)
             {
                 ans[e++]=48+(ctr/10);
                 ans[e++]=48+(ctr%10);
             }
         else if(ctr<1000)
             {
                 int abc=ctr/100,bcd=ctr/10,cde=ctr%10;
                 ans[e++]=48+(ctr/100);
                 ans[e++]=48+(ctr/10);
                 ans[e++]=48+(ctr%10);
             }
         ans[e++]='\0';
         ans[e]=3;
 
         strcat(cased,trc);
         strcat(cased,": ");
         strcat(ans,"\n");
         strcat(cased,ans);
         fputs(cased,z);
 
         puts(cased); printf("%d,%d\n",a,b);
         tr++;
     }
     fclose(f);
     fclose(z);
 }

