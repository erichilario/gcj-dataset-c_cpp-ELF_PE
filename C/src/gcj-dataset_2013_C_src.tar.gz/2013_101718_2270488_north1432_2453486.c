#include <stdio.h>
 
 main()
 {
     freopen("A-small-attempt0.in","r",stdin);
     freopen("tictacout.txt","w",stdout);
     int t,test;
     scanf("%d",&test);
     for (t=1;t<=test;t++)
     {
         printf("Case #%d: ",t);
         char board[4][5],i,j,dotcount=0;
         for (i=0;i<4;i++)
         {
             for (j=0;j<4;j++)
             {
                 scanf(" %c",&board[i][j]);
                 if (board[i][j] == '.') dotcount++;
             }
             board[i][4] = '\0';
         }
         //horizontal
         int xcount=0,ocount=0;
         for (i=0;i<4;i++)
         {
             for (j=0;j<4;j++)
             {
                 if (board[i][j] == 'X') xcount++;
                 else if (board[i][j] == 'O') ocount++;
                 else if (board[i][j] == 'T')
                 {
                     xcount++;
                     ocount++;
                 }
                 else break; // found '.'
             }
             if (xcount == 4)
             {
                 printf("X won\n");
                 goto end;
             }
             else if (ocount == 4)
             {
                 printf("O won\n");
                 goto end;
             }
             else
             {
                 xcount = 0;
                 ocount = 0;
             }
         }
         // vertical
         for (i=0;i<4;i++)
         {
             for (j=0;j<4;j++)
             {
                 if (board[j][i] == 'X') xcount++;
                 else if (board[j][i] == 'O') ocount++;
                 else if (board[j][i] == 'T')
                 {
                     xcount++;
                     ocount++;
                 }
                 else break; // found '.'
             }
             if (xcount == 4)
             {
                 printf("X won\n");
                 goto end;
             }
             else if (ocount == 4)
             {
                 printf("O won\n");
                 goto end;
             }
             else
             {
                 xcount = 0;
                 ocount = 0;
             }
         }
         // diagonal 1
         for (i=0;i<4;i++)
         {
             if (board[i][i] == 'X') xcount++;
             else if (board[i][i] == 'O') ocount++;
             else if (board[i][i] == 'T')
             {
                 xcount++;
                 ocount++;
             }
             else break;
         }
         if (xcount == 4)
         {
             printf("X won\n");
             goto end;
         }
         else if (ocount == 4)
         {
             printf("O won\n");
             goto end;
         }
         else
         {
             xcount = 0;
             ocount = 0;
         }
         // diagonal 2
         for (i=0;i<4;i++)
         {
             if (board[i][3-i] == 'X') xcount++;
             else if (board[i][3-i] == 'O') ocount++;
             else if (board[i][3-i] == 'T')
             {
                 xcount++;
                 ocount++;
             }
             else break;
         }
         if (xcount == 4)
         {
             printf("X won\n");
             goto end;
         }
         else if (ocount == 4)
         {
             printf("O won\n");
             goto end;
         }
         else
         {
             xcount = 0;
             ocount = 0;
         }
         // not any match
         if (dotcount == 0) printf("Draw\n");
         else printf("Game has not completed\n");
         end:;
     }
 }

