#include<stdio.h>
 #include<math.h>
 	int pal(int num)
 	{
            int rev=0,temp;
 	   temp = num;
 		while(temp != 0)
 		{
 			rev = rev * 10;
 			rev = rev + temp%10;
 			temp = temp / 10;
 		}
 		if(rev == num)
 		 {
 			return 1;
 		 }
 		else
 		 {
 			return 0;
 		 }
 	 }
           
 
 
 	int sqrt1(int num)
 	{
 	   int s=0,s1=0;
 	    s=(int) (sqrt(num));
            s1= pal(s);
            if(s*s == num&&s1==1) 
 		{
 		    return 1;
 		}
 		else 
 		{
 		    return 0;
 		}
 
 	}
 
 main()
 { 
 
      int a,b,c,d,e,f=0,j,i;
     FILE *fp,*fp1;
 	fp=fopen("C-small-attempt2.in","r+");
 	fp1=fopen("output4.txt","w+");
         fscanf(fp,"%d",&a);
          for(i=0;i<a;i++)
           {
 		fscanf(fp,"%d",&b);
 		fscanf(fp,"%d",&c);
 		for(j=b;j<=c;j++)
 		{              
 		  if((d=pal(j))==1 && (e=sqrt1(j))==1)
 			{        
 				f++;
                              
 			}
                          
 		}
 
                          fprintf(fp1,"Case #%d: %d\n",i+1,f);
                f=0;
 
 	}
 
 
 
 
 
 
 }

