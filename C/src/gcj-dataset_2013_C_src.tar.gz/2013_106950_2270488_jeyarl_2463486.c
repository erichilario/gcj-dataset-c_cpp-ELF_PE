#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <gmp.h>
 #define BASE 10
 
 
 int main(int argc, char *argv[]) {
   FILE *fp;
   /* char *fname = "test.in"; */
   /* char *fname = "C-small-attempt0.in"; */
   char *fname = "C-small-attempt1.in";
   int ret, prob_num, l_num, r_num;
 
   int i_count, j_count, k_count, num, digit = 0, sqrt_digit = 0, count = 0, case_num = 0;
 
   char num_string[256] = {'\0'};
   char num_sqrt_string[256] = {'\0'};
 
   fp = fopen(fname, "r");
   if (fp == NULL) {
     printf("%s FILE OPEN ERROR\n", fname);
     return -1;
   }
 
   ret=fscanf(fp, "%d", &prob_num);
 
   while ((ret=fscanf(fp, "%d %d", &l_num, &r_num))!=EOF) {
     case_num++;
     count = 0;
 
     for (i_count=l_num; i_count<=r_num; ++i_count) {
       digit = 0;
       sqrt_digit = 0;
     
       if (sqrt(i_count)==(int)sqrt(i_count)) {
         sprintf(num_string, "%d", i_count);
         sprintf(num_sqrt_string, "%d", (int)sqrt(i_count));
 
         num = i_count;
         while (num > 0) {
           digit++;
           num /= 10;
         }
 
         num = (int)sqrt(i_count);
         while (num > 0) {
           sqrt_digit++;
           num /= 10;
         }
 
         int flag = 1;
 
         for (j_count=0; j_count<digit/2; ++j_count) {
           if (num_string[j_count]!=num_string[digit-j_count-1]) {
             flag = 0;
             continue;
           }
         }
 
         for (k_count=0; k_count<sqrt_digit/2; ++k_count) {
           if (num_sqrt_string[k_count]!=num_sqrt_string[sqrt_digit-k_count-1]) {
             flag = 0;
             continue;
           }
         }
 
         if (flag) {
           count++;
           /* printf("%d, %d\n", i_count, (int)sqrt(i_count)); */
         }
       }
     }
 
     printf("Case #%d: %d\n", case_num, count);
   }
 
   fclose( fp );
 
   return 0;
 }

