#include<stdio.h>
 void main()
 {
 	int T,N,M,a[100][100],i,j,k,l,m,p,q,r;
     char skip[100];FILE *ptr;
       ptr=fopen("B-large-attempt0.txt","r");
   fscanf (ptr, "%d", &T); 
   fgets(skip,5,ptr);
  	freopen("output.txt","w",stdout);
 	for(i=1;i<=T;i++)
 	{ r=1;
 
 	  fscanf(ptr,"%d %d",&N,&M);
 		for(j=0;j<N;j++)
 		{ 
           fgets(skip,101,ptr);      
 			for(k=0;k<M;k++)
 			{
                        
 				fscanf(ptr,"%d",&a[j][k]);
 			}
 		}
 		
 		
 		for(j=0;j<N;j++)
 		{
 			for(k=0;k<M;k++)
 			{  p=1,q=1;
 			   for(l=0;l<M;l++)
 		       {
 		       	   if(a[j][l]>a[j][k])
 		       	   {p=0;break;}
 		       }
 			   for(m=0;m<N;m++)
 		       {
 				    if(a[m][k]>a[j][k])
 					{q=0;break;}
 			   }
 			   if(p==0&&q==0)
 			   {
 			   	  r=0;
 				  break;  
 			   }	           
 			}
 			if(r==0)	
 			break;
 		}
 		if(r==0)
 		printf("Case #%d: NO\n",i);
 		else
 		printf("Case #%d: YES\n",i);
 		
 	}
 return 0;	
 }

