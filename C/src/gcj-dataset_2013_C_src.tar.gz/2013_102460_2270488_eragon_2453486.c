#include <stdio.h>
 
 int main() {
 
 	int T;
 	int A[4][4];
 	int status;
 	int i,j;
 	char str[6];
 	int n=0;
 	int k,m;
 	int d1,d2;
 
 	scanf("%d\n",&T);
 	while (n++ < T) {
 		
 		int complete = 1;
 		char tmp;
 	
 
 		for (i = 0; i<4; i++) {
 			scanf("%s",str);
 			for (j=0;j<4;j++) {
 				tmp=str[j];
 				if (tmp == '.') {
 					complete = 0;
 					A[i][j] = 0;
 				} else if (tmp == 'X') {
 					A[i][j] = 1;
 				} else if (tmp == 'O') {
 					A[i][j] = 2;
 				} else if (tmp == 'T') {
 					A[i][j] = 3;
 				} else {
 					//j--;
 					//continue;
 				}
 			}
 		}
 
 		for (i=0; i<4; i++) {
 			status = 0;
 			k = A[i][0] & A[i][1] & A[i][2] & A[i][3];
 			m = A[0][i] & A[1][i] & A[2][i] & A[3][i];
 			if (k == 1 || m == 1) {
 				printf("Case #%d: X won\n",n);
 				status = 1;
 				break;
 			} else if (k == 2 || m == 2) {
 				printf("Case #%d: O won\n",n);
 				status = 1;
 				break;
 			}
 		}
 
 		if (!status) {
 			d1 = A[0][0] & A[1][1] & A[2][2] & A[3][3];
 			d2 = A[3][0] & A[2][1] & A[1][2] & A[0][3];
 			if (d1 == 1 || d2 == 1) {
 				printf("Case #%d: X won\n",n);
 				status = 1;
 			} else if (d1 == 2 || d2 == 2) {
 				printf("Case #%d: O won\n",n);
 				status = 1;
 			} else if (complete) {
 				printf("Case #%d: Draw\n",n);
 			} else {
 				printf("Case #%d: Game has not completed\n",n);
 			}
 		}
 
 		scanf("%c",&tmp);
 
 	}
 
 }

