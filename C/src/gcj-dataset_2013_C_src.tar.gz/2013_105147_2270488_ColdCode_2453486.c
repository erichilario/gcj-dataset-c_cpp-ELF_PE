#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define quit(n) { \
     printf("%s:%d exiting\n", __func__, __LINE__); \
     exit(n); \
 }
 
 void
 readLine(FILE *f, char *line)
 {
     if (fgets(line, 80, f) == NULL) {
         quit(1);
     }
     // printf("%s\n", line);
 }
 
 void
 readNumber(FILE *f, int *num)
 {
     char line[80];
 
     readLine(f, line);
     sscanf(line, "%d", num);
 }
 
 void readMatrix(FILE *f, char *m)
 {
     int i;
     char line[80];
     size_t len;
 
     for (i = 0; i < 4; i++) {
         readLine(f, line);
         memcpy(&m[4 * i], line, 4);
     }
     m[4 * 4] = 0;
     readLine(f, line);
 }
 
 char
 try(char *m, char c)
 {
     int i, j;
     char state;
     char possible = 'F';
     char mm;
 
     /* rows */
     for (i = 0; i < 4; i++) {
         state = c;
         for (j = 0; j < 4; j++) {
             mm = m[i * 4 + j];
             if (mm != c && mm != 'T' && mm != '.') {
                 break;
             }
             if (mm == '.') {
                 state = 'I';
             }
         }
         if (j == 4 && state != 'I') {
             return state; // bingo
         } else if (j == 4 && state == 'I') {
             possible = 'I'; // possible
         }
     }
 
     /* columns */
     for (i = 0; i < 4; i++) {
         state = c;
         for (j = 0; j < 4; j++) {
             mm = m[i + 4 * j];
             if (mm != c && mm != 'T' && mm != '.') {
                 break;
             }
             if (mm == '.') {
                 state = 'I';
             }
         }
         if (j == 4 && state != 'I') {
             return state; // bingo
         } else if (j == 4 && state == 'I') {
             possible = 'I'; // possible
         }
     }
 
     /* diagonals */
     state = c;
     for (i = 0, j = 0; i < 4; i++, j++) {
         mm = m[i + 4 * j];
         if (mm != c && mm != 'T' && mm != '.') {
             break;
         }
         if (mm == '.') {
             state = 'I';
         }
     }
     if (i == 4 && state != 'I') {
         return state; // bingo
     } else if (i == 4 && state == 'I') {
         possible = 'I'; // possible
     }
 
     state = c;
     for (i = 0, j = 3; i < 4; i++, j--) {
         mm = m[i + 4 * j];
         if (mm != c && mm != 'T' && mm != '.') {
             break;
         }
         if (mm == '.') {
             state = 'I';
         }
     }
     if (i == 4 && state != 'I') {
         return state; // bingo
     } else if (i == 4 && state == 'I') {
         possible = 'I'; // possible
     }
 
     return possible;
 }
 
 char 
 trial(char *m)
 {
     /* algo */
     char state = 'I';
     char x = try(m, 'X');
     char o = try(m, 'O');
 
     if (x == 'X' && o == 'O') {
         state = 'D';
     } else if ((x == 'I' || x == 'F') && o == 'O') {
         state = 'O';
     } else if (x == 'X' && (o == 'I' || o == 'F')) {
         state = 'X';
     } else if (x == 'I' && o == 'I') {
         state = 'I';
     } else if (x == 'F' && o == 'F') {
         state = 'D';
     }
 
     return state;
 }
 
 void
 main(int argc, char **argv)
 {
     FILE *infile;
     int caseNum, i;
     char matrix[100];
 
     if (argc > 1) {
         infile = fopen(argv[1], "r");
         if (infile == NULL) {
             quit(1);
         }
     } else {
         infile = stdin;
     }
     readNumber(infile, &caseNum);
     for (i = 0; i < caseNum; i++) {
         readMatrix(infile, matrix);
         switch(trial(matrix)) {
         case 'X':
             printf("Case #%d: X won\n", i + 1);
             break;
         case 'O':
             printf("Case #%d: O won\n", i + 1);
             break;
         case 'D':
             printf("Case #%d: Draw\n", i + 1);
             break;
         case 'I':
             printf("Case #%d: Game has not completed\n", i + 1);
             break;
         }
     }
 }

