#include<stdio.h>
 int main(){
     int t,T;
     int a,b;
     int loe;
     scanf("%i\n",&T);
  //   printf("%i\n",T);
     for(t=1;t<=T;t++){
         loe=0;
         scanf("%i %i\n",&a,&b);
         //printf("%i\n",t);
         if(a<=1)loe++;
         if(a<=4 && b>=4)loe++;
         if(a<=9 && b>=9)loe++;
         if(a<=121 && b>=121)loe++;
         if(a<=484 && b>=484)loe++;
         printf("Case #%i: %i\n",t,loe);
 
     }
 }

