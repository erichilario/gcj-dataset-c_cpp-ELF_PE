#include<stdio.h>
 
 int row, column;
 int results[100][100];
 int lawn[100][100];
 
 void travel(int i, int j, int direction, int current);
 
 int main(void) {	
 	int k, i, j;
 	int case_cnt;
 	int max_height;
 	int success = 0;
 	int height = 0;
 
 	scanf("%d", &case_cnt);
 
 	for(k = 0; k < case_cnt; ++k) {
 		scanf("%d", &row);
 		scanf("%d", &column);
 
 		success = 1;
 		max_height = 0;
 		height = 1;
 
 		for(i = 0; i < row; ++i) {		
 			memset(results[i], (int)NULL, column*4);
 		}
 
 		for(i = 0; i < row; ++i) {
 			for(j = 0; j < column; ++j) {
 				scanf("%d", lawn[i] + j);
 				if(lawn[i][j] > max_height) {
 					max_height = lawn[i][j];
 				}	
 			}
 		}
 
 		for(height = max_height; height >= 1; height--) {
 			for(i = 0; i < row; ++i) {
 				if(lawn[i][0] <= height)
 					travel(i, 0, 3, height);
 			}
 
 			for(i = 0; i < column; ++i) {
 				if(lawn[0][i] <= height)
 					travel(0, i, 1, height);
 			}
 		}
 		
 		for(i = 0; i < row; ++i) {
 			for(j = 0; j < column; ++j) {
 				if(!results[i][j]) {
 					success = 0;
 					break;
 				}
 				// printf("%d ", results[i][j]);
 			}
 			// printf("\n");
 		}
 
 		if(success) { 
 			printf("Case #%d: YES\n" , k+1);
 		} else {
 			printf("Case #%d: NO\n", k+1);
 		}
 	}
 	return 0;
 }
 
 void travel(int i, int j, int direction, int current) {
 	int k = 0;
 
 	if(direction == 1) {
 		for(k = 0; k < row; ++k) {
 			if(current < lawn[k][j]) {
 				return;
 			}
 		}
 		
 		for(k = 0; k < row; ++k) {
 			if(lawn[k][j] == current)
 				results[k][j] = 1;
 		}
 	} else {
 		for(k = 0; k < column; ++k) {
 			if(current < lawn[i][k]) {
 				return;
 			}
 		}
 		
 		for(k = 0; k < column; ++k) {
 			if(lawn[i][k] == current)
 				results[i][k] = 1;
 		}
 	}
 }
