#include <stdio.h>
 #include <stdlib.h>
 
 
 FILE *out;
 char ar[4][5],ch;
 char check();
 void print();
 
 int main()
 {
     FILE *fp;
     int num,i,times;
 
     out=fopen("out","w");
     fp=fopen("A-small-attempt0.in","r");
     fscanf(fp,"%d",&num);
     for(times=0;times<num;times++)
     {
         for (i=0;i<4;i++)
         fscanf(fp,"%s",ar[i]);
         fgetc(fp);
     ch=check();
     print();
     }
     fclose(fp);
     fclose(out);
     system("PAUSE");
     return 0;
 }
 
 
 char check()
 {
     int i,j;
     for(i=0;i<4;i++)
     {
         if((ar[i][0]=='X' || ar[i][0]=='T') && (ar[i][1]=='X' || ar[i][1]=='T') && (ar[i][2]=='X' || ar[i][2]=='T') && (ar[i][3]=='X' || ar[i][3]=='T'))
             return 'X';
         else if ((ar[i][0]=='O' || ar[i][0]=='T') && (ar[i][1]=='O' || ar[i][1]=='T') && (ar[i][2]=='O' || ar[i][2]=='T') && (ar[i][3]=='O' || ar[i][3]=='T'))
             return 'O';
         else if((ar[0][i]=='X' || ar[0][i]=='T') && (ar[1][i]=='X' || ar[1][i]=='T') && (ar[2][i]=='X' || ar[2][i]=='T') && (ar[3][i]=='X' || ar[3][i]=='T'))
             return 'X';
         else if((ar[0][i]=='O' || ar[0][i]=='T') && (ar[1][i]=='O' || ar[1][i]=='T') && (ar[2][i]=='O' || ar[2][i]=='T') && (ar[3][i]=='O' || ar[3][i]=='T'))
             return 'O';
     }
     if((ar[0][0]=='X' || ar[0][0]=='T') && (ar[1][1]=='X' || ar[1][1]=='T') && (ar[2][2]=='X' || ar[2][2]=='T') && (ar[3][3]=='X' || ar[3][3]=='T'))
             return 'X';
     if((ar[0][0]=='O' || ar[0][0]=='T') && (ar[1][1]=='O' || ar[1][1]=='T') && (ar[2][2]=='O' || ar[2][2]=='T') && (ar[3][3]=='O' || ar[3][3]=='T'))
             return 'O';
     if((ar[0][3]=='X' || ar[0][3]=='T') && (ar[1][2]=='X' || ar[1][2]=='T') && (ar[2][1]=='X' || ar[2][1]=='T') && (ar[3][0]=='X' || ar[3][0]=='T'))
             return 'X';
     if((ar[0][3]=='O' || ar[0][3]=='T') && (ar[1][2]=='O' || ar[1][2]=='T') && (ar[2][1]=='O' || ar[2][1]=='T') && (ar[3][0]=='O' || ar[3][0]=='T'))
             return 'O';
     for(i=0;i<4;i++)
         {
             for(j=0;j<4;j++)
             {
                 if (ar[i][j]=='.')
                     return 'n';
             }
         }
     return 'd';
 }
 
 void print()
 {
     static int c=1;
     if (ch=='X') fprintf(out,"Case #%d: X won\n",c);
     else if (ch=='O') fprintf(out,"Case #%d: O won\n",c);
     else if(ch=='n') fprintf(out,"Case #%d: Game has not completed\n",c);
     else fprintf(out,"Case #%d: Draw\n",c);
     c++;
 }

