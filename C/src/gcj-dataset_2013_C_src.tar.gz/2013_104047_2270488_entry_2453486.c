/*Tic-Tac-Toe-Tomek*/
 #include<stdio.h>
 int main()
 {
     freopen("amol1.txt","r",stdin);
     freopen("output.txt","w",stdout);
     int h,k=1;
     scanf("%d",&h);
     while(k<=h)
     {   char a[4][4],c1;
         int i=0,j=0,count=0,count1=0,c;
         for(i=0;i<=3;i++)
             scanf("%s",&a[i]);
         for(i=0;i<4;i++)
         {   for(j=0;j<4;j++)
             {   if(a[i][j]=='.')
                     count++;
             }
         }
         c=1;
         for(i=0;i<4;i++)
         {   count1=0;
             //printf("*\n");
             if(a[i][0]!='T')
                 c1=a[i][0];
             else
                 c1=a[i][1];
             //printf("c1=%c\n",c1);
             for(j=1;j<4;j++)
             {   if((a[i][j]==c1||a[i][j]=='T')&&a[i][j]!='.')
                     count1++;
                 else
                     break;
                 //printf("%d\n",count1);
             }
             if(count1==3)
             {   printf("Case #%d: %c won\n",k,c1);
                 c=0;
                 k++;
                 break;
             }
         }
         //printf("*\n");
         if(c==0)
             continue;
         for(j=0;j<4;j++)
         {   count1=0;
             //printf("*\n");
             if(a[0][j]!='T')
                 c1=a[0][j];
             else
                 c1=a[1][j];
             //printf("c1=%c\n",c1);
             for(i=1;i<4;i++)
             {   if((a[i][j]==c1||a[i][j]=='T')&&a[i][j]!='.')
                     count1++;
                 else
                     break;
                // printf("%d\n",count1);
             }
             if(count1==3)
             {   printf("Case #%d: %c won\n",k,c1);
                 c=0;
                 k++;
                 break;
             }
         }
         //printf("*\n");
         if(c==0)
             continue;
         /*if(t==0)
         {   t++;
             continue;
         }*/
         if(a[0][0]!='T')
             c1=a[0][0];
         else
             c1=a[1][1];
         //printf("c1=%c\n",c1);
         count1=0;
         for(i=1;i<4;i++)
         {   if((a[i][i]==c1||a[i][i]=='T')&&a[i][i]!='.')
                 count1++;
             else
                 break;
         }
         if(count1==3)
         {   printf("Case #%d: %c won\n",k,c1);
             c=0;
             k++;
         }
         if(c==0)
             continue;
         if(a[0][3]!='T')
             c1=a[0][3];
         else
             c1=a[1][2];
         //printf("c1=%c\n",c1);
         count1=0;
         for(i=1,j=2;i<4;i++,j--)
         {   if((a[i][j]==c1||a[i][j]=='T')&&a[i][j]!='.')
                 count1++;
             else
                 break;
         }
         if(count1==3)
         {   printf("Case #%d: %c won\n",k,c1);
             c=0;
             k++;
         }
         if(c==0)
             continue;
         //printf("*\n");
         if(count>0)
             printf("Case #%d: Game has not completed\n",k);
         else
             printf("Case #%d: Draw\n",k);
         k++;
     }
     return 0;
 }

