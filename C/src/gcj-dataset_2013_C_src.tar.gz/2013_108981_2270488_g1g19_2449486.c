#include<stdio.h>
 #include<stdlib.h>
 #include<stddef.h>
 
 void lawn_check(int** A,int n,int m,int t,FILE* s);
 int row_check(int** A,int i,int j,int p,int q);
 int column_check(int** A,int i,int j,int p,int q);
 int corner_check(int** A,int n,int m);
 
 int main(void)
 {
 	int t,i,j,k,m,n,b,lk;
 	char ch;
 	int** A;
 	FILE* fp = fopen("test.txt","r");
 	FILE* f = fopen("output","w");
 	fscanf(fp,"%d",&t);
 	
 	for(i=0;i<t;i++)
 	{
 		fscanf(fp,"%d %d",&n,&m);
 		A = (int**)malloc(n*sizeof(int*));
 		for(j=0;j<n;j++)
 		{
 			A[j] = (int*)malloc(m*sizeof(int));
 			for(k=0;k<m;k++)
 			{
 				fscanf(fp,"%d",&A[j][k]);
 			}
 		}
 		
 
 		lk = corner_check(A,n,m);
 		if(lk == 0)
 		{
 			fprintf(f,"Case #%d: NO\n",i+1);
 			//printf("done\n");
 		}
 		else
 			lawn_check(A,n,m,i+1,f);
 		free(A);
 	}
 	return 0;
 }
 
 void lawn_check(int** A,int n,int m,int t,FILE* s)
 {
 	int p = n-2;
 	int q = m-2;
 	int i,j,k,a,b,c,d;
 	
 	for(i=1;i<=p;i++)
 	{
 		for(j=1;j<=q;j++)
 		{
 			a = row_check(A,i,j,p,q);
 			b = column_check(A,i,j,p,q);
 			if((a == 1) && (b == 1))
 			{
 				//fprintf(s,"i=%d j=%d\n",i,j);
 				fprintf(s,"Case #%d: NO\n",t);
 				return;
 			}
 		}
 	}
 	fprintf(s,"Case #%d: YES\n",t);
 	return;
 }
 
 int row_check(int** A,int i,int j,int p,int q)
 {
 	int w,e;
 	e = A[i][j];
 	for(w=1;w<=p;w++)
 	{
 		if(e == A[w][j])
 			continue;
 		else 
 			{
 				return 1;
 			}
 	}
 	return 0;
 }
 
 int column_check(int** A,int i,int j,int p,int q)
 {
 
 	int w,e;
 	e = A[i][j];
 	for(w=1;w<=q;w++)
 	{
 		if(e == A[i][w])
 			continue;
 		else
 			{
 				return 1;
 			}
 	}
 	return 0;
 }
 
 int corner_check(int** A,int n,int m)
 {
 	//printf("INSIDE CORNER\n");
 	if(n<2 || m<2)
 	{
 		return 1;
 	}
 	int p[4];
 	int a,b,c,d,e,f,g,h;
 	p[0] = A[0][0];
 	p[1] = A[0][m-1];
 	p[2] = A[n-1][m-1];
 	p[3] = A[n-1][0];
 	//printf("hello1\n");
 	a = A[0][1];
 	b = A[1][0];
 	//printf("hello2\n");
 	c = A[0][m-2];
 	d = A[1][m-1];
 	//printf("hello3\n");
 	e = A[n-2][m-1];
 	f = A[n-1][m-2];
 	//printf("hello4\n");
 	g = A[n-2][0];
 	h = A[n-1][1];
 	//printf("hello5\n");
 
 	if((p[0]>=a)&& (p[0]>=b))
 	{
 		//printf("hello6\n");
 		if((p[1]>=c)&& (p[1]>=d))
 		{
 			//printf("hello7\n");
 			if((p[2]>=e)&& (p[2]>=f))
 			{
 				//printf("hello8\n");
 				if((p[3]>=g)&& (p[3]>=h))
 				{
 					//printf("hello9\n");
 					return 1;
 				}
 			}
 		}
 	} 
 	return 0;
 }
