
 #include<stdio.h>
 
 
 int lawn [100][100];
 
 
 int maxrow(int max,int i,int m,int n)
 { 
    int k;
     
     for(k=0;k<n;k++)
     {
       if(max<lawn[i][k])
       return 0;
     }
   return 1;
 }                  
 
 
 int maxcol(int max,int j,int m,int n)
 { 
    int k;
     
     for(k=0;k<m;k++)
     {
       if(max<lawn[k][j])
       return 0;
     }
   return 1;
 }  
 
 
 void main ()
 
 { 
       int T,t,i,j,c1,c2,run,m,n;
     FILE *fp=fopen("output.txt","w+");
 
      scanf("%d",&T);
      
     for(t=1;t<=T;t++)
     {
          scanf("%d %d",&m,&n);
              
          for(i=0;i<m;i++)
           for(j=0;j<n;j++)
             scanf("%d",&lawn[i][j]);
           
           run=1;
             
         for(i=0;i<m;i++)
          {
               c1=0;
               c2=0;
               
                    
                     for(j=0;j<n;j++)
           {
              c1=maxrow(lawn[i][j],i,m,n);
               c2=maxcol(lawn[i][j],j,m,n);
               
               if(c1||c2)
               ;
               else
               { fprintf(fp,"Case #%d: NO\n",t);
                run=0;
                break;
                }
            }
            if(run==0)
            break;
       }
       if(run==1)
       fprintf(fp,"Case #%d: YES\n",t);   
      
       } 
       }
                
                   
                                       

