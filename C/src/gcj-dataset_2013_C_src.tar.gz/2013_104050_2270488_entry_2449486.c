/*Lawnmower*/
 #include<stdio.h>
 int main()
 {
     freopen("amol3.txt","r",stdin);
     freopen("output.txt","w",stdout);
     int t,count=0;
     scanf("%d",&t);
     while(t--)
     {   count++;
         int n,m,i,j,k,c=1;
         scanf("%d %d",&n,&m);
         int a[n][m],max[100]={0};
         for(i=0;i<n;i++)
         {   for(j=0;j<m;j++)
             {   scanf("%d",&a[i][j]);
                 if(a[i][j]>max[i])
                     max[i]=a[i][j];
             }
         }
         for(i=0;i<n;i++)
         {   for(j=0;j<m;j++)
             {   if(a[i][j]==max[i])
                     continue;
                 if(a[i][j]<max[i])
                 {   for(k=0;k<n;k++)
                     {   if(a[k][j]>a[i][j])
                         {   printf("Case #%d: NO\n",count);
                             c=0;
                             break;
                         }
                     }
                     if(c==0)
                         break;
                 }
             }
             if(c==0)
                 break;
         }
         if(c==0)
             continue;
         printf("Case #%d: YES\n",count);
     }
     return 0;
 }

