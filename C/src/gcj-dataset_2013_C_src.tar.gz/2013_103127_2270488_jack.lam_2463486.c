#include <stdio.h>
 #include <string.h>
 
 #define DEBUG 0
 #define NDIG  52
 
 int min[NDIG*2];
 int max[NDIG*2];
 int out[NDIG*2];
 int in[NDIG];
 int pdlen;
 
 void docarry(int len, int *v)
 {
   int i;
   int p;
   
   for ( i=0; i<len-1; i++ ) {
     p = v[i];
     v[i] = p % 10;
     v[i+1] = v[i+1] + p / 10;
   }
 }
 
 void squareab(void)
 {
   int i, j, p;
   
   for ( i=0; i<NDIG*2; i++ )
     out[i] = 0;
   
   for ( i=0; i<NDIG; i++ )
     for ( j=0; j<NDIG; j++ ) {
       out[i+j] = out[i+j] + in[j] * in[i];
       /*out[i+j] = p % 10;
       out[i+j+1] = out[i+j+1] p / 10;
       printio();*/
     }
     
   for ( i=0; i<NDIG*2-1; i++ ) {
     p = out[i];
     out[i] = p % 10;
     out[i+1] = out[i+1] + p / 10;
   }
 }
 
 void printio(void)
 {
   int i;
   
   printf("in = ");
   for ( i=0; i<NDIG; i++ )
     printf("%1d", in[i]);
   printf("  out = ");
   for ( i=0; i<NDIG*2; i++ )
     printf("%1d", out[i]);
   printf("\n");
 }
 
 int checkpalindrome(void)
 {
   int zeroi;
   int i, j;
   
   i = NDIG*2-1;
   
   while ( out[i] == 0 ) i=i-1;
   zeroi = i;
   
   j = zeroi;
   for ( i=0; i<=zeroi; i=i+1 ) {
     if ( out[i] != out[j] ) return 0;
     j = j-1;
   }
   
   return 1;
 }
 
 int checkabove(int *max)
 {
   int i = NDIG*2-1;
   
   while ( i>=0 && out[i] == max[i] ) i=i-1;
   /*
   if ( DEBUG ) {
     printf("--> checkabove : out[%d] >= max[%d] : %d >= %d :: ", i, i, out[i], max[i]);
   }*/
   
   return out[i] >= max[i];
 }
 
 int checkbelow(int *max)
 {
   int i = NDIG*2-1;
   
   while ( i>=0 && out[i] == max[i] ) i=i-1;
 
 /*
   if ( DEBUG ) {
     printf("--> checkbelow : out[%d] <= max[%d] : %d <= %d :: ", i, i, out[i], max[i]);
   }
   */
   return out[i] <= max[i];
 }
 
 int convertstr(char *str, int *v)
 {
   int i;
   int len = strlen(str);
   
   for ( i=0; i<len; i++ ) {
     v[i] = str[len-i-1] - '0';
   }
   
   return len;
 }
 
 void startpd(int len)
 {
   int i;
   
   pdlen = len;
   
   for ( i=0; i<NDIG; i++ )
     in[i] = 0;
     
   in[0] = 1;
   in[len-1] = 1;
 }
 
 void nextpd(void)
 {
   int i;
 
   in[pdlen/2]++;
   
   docarry(NDIG, in);
   
   for ( i=0; i<pdlen/2; i++ )
     in[i] = in[pdlen-1-i];
 }
 
 int donepd(void)
 {
   int i;
 
   for (i=0; i<pdlen; i++ )
     if ( in[i] != 9 ) return 0;
     
   return 1;
 }
 
 int main(void)
 {
   int T;
   int t;
   char sta[120];
   char stb[120];
   int count = 0;
   int i;
 /*
   for ( t =0; t<=NDIG*2-1;t++) {
     out[t] = 0;
     max[t] = 0;
     min[t] = 0;
   }
     
   out[0] = 1;
   out[1] = 3;
   out[2] = 3;
   out[3] = 1;
 
   printio();  
   printf("checkpalindrome: %d\n", checkpalindrome());
 
  
   scanf("%s %s", sta, stb);
   convertstr(sta, min);
   convertstr(stb, max);
   
   if ( DEBUG ) {
     printf("min : ");
     for (t=0; t<NDIG*2; t++) {
       printf("%1d",min[t]);
     }
     printf("\nmax : ");
     for (t=0; t<NDIG*2; t++) {
       printf("%1d",max[t]);
     }
     printf("\n");
   }
   
   printf("length = %d\n", T);
     
   for ( t=1; t<=5; t++  ) {
   startpd(t);
   squareab();
   if ( checkabove(min) ) printf("above(min) : ");
   if ( checkbelow(max) ) printf("below(max) : ");
   printio();
   while ( !donepd() ) {
     nextpd();
     squareab();
     if ( checkabove(min) ) printf("above(min) : ");
     if ( checkbelow(max) ) printf("below(max) : ");
     printio();
   }
   }
   
   return 0;
   
 */
   
   scanf("%d", &T);
   
   for ( t=1; t<=T; t++ ) {
   
     for ( i =0; i<=NDIG*2-1;i++) {
       out[i] = 0;
       max[i] = 0;
       min[i] = 0;
     }
     
     scanf("%s %s", sta, stb);
     convertstr(sta, min);
     convertstr(stb, max);
     
     count = 0;
 
   for ( i=1; i<=5; i++  ) {
     startpd(i);
     squareab();
     if ( checkabove(min) && checkbelow(max) ) {
       if ( checkpalindrome() ) count++;
       if ( DEBUG ) {
         printf("in range [%d] : ", count);
         printio();
       }
     }
     while ( !donepd() ) {
       nextpd();
       squareab();
       if ( checkabove(min) && checkbelow(max) ) {
         if ( checkpalindrome() ) count++;
         if ( DEBUG ) {
           printf("in range [%d] : ", count);
           printio();
         }
       }
       if ( !checkbelow(max) ) break;
     }
     if ( !checkbelow(max) ) break;
   }
   
   printf("Case #%d: %d\n",t, count);
   
   }
 
   return 0;
 }

