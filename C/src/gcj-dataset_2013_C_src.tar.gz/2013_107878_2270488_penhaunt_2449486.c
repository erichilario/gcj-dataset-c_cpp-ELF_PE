//Problem B. Lawnmower
 #include<stdio.h>
 int rechable(int **a,int N,int M,int x,int y)
 {
     int i,j,flag=0;
     int pivot = *(a+x*M+y);
     //horizontal
     for(i=0;i<M;i++)
     {
         if(*(a+x*M+i)<pivot) flag=1;
     }
     if(!flag) return 1;
     flag=0;
     // vertical
     for(i=0;i<N;i++)
     {
         if(*(a+i*M+y)<pivot) flag=1;
     }
     if(!flag) return 1;
 
     return 0;
 }
 int main()
 {
     FILE *fp = fopen("B-large.in","r");
     FILE *fout = fopen("output.txt","w");
     int t,i;
     fscanf(fp,"%d",&t);
     for(i=1;i<=t;i++)
     {
         int M,N,j,k;
         fscanf(fp,"%d %d",&N,&M);
         int a[N][M];
         for(j=0;j<N;j++)
         {
             for(k=0;k<M;k++)
             {
                 fscanf(fp,"%d",&a[j][k]);
             }
         }
         // solution
         int flag=0;
         for(j=0;j<N&& !flag;j++)
         {
             for(k=0;k<M && !flag;k++)
             {
                 if(a[j][k]==1 )
                 {
                     int ans = rechable(a,N,M,j,k);
                     if(!ans) flag=1;
                 }
             }
         }
         if(flag) fprintf(fout,"Case #%d: NO\n",i);
         else fprintf(fout,"Case #%d: YES\n",i);
     }
 }

