#include<string.h>
 #include<stdio.h>
 #include<stdbool.h>
 int main (){
     int T,i,j,T2;
     char **str;
     scanf("%d",&T);
     T2=T;
     str=malloc(4*sizeof(char *));
     for(i=0;i<4;i++){
         str[i]=malloc(sizeof(char)*4);
     }
     
     bool xflag=0;
     bool oflag=0;
     bool dflag=0;
     bool result=0;
     bool Dflag=0;
     while(T>0){
         for(i=0;i<4;i++){
                 scanf("%s",str[i]);
         }
         for(i=0;i<4&&result==0;i++){
             bool xflag=0;
             bool oflag=0;
             bool dflag=0;
             for(j=0;j<4&&(dflag==0);j++){
                 switch( str[i][j] ) 
                 {
                     case 'X':
                         xflag=1;
                         break;
                     case 'O':
                         oflag=1;
                         break;
                     case 'T':
                         
                         break;
                     case '.':
                         dflag=1;
                         Dflag=1;
                         break;
                 }    
             }
             if(dflag==0){
                 if(!(xflag==1 && oflag==1)){
                     if(xflag){
                         printf("Case #%d: X won\n",T2-T+1);
                         result=1;
                     } else if (oflag) {
                         printf("Case #%d: O won\n",T2-T+1);
                         result=1;
                     }
                 }
              }
         }
         
         //////////////////////////
         
         for(i=0;i<4&&(result==0);i++){
             bool xflag=0;
             bool oflag=0;
             bool dflag=0;
             for(j=0;j<4&&(!(((xflag==1)&&(oflag==1)) || (dflag==1)));j++){
                 switch( str[j][i] ) 
                 {
                     case 'X':
                         xflag=1;
                         break;
                     case 'O':
                         oflag=1;
                         break;
                     case 'T':
                         
                         break;
                     case '.':
                         dflag=1;
                         break;
                 }    
             }
             if(dflag==0){
                 if(!(xflag==1 && oflag==1)){
                     if(xflag){
                         printf("Case #%d: X won\n",T2-T+1);
                         result=1;
                     } else if (oflag) {
                         printf("Case #%d: O won\n",T2-T+1);
                         result=1;
                     }
                 }
              }
         }
         
         ///////////////////
         
         if(result==0){
         bool xflag=0;
         bool oflag=0;
         bool dflag=0;
         for(i=0;i<4;i++){      
                 switch( str[i][i] ) 
                 {
                     case 'X':
                         xflag=1;
                         break;
                     case 'O':
                         oflag=1;
                         break;
                     case 'T':
                         
                         break;
                     case '.':
                         dflag=1;
                         break;
                 }    
             }
             if(dflag==0){
                 if(!(xflag==1 && oflag==1)){
                     if(xflag){
                         printf("Case #%d: X won\n",T2-T+1);
                         result=1;
                     } else if (oflag) {
                         printf("Case #%d: O won\n",T2-T+1);
                         result=1;
                     }
                 }
              }
     }
              
              //////////////
     if(result==0) {  
             bool xflag=0;
         bool oflag=0;
         bool dflag=0;
         for(i=0;i<4;i++){      
                 switch( str[i][3-i] ) 
                 {
                     case 'X':
                         xflag=1;
                         break;
                     case 'O':
                         oflag=1;
                         break;
                     case 'T':
                         
                         break;
                     case '.':
                         dflag=1;
                         break;
                 }    
             }
             if(dflag==0){
                 if(!(xflag==1 && oflag==1)){
                     if(xflag){
                         printf("Case #%d: X won\n",T2-T+1);
                         result=1;
                     } else if (oflag) {
                         printf("Case #%d: O won\n",T2-T+1);
                         result=1;
                     }
                 }
              }
         }           
         
         if(result==0) {
             if(Dflag){
                 printf("Case #%d: Game has not completed\n",T2-T+1);
             } else {
                 printf("Case #%d: Draw\n",T2-T+1);
             }
         }
         result=0;
         Dflag=0;
         
         T--;
     }
     
   return 0;
 
 }
