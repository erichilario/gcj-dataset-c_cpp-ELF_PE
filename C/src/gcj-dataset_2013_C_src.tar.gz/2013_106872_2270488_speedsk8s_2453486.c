#include <stdio.h>
 #include <string.h>
 
 int check(char victory_string[5]) {
   char *T;
   if(NULL != strchr(victory_string, '.')) return 0;
   if(NULL != (T = strchr(victory_string, 'T'))) {
     if(T == victory_string) *T = *(T+1);
     else *T = *(T-1);
   }
 
   if(victory_string[0] == victory_string[1]
      && victory_string[0] == victory_string[2] 
      && victory_string[0] == victory_string[3])
     return victory_string[0] == 'X' ? 1 : 2;
   return -1;
 }
 
 int checkTable(char table[][5]) {
   int i;
   char victory_string[5];
   int empty_cells = 0;
   int result;
 
   // Check horizontal wins
   for(i=0; i<4; i++) {
     result = check(table[i]);
     if(result > 0) return result;
     else if (result == 0) empty_cells++;
   }
 
   // Check vertical wins
   for(i=0; i<4; i++) {
     victory_string[0] = table[0][i];
     victory_string[1] = table[1][i];
     victory_string[2] = table[2][i];
     victory_string[3] = table[3][i];
     victory_string[4] = '\0';
     result = check(victory_string);
     if(result > 0) return result;
     else if (result == 0) empty_cells++;
   }
 
   // Check diagonal wins
   victory_string[0] = table[0][0];
   victory_string[1] = table[1][1];
   victory_string[2] = table[2][2];
   victory_string[3] = table[3][3];
   victory_string[4] = '\0';
   result = check(victory_string);
   if(result > 0) return result;
   else if (result == 0) empty_cells++;
 
   victory_string[0] = table[0][3];
   victory_string[1] = table[1][2];
   victory_string[2] = table[2][1];
   victory_string[3] = table[3][0];
   victory_string[4] = '\0';
   result = check(victory_string);
   if(result > 0) return result;
   else if (result == 0) empty_cells++;
 
   // Check empty cells for draw
   if(empty_cells == 0) return 0;
 
   // If not then the game must be incomplete
   return 3;
 }
 
 int main(void) {
   int nb_test_cases, i;
   int test_counter = 1;
   char table[4][5];
 
   scanf("%d\n", &nb_test_cases);
   while (nb_test_cases - test_counter >= 0) {
     for(i=0;i<4;i++) {
       scanf("%s\n", &table[i][0]);
     }
     scanf("\n");
     
     printf("Case #%d: ", test_counter);
     switch(checkTable(table)) {
       case 0:
         printf("Draw");
         break;
       case 1:
         printf("X won");
         break;
       case 2:
         printf("O won");
         break;
       default:
         printf("Game has not completed");
     }
     printf("\n");
 
     test_counter++;
   }
   return 0;
 }

