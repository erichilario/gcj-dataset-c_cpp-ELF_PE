#include <stdio.h>
 #include <stdint.h>
 #include <stdbool.h>
 
 typedef enum {
    Res_X_Won,
    Res_O_Won,
    Res_Draw,
    Res_Incomplete,
    Res_Error,
 } Result_e;
 
 const char* k_pcResultText[] = {
    "X won",
    "O won",
    "Draw",
    "Game has not completed",
    "Erroneous input"};
 
 #define DIAG_ROW_MASK1 0x8421
 #define DIAG_ROW_MASK2 0x1248
 
 static bool s_bWinner(uint32_t u32)
 {
 //x   printf("Check %04x\n", u32);
    
    if (__builtin_popcount(u32 & DIAG_ROW_MASK1) == 4 ||
        __builtin_popcount(u32 & DIAG_ROW_MASK2) == 4)
    {
       return true;
    }
 
    if ((u32 & 0x000f) == 0xf ||
        (u32 & 0x00f0) == 0xf0 ||
        (u32 & 0x0f00) == 0x0f00 ||
        (u32 & 0xf000) == 0xf000 ||
        (u32 & 0x1111) == 0x1111 ||
        (u32 & 0x2222) == 0x2222 ||
        (u32 & 0x4444) == 0x4444 ||
        (u32 & 0x8888) == 0x8888)
    {
       return true;
    }
    
    return false;
 }
 
 static Result_e s_eSolve(char ppcLines[4][5])
 {
    uint32_t u32X = 0;
    uint32_t u32O = 0;
    uint32_t u32E = 0;
    
    for (int row = 0; row < 4; ++row)
    {
       for (int col = 0; col < 4; ++col)
       {
 //x         printf("%c %d,%d - %x\n", ppcLines[row][col], row, col, (1<<(row*4 + col)));
          
          switch(ppcLines[row][col])
          {
          case 'X':
             u32X |= (1<<(row*4 + col));
             break;
          case 'O':
             u32O |= (1<<(row*4 + col));
             break;
          case 'T':
             u32X |= (1<<(row*4 + col));
             u32O |= (1<<(row*4 + col));
             break;
          case '.':
             u32E |= (1<<(row*4 + col));
             break;
          default:
             return Res_Error;
          }
       }
    }
 
    Result_e eRes = Res_Incomplete;
    
    // Elliminate incomplete
    if (__builtin_popcount(u32X) > 3)
    {
       eRes = s_bWinner(u32X) ? Res_X_Won : Res_Draw;
    }
 
    if (__builtin_popcount(u32O) > 3)
    {
       eRes = s_bWinner(u32O) ? Res_O_Won : eRes;
    }
 
    if (eRes > Res_O_Won && __builtin_popcount(u32E))
    {
       eRes = Res_Incomplete;
    }
    
    return eRes;
 }
 
 int main(int argc, char *argv[])
 {
    uint16_t u16Cases;
 
    scanf("%hu", &u16Cases);
 
    for (int i = 0; i < u16Cases; ++i)
    {
       char acLines[4][5];
 
       for (int line=0; line < 4; ++line)
       {
          scanf("%s", acLines[line]);
       }
 
       Result_e eRes = s_eSolve(acLines);
 
       printf("Case #%d: %s\n", i + 1, k_pcResultText[eRes]);
    }
 
    return 0;
 }

