#include <stdio.h>
 #include <math.h>
 #include <stdbool.h>
 
 bool IsPalindrome(long long value) {
     long long tmp = 0, origin_value = value;
     while (value > 0) {
         tmp *= 10;
         tmp += value % 10;
         value /= 10;
     }
     return origin_value == tmp;
 }
 
 bool IsSquare(long long value) {
     long long root = (long long)sqrt(value);
     if (root * root == value) {
         if (IsPalindrome(root)) {
             return true;
         }
     }
     return false;
 }
 
 void Output(int index, long long result) {
     printf("Case #%d: %lld\n", index, result);
 }
 
 int main() {
     freopen("C-small-attempt0.in", "r", stdin);
     freopen("C-small-attempt0.out", "w", stdout);
     int T, index, digit;
     long long A, B, i, count;
     scanf("%d", &T);
     for (index = 1; index <= T; ++index) {
         scanf("%lld %lld", &A, &B);
         count = 0;
         for (i = A; i <= B; ++i) {
             digit = i % 10;
             if (digit == 1 || digit == 4 || digit == 5 || digit == 6 || digit == 9)
                 if (IsPalindrome(i) && IsSquare(i))
                     ++count;
         }
         Output(index, count);
     }
     fclose(stdout);
     fclose(stdin);
 }

