#include <stdio.h>
 #define N 4
 
 char map[N][N+2];
 
 int run(int x, int y, int dx, int dy) {
   int p,i;
   p=0;
   for(i=0;i<N;i++) if(map[y+i*dy][x+i*dx]=='O' || (map[y+i*dy][x+i*dx]=='T')) p++;
   if(p==4) return 1;
   p=0;
   for(i=0;i<N;i++) if(map[y+i*dy][x+i*dx]=='X' || (map[y+i*dy][x+i*dx]=='T')) p++;
   if(p==4) return 2;
   return 0;
 }
 
 int runs() {
   int i,q,c,j,k;
   for(i=0;i<N;i++) {q=run(0,i,1,0); if(q>0) return q; }   //Testa vgrta rader
   for(i=0;i<N;i++) {q=run(i,0,0,1); if(q>0) return q; }   //Testa lodrta rader
   q=run(0,0,1,1); if(q>0) return q;                     //Testa ena diagonalen
   q=run(0,N-1,1,-1); if(q>0) return q;                  //Testa andra diagonalen
   c=0;
   for(j=0;j<4;j++) for(k=0;k<4;k++) if(map[j][k]=='.') c++;
   return (c==0) ? 3 : 0;
 }
 
     
 int main() {
   int W, i,j;
   scanf("%d", &W);
   for(i=0;i<W;i++) {
     for(j=0;j<N;j++) scanf("%s", map[j]);
     printf("Case #%d: ",i+1);
     switch(runs()) {
     case 0: printf("Game has not completed\n"); break;
     case 1: printf("O won\n"); break;
     case 2: printf("X won\n"); break;
     case 3: printf("Draw\n"); break;
     }
   }
   return 0;
 }

