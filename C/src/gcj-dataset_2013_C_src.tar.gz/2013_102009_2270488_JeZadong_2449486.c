#include <iostream>
 
 #include <fstream>
 
 #include <string>
 
 using namespace std;
 
 int lawn [100][100];
 
 int main(int argc, char *argv[])
 {
   ifstream inputFile;
   inputFile.open(argv[1]);
 
   string numOfInputStr;
   getline(inputFile, numOfInputStr);
   int numOfInput = atoi(numOfInputStr.c_str());
 
   //cout << argv[1] << endl;
   //cout << numOfInput << endl;
 
   for(int inputIndex=0; inputIndex<numOfInput; inputIndex++) {
 
     int rowCount;
     inputFile >> rowCount;
 
     int columnCount;
     inputFile >> columnCount;
 
     for(int rowIndex=0; rowIndex<rowCount; rowIndex++) {
 
       for(int columnIndex=0; columnIndex<columnCount; columnIndex++) {
 
         inputFile >> lawn[rowIndex][columnIndex];
 
       }
 
     }
 
     bool isPossible = true;
 
     for(int rowIndex=0; rowIndex<rowCount&&isPossible; rowIndex++) {
 
       if(rowIndex==0&&rowCount==1) {
         continue;
       }
 
       for(int columnIndex=0; columnIndex<columnCount&&isPossible; columnIndex++) {
 
         if(columnIndex==0&columnCount==1) {
           //cout << "Input#" << inputIndex+1 << ": " << "Skip Column" << endl;
           continue;
         }
 
         int foundHill = 0;
 
         // find hill on the right
         for(int trialColumnIndex=columnIndex; trialColumnIndex<columnCount; trialColumnIndex++) {
           if(lawn[rowIndex][columnIndex]<lawn[rowIndex][trialColumnIndex]) {
             foundHill++;
             break;
           }
         }
 
         // find hill on the left
         for(int trialColumnIndex=columnIndex; trialColumnIndex>=0; trialColumnIndex--) {
           if(lawn[rowIndex][columnIndex]<lawn[rowIndex][trialColumnIndex]) {
             foundHill++;
             break;
           }
         }
 
         // find hill on the bottom
         for(int trialRowIndex=rowIndex; trialRowIndex<rowCount; trialRowIndex++) {
           if(lawn[rowIndex][columnIndex]<lawn[trialRowIndex][columnIndex]) {
             foundHill++;
             break;
           } 
         }
 
         // find hill on the top
         for(int trialRowIndex=rowIndex; trialRowIndex>=0; trialRowIndex--) {
           if(lawn[rowIndex][columnIndex]<lawn[trialRowIndex][columnIndex]) {
             foundHill++;
             break;
           }
         }
 
         if(rowIndex==0) {
           foundHill++;
         }
 
         if(columnIndex==0) {
           foundHill++;
         }
 
         if(rowIndex==rowCount-1) {
           foundHill++;
         }
 
         if(columnIndex==columnCount-1) {
           foundHill++;
         }
 
         if(foundHill>=4) {
           isPossible = false;
         }
 
       }
 
     }
 
     if(isPossible) {
       cout << "Case #" << inputIndex+1 << ": " << "YES" << endl;
     } else {
       cout << "Case #" << inputIndex+1 << ": " << "NO" << endl;
     }
 
   }
 
   return 0;
 } 

