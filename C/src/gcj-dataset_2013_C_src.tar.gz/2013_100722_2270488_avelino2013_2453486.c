#include <stdio.h>
 
 int main()
 {
     int i, j, dot, t, aux=1, cx, co, fx, fo;
     char tic[10][10];
     scanf("%d", &t);
     while(t--)
     {
         fx=fo=dot=0;
         for(i=0; i<4; i++)
         {
             scanf("%s", tic[i]);
             cx=co=0;
             for(j=0; j<4; j++)
             {
                 if(tic[i][j]=='.') dot++;
                 if(tic[i][j]=='X' || tic[i][j]=='T') cx++;
                 if(tic[i][j]=='O' || tic[i][j]=='T') co++;
             }
             if(cx==4) fx=1;
             if(co==4) fo=1;
         }
         for(j=0; j<4; j++)
         {
             cx=co=0;
             for(i=0; i<4; i++)
             {
                 if(tic[i][j]=='X' || tic[i][j]=='T') cx++;
                 if(tic[i][j]=='O' || tic[i][j]=='T') co++;
             }
             if(cx==4) fx=1;
             if(co==4) fo=1;
         }
         cx=co=0;
         for(i=0, j=0; i<4; i++, j++)
         {
             if(tic[i][j]=='X' || tic[i][j]=='T') cx++;
             if(tic[i][j]=='O' || tic[i][j]=='T') co++;
             if(cx==4) fx=1;
             if(co==4) fo=1;
         }
         cx=co=0;
         for(i=0, j=3; i<4; i++, j--)
         {
             if(tic[i][j]=='X' || tic[i][j]=='T') cx++;
             if(tic[i][j]=='O' || tic[i][j]=='T') co++;
             if(cx==4) fx=1;
             if(co==4) fo=1;
         }
         printf("Case #%d: ", aux++);
         if(fx) printf("X won\n");
         else if(fo) printf("O won\n");
         else if(dot) printf("Game has not completed\n");
         else printf("Draw\n");
     }
     return 0;
 }

