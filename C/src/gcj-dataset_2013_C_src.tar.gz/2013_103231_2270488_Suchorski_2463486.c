#include <stdio.h>
 #include <math.h>
 #include <string.h>
 
 int palindromo(int numero) {
 	char palavra[64];
 	char *pI, *pF;
 	sprintf(palavra, "%d", numero);
 	for (pI = palavra, pF = palavra + strlen(palavra) - 1; pI <= pF; ++pI, --pF) {
 		if (*pI != *pF) {
 			return 0;
 		}
 	}
 	return 1;
 }
 
 int main(int argc, char *argv[]) {
     FILE *fr = fopen("input.txt", "r");
     FILE *fw = fopen("output.txt", "w");
     unsigned long int i, corretos, min, max, total;
     fscanf(fr, "%lu", &total);
     for (i = 0; i < total; ++i) {
 		corretos = 0;
 		fscanf(fr, "%lu %lu", &min, &max);
 		min = (int) ceil(sqrt(min));
 		max = (int) floor(sqrt(max));
 		for (; min <= max; ++min) {
 			if (palindromo(min)) {
 				if (palindromo(min * min)) {
 					++corretos;
 				}
 			}
 		}
 		fprintf(fw, "Case #%lu: %lu\n", (i + 1), corretos);
     }
     return 0;
 }

