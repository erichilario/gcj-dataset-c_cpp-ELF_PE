#include <stdio.h>
 #include <math.h>
 
 
 // return w if win in row n for not
 
 
 
 char  rowCheck ( char player, char board[4][4]);
 char  colCheck ( char player, char board[4][4]);
 char dioCheck ( char player, char board[4][4]);
 char Draw( char board[4][4]);
 char fullCheck ( char player, char board[4][4]);
 
 void printTable ( char baord[4][4]);
 
 int main ( void){
 	
 	int c, r;
 	char temp;
 	char board[4][4];
 	int numberOfBoard;
 	int currentBoard = 1;
 	scanf("%d",&numberOfBoard);
 	
 	for ( ; currentBoard <= numberOfBoard; currentBoard++){
 		
 		
 		
 		
 	
 	
 	
 	for ( r = 0 ; r < 4 ; r++){
 		for ( c = 0 ; c < 4 ; c++){
 			temp = getchar();
 			if ( temp != '\n'){
 				board[r][c] = temp;
 			}else{
 				
 				c--;	
 			}
 		
 		}
 	}
 	
 //	printTable( board);
 	
 
 	
 	
 	if ( fullCheck( 'O' , board) == 'w'){
 		printf("Case #%d: O won\n",currentBoard);
 	}
 	else if( fullCheck( 'X' , board) == 'w'){
 		printf("Case #%d: X won\n",currentBoard);
 	}
 	else if ( Draw ( board) == 'w'){
 		printf("Case #%d: Draw\n", currentBoard);
 	}
 	else{
 		printf("Case #%d: Game has not completed\n", currentBoard);
 	}
 	
 	
 	temp= getchar();	
 }
 	
 	
 	return 0;
 }
 
 
 
 char fullCheck ( char player, char board[4][4]){
 	
 	if ( (dioCheck( player, board) == 'w')|| (colCheck( player, board) == 'w') || (rowCheck( player, board) == 'w') ){
 		return 'w';
 	}
 	else{
 		return 'n';
 	}
 	
 }
 
 
 // return w if draw
 char Draw( char board[4][4]){
 	
 	int i, j;
 	for ( i = 0; i < 4 ; i++){
 		for ( j = 0 ; j < 4 ; j++){
 			if ( board[i][j] == '.'){
 				return 'n';
 			}
 			
 		}
 	}
 	
 	return 'w';
 	
 }
 
 
 // if win return w
 char dioCheck ( char player, char board[4][4]){
 	
 	int i;
 	int point = 0;
 	//char result;
 	for ( i = 0 ; i < 4 ; i++){
 		if ( (board[i][i] == player) || (board[i][i] == 'T')){
 			point++;
 			//printf("%d\n", point);
 			if ( point == 4){
 				return 'w';
 			}
 		}
 	}
 	point = 0;
 	
 	for ( i = 3 ; i  >= 0 ; i--){
 		
 		if ( (board[i][3-i] == player) || (board[i][3-i] == 'T')){
 			point++;
 			//printf("%d\n", point);
 			
 			if ( point == 4){
 				return 'w';
 			}
 		}
 		
 	}
 	
 	
 	return 'n';
 }
 
 char  colCheck ( char player, char board[4][4]){
 	int c, r;
 	int point = 0;
 	char result;
 	
 	//printTable( board);
 	
 	for (c = 0 ; (c < 4) ; c++ ){
 		for ( r = 0 ; ( r < 4)  ; r++ ){
 			//printf(" point for %c : %d\n",player, point);
 			if ( (board[r][c] == player) || (board[r][c] == 'T')){
 				point++;
 			//	printf("P : %d\n", point);
 				if ( point == 4){
 					return 'w';
 				}
 			}
 			else{
 				point = 0;
 			}
 			
 		}
 		point = 0;
 		
 	}
 	if ( point >= 4){
 		result = 'w';
 	}else{
 		result = 'n';
 	}
 	return result;
 }
 	
 
 
 char  rowCheck ( char player, char board[4][4]){
 	int c, r;
 	int point = 0;
 	char result;
 	
 	//printTable( board);
 	
 	for (r = 0 ; (r < 4) ; r++ ){
 		for ( c = 0 ; ( c < 4)  ; c++ ){
 			//printf(" point for %c : %d\n",player, point);
 			if ( (board[r][c] == player) || (board[r][c] == 'T')){
 				point++;
 				//printf("P : %d\n", point);
 				if ( point == 4){
 					return 'w';
 				}
 			}
 			else{
 				point = 0;
 				}
 			//printf("row: %d, col: %d  point for %c : %d\n",r,c,player, point);
 			
 		}
 		point = 0;
 		
 	}
 	if ( point >= 4){
 		result = 'w';
 	}else{
 		result = 'n';
 	}
 	return result;
 }
 
 
 
 void printTable ( char board[4][4]){
 	int r,c;
 	
 	for ( r = 0 ; r < 4 ; r++){
 		for ( c = 0 ; c < 4 ; c++){
 			printf("%c\n", board[r][c]);
 		}
 	}
 	//return void;
 	
 }
 
 

