#include<stdio.h>
 int main()
 {
     freopen("C-small-attempt0.in","r",stdin);
     freopen("output.txt","w",stdout);
     int i,t;
     int a[1002]={0};
     a[1]=1;
     a[4]=1;
     a[9]=1;
     a[121]=1;
     a[484]=1;
     scanf("%d",&t);
     for(i=1;i<=t;i++)
     {
         int j,k=0,m,n;
         scanf("%d%d",&m,&n);
         for(j=m;j<=n;j++)
         {
             if(a[j]==1)
                 k++;
         }
         printf("Case #%d: %d\n",i,k);
     }
     return 0;
 }

