#include <stdio.h>
 #include <stdlib.h>
 
 //Function Declarations
 //File I/O
 void saveFile (int, int);
 int load(char [100][100][100], int [100], int [100]);
 
 //Lawnmower Functions
 int maximumLine(char [100][100],int ,int);
 int maximumColumn(char [100][100],int ,int);
 int check(char [100][100], int, int);
 
 int main(int argc, char *argv[])
 {
 	int result, numberOfCases, i;
 	int n[100], m[100];
 	char board[100][100][100];
 
 	numberOfCases = load (board, n, m);
 
 	for (i=0; i<numberOfCases; i++)
 	{
 		result = check(board[i], n[i], m[i]);
 		saveFile (result, i);
 		printf ("Case #%d: %d\n", result);
 	}
 
 	system ("pause");
 	return 0;
 }
 
 void saveFile (int result, int caseNumber)
 {
 	FILE *fp;
 	fp = fopen ("output.txt", "a");
 
 	if (fp!=NULL)
 	{
 			fprintf(fp, "Case #%d: ", caseNumber+1);
 			if (result==0)
 				fprintf (fp, "NO\n");
 			if (result==1)
 				fprintf (fp, "YES\n");
 	}
 	else
 		printf ("Error opening/creating file");
 	fclose(fp);
 }
 
 int load(char board[100][100][100], int n[100], int m[100])
 {
     int i, j, k;
     int cases=0;
 
     FILE *fp;
     fp = fopen("input.txt", "r");
 
     if(fp != NULL)
     {
 	    fscanf(fp,"%d",&cases);
 	    for(i=0;i<cases;i++)
 	    {
 	        fscanf(fp,"%d %d",&n[i], &m[i]); //m->grammes & n->stiles
 	        for(j=0;j<n[i];j++)  //j->grammes
 	        {
 	           for(k=0;k<m[i];k++)  //k->stiles
 	           {
 	                fscanf(fp, "%d", &board[i][j][k]);
 	           }
 	    	}
 	    }
 	}
 	else
 		printf ("Error loading file\n");
     return cases;
 }
 
 int maximumLine(char board[100][100],int line,int m)
 {
     int max=board[line][0],j;
     for(j=1;j<m;j++)
         if (max<board[line][j])
             max=board[line][j];
     return max;
 }
 
 int maximumColumn(char board[100][100],int column,int n)
 {
     int max=board[0][column],i;
     for(i=1;i<n;i++)
         if (max<board[i][column])
             max=board[i][column];
     return max;
 }
 
 int check (char board[100][100], int n, int m)
 {
 	int i, j, maxLine, maxCol;
 
 	for (i=0; i<n; i++)
 	{
 		maxLine = maximumLine (board, i, m);
 		for (j=0; j<m; j++)
 		{
 			if (board[i][j]<maxLine)
 			{
 				maxCol = maximumColumn (board, j, n);
 				if (board[i][j]<maxCol)
 					return 0;
 			}
 		}
 	}
 	return 1;
 }
 
 

