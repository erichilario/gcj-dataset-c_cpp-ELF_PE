#include<stdio.h>
 #include<math.h>
 
 int if_palin(int m)
 {
 	long long int array[15];
 	int i=0,j,y=1;
 	while(m!=0)
 	{
 		array[i]=m%10;
 		i++;
 		m=m/10;
 	}
 	j=i;
 	for(i=0;i<=j/2;i++)
 	{
 		if(array[i]!=array[j-1-i])
 		{
 			y=0;
 			return y;
 		}
 	}
 	return y;
 }
 
 int main()
 {
 	int no_test,k=0,i;
 	long long int a,b,m,n,count,y;
 	scanf("%d",&no_test);
 	int result[no_test];
 	while(k<no_test)
 	{
 		count=0;
 		scanf("%lld %lld",&a,&b);
 		m=sqrt(a);
 		if(m*m!=a)
 			m++;
 		n=sqrt(b);
 		for(i=m;i<n+1;i++)
 		{
 			y=if_palin(i);
 			if(y==1)
 			{
 				y=if_palin(i*i);
 				if(y==1)
 					count++;
 			}
 		}
 		//printf("%lld ",count);
 		result[k]=count;
 		k++;
 	}
 	for(i=0;i<no_test;i++)
 	{
 		printf("Case #%d: %d\n",i+1,result[i]);
 	}
 }

