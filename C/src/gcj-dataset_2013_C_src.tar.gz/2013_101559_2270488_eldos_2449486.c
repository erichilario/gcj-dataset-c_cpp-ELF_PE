#include<stdio.h>
 #include<stdlib.h>
 
 int c,*sol,i,j,m,n;
 int rmax(int **lawn,int r)
 {//printf("Entered \n");
 	int max=lawn[r][0],x;
 	for(x=0;x<n;x++)
 	{
 		if(lawn[r][x]>max)
 			max=lawn[r][x];
 	}
 	//printf("Ext1 %d \n",max);
 	return max;
 }
 int cmax(int **lawn,int c)
 {//printf("Entered 2\n");
 	int max=lawn[0][c],x;
 	for(x=0;x<m;x++)
 	{
 		if(lawn[x][c]>max)
 			max=lawn[x][c];
 	}//printf("Ext2 \n");
 	return max;
 }
 void input()
 {
 	int **lawn,count=0,k;
 	scanf("%d %d",&m,&n);
 	lawn=(int**)malloc(m*sizeof(int*));
 	for(i=0;i<m;i++)
 		lawn[i]=(int*)malloc(n*sizeof(int));
 	for(i=0;i<m;i++)
 	{
 		for(j=0;j<n;j++)
 			scanf("%d",&lawn[i][j]);
 	}
 	
 //===============================================================================================================
 	if(m==1)
 		count+=n;
 	else if(n==1)
 		count+=m;
 	else
 	{
 		for(i=0;i<m;i++)
 		{
 			for(j=0;j<n;j++)
 			{
 				if(i==0 || i==m-1 || j==0 || j==n-1)
 				{
 					if((i==0) && (j==0 || j==n-1))
 					{
 						k= ((j==0) ? 1 : -1);
 						if((lawn[i][j]>=lawn[i+1][j]) || (lawn[i][j]>=lawn[i][j+k]))
 							count++;
 					}
 					else if(((i==m-1) && (j==0 || j==n-1)))
 					{
 						k= ((j==0) ? 1 : -1);
 						if((lawn[i][j]>=lawn[i-1][j]) || (lawn[i][j]>=lawn[i][j+k]))
 							count++;
 					}
 					else if(i==0 || i==m-1)
 					{
 						k= ((i==0) ? 1 : -1);
 						if((lawn[i][j]>=lawn[i+k][j]) || ((lawn[i][j]>=lawn[i][j+1])&&(lawn[i][j]>=lawn[i][j-1])))
 							count++;
 					}
 					else if (j==0 || j==n-1)
 					{
 						k= ((j==0) ? 1 : -1);
 						if((lawn[i][j]>=lawn[i][j+k]) || (((lawn[i][j]>=lawn[i+1][j])&&(lawn[i][j]>=lawn[i-1][j]))))
 							count++;
 					}
 				}
 				else if(((lawn[i][j]>=lawn[i+1][j])&&(lawn[i][j]>=lawn[i-1][j])) || ((lawn[i][j]>=lawn[i][j+1])&&(lawn[i][j]>=lawn[i][j-1])))
 					count++;
 			}
 		}
 	}
 //=============================================================================================================================
 	if(count==(m*n))
 	{
 		*(sol+c)=1;
 		for(i=0;i<m;i++)
 		{
 			for(j=0;j<n;j++)
 			{
 				if(!((lawn[i][j]>=rmax(lawn,i)) || (lawn[i][j]>=cmax(lawn,j))))
 				{
 					*(sol+c)=0;
 					break;
 				}
 			}
 		}
 	}
 	return;
 }
 
 int main ()
 {
 	int t;
 	scanf("%d",&t);
 	sol=(int*)malloc(t*sizeof(int));
 	for(c=0;c<t;c++)
 	{
 		*(sol+c)=0;
 		input();
 	}
 	for(i=0;i<t;i++)
 	{
 		if(*(sol+i)==1)
 			printf("Case #%d: YES\n",i+1);
 		else if(*(sol+i)==0)
 			printf("Case #%d: NO\n",i+1);
 		
 	}
 	return 0;
 }

