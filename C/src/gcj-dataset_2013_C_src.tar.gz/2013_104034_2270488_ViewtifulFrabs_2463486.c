#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 #define ARCHTXT "C:\\google code jam\\C-small-attempt0.IN"
 #define ARCHTXTOUT "C:\\google code jam\\output.txt"
 #define MAXCASOS 3
 #define MAXLINEA 9
 
 short int verificar_palindromo(char cadena[MAXLINEA])
 {int i,j;
 j=strlen(cadena)-1;
 for(i=0;i<=j;i++)
     {if(cadena[i]!=cadena[j-i])
         {return 0;}}
 return 1;}
 
 short int obtener_encabezado(int *x)
 {char cadena[MAXCASOS+1];
 FILE *archlog;
 archlog=fopen(ARCHTXT,"rt");
 if(!archlog)
     {fclose(archlog);
     return 0;}
 else
     {int i,j;
     fseek(archlog,0L,SEEK_SET);
     fgets(cadena,MAXCASOS+1,archlog);
     fclose(archlog);
     j=strlen(cadena);
     *x=atoi(cadena);
     if(*x>100)
         {return 0;}
     else
         {return 1;}}}
 
 short int obtener_limites(int *x,  int *y, int k)
 {FILE *archlog;
 archlog=fopen(ARCHTXT,"rt");
 if(!archlog)
     {fclose(archlog);
     return 0;}
 else
     {int i,j;
     char cadena[MAXLINEA],cad[MAXLINEA];
     for(i=-1;i<=k;i++)
         {fgets(cadena,MAXLINEA,archlog);}
     fclose(archlog);
     strcpy(cad,cadena);
     i=-1;
     do
         {i++;
         if(cadena[i]==' ')
             {cadena[i]='\0';}}
     while(cadena[i]!='\0');
     *x=atoi(cadena);
     cadena[0]='\0';
     j=-1;
     do
         {i++;
         j++;
         cadena[j]=cad[i];}
     while(cad[i]!='\0');
     *y=atoi(cadena);
 
 }}
 
 void main()
 {char cadena[25];
 FILE *archlog;
 archlog=fopen(ARCHTXTOUT,"wt");
 int max,min,contador=0,i,x,kk,k;
 
 obtener_encabezado(&kk);
 for(k=0;k<kk;k++)
     {contador=0;
     obtener_limites(&min,&max,k);
     for(i=min;i<=max;i++)
     {sprintf(cadena,"%d",i);
     if(verificar_palindromo(cadena))
         {int x=sqrt(atof(cadena));
         if((x*x)==atof(cadena))
             {char cadenaraiz[25];
             sprintf(cadenaraiz,"%d",x);
             if(verificar_palindromo(cadenaraiz))
                 {contador++;}}}}
     fprintf(archlog,"Case #%d: %d\n",k+1,contador);}}

