# include <stdio.h>
 # include <stdlib.h>
 
 #define MAX 200
 int main(){
 	int arr[MAX][MAX];
 	int i,j,tc,cas,n,m,k,flag;
 	scanf("%d", &cas);
 	
 	for(tc=1;tc<=cas;tc++){
 		flag=0;
 		scanf("%d",&n);
 		scanf("%d",&m);
 		for(i=0;i<n;i++)
 			for(j=0;j<m;j++){
 				scanf("%d",&arr[i][j]);
 			}
 		for(i=0;i<n;i++){
 			for(j=0;j<m;j++){
 				int try=0;
 				for(k=0;k<n;k++){	
 					if(arr[k][j]>arr[i][j]){
 						try=1;
 						break;
 					}
 				}	
 				if(try){
 					for(k=0;k<m;k++){	
 						if(arr[i][k]>arr[i][j]){
 							flag=1;
 							break;
 						}
 					}
 				}
 				if(flag)
 					break;
 			}
 			if(flag)
 				break;
 		}
 		if(flag)
 			printf("Case #%d: NO\n",tc);
 		else
 			printf("Case #%d: YES\n",tc);
 	}
 	return 0;
 }

