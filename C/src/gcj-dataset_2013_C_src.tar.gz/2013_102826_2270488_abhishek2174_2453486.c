#include<stdio.h>
 #include<string.h>
 int main()
 {
     freopen("A-small-attempt3.in","r",stdin);
     freopen("output.txt","w",stdout);
     int t,h;
     char l[30];
     scanf("%d",&t);
     gets(l);
     for(h=1;h<=t;h++)
     {
         char q[10][100];
         if(h!=1)
         {
             gets(q[1]);
             //gets(q[2]);
         }
         int i,j,flag=0;
         char text[80][80];
         for(i=1;i<=4;i++)
                 gets(text[i]);
         for(i=1;i<=4;i++)
         {
             if((text[i][0]=='X'||text[i][0]=='T')&&(text[i][1]=='X'||text[i][1]=='T')&&(text[i][2]=='X'||text[i][2]=='T')&&(text[i][3]=='X'||text[i][3]=='T'))
             {
                 flag=1;
                 break;
             }
             if((text[i][0]=='O'||text[i][0]=='T')&&(text[i][1]=='O'||text[i][1]=='T')&&(text[i][2]=='O'||text[i][2]=='T')&&(text[i][3]=='O'||text[i][3]=='T'))
             {
                 flag=2;
                 break;
             }
             if((text[1][i-1]=='X'||text[1][i-1]=='T')&&(text[2][i-1]=='X'||text[2][i-1]=='T')&&(text[3][i-1]=='X'||text[3][i-1]=='T')&&(text[4][i-1]=='X'||text[4][i-1]=='T'))
             {
                 flag=1;
                 break;
             }
             if((text[1][i-1]=='O'||text[1][i-1]=='T')&&(text[2][i-1]=='O'||text[2][i-1]=='T')&&(text[3][i-1]=='O'||text[3][i-1]=='T')&&(text[4][i-1]=='O'||text[4][i-1]=='T'))
             {
                 flag=2;
                 break;
             }
         }
         if(flag==0)
         {
             if((text[1][0]=='O'||text[1][0]=='T')&&(text[2][1]=='O'||text[2][1]=='T')&&(text[3][2]=='O'||text[3][2]=='T')&&(text[4][3]=='O'||text[4][3]=='T'))
             {
                 flag=2;
             }
             if((text[1][0]=='X'||text[1][0]=='T')&&(text[2][1]=='X'||text[2][1]=='T')&&(text[3][2]=='X'||text[3][2]=='T')&&(text[4][3]=='X'||text[4][3]=='T'))
             {
                 flag=1;
             }
             if((text[4][0]=='X'||text[4][0]=='T')&&(text[3][1]=='X'||text[3][1]=='T')&&(text[2][2]=='X'||text[2][2]=='T')&&(text[1][3]=='X'||text[1][3]=='T'))
             {
                 flag=1;
             }
             if((text[4][0]=='O'||text[4][0]=='T')&&(text[3][1]=='O'||text[3][1]=='T')&&(text[2][2]=='O'||text[2][2]=='T')&&(text[1][3]=='O'||text[1][3]=='T'))
             {
                 flag=2;
             }
         }
         if(flag==0)
         {
             for(i=1;i<=4;i++)
                 for(j=0;j<=3;j++)
             {
                 if(text[i][j]=='.')
                 {
                     flag=3;
                     break;
                 }
             }
         }
         if(flag==0)
             printf("Case #%d: Draw\n",h);
         else if(flag==1)
             printf("Case #%d: X won\n",h);
         else if(flag==2)
             printf("Case #%d: O won\n",h);
         else
             printf("Case #%d: Game has not completed\n",h);
 
     }
     return 0;
 }

