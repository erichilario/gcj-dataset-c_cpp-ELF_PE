#include <stdio.h>
 #include <string.h>
 
 unsigned char chess[6][6];
 
 // O win: 132/137
 // X win: 168/164
 int check(int sum)
 {
   switch(sum)
   {
     case 132:
     case 137: printf("O won\n"); return 1;
     case 168:
     case 164: printf("X won\n"); return 1;
   }
   return 0;
 }
 
 void f()
 {
   int i, j, isfull = 1, diag[2]={0,0};
   for(i=0;i<4;i++)
   {
     for(j=0;j<4;j++)
     {
       chess[i][4] += chess[i][j] - '.';
       chess[4][j] += chess[i][j] - '.';
       if(isfull && chess[i][j] == '.')
         isfull = 0;
       if(i == j)
         diag[0] += chess[i][j] - '.';
       if(i+j == 3)
         diag[1] += chess[i][j] - '.';
     }
   }
   for(i=0;i<4;i++)
   {
     if(check(chess[i][4]) || check(chess[4][i]))
       return;
   }
   if(check(diag[0]) || check(diag[1]))
     return;
   if(isfull)
     printf("Draw\n");
   else
     printf("Game has not completed\n");
 }
 
 void prt()
 {
   int i, j;
   for(i=0;i<5;i++)
   {
     for(j=0;j<5;j++)
       printf("%d ", chess[i][j]);
     printf("\n");
   }
   printf("\n");
 }
 
 int main()
 {
   int T, i, j;
   scanf("%d", &T);
   for(i=1;i<=T;i++)
   {
     memset(chess, 0, sizeof(char)*36);
     for(j=0;j<4;j++)
       scanf("%s\n", chess[j]);
     printf("Case #%d: ", i);
     f();
   }
   return 0;
 }

