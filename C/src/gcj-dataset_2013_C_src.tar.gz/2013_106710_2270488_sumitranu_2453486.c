#include<stdio.h>
 main()
 {
       char h[4][5],skip[5],gh[1];int r,i,T,j,k,count,count1,flag=0,count2=0,count3=0,flag2=0,q=0,p=0;FILE *ptr;
       //scanf("%d",&T);
       ptr=fopen("a.txt","r");
        //freopen("1.txt","r",stdin);
       freopen("Output.txt","w",stdout);
        fscanf (ptr, "%d", &T); 
        fgets(skip,5,ptr);
       for(r=0;r<T;r++)
       {count2=0;p=0;q=0;
      
       count3=0;flag2=0;
        fflush(stdin);
        if(r>0)
          fgets(skip,5,ptr);
      
              for(i=0;i<4;i++) 
              {// gets(h[i]);
              fgets(&h[i][0],6,ptr);
              
              }
         /*  for(i=0;i<4;i++) 
             {for(j=0;j<4;j++)
             printf("%c",h[i][j]);printf("\n");}getch();*/
            
             for(j=0;j<4;j++)
             {
                    if((h[j][j]=='X')||(h[j][j]=='T'))
                    count2++;
                    if((h[j][j]=='O')||(h[j][j]=='T'))
                    count3++;
                    }
               for(j=0;j<4;j++)
             { if((h[3-j][j]=='X')||(h[3-j][j]=='T'))
                    p++;
                    if((h[3-j][j]=='O')||(h[3-j][j]=='T'))
                    q++;
                    
                    } 
                   
              if(count2==4)
                     { printf("Case #%d: X won\n",r+1);flag2=1;}
                      if(count3==4)
                       { printf("Case #%d: O won\n",r+1);flag2=1;}   
               if(p==4)
                     { printf("Case #%d: X won\n",r+1);flag2=1;}
                      if(q==4)
                       { printf("Case #%d: O won\n",r+1);flag2=1;}               
                              
             if(flag2==0)
          {   for(j=0;j<4;j++)
             {count=0;
             count1=0;
                for(k=0;k<4;k++)
                {
                     if((h[j][k]=='X') || (h[j][k]=='T'))
                     {
                           count++;            }   
                            
                     else if((h[j][k]=='O') || (h[j][k]=='T'))       
                      {count1++;}
                            
                             }
                                              
                      
                      if(count==4 )
                     { printf("Case #%d: X won\n",r+1);flag2=1;break;}
                      if(count1==4)
                       { printf("Case #%d: O won\n",r+1);flag2=1;break;}
                      
                      }  
               if(flag2==0)        
              {for(j=0;j<4;j++)
             {count=0;
             count1=0;
                for(k=0;k<4;k++)
                {
                     if((h[k][j]=='X') || (h[k][j]=='T'))
                     {
                           count++;            }   
                            
                     else if((h[k][j]=='O') || (h[k][j]=='T'))       
                      {count1++;}
                            }
                    if(count==4)
                     { printf("Case #%d: X won\n",r+1);flag2=1;break;}
                      if(count1==4)
                       { printf("Case #%d: O won\n",r+1);flag2=1;break;}
                      
                      }  
                              
                              }}
                   
                   
                   if(flag2==0)
                    {flag=0;
                   for(j=0;j<4;j++)
                    {for(k=0;k<4;k++)
                    {
                        if(h[j][k]=='.')  
                          {flag=1;break;}          
                                    }
                                    if(flag==1)
                                    break;
                                    } 
                        if(flag==0)
                        printf("Case #%d: Draw\n",r+1);
                        if(flag==1)
                        printf("Case #%d: Game has not completed\n",r+1);    }         
                          
                             
                   }// for loop
          return 0;
              }       

