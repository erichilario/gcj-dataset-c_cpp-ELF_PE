#include<string.h>
 #include<stdio.h>
 #include<stdbool.h>
 #include<stdlib.h>
 struct node {
     int num;
     int pos;
     int axis;
 };
 int compare_num(const void *v1 , const void *v2) {
     const struct node * p1 = v1;
     const struct node * p2 = v2;
     if(p1->num >p2->num) {
         return 1;
     } else if (p1->num < p2->num){
         return -1;
     } else if(p1->axis< p2->axis){
         return -1;
     } else if(p1->axis> p2->axis){
         return 1;
     } else if(p1->pos< p2->pos){
         return -1;
     } else if(p1->pos > p2->pos){
         return 1;
     }
 }
 void top_bot(int ** arr,int pos, int *covered, int value , int N) {
     int i;
     bool flag=1;
     for(i=0;i<N && flag;i++) {
         if(!((arr[i][pos]==value ) || (arr[i][pos]==0))) {
                 flag=0;
             }
     }
     if(flag){
         for(i=0;i<N ;i++) {
             if(arr[i][pos]==value ) {
                 arr[i][pos]=0;
                 *covered=*covered+1;                    
             } 
         }
     }
 }
 
 void bot_top(int ** arr,int pos, int *covered, int value , int N) {
     int i;
     bool flag=1;
     for(i=N-1;i>=0 && flag;i--) {
         if(!((arr[i][pos]==value ) || (arr[i][pos]==0))) {
                 flag=0;
             }
     }
     if(flag){
         for(i=N-1;i>=0 ;i--) {
             if(arr[i][pos]==value ) {
                 arr[i][pos]=0;
                 *covered=*covered+1;                    
             } 
         }
     }
 }
 void left_right(int ** arr,int pos, int *covered, int value , int M) {
     int i;
     bool flag=1;
     for(i=0;i<M && flag;i++) {
         if(!((arr[pos][i]==value ) || (arr[pos][i]==0))) {
                 flag=0;
             }
     }
     if(flag){
         for(i=0;i<M ;i++) {
             if(arr[pos][i]==value ) {
                 arr[pos][i]=0;
                 *covered=*covered+1;                    
             } 
         }
     }
 }
 
 void right_left(int ** arr,int pos, int *covered, int value , int M) {
     int i;
     bool flag=1;
     for(i=M-1;i>=0 && flag;i--) {
         if(!((arr[pos][i]==value ) || (arr[pos][i]==0))) {
                 flag=0;
             }
     }
     if(flag){
         for(i=M-1;i>=0 ;i--) {
             if(arr[pos][i]==value ) {
                 arr[pos][i]=0;
                 *covered=*covered+1;                    
             } 
         }
     }
 }
 
 
 
 int main (){
   int T=0,T2,N,M,i=0,j=0,k=0,L=0,size=0,covered=0;
   bool flag=0;
   scanf("%d",&T);
   T2=T;
   while(T>0) {
       covered=0;
       scanf("%d %d",&N,&M);
       int ** arr=malloc(N*sizeof(int*));
       for(i=0;i<N;i++){
           arr[i]=malloc(M*sizeof(int));
       }
       struct node * fullarr=malloc((2*(M+N))*sizeof(struct node));
       for(i=0;i<N;i++){
           for(j=0;j<M;j++){
               scanf("%d",&arr[i][j]);
           }
       }
       k=0;
       for(i=0;i<M;i++){
           fullarr[k].num=arr[0][i];
           fullarr[k].pos=i;
           fullarr[k].axis=0;
           k++;
       }
       for(i=0;i<N;i++){
           fullarr[k].num=arr[i][0];
           fullarr[k].pos=i;
           fullarr[k].axis=1;
           k++;
       }
       for(i=0;i<M;i++){
           fullarr[k].num=arr[N-1][i];
           fullarr[k].pos=i;
           fullarr[k].axis=2;
           k++;
       }
       for(i=0;i<N;i++){
           fullarr[k].num=arr[i][M-1];
           fullarr[k].pos=i;
           fullarr[k].axis=3;
           k++;
       }
       qsort(fullarr,k,sizeof(struct node),compare_num);
       L=k;
       size=M*N;
       for(i=0;i<L && covered<=size;i++){
           switch( fullarr[i].axis ) 
         {
             case 0:
                 top_bot(arr,fullarr[i].pos, &covered, fullarr[i].num , N);
                 break;
             case 1 :
                 left_right(arr,fullarr[i].pos, &covered, fullarr[i].num , M);
                 break;
             case 2 :
                 bot_top(arr,fullarr[i].pos, &covered, fullarr[i].num , N);
                 break;
             case 3 :
                 right_left(arr,fullarr[i].pos, &covered, fullarr[i].num , M);
                 break;
         }
       }
       flag=0;
       if(covered==size){
           printf("Case #%d: YES\n",T2-T+1);
       }else {
           for(i=0;i<N;i++){
               for(j=0;j<M;j++){
                   if(arr[i][j]==1)
                     flag=1;
               }
           }
           if(flag)
             printf("Case #%d: NO\n",T2-T+1);
         else
            printf("Case #%d: YES\n",T2-T+1); 
       }
       free(fullarr);
       for(i=0;i<N;i++){
           free(arr[i]);
       }
       free(arr);
       T--;
   }
   
   
   return 0;
 
 }
