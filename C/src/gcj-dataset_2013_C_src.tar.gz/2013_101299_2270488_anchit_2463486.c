#include <stdio.h>
 #include <math.h>
 
 int palindrome(int n)
 {
 	int j,temp,b[5],i=0;
 	temp = n;
 	for(i=0;temp!=0;i++)
 	{
 		b[i] = temp%10;
 		temp = temp/10;
 	}
 	temp = 0;
 	for(j=0;j<i;j++)
 	{
 		temp = temp*10 + b[j];
 	}	
 	if(temp == n)
 		return 1;
 	else
 		return 0;
 }
 
 int main()
 {
 	int t,i,a[100],j,c[100],d[100],e[100],k;
 	scanf("%d",&t);
 	int cnt = 1;
 	while(t--)
 	{
 		int A,B;
 		scanf("%d %d",&A,&B);
 		j=0;
 		int temp;
 		for(i=1;i<=1000;i++)
 		{
 			if(floor((double)sqrt(i)) == (double)sqrt(i))
 			{
 				a[j]=i;
 				j++;
 			}
 		}
 		k=0;
 		for(i=0;i<j;i++)
 		{
 			if(palindrome(a[i]))
 			{
 				c[k] = a[i];
 				k++;
 			}
 		} 
 		for(i=0;i<k;i++)
 		{
 			d[i] = sqrt(c[i]);
 		}
 		j=0;
 		for(i=0;i<k;i++)
 		{
 			if(palindrome(d[i]))
 			{
 				e[j] = d[i]*d[i];
 				j++;
 			}
 		}
 		int count=0;
 		for(i=0;i<j;i++)
 		{
 			if(e[i]>=A && e[i]<=B)
 				count++;
 		}
 		printf("Case #%d: %d\n",cnt,count);
 		cnt++;
 	}
 }
