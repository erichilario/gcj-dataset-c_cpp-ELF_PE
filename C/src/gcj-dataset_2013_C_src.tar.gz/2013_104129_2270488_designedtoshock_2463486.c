#include<stdio.h>
 #include<stdlib.h>
 int  main()
 {
 	int t,i,j,k,count,n,m;
 	int a[5]={1,4,9,121,484};
 	scanf("%d",&t);
 	for ( i = 1; i <= t; ++i)
 	{
 		count=0;
 		j=0;
 		scanf("%d%d",&n,&m);
 		while(a[j]<n)
 		{
 			j++;
 			//printf("I am in 1st loop\n");
 		}
 
 		while((a[j]>=n)&&(a[j]<=m)&&(j<5))
 		{
 			count+=1;
 			j++;
 			//printf("I am in 2nd loop\n");
 		}
 		printf("Case #%d: %d\n",i,count);
 
 		/* code */
 	}
 
 	/* code */
 	return 0;
 }
