#include<stdio.h>
 #include<math.h>
 int a1, b1;
 long long unsigned int rev(long long unsigned int);
 int palin(long long unsigned int, long long unsigned int, int);
 int main()
 {
 	int j, k, t; 
 	long long unsigned int a, b, x, i, w, w1;
 	scanf("%d", &t);
 	for(k=0;k<t;k++)
 	{
 		int r, s, count=0;
 		scanf("%llu %llu", &a, &b);
 		for(i=a;i<=b;i++)
 		{
 			a1=0;
 			x=rev(i);
 	//		printf("%d\n", a1);
 			r=palin(i, x, a1);
 			if(r==0)
 			{
 				continue;
 			}
 			else
 			{
 				a1=0;
 				double t1, t2, t4;
 				long long unsigned int t3;
 				t1=sqrt(i);
 			//	printf("%lf\n", t1);
 				t3=t1;
 			//	printf("%d\n", t3);
 				t4=t3*1.0;
 				t2=t1-t4;
 		//		printf("%lf\n", t2);
 				if(t2>0)
 				{
 					continue;
 				}
 			//	printf("%llu %llu\n", w, i); 
 				w=t3;
 				w1=rev(w);
 		//		printf("%llu\n", w);
 				s=palin(w, w1, a1);
 				if(s==0)
 				{
 					continue;
 				}
 				else
 				{
 					count++;
 	//				printf("%llu\n", i);
 				}
 			}
 		}
 		printf("Case #%d: %d\n", k+1, count);
 	}
 	return 0;
 }
 
 
 			
 
 
 long long unsigned int rev(long long unsigned int a)
 {
 	long long unsigned int r=0;
 	while(a>0)
 	{
 	//	int r;
 		r=r*10+a%10;
 		a=a/10;
 		a1++;
 	}
 	return r;
 }
 
 int palin(long long unsigned int a, long long unsigned int b, int c)
 {
 	if(a>0 && a<10)
 	{
 		return 1;
 	}
 	int z=c/2;
 //	printf("%d %llu\n", c, a);
 	int r1, r2;
 	while(z>0)
 	{
 		r1=a%10;
 		r2=b%10;
 		a=a/10;
 		b=b/10;
 		z--;
 		if(r1==r2)
 		{
 			continue;
 		}
 		else
 			return 0;
 	}
 	return 1;
 }
 

