#include <stdio.h>
 #include <stdlib.h>
 
 #define MAX_BUFFER_SIZE 1024*1024
 
 unsigned int convert(char* buff, int *is_over, int *loc) {
 	unsigned int num = 0;
 	char O_val = 0x1;
 	char X_val = 0x2;
 	char T_val = 0x3;
 
 	int i = 0;
 	int ctr = 0;
 	int lines = 0;
 
 	*is_over = 1;
 	for(i = 0; i < 21; i++) {
 		(*loc)++;
 		switch(buff[i]) {
 			case 'O':
 				num |= (O_val << (ctr*2));
 				ctr++;
 				break;
 
 			case 'X':
 				num |= (X_val << (ctr*2));
 				ctr++;
 				break;
 
 			case 'T':
 				num |= (T_val << (ctr*2));
 				ctr++;
 				break;
 
 			case '.':
 				*is_over = 0;
 				ctr++;
 				break;
 
 			case '\n':
 				lines++;
 			default:
 				if(lines >= 4)
 					return num;
 				continue;
 		}
 	}
 	return num; 
 }
 
 #define compare(x, y) ((x & y) == y)
 
 void main(int argc, char** argv) {
 	int is_over = 0;
 	int entries = 0;
 	int ctr = 0;
 	int loc = 0;
 	unsigned int number = 0;
 	FILE* fp = NULL;
 	char* buff = NULL;
 	char buffer[MAX_BUFFER_SIZE] = { 0 };
 
 	if(argc < 2) {
 		printf("Insufficient arguments\n");
 		return;
 	}
 
 	fp = fopen(argv[1], "r");
 	if(fp == NULL) {
 		printf("Unable to open input file\n");
 		return;
 	}
 
 	fscanf(fp, "%d\n", &entries);
 //	printf("Number of entries %d\n", entries);
 
 	fread(buffer, MAX_BUFFER_SIZE, 1, fp);
 
 	while(ctr < entries) {
 		buff = &buffer[loc];
 
 		number = convert(buff, &is_over, &loc);
 
 //		printf("Case #%d (%x): ", (ctr + 1), number);
 		printf("Case #%d: ", (ctr + 1), number);
 
 		if(compare(number, 0x55) || compare(number, 0x5500) ||
 			compare(number, 0x550000) || compare(number, 0x55000000) ||
 			compare(number, 0x01010101) || compare(number, (0x01010101 << 2)) ||
 			compare(number, (0x01010101 << 4)) || compare(number, (0x01010101 << 6)) ||
 			compare(number, 0x40100401 ) || compare(number, 0x01041040)) {
 
 			printf("O won\n");
 
 		} else if(compare(number, 0xAA) || compare(number, 0xAA00) ||
 			compare(number, 0xAA0000) || compare(number, 0xAA000000) ||
 			compare(number, 0x02020202) || compare(number, (0x02020202 << 2)) ||
 			compare(number, (0x02020202 << 4)) || compare(number, (0x02020202 << 6)) ||
 			compare(number, 0x80200802) || compare(number, 0x2082080)) {
 
 			printf("X won\n");
 
 		} else {
 			if(is_over == 1) {
 				printf("Draw\n");
 			} else {
 				printf("Game has not completed\n");
 			}
 		}
 
 		while((buffer[loc] == '\n')) {
 			loc++;
 		}
 		ctr++;
 	}
 }

