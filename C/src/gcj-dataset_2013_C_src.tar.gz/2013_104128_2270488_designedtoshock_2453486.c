#include<stdio.h>
 #include<stdlib.h>
 int main()
 {
 	int t,i,j,k,incomplete,win;
 	int hor[4],ver[4],dig[2];
 	scanf("%d",&t);
 	char a[4][4];
 	for(i=1;i<=t;i++)
 	{
 		
 		incomplete=0,win=0,dig[0]=0,dig[1]=0;
 		for(j=0;j<4;j++)
 		{
 			hor[j]=0;
 			ver[j]=0;
 			for(k=0;k<4;k++)
 				scanf(" %c",&a[j][k]);
 		}
 		for(j=0;j<4;j++)
 		{
 			for(k=0;k<4;k++)
 			{
 				if(a[j][k]=='X')
 				{
 					if((hor[j]==0)||(hor[j]==1))
 					{
 						hor[j]=1;	
 					}
 					else
 						hor[j]=3;
 
 				}
 				else if(a[j][k]=='O')
 				{
 					if((hor[j]==0)||(hor[j]==2))
 						hor[j]=2;
 					else
 						hor[j]=3;
 				}
 				else if(a[j][k]=='.')
 				{
 					incomplete=1;
 					hor[j]=3;
 				}
 
 			}
 		//	printf("hor[%d] is %d\n",j,hor[j]);
 		}
 		for(k=0;k<4;k++)
 		{
 			for(j=0;j<4;j++)
 			{
 				if(a[j][k]=='X')
 				{
 					if((ver[k]==0)||(ver[k]==1))
 					{
 						ver[k]=1;	
 					}
 					else
 						ver[k]=3;
 
 				}
 				else if(a[j][k]=='O')
 				{
 					if((ver[k]==0)||(ver[k]==2))
 						ver[k]=2;
 					else
 						ver[k]=3;
 				}
 				else if(a[j][k]=='.')
 				{
 					incomplete=1;
 					ver[k]=3;
 				}
 				
 			}
 		//			printf("ver[%d] is %d\n",k,ver[k]);
 		}
 		for(j=0;j<4;j++)
 		{
 			if(a[j][j]=='X')
 			{
 				if((dig[0]==0)||(dig[0]==1))
 				{
 					dig[0]=1;
 				}
 				else
 					dig[0]=3;
 			}
 			else if (a[j][j]=='O')
 			{
 				if((dig[0]==0)||(dig[0]==2))
 				{
 					dig[0]=2;
 				}
 				else
 					dig[0]=3;
 			
 			}
 			else if(a[j][j]=='.')
 			{
 				dig[0]=3;
 				incomplete=1;
 
 			}
 		}
 		for(j=0;j<4;j++)
 		{
 			if(a[j][3-j]=='X')
 			{
 				if((dig[1]==0)||(dig[1]==1))
 				{
 					dig[1]=1;
 				}
 				else
 					dig[1]=3;
 			}
 			else if (a[j][3-j]=='O')
 			{
 				if((dig[1]==0)||(dig[1]==2))
 				{
 					dig[1]=2;
 				}
 				else
 					dig[1]=3;
 			
 			}
 			else if(a[j][3-j]=='.')
 			{
 				dig[1]=3;
 				incomplete=1;
 				
 			}
 		}
 		for ( j = 0; j < 4; ++j)
 		{
 			if((hor[j]!=0)&&(hor[j]!=3))
 			{
 				win=hor[j];
 			//	printf("Current value in hor is %d\n",j);
 			}
 			if((ver[j]!=0)&&(ver[j]!=3))
 			{
 				win=ver[j];
 			//	printf("Current value in hor is %d\n",j);
 			}
 			/* code */
 		}
 		if((dig[0]!=0)&&(dig[0]!=3))
 			win=dig[0];
 		if((dig[1]!=0)&&(dig[1]!=3))
 			win=dig[1];
 
 
 		if(win==1)
 			printf("Case #%d: X won\n",i);
 		else if(win==2)
 			printf("Case #%d: O won\n",i);
 		else if(incomplete==1)
 			printf("Case #%d: Game has not completed\n",i);
 		else 
 			printf("Case #%d: Draw\n",i);
 
 	}
 	return 0;
 }

