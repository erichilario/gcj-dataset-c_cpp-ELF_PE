#include<stdio.h>
 int main()
 {
 int T,z,a,b,flag;
 
 scanf("%d",&T);
 
 for(z=1;z<=T;z++)
 {
   
   flag=0;
   scanf("%d%d",&a,&b);
   if(1>=a&&1<=b)flag++;
   if(4>=a&&4<=b)flag++;
   if(9>=a&&9<=b)flag++;
   if(484>=a&&484<=b)flag++;
   if(121>=a&&121<=b)flag++;
   
   printf("Case #%d: %d\n",z,flag);
   
 }
 
   
 }

