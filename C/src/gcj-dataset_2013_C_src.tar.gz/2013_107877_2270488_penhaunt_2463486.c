//Problem C. Fair and Square
 #include<stdio.h>
 #include<math.h>
 int issquare(int n)
 {
     int r = sqrt(n);
     return n== r*r;
 }
 int isPal(int n)
 {
     int r=0,t=n;
     while(t)
     {
         int d = t%10;
         r = r*10 + d;
         t/=10;
     }
     return n==r;
 }
 int main()
 {
     FILE *fp = fopen("C-small-attempt0.in","r");
     FILE *fout = fopen("output.txt","w");
     int t,i;
     fscanf(fp,"%d",&t);
     for(i=1;i<=t;i++)
     {
         int a,b;
         fscanf(fp,"%d %d",&a,&b);
         int j,k,count=0;
         for(j=a;j<=b;j++)
         {
             if(issquare(j) && isPal(j) && isPal(sqrt(j)))
             {
                 count++;
                 //printf("No is :: %d\n",j);
             }
         }
         fprintf(fout,"Case #%d: %d\n",i,count);
     }
 }

