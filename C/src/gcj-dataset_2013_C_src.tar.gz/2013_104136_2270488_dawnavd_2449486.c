#include <stdio.h>
 #include <string.h>
 int main()
 {
 	FILE *in,*out;
 	int i,j;
 	int n,m;
 	int ar[100][100];
 	int row[100];
 	int col[100];
 	int t;
 	int cs = 1;
 	in = fopen("b.in","r");
 	out = fopen("b.out","w");
 
 	fscanf(in,"%d",&t);
 	while (t--) {
 		fscanf(in,"%d%d",&m,&n);
 		memset(row,0,sizeof(row));
 		memset(col,0,sizeof(col));
 		for(i = 0; i < m; i++) {
 			for(j = 0; j < n; j++) {
 				fscanf(in,"%d",&ar[i][j]);
 				if(ar[i][j] > row[i]) {
 					row[i] = ar[i][j];
 				}
 				if(ar[i][j] > col[j]) {
 					col[j] = ar[i][j];
 				}
 			}
 		}
 		int check = 1;
 		for(i = 0; i < m; i++) {
 			for(j = 0; j < n; j++) {
 				if(ar[i][j] != col[j] && ar[i][j] != row[i]){
 					check = 0;
 					break;
 				}
 			}
 			if(check == 0) {
 				break;
 			}
 		}
 		fprintf(out,"Case #%d: ",cs++);
 		if(check) {
 			fprintf(out,"YES\n");
 		}
 		else{
 			fprintf(out,"NO\n");
 		}
 	}
 	return 0;
 }

