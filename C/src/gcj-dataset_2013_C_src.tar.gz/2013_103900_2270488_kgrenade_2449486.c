#include<cstdio>
 
 
 
 int check_valid(int** prob, int N, int M) {
     int* row_maxes = new int[N];
     int* col_maxes = new int[M];
     for(int i = 0; i < N; ++i) {
         row_maxes[i] = 0;
         for(int j = 0; j < M; ++j) {
             if(prob[i][j] > row_maxes[i])
                row_maxes[i] = prob[i][j];
         }
     }
 
     for(int j = 0; j < M; ++j) {
         col_maxes[j] = 0;
         for(int i = 0; i < N; ++i) {
             if(prob[i][j] > col_maxes[j]) {
                 col_maxes[j] = prob[i][j];
             }
         }
     }
 
 
     for(int i = 0; i < N; ++i) {
         for(int j = 0; j < M; ++j) {
             if(prob[i][j] < row_maxes[i] && prob[i][j] < col_maxes[j]) {
                 delete[] row_maxes;
                 delete[] col_maxes;
                 return 0;
             }
         }
     }
     delete[] row_maxes;
     delete[] col_maxes;
     return 1;
 
 
 }
 
 
 int solve_next() {
     int N;
     int M;
     scanf("%d %d\n", &N, &M);
     int** prob = new int*[N];
     for(int i = 0; i < N; ++i) {
         prob[i] = new int[M];
         for(int j = 0; j < M-1; ++j){
             scanf("%d ", &prob[i][j]);
         }
         scanf("%d\n", &prob[i][M-1]);
 
     }
 
     return check_valid(prob, N, M);
 }
 
 
 int main() {
 
     int num_ex;
     scanf("%d\n", &num_ex);
 
     for(int p = 1; p <= num_ex; ++p) {
         int res = solve_next();
         printf("Case #%d: ", p);
         switch(res) {
             case 0:
                 printf("NO");
                 break;
             case 1:
                 printf("YES");
                 break;
             default:
                 break;
         }
         printf("\n");
     }
 }

