#include<stdio.h>
 #include<math.h>
 #include<string.h>
 #include<stdlib.h>
 #include<memory.h>
 #include<malloc.h>
 #include<limits.h>
 #define ll long long
 #define ull unsigned long long
 #define max(a,b) (a)>(b)?(a):(b)
 #define min(a,b) (a)<(b)?(a):(b)
 int gcd(int a,int b){
 	return b?gcd(b,a%b):a;
 }
 char a[5][5];
 int check(){
 	int i,j,t_ct,x_ct,o_ct;
 	for(i=0;i<4;i++){
 		x_ct=0;t_ct=0;o_ct=0;
 		for(j=0;j<4;j++){
 			if(a[i][j]=='T') t_ct++;
 			else if(a[i][j]=='X') x_ct++;
 			else if(a[i][j]=='O') o_ct++;
 		}
 		if(x_ct==4 || (x_ct==3 && t_ct==1)) return 1;
 		else if(o_ct==4 || (o_ct==3 && t_ct==1)) return 2;
 		x_ct=0;t_ct=0;o_ct=0;
 		for(j=0;j<4;j++){
 			if(a[j][i]=='T') t_ct++;
 			else if(a[j][i]=='X') x_ct++;
 			else if(a[j][i]=='O') o_ct++;
 		}
 		if(x_ct==4 || (x_ct==3 && t_ct==1)) return 1;
 		else if(o_ct==4 || (o_ct==3 && t_ct==1)) return 2;
 	}
 	x_ct=0;t_ct=0;o_ct=0;
 	for(i=0;i<4;i++){
 		if(a[i][i]=='T') t_ct++;
 		else if(a[i][i]=='X') x_ct++;
 		else if(a[i][i]=='O') o_ct++;
 	}
 	if(x_ct==4 || (x_ct==3 && t_ct==1)) return 1;
 	else if(o_ct==4 || (o_ct==3 && t_ct==1)) return 2;
 	x_ct=0;t_ct=0;o_ct=0;
 	for(i=0;i<4;i++){
 		if(a[i][3-i]=='T') t_ct++;
 		else if(a[i][3-i]=='X') x_ct++;
 		else if(a[i][3-i]=='O') o_ct++;
 	}
 	if(x_ct==4 || (x_ct==3 && t_ct==1)) return 1;
 	else if(o_ct==4 || (o_ct==3 && t_ct==1)) return 2;
 	return 0;
 }
 int main()
 {
 	int t,i,j,won,d,k=1;
 	scanf("%d",&t);
 	while(t--){
 		for(i=0;i<4;i++) scanf("%s",a[i]);
 		won=check();
 		printf("Case #%d: ",k);
 		k++;
 		if(won==1)
 			printf("X won\n");
 		else if(won==2)
 			printf("O won\n");
 		else{
 			d=0;
 			for(i=0;i<4;i++){
 				for(j=0;j<4;j++){
 					if(a[i][j]=='.'){
 						d=1;
 						break;
 					}
 				}
 				if(d==1) break;
 			}
 			if(d==1) printf("Game has not completed\n");
 			else printf("Draw\n");
 		}		
 	}
 	return 0;
 }

