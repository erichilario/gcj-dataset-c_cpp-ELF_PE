#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 void processBoard(int caseNumber);
 int main(void)
 {
 	int T =0, i= 0;
 	char nl;
 
 	scanf("%d", &T);
 	scanf("%c", &nl);
 
 	for (i = 0; i < T; ++i)
 	{
 		processBoard(i + 1);
 	}
 
 }
 
 void processBoard(int caseNumber)
 {
 	char board[4][4], nl;
 	int rowSum[4];
 	int colSum[4];
 	int diagSum[2];
 	char dummy[32];
 
 	scanf("%c%c%c%c%c", &(board[0][0]), &(board[0][1]), &(board[0][2]), &(board[0][3]), &nl);
 	scanf("%c%c%c%c%c", &(board[1][0]), &(board[1][1]), &(board[1][2]), &(board[1][3]), &nl);
 	scanf("%c%c%c%c%c", &(board[2][0]), &(board[2][1]), &(board[2][2]), &(board[2][3]), &nl);
 	scanf("%c%c%c%c%c", &(board[3][0]), &(board[3][1]), &(board[3][2]), &(board[3][3]), &nl);
 	gets(dummy);
 
 	rowSum[0] = (int)(board[0][0]) + (int)(board[0][1]) + (int)(board[0][2]) + (int)(board[0][3]);
 	rowSum[1] = (int)(board[1][0]) + (int)(board[1][1]) + (int)(board[1][2]) + (int)(board[1][3]);
 	rowSum[2] = (int)(board[2][0]) + (int)(board[2][1]) + (int)(board[2][2]) + (int)(board[2][3]);
 	rowSum[3] = (int)(board[3][0]) + (int)(board[3][1]) + (int)(board[3][2]) + (int)(board[3][3]);
 
 	colSum[0] = (int)(board[0][0]) + (int)(board[1][0]) + (int)(board[2][0]) + (int)(board[3][0]);
 	colSum[1] = (int)(board[0][1]) + (int)(board[1][1]) + (int)(board[2][1]) + (int)(board[3][1]);
 	colSum[2] = (int)(board[0][2]) + (int)(board[1][2]) + (int)(board[2][2]) + (int)(board[3][2]);
 	colSum[3] = (int)(board[0][3]) + (int)(board[1][3]) + (int)(board[2][3]) + (int)(board[3][3]);
 
 	diagSum[0] = (int)(board[0][0]) + (int)(board[1][1]) + (int)(board[2][2]) + (int)(board[3][3]);
 	diagSum[1] = (int)(board[0][3]) + (int)(board[1][2]) + (int)(board[2][1]) + (int)(board[3][0]);
 
 	if (
 			(rowSum[0] == 352) || (rowSum[0] == 348) ||
 			(rowSum[1] == 352) || (rowSum[1] == 348) ||
 			(rowSum[2] == 352) || (rowSum[2] == 348) ||
 			(rowSum[3] == 352) || (rowSum[3] == 348) ||
 
 			(colSum[0] == 352) || (colSum[0] == 348) ||
 			(colSum[1] == 352) || (colSum[1] == 348) ||
 			(colSum[2] == 352) || (colSum[2] == 348) ||
 			(colSum[3] == 352) || (colSum[3] == 348) ||
 
 			(diagSum[0] == 352) || (diagSum[0] == 348) ||
 			(diagSum[1] == 352) || (diagSum[1] == 348)
 	   )
 	{
 		printf("Case #%d: X won\n", caseNumber);
 	}
 	else if (
 			(rowSum[0] == 316) || (rowSum[0] == 321) ||
 			(rowSum[1] == 316) || (rowSum[1] == 321) ||
 			(rowSum[2] == 316) || (rowSum[2] == 321) ||
 			(rowSum[3] == 316) || (rowSum[3] == 321) ||
 
 			(colSum[0] == 316) || (colSum[0] == 321) ||
 			(colSum[1] == 316) || (colSum[1] == 321) ||
 			(colSum[2] == 316) || (colSum[2] == 321) ||
 			(colSum[3] == 316) || (colSum[3] == 321) ||
 
 			(diagSum[0] == 316) || (diagSum[0] == 321) ||
 			(diagSum[1] == 316) || (diagSum[1] == 321) 
 			)
 	{
 		printf("Case #%d: O won\n", caseNumber);
 	}
 	else if (
 			(rowSum[0] < 316) || (rowSum[1] < 316) || (rowSum[2] < 316) || (rowSum[3] < 316) || 
 			(colSum[0] < 316) || (colSum[1] < 316) || (colSum[2] < 316) || (colSum[3] < 316) || 
 			(diagSum[0] < 316) || (diagSum[1] < 316)
 			)
 	{
 		printf("Case #%d: Game has not completed\n", caseNumber);
 	}
 	else
 	{
 		printf("Case #%d: Draw\n", caseNumber);
 	}
 
 	return;
 }

