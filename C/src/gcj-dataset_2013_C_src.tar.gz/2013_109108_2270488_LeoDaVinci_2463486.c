#include<stdio.h>
 #include<math.h>
 #include<string.h>
 #include<stdlib.h>
 #include<memory.h>
 #include<malloc.h>
 #include<limits.h>
 #define ll long long
 #define ull unsigned long long
 #define max(a,b) (a)>(b)?(a):(b)
 #define min(a,b) (a)<(b)?(a):(b)
 int gcd(int a,int b){
 	return b?gcd(b,a%b):a;
 }
 int a[1010];
 int palin(int x){
 	int ar[8],i=0,r,j=0,q=x;
 	while(x>0){
 		r=x%10;
 		ar[i++]=r;
 		x=x/10;
 	}
 	i--;
 	while(i>j){
 		if(ar[i]!=ar[j]) return 0;
 		i--;j++;
 	}
 	return 1;
 }
 void solve(){
 	int i,j,p;
 	for(i=1;i<32;i++){
 		p=i*i;
 		if(palin(i) && palin(p)) a[p]=1;
 	}
 	for(i=1;i<=1000;i++) a[i]+=a[i-1];
 }
 int main()
 {
 	int t,x,y,k=1;
 	solve();
 	scanf("%d",&t);
 	while(t--){
 		scanf("%d%d",&x,&y);
 		printf("Case #%d: %d\n",k,a[y]-a[x-1]);
 		k++;
 	}
 	return 0;
 }

