#include <stdio.h>
 
 int main()
 {
 	int t;
 	scanf("%d",&t);
 	int count=1;
 	while(t--)
 	{
 		int n,m,i,j,flag=1,k;
 		scanf("%d %d",&n,&m);
 		int a[n][m],sumr[n],sumc[m];
 		for(i=0;i<n;i++)
 			sumr[i] = 0;		
 		for(i=0;i<m;i++)
 			sumc[i] = 0;
 		
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				scanf("%d",&a[i][j]);
 			}
 		}
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				int flag1=1,flag2=1;
 				for(k=0;k<m;k++)
 				{
 					if(a[i][j]<a[i][k])
 					{
 						flag1=0;
 						break;
 					}
 				}
 				for(k=0;k<n;k++)
 				{
 					if(a[i][j]<a[k][j])
 					{
 						flag2=0;
 						break;
 					}
 				}
 				if(flag1==0 && flag2==0)
 				{
 					flag = 0;
 					printf("Case #%d: NO\n",count);
 					break;
 				}
 			}
 			if(flag == 0)
 				break;
 		}
 		if(flag == 1)
 			printf("Case #%d: YES\n",count);
 		count++;
 	}
 	return 0;
 }
