#include <stdio.h>
 #include <math.h>
 
 int is_pal(int n)
 {
   int dig;
   char s[100];
   int i;
 
 
   dig = (int)ceil(log10(n));
 
   sprintf(s, "%d", n);
   for (i = 0; i < dig/2; i++)
   {
     if (s[i] != s[dig -i -1])
       return 0;
   }
   return 1;
 }
 
 
 int main()
 {
   int t,T;
   int min, max;
   int n,q;
   scanf("%d\n", &T);
   for(t = 1; t < T+1; t++)
   {
 
     scanf("%d %d", &min, &max);
 
     min = (int)ceil(sqrt(min));
     max = (int)floor(sqrt(max));
 
     q = 0;
     for (n = min; n<=max; n++)
     {
       if (is_pal(n) && is_pal(n*n))
         q++;
     }
     printf ("Case #%d: %d\n", t,q);
   }
   return 0;
 }

