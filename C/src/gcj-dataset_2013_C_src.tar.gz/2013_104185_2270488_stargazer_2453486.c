#include<stdio.h>
 
 int compare(char c1, char c2, char c3, char c4);
 
 int compare(char c1, char c2, char c3, char c4)
 {
 	int flag=1;
 	flag-=(c1!=c2);
 	flag-=(c1!=c3);
 	flag-=(c1!=c4);
 	if (flag<0 || c1=='.'  || c2=='.'  || c3=='.'  || c4=='.')	flag=0;
 	return flag;
 }
 
 int main()
 {
 	int test_case, i, j, k, T;
 	char board[16];
 	char status;
 	scanf("%d",&test_case);
 	getchar();
 	for (i=1; i<=test_case; i++)
 	{
 		T=0, status='D';
 		for (j=0; j<16; j++)
 		{
 			scanf("%c",&board[j]);
 			if (board[j]=='T')	T=j;
 			if (j%4==3)	getchar();
 		}
 		getchar();
 		if (T)	board[T]='X';
 		if (compare(board[0], board[5], board[10], board[15]))	status=board[0];
 		if (compare(board[3], board[6], board[9], board[12]))	status=board[3];
 		for (j=0; j<16; j+=4)
 		{
 			if (compare(board[j], board[j+1], board[j+2], board[j+3]))
 			{
 				status=board[j];
 				goto exit;
 			}
 		}
 		for (k=0; k<4; k++)
 		{
 			if (compare(board[k], board[k+4], board[k+8], board[k+12]))
 			{
 				status=board[k];
 				goto exit;
 			}
 		}
 		if (T)	board[T]='O';
 		if (compare(board[0], board[5], board[10], board[15]))	status=board[0];
 		if (compare(board[3], board[6], board[9], board[12]))	status=board[3];
 		for (j=0; j<16; j+=4)
 		{
 			if (compare(board[j], board[j+1], board[j+2], board[j+3]))
 			{
 				status=board[j];
 				goto exit;
 			}
 		}
 		for (k=0; k<4; k++)
 		{
 			if (compare(board[k], board[k+4], board[k+8], board[k+12]))
 			{
 				status=board[k];
 				goto exit;
 			}
 		}
 		for (j=0; j<16; j++)
 		{
 			if (board[j]=='.' && status=='D')
 			{
 				status='G';
 			}
 		}
 		exit:
 		switch(status)
 		{
 			case 'X':
 				printf("Case #%d: X won\n",i);
 				break;
 			case 'O':
 				printf("Case #%d: O won\n",i);
 				break;
 			case 'D':
 				printf("Case #%d: Draw\n",i);
 				break;
 			case 'G':
 				printf("Case #%d: Game has not completed\n",i);
 				break;
 			default:
 				break;
 		}
 	}
 	return 0;
 }

