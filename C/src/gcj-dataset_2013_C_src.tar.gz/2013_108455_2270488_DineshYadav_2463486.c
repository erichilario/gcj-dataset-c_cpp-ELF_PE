#include<stdio.h>
 #include<math.h>
 #include<malloc.h>
 
 /*
 int isPalindrome( int number)
 {
 	int num ;
 	while( number > 0 )
 	{
 		num = number%10 ;
 		numer = number/10;
 	}
 	
 }
 */
 int isPalindrome( int number)
 {
 	
 	if( number/10 == 0 )
 		return 1 ;
 	else if( number/100 == 0 && number/10 == number%10)
 		return 1;
 	else if(number/100 == number%10)
 		return 1;
 	else
 		return 0 ;
 }
 
 int isFairAndSquare(int number,int maxAll)
 {
 	if( isPalindrome(number) )
 	{
 		int squareNo = number*number ;
 		if( squareNo <= maxAll && isPalindrome(squareNo) == 1)
 		{
 			return squareNo ;
 		}
 		
 	}
 	return -1 ;
 }
 
 int main()
 {
 	int cases = 0 ;
 	FILE *fp = fopen("C-small-attempt0.in","r");
 	FILE *fp1 = fopen("output.txt","w");
 	fscanf(fp,"%d",&cases);
 	int *min = (int*)malloc(sizeof(int)*cases);
 	int *max = (int*)malloc(sizeof(int)*cases);
 	int minAll = 1001;
 	int maxAll = 0 ;
 	int i = 0 ;
 	int FASNumber[32] ;
 	for( i = 0 ; i < cases ; i++ )
 	{
 		fscanf(fp,"%d %d",&min[i],&max[i]);
 		if( min[i] < minAll )
 			minAll = min[i] ;
 		if( max[i] > maxAll)
 			maxAll = max[i];
 	}
 
 	int range = 0 ;
 	int j = 0 ;
 	
         for( range = minAll ; range <= 33 ; range++)
 	{
 		int x = isFairAndSquare(range,maxAll) ;
 		if( x != -1)
 		{
 			FASNumber[j] = x ;
 			//printf("%d\n",FASNumber[j]);
 			j++ ;
 		}
 	}
 
 	for(i = 0 ; i < cases ; i++ )
 	{
 		int count = 0 ;
 		int c = 0 ;
 		for( ;count < j ; count++ )
 		{
 			if((FASNumber[ count ] >= min[i] && FASNumber[count]<= max[i]))
 				c++;
 		}
 	        fprintf(fp1,"Case #%d: %d\n",i+1,c);
 		
 	}
 	fclose(fp);
 	fclose(fp1);	
 
 }

