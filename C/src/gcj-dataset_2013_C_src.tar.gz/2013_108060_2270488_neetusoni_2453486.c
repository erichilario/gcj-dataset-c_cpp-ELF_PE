#include<stdio.h>
 
 int main()
 {
 	int n,i,j,k=0,blank,count,present;
 	scanf("%d",&n);
 	char array[4][4],a,b;
 	char result[n];
 	b=getchar();
 	while(k<n)
 	{	
 		blank=0;
 		count=1;
 		present=0;
 		if(k>=1)
 			scanf("%c",&b);
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				scanf("%c",&array[i][j]);
 				
 				a=array[0][0];
 				if(a!='.')
 				{
 					if(i==j&&i!=0)
 					{
 						if(array[i][j]==a||array[i][j]=='T')
 							count++;
 					}
 				}
 				if(array[i][j]=='.')
 					blank++;
 			}
 			scanf("%c",&b);
 			
 		}
 		if(count==4)
 		{	
 			result[k]=a;
 			k++;
 			continue;
 		}
 		count=1;
 		a=array[0][3];
 		if(a!='.')
 		{
 			j=2;
 			for(i=1;i<4;i++)
 			{
 				if(array[i][j]!=a&&array[i][j]!='T')
 					break;
 				else
 					count++;
 				j--;
 			}
 			if(count==4)
 			{
 				result[k]=a;
 				k++;		
 				continue;
 			}
 		}
 		for(i=0;i<4;i++)
 		{
 			count=1;
 			a=array[i][0];
 			if(a!='.')
 			{
 				for(j=1;j<4;j++)
 				{
 					if(array[i][j]==a||array[i][j]=='T')
 					count++;
 				}
 				if(count==4)
 					break;
 			}
 		}
 		if(count==4)
 		{
 			result[k]=a;
 			k++;
 			continue;
 		}
 
 		for(i=0;i<4;i++)
 		{
 			count=1;
 			a=array[0][i];
 			if(a!='.')
 			{
 				for(j=1;j<4;j++)
 				{
 					if(array[j][i]==a||array[j][i]=='T')
 						count++;
 				}
 				if(count==4)
 				break;
 			}
 		}
 		if(count==4)
 		{
 			result[k]=a;
 			k++;
 			continue;
 		}
 		if(blank!=0)
 			result[k]='b';
 		else
 			result[k]='c';
 		k++;
 	}
 
 for(i=0;i<n;i++)
 
 {
 
 if(result[i]=='b')
 printf("Case #%d: Game has not completed\n",i+1);
 else if(result[i]=='c')
 printf("Case #%d: Draw\n",i+1);
 else if(result[i]=='X'||result[i]=='O')
 printf("Case #%d: %c won\n",i+1,result[i]);
 }
 
 }

