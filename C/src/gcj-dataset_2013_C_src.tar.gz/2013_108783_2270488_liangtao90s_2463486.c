/*
  * =====================================================================================
  *
  *       Filename:  problemCC.c
  *
  *    Description:  i
  *
  *        Version:  1.0
  *        Created:  2013年04月13日 15时35分28秒
  *       Revision:  none
  *       Compiler:  gcc
  *
  *         Author:  梁涛 (suck_it), liangtao90s@gmail.com
  *   Organization:  
  *
  * =====================================================================================
  */
 
 #include <stdio.h>
 #include <math.h>
 
 int record[39] = {1, 2, 3, 11, 22, 101, 111, 121, 202, 212, 1001,
 1111, 2002, 10001, 10101, 10201, 11011, 11111, 11211,  20002, 20102, 
 100001,  101101,  110011,  111111,  200002,  1000001,  1001001, 
 1002001, 1010101, 1011101,  1012101,  1100011,  1101011,  1102011,
 1110111, 1111111, 2000002,  2001002
 };
 
 int main()
 {
 		int T;
 		int i;
 		scanf("%d", &T);
 		for (i = 1; i <= T; i++) {
 				double root;
 				unsigned long long A,  B;
 				int j, k;
 				scanf("%llu%llu", &A, &B);
 				root = sqrt(A);
 				B = sqrt(B);
 				A = root;
 				if (root > (unsigned long long)A)
 						A++;
 				for (j = 0; j < 39; j++)
 						if (record[j] >= A) {
 								break;
 						}
 				for (k = j; k < 39; k++)
 						if (record[k] >= B) {
 								if (record[k] > B)
 										k--;
 								break;
 						}
 
 				printf("Case #%d: %d\n", i, k - j + 1);
 		}
 		return 0;
 }

