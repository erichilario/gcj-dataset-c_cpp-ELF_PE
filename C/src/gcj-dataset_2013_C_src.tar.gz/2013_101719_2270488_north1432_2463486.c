#include <stdio.h>
 #include <math.h>
 #include <string.h>
 
 int check(int a);
 main()
 {
     freopen("C-small-attempt0.in","r",stdin);
     freopen("fairandsquareout.txt","w",stdout);
     int t,test;
     scanf("%d",&test);
     for (t=1;t<=test;t++)
     {
         printf("Case #%d: ",t);
         int a,b,i;
         int count=0,ispal=0;
         scanf("%d%d",&a,&b);
         int roota = ((int) (sqrt(a)+0.9999999)); // ceil up
         int rootb = ((int) sqrt(b)); // floor down
         for (i=roota;i<=rootb;i++)
         {
             ispal = check(i);
             if (ispal == 1)
             {
                 ispal = check(i*i);
                 if (ispal == 1)
                 {
                     count++;
                 }
                 else continue;
             }
             else continue;
         }
         printf("%d\n",count);
     }
 }
 
 int check(int a)
 {
     char c1[20],c2[20];
     sprintf(c1,"%d",a);
     strcpy(c2,c1);
     strrev(c2);
     if (strcmp(c1,c2) == 0)
     {
         return 1;
     }
     else return 0;
 }

