#include <stdio.h>
 
 int main ()
 {
 
 	int a[100][100];
 	FILE *fp;
 	int i, j, k, l, flag, T, m, n;
 
 	fp=fopen("GRASS.out", "w");
 
 	scanf ("%d",&T);
 
 	for (i=0; i<T; i++)
 	{
 		scanf ("%d", &m);
 		scanf ("%d", &n);
 		flag=1;
 
 		for (j=0; j<m; j++)
 			for (k=0; k<n; k++)
 				scanf ("%d", &a[j][k]);
 
 		for (j=0; j<m; j++)
 		{
 			for (k=0; k<n && a[j][k]==a[j][0]; k++);
 			if (k!=n)
 			{
 				for (l=0; l<n && a[l][k]==a[0][k]; l++);
 				if (l!=m)
 				{
 					flag=0;
 					goto ab;
 				}
 			}
 		}
 
 		ab:
 
 		fprintf (fp,"Case #%d: %s\n", i+1, (flag==1)?"YES":"NO");
 	}
 } 
 			

