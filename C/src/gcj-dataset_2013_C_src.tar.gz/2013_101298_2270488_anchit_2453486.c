#include <stdio.h>
 
 int main()
 {
 	int t;
 	scanf("%d",&t);
 	int count=1;
 	while(t--)
 	{
 		int i,j,d[4][4],flag=1,cnt=0;
 		char c[4][5];
 		for(i=0;i<4;i++)
 		{
 			scanf("%s",c[i]);
 		}
 /* 		for(i=0;i<4;i++)
 		{
 			printf("%s",c[i]);
 		} */
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 				d[i][j] = c[i][j] - 'T';
 		}
 		for(i=0;i<4;i++)
 		{
 			if(((d[i][0]+d[i][1]+d[i][2]+d[i][3]==16)||(d[i][0]+d[i][1]+d[i][2]+d[i][3]==12))&&flag)
 			{
 				printf("Case #%d: X won\n",count);
 				flag=0;
 			}
 			else if(((d[i][0]+d[i][1]+d[i][2]+d[i][3]==-15)||(d[i][0]+d[i][1]+d[i][2]+d[i][3]==-20))&&flag)
 			{
 				printf("Case #%d: O won\n",count);
 				flag=0;
 			}
 		}
 		for(i=0;i<4;i++)
 		{
 			if(((d[0][i]+d[1][i]+d[2][i]+d[3][i]==16)||(d[0][i]+d[1][i]+d[2][i]+d[3][i]==12))&&flag)
 			{
 				printf("Case #%d: X won\n",count);
 				flag=0;
 			}
 			else if(((d[0][i]+d[1][i]+d[2][i]+d[3][i]==-15)||(d[0][i]+d[1][i]+d[2][i]+d[3][i]==-20))&&flag)
 			{
 				printf("Case #%d: O won\n",count);
 				flag=0;
 			}
 		}
 		if(((d[0][0]+d[1][1]+d[2][2]+d[3][3]==16)||(d[0][0]+d[1][1]+d[2][2]+d[3][3]==12))||((d[0][3]+d[1][2]+d[2][1]+d[3][0]==16)||(d[0][3]+d[1][2]+d[2][1]+d[3][0]==12))&&flag)
 		{
 			printf("Case #%d: X won\n",count);
 			flag=0;
 		}
 		else if(((d[0][0]+d[1][1]+d[2][2]+d[3][3]==-15)||(d[0][0]+d[1][1]+d[2][2]+d[3][3]==-20))||((d[0][3]+d[1][2]+d[2][1]+d[3][0]==-15)||(d[0][3]+d[1][2]+d[2][1]+d[3][0]==-20))&&flag)
 		{
 			printf("Case #%d: O won\n",count);
 			flag=0;
 		}
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				if(d[i][j]==-38)
 					cnt++;
 			}
 		}
 		if(flag && cnt!=0)
 			printf("Case #%d: Game has not completed\n",count);
 		else if(flag)
 			printf("Case #%d: Draw\n",count);
 		count++;
 		getchar();
 	}
 	return 0;
 }
