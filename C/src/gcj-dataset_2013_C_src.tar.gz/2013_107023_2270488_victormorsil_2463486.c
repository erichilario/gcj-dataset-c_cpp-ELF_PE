#include<stdio.h>
 main(){
     int t, i;
     int a, b, cont=0;
 
     scanf("%d", &t);
 
     for(i=0; i<t; i++){
             cont=0;
             scanf("%d %d", &a, &b);
             if(a<=1 && 1<=b) cont++;
             if(a<=4 && 4<=b) cont++;
             if(a<=9 && 9<=b) cont++;
             if(a<=121 && 121<=b) cont++;
             if(a<=242 && 242<=b) cont++;
             if(a<=14641 && 14641<=b) cont++;
 
             printf("Case #%d: %d\n", i+1, cont);
     }
 }

