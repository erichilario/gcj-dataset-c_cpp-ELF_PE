//A-small-attempt0
 #include<stdio.h>
 int status(char board[4][4],int player)
 {
     if(player==1)
     {
         int i,j,k;
         // row check
         for(j=0;j<4;j++)
         {
             int flag=0;
             for(k=0;k<4;k++)
             {
                 if(board[j][k]=='X'||board[j][k]=='T')
                 continue;
                 else
                 flag=1;
             }
             if(flag==0) return 1;
         }
         // column check
         for(j=0;j<4;j++)
         {
             int flag=0;
             for(k=0;k<4;k++)
             {
                 if(board[k][j]=='X'||board[k][j]=='T')
                 continue;
                 else
                 flag=1;
             }
             if(flag==0) return 1;
         }
         // principle diognal
         int dia=0;
         for(j=0;j<4;j++)
         {
             if(board[j][j]=='X'||board[j][j]=='T')
             continue;
             else
             dia=1;
         }
         if(!dia) return 1;
         // secondary diagonal
         int dia2=0;
         for(j=0;j<4;j++)
         {
             if(board[j][3-j]=='X'||board[j][3-j]=='T')
             continue;
             else
             dia2=1;
         }
         if(!dia2) return 1;
         // not winning
         return 0;
     }
     if(player==2)
     {
         int i,j,k;
         // row check
         for(j=0;j<4;j++)
         {
             int flag=0;
             for(k=0;k<4;k++)
             {
                 if(board[j][k]=='O'||board[j][k]=='T')
                 continue;
                 else
                 flag=1;
             }
             if(flag==0) return 1;
         }
         // column check
         for(j=0;j<4;j++)
         {
             int flag=0;
             for(k=0;k<4;k++)
             {
                 if(board[k][j]=='O'||board[k][j]=='T')
                 continue;
                 else
                 flag=1;
             }
             if(flag==0) return 1;
         }
         // principle diognal
         int dia=0;
         for(j=0;j<4;j++)
         {
             if(board[j][j]=='O'||board[j][j]=='T')
             continue;
             else
             dia=1;
         }
         if(!dia) return 1;
         // secondary diagonal
         int dia2=0;
         for(j=0;j<4;j++)
         {
             if(board[j][3-j]=='O'||board[j][3-j]=='T')
             continue;
             else
             dia2=1;
         }
         if(!dia2) return 1;
         // not winning
         return 0;
     }
 }
 int nodot(char board[4][4])
 {
     int j,k;
     for(j=0;j<4;j++)
     {
         for(k=0;k<4;k++)
         {
             if(board[j][k]=='.')return 0;
         }
     }
     return 1;
 }
 int main()
 {
     FILE *fp = fopen("A-large.in","r");
     FILE *fout = fopen("A-small-attempt0.txt","w");
     int t,i;
     char board[4][4];
     fscanf(fp,"%d",&t);
     //printf("%d",t);
     for(i=1;i<=t;i++)
     {
         int j,k;
         for(j=0;j<4;j++)
         {
             for(k=0;k<4;k++)
             {
                 char c;
                 fscanf(fp,"%c",&c);
                 //fscanf(fp,"%c",&board[j][k]);
                 while(c==' '||c=='\n'||c=='\t')
                 {
                     //printf("%c",c);
                     fscanf(fp,"%c",&c);
                 }
                 board[j][k]=c;//printf("%c",c);
             }
         }
         int o = status(board,2);
         int x = status(board,1);
         int dot = nodot(board);
         if(o) fprintf(fout,"Case #%d: O won\n",i);
         else
         if(x) fprintf(fout,"Case #%d: X won\n",i);
         else
         if(dot==0) fprintf(fout,"Case #%d: Game has not completed\n",i);
         else fprintf(fout,"Case #%d: Draw\n",i);
     }
 }

