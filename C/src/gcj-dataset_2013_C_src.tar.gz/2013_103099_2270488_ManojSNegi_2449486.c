#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define N 100
 #define M 100
 
 int board[M][N];
 
 void processBoard(int caseNumber);
 int main(void)
 {
 	int T = 0, i = 0;
 
 	scanf("%d", &T);
 
 	for (i = 0; i < T; ++i)
 	{
 		processBoard(i + 1);
 	}
 
 	return 1;
 }
 
 int check(int i, int j, int n, int m)
 {
 	int x = 0, y = 0;
 	int val = board[i][j];
 
 	for (x = 0; x < n; ++x)
 	{
 		if (board[x][j] > val)
 		{
 			for (y = 0; y < m; ++y)
 			{
 				if (board[i][y] > val)
 				{
 					return 1;
 
 				}
 			}
 		}
 	}
 	return 0;
 }
 
 void processBoard(int caseNumber)
 {
 	int m = 0, n = 0, i,j;
 	scanf("%d %d", &n, &m);
 
 	for (i = 0 ; i < n ; ++i)
 	{
 		for (j = 0 ; j < m ; ++j)
 		{
 			scanf("%d", &board[i][j]);
 		}
 	}
 
 	for (i = 0 ; i < n ; ++i)
 	{
 		for (j = 0 ; j < m ; ++j)
 		{
 			if (check(i, j , n, m) == 1)
 			{
 				printf("Case #%d: NO\n", caseNumber);
 				return;
 			}
 		}
 	}
 
 	printf("Case #%d: YES\n", caseNumber);
 	return;
 }

