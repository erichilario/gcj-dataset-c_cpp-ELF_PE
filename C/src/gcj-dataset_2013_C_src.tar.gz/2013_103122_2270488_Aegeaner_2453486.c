#include <stdio.h>
 
 char board[4][4];
 int T;
 
 int atom_check(char ch)
 {
 	if(ch == 'X')
 		return 1;
 	else if(ch == 'O')
 		return 2;
 	else if(ch == 'T')
 		return 3;
 	else
 		return 4;
 }
 
 int check(char a, char b, char c, char d)
 {
 	if(!(atom_check(b)&atom_check(a)))
 		return -1;
 	if(!(atom_check(c)&atom_check(b)))
 		return -1;
 	if(!(atom_check(d)&atom_check(c)))
 		return -1;
 	if(!(atom_check(c)&atom_check(a)))
 		return -1;
 	if(!(atom_check(d)&atom_check(a)))
 		return -1;
 	if(!(atom_check(d)&atom_check(b)))
 		return -1;
 	return atom_check(b)&atom_check(a);
 }
 
 int main()
 {
 	int i, j, k;
 	int flag;
 	
 	freopen("A-small-attempt1.in", "r", stdin);
 	freopen("A-small-attempt1.out", "w", stdout);
 
 	scanf("%d", &T);
 
 	for(i=0; i<T; i++)
 	{
 		getchar();
 		for(j=0; j<4; j++)
 		{
 			for(k=0; k<4; k++)
 			{
 				scanf("%c", &board[j][k]);
 			}
 			getchar();
 		}
 		flag = 0;
 
 		for(j=0; j<4; j++)
 			{
 				int result = check(board[j][0],
 					board[j][1],
 					board[j][2],
 					board[j][3]);
 				if(result == 1)
 				{
 					printf("Case #%d: X won\n", i+1);
 					flag = 1;
 					break;
 				} else if(result == 2)
 				{
 					printf("Case #%d: O won\n", i+1);
 					flag = 1;
 					break;
 				}
 			}
 		if(flag)
 			continue;
 			
 		for(j=0; j<4; j++)
 			{
 				int result = check(board[0][j],
 					board[1][j],
 					board[2][j],
 					board[3][j]);
 				if(result == 1)
 				{
 					printf("Case #%d: X won\n", i+1);
 					flag = 1;
 					break;
 				} else if(result == 2)
 				{
 					printf("Case #%d: O won\n", i+1);
 					flag = 1;
 					break;
 				}
 			}
 		if(flag)
 			continue;
 			
 		{
 			int result = check(board[0][0],
 					board[1][1],
 					board[2][2],
 					board[3][3]);
 				if(result == 1)
 				{
 					printf("Case #%d: X won\n", i+1);
 					flag = 1;
 				} else if(result == 2)
 				{
 					printf("Case #%d: O won\n", i+1);
 					flag = 1;
 				}
 		}
 		if(flag)
 			continue;
 			
 		{
 			int result = check(board[0][3],
 					board[1][2],
 					board[2][1],
 					board[3][0]);
 				if(result == 1)
 				{
 					printf("Case #%d: X won\n", i+1);
 					flag = 1;
 				} else if(result == 2)
 				{
 					printf("Case #%d: O won\n", i+1);
 					flag = 1;
 				}
 		}
 		if(flag)
 			continue;
 			
 		for(j=0; j<4; j++)
 		{
 			for(k=0; k<4; k++)
 			{
 				if(board[j][k] == '.')
 				{
 					printf("Case #%d: Game has not completed\n", i+1);
 					flag = 1;
 					break;
 				}
 			}
 			if(flag)
 				break;
 		}
 		if(flag)
 			continue;
 			
 		printf("Case #%d: Draw\n", i+1);
 	}
 }

