#include<stdio.h>
 #include<math.h>
 
 int ispal(int n)
 {
   int m=n;
 int x=0,z=0;
   while(m){z++;m/=10;}
 	//printf("%d\n",z);
 m=n;
 	while(z)
 	{
 	  x+=(n%10)*(int)pow(10,z-1);
 		n/=10; 
 	z--;
 	
 		}
 
 if(x==m)
   return 1;
 else return 0;
 
 }
 
 void main()
 {
   int t,a,b,n,count,k;
   float y,x;
   scanf("%d",&t);
 k=t;
 while(t--)
 {
 	
 	scanf("%d %d",&a,&b);
         n=a;
       count=0;
 while(n<=b)
 {
 	if(ispal(n))
 	{
 	  	y=sqrt(n);
 		x=y-(int)y;
 		if(x==0)
 		  {
 		     if(ispal(y))
 		       count++;
 		  }
 	}		
 n++;
 }
  printf("Case #%d: %d\n",k-t,count);
 }
 }

