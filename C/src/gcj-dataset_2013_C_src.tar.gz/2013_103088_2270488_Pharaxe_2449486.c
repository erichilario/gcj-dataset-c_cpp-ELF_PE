#include <iostream>
 #include <cstdlib>
 
 using namespace std;
 
 int *lawn;
 int testCases;
 int rows, cols;
 
 int getGrassLength(int x, int y);
 void setGrassLength(int x, int y, int val);
 bool solve();
 
 int *maxCol;
 int *maxRow;
 
 int main() {
    lawn = 0;
    int len;
 
    cin >> testCases;
    
    for (int t = 1; t < testCases + 1; t++) {
       cin >> rows >> cols;
       lawn = (int*)malloc(rows * cols * sizeof(int));
       maxCol = (int*)malloc(cols * sizeof(int));
       maxRow = (int*)malloc(rows * sizeof(int));
 
 
       for (int x = 0; x < cols; x++) {
          maxCol[x] = -1;
       }
       for (int y = 0; y < rows; y++) {
          maxRow[y] = -1;
       }
 
       for (int y = 0; y < rows; y++) {
          for (int x = 0; x < cols; x++) {
             cin >> len;
             setGrassLength(x, y, len);
             maxRow[y] = max(maxRow[y], len);
             maxCol[x] = max(maxCol[x], len);
          }
       }
       /*
       for (int y = 0; y < rows; y++) {
          for (int x = 0; x < cols; x++) {
             cout << getGrassLength(x, y) << ", ";
          }
          cout << endl;
       }
       cout << "rows: " << endl;
       for (int y = 0; y < rows; y++) {
          cout << maxRow[y] << endl;
       }
       cout << "cols: " << endl;
       for (int x = 0; x < cols; x++) {
          cout << maxCol[x]  << endl;
       }
       */
 
       cout << "Case #" << t << ": ";
       if (solve()) {
          cout << "YES";
       } else {
          cout << "NO";
       }
       free(maxRow);
       free(maxCol);
       free(lawn);
       cout << endl;
    }
 }
 
 bool solve() {
    for (int x = 0; x < cols; x++) {
       for (int y = 0; y < rows; y++) {
          int myLength = getGrassLength(x, y);
 
          if (myLength < maxRow[y] && myLength < maxCol[x]) {
             return false;
          }
       }
    }
 
    return true;
 }
 
 int getGrassLength(int x, int y) {
    return *(lawn + x + y * cols);
 }
 
 void setGrassLength(int x, int y, int val) {
    *(lawn + x + y * cols) = val;
 }

