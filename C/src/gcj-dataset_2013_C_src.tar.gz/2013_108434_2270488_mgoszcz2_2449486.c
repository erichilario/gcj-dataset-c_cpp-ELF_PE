#include <stdio.h>
 #include <stdbool.h>
 
 long l[101][101], at, len;
 
 void solve(){
     long n, m, i, j, t, c;
     scanf("%ld %ld\n", &n, &m);
 
     for(i = 0; i < n; ++i){
         for(j = 0; j < m-1; ++j){
             scanf("%ld ", &(l[i][j]));
         }
         scanf("%ld\n", &(l[i][m-1]));
     }
 
     for(i = 0; i < n; ++i){
         for(j = 0; j < m; ++j){
             c = 2;
             //Right
             for(t = 0; t < m; ++t){
                 if(l[i][t] > l[i][j]){
                     --c;
                     break;
                 }
             }
 
             //Down
             for(t = 0; t < n; ++t){
                 if(l[t][j] > l[i][j]){
                     --c;
                     break;
                 }
             }
 
             if(c == 0){
                 goto exit_loops;
             }
         }
     }
     printf("Case #%ld: YES\n", at+1);
     return;
     exit_loops:;
     printf("Case #%ld: NO\n", at+1);
 }
 
 int main(void){
     scanf("%ld\n", &len);
 
     for(at = 0; at < len; ++at){
         solve();
     }
     return 0;
 }
