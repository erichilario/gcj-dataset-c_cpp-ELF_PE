#include<stdio.h>
 #include<math.h>
 int palindrome(long int n)
 {
 	long int t,m,r;
 	t=n;
 	m=0;
 	while(t!=0)
 	{
 		r=t%10;
 		m=(m*10)+r;
 		t/=10;
 	}
 	if(m==n)
 	{
 		return 1;
 	}
 	return 0;
 }
 		
 		
 int main()
 {
 	int n;
 	long int l[110][2],i,count,res[110],j;
 	scanf("%d",&n);
 	for(i=0;i<n;i++)
 	{
 		scanf("%d %d",&l[i][0],&l[i][1]);
 		//printf("a\a=%d\n",l[i][0]);
 		//printf("b=%d\n",l[i][1]);
 	}
 	
 	for(i=0;i<n;i++)
 	{
 		count=0;
 		/*printf("###################################\n");
 		printf("a\a=%d\n",l[i][0]);
 		printf("b=%d\n",l[i][1]);
 		printf("###################################\n");
 		printf("a\a=%ld\n",(long int) sqrt(l[i][0]));
 		printf("b=%ld\n",(long int)sqrt(l[i][1]));*/
 		for(j=(long int)sqrt((l[i][0]));j<=(long int)sqrt(l[i][1])+1;j++)
 		{
 			//printf("j=%d\n",j);
 			if(palindrome(j)==1 && palindrome((j*j))==1 && (j*j)>=l[i][0] && (j*j)<=l[i][1])
 			{
 				count++;
 				//printf("number=%d\n",j);
 				//getchar();
 			}
 		}
 		res[i]=count;
 	}
 	for(i=0;i<n;i++)
 	{
 		printf("Case #%d: %d\n",(i+1),res[i]);		
 	}
 	
 	return 0;
 }

