#include <stdio.h>
 #include <stdlib.h>
 
 void printBoard(int board[4][4]);
 
 int judgeRow(int board[4][4]);
 int judgeCol(int board[4][4]);
 int judgeDiagR(int board[4][4]);
 int judgeDiagL(int board[4][4]);
 
 
 int main(int argc, char *argv[]) {
   FILE *fp;
   /* char *filename = "test.in"; */
   /* char *filename = "A-small-attempt0.in"; */
   /* char *filename = "A-small-attempt1.in"; */
   /* char *filename = "A-small-attempt2.in"; */
   char *filename = "A-small-attempt3.in";
   char *result[10] = {"X won", "O won", "Draw", "Game has not completed"};
   
   int ch, row = 0, col = 0, space = 0, prod, num;
   int board[4][4];
 
   /* FILE OPEN */
   if ((fp = fopen(filename, "r")) == NULL) {
     fprintf(stderr, "%s FILE OPEN ERROR.\n", filename);
     exit(EXIT_FAILURE);
   }
 
   char num_string[10];
   int i_count = 0, j_count = 0;
   
 
   while ((ch = fgetc(fp)) != EOF && ch!='\n') {
     num_string[i_count] = ch;
     i_count++;
   }
 
   num = atoi(num_string);
   /* puts(num_string); */
 
   for (row=0; row<4; ++row) {
     for (col=0; col<4; ++col) {
       board[row][col] = 0;
     }
   }
 
   while ((ch = fgetc(fp)) != EOF) {
     row = space / 4;
     col = space % 4;
 
     
     switch (ch) {
     case 'X':
       board[row][col] = 2;
       /* printf("X"); */
       break;
     case 'O':
       board[row][col] = 3;
       /* printf("O"); */
       break;
     case 'T':
       board[row][col] = 5;
       /* printf("T"); */
       break;
     case '.':
       board[row][col] = 0;
       /* printf("."); */
       break;
     case '\n':
       /* printf("\n"); */
       space--;
       break;
     default:
       break;
     }
 
     if (space != 15)
       space++;
     else{
       j_count++;
       
       space = 0;
       
       /* printBoard(board); */
 
       prod = judgeRow(board) * judgeCol(board) * judgeDiagL(board) * judgeDiagR(board);
 
       printf("Case #%d: ", j_count);
       
       if (!(prod%2))
         puts(result[0]);
       else if (!(prod%3))
         puts(result[1]);
       else if (!(prod%7))
         puts(result[3]);
       else if (!(prod%5))
         puts(result[2]);
     }
   }
 
   /* FILE CLOSE */
   fclose(fp);
 
 
   return 0;
 }
 
 void printBoard(int board[4][4]) {
   int row, col;
   for (row=0; row<4; ++row) {
     for (col=0; col<4; ++col) {
       printf("%d", board[row][col]);
     }
     puts("");
   }
 }
 
 
 int judgeRow(int board[4][4]) {
   int prod = 1, row, col, drawFlag = 0;
   for (row=0; row<4; ++row) {
     for (col=0; col<4; ++col) {
       prod *= board[row][col];
     }
 
     switch (prod) {
     case 16:
     case 40:
       return 2;
     case 81:
     case 135:
       return 3;
     case 0:
       drawFlag = 1;
     default:
       prod = 1;
       break;
     }
   }
 
   if (drawFlag)
     return 7;
   else
     return 5;
 }
 
 int judgeCol(int board[4][4]) {
   int prod = 1, row, col, drawFlag = 0;
   for (col=0; col<4; ++col) {
     for (row=0; row<4; ++row) {
       prod *= board[row][col];
     }
 
     switch (prod) {
     case 16:
     case 40:
       return 2;
     case 81:
     case 135:
       return 3;
     case 0:
       drawFlag = 1;
     default:
       prod = 1;
       break;
     }
   }
 
   if (drawFlag)
     return 7;
   else
     return 5;
 }
 
 int judgeDiagR(int board[4][4]) {
   int prod = 1, i_count, drawFlag = 0;
 
   for (i_count=0; i_count<4; ++i_count)
     prod *= board[i_count][i_count];
 
   switch (prod) {
   case 16:
   case 40:
     return 2;
   case 81:
   case 135:
     return 3;
   case 0:
     drawFlag = 1;
   default:
     prod = 1;
     break;
   }
 
   if (drawFlag)
     return 7;
   else
     return 5;
 }
 
 int judgeDiagL(int board[4][4]) {
   int prod = 1, i_count, drawFlag = 0;
 
   for (i_count=0; i_count<4; ++i_count)
     prod *= board[i_count][3-i_count];
   
   switch (prod) {
   case 16:
   case 40:
     return 2;
   case 81:
   case 135:
     return 3;
   case 0:
     drawFlag = 1;
   default:
     prod = 1;
     break;
   }
 
   if (drawFlag)
     return 7;
   else
     return 5;
 }

