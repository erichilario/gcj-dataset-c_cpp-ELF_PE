#include<stdio.h>
 #include<math.h>
 
 int ispal(int a)
 {
     int t,d,r;
     r=0;
     t=a;
     do{
         r=r*10+t%10;
         t/=10;
     }while(t);
     if(a==r)
         return 1;
     else
         return 0;
 }
 int main(int argc,char** argv)
 {
 	FILE *fpin,*fpout;
     int c=1,t,l,m,v,count;
     
     
     fpin=fopen(argv[1],"r");
     fpout=fopen(argv[2],"w");
     fscanf(fpin,"%d",&t);
     
     do{
         count=0;
         fscanf(fpin,"%d%d",&l,&m);
         v=sqrt(l);
         if(v*v<l)
             ++v;
         for(;v*v<=m;++v){
             if(ispal(v))
             {
                 if(ispal(v*v))
                     count++;
             }
         }
         fprintf(fpout,"Case #%d: %d\n",c++,count);
         --t;
     }while(t);
     
     
     
     
     close(fpin);
     close(fpout);
 }

