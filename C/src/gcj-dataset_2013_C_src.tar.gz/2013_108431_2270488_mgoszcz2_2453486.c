#include <stdio.h>
 #include <stdbool.h>
 #define X 88
 #define O 79
 #define N 46
 #define T 84
 
 long len, at;
 
 bool printWon(long xs, long os){
     if(xs > 3 && os > 3){
         printf("Case #%ld: Draw\n", at+1);
         return true;
     }else if(xs > 3){
         printf("Case #%ld: X won\n", at+1);
         return true;
     }else if(os > 3){
         printf("Case #%ld: O won\n", at+1);
         return true;
     }
     return false;
 }
 
 void solve(void){
     char b[4][4];
     long i, j, xs, os;
     bool fin = true;
 
     for(i = 0; i < 4; ++i){
         scanf("%c%c%c%c\n\n", &(b[i][0]), &(b[i][1]), &(b[i][2]), &(b[i][3]));
         if(b[i][0] == N || b[i][1] == N || b[i][2] == N || b[i][3] == N) fin = false;
     }
 
     //Horizontal
     for(i = 0; i < 4; ++i){
         xs = 0;
         os = 0;
         for(j = 0; j < 4; ++j){
             if(b[i][j] == X) ++xs;
             if(b[i][j] == O) ++os;
             if(b[i][j] == T) ++xs, ++os;
         }
         if(printWon(xs, os)) return;
     }
 
     //Vertical
     for(i = 0; i < 4; ++i){
         xs = 0;
         os = 0;
         for(j = 0; j < 4; ++j){
             if(b[j][i] == X) ++xs;
             if(b[j][i] == O) ++os;
             if(b[j][i] == T) ++xs, ++os;
         }
         if(printWon(xs, os)) return;
     }
 
     //Across descending
     xs = 0;
     os = 0;
     for(i = 0; i < 4; ++i){
         if(b[i][i] == X) ++xs;
         if(b[i][i] == O) ++os;
         if(b[i][i] == T) ++xs, ++os;
     }
     if(printWon(xs, os)) return;
 
     //Across ascending
     xs = 0;
     os = 0;
     for(i = 0; i < 4; ++i){
         if(b[3-i][i] == X) ++xs;
         if(b[3-i][i] == O) ++os;
         if(b[3-i][i] == T) ++xs, ++os;
     }
     if(printWon(xs, os)) return;
 
     if(fin){
         printf("Case #%ld: Draw\n", at+1);
     }else{
         printf("Case #%ld: Game has not completed\n", at+1);
     }
 }
 
 int main(void){
     scanf("%ld\n", &len);
 
     for(at = 0; at < len; ++at){
         solve();
     }
 
     return 0;
 }
