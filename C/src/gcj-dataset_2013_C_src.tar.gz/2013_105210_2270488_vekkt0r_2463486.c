#include <stdio.h>
 #include <stdint.h>
 #include <stdbool.h>
 #include <math.h>
 #include <string.h>
 
 uint16_t fandfs[] = {
    1, 4, 9, 121, 484, 676
 };
 
 static bool s_bIsFair(uint16_t u16)
 {
    char acReadable[10];
 
    snprintf(acReadable, 10, "%hu", u16);
 
    uint16_t len = strlen(acReadable);
 
    for (uint16_t i = 0; i < len/2; ++i)
    {
       if (acReadable[i] != acReadable[len-i-1])
       {
          return false;
       }
    }
 
    return true;
 }
 
 // John D. Cook s code
 static bool s_bIsSquare(uint16_t n, uint16_t *u16Square)
 {
    int h = n & 0xF; // last hexidecimal "digit"
    if (h > 9)
       return false; // return immediately in 6 cases out of 16.
 
    // Take advantage of Boolean short-circuit evaluation
    if ( h != 2 && h != 3 && h != 5 && h != 6 && h != 7 && h != 8 )
    {
       // take square root if you must
       int t = (int) floor( sqrt((double) n) + 0.5 );
       if (t*t == n)
       {
          *u16Square = t;
          return true;
       }
 
       return false;
    }
 
    return false;
 }
 
 static uint16_t s_u16Solve(uint16_t u16Min, uint16_t u16Max)
 {
    uint16_t u16Res = 0;
    uint16_t u16Square = 0;
 
    for (uint16_t t = u16Min; t <= u16Max; ++t)
    {
       if (s_bIsFair(t) &&
           s_bIsSquare(t, &u16Square) &&
           s_bIsFair(u16Square))
       {
          u16Res++;
       }
    }
 
    return u16Res;
 }
 
 int main(int argc, char *argv[])
 {
    uint16_t u16Cases;
 
    scanf("%hu", &u16Cases);
 
    for (int i = 0; i < u16Cases; ++i)
    {
       uint16_t u16Min;
       uint16_t u16Max;
       
       scanf("%hu %hu", &u16Min, &u16Max);
       
       printf("Case #%d: %d\n", i + 1, s_u16Solve(u16Min, u16Max));
    }
 
    return 0;
 }

