#include <stdio.h>
 
 int MIN(int p, int q) { return p<q?p:q;}
 int N,M,h[100][100];
 
 
 int main() {
   int W, i,j,k,m,ok,b[200];
   scanf("%d", &W);
   for(i=0;i<W;i++) {
     scanf("%d %d", &N,&M);
     for(j=0;j<N;j++) for(k=0;k<M;k++) scanf("%d", &h[j][k]);
     for(m=0;m<(1<<(N+M));m++) {
       for(j=0;j<N+M;j++) b[j]=((m>>j)&1) + 1;
       ok=1;
       for(j=0;j<N && ok;j++) for(k=0;k<M && ok;k++) if(MIN(b[j],b[N+k])!=h[j][k]) ok=0;
       if(ok) {printf("Case #%d: YES\n",i+1); break; }
     }
     if(!ok) printf("Case #%d: NO\n",i+1);
   }
   return 0;
 }

