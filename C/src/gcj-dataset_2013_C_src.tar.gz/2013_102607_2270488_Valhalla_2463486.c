#include <stdio.h>
 #include <math.h>
 
 int main() {
 
 	unsigned long long int cases = 1, a, b, sum, n, tmp, num, rev, tmp2, rev2;
 
 	scanf("%lld", &num);
 	while (num--) {
 		scanf("%lld %lld", &a, &b);
 		sum = 0;
 		for (n = a; n <= b; n++) {
 			if (sqrt(n) != (unsigned long long int) sqrt(n))
 				continue;
 			rev = rev2 = 0;
 			tmp = n;
 			tmp2 = sqrt(n);
 			while (tmp != 0 || tmp2 != 0) {
 				if (tmp != 0) {
 					rev = rev*10;
 					rev += tmp%10;
 					tmp /= 10;
 				}
 				if (tmp2 != 0) {
 					rev2 = rev2*10;
 					rev2 += tmp2%10;
 					tmp2 /= 10;
 				}
 			}
 
 			if (rev == n && rev2 == sqrt(n)) sum++;
 		}
 		printf("Case #%d: %d\n", cases++, sum);
 	}
 
 	return 0;
 }

