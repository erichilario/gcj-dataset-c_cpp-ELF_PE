# include <stdio.h>
 # include <stdlib.h>
 
 
 
 int main(){
 		
 	int tc,cc;
 	char arr[4][4];
 	scanf("%d",&cc);
 	int cc1=cc;
 	for(tc=1;tc<=cc1;tc++){
 		
 		int j,i,dc=0,flag=0;
 		
 		for(i=0;i<4;i++){
 
 			scanf("%s",arr[i]);
 			for(j=0;j<4;j++){
 				if(arr[i][j]=='.'){
 					dc++;
 				}
 			}
 		}
 		
 		//checking rows
 		for(i=0;i<4;i++){
 			if((arr[i][0]=='O'||arr[i][0]=='T') && (arr[i][1]=='O'||arr[i][1]=='T') && (arr[i][2]=='O'||arr[i][2]=='T') && (arr[i][3]=='O'||arr[i][3]=='T')){
 				printf("Case #%d: O won\n",tc);
 				flag=1;
 			}
 			else if((arr[i][0]=='X'||arr[i][0]=='T') && (arr[i][1]=='X'||arr[i][1]=='T') && (arr[i][2]=='X'||arr[i][2]=='T') && (arr[i][3]=='X'||arr[i][3]=='T')){
 				printf("Case #%d: X won\n",tc);
 				flag=1;
 			}
 		}
 		//checking cols
 		for(i=0;i<4;i++){
 			if(!flag &&(arr[0][i]=='O'||arr[0][i]=='T') && (arr[1][i]=='O'||arr[1][i]=='T') && (arr[2][i]=='O'||arr[2][i]=='T') && (arr[3][i]=='O'||arr[3][i]=='T')){
 				printf("Case #%d: O won\n",tc);
 				flag=1;
 			}
 			else if(!flag &&(arr[0][i]=='X'||arr[0][i]=='T') && (arr[1][i]=='X'||arr[1][i]=='T') && (arr[2][i]=='X'||arr[2][i]=='T') && (arr[3][i]=='X'||arr[3][i]=='T')){
 				printf("Case #%d: X won\n",tc);
 				flag=1;
 			}
 		}
 		//checking digs
 		if(!flag && (arr[0][0]=='O'||arr[0][0]=='T') && (arr[1][1]=='O'||arr[1][1]=='T') && (arr[2][2]=='O'||arr[2][2]=='T') && (arr[3][3]=='O'||arr[3][3]=='T')){
 			printf("Case #%d: O won\n",tc);
 			flag=1;
 		}
 		else if(!flag &&(arr[0][0]=='X'||arr[0][0]=='T') && (arr[1][1]=='X'||arr[1][1]=='T') && (arr[2][2]=='X'||arr[2][2]=='T') && (arr[3][3]=='X'||arr[3][3]=='T')){
 			printf("Case #%d: X won\n",tc);
 			flag=1;
 		}
 		else if(!flag &&(arr[0][3]=='O'||arr[0][3]=='T') && (arr[1][2]=='O'||arr[1][2]=='T') && (arr[2][1]=='O'||arr[2][1]=='T') && (arr[3][0]=='O'||arr[3][0]=='T')){
 			printf("Case #%d: O won\n",tc);
 			flag=1;
 		}
 		else if(!flag &&(arr[0][3]=='X'||arr[0][3]=='T') && (arr[1][2]=='X'||arr[1][2]=='T') && (arr[2][1]=='X'||arr[2][1]=='T') && (arr[3][0]=='X'||arr[3][0]=='T')){
 			printf("Case #%d: X won\n",tc);
 			flag=1;
 		}
 		if(flag==0){
 			if(dc>0){
 				printf("Case #%d: Game has not completed\n",tc);
 			}
 			else{
 				printf("Case #%d: Draw\n",tc);
 			}
 		}
 	}
 	return 0;
 }
