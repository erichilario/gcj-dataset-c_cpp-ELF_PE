#include <stdlib.h>
 #include <stdio.h>
 
 #include <stdbool.h>
 #include <math.h>
 
 
 
 char buffer[BUFSIZ];
 
 typedef long long unsigned int lluint;
 
 //NOTE: This function shameless copied from:
 // http://stackoverflow.com/questions/1398601/can-i-rely-on-this-to-judge-a-square-number-in-c
 // Finds the integer square root of a positive number
 lluint isqrt(lluint num)
 {
     if (0 == num) { return 0; }  // Avoid zero divide
     lluint n = (num / 2) + 1;       // Initial estimate, never low
     lluint n1 = (n + (num / n)) / 2;
     while (n1 < n)
     {
         n = n1;
         n1 = (n + (num / n)) / 2;
     }
     return n;
 }
 
 bool palindrone(lluint i)
 {
 	int len = sprintf(buffer, "%llu", i);
 	for (int i = 0; i < len/2; ++i)
 	{
 		if (buffer[i] != buffer[len-1-i])
 		{
 			fprintf(stderr, "%s is not a palindrone\n", buffer);
 			return false;
 		}
 	}
 	fprintf(stderr, "%s is a palindrone\n", buffer);
 	return true;
 }
 
 bool fair_and_square(lluint i)
 {
 	if (!palindrone(i))
 		return false;
 	lluint s = isqrt(i);
 	if (s * s != i)
 	{
 		fprintf(stderr, "%llu is not a square number\n", i);
 		return false;
 	}
 	
 	return palindrone(s);
 	
 }
 
 int main(int argc, char ** argv)
 {
 	int nCases = 0;
 	fgets(buffer, sizeof(buffer), stdin);
 	sscanf(buffer, "%d", &nCases);
 	
 	for (int c = 1; c < nCases+1; ++c)
 	{
 		lluint count = 0;
 		lluint start; lluint end;
 		fgets(buffer, sizeof(buffer), stdin);
 		sscanf(buffer, "%llu %llu", &start, &end);
 		
 		for (lluint i = start; i <= end; ++i)
 		{
 			if (fair_and_square(i))
 				++count;
 		}
 		
 		fprintf(stdout, "Case #%d: %d\n", c, count);
 	}
 	return 0;
 }
