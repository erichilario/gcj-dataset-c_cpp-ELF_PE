#include<stdio.h>
 #include<string.h>
 #include<stdlib.h>
 int main(void)
 {
   int t,count,lower,upper,times,i;
   int fns[]={1,4,9,121,484};
   char here;
   FILE *fin,*fout;
   fin=fopen("C-small-attempt0.in","r");
   fout=fopen("ojam.txt","w");
   
   //to get the number of test cases
   fscanf(fin,"%d",&t);
   //printf("no of test cases are %d",t);
   
   //initializing cases
   count=0;
   
   //looping
   while(fscanf(fin,"%c",&here)!=EOF)
   {
     count++;
     times=0;
     //lower limit
     fscanf(fin,"%d",&lower);
     //skip space
     fscanf(fin,"%c",&here);
     //upper limit
     fscanf(fin,"%d",&upper);
     
     //check for fair and square nos within range
     for(i=0;i<5;i++)
       if(fns[i]>=lower && fns[i]<=upper)
 	times++;
     fprintf(fout,"Case #%d: %d\n",count,times);
     if(count==t)
       break;
   } 
   
   return 0;
 }
