#include<stdio.h>
 #include<stdlib.h>
 int main(int argc,char** argv)
 {
 	FILE *fpin,*fpout;
     int t,c=1,row[4],col[4],d1,d2,i,j,v,d;
     char ch;
     
     
     
     fpin=fopen(argv[1],"r");
     fpout=fopen(argv[2],"w");
     fscanf(fpin,"%d",&t);
     do{
         d=1;
         for(i=0;i<4;++i)
         {
             row[i]=0;
             col[i]=0;
             d1=0;
             d2=0;
         }
         for(i=0;i<4;++i)
             for(j=0;j<4;++j)
             {
                 fscanf(fpin," %c",&ch);
                 switch(ch)
                 {
                     case 'X': v=10;
                         break;
                     case 'O': v=-3;
                         break;
                     case 'T': v=0;
                         break;
                     case '.': v=100;
                         d=0;
                 }
                 row[i]+=v;
                 col[j]+=v;
                 if(i==j)
                     d1+=v;
                 if((i+j)==3)
                     d2+=v;
             }
         v=0;
         for(i=0;i<4;++i)
         {
             if(row[i]==40||row[i]==30||col[i]==40||col[i]==30)
                 v=1;
             else if(row[i]==-12||row[i]==-9||col[i]==-12||col[i]==-9)
                 v=2;
             if(v)
                 break;
         }
         if(!v)
         {
             if(d1==40||d2==40||d1==30||d2==30)
                 v=1;
             else if(d1==-12||d2==-12||d1==-9||d2==-9)
                 v=2;
         }
         if(!v&&d)
             v=3;
         fprintf(fpout,"Case #%d: ",c++);
         switch(v)
         {
             case 1: fprintf(fpout,"X won\n");
                 break;
             case 2: fprintf(fpout,"O won\n");
                 break;
             case 3: fprintf(fpout,"Draw\n");
                 break;
             case 0: fprintf(fpout,"Game has not completed\n");
         }
         --t;
     }while(t);
     
     
     
     close(fpin);
     close(fpout);
 }

