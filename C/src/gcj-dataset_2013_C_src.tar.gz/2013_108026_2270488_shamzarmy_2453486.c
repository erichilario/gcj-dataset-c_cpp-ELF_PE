#include<stdio.h>
 main()
 {
    FILE *fp,*fp1;
    int a,i,j,k,l=0,l1=0,l2=0,l3=0,flag=0;
 char b[4][5];
    fp=fopen("A-small-attempt4.in","r+");
    fp1=fopen("output.txt","w+");
    fscanf(fp,"%d",&a);
    
    
  for(i=0;i<a;i++)
   {   
        flag=0;l=0;l1=0;l2=0;l3=0;
        for(j=0;j<4;j++)
         fscanf(fp,"%s",b[j]);
 
  
  
  
   for(j=0;j<4;j++)
      {
         for(k=0;k<4;k++)
            {
             if(b[j][k]=='.')
            flag=1;
              if(b[j][k]=='O'||b[j][k]=='T')
              l++;
              if(b[j][k]=='X'||b[j][k]=='T')
              l1++;
             }
 
               if(l==4)
               {
               fprintf(fp1,"Case #%d: O won\n",i+1);
               break;
               }
               else if(l1==4)
              {
               fprintf(fp1,"Case #%d: X won\n",i+1);
               break;
               }
              l=0;l1=0;
        }
           if(l==4||l1==4)
           {
            l=0;l1=0;     
           continue;
           }   
  
        for(j=0;j<4;j++)
      {
         for(k=0;k<4;k++)
            {
             if(b[k][j]=='.')
            flag=1;
              if(b[k][j]=='O'||b[k][j]=='T')
              l++;
              if(b[k][j]=='X'||b[k][j]=='T')
              l1++;
             }
 
               if(l==4)
               {
               fprintf(fp1,"Case #%d: O won\n",i+1);
               
               break;
               }
               else if(l1==4)
              {
               fprintf(fp1,"Case #%d: X won\n",i+1);
               break;
               }
               l=0;l1=0;
        }
                if(l==4||l1==4)
           {
            l=0;l1=0;  flag=0;   
           continue;
           }    
      
        for(j=0;j<4;j++)
        {
           if(b[j][j]=='O'||b[j][j]=='T')
           l++;
           else if(b[j][j]=='X'||b[j][j]=='T')
           l1++;
           else if(b[j][j]=='.')
            flag=1;
            if(b[3-j][j]=='O'||b[3-j][j]=='T')
           l2++;
           else if(b[3-j][j]=='X'||b[3-j][j]=='T')
           l3++;
           else if(b[3-j][j]=='.')
            flag=1;
 
        }  
            if(l==4||l2==4)
               {
               fprintf(fp1,"Case #%d: O won\n",i+1);
               l=0;l1=0;l2=0;l3=0;flag=0;
               continue;
               }
               else if(l1==4||l3==4)
              {
               fprintf(fp1,"Case #%d: X won\n",i+1);
 	      l=0;l1=0;l2=0;l3=0;
 		flag=0;
               continue;
               }
                
               l=0;l1=0;
             if(flag==1)
             {
               fprintf(fp1,"Case #%d: Game has not completed\n",i+1);
               l=0;l1=0;l2=0;l3=0; 
              continue;
             }
 
            fprintf(fp1,"Case #%d: Draw\n",i+1);
 
     
 l=0;l1=0;l2=0;l3=0;flag=0;
  }
                
 
 
 }

