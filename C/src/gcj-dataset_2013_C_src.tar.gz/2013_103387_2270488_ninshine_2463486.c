#include<stdio.h>
 #include<math.h>
 
 int f1(int a[],double k)
 {
 	int i;
 	for(i=0;i<21;i++)
 	{if(k<=a[i]) return i;
 	}
 }
 int f2(int a[],double k)
 {
 	int i;
 	for(i=0;i<21;i++)
 	{if(k<a[i]) return i;
 	if(k==a[i]) return i+1;
 	}
 }
 
 	
 main()
 {
 	int a[21]={1,2,3,11,22,101,111,121,202,212,1001,1111,2002,10001,10201,11011,11111,11211,20002,20102};
 	int n,i,j,m;
 	double k,q;
 	FILE* p;
 	FILE* t;
 
 	p=fopen("C-large-1.in","r");
 	t=fopen("out.txt","w");
 	fscanf(p,"%d",&n);
 	m=n;
 	while(n--)
 	{
 		fscanf(p,"%lf %lf",&k,&q);
 		k=sqrt(k);
 		q=sqrt(q);
 		i=f1(a,k);
 		j=f2(a,q);
 		fprintf(t,"Case #%d: %d\n",m-n,j-i);
 	}
 }
 

