#include <stdio.h>
 
 #define TRUE 1
 #define FALSE 0
 
 int n;
 int chest[205][205];
 int type[205];
 int ans[205], al[205];
 int key[205][205], needs[205][205];
 int opened[205][205];
 
 int dfs(int d)
 {
     int i, j;
     for(i = 1; i <= n; ++i)
         if(!opened[d-1][i])
             break;
     if(i > n) return TRUE;
     al[d] = al[d - 1];
     for(i = 1; i <= 200; ++i)
         opened[d][i] = opened[d-1][i], key[d][i] = key[d-1][i], needs[d][i] = needs[d-1][i];
     for(i = 1; i <= n; ++i)
         if(!opened[d][i] && key[d][type[i]] >= needs[d][type[i]])
             break;
     if(i <= n)
     {
         for(i = 1; i <= n; ++i)
             if(!opened[d][i] && key[d][type[i]] >= needs[d][type[i]])
             {
                 opened[d][i] = TRUE; ans[++al[d]] = i;
                 --key[d][type[i]]; --needs[d][type[i]];
                 for(j = 1; j <= 200; ++j)
                     key[d][j] += chest[i][j];
             }
         return dfs(d+1);
     }
     for(i = 1; i <= n; ++i)
         if(!opened[d][i] && key[d][type[i]] && chest[i][type[i]])
             break;
     if(i <= n)
     {
         for(i = 1; i <= n; ++i)
             if(!opened[d][i] && key[d][type[i]] && chest[i][type[i]])
             {
                 opened[d][i] = TRUE; ans[++al[d]] = i;
                 --key[d][type[i]]; --needs[d][type[i]];
                 for(j = 1; j <= 200; ++j)
                     key[d][j] += chest[i][j];
             }
         return dfs(d+1);
     }
     for(i = 1; i <= n; ++i)
         if(!opened[d][i] && key[d][type[i]])
         {
             opened[d][i] = TRUE; ans[++al[d]] = i;
             --key[d][type[i]]; --needs[d][type[i]];
             for(j = 1; j <= 200; ++j)
                 key[d][j] += chest[i][j];
             if(dfs(d+1))
                 return TRUE;
             opened[d][i] = FALSE; --al[d];
             ++key[d][type[i]]; ++needs[d][type[i]];
             for(j = 1; j <= 200; ++j)
                 key[d][j] -= chest[i][j];
         }
     return FALSE;
 }
 
 int main(int argc, const char *argv[])
 {
 	freopen("input.txt", "r", stdin);
 	freopen("output.txt", "w", stdout);
     int i, j, x, m, k, o;
     for(scanf("%d%*c", &o), k = 1; k <= o; ++k)
     {
 		printf("Case #%d: ", k);
         scanf("%d%d", &m, &n);
         for(i = 1; i <= 200; ++i)
         {
             key[0][i] = 0, needs[0][i] = 0;
             opened[0][i] = FALSE;
             for(j = 1; j <= 200; ++j)
                 chest[i][j] = 0;
         }
         for(i = 1; i <= m; ++i)
         {
             scanf("%d", &x);
             ++key[0][x];
         }
         for(i = 1; i <= n; ++i)
         {
             scanf("%d%d", &type[i], &m);
             ++needs[0][type[i]];
             for(j = 1; j <= m; ++j)
                 scanf("%d", &x), ++chest[i][x];
         }
         al[0] = 0;
         if(dfs(1))
         {
             for(i = 1; i < n; ++i)
                 printf("%d ", ans[i]);
             printf("%d\n", ans[n]);
         }
         else printf("IMPOSSIBLE\n");
     }
     return 0;
 }

