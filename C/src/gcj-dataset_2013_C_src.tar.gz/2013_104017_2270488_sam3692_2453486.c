# include<stdio.h>
 # include<conio.h>
 # include<malloc.h>
 # include<string.h>
 # include<math.h>
 
 void main()
 {
 int a,c=0,d,i,j,k,l,t,tie=0;
 char b[4][4];
 int won;
 FILE * fin = fopen("G:/WORK/SAMARTH JIIT/Placement Study/google/input.in", "r");
 FILE * out = fopen("G:/WORK/SAMARTH JIIT/Placement Study/google/out.txt", "w");
 //scanf("%d",&t);
 fscanf(fin, "%d\n", &t);
 //printf("%d",t);
 for(l=0;l<t;l++)
 	{
 	c=0,tie=0;
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				if(j==3)
 					fscanf(fin, "%c\n", &b[i][j] );
 				else
 					fscanf(fin, "%c", &b[i][j] );
 			}
 		}
 		//for(i=0;i<4;i++){for(j=0;j<4;j++){	printf("%c",b[i][j]);}printf("\n");	}
 				//rows
 				for(i=0; i<4; i++) 
 				{
 					d=check(b[i][0],b[i][1],b[i][2],b[i][3]);
 					if(d==1)
 					{ 
 					 fprintf(out, "Case #%d: X won\n", l+1);
 					  //printf("Case #%d: X won\n",l+1);
 					  goto abc;
 					 }
 					if(d==2)
 					{ fprintf(out, "Case #%d: O won\n", l+1);
 						//printf("Case #%d: O won\n",l+1);
 					 goto abc;
 					}
 					if( d==4)
 						c++;
 					if( d==3)
 						tie++;
 					}
 			
 			//columns
 				for(i=0; i<4; i++) 
 				{
 					d=check(b[0][i],b[1][i],b[2][i],b[3][i]);
 					if(d==1)
 					{ fprintf(out, "Case #%d: X won\n", l+1);
 						//printf("Case #%d: X won\n",l+1);
 					  goto abc;
 					}
 					if(d==2)
 					{ fprintf(out, "Case #%d: O won\n", l+1);
 						//printf("Case #%d: O won\n",l+1);
 					  goto abc;
 					}
 					if( d==4)
 						c++;
 					if( d==3)
 						tie++;
 				
 				}
 				// diagonals
 					d=check(b[0][0],b[1][1],b[2][2],b[3][3]);
 					if( d==3)
 						tie++;
 						if( d==4)
 						c++;
 					
 					if(d==1)
 					{ fprintf(out, "Case #%d: X won\n", l+1);
 						//printf("Case #%d: X won\n",l+1);
 					  goto abc;
 					}
 					if(d==2)
 					{ fprintf(out, "Case #%d: O won\n", l+1);
 						//printf("Case #%d: O won\n",l+1);
 					  goto abc;
 					}	
 					
 					d=check(b[0][3],b[1][2],b[2][1],b[3][0]);
 					if( d==3)
 						tie++;
 					
 					if( d==4)
 						c++;
 					
 					if(d==1)
 					{ fprintf(out, "Case #%d: X won\n", l+1);
 						//printf("Case #%d: X won\n",l+1);
 					  goto abc;
 					}
 					if(d==2)
 					{ fprintf(out, "Case #%d: O won\n", l+1);
 						//printf("Case #%d: O won\n",l+1);
 					  goto abc;
 					}
 									
 					if(c==10)
 						fprintf(out, "Case #%d: Game has not completed\n", l+1);
 						//printf("Case #%d: Game has not completed\n",l+1);
 					if(tie==10)
 						fprintf(out, "Case #%d: Draw\n", l+1);
 						//printf("Case #%d: Draw\n",l+1);
 					
 					
 abc: ;		
 	}
 fclose(fin);
 fclose(out);
 
 }
 
 
 int check(char a,char b, char c ,char d)
 {
 	int x=0,o=0,t=0;
 //if(a=='.' || b=='.' || c=='.'|| d=='.')
 //return 4;
 if(a=='T' || b=='T' || c=='T'|| d=='T') t++; 
 if(a=='X')x++; if(a=='O') o++;
 if(b=='X')x++; if(b=='O') o++;
 if(c=='X')x++; if(c=='O') o++;
 if(d=='X')x++; if(d=='O') o++;
 
 if((x==3 && t==1 ) || x==4 )
 return 1;
 
 else if((o==3 && t==1 ) || o==4 )
 return 2;
 
 else if(x+o+t==4)
 return 3;
 
 else if(x+o+t<4)
 return 4;
 }
  
