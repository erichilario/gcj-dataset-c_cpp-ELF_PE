#define _CRT_SECURE_NO_DEPRECATE
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define GAME_NOT_OVER -1
 #define GAME_DRAW  0
 #define GAME_WON  1
 #define DOT  '.'
 #define X  'X'
 #define O  'O'
 #define T  'T'
 
 int A2012_1(void);
 char a[4][4];
 
 char ROW_CHECK(char ch)
 {
     int i = 0;
     int rcount = 0;
     int ccount = 0;
     int dcount = 0;
 
     for (i = 0; i < 4; i++)
     {
         rcount=dcount=ccount=0;
         /* Row wise check */
         if(a[i][0] == ch || a[i][0] == T) rcount++;
         else if( a[i][0] == DOT) dcount++;
         else ccount++;
 
         if(a[i][1] == ch || a[i][1] == T ) rcount++;
         else if( a[i][1] == DOT) dcount++;
         else ccount++;
 
         if(a[i][2] == ch || a[i][2] == T) { rcount++; } 
         else if( a[i][2] == DOT) dcount++;
         else ccount++;
 
         if(a[i][3] == ch || a[i][3] == T) { rcount++; } 
         else if( a[i][3] == DOT) dcount++;
         else ccount++;
 
         if (rcount==4) return GAME_WON;
         if(rcount+dcount == 4)
             return(GAME_NOT_OVER);
     }
     return('C');
 }
 
 
 char COL_CHECK(char ch)
 {
     int i = 0;
     int rcount = 0;
     int ccount = 0;
     int dcount = 0;
 
     for (i = 0; i < 4; i++)
     {
         rcount=dcount=ccount=0;
         /* Row wise check */
         if(a[0][i] == ch || a[0][i] == T) rcount++;
         else if( a[0][i] == DOT) dcount++;
         else ccount++;
 
         if(a[1][i] == ch || a[1][i] == T ) rcount++;
         else if( a[1][i] == DOT) dcount++;
         else ccount++;
 
         if(a[2][i] == ch || a[2][i] == T) { rcount++; } 
         else if( a[2][i] == DOT) dcount++;
         else ccount++;
 
         if(a[3][i] == ch || a[3][i] == T) { rcount++; } 
         else if( a[3][i] == DOT) dcount++;
         else ccount++;
 
         if (rcount==4) return GAME_WON;
         if(rcount+dcount == 4)
             return(GAME_NOT_OVER);
     }
     return('C');
 }
 
 
 
 char DIAG_CHECK(char ch)
 {
     int rcount = 0;
     int ccount = 0;
     int dcount = 0;
 
     {
         rcount=dcount=ccount=0;
         /* Row wise check */
         if(a[0][0] == ch || a[0][0] == T) rcount++;
         else if( a[0][0] == DOT) dcount++;
         else ccount++;
 
         if(a[1][1] == ch || a[1][1] == T ) rcount++;
         else if( a[1][1] == DOT) dcount++;
         else ccount++;
 
         if(a[2][2] == ch || a[2][2] == T) { rcount++; } 
         else if( a[2][2] == DOT) dcount++;
         else ccount++;
 
         if(a[3][3] == ch || a[3][3] == T) { rcount++; } 
         else if( a[3][3] == DOT) dcount++;
         else ccount++;
 
         if (rcount==4) return GAME_WON;
         if(rcount+dcount == 4)
             return(GAME_NOT_OVER);
     }
 
     {
         rcount=dcount=ccount=0;
         /* Row wise check */
         if(a[0][3] == ch || a[0][3] == T) rcount++;
         else if( a[0][3] == DOT) dcount++;
         else ccount++;
 
         if(a[1][2] == ch || a[1][2] == T ) rcount++;
         else if( a[1][2] == DOT) dcount++;
         else ccount++;
 
         if(a[2][1] == ch || a[2][1] == T) { rcount++; } 
         else if( a[2][1] == DOT) dcount++;
         else ccount++;
 
         if(a[3][0] == ch || a[3][0] == T) { rcount++; } 
         else if( a[3][0] == DOT) dcount++;
         else ccount++;
 
         if (rcount==4) return GAME_WON;
         if(rcount+dcount == 4)
             return(GAME_NOT_OVER);
     }
     return('C');
 }
 
 int A2012_1(void )
 {
     int i=0;
     int TC = 0,t=0;
     char line[5];
     FILE *fp, *fpo;
 
 //    fp = fopen("c:\\sajive\\CODEJAM\\input.txt","r");
 //    fpo = fopen("c:\\sajive\\CODEJAM\\output.txt","w");
 
     fp = fopen("input.txt","r");
     fpo = fopen("output.txt","w");
 
     if (fp == NULL) {perror ("Error opening file");exit(0);}
     else
     {
         fscanf(fp, "%d", &TC);
 
         memset(a, '.', sizeof(a));
         while(!feof(fp))
         {
             if(t<TC)
             {
                 t++;
             }
             else
                 return(1);
 
             for (i = 0; i < 4; i++)
             {
                 //fscanf(fp, "%c%c%c%c", &a[i][0], &a[i][1], &a[i][2], &a[i][3]);
                 fscanf(fp, "%s", line);
                 sscanf(line, "%c%c%c%c", &a[i][0], &a[i][1], &a[i][2], &a[i][3]);
 //                printf("%c-%c-%c-%c", a[i][0], a[i][1], a[i][2], a[i][3]);
             }
             fprintf(fpo, "Case #%d: ", t);
 
             {
                 char cX; char rX; char dX;
                 char cO; char rO; char dO;
 
                 rX = ROW_CHECK(X);
                 if(rX==GAME_WON)
                     { fprintf(fpo, "X won \n");continue;}
 
                 cX = COL_CHECK(X);
                 if(cX==GAME_WON)
                     { fprintf(fpo, "X won \n");continue;}
 
                 dX = DIAG_CHECK(X);
                 if(dX==GAME_WON)
                     { fprintf(fpo, "X won \n");continue;}
 
                 rO = ROW_CHECK(O);
                 if(rO==GAME_WON)
                     { fprintf(fpo, "O won \n");continue;}
 
                 cO = COL_CHECK(O);
                 if(cO==GAME_WON)
                     { fprintf(fpo, "O won \n");continue;}
 
                 dO = DIAG_CHECK(O);
                 if(dO==GAME_WON)
                     { fprintf(fpo, "O won \n");continue;}
 
                 if(rX == GAME_NOT_OVER || cX == GAME_NOT_OVER || dX == GAME_NOT_OVER
                  || rO == GAME_NOT_OVER || cO == GAME_NOT_OVER || dO == GAME_NOT_OVER)
                     fprintf(fpo, "Game has not completed\n");
                 else
                     fprintf(fpo, "Draw\n");
              
             }
 
         }
 
     }
     fclose (fp);
     fclose (fpo);
 
     return 0;
 }
 
 int main(int argc, char *argv[])
 {
     int i = A2012_1();
     return i;
 }
 

