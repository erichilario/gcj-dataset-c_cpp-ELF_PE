#include "stdio.h"
 #include "stdlib.h"
 
 int A[100][100];	
 int N, M;
 
 int checkColumn(int x, int  min)
 {
 	int i;
 	for(i=0; i<N; i++)
 	{
 		if(A[i][x] > min)
 		{
 			return 1;
 		}
 	}
 	return 0;
 }
 
 int checkRow(int y, int  min)
 {
 	int j;
 	for(j=0; j<M; j++)
 	{
 		if(A[y][j] > min)
 		{
 			return 1;
 		}
 	}
 	return 0;
 }
 
 int main()
 {
 	int T = 0;
 	
 	int t, i, j, k, possible;
 	char tmp;
 	
 	FILE* fIn = fopen("B-small-attempt8.in", "r");
 	FILE* fOut = fopen("solutionB.out", "w");
 	fscanf(fIn, "%d\n", &T);
 	
 	for (t=1; t<=T; t++)
 	{
 		fscanf(fIn, "%d %d\n", &N, &M);
 		possible = 1;
 		for (i=0; i<N; i++)
 		{
 			for (j=0; j<M; j++)
 			{
 				fscanf(fIn, "%i ", &A[i][j] );
 			}
 			fscanf(fIn, "\n", &tmp );	
 		}
 
 		if( N==1 || M==1)
 		{
 			fprintf(fOut, "Case #%d: YES\n", t);
 			continue;
 		}
 		
 
 		for (i=0; i<N; i++)
 		{
 			for (j=0; j<M-1; j++)
 			{
 				for(k=j; k<M; k++)
 				{
 					if (A[i][j] < A[i][k])
 					{
 						if(checkColumn(j,A[i][j]))
 						{
 							possible = 0;
 							break;
 						}
 					}
 					if (A[i][j] > A[i][k])
 					{
 						if(checkColumn(k,A[i][k]))
 						{
 							possible = 0;
 							break;
 						}
 					}
 				}
 				
 			}
 		}
 
 		for (j=0; j<M; j++)
 		{
 			for (i=0; i<N-1; i++)
 			{
 				for(k=i; k<N; k++)
 				{
 					if (A[i][j] < A[k][j])
 					{
 						if(checkRow(i,A[i][j]))
 						{
 							possible = 0;
 							break;
 						}
 					}
 					if (A[i][j] > A[k][j])
 					{
 						if(checkRow(k,A[k][j]))
 						{
 							possible = 0;
 							break;
 						}
 					}
 				}
 				
 			}
 		}
 
 		if (possible)
 		{
 			fprintf(fOut, "Case #%d: YES\n", t);
 		}
 		else
 		{
 			fprintf(fOut, "Case #%d: NO\n", t);
 		}
 	}
 }

