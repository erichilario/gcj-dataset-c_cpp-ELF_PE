#include <stdlib.h>
 #include <stdio.h>
 #include <assert.h>
 
 
 void solve(int caseNo);
 int xwon(char board[4][4]);
 int owon(char board[4][4]);
 int notDone(char board[4][4]);
 
 int main(int argc, char* argv[]){
     int cases;
     scanf("%d", &cases);
     int i;
     for(i = 1; i <= cases; i++){
           solve(i);
     }
     return 0;
 }
 
 void solve(int caseNo){
     char board[4][4];
 	int a,b;
 	getchar();
 	for(a = 0; a < 4; a++){
 		for(b = 0; b < 4; b++){
 			board[a][b] =  getchar();
 		}
 		getchar();
 	}
 	
 	if (xwon(board)){
 		printf("Case #%d: X won\n", caseNo);
 		return;
 	} else if (owon(board)){
 		printf("Case #%d: O won\n", caseNo);
 		return;
 	} else if (notDone(board)){
 		printf("Case #%d: Game has not completed\n", caseNo);
 		return;
 	} else {
 	   	printf("Case #%d: Draw\n", caseNo);
 		return;
 	}
 }
 
 
 int xwon(char board[4][4]){
    int ans = 0;
    int a;
    //check horizontal
    for (a = 0; a < 4; a++){
      	if((board[a][0] == 'X' || board [a][0] == 'T') &&
 	     (board[a][1] == 'X' || board [a][1] == 'T') &&
 	     (board[a][2] == 'X' || board [a][2] == 'T') &&
 	     (board[a][3] == 'X' || board [a][3] == 'T')
 	      ) 
 	    return 1;
 	  }
    
    //check vertical
       for (a = 0; a < 4; a++){
      	if((board[0][a] == 'X' || board [0][a] == 'T') &&
 	     (board[1][a] == 'X' || board [1][a] == 'T') &&
 	     (board[2][a] == 'X' || board [2][a] == 'T') &&
 	     (board[3][a] == 'X' || board [3][a] == 'T')
 	      ) 
 	    return 1;
 	 }
 	 //check diagonals
 
      	if((board[0][0] == 'X' || board [0][0] == 'T') &&
 	     (board[1][1] == 'X' || board [1][1] == 'T') &&
 	     (board[2][2] == 'X' || board [2][2] == 'T') &&
 	     (board[3][3] == 'X' || board [3][3] == 'T') 
 	      ) 
 	    return 1;
 	    
 	    if((board[0][3] == 'X' || board [0][3] == 'T') &&
 	     (board[1][2] == 'X' || board [1][2] == 'T') &&
 	     (board[2][1] == 'X' || board [2][1] == 'T') &&
 	     (board[3][0] == 'X' || board [3][0] == 'T')
 	      ) 
 	    return 1;
    return ans;
 }
 
 int owon(char board[4][4]){
    int ans = 0;
     int a;
    //check horizontal
    for (a = 0; a < 4; a++){
      	if((board[a][0] == 'O' || board [a][0] == 'T') &&
 	     (board[a][1] == 'O' || board [a][1] == 'T') &&
 	     (board[a][2] == 'O' || board [a][2] == 'T') &&
 	     (board[a][3] == 'O' || board [a][3] == 'T')
 	      ) 
 	    return 1;
 	  }
    
    //check vertical
       for (a = 0; a < 4; a++){
      	if((board[0][a] == 'O' || board [0][a] == 'T') &&
 	     (board[1][a] == 'O' || board [1][a] == 'T') &&
 	     (board[2][a] == 'O' || board [2][a] == 'T') &&
 	     (board[3][a] == 'O' || board [3][a] == 'T')
 	      ) 
 	    return 1;
 	 }
 	 //check diagonals
 
      	if((board[0][0] == 'O' || board [0][0] == 'T') &&
 	     (board[1][1] == 'O' || board [1][1] == 'T') &&
 	     (board[2][2] == 'O' || board [2][2] == 'T') &&
 	     (board[3][3] == 'O' || board [3][3] == 'T') 
 	      ) 
 	    return 1;
 	    
 	    if((board[0][3] == 'O' || board [0][3] == 'T') &&
 	     (board[1][2] == 'O' || board [1][2] == 'T') &&
 	     (board[2][1] == 'O' || board [2][1] == 'T') &&
 	     (board[3][0] == 'O' || board [3][0] == 'T')
 	      ) 
 	    return 1;
    
    return ans;
 }
 
 int notDone(char board[4][4]){
 	int ans = 0;
 	int a,b;
 	for(a = 0; a < 4; a++){
 		for(b = 0; b < 4; b++){
 			if(board[a][b] ==  '.'){
 				return 1;
 			}
 		}
 	}
 	return ans;
 }

