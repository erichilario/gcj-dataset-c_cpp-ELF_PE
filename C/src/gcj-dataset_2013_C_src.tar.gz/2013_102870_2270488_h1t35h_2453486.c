#include<stdio.h>
 #include<stdlib.h>
 #include<stdio.h>
 #define get getchar_unlocked
 inline int scan()
 {
     int n=0,s=1;
     char p=get();
     if(p=='-') s=-1;
     while((p<'0'||p>'9')&&p!=EOF&&p!='-') p=get();
     if(p=='-') s=-1,p=get();
     while(p>='0'&&p<='9')
     {
         n = (n<< 3) + (n<< 1) + (p - '0');
         p=get();
     }
     return n*s;
 }
 char rowSearch(char a[5][5]);
 char ColmnSearch(char a[5][5]);
 char notover(char a[5][5]);
 char diagonalSearch(char a[5][5]);
 
 
 int main()
 {
     int test,i,a,b;
     char inp[5][5];
     char rowr,colr,diar,notovr,x;
     test=scan();
     i=0;
     while(i<test)
     {
         for(a=0; a<4; a++)
         {
             //for(b=0;b<4;b++)
             //{
             scanf("%s",inp[a]);
             //}
         }
         /*  printf("Array:\n");
           for(a=0; a<4; a++)
           {
               for(b=0; b<4; b++)
               {
                   printf("%c",inp[a][b]);
               }
               printf("\n");
           }*/
         rowr=rowSearch(inp);
         colr=ColmnSearch(inp);
         diar=diagonalSearch(inp);
         if(rowr=='D' && colr=='D' && diar=='D')
         {
             notovr=notover(inp);
             if(notovr=='N')
             {
                 printf("Case #%d: Game has not completed\n",i+1);
             }
             else
             {
                 printf("Case #%d: Draw\n",i+1);
             }
         }
         else
         {
             if(rowr!= 'D')
             {
                 printf("Case #%d: %c won\n",i+1,rowr);
             }
             else if(colr!= 'D')
             {
                 printf("Case #%d: %c won\n",i+1,colr);
             }
             else
             {
                 printf("Case #%d: %c won\n",i+1,diar);
             }
         }
         i++;
     }
     return 0;
 }
 
 char rowSearch(char a[5][5])
 {
     int cnt,i,j;
     char ch,retval;
     retval='D';
     for(i=0; i<4; i++)
     {
         cnt=0;
         ch=a[i][0];
         if(ch=='.')
         {
             ;
         }
         else if(ch=='T')
         {
             ch=a[i][1];
             if(ch=='.')
             {
                 ;
             }
             else
             {
                 for(j=0; j<4; j++)
                 {
                     if(a[i][j]==ch || a[i][j]=='T')
                     {
                         cnt++;
                         if(cnt==4)
                         {
                             retval = ch;
                         }
                     }
                     else
                         break;
                 }
             }
         }
         else
         {
             for(j=0; j<4; j++)
             {
                 if(a[i][j]==ch || a[i][j]=='T')
                 {
                     cnt++;
                     if(cnt==4)
                     {
                         retval = ch;
                     }
                 }
                 else
                     break;
             }
         }
     }
     return retval;
 }
 
 char notover(char a[5][5])
 {
     int i,j;
     char retval;
     retval='D';
     for(i=0; i<4; i++)
     {
         for(j=0; j<4; j++)
         {
             if(a[i][j]=='.')
             {
                 retval='N';
             }
         }
     }
     return retval;
 }
 
 char diagonalSearch(char a[5][5])
 {
     int cnt,i,flag=1;
     char ch,retval;
     retval='D';
     cnt=0;
     ch=a[0][0];
     if(ch=='.')
     {
         flag=0;
     }
     if(ch=='T')
     {
         ch=a[1][1];
         if(ch=='.')
         {
             ;
         }
         else
         {
             for(i=0; i<4 && flag!=0; i++)
             {
                 if(a[i][i]==ch || a[i][i]=='T')
                 {
                 //    printf("\n c1: %c",ch);
                     cnt++;
                     if(cnt==4)
                     {
                         retval = ch;
                     }
                 }
                 else
                     break;
             }
         }
     }
     else
         {
             for(i=0; i<4 && flag!=0; i++)
             {
                 if(a[i][i]==ch || a[i][i]=='T')
                 {
                 //    printf("\n c1: %c",ch);
                     cnt++;
                     if(cnt==4)
                     {
                         retval = ch;
                     }
                 }
                 else
                     break;
             }
         }
     flag=1;
     if(retval =='D')
     {
         ch=a[0][3];
         cnt=0;
         for(i=0; i<4 && flag!=0; i++)
         {
             if(ch=='.')
             {
                 flag=0;
             }
             else if(ch=='T')
             {
                 ch=a[1][2];
                 if(ch=='.')
                 {
                     break;
                 }
                 else if(a[i][4-1-i]==ch || a[i][4-i-1]=='T')
                 {
                  //   printf("\n c: %c",ch);
                     cnt++;
                     if(cnt==4)
                     {
                         retval = ch;
                     }
                 }
             }
             else
             {
 
                 if(a[i][4-1-i]==ch || a[i][4-i-1]=='T')
                 {
                //     printf("\n c: %c",ch);
                     cnt++;
                     if(cnt==4)
                     {
                         retval = ch;
                     }
                 }
                 else
                     break;
             }
         }
     }
     return retval;
 }
 
 char ColmnSearch(char a[5][5])
 {
     int cnt,i,j;
     char ch,retval;
     retval='D';
     for(i=0; i<4; i++)
     {
         cnt=0;
         ch=a[0][i];
         if(ch=='.')
         {
             ;
         }
         else if(ch=='T')
         {
             ch=a[1][i];
             if(ch=='.')
             {
                 ;
             }
 
             else
             {
 
                 for(j=0; j<4; j++)
                 {
                     if(a[j][i]==ch || a[j][i]=='T')
                     {
                         cnt++;
                         if(cnt==4)
                         {
                             retval = ch;
                         }
                     }
                     else
                         break;
                 }
             }
         }
         else
         {
 
             for(j=0; j<4; j++)
             {
                 if(a[j][i]==ch || a[j][i]=='T')
                 {
                     cnt++;
                     if(cnt==4)
                     {
                         retval = ch;
                     }
                 }
                 else
                     break;
             }
         }
     }
     return retval;
 }
 

