#include<stdio.h>
 #include<stdlib.h>
 long long arr[1000];
 int ispalin(long long a)
 {
     char str[20];
     int j,k,flag;
     j = 0;
     while(a!=0)
     {
         str[j] = a%10;
         a = a/10;
         j++;
     }
     k = 0;j--;flag=0;
     while(k!=j&&k<j)
     {
         if(str[k]!=str[j])
         {
             flag = 1;
             break;
         }
         j--;
         k++;
     }
     if(flag == 1)
         return 0;
     else
         return 1;
 }
 int main()
 {
     int t,j;
     int cnt,flag,cnt2;
     long long no,i,a,b;
     FILE *fp,*fo;
     fp = fopen("inp.in","r");
     fo = fopen("out.txt","w");
     arr[0] = 1;
     cnt = 1;
     for(i=2;i<10000000;i++)
     {
         if(ispalin(i))
         {
             no = i*i;
             if(ispalin(no))
             {
                 arr[cnt++] = no;
             }
         }
     }
     fscanf(fp,"%d",&t);
     j=1;
     while(t--)
     {
         fscanf(fp,"%lld%lld",&a,&b);
         cnt2 = 0;
         for(i=0;i<cnt;i++)
         {
             if(arr[i]>=a&&arr[i]<=b)
                 cnt2++;
         }
         fprintf(fo,"Case #%d: %d\n",j++,cnt2);
     }
     return 0;
 }

