#include <stdio.h>
 #include <stdlib.h>
 
 #define NO_WIN 0
 #define X_WON 1
 #define O_WON 2
 
 void solveCase(void);
 int analyzeLine(int l, int *es);
 int analyzeColumn(int c);
 int analyzeDiagonal(int d);
 
 int main(void)
 {
 	int testCases;
 	int currentCase = 1;
 
 	scanf("%d", &testCases);
 	while(testCases--)
 	{
 		printf("Case #%d: ", currentCase++);
 		solveCase();
 	}
 	
 	return 0;
 }
 
 char gameBoard[4][7]; // for \n, \r and \0 at the worst case
 
 void solveCase(void)
 {
 	int emptySpace = 0;
 	int i;
 	int rc;
 	
 	for(i = 0; i < 4; i++) {
 		scanf("%s", gameBoard[i]);
 	}
 	
 	for(i = 0; i < 4; i++) {
 		rc = analyzeLine(i, &emptySpace);
 		if (rc) break;
 		rc = analyzeColumn(i);
 		if (rc) break;
 		rc = analyzeDiagonal(i);
 		if (rc) break;
 	}
 	
 	if (NO_WIN == rc){
 		if (emptySpace){
 			printf("Game has not completed\n");
 		}
 		else
 		{
 			printf("Draw\n");
 		}
 	} else if (X_WON == rc){
 		printf("X won\n");
 	} else {
 		printf("O won\n");
 	}
 }
 
 int analyzeLine(int l, int *es){
 	int sum = 0;
 	int i;
 	int rc;
 	
 	for(i = 0; i < 4; i++){
 		sum += gameBoard[l][i];
 	}
 	
 	if (sum == 4 * 'X' || sum == 3 * 'X' + 'T'){
 		rc = X_WON;
 	} else if (sum == 4*'O' || sum == 3*'O' + 'T'){
 		rc = O_WON;
 	}else{
 		if (sum < 4*'O'){
 			*es = 1;
 		}
 		rc = NO_WIN;
 	}
 		
 	return rc;
 }
 
 int analyzeColumn(int c){
 	int sum = 0;
 	int i;
 	int rc;
 	
 	for(i = 0; i < 4; i++){
 		sum += gameBoard[i][c];
 	}
 	
 	if (sum == 4 * 'X' || sum == 3 * 'X' + 'T'){
 		rc = X_WON;
 	} else if (sum == 4*'O' || sum == 3*'O' + 'T'){
 		rc = O_WON;
 	}else{
 		rc = NO_WIN;
 	}
 		
 	return rc;
 }
 
 int analyzeDiagonal(int d){
 	int sum = 0;
 	int i;
 	int rc;
 	
 	if (0 == d){
 		for(i = 0; i < 4; i++){
 			sum += gameBoard[i][i];
 		}
 	}else if (1 == d){
 		for(i = 0; i < 4; i++){
 			sum += gameBoard[i][3-i];
 		}
 	}else{
 		return NO_WIN;
 	}
 	
 	if (sum == 4 * 'X' || sum == 3 * 'X' + 'T'){
 		rc = X_WON;
 	} else if (sum == 4*'O' || sum == 3*'O' + 'T'){
 		rc = O_WON;
 	}else{
 		rc = NO_WIN;
 	}
 		
 	return rc;
 }
 

