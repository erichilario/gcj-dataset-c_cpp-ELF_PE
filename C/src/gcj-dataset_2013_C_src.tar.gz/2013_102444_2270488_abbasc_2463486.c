#include <stdio.h>
 #include <stdbool.h>
 
 
 int main()
 {
 	freopen("C-small-attempt0.in", "r", stdin);
 	freopen("fairNSq.txt", "w", stdout);
 	int i, j = 0, sq[36];
 	for(i = 1; i < 35; i++)
 		sq[i] = i*i;
 	int fairNSq[36] = {0};
 	for(i = 1; i < 35; i++)			//improper...
 	{
 		int temp = i,rev = 0;
 		while(temp > 0)
 		{
 			rev = temp%10 + 10*rev;
 			temp /= 10;
 		}
 		if(rev == i)
 		{
 			temp = sq[i], rev = 0;
 			while(temp > 0)
 			{
 				rev = temp%10 + 10*rev;
 				temp /= 10;
 			}
 			if(rev == sq[i])
 				fairNSq[j++] = sq[i];
 		}
 	}
 	int t,x;
 	scanf("%d", &t);
 	for(x = 1; x <= t; x++)
 	{
 		int a, b,ans = 0;
 		scanf("%d %d", &a, &b);
 		for(i = 0; i < j ; i++)
 		{
 			if(a <= fairNSq[i] && b >= fairNSq[i])	ans++;
 		}
 		printf("Case #%d: %d\n",x, ans);
 
 	}
 	return 0;
 }

