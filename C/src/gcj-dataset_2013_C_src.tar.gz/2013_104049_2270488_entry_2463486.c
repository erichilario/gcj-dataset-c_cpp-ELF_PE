/*Fair and Square*/
 #include<stdio.h>
 int main()
 {
     freopen("amol.txt","r",stdin);
     freopen("output.txt","w",stdout);
     int t,k=1;
     scanf("%d",&t);
     int pal[5]={1,4,9,121,484};
     while(t--)
     {   int a,b,i,count=0;
         scanf("%d %d",&a,&b);
         for(i=0;i<=4;i++)
         {   if(pal[i]>=a&&pal[i]<=b)
                 count++;
         }
         printf("Case #%d: %d\n",k,count);
         k++;
     }
     return 0;
 }

