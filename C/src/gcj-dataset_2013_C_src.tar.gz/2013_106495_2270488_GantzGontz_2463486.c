#include <stdio.h>
 #include <string.h>
 #include <conio.h>
 #include <stdlib.h>
 #include <math.h>
 
 void open (char t[][4])
 {
     char s[50];
     int i,j;
     printf ("Give file name\n");
     scanf ("%s",s);
     FILE *fp;
     fp=fopen(s,"r");
     if (fp==NULL)
     {
     printf("error- file not found or corrupted\n");
     system("pause");
     system("cls");
     return;
     }
 
     for (i=0;i<4;i++)
     {
         for (j=0;j<4;j++)
         {
             t[i][j]=fgetc(fp);
         }
     }
 }
 
 int pal (int a)
 {
 
     int temp,b,newa=0;
     while (temp!=0)
     {
         b=a%10;
         temp=a/10;
         newa=(newa*10)+b;
     }
     if (a==newa) return 1;
     else return 0;
 }
 
 int chsquare(int a )
 {
 
     if (sqrt((float)a)*sqrt((float)a)==a) return 1;
     else return 0;
 }
 
 int check (int a)
 {
     if (pal(a)==1 && chsquare(a)==1 && pal(sqrt(a))==1) return 1 ;
     else return 0;
 }
 
 int fairandsquare(int a, int b)
 {
     count=0;
     for (i=a;i<=b;i++)
     {
         if (check(i)==1) count ++;
     }
     return count ;
 }
 
 
 main()
 {
     char *c;
     int i,j;
 
 
 }

