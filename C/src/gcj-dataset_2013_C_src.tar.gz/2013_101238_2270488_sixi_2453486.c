#include <stdio.h>
 #include <stdbool.h>
 
 char board[4][5];
 int digit_board[4][4];
 
 void Convert() {
     int i, j;
     for (i = 0; i <= 3; ++i) {
         for (j = 0; j <= 3; ++j) {
             if (board[i][j] == 'O') {
                 digit_board[i][j] = 100;
             } else if (board[i][j] == 'X') {
                 digit_board[i][j] = 10;
             } else if (board[i][j] == 'T') {
                 digit_board[i][j] = 1;
             } else {
                 digit_board[i][j] = 0;
             }
         }
     }
 }
 
 int Won(int result) {
     if (result == 400 || result == 301) {
         return 1;
     } else if (result == 40 || result == 31) {
         return 2;
     }
     return 0;
 }
 
 int IsWon() {
     int i, j, result, status;;
     for (i = 0; i <= 3; ++i) {
         result = digit_board[i][0] + digit_board[i][1] + digit_board[i][2] + digit_board[i][3];
         status = Won(result);
         if (status > 0)
             return status;
     }
     for (i = 0; i <= 3; ++i) {
         result = digit_board[0][i] + digit_board[1][i] + digit_board[2][i] + digit_board[3][i];
         status = Won(result);
         if (status > 0)
             return status;
     }
     result = digit_board[0][0] + digit_board[1][1] + digit_board[2][2] + digit_board[3][3];
     status = Won(result);
     if (status > 0)
         return status;
     result = digit_board[0][3] + digit_board[1][2] + digit_board[2][1] + digit_board[3][0];
     status = Won(result);
     if (status > 0)
         return status;
     return 0;
 }
 
 bool IsFinished() {
     int i, j;
     for (i = 0; i <= 3; ++i)
         for (j = 0; j <= 3; ++j)
             if (board[i][j] == '.')
                 return false;
     return true;
 }
 
 int main() {
     int T, i, j, status;
     scanf("%d", &T);
     for (i = 1; i <= T; ++i) {
         for (j = 0; j <= 3; ++j) {
             scanf("%s", &board[j]);
         }
         Convert();
         status = IsWon();
         if (status > 0) {
             if (status == 1) {
                 printf("Case #%d: O won\n", i);
             } else {
                 printf("Case #%d: X won\n", i);
             }
         } else {
             if (IsFinished()) {
                 printf("Case #%d: Draw\n", i);
             } else {
                 printf("Case #%d: Game has not completed\n", i);
             }
         }
     }
     return 0;
 }

