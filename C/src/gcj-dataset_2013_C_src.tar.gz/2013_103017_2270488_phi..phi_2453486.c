#include<stdio.h>
 int main(){
     int T,t;
     int i,j;
     char c;
     int endO=0,endX=0;
     int O=0,X=0,o1=0,o2=0,x1=0,x2=0;
     char a[4][4];
     scanf("%i\n",&T);
     int punkt;
     for(t=1;t<=T;t++){
         punkt=0;
         endO=endX=0;
         X=O=x1=x2=o1=o2=0;
         for(i=0;i<4;i++){
             O=0;
             X=0;
             for(j=0;j<4;j++){
                 scanf("%c",&c);
             //    printf("%c",c);
                 a[i][j]=c;
                 if(c=='.')punkt=1;
               //  printf("%c",c);
                 if(c=='O' || c=='T')O++;
                 if(c=='X' || c=='T')X++;
                 if(i==j && (c=='O' || c=='T'))o1++;
                 if(i+j==3 && (c=='O' || c=='T'))o2++;
                 if(i==j && (c=='X' || c=='T'))x1++;
                 if(i+j==3 && (c=='X' || c=='T'))x2++;
             }
             if(O==4 || o1==4 || o2==4){
                 endO=1;
             }
             if(X==4 || x1==4 || x2==4){
                 endX=1;
             }
             scanf("\n");
           //  printf("\n");
         }
         //printf("%i %i \n",endO,endX);
         for(j=0;j<4;j++){
             X=O=0;
             for(i=0;i<4;i++){
                 if(a[i][j]=='O' || a[i][j]=='T')O++;
                 if(a[i][j]=='X' || a[i][j]=='T')X++;
             }
             if(O==4)endO=1;
             if(X==4)endX=1;
            // printf("--- %i %i -- %i %i\n",endO,endX,O,X);
         }
 
         if(!endO && !endX && punkt){
             printf("Case #%i: Game has not completed\n",t);
             X=O=0;
         }
         else if(endO)
             printf("Case #%i: O won\n",t);
         else if(endX)
             printf("Case #%i: X won\n",t);
         else
             printf("Case #%i: Draw\n",t);
 
         scanf("\n");
     }
 }

