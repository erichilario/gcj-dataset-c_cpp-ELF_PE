/* gcc -Wall -g -pg -oedantic -ansi -o fairsquare fairsquare.c 
    i686-apple-darwin10-gcc-4.2.1 (GCC) 4.2.1 (Apple Inc. build 5666) (dot 3) */
 
 #include <stdio.h>
 #include <stdlib.h>
 
 int ispalindrome(unsigned long int p) {
   char s[16];
   int i, l;
   sprintf(s, "%lu", p);
   for (i=0;i<16;i++) {
     if (s[i] == '\0') {
       l = i;
       break;
     }
   }
   for (i=0;i<l;i++) {
     if (s[i] != s[l-i-1])
       return 0;
     if (i > l/2)
       break;
   }
   return 1;
 }
 
 int main(int argc, char **argv) {
   int val, cases, casemax = 0, n, i, j;
   unsigned long int a, b;/* c, d; */
   unsigned long int fstbl[39] = {1, 4, 9, 121, 484, 10201, 12321, 14641, 40804, 44944, 1002001, 1234321, 4008004, 100020001, 102030201, 104060401, 121242121, 123454321, 125686521, 400080004, 404090404, 10000200001, 10221412201, 12102420121, 12345654321, 40000800004, 1000002000001, 1002003002001, 1004006004001, 1020304030201, 1022325232201, 1024348434201, 1210024200121, 1212225222121, 1214428244121, 1232346432321, 1234567654321, 4000008000004, 4004009004004};
   while ((n = getchar()) != 10) {
     casemax *= 10;
     casemax += n - 48;
   }
   casemax++;
   for (cases=1;cases<casemax;cases++) {
     val = 0;
     /* d = 1; */
     a = 0;
     b = 0;
     while ((n = getchar()) != 32) {
       a *= 10;
       a += n - 48;
     }
     while ((n = getchar()) != 10) {
       b *= 10;
       b += n - 48;
     }
     /* c = d * d;
     while (c < a) {
       c += d*2;
       c++;
       d++;
     }
     while (a <= c && c <= b) {
       if (ispalindrome(d) && ispalindrome(c))
         val++;
       c += d*2;
       c++;
       d++;
       }*/
     for (i=0;fstbl[i]<a;i++);
     for (j=i;fstbl[j]<b;j++);
     val = j - i;
     printf("Case #%d: %d\n", cases, val);
   }
   return 0;
 }

