#include <stdio.h>
 #include <stdlib.h>
 
 int main()
 {
     FILE *fi = fopen("A-large.in","r");
     FILE *fo = fopen("A.out","w");
     char matrix[4][4];
     int testCases;
     fscanf(fi,"%d\n",&testCases);
     int t=1;
     for(;t<=testCases;t++)
     {
         //read the matrix
         int incomplete = 0;
         int won = 0;
         int i=0,j=0;
         printf("Matrix Number #%d:\n",t);
         for(;i<4;i++)
         {
             fscanf(fi, "%c%c%c%c\n", &matrix[i][0],&matrix[i][1],&matrix[i][2],&matrix[i][3]);
             printf("%c%c%c%c\n", matrix[i][0],matrix[i][1],matrix[i][2],matrix[i][3]);
         }
 
         char player = matrix[0][0];
         //Check the first diagonal
         int dia = 0;
         if(player == '.')
         {
             incomplete = 1;
         }
         else
         {
             for(;dia<4;dia++)
             {
                 if(matrix[dia][dia]== '.')
                 {
                     incomplete = 1;//fprintf(fo,"Case #%d: Game has not completed",t);
                     dia = -1;
                     break;
                 }
                 if(matrix[dia][dia]!=player && matrix[dia][dia] != 'T')
                 {
                     dia =-1;
                     break;
                 }
             }
             if(dia != -1)
             {
                 fprintf(fo,"Case #%d: %c won\n",t,player);
                 printf("Case #%d: %c won\n",t,player);
                 won =1;
                 continue;
             }
         }
         player = matrix[0][3];
         if(player == '.')
         {
             incomplete = 1;
         }
         else
         {
             dia = 0;
             for(;dia<4;dia++)
             {
                 if(matrix[dia][3-dia]== '.')
                 {
                     incomplete = 1;//fprintf(fo,"Case #%d: Game has not completed",t);
                     dia = -1;
                     break;
                 }
                 if(matrix[dia][3-dia]!=player && matrix[dia][3-dia] != 'T')
                 {
                     dia =-1;
                     break;
                 }
             }
             if(dia != -1)
             {
                 fprintf(fo,"Case #%d: %c won\n",t,player);
                 printf("Case #%d: %c won\n",t,player);
                 won =1;
                 continue;
             }
         }
         //Check for rows
         for(i=0;i<4;i++)
         {
             player = matrix[i][0];
             for(j=0;j<4;j++)
             {
                 if(matrix[i][j] == '.')
                 {
                     incomplete = 1;//fprintf(fo,"Case #%d: Game has not completed",t);
                     j=-1;
                     break;
                 }
                 if(matrix[i][j] != player && matrix[i][j] != 'T')
                 {
                     j= -1;
                     break;
                 }
             }
             if(j!=-1)
             {
                 fprintf(fo,"Case #%d: %c won\n",t,player);
                 printf("Case #%d: %c won\n",t,player);
                 won =1;
                 break;
             }
             player = matrix[0][i];
             for(j=0;j<4;j++)
             {
                 if(matrix[j][i] == '.')
                 {
                     incomplete = 1;//fprintf(fo,"Case #%d: Game has not completed",t);
                     j=-1;
                     break;
                 }
                 if(matrix[j][i] != player && matrix[j][i] != 'T')
                 {
                     j= -1;
                     break;
                 }
             }
             if(j != -1)
             {
                 fprintf(fo,"Case #%d: %c won\n",t,player);
                 printf("Case #%d: %c won\n",t,player);
                 won =1;
                 break;
             }
          }
         if(won == 0 && incomplete== 0)
          {
             fprintf(fo,"Case #%d: Draw\n",t);
             printf("Case #%d: Draw\n",t);
          }
         if(won == 0 && incomplete == 1)
         {
             fprintf(fo,"Case #%d: Game has not completed\n",t);
             printf("Case #%d: Game has not completed\n",t);
         }
     }
 
     fclose(fi);
     fclose(fo);
     return 0;
 }

