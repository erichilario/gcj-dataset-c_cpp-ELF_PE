#include <stdio.h>
 #include <string.h>
 
 #define BOARD_WIDTH	4
 
 enum {
 	DRAW,
 	NOT_COMPLETED
 };
 
 void read_board(int board[BOARD_WIDTH][BOARD_WIDTH], int **pp_t) {
 	int i, j;
 	
 	*pp_t = NULL;
 	
 	for (i = 0; i < BOARD_WIDTH; i++) {
 		char line[BOARD_WIDTH + 1];
 		
 		scanf("%s", line);
 		
 		for (j = 0; j < BOARD_WIDTH; j++) {
 			board[i][j] = line[j];
 			
 			if (*pp_t == NULL && board[i][j] == 'T') {
 				*pp_t = &board[i][j];
 			}
 		}
 	}
 }
 
 int is_full(int board[BOARD_WIDTH][BOARD_WIDTH]) {
 	int i, j;
 	
 	for (i = 0; i < BOARD_WIDTH; i++) {
 		for (j = 0; j < BOARD_WIDTH; j++) {
 			if (board[i][j] == '.') {
 				return 0;
 			}
 		}
 	}
 	
 	return 1;
 }
 
 int is_won(int board[BOARD_WIDTH][BOARD_WIDTH], int symbol) {
 	int i, j;
 	
 	for (i = 0; i < BOARD_WIDTH; i++) {
 		if (board[i][(BOARD_WIDTH - 1) - i] != symbol) {
 			break;
 		}
 	}
 	
 	if (i == BOARD_WIDTH) {
 		return 1;
 	}
 	
 	for (i = 0; i < BOARD_WIDTH; i++) {
 		if (board[i][i] != symbol) {
 			break;
 		}
 	}
 	
 	if (i == BOARD_WIDTH) {
 		return 1;
 	}
 	
 	for (i = 0; i < BOARD_WIDTH; i++) {
 		for (j = 0; j < BOARD_WIDTH; j++) {
 			if (board[i][j] != symbol) {
 				break;
 			}
 		}
 		
 		if (j == BOARD_WIDTH) {
 			return 1;
 		}
 		
 		for (j = 0; j < BOARD_WIDTH; j++) {
 			if (board[j][i] != symbol) {
 				break;
 			}
 		}
 		
 		if (j == BOARD_WIDTH) {
 			return 1;
 		}
 	}
 	
 	return 0;
 }
 
 #define ARRAY_SIZE(a)	(sizeof(a) / sizeof(a[0]))
 
 int get_state(int board[BOARD_WIDTH][BOARD_WIDTH], int *p_t) {
 	int symbols[] = {'O', 'X'};
 	int i;
 	
 	for (i = 0; i < ARRAY_SIZE(symbols); i++) {
 		if (p_t) {
 			*p_t = symbols[i];
 		}
 		
 		if (is_won(board, symbols[i])) {
 			return symbols[i];
 		}
 	}
 
 	if (is_full(board)) {
 		return DRAW;
 	}
 	
 	return NOT_COMPLETED;
 }
 
 void print_state(int n, int state) {
 	switch (state) {
 		case DRAW:
 			printf("Case #%d: Draw\n", n);
 			break;
 		
 		case NOT_COMPLETED:
 			printf("Case #%d: Game has not completed\n", n);
 			break;
 			
 		default:
 			printf("Case #%d: %c won\n", n, state);
 			break;
 	}
 }
 
 int main() {
 	int case_cnt;
 	int i;
 	
 	scanf("%d", &case_cnt);
 	
 	for (i = 0; i < case_cnt; i++) {
 		int board[BOARD_WIDTH][BOARD_WIDTH];
 		int *p_t;
 		int state;
 		
 		read_board(board, &p_t);
 		state = get_state(board, p_t);
 		print_state(i + 1, state);
 	}
 	
 	return 0;
 }
 

