#include<stdio.h>
 #include<stdlib.h>
 
 int sqr_palin[]={1,4,9,121,484};//On long set, evaluate squares of each number less than Max_Val and check if it is palindrome.
 int NFP=5;
 int test_fp(int a,int b)
 {
 int i,count=0;
 for(i=0;i<NFP;i++)
 {
 if(a>sqr_palin[i])
 	continue;
 if(b<sqr_palin[i])
 	break;
 count=count+1;
 }
 return count;
 }
 int main()
 {
 int i,N,A,B,res;
 
 
 scanf("%d",&N);
 for(i=0;i<N;i++)
 {
 scanf("%d%d",&A,&B);
 res=test_fp(A,B);
 printf("Case #%d: %d\n",i+1,res);
 }
 return 0;
 
 }

