
 #include<stdio.h> 
 #include<string.h> 
 #include<stdlib.h> 
 #include<math.h> 
 int main(void) 
 { 
        FILE* fp= fopen("input","r");
        FILE* f = fopen("output","w");
 	      int IsSquare(int n);
         int T,m,c,i,k; 
         int palindrome(int a);
         char ch;
         fscanf(fp,"%d",&T);
         fscanf(fp,"%c",&ch); 
         int A[T],B[T]; 
         for(i=1;i<=T;i++) 
         { 
                 fscanf(fp,"%d %d",&A[i],&B[i]);
                 fscanf(fp,"%c",&ch); 
         } 
         for(i=1;i<=T;i++)
         {
          c=0;
          for(m=A[i];m<=B[i];m++) 
          {
 	    if((floor(log10(abs(m)))+1)!=2|| 4|| 8|| 10|| 14|| 18|| 20|| 24|| 30|| 38|| 40)
 	    {
 		if(m%10 == 1||4||5||6||9)
 		{
                          k=IsSquare(m); 
                          if(k)
                          { 
                            if(palindrome(k))
                            {
                              if(palindrome(m))
                              c++;
                            }
                          }
 		}
 	}
          }
                 fprintf(f,"Case #%d: %d\n",i,c);
         }
         return 0;
 } 
 int IsSquare(int n)
 {
 	int h = n/2;
 	int l = 0;
 	if(n==1)
 		return 1;
 	while(h>=l)
 	{
 		int mid = (l + h)/2;
 		int square = mid * mid;
 		if(square==n)
 		{
 			return mid;
 		}
 		if(square > n)
 		{
 			h = mid-1;
 		}
 		else
 		{
 			l = mid+1;
 		}
 	}
 	return 0;
 } 	
 int palindrome(int a)
 {
     int rev = 0, temp;
     temp = a;
    while( temp != 0 )
    {
       rev = rev*10;
       rev = rev + temp%10;
       temp = temp/10;
    }
    if ( a == rev )
       return 1;
    else
        return 0;
        
 }
 

