#include <stdio.h>
 #include <stdbool.h>
 int lawn[101][101];
 int rMax[101];
 int cMax[101];
 
 int main()
 {
 	freopen("B-large.in", "r", stdin);
 	freopen("lawn.txt", "w", stdout);
 	int t,a;
 	scanf("%d", &t);
 	for(a = 1; a <= t; a++)
 	{
 		int n,m,i,j;
 		bool possible = true;
 		scanf("%d %d", &n, &m);
 
 		for(i = 0;i < n; i++)
 		{
 			for(j = 0; j < m; j++)
 			{
 				scanf("%d", &lawn[i][j]);
 				if(lawn[i][j] > rMax[i])	rMax[i] = lawn[i][j];
 				if(lawn[i][j] > cMax[j])	cMax[j] = lawn[i][j];
 			}
 		}
 
 		for(i = 0; i < n; i++)
 		{
 			if(!possible)	break;
 			for(j = 0; j < m; j++)
 				if(lawn[i][j] != rMax[i] && lawn[i][j] != cMax[j])
 					possible = false;
 		}
 
 		if(possible)
 			printf("Case #%d: YES\n", a);
 		else	printf("Case #%d: NO\n", a);
 		for(i = 0; i < 101; i++)
 		{
 			rMax[i] = 0;
 			cMax[i] = 0;
 		}
 
 	}
 	return 0;
 }

