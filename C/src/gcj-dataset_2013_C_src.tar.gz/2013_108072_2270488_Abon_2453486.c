#include <stdio.h>
 
 /*inline void check_row(char i){
 	if(arr[i]0]!='T'){
 		xo=arr[i][0]
 		if((arr[i][1]==xo || arr[i][1]=='T')
 		&& (arr[i][2]==xo || arr[i][2]=='T')
 		&& (arr[i][3]==xo || arr[][2]=='T'))
 	}else{
 		xo=arr[i][3]
 		if((arr[i][2]==xo)
 		&& (arr[i][1]==xo)
 		//first is 'T'
 	}
 }*/
 
 int main(){
 	int n;
 	scanf("%d\n",&n);	
 	char arr[4][5];
 	char empty_line[1];
 	char xo; //first character in a line or row
 
 	int T=0;
 	char *p, *p_lim=(char*)arr+20;
 	while(++T<=n){
 		gets(arr[0]);
 		gets(arr[1]);
 		gets(arr[2]);
 		gets(arr[3]);
 		gets(empty_line);
 		/*printf("@1 %s\n", arr[0]);
 		printf("@2 %s\n", arr[1]);
 		printf("@3 %s\n", arr[2]);
 		printf("@4 %s\n", arr[3]);*/
 		//check rows
 		//0
 		xo=arr[0][0];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[0][1]==xo || arr[0][1]=='T')
 				&& (arr[0][2]==xo || arr[0][2]=='T')
 				&& (arr[0][3]==xo || arr[0][3]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[0][3]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[0][2]==xo)
 					&& (arr[0][1]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		//1
 		xo=arr[1][0];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[1][1]==xo || arr[1][1]=='T')
 				&& (arr[1][2]==xo || arr[1][2]=='T')
 				&& (arr[1][3]==xo || arr[1][3]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[1][3]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[1][2]==xo)
 					&& (arr[1][1]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		//2
 		xo=arr[2][0];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[2][1]==xo || arr[2][1]=='T')
 				&& (arr[2][2]==xo || arr[2][2]=='T')
 				&& (arr[2][3]==xo || arr[2][3]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[2][3]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[2][2]==xo)
 					&& (arr[2][1]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		//3
 		xo=arr[3][0];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[3][1]==xo || arr[3][1]=='T')
 				&& (arr[3][2]==xo || arr[3][2]=='T')
 				&& (arr[3][3]==xo || arr[3][3]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[3][3]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[3][2]==xo)
 					&& (arr[3][1]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		//check columns
 		//0
 		xo=arr[0][0];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[1][0]==xo || arr[1][0]=='T')
 				&& (arr[2][0]==xo || arr[2][0]=='T')
 				&& (arr[3][0]==xo || arr[3][0]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[3][0]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[2][0]==xo)
 					&& (arr[1][0]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		//1
 		xo=arr[0][1];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[1][1]==xo || arr[1][1]=='T')
 				&& (arr[2][1]==xo || arr[2][1]=='T')
 				&& (arr[3][1]==xo || arr[3][1]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[3][1]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[2][1]==xo)
 					&& (arr[1][1]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		//2
 		xo=arr[0][2];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[1][2]==xo || arr[1][2]=='T')
 				&& (arr[2][2]==xo || arr[2][2]=='T')
 				&& (arr[3][2]==xo || arr[3][2]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[3][2]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[2][2]==xo)
 					&& (arr[1][2]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		//3
 		xo=arr[0][3];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[1][3]==xo || arr[1][3]=='T')
 				&& (arr[2][3]==xo || arr[2][3]=='T')
 				&& (arr[3][3]==xo || arr[3][3]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[3][3]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[2][3]==xo)
 					&& (arr[1][3]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		//check diagonals
 		//from left top to right bottom
 		xo=arr[0][0];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[1][1]==xo || arr[1][1]=='T')
 				&& (arr[2][2]==xo || arr[2][2]=='T')
 				&& (arr[3][3]==xo || arr[3][3]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[3][3]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[2][2]==xo)
 					&& (arr[1][1]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		//from left bottom to right top
 		xo=arr[3][0];
 		if(xo!='.'){
 			if(xo!='T'){
 				if((arr[2][1]==xo || arr[2][1]=='T')
 				&& (arr[1][2]==xo || arr[1][2]=='T')
 				&& (arr[0][3]==xo || arr[0][3]=='T')){
 					printf("Case #%d: %c won\n", T, xo);
 					continue;
 				}
 			}else{
 				xo=arr[0][3]; //can't compare to 'T'
 				if(xo!='.'){
 					if((arr[1][2]==xo)
 					&& (arr[2][1]==xo)){
 						printf("Case #%d: %c won\n", T, xo);
 						continue;
 					}
 					//first is 'T'
 				}
 			}
 		}
 		p=(char*)arr;
 		while(p<=p_lim && *p!='.') ++p;
 		if(p<=p_lim) printf("Case #%d: Game has not completed\n", T);
 		else printf("Case #%d: Draw\n", T);
 	}
 
 return 0;
 }
 

