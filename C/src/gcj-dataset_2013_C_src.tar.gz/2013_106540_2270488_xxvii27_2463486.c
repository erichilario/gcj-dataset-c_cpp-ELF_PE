#include<stdio.h>
 #include<math.h>
 #include<string.h>
 
 int  isSquareRoot (int n);
 int  isPalindrome (int n);
 
 int main(void)
 {
 
     FILE *input = fopen("C-small-attempt5.in", "r");
     FILE *output = fopen("Csmall-output.txt", "w");
     int cases, cnt = 0;
     int a, b;
     int num = 0;
     fscanf(input, "%d", &cases);
     while(cnt<cases && fscanf(input, "%d %d", &a, &b)!=EOF){
         while(a<=b){
              if(isPalindrome(a) && isSquareRoot(a)){
                 if(isPalindrome((int) sqrt(a)))
                     num++;
              }
              a++;
         }
         fprintf(output, "Case #%d: %d\n", cnt + 1, num);
         num = 0;
         cnt++;
     }
     fclose(input);
     fclose(output);
     return 0;
 }
 
 int  isSquareRoot (int n){
    double ch;
     if(n<0)
         return 0;
 
    ch = sqrt(n);
    return ch*ch==n;
 }
 
 int  isPalindrome (int n){
     char sn[10], temp[10];
 
     sprintf(sn, "%d", n);
     strcpy(temp, sn);
     strrev(sn);
     return (strcmp(sn, temp)==0);
 }

