#include <stdio.h>
 #include <string.h>
 
 char* mul (char *n, int j)
 	{
 	int i, carry; char mult[100], *ptr;
 
 	ptr=mult;
 	i=strlen(n);
 	mult[i+1]='\0';
 	i--;
 	carry=0;
 	while (i>=0)
 		{
 		mult[i+1]=(((n[i]-'0')*j+carry)%10)+'0';
 		carry=((n[i]-'0')*j+carry)/10;
 		i--;
 		}
 	mult[0]=carry+'0';
 
 	printf ("%s\n",ptr);
 	return ptr;
 	}
 
 char *sub (char *m, char *n)
 	{
 	int i, j, k, l;
 	char res[100], *ptr, carry='0';
 
 	ptr=res;
 	i=strlen(m);
 	j=strlen(n);
 
 	for (k=i-1, l=j-1; k>=0; k--, l--)
 		if (l<0)
 			{
 			res[k]=((m[k]-carry)>=0)?(m[k]-carry+'0'):(m[k]-carry+10+'0');
 			carry=((m[k]-carry)>=0)?'0':'1';
 			}
 		else 
 			{
 			res[k]=((m[k]-n[l]-carry+'0')>=0)?(m[k]-n[l]-carry+'0'+'0'):(m[k]-n[l]-carry+'0'+10+'0');
 			carry=((m[k]-n[l]-carry+'0')>=0)?'0':'1';
 			}
 
 	res[i]='\0';
 
 	printf ("%s\n",ptr);
 	return ptr;
 	}
 
 char *add (char *m)
 	{
 	int i, carry; char res[100], *ptr; 
 	
 	i=strlen(m);
 	ptr=res;
 
 	res[i+1]='\0';
 
 	carry=m[--i]-'0';
 
 	while (i>=0)
 		{
 		res[i+1]=((m[i]-'0'+carry)%10)+'0';
 		carry=(m[i]-'0'+carry)/10;
 		i--;
 		}
 	res[0]=carry+'0';
 
 	printf ("%s\n",ptr);
 	return ptr;
 	}
 
 int less_than (char *mult, char *m)
 	{
 	int i, j, k, x=0, y=0;
 	char a[100], b[100];
 	while (mult[x]=='0')	x++;
 	while (m[y]=='0')	y++;
 	for (i=0; mult[x]!='\0'; a[i]=mult[x], i++, x++);
 	for (j=0; m[y]!='\0'; b[j]=m[y], j++, y++);
 	if (i<j)	return 1;
 	if (i>j)	return 0;
 	for (k=0; a[k]!='\0' && a[k]==b[k]; k++);
 	if (k==i || a[k]<b[k])	return 1;
 	return 0;
 	}
 
 int find_quot (char* m, char* n)
 	{
 	int i, j;
 	char p[100];
 	strcpy(p,n);
 	i=strlen(n);	
 	p[i]='0'; p[i+1]='\0';
 	for (j=0; less_than(mul(p,j),m)==1; p[i]=++j+'0');
 	return (j-1);
 	}
 
 char *find_sqrt (char *val)
 	{
 	int i, j, t, x;
 	char left[100],sqrt[100],str[3],mult[100],*ptr,*ptr1;
 
 	i=strlen(val);
 
 	mult[0]=(i%2==0)?val[0]:'0';
 	mult[1]=(i%2==0)?val[1]:val[0];
 	mult[2]='\0';
 
 	j=0;
 
 	t=find_quot(mult,"");
 	left[0]=t+'0';
 	left[1]='\0';
 	sqrt[0]=t+'0';
 
 	for (i=2-(i%2); val[i]!='\0'; i+=2)
 		{
 		str[0]=val[i];
 		str[1]=val[i+1];
 		str[2]='\0';
 		ptr=sub(mult,mul(left,t));
 		strcat(ptr,str);
 		strcpy(mult,ptr);
 		ptr=add(left);
 		strcpy(left,ptr);
 		t=find_quot(mult,left);
 		sqrt[++j]=t+'0';
 		}
 		
 	x=strlen(left);
 	left[x]=sqrt[j];
 	left[x+1]='\0';
 	ptr1=sub(mult, mul(left,t));
 		
 	for (i=0; ptr1[i]!='\0'; i++)	
 		if (ptr1[i]!='0')
 			return "";
 
 	sqrt[++j]='\0';
 	ptr=sqrt;
 	printf ("%s\n",ptr);
 	return ptr;
 	}
 
 int is_palin (char *b)
 	{
 	int i=0, j;
 
 	j=strlen(b)-1;
 
 	if (j==-1)	return 0;
 
 	while (i<=j && b[i]==b[j])
 		{
 		j--; i++;
 		}
 
 	if (j>i)	return 0;
 	else		return 1;
 	}	
 
 int main ()
 	{
 	FILE *fp;
         int i, k, l, T, carry, count, A, B;
 	char a[100], b[100], h[100], *j;
 
         fp=fopen("FAIRSQR.out", "w");
 
         scanf ("%d",&T);
 
 
         for (i=0; i<T; i++)
         	{
 		count=0;
 		scanf ("%d", &A);
                 scanf ("%d", &B);
 
 		/*scanf ("%s", a);
 		scanf ("%s", b);
 		
 		for (j=a; less_than(j,b)==1;)
 			{
 			fprintf (fp,"feed %s ", j);
 			if (is_palin(j) && is_palin(find_sqrt(j)))
 				count++;
 			carry=1;
 			l=strlen(b)-strlen(j);
                 	for (k=0; k<l; k++)
                         	h[k]='0';
                 	h[k]='\0';
                 	strcat(h,j);
                 	strcpy(j,h);
 			for (k=strlen(j)-1;k>=0;k--)
 				{
 				j[k]=((j[k]+carry)>'9')?'0':(j[k]+carry);
 				carry=((j[k]+carry)>'9')?1:0;
 				}
 			k=0; l=0;
 			while (j[k]=='0')       k++;
                         while (j[k]!='\0')      h[l++]=a[k++];
                         h[l]='\0';
                         strcpy(j,h);
 			}*/
 
 		for (k=A; k<=B; k++)
 			{
 			sprintf(h,"%d",k);
 			
 			if (is_palin(h) && is_palin(find_sqrt(h)))
 				{
 				count++;
 				}
 			h[0]='\0';
 			}
 
 		fprintf (fp,"Case #%d: %d\n",i+1,count);
 		}
 
 	return 0;
 	}

