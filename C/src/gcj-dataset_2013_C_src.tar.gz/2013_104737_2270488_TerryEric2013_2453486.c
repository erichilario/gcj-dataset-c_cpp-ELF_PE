#include <stdio.h>
 //#include <curses.h>
 #define XWON 1
 #define OWON 2
 #define DRAW 3
 #define INCOMPLETE 4
 int eval_board(char (*ptr)[5]);
 
 int main(void)
 {
     FILE *fp;
     FILE *out;
     int loopmax;
   int i,j;
   char board[4][5];
   int result;
 
   out = fopen ("outdata.txt","w");
   if (out==NULL)
   {
        printf("cant open the output file\n");
      getche();
   return 0; 
   }
 
   fp = fopen ("data.txt","r");
   if (fp==NULL)
   {
        printf("cant open the input file\n");
      getche();
   return 0; 
   }
   fscanf(fp,"%d",&loopmax);
 //  printf("loopmax = %d\n",loopmax);
 
   for(i=0;i<loopmax;i++)
   {
    for(j=0;j<4;j++)
    {
      fscanf(fp,"%s\n",board[j]);
 //     printf("%s\n",board[j]);
      
    }
    result=eval_board(board);
    fscanf(fp,"\n");
    if(i==loopmax-1)
    {
    switch(result)
    {
        case XWON:
        fprintf(out,"Case #%d: X won",i+1);
        break;
        case OWON:
        fprintf(out,"Case #%d: O won",i+1);
        break;
        case DRAW:
        fprintf(out,"Case #%d: Draw",i+1);
        break;
        default:
        fprintf(out,"Case #%d: Game has not completed",i+1);
        break;
    }
    }
    else
    {
    switch(result)
    {
        case XWON:
        fprintf(out,"Case #%d: X won\n",i+1);
        break;
        case OWON:
        fprintf(out,"Case #%d: O won\n",i+1);
        break;
        case DRAW:
        fprintf(out,"Case #%d: Draw\n",i+1);
        break;
        default:
        fprintf(out,"Case #%d: Game has not completed\n",i+1);
        break;
    }
    }
   }
 
 fclose(fp);
 fclose(out);
   return 0;
 }
 int eval_board(char (*ptr)[5])
 {
     int i;
     int j;
 
     //accross
   for(i=0;i<4;i++)
   {
      if( (ptr[i][0]=='X' || ptr[i][0]=='T') &&
          (ptr[i][1]=='X' || ptr[i][1]=='T') &&
          (ptr[i][2]=='X' || ptr[i][2]=='T') &&
          (ptr[i][3]=='X' || ptr[i][3]=='T') )
        return XWON;
      if( (ptr[i][0]=='O' || ptr[i][0]=='T') &&
          (ptr[i][1]=='O' || ptr[i][1]=='T') &&
          (ptr[i][2]=='O' || ptr[i][2]=='T') &&
          (ptr[i][3]=='O' || ptr[i][3]=='T') )
        return OWON;
   }
 
   for(i=0;i<4;i++)
   {
      if( (ptr[0][i]=='X' || ptr[0][i]=='T') &&
          (ptr[1][i]=='X' || ptr[1][i]=='T') &&
          (ptr[2][i]=='X' || ptr[2][i]=='T') &&
          (ptr[3][i]=='X' || ptr[3][i]=='T') )
        return XWON;
      if( (ptr[0][i]=='O' || ptr[0][i]=='T') &&
          (ptr[1][i]=='O' || ptr[1][i]=='T') &&
          (ptr[2][i]=='O' || ptr[2][i]=='T') &&
          (ptr[3][i]=='O' || ptr[3][i]=='T') )
        return OWON;
   }
 
      if( (ptr[0][0]=='X' || ptr[0][0]=='T') &&
          (ptr[1][1]=='X' || ptr[1][1]=='T') &&
          (ptr[2][2]=='X' || ptr[2][2]=='T') &&
          (ptr[3][3]=='X' || ptr[3][3]=='T') )
        return XWON;
      if( (ptr[0][0]=='O' || ptr[0][0]=='T') &&
          (ptr[1][1]=='O' || ptr[1][1]=='T') &&
          (ptr[2][2]=='O' || ptr[2][2]=='T') &&
          (ptr[3][3]=='O' || ptr[3][3]=='T') )
        return OWON;
      if( (ptr[0][3]=='X' || ptr[0][3]=='T') &&
          (ptr[1][2]=='X' || ptr[1][2]=='T') &&
          (ptr[2][1]=='X' || ptr[2][1]=='T') &&
          (ptr[3][0]=='X' || ptr[3][0]=='T') )
        return XWON;
      if( (ptr[0][3]=='O' || ptr[0][3]=='T') &&
          (ptr[1][2]=='O' || ptr[1][2]=='T') &&
          (ptr[2][1]=='O' || ptr[2][1]=='T') &&
          (ptr[3][0]=='O' || ptr[3][0]=='T') )
        return OWON;
 
 
     for(i=0;i<4;i++)
   {
       for(j=0;j<4;j++)
       {
           if(ptr[i][j]=='.')
             return(INCOMPLETE);
       }
   }
   return DRAW;
 }
 

