#include <stdio.h>
 
 int m[4][4];
 int X = 0;
 int O = 0;
 int F = 1;
 
 void resolver(){
 	
 	int i;
 	int j;
 	int x = 0;
 	int o = 0;
 	
 	// cuantos horizontales hizo O
 	for (i=0;i<4;i++){
 		o=0;
 		for (j=0;j<4;j++){
 			if (o==j && (m[i][j]=='O' || m[i][j]=='T')) o++;
 			if (m[i][j]=='.') F = 0;
 		}
 		if (o==4) O=1;
 	}
 	// cuantos verticales hizo O
 	if (!O) for (j=0;j<4;j++){
 		o=0;
 		for (i=0;i<4;i++){
 			if (o==i && (m[i][j]=='O' || m[i][j]=='T')) o++;
 			if (m[i][j]=='.') F = 0;
 		}
 		if (o==4) O=1;
 		
 	}
 	
 	// cuantos horizontales hizo X
 	for (i=0;i<4;i++){
 		x=0;
 		for (j=0;j<4;j++){
 			if (x==j && (m[i][j]=='X' || m[i][j]=='T')) x++;
 		}
 		if (x==4) X=1;
 		if (X==1) break;
 	}
 	if (!X) for (j=0;j<4;j++){
 		x=0;
 		for (i=0;i<4;i++){
 			if (x==i && (m[i][j]=='X' || m[i][j]=='T')) x++;
 		}
 		if (x==4) X=1;
 		if (X==1) break;
 	}
 
 	o=0;
 	if (!O) for (i=0; i<4; i++){
 		if (o==i && (m[i][i]=='O' || m[i][i]=='T')) o++;
 	}
 	if (o==4) O=1;
 	
 	x=0;
 	if (!X) for (i=0; i<4; i++){
 		if (x==i && (m[i][i]=='X' || m[i][i]=='T')) x++;
 	}
 	if (x==4) X=1;
 	
 	/*
 	XXXO
 	..O.
 	.O..
 	T...
 	*/
 	
 	o=0;
 	if (!O) for (i=0; i<4; i++){
 		if (o==i && (m[3-i][i]=='O' || m[3-i][i]=='T')) o++;
 	}
 	if (o==4) O=1;
 	
 	x=0;
 	if (!X) for (i=0; i<4; i++){
 		if (x==i && (m[3-i][i]=='X' || m[3-i][i]=='T')) x++;
 	}
 	if (x==4) X=1;
 }
 
 int main(){
 
 	int ndc;
 	int caso;
 	scanf("%d\n",&ndc);
 	
 	for(caso=0; caso<ndc; caso++){
 		
 		//printf("caso %d\n", caso +1);
 		
 		X = 0;
 		O = 0;
 		F = 1;
 		
 		int i;
 		int j;
 		for (i=0;i<4;i++)
 		{
 			for (j=0;j<4;j++)
 			{
 				scanf("%c",&m[i][j]);
 			}
 			scanf("\n");
 		}
 		scanf("\n");
 		
 		/*for (i=0;i<4;i++)
 		{
 			for (j=0;j<4;j++)
 			{
 				printf("%c",m[i][j]);
 			}
 			printf("\n");
 		}*/
 		
 		resolver();	
 				
 		// imprimir resultado
 		printf("Case #%d: %s\n",caso+1,
 				X && O || (F && !X && !O)? 
 					"Draw" :
 					X ? 
 						"X won" :
 						O ? 
 							"O won" :
 							"Game has not completed"
 		);
 	}
 	return 0;
 }

