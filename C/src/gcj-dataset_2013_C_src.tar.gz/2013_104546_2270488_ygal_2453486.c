#include "stdio.h"
 #include "stdlib.h"
 
 
 char A[4][4];
 
 int checkIfWon(char symb)
 {
 	return( A[0][0] == symb && A[0][1] == symb && A[0][2] == symb && A[0][3] == symb ||
 		A[1][0] == symb && A[1][1] == symb && A[1][2] == symb && A[1][3] == symb ||
 		A[2][0] == symb && A[2][1] == symb && A[2][2] == symb && A[2][3] == symb ||
 		A[3][0] == symb && A[3][1] == symb && A[3][2] == symb && A[3][3] == symb ||
 
 		A[0][0] == symb && A[1][0] == symb && A[2][0] == symb && A[3][0] == symb ||
 		A[0][1] == symb && A[1][1] == symb && A[2][1] == symb && A[3][1] == symb ||
 		A[0][2] == symb && A[1][2] == symb && A[2][2] == symb && A[3][2] == symb ||
 		A[0][3] == symb && A[1][3] == symb && A[2][3] == symb && A[3][3] == symb ||
 
 		A[0][0] == symb && A[1][1] == symb && A[2][2] == symb && A[3][3] == symb ||
 		A[0][3] == symb && A[1][2] == symb && A[2][1] == symb && A[3][0] == symb);
 	
 
 }
 int main()
 {
 	int T = 0;
 	
 	char tmp;
 	char symb;
 	int tPos[2];
 	int t, i, j, res, gameInProgress;
 	
 
 	FILE* fIn = fopen("A-large (1).in", "r");
 	FILE* fOut = fopen("solution.out", "w");
 	fscanf(fIn, "%d\n", &T);
 	
 	//fprintf(fOut, "T = %d, N = %d\n", T, N);
 	for (t=1; t<=T; t++)
 	{
 		tPos[0] = -1;
 		res = 0;
 		gameInProgress = 0;
 		for (i=0; i<4; i++)
 		{
 			fscanf(fIn, "%c%c%c%c\n", &A[i][0],&A[i][1],&A[i][2],&A[i][3] );
 		}
 		fscanf(fIn, "\n", &tmp );
 		
 		for (i=0; i<4;i++)
 		{
 			for (j=0; j<4;j++)
 			{
 				if(A[i][j] == 'T')
 				{
 					tPos[0] = i;
 					tPos[1] = j;
 				}
 				if(A[i][j] == '.')
 				{
 					gameInProgress = 1;
 				}
 			}
 		}
 		for (i=0; i<2; i++)
 		{
 			symb = (i==0)?'X':'O';
 			if(tPos[0] != -1)
 			{
 				A[tPos[0]][tPos[1]] = symb;
 			}
 			if(checkIfWon(symb))
 			{
 				fprintf(fOut, "Case #%d: %c won\n", t, symb);
 				break;
 			}
 		}
 		if ( i ==2 ) //no one won
 		{
 			if( gameInProgress == 1)
 			{
 				fprintf(fOut, "Case #%d: Game has not completed\n", t);
 			}
 			else
 			{
 				fprintf(fOut, "Case #%d: Draw\n", t);
 			}
 		}
 	}
 }
 
 
 
 

