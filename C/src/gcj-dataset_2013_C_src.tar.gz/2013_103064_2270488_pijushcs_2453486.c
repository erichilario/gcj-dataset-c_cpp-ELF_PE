#include<stdio.h>
 #include<ctype.h>
 #include<stdlib.h>
 
 int main(){
     FILE *fp;
     char str[10],tic[10][10];
     int t,winx,winy,x,y,flg=0,k,i,j;
     freopen("ans1.txt","w",stdout);
     fp=fopen("abc.in","r");
     fgets(str,10,fp);
     t=atoi(str);
     for(k=0;k<t;k++){
       flg=0; winx=0; winy=0;
       for(i=0;i<4;i++)
         fgets(tic[i],10,fp);
       for(i=0;i<4;i++){
         x=0; y=0;
         for(j=0;j<4;j++){
           if(tic[i][j]=='X')
             x++;
           else if(tic[i][j]=='O')
             y++;
           else if(tic[i][j]=='T'){
             x++; y++;
           }
           else if(tic[i][j]=='.')
             flg=1;
         }
         if(x==4)
           winx=1;
         else if(y==4)
           winy=1;
       }
       for(i=0;i<4;i++){
         x=0; y=0;
         for(j=0;j<4;j++){
           if(tic[j][i]=='X')
             x++;
           else if(tic[j][i]=='O')
             y++;
           else if(tic[j][i]=='T'){
             x++; y++;
           }
         }
         if(x==4)
           winx=1;
         else if(y==4)
           winy=1;
       }
       x=0;
       y=0;
       for(j=0;j<4;j++){
           if(tic[j][j]=='X')
             x++;
           else if(tic[j][j]=='O')
             y++;
           else if(tic[j][j]=='T'){
             x++; y++;
           }
       }
       if(x==4)
          winx=1;
       else if(y==4)
          winy=1;
      x=0; y=0;
       for(j=3,i=0;i<4;j--,i++){
           if(tic[i][j]=='X')
             x++;
           else if(tic[i][j]=='O')
             y++;
           else if(tic[i][j]=='T'){
             x++; y++;
           }
       }
       if(x==4)
          winx=1;
       else if(y==4)
          winy=1;
      
       if(winx==1)
         printf("Case #%d: X won\n",k+1);
       else if(winy==1)
         printf("Case #%d: O won\n",k+1);
       else if(flg)
         printf("Case #%d: Game has not completed\n",k+1);
       else 
         printf("Case #%d: Draw\n",k+1);
       fgets(str,10,fp);
     }
     getch();
 }

