#include <stdio.h>
 #include <stdlib.h>
 
 #define LEN 6
 
 int Win(char [][4],char);
 int finished(char [][4]);
 int getCases(FILE**);
 
 int main()
 {
 	FILE* fp,* FileToSave;
 	char* fl,winO,winX;
 	char temp[4][4];
 	int cases,GameNumber,i,j;
 	fl = "A-large.in";
 	fp = fopen(fl,"r");
 	if (fp != NULL)
 	{
 		FileToSave = fopen("results big.txt","w");
 		cases = getCases(&fp);
 		for(GameNumber=0 ; GameNumber<cases ; GameNumber++)
 		{
 			for(i=0 ; i<4 ; i++)
 			{
 				for(j=0 ; j<4 ; j++)
 				{
 					temp[i][j] = fgetc(fp);
 				}
 				fgetc(fp);					//\n ka8e grammhs
 			}
 			winX = Win(temp,'X');
 			if (winX == 1)
 				fprintf(FileToSave,"Case #%d: X won\n",GameNumber+1);
 			else
 			{
 				winO = Win(temp,'O');
 				if (winO == 1)
 					fprintf(FileToSave,"Case #%d: O won\n",GameNumber+1);
 				else
 				{
 					if (finished(temp) == 1)
 						fprintf(FileToSave,"Case #%d: Draw\n",GameNumber+1);
 					else
 						fprintf(FileToSave,"Case #%d: Game has not completed\n",GameNumber+1);
 				}
 			}
 			fgetc(fp);						//gia \n ka8e block
 		}
 		printf("done!");
 		fclose(FileToSave);
 		fclose(fp);
 		system("results big.txt");
 	}
 	system("pause");
 }
 
 int Win(char temp[][4],char ch)
 {
 	int column,row,diagonal,rdiagonal,winX = 0,i,j;
 	diagonal = 0;
 	rdiagonal = 0;
 	for(i=0 ; i<4 ; i++)
 	{
 		column = 0;
 		row = 0;
 		for(j=0 ; j<4 ; j++)		//gia ton X
 		{
 			if (temp[i][j] == ch || temp[i][j] == 'T') 
 				row++;
 			if (temp[j][i] == ch || temp[j][i] == 'T')
 				column++;	
 		}
 		if (temp[i][i] == ch || temp[i][i] == 'T')
 			diagonal++;
 		if (temp[i][3-i] == ch || temp[i][3-i] == 'T')
 			rdiagonal++;
 		if (column == 4 || row == 4 || diagonal == 4 || rdiagonal == 4)
 		{
 			winX = 1;
 			break;
 		}
 
 	}
 	return winX;
 }
 
 int finished(char temp [][4])
 {
 	int i,j;
 	for(i=0 ; i<4 ; i++)
 		for(j=0 ; j<4 ; j++)
 			if (temp[i][j] == '.')
 				return 0;
 	return 1;
 }
 
 int getCases(FILE** fp)
 {
 	char ch,string[LEN];
 	int i;
 	for(i=0 ; i<LEN ; i++)
 		string[i] = 0;
 	ch = getc(*fp);
 	for(i=0 ; (ch != '\n') && (ch != EOF) ; i++)
 	{
 		string[i] = ch;
 		ch = getc(*fp);
 	}
 	return atoi(string);
 }
