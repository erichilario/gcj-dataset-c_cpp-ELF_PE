#include <stdio.h>
 #include <math.h>
 int main()
 {
 	int n,i;
 	scanf("%d",&n);
 	for (i=0;i<n;i++)
 	{
 		int a,b,count=0;
 		scanf("%d %d",&a,&b);
 		int k;
 		for (k=a;k<=b;k++)
 		{
 			if (is_palindrom(k) && is_psquare(k))
 			{
 			   int srt=sqrt(k);
 				 if(is_palindrom(srt))
 					count++;
 			}
 		}
 		printf("Case #%d: %d\n",i+1,count);
 	}	
 	return 0;
 }
 int is_palindrom(int no)
 {
 	int temp=no;
 	int remainder,new_no=0;
 	while (no>0)
 	{
 	 remainder=no%10;
 	 no=no/10;
 	 new_no+=remainder;
 	 new_no*=10;
 
 	}
 	new_no/=10;
 //	printf("original = %d \n reverse = %d",temp,new_no);
 	return (new_no==temp);
 }
 int is_psquare(int no)
 {
 	int tmp=(int) sqrt(no);
 	return  ((tmp*tmp)==no);
 
 }

