#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 //Function Declarations
 //File I/O
 void saveFile (int, int, char *);
 int load(char board[1000][4][4]);
 
 //Tic Tac Toe Functions
 int checker(char [4][4]);
 void printBoard (int, char [1000][4][4]);
 
 //Main
 int main(int argc, char *argv[])
 {
 	//Variable Declarations
 	int result, i;
 	int numberOfCases;
 	char board[1000][4][4];
 	
 	//Resize console window
 	//system ("mode con: cols=150 lines=2000");
 	
 	
 	numberOfCases = load(board);
 	printBoard(numberOfCases, board);
 	
 	for (i=0; i<numberOfCases; i++)
 	{
 		result = checker(board[i]);
 		saveFile (result, i, "output.txt");
 		
 	}
 	
 	
 	//saveFile (loadedFile, "test.txt");
 	
 	system ("pause");
 	return 0;
 }
 
 void saveFile (int result, int caseNumber, char *fileName)
 {
 	int i;
 	
 	FILE *fp;
 	fp = fopen (fileName, "a");
 	
 	if (fp!=NULL)
 	{
 			fprintf(fp, "Case #%d: ", caseNumber+1);
 			if (result==0)
 				fprintf (fp, "Draw\n");
 			if (result==1)
 				fprintf (fp, "X won\n");
 			if (result==2)
 				fprintf (fp, "O won\n");
 			if (result==3)
 				fprintf (fp, "Game has not completed\n");
 	}
 	else
 		printf ("Error opening file");
 	fclose(fp);
 }
 
 int load(char board[1000][4][4])
 {
      int i, m, n, cases;
      char ch;
      FILE *fp;
      fp = fopen("input.txt","r");
      fscanf(fp,"%d",&cases);
      m=0;
      n=0;
      fgetc(fp);
      for(i=0;i<cases;i++)
      {
         for(m=0;m<4;m++)
         {
             for(n=0;n<4;n++)
                 board[i][m][n] = fgetc(fp);
             fgetc(fp);
         }
         fgetc(fp);   
      }
      fclose(fp);
      return cases;
 }
 
 int checker(char board[4][4])
 {
     char temp;
     int i,j, counter;
 
     for(i=0;i<4;i++)
     {
         temp=board[i][0];
         j=1;
 
         if(temp=='X')
         {
             while((board[i][j]=='X'||board[i][j]=='T')&&j<4)
             {
                 j++;
             }
             if(j==4)
             {
                 return 1;
             }
         }
         else if(temp=='O')
         {
             while((board[i][j]=='O'||board[i][j]=='T')&&j<4)
             {
                 j++;
             }
             if(j==4)
             {
                 return 2;
             }
         }
         else if(temp=='T')
         {
             temp=board[i][1];
             j=2;
 
             if(temp=='X')
             {
                 while((board[i][j]=='X'&&j<4))
                 {
                     j++;
                 }
                 if(j==4)
                 {
                     return 1;
                 }
             }
             else if(temp=='O')
             {
                 while((board[i][j]=='O'&&j<4))
                 {
                     j++;
                 }
                 if(j==4)
                 {
                     return 2;
                 }
             }
         }
     }
 
     for(j=0;j<4;j++)
     {
         temp=board[0][j];
         i=1;
 
         if(temp=='X')
         {
             while((board[i][j]=='X'||board[i][j]=='T')&&i<4)
             {
                 i++;
             }
             if(i==4)
             {
                 return 1;
             }
         }
         else if(temp=='O')
         {
             while((board[i][j]=='O'||board[i][j]=='T')&&i<4)
             {
                 i++;
             }
             if(i==4)
             {
                 return 2;
             }
         }
         else if(temp=='T')
         {
             temp=board[1][j];
             i=2;
 
             if(temp=='X')
             {
                 while((board[i][j]=='X'&&i<4))
                 {
                     i++;
                 }
                 if(i==4)
                 {
                     return 1;
                 }
             }
             else if(temp=='O')
             {
                 while((board[i][j]=='O'&&i<4))
                 {
                     i++;
                 }
                 if(i==4)
                 {
                     return 2;
                 }
             }
         }
     }
 
     counter=0;
     for(i=0;i<4;i++)
     {
         if(board[i][i]=='X')
             counter++;
         else if(board[i][i]=='O')
             counter--;
         else if(board[i][i]=='.')
         {
             counter=0;
             break;
         }
     }
     if(counter>2)
         return 1;
     else if(counter<-2)
         return 2;
 
     counter=0;
     for(i=0;i<4;i++)
     {
         if(board[i][3-i]=='X')
             counter++;
         else if(board[i][3-i]=='O')
             counter--;
         else if(board[i][3-i]=='.')
         {
             counter=0;
             break;
         }
     }
     if(counter>2)
         return 1;
     else if(counter<-2)
         return 2;
 
     for(i=0;i<4;i++)
         for(j=0;j<4;j++)
             if(board[i][j]=='.')
                 return 3;
     return 0;
 
 }
 	
 void printBoard (int numberOfCases, char board[1000][4][4])
 {
 	int i, j, k;
 	
 	for (k=0; k<numberOfCases; k++)
 	{
 		for (i=0; i<4; i++)
 		{
 			for (j=0; j<4; j++)
 				printf ("%c", board[k][i][j]);
 			printf ("\n");
 		}
 		printf ("\n");
 	}
 }

