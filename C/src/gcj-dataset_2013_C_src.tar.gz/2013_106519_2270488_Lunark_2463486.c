#include<stdio.h>
 #include<math.h>
 int main()
 {
     freopen("input.txt","r",stdin);
     freopen("output.txt","w",stdout);
 
     int i,j,k,A,B,n,ans[10000]={};
     int reverse = 0, temp,p;
 
     scanf("%d",&n);
     for(i=0;i<n;i++)
     {
         scanf("%d %d",&A,&B);
         for(j=A;j<=B;j++)
         {
             k = sqrt(j);
             if(k*k!=j) continue;
 
             temp = k;
             reverse = 0;
             while( temp != 0 ) {
                 reverse = reverse * 10;
                 reverse = reverse + temp%10;
                 temp = temp / 10;
             }
             if ( k != reverse ) continue;
 
             temp = j;
             reverse = 0;
             while( temp != 0 ) {
                 reverse = reverse * 10;
                 reverse = reverse + temp%10;
                 temp = temp / 10;
             }
             if ( j != reverse ) continue;
 
             ans[i]++;
 
         }
 
     }
 
     for(i=0;i<n;i++)
     {
         printf("Case #%d: %d\n",i+1,ans[i]);
     }
 
     return 0;
 }

