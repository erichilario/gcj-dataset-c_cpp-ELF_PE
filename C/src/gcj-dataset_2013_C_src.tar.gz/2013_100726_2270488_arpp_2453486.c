#include<stdio.h>
 
 void main()
 {
     int t,i,j,k,flagDraw,flagWin;
     int a[10];
     char arr[4][4],ch;
 
     scanf("%d",&t);
 
     for(i=1;i<=t;i++)
     {
         scanf("%c",&ch);
         flagDraw=1;
         flagWin=1;
         for(j=0;j<4;j++)
         {
             for(k=0;k<4;k++)
             {
                 scanf("%c",&ch);
                 if(ch=='.')
                 {
                     flagDraw=0;
                     arr[j][k]=0;
                 }
                 else if(ch=='X')
                 {
                     arr[j][k]=1;
                 }
                 else if(ch=='T')
                 {
                     arr[j][k]=5;
                 }
                 else
                 {
                     arr[j][k]=10;
                 }
             }
             scanf("%c",&ch);
         }
         a[0]=arr[0][0]+arr[0][1]+arr[0][2]+arr[0][3];
         a[1]=arr[1][0]+arr[1][1]+arr[1][2]+arr[1][3];
         a[2]=arr[2][0]+arr[2][1]+arr[2][2]+arr[2][3];
         a[3]=arr[3][0]+arr[3][1]+arr[3][2]+arr[3][3];
 
         a[4]=arr[0][0]+arr[1][0]+arr[2][0]+arr[3][0];
         a[5]=arr[0][1]+arr[1][1]+arr[2][1]+arr[3][1];
         a[6]=arr[0][2]+arr[1][2]+arr[2][2]+arr[3][2];
         a[7]=arr[0][3]+arr[1][3]+arr[2][3]+arr[3][3];
 
         a[8]=arr[0][0]+arr[1][1]+arr[2][2]+arr[3][3];
         a[9]=arr[0][3]+arr[1][2]+arr[2][1]+arr[3][0];
 
         for(j=0;j<10;j++)
         {
             if(a[j]==35||a[j]==40)
             {
                 printf("Case #%d: O won\n",i);
                 flagWin=0;
                 break;
             }
             else if(a[j]==4||a[j]==8)
             {
                 printf("Case #%d: X won\n",i);
                 flagWin=0;
                 break;
             }
         }
         if(flagWin==1)
         {
             if(flagDraw==1)
             {
                 printf("Case #%d: Draw\n",i);
             }
             else
             {
                 printf("Case #%d: Game has not completed\n",i);
             }
         }
     }
 }

