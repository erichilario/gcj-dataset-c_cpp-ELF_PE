# include <stdio.h>
 # include <stdlib.h>
 # include <math.h>
 
 int ispalin(char* str){
     int i,j;
     char rev[30];
     for(i=0; str[i]!='\0'; i++)
     	rev[i] = str[i];
     
     i--;
     
     for(j=0;i>=0;j++,i--){
     	if(rev[j]!=str[i]){
     	   return 0;
     	}
     }
     return 1;
 }
 
 /*float sqrtfn (int k ) {
 	float a, b, e=0.00001,p  ;
 	a=k;p=a*a;
   	while(p-k>=e)
    	{
    		b=(a+(k/a))/2;
    	 	a=b;
    	 	p=a*a;
    }
    
    return a ;
 }
 */
 
 int isperfect (int num) {
 	double m ;
 	int p ;
 	m=sqrt(num) ;
 	p=m; 
 	if (m==p)
 		return 1 ;
 	else
 		return 0 ;
 }
 
 int main () {
 	int casen[100], t, count=0 ;
 	char number[20], sqnumber[20] ;
 	double sqdnum ;
 	int a, b, i, j  ;
 	
 	scanf ("%d", &t) ;
 	
 	for (i=0; i<t; ++i) {
 		fflush(stdin) ;
 		scanf("%d %d", &a, &b) ;
 		
 		for (j=a; j<=b; j++) {
 			if (isperfect(j)) {
 				sqdnum = sqrt(j) ;
 				sprintf(number, "%d", j) ;
 				sprintf(sqnumber, "%d", (int)sqdnum) ;
 				if (ispalin(number) && ispalin(sqnumber)) {
 					count++ ;
 				}
 			}
 		}
 		
 		casen[i] = count ;
 		count = 0 ;
 		fflush(stdin) ;
 	}
 	
 	for (i=0; i<t; ++i) {
 		printf ("Case #%d: %d\n", i+1, casen[i]) ;
 	}
 	
 	
 	return 0 ;
 }

