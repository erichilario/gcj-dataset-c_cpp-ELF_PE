#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 
 int main()
 {
 	FILE *ifp, *ofp;
 
 	int i,j,z,t,x,o,d,nc,br;
 	char e;
 
 	ifp = fopen("input.txt", "r");
 	ofp = fopen("output.txt", "w");
 
 	fscanf(ifp,"%d",&t);
 
 	for(z=0;z<t;z++)
 	{
 		char **b = malloc(4*sizeof(char *));
 		for(i=0;i<4;i++)	b[i] = malloc(4*sizeof(char));
 
 		x=0;o=0;d=0;nc=0;br=0;
 
 		if(z<t)	fscanf(ifp,"%c",&e);
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				fscanf(ifp,"%c",&b[i][j]);
 			}
 			fscanf(ifp,"%c",&e);
 		}
 
 		/*for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				printf("%c ", b[i][j]);
 			}
 			printf("\n");
 		}*/
 
 		for(i=0;i<4;i++)
 		{
 			if((b[i][0]=='X'||b[i][0]=='T') && (b[i][1]=='X'||b[i][1]=='T') && (b[i][2]=='X'||b[i][2]=='T') && (b[i][3]=='X'||b[i][3]=='T'))
 			{
 				x=1;
 				break;
 			}
 		}
 
 		if(x==0 && o==0 && d==0 && nc==0)
 		{
 			for(j=0;j<4;j++)
 			{
 				if((b[0][j]=='X'||b[0][j]=='T') && (b[1][j]=='X'||b[1][j]=='T') && (b[2][j]=='X'||b[2][j]=='T') && (b[3][j]=='X'||b[3][j]=='T'))
 				{
 					x=1;
 					break;
 				}
 			}
 		}
 
 		if(x==0 && o==0 && d==0 && nc==0)
 		{
 			if((b[0][0]=='X'||b[0][0]=='T') && (b[1][1]=='X'||b[1][1]=='T') && (b[2][2]=='X'||b[2][2]=='T') && (b[3][3]=='X'||b[3][3]=='T'))
 			{
 				x=1;
 			}
 		}
 		
 		if(x==0 && o==0 && d==0 && nc==0)
 		{			
 			if((b[0][3]=='X'||b[0][3]=='T') && (b[1][2]=='X'||b[1][2]=='T') && (b[2][1]=='X'||b[2][1]=='T') && (b[3][0]=='X'||b[3][0]=='T'))
 			{
 				x=1;
 			}
 		}
 
 
 
 		if(x==0 && o==0 && d==0 && nc==0)
 		{
 			for(i=0;i<4;i++)
 			{
 				if((b[i][0]=='O'||b[i][0]=='T') && (b[i][1]=='O'||b[i][1]=='T') && (b[i][2]=='O'||b[i][2]=='T') && (b[i][3]=='O'||b[i][3]=='T'))
 				{
 					o=1;
 					break;
 				}
 			}
 		}
 
 		if(x==0 && o==0 && d==0 && nc==0)
 		{
 			for(j=0;j<4;j++)
 			{
 				if((b[0][j]=='O'||b[0][j]=='T') && (b[1][j]=='O'||b[1][j]=='T') && (b[2][j]=='O'||b[2][j]=='T') && (b[3][j]=='O'||b[3][j]=='T'))
 				{
 					o=1;
 					break;
 				}
 			}
 		}
 
 		if(x==0 && o==0 && d==0 && nc==0)
 		{
 			if((b[0][0]=='O'||b[0][0]=='T') && (b[1][1]=='O'||b[1][1]=='T') && (b[2][2]=='O'||b[2][2]=='T') && (b[3][3]=='O'||b[3][3]=='T'))
 			{
 				o=1;
 			}
 		}
 		
 		if(x==0 && o==0 && d==0 && nc==0)
 		{			
 			if((b[0][3]=='O'||b[0][3]=='T') && (b[1][2]=='O'||b[1][2]=='T') && (b[2][1]=='O'||b[2][1]=='T') && (b[3][0]=='O'||b[3][0]=='T'))
 			{
 				o=1;
 			}
 		}
 
 
 
 		if(x==0 && o==0 && d==0 && nc==0)
 		{
 			for(i=0;i<4;i++)
 			{
 				for(j=0;j<4;j++)
 				{
 					if(b[i][j]=='.')
 					{
 						nc=1;
 						br=1;
 						break;
 					}
 				}
 				if(br==1)	break;
 			}
 		}
 
 		if(x==0 && o==0 && d==0 && nc==0)	d=1;
 
 		if(x==1)	fprintf(ofp,"Case #%d: X won\n",z+1);
 		else if(o==1)	fprintf(ofp,"Case #%d: O won\n",z+1);
 		else if(d==1)	fprintf(ofp,"Case #%d: Draw\n",z+1);
 		else if(nc==1)	fprintf(ofp,"Case #%d: Game has not completed\n",z+1);
 	
 		for(i=0;i<4;i++) free(b[i]);
 		free(b);
 	}
 
 	fclose(ifp);
 	fclose(ofp);
 	return 0;
 }

