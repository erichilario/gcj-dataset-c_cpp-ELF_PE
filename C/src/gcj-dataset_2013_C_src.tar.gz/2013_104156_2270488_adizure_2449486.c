#include<stdio.h>
 int main()
 {
 	int i, j, n, m, t, k, max;
 	scanf("%d", &t);
 	for(k=0;k<t;k++)
 	{
 		int a[100][100], b[100][100];
 		scanf("%d %d", &n, &m);
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				a[i][j]=100;
 				scanf("%d", &b[i][j]);
 			}
 		}
 
 		for(j=0;j<m;j++)
 		{
 			max=-9999;
 			for(i=0;i<n;i++)
 			{
 				if(b[i][j] > max)
 				{
 					max=b[i][j];
 				}
 			}
 			for(i=0;i<n;i++)
 			{
 				a[i][j]=max;
 			}
 		}
 
 		for(i=0;i<n;i++)
 		{
 			max=-9999;
 			for(j=0;j<m;j++)
 			{
 				if(b[i][j] > max)
 				{
 					max=b[i][j];
 				}
 			}
 			for(j=0;j<m;j++)
 			{
 				if(a[i][j] > max)
 				{
 					a[i][j]=max;
 				}
 			}
 		}
 
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				if(a[i][j] != b[i][j])
 				{
 					break;
 				}
 			}
 			if(j != m)
 			{
 				break;
 			}
 		}
 
 		if(i != n)
 		{
 			printf("Case #%d: NO\n", k+1);
 		}
 		else 
 		{
 			printf("Case #%d: YES\n", k+1);
 		}
 	}
 	return 0;
 }

