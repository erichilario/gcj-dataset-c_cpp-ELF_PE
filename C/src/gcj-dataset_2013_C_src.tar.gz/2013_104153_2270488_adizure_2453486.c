#include<stdio.h>
 int main()
 {
 	char a[5][5], c;
 	int i, j, t, k, f=0, count, x1;
 	scanf("%d", &t);
 	int flag=0, fl=0;
 	for(k=0;k<t;k++)
 	{
 	/*	flag=-1;
 		fl=0;
 		f=0;
 		x1=0;  */
 		x1=0;
 		scanf("%c", &c);
 		for(i=0;i<4;i++)
 
 		{
 
 			//		scanf("%c", &c);
 			//		printf("%c", c);
 			for(j=0;j<4;j++)
 			{
 				scanf("%c", &a[i][j]);
 				//		printf("%c", a[i][j]);
 			}
 			scanf("%c", &c);
 			//	printf("%c", c);
 		}
 /*		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				printf("%c", a[i][j]);
 			}
 			printf("\n");
 		} */
 		flag=-1;
 		count=0;
 		fl=0;
 		f=0;
 		for(i=0;i<4;i++)
 		{
 			if(a[i][i]=='.')
 			{
 				x1++;
 				fl=1;
 				break;
 			}
 			if(a[i][i]=='T')
 			{
 				continue;
 			}
 			if(a[i][i]=='X')
 			{
 				if(flag!=1)
 				{
 					flag=1;
 					count++;
 				}
 			}
 
 			if(a[i][i]=='O')
 			{
 				if(flag!=0)
 				{
 					flag=0;
 					count++;
 				}
 			}
 		}	
 		if(fl==0 && count==1)
 		{
 			f=1;
 			printf("Case #%d: ", k+1);
 			if(flag==1)
 				printf("X won\n");
 			else
 				printf("O won\n");
 
 			continue;
 		}
 
 		f=0;
 
 		flag=-1;
 		count=0;
 		fl=0;
 		for(i=0;i<4;i++)
 		{
 			if(a[i][3-i]=='.')
 			{
 				x1++;
 				fl=1;
 				break;
 			}
 			if(a[i][3-i]=='T')
 			{
 				continue;
 			}
 			if(a[i][3-i]=='X')
 			{
 				if(flag!=1)
 				{
 					flag=1;
 					count++;
 				}
 			}
 
 			if(a[i][3-i]=='O')
 			{
 				if(flag!=0)
 				{
 					flag=0;
 					count++;
 				}
 			}
 		}	
 
 		if(fl==0 && count==1)
 		{
 				f=1;
 			printf("Case #%d: ", k+1);
 			if(flag==1)
 				printf("X won\n");
 			else
 				printf("O won\n");
 		
 			continue;
 		}
 
 
 		for(i=0;i<4;i++)
 		{
 	//		printf("%d asdadsdasasdad", k);
 			flag=-1;
 			//		flags=0;
 			count=0;
 			fl=0;
 			for(j=0;j<4;j++)
 			{
 				if(a[i][j]=='.')
 				{
 					x1++;
 					fl=1;
 					break;
 				}
 				if(a[i][j]=='T')
 				{
 					continue;
 				}
 				if(a[i][j]=='X')
 				{
 					if(flag!=1)
 					{
 						flag=1;
 						count++;
 					}
 				}
 
 				if(a[i][j]=='O')
 				{
 					if(flag!=0)
 					{
 						flag=0;
 						count++;
 					}
 				}
 			}
 			if(fl==0 && count==1)
 			{
 				f=1;
 				printf("Case #%d: ", k+1);
 				if(flag==1)
 					printf("X won\n");
 				else
 					printf("O won\n");
 
 				break;
 			}
 		}
 		if(f==1)
 		{
 			continue;
 		}
 		f=0;
 		for(j=0;j<4;j++)
 		{
 			flag=-1;
 			count=0;
 			fl=0;
 			for(i=0;i<4;i++)
 			{
 				if(a[i][j]=='.')
 				{
 					x1++;
 					fl=1;
 					break;
 				}
 				if(a[i][j]=='T')
 				{
 					continue;
 				}
 				if(a[i][j]=='X')
 				{
 					if(flag!=1)
 					{
 						flag=1;
 						count++;
 					}
 				}
 
 				if(a[i][j]=='O')
 				{
 					if(flag!=0)
 					{
 						flag=0;
 						count++;
 					}
 				}
 			}
 			if(fl==0 && count==1)
 			{
 				f=1;
 				printf("Case #%d: ", k+1);
 				if(flag==1)
 					printf("X won\n");
 				else
 					printf("O won\n");
 
 				break;
 			}
 		}
 		if(f==1)
 		{
 			continue;
 		}
 
 
 
 		if(f==0 && x1==0)
 			printf("Case #%d: Draw\n", k+1);
 		else
 			printf("Case #%d: Game has not completed\n", k+1);
 	}
 	return 0;
 }

