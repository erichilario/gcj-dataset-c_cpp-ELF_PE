#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define MAX_BUFFER_SIZE 1024*1024
 
 #define MAX_ROWS_COLS 128*128
 char map[MAX_ROWS_COLS] = {0};
 
 int check_uniformity_rows(int row, int cols) {
 	int ctr = 0;
 	unsigned int check = 0;
 	unsigned int check_last = 0;
 	int *map_curr = (int*)&map[row*cols];
 	char tmp = map[row*cols];
 	int dg = cols % 8;
 	int num = 0;
 
 	if(tmp != map[(row*cols) + (cols - 1)]) {
 		return 0;
 	}
 
 	for(;ctr < dg; ctr++)
 		check_last |= (tmp << (ctr*8));
 
 	if(cols >= 8) {
 		check = tmp | (tmp << 8) | (tmp << 16) | (tmp << 24) | (tmp << 32) | (tmp << 40) | (tmp << 48) | (tmp << 56);
 	} else {
 		check = check_last;
 	}
 
 	num = (dg == 0) ? (cols/8) : ((cols - dg) / dg);
 		
 	for(ctr = 0; ctr < num; ctr++)
 		if(map_curr[ctr] != check) {
 			return 0;
 		}
 
 	if(dg) {
 		if((map_curr[ctr] & check_last) != check_last) {
 			return 0;
 		}
 	}
 
 	return 1;
 }
 
 int check_uniformity_cols(int rows, int cols, int col) {
 	int i = 0;
 	char value = map[col];
 	char* slow_ptr = &map[col];
 	char* fast_ptr = &map[col];
 
 	for(; i < (rows/2); i++) {
 		if((*slow_ptr != value) || (*fast_ptr != value)) {
 			return 0;
 		}
 
 		slow_ptr += cols;
 		fast_ptr += (2*cols);
 	}
 
 	return 1;
 }
 
 int check_uniformity(int rows, int cols) {
 	int i = 0;
 
 	if(check_uniformity_rows(0, cols) == 1) {
 		for(i = 1; i < rows; i++) {
 			if(check_uniformity_rows(i, cols) != 1) {
 				return 0;
 			}
 		}
 	} else {
 		for(i = 0; i < cols; i++) {
 //			printf("Checking column: map[0] => %d map[%d] => %d\n", map[0], i, map[i]);
 			if(map[0] != map[i])
 				if(check_uniformity_cols(rows, cols, i) != 1) {
 					return 0;
 				}
 		}
 	}
 
 	return 1;
 }
 
 int convert(char* buffer, int rows, int cols) {
 	int ret = 0;
 	int len = 0;
 	int loc = 0;
 	int i = 0;
 	int ctr = 0;
 	char tmp[1024] = { '\0' };
 
 	memset(map, 0, MAX_ROWS_COLS);
 	for(i = 0; i < (rows*cols); i++) {
 		ret = sscanf(&buffer[loc], "%d%n", (int *)&map[ctr], &len);
 		loc += len;
 		ctr++;
 	}
 
 	return loc;
 }
 
 void main(int argc, char** argv) {
 	int entries = 0;
 	int ctr = 0;
 	int ret = 0;
 	int loc = 0;
 	int rows = 0;
 	int cols = 0;
 	int len = 0;
 	unsigned int number = 0;
 	FILE* fp = NULL;
 	char* buff = NULL;
 	char buffer[MAX_BUFFER_SIZE] = { 0 };
 
 	if(argc < 2) {
 		printf("Insufficient arguments\n");
 		return;
 	}
 
 	fp = fopen(argv[1], "r");
 	if(fp == NULL) {
 		printf("Unable to open input file\n");
 		return;
 	}
 
 	fscanf(fp, "%d\n", &entries);
 
 	fread(buffer, MAX_BUFFER_SIZE, 1, fp);
 
 	while(ctr < entries) {
 		ret = sscanf(&buffer[loc], "%d %d\n%n", &rows, &cols, &len);
 		loc += len;
 
 		buff = &buffer[loc];
 		len = convert(buff, rows, cols);
 
 		ret = check_uniformity(rows, cols);
 
 		loc += len;
 		printf("Case #%d: %s\n", (ctr + 1), (ret == 1) ? "YES" : "NO");
 		ctr++;
 	}
 }

