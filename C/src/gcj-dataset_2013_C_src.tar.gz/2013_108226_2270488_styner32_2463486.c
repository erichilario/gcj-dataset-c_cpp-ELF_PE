#include<stdio.h>
 #include<stdint.h>
 #include<limits.h>
 
 unsigned long long int sqrts[100];
 int number_of_sqrts = 0;
 
 int main(void)
 {
   int case_cnt;
   int k;
   unsigned long long int i, start, end;
   int start_index, end_index;
   int count;
 
   set_sqrts();
   scanf("%d", &case_cnt);
   for(k = 0; k < case_cnt; k++) {
     scanf("%lld", &start);
     scanf("%lld", &end);
     count = 0;
 
     for(i = 0; i < number_of_sqrts; ++i) {
       if(sqrts[i] >= start) {
         start_index = i;
         break;
       } 
     }
 
     for(i = sqrts[start_index]; i <= end && start_index < number_of_sqrts ; start_index++, i = sqrts[start_index]) {
       count++;
     }
 
     printf("Case #%d: %d\n", k+1, count);
   }
   return 0;
 }
 
 int set_sqrts() {
   unsigned long long int value = 1;
   unsigned long long int max = 100000000000000;
   unsigned long long int i = 1;
   int index = 0;
   int length = 0;
 
   while(value <= max) {    
     if(check_paindrom(i)) {
       value = i*i;
       if(check_paindrom(value)) {
         sqrts[length] = value;
         length++;
       }
     }
     i++;
   }
 
   number_of_sqrts = length;
 }
 
 int check_paindrom(long long int number) {
   int str[101];
   int length = 0;
   int i = 0;
   int half = 0;
 
   if(number < 10)
     return 1;
 
   while(number > 0) {
     str[length] = number % 10;
     number /= 10;
     length++;
   }
 
   half = length/2;
 
   for(i = 0; i < half ; ++i) {
     if(str[i] != str[length-1]) {
       return 0;
     }
   }
 
   return 1;
 }
 

