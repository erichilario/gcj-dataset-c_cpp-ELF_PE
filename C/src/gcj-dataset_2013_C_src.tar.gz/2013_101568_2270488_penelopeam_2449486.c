#include<stdio.h>
 #include<stdlib.h>
 
 int max(int a, int b){
     if(a > b) return a;
     return b;
 }
 int min(int a, int b){
     if(a < b) return a;
     return b;
 }
 int main(int argc, char* argv[])
 {
     int t, m, n, ans;
     int land[100][100], l[100], c[100];
     int k=1, i, j;
     scanf("%d", &t);
     while(k<=t){
         ans=1;
         scanf(" %d %d", &m, &n);
         for(i=0; i<100; i++){
             l[i]=0;
             c[i]=0;
         }
 
         for(i=0; i<m;i++)
             for(j=0; j<n; j++){
                 scanf(" %d", &land[i][j]);
                 l[i]=max(l[i], land[i][j]);
                 c[j]= max(c[j], land[i][j]);
             }
 
         for(i=0; i<m;i++)
             for(j=0; j<n; j++){
                 if(min(l[i], c[j]) != land[i][j] )
                     ans=0;
             }
         if(ans)
             printf("Case #%d: YES\n", k);
         else
             printf("Case #%d: NO\n", k);
         k++;
     }
 
     return 0;
 }

