#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define S 4
 
 
 /* char* func(int *t){ */
   
 /*   return 'c' ; */
 
 /* } */
 
 int is_digit(char c){
   if((c >= 48 && c<= 57)){
     return 1 ;
   }
   return 0 ;
 }
 
 
 int max(int a, int b){
 
   if(a > b){
     return a ;
   }
   return b ;
 }
 
 void func(FILE* out, int cas, int N, int M, int * t){
 
 
   int * linemax = malloc(sizeof(int)*M);
   int * colmax = malloc(sizeof(int)*N);
   
   int res = 1 ;
   int i ;
   int j ;
   for(i=0 ; i<M ; i++)
     linemax[i] = 0 ;
   for(i=0 ; i<N ; i++)
     colmax[i] = 0 ;
 
  
   for(i=0 ; i<M ; i++){
     for(j=0 ; j<N ; j++){
       linemax[i] = max(linemax[i], t[i*N+j]);
       colmax[j] = max(colmax[j], t[i*N+j]);
     }
   }
 
   for(i=0 ; i<M ; i++){
     for(j=0 ; j<N ; j++){
       printf("(%d %d)", linemax[i], colmax[j]);
       if(t[i*N+j] < linemax[i] && t[i*N+j] < colmax[j]){
 	res = 0 ;
       }
     }
        printf("\n");
   }
   
   if(res == 0){
     fprintf(out,"Case #%d: NO\n", cas);
   }
   else{
     fprintf(out,"Case #%d: YES\n", cas);
   }
  
 
 }
 
 int main(void){
 
  
  
   FILE* out = fopen("outputqualifB.txt", "w+") ;
   FILE * in = fopen("B-small-attempt2-1.in", "r+" );
   int T ;
  
   int i = 0;
   int j = 0;
   
 
   fscanf(in, "%d", &T);
   int d = printf("T=  %d \n", T);
   
   
   int N ;
   int M ;
   int tmp = 0 ;
   int c ;
   int * t = malloc(sizeof(int)*100*100);
   for(d=0 ; d < T ; d++){
     fscanf(in, "%d %d", &N, &M);
     printf("N = %d, M = %d \n", N, M);
     //  t = (int*) malloc(sizeof(int)*M*N);
     c = fgetc(in);
     
     i = 0 ;
     j = 0 ;
     while(i<N){
       j = 0 ;
       tmp = 0;
        c = fgetc(in);
       while(c != '\n'){
 	//	printf("(%c) %d %d\n", c, i ,j);
 	if(c == 32){
 	  t[i*N+j] = tmp ;
 	  //	  printf("tmp push = %d\n", tmp);
 	  tmp = 0 ;
 	  j++ ;
 	  
 	  /* printf("fin if"); */
 	}
 	else{
 	  if(c>= 48 && c < 58)
 	    tmp = tmp*10 + c-48 ;
 	  //	  printf("tmp = %d", tmp);
 	}
 
 	c = fgetc(in);
       }
       t[i*N+j] = tmp ;
      
       i++ ;
     /* } */
     /*   printf("tableau finale : (%c) \n", c); */
     /* for(i=0 ; i< N ; i++){ */
     /*   for(j=0 ; j < M ; j++){ */
     /* 	printf("%d ", t[i*N+j]); */
     /*   } */
     /*   printf("\n"); */
     /* } */
     
     //printf("%s \n", func(t));
     // fprintf(out, "Case #%d: %s\n", d+1, func(t));
     }
       func(out, d+1, N, M,t);
       
     //free(t);
     
   }
 
   
 
 
   /* for(i=0 ; i< N ; i++){ */
  
 
   /*   fscanf(in,"%s %s %s",n,s,d); */
  
   /* } */
   
   /* fprintf(fichier, "Case #%d: %s\n", cas, resf); */
   fclose(out);
   fclose(in);
 
   return 0 ;
 
 }

