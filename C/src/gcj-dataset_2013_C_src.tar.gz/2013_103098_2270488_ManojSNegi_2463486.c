#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 #define FALSE 0
 #define TRUE  1
 
 void process(int caseNumber);
 
 typedef int bool;
 
 int main(void)
 {
 	int T = 0, i = 0;
 
 	scanf("%d", &T);
 
 	for (i = 0; i < T; ++i)
 	{
 		process(i + 1);
 	}
 
 	return 1;
 }
 
 bool palindrome(long long number)
 {
 	char str[1001] = {'\0'};
 	int i = 0, j = 0;
 
 	while(number)
 	{
 		str[i] = (number % 10) + '0';
 		number /= 10;
 		i += 1;
 	}
 
 	i = 0; j = strlen(str) - 1;
 
 	for(; (i < j) && (str[i] == str[j]); ++i, --j);
 
 	return (i < j) ? FALSE:TRUE;
 }
 
 void process(int caseNumber)
 {
 	long long a = 0, b = 0, start = 0, end = 0, sqr = 0;
 	int i,j, count = 0;
 
 
 	scanf("%Ld %Ld", &a, &b);
 
 	start = sqrt(a);
 	end = sqrt(b);
 
 	while (start <= end)
 	{
 		sqr = start * start;
 		if ((sqr >= a) && (sqr <= b) && (palindrome(start) == TRUE) && (palindrome(sqr) == TRUE))
 		{
 			count += 1;
 		}
 
 		start += 1;
 	}
 
 	printf("Case #%d: %d\n", caseNumber, count);
 	return;
 }

