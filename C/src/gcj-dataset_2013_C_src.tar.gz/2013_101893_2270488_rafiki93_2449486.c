#include<stdio.h>
 int a[100][100];
 int posr,posc;
 int main()
 {
     int times,flag1=0,flag2=0,i,j,m,n,k=0;
     FILE *fp,*fp1;
     fp=fopen("B-small-attempt0.in","r");
     fp1=fopen("B-small-attempt0.out","w");
     fscanf(fp,"%d",&times);
     while(times--)
     {
         k++;
         fscanf(fp,"%d %d",&n,&m);
         for(i=0;i<n;i++)
         for(j=0;j<m;j++)
         {
             fscanf(fp,"%d",&a[i][j]);
         }
 
         out:
         flag1=flag2=0;
         min_matrix(n,m);
         /*
         if(k==93)
         {
             fprintf(fp1,"debug minr:%d minc:%d \n",a[posr][posc]);
         }
         */
         if(a[posr][posc]==0){ fprintf(fp1,"Case #%d: YES\n",k); continue; }
         for(i=0;i<n;i++)
         {
             if(a[i][posc]>a[posr][posc])    flag1=1;
         }
 
         for(i=0;i<m;i++)
         {
             if(a[posr][i]>a[posr][posc])    flag2=1;
         }
           /*      if(k==93)
         {
             fprintf(fp1,"debug :  flag1=%d flag2=%d\n",flag1,flag2);
         }*/
         if(flag1==1 && flag2==1){fprintf(fp1,"Case #%d: NO\n",k); continue; }
         if(flag1==0)
         {
             for(i=0;i<n;i++)
             a[i][posc]=0;
         }
           if(flag2==0)
         {
             for(i=0;i<m;i++)
             a[posr][i]=0;
         }
             goto out;
     }
 
     fclose(fp);
     fclose(fp1);
 
     return 0;
 }
 int min_matrix(int n,int m)
 {
     int min,i,j;
     min=100;
 for(i=0;i<n;i++)
 for(j=0;j<m;j++)
 {
     if(a[i][j]<min && a[i][j]!=0)
     {
         min=a[i][j]; posr=i; posc=j;
     }
 }
 }

