# include<stdio.h>
 # include<stdlib.h>
 
 int main()
 {
 FILE* fp1=fopen("/home/ajit/Downloads/aa.in","r+");
 FILE* fp2=fopen("/home/ajit/Downloads/ans.txt","w+");
 int i,j,k,l,no_of_cases,pp;
 fscanf (fp1,"%d", &no_of_cases);
 printf("no of cases=%d",no_of_cases);
 
 for(pp=0;pp<no_of_cases;pp++)
 {
 char ln[5][5];
 char junk[4];
 int dot=0,o_res=0,x_res=0;
 int no,o_no=0,x_no=0;
 
 for(i=0;i<4;i++)
 {
 
    //fgets(ln[i],4,fp1);
    fscanf(fp1,"%s",ln[i]);
   printf("%s\n",ln[i]);
 }
 //fscanf(fp1,"%s",junk);
 //printf("aj:%s:",junk)
 fgets(junk,2,fp1);
 printf("??%s??",junk);
 for(i=0;i<4;i++)
 {
    for(j=0;j<4;j++)
    {
      if(ln[i][j]=='.')
      {
        dot++;
      }
      if(ln[i][j]=='T')
      {
        o_no++;
        x_no++;
      }
      if(ln[i][j]=='X')
      {
        x_no++;
      }
      if(ln[i][j]=='O')
      {
        o_no++;
      }
    }
    if(o_no==4)
    {
   fprintf(fp2,"Case #%d: O won\n",pp+1);
    o_res=1;
    break;
    }
    else if(x_no==4)
    {
    fprintf(fp2,"Case #%d: X won\n",pp+1);
    x_res=1;
    break;
    }
    else;
   o_no=0;
   x_no=0;
 }
 
 if((x_res==1)||(o_res==1))
 continue;
 x_res=0;o_res=0;
 for(i=0;i<4;i++)
 {
    for(j=0;j<4;j++)
    {
 
      if(ln[j][i]=='T')
      {
        o_no++;
        x_no++;
      }
      if(ln[j][i]=='X')
      {
        x_no++;
      }
      if(ln[j][i]=='O')
      {
        o_no++;
      }
    }
    if(o_no==4)
    {
    fprintf(fp2,"Case #%d: O won\n",pp+1);
    o_res=1;
    break;
    }
    else if(x_no==4)
    {
    fprintf(fp2,"Case #%d: X won\n",pp+1);
    x_res=1;
    break;
    }
   o_no=0;
   x_no=0;
 }
 
 if((x_res==1)||(o_res==1))
 continue;
 x_res=0;o_res=0;
 
 for(i=0;i<4;i++)
 {
  if(ln[i][i]=='T')
  {
  o_no++;
  x_no++;
  }
  else if(ln[i][i]=='X')
  x_no++;
  else if(ln[i][i]=='O')
  o_no++;
 
 }
 if(o_no==4)
 {
 fprintf(fp2,"Case #%d: O won\n",pp+1);
 continue;
 }
 else if(x_no==4)
 {
 fprintf(fp2,"Case #%d: X won\n",pp+1);
 continue;
 }
 else;
 o_no=0;
 x_no=0;
 j=0;
 for(i=3;i>=0;i--)
 {
 
  if(ln[i][j]=='T')
  {
  o_no++;
  x_no++;
  }
  else if(ln[i][j]=='X')
  x_no++;
  else if(ln[i][j]=='O')
   o_no++;
 
  j++;
 }
 if(o_no==4)
 {
 fprintf(fp2,"Case #%d: O won\n",pp+1);
 continue;
 }
 else if(x_no==4)
 {
 fprintf(fp2,"Case #%d: X won\n",pp+1);
 continue;
 }
 if(dot)
 fprintf(fp2,"Case #%d: Game has not completed\n",pp+1);
 else
 fprintf(fp2,"Case #%d: Draw\n",pp+1);
 
 
 }
 printf("\npp=%d",pp);
 fclose(fp1);
 fclose(fp2);
 
 return 0;
 
 }

