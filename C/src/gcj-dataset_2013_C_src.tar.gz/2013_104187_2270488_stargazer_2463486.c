#include<stdio.h>
 #include<stdlib.h>
 #include<gmp.h>
 #include<string.h>
 
 int main()
 {
 	int test_case, i, j;
 	mpz_t lower_limit, upper_limit, sum, sqrt, zero;
 	mpz_init(lower_limit);
 	mpz_init(upper_limit);
 	mpz_init(sum);
 	mpz_init(sqrt);
 	mpz_init(zero);
 	char temp;
 	char *a, *b, *forward, *backward;
 	scanf("%d",&test_case);
 	getchar();
 	for (i=1; i<=test_case; i++)
 	{
 		mpz_set(sum,zero);
 		a=calloc(350,sizeof(char)), b=calloc(350,sizeof(char));
 		forward=calloc(150,sizeof(char)), backward=calloc(150,sizeof(char));
 		scanf("%s",a);
 		getchar();
 		mpz_set_str(lower_limit, a, 10);
 		scanf("%s",b);
 		getchar();
 		mpz_set_str(upper_limit, b, 10);
 		while (mpz_cmp(upper_limit, lower_limit)+1)
 		{
 			if (mpz_perfect_square_p(lower_limit))
 			{
 				mpz_get_str(forward, 10, lower_limit);
 				backward=strrev(strdup(forward));
 				if (strcmp(forward, backward)==0)
 				{
 					mpz_sqrt(sqrt, lower_limit);
 					mpz_get_str(forward, 10, sqrt);
 					backward=strrev(strdup(forward));
 					if (strcmp(forward, backward)==0)	mpz_add_ui(sum, sum, 1);
 				}
 			}
 			mpz_add_ui(lower_limit, lower_limit, 1);
 		}
 		gmp_printf("Case #%d: %Zd\n",i,sum);
 		free(a);
 		free(b);
 		free(forward);
 		free(backward);
 	}
 	return 0;
 }

