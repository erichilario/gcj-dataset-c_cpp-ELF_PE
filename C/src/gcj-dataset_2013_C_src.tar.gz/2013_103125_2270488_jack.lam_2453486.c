#include <stdio.h>
 #define DEBUG 0
 
 int numwinners = 10;
 unsigned int winpat[10] = { 0xF000, 0x0F00, 0x00F0, 0x000F, 0x8888, 
   0x4444, 0x2222, 0x1111, 0x8421, 0x1248 };
 
 int checkwin(unsigned int pat)
 {
   int i;
   
   for ( i=0; i<numwinners; i++ ) {
     if ( DEBUG ) printf("checkwin: (%x & %x) == %x\n", winpat[i], pat, winpat[i]&pat);
     if ( (winpat[i] & pat) == winpat[i] ) return 1;
   }
 
   return 0;
 }
 
 int main(void)
 {
   int T;
   unsigned int xpat;
   unsigned int opat;
   int occupied;
   int t;
   char raw[10];
   int line;
   int cpos;
   
   scanf("%d", &T);
   
   for ( t=1; t<=T; t++ ) {
     xpat = 0;
     opat = 0;
     occupied = 0;
   
     for ( line=0; line<4; line++ ) {
       scanf("%s", raw);
       xpat <<= 4;
       opat <<= 4;
       for ( cpos=0; cpos<4; cpos++ ) {
         switch ( raw[cpos] ) {
            case 'X': xpat += 1 << (3-cpos); occupied++; break;
            case 'O': opat += 1 << (3-cpos); occupied++; break;
            case 'T': xpat += 1 << (3-cpos); opat += 1 << (3-cpos); occupied++; break;
            default : break;
         }
       }
     }
     
     /* debug */
     if ( DEBUG ) printf("Case #%d: %x %x\n", t, xpat, opat);
     
     
     /* compute winner */
     if ( checkwin(xpat) ) {
       printf("Case #%d: X won\n", t);
     } else if ( checkwin(opat) ) {
       printf("Case #%d: O won\n", t);
     } else if ( occupied == 16 ) {
       printf("Case #%d: Draw\n", t);
     } else {
       printf("Case #%d: Game has not completed\n", t);
     }
   }
 
   return 0;
 }

