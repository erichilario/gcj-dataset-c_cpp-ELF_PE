# include <stdio.h>
 void part(int);
 int main()
 {
     int t,turn=0;
     scanf("%d",&t);
     while(t--)
     {
         part(++turn);
 	if(t)
 	{
 	    getchar();
 	}
     }
     return 0;
 }
 void part(int turn)
 {
     char line[10];
     int i=0,j=0,vert[4],hor[4];
     int pvert[4],phor[4];
     int pdig[2],dig[2];
     int O_flag=0,X_flag=0,Dot_flag=0;
     for(i=0;i<4;i++)
     {
         vert[i]=0;
         hor[i]=0;
         pvert[i]=0;
         phor[i]=0;
     }
     for(i=0;i<2;i++)
     {
         dig[i]=0;
         pdig[i]=0;
     }
     for(i=0;i<4;i++)
     {
         scanf("%s",line);
         for(j=0;j<4;j++)
         {
             if(line[j]=='X')
             {
                 if(vert[j]==0 && pvert[j]==0 || pvert[j]==1)
                     pvert[j]=1;
                 else
                     vert[j]=1;
                 if(hor[i]==0 && phor[i]==0 || phor[i]==1)
                     phor[i]=1;
                 else
                     hor[i]=1;
                 if(i==j)
                 {
                     if(dig[0]==0 && pdig[0]==0 || pdig[0]==1)
                         pdig[0]=1;
                     else
                         dig[0]=1;
                 }
                 else if(i+j==3)
                 {
                     if(dig[1]==0 && pdig[1]==0 || pdig[1]==1)
                         pdig[1]=1;
                     else
                         dig[1]=1;
                 }
             }
             else if(line[j]=='O')
             {
                 if(vert[j]==0 && pvert[j]==0 || pvert[j]==2)
                     pvert[j]=2;
                 else
                     vert[j]=1;
                 if(hor[i]==0 && phor[i]==0 || phor[i]==2)
                     phor[i]=2;
                 else
                     hor[i]=1;
                 if(i==j)
                 {
                     if(dig[0]==0 && pdig[0]==0 || pdig[0]==2)
                         pdig[0]=2;
                     else
                         dig[0]=1;
                 }
                 else if(i+j==3)
                 {
                     if(dig[1]==0 && pdig[1]==0 || pdig[1]==2)
                         pdig[1]=2;
                     else
                         dig[1]=1;
                 }
             }
             else if(line[j]=='.')
             {
                 Dot_flag=1;
                 vert[j]=1;
                 hor[i]=1;
                 if(i==j)
                 {
                     dig[0]=1;
                 }
                 else if(i+j==3)
                 {
                     dig[1]=1;
                 }
             }
         }
     }
     for(i=0;i<4;i++)
     {
         if(vert[i]==0)
         {
             if(pvert[i]==1)
             {
                 X_flag=1;
             }
             else if(pvert[i]==2)
             {
                 O_flag=1;
             }
         }
         if(hor[i]==0)
         {
             if(phor[i]==1)
             {
                 X_flag=1;
             }
             else if(phor[i]==2)
             {
                 O_flag=1;
             }
         }
     }
     for(i=0;i<2;i++)
     {
         if(dig[i]==0)
         {
             if(pdig[i]==1)
             {
                 X_flag=1;
             }
             else if(pdig[i]==2)
             {
                 O_flag=1;
             }
         }
     }
     if(X_flag && O_flag)
         printf("Case #%d: Draw\n",turn);
     else if(X_flag)
         printf("Case #%d: X won\n",turn);
     else if(O_flag)
         printf("Case #%d: O won\n",turn);
     else if(Dot_flag)
         printf("Case #%d: Game has not completed\n",turn);
     else
         printf("Case #%d: Draw\n",turn);
 }

