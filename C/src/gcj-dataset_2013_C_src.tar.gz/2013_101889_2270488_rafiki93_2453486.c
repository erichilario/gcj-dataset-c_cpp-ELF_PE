#include<stdio.h>
 char c[4][4];
 int checkcol(char ch,int co);
 int checkrow(char ch,int r);
 int checkdiag(char ch);
 int main()
 {
     FILE *fp,*fp1;
     fp=fopen("A-large.in","r");
     fp1=fopen("A-large.out","w");
         char g;
     int i,j,flag=0,times,k=0,chk1,chk2;
     fscanf(fp,"%d",&times);
     while(times--)
     {
         k++;
     for(i=0;i<4;i++)
     {
         fscanf(fp,"%c",&g);
        // if(g=='\n') printf("flag\n");
         for(j=0;j<4;j++)
         {
             fscanf(fp,"%c",&c[i][j]);
             if(c[i][j]=='.')    flag=1;
         }
 
     }
     fscanf(fp,"%c",&g);
     /* for(i=0;i<4;i++)
      {
          for(j=0;j<4;j++)
         {
             printf("%c ",c[i][j]);
         }
         printf("\n");
     }*/
     for(i=0;i<4;i++)
     {
     chk1=checkrow('X',i);
     if(chk1==1) {fprintf(fp1,"Case #%d: X won\n",k); goto out;}  //X wins
     chk1=checkcol('X',i);
     if(chk1==1) {fprintf(fp1,"Case #%d: X won\n",k); goto out;}
 
     chk2=checkrow('O',i);
     if(chk2==1) { fprintf(fp1,"Case #%d: O won\n",k); goto out;}//o wins
     chk2=checkcol('O',i);
     if(chk2==1) { fprintf(fp1,"Case #%d: O won\n",k); goto out;}
 
     chk1=checkdiag('X');
     if(chk1==1)  {fprintf(fp1,"Case #%d: X won\n",k); goto out;}
     chk2=checkdiag('O');
     if(chk2==1) { fprintf(fp1,"Case #%d: O won\n",k); goto out;}
     }
     if(flag==1)
         fprintf(fp1,"Case #%d: Game has not completed\n",k);
         else
         fprintf(fp1,"Case #%d: Draw\n",k);
         out:  flag=0;
     }
     getchar();
     getchar();
         fclose(fp);
         fclose(fp1);
 
 
     return 0;
 }
 
 int checkrow(char ch,int r)
 {
     int i,flag=0;
     for(i=0;i<4;i++)
     {
         if(!(c[r][i]==ch || c[r][i]=='T'))
             flag=1;
     }
     if(flag==1) return 0;
     else        return 1;
 }
 
 
 
 int checkcol(char ch,int co)
 {
     int i,flag=0;
     for(i=0;i<4;i++)
     {
         if(!(c[i][co]==ch || c[i][co]=='T'))
             flag=1;
     }
     if(flag==1) return 0;
     else        return 1;
 }
 
 int checkdiag(char ch)
 {
     int flag1=0,flag2=0,i;
     for(i=0;i<4;i++)
     {
         if(!(c[i][i]==ch||c[i][i]=='T'))
         flag1=1;
 
         if(!(c[i][3-i]==ch || c[i][3-i]=='T'))
         flag2=1;
     }
         if(flag1==0 || flag2==0) return 1;
         else
         return 0;
 
 }

