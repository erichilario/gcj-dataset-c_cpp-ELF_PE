#include <stdio.h>
 #define BOARDSIZE 4
 #define X 1
 #define O 2
 
 int coordstoi (int x, int y) {
 	return y * BOARDSIZE + x;
 }
 
 void inc (char tile, int* xcount, int* ocount) {
 	switch (tile) {
 		case 'X':
 			(*xcount)++;
 			break;
 		case 'O':
 			(*ocount)++;
 			break;
 		case 'T':
 			(*xcount)++;
 			(*ocount)++;
 			break;
 	}
 }
 
 int horizwin (char *board) {
 	int x, y;
 	for (y = 0; y < BOARDSIZE; y++) {
 		int xcount = 0, ocount = 0;
 		for (x = 0; x < BOARDSIZE; x++) {
 			inc (board [coordstoi(x, y)], &xcount, &ocount);
 		}
 		if (xcount == BOARDSIZE) {
 			return X;
 		} else if (ocount == BOARDSIZE) {
 			return O;
 		}
 	}
 	return 0;
 }
 int vertwin (char *board) {
 	int x, y;
 	for (x = 0; x < BOARDSIZE; x++) {
 		int xcount = 0, ocount = 0;
 		for (y = 0; y < BOARDSIZE; y++) {
 			inc (board [coordstoi(x, y)], &xcount, &ocount);
 		}
 		if (xcount == BOARDSIZE) {
 			return X;
 		} else if (ocount == BOARDSIZE) {
 			return O;
 		}
 	}
 	return 0;
 }
 int fswin (char *board) {
 	int xcount = 0, ocount = 0;
 	int i;
 	for (i = 0; i < BOARDSIZE; i++) {
 		inc (board [coordstoi (BOARDSIZE - i - 1, i)], &xcount, &ocount);
 	}
 	if (xcount == BOARDSIZE) {
 		return X;
 	} else if (ocount == BOARDSIZE) {
 		return O;
 	}
 	return 0;
 }
 int bswin (char *board) {
 	int xcount = 0, ocount = 0;
 	int i;
 	for (i = 0; i < BOARDSIZE; i++) {
 		inc (board [coordstoi (i, i)], &xcount, &ocount);
 	}
 	if (xcount == BOARDSIZE) {
 		return X;
 	} else if (ocount == BOARDSIZE) {
 		return O;
 	}
 	return 0;
 }
 int isfull (char *board) {
 	int full = 1;
 	int i;
 	for (i = 0; i < BOARDSIZE * BOARDSIZE; i++) {
 		if (board [i] != 'X' && board [i] != 'O' && board [i] != 'T') full = 0;
 	}
 	return full;
 }
 
 void results (char *board) {
 	int winner = 0;
 	int horizwinner;
 	if (horizwinner = horizwin (board)) {
 		winner = horizwinner;
 	}
 	int vertwinner;
 	if (vertwinner = vertwin (board)) {
 		winner = vertwinner;
 	}
 	int fswinner;
 	if (fswinner = fswin (board)) {
 		winner = fswinner;
 	}
 	int bswinner;
 	if (bswinner = bswin (board)) {
 		winner = bswinner;
 	}
 	if (winner) {
 		if (winner == X) {
 			printf ("X won\n");
 		} else {
 			printf ("O won\n");
 		}
 	} else {
 		if (isfull (board)) {
 			printf ("Draw\n");
 		} else {
 			printf ("Game has not completed\n");
 		}
 	}
 }
 
 int main (void) {
 	int probcount;
 	scanf ("%i\n", &probcount);
 	int i, row;
 	char board [BOARDSIZE * BOARDSIZE];
 	for (i = 0; i < probcount; i++) {
 		printf ("Case #%i: ", i+1);
 		for (row = 0; row < BOARDSIZE; row++) {
 			char *crow;
 			crow = board + row * BOARDSIZE;
 			scanf ("%c%c%c%c\n", crow, crow + 1, crow + 2, crow + 3);
 		}
 		results (board);
 	}
 }
