#include <stdio.h>
 int isCuttable(int n,int m,int N,int M,int heights[100][100]){
 	int i,u=1;
 	for(i=0;i<N;i++){
 		if(heights[i][m]>heights[n][m]){
 			u=0;
 			break;
 		}
 	}
 	if(u) return 1;
 	u=1;
 	for(i=0;i<M;i++){
 		if(heights[n][i]>heights[n][m]){
 			u=0;
 			break;
 		}
 	}
 	if(u) return 1;
 	return 0;
 }
 int main(){
 	int heights[100][100];
 	int N,M,T,i1,i2,i3,u;
 	FILE *file1;
 	file1=fopen("B-small-attempt0.in","r");
 	FILE *file2;
 	file2=fopen("B-small-attempt0.out","w");
 	fscanf(file1,"%d",&T);
 	for(i1=0;i1<T;i1++){
 		fscanf(file1,"%d",&N);
 		fscanf(file1,"%d",&M);
 		for(i2=0;i2<N;i2++){
 			for(i3=0;i3<M;i3++){
 				fscanf(file1,"%d",&heights[i2][i3]);
 			}
 		}
 		u=1;
 		for(i2=0;i2<N;i2++){
 			if(u)
 			for(i3=0;i3<M;i3++){
 				if(!isCuttable(i2,i3,N,M,heights)){
 					u=0;
 					break;
 				}
 			}
 		}
 		if(u)
 		fprintf(file2,"Case #%d: YES\n",i1+1);
 		else
 		fprintf(file2,"Case #%d: NO\n",i1+1);
 	}
 	fclose(file2);
 	return 0;
 }

