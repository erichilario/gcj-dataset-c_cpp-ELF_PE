#include<stdio.h>
 
 int main()
 {
   int t,i,j,k,n,m,l,o,fr,fc,p=0;
   int array[105][105];
   scanf("%d",&t);
   while(t--)
   {
     p++;
     fr=0,fc=0;
    scanf("%d %d",&n,&m);
 
   for(i=1;i<=n;i++)
    {
      for(j=1;j<=m;j++)
       {
          scanf("%d",&array[i][j]);
       }
    }
   
 
   for(i=1;i<=n;i++)
    {
      for(j=1;j<=m;j++)
       {
         if(array[i][j]==1)
          {
            fr=0,fc=0;
            for(l=1;l<=m;l++)
             {
                if(array[i][l]!=1)
                   {
                     fr=1;
                     break;
                   }
                  
             }
            for(l=1;l<=n;l++)
              {
                if(array[l][j]!=1)
                  {
                    fc=1;
                    break;
                  }
              }
  
           if(fr==1 && fc==1)
             {
               printf("Case #%d: NO\n",p);
               goto z;
             }
          }
       }
    }
 printf("Case #%d: YES\n",p);
 
 z:
 continue;
 }
 return 0;
 }
