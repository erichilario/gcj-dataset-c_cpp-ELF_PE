#include<stdio.h>
 #include<stdlib.h>
 long long squ[5] = {1,4,9,121,484};
 int main()
 {
     int t,i,j;
     int a,b,cnt;
     FILE *fp,*fo;
     fp = fopen("inp.in","r");
     fo = fopen("out.txt","w");
     fscanf(fp,"%d",&t);
     j=1;
     while(t--)
     {
         fscanf(fp,"%d%d",&a,&b);
         cnt = 0;
         for(i=0;i<=4;i++)
         {
             if(squ[i]>=a&&squ[i]<=b)
                 cnt++;
         }
         fprintf(fo,"Case #%d: %d\n",j++,cnt);
     }
     return 0;
 }

