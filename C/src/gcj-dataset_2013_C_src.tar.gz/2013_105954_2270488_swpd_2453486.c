#include <stdio.h>
 
 enum {X_WIN, O_WIN, NO_WIN, NO_FIN};
 
 void print(char m[][4])
 {
     int i,j;
     for (i = 0; i < 4; ++i)
     {
         for (j = 0; j < 4; ++j)
             printf("%c", m[i][j]);
         printf("\n");
     }
 }
 
 int checkline(char m[][4], int x, int y, int dx, int dy)
 {
     int i;
     int count[3] = {0, 0, 0};
     for (i = 0; i < 4; ++i)
     {
         char s = m[x + i * dx][y + i * dy];
         if (s == '.') return NO_FIN;
         if (s == 'X') count[0]++;
         if (s == 'O') count[1]++;
         if (s == 'T') count[2]++;
     }
     if (count[0] + count[2] == 4) return X_WIN;
     if (count[1] + count[2] == 4) return O_WIN;
     return NO_WIN;
 }
 
 int main(int argc, const char *argv[])
 {
     int t;
     int count = 1;
     char m[4][4];
     FILE *fp = fopen(argv[1], "r");
     fscanf(fp, "%d ", &t);
     while (t--)
     {
         int i,j;
         char in[6];
         for (i = 0; i < 4; ++i)
         {
             fgets(in, sizeof(in), fp);
             for (j = 0; j < 4; ++j)
                 m[i][j] = in[j];
         }
         fgets(in, sizeof(in), fp);
         int win = 0;
         int no_fin = 0;
         char winner;
         for (i = 0; i < 4; ++i)
         {
             int status = checkline(m, i, 0, 0, 1);
             if (status == X_WIN)
             {
                 win = 1;
                 winner = 'X';
             }
             if (status == O_WIN)
             {
                 win = 1;
                 winner = 'O';
             }
             if (status == NO_FIN)
                 no_fin = 1;
         }
         for (i = 0; i < 4; ++i)
         {
             int status = checkline(m, 0, i, 1, 0);
             if (status == X_WIN)
             {
                 win = 1;
                 winner = 'X';
             }
             if (status == O_WIN)
             {
                 win = 1;
                 winner = 'O';
             }
             if (status == NO_FIN)
                 no_fin = 1;
         }
         int status = checkline(m, 0, 0, 1, 1);
         if (status == X_WIN)
         {
             win = 1;
             winner = 'X';
         }
         if (status == O_WIN)
         {
             win = 1;
             winner = 'O';
         }
         if (status == NO_FIN)
             no_fin = 1;
         status = checkline(m, 3, 0, -1, 1);
         if (status == X_WIN)
         {
             win = 1;
             winner = 'X';
         }
         if (status == O_WIN)
         {
             win = 1;
             winner = 'O';
         }
         if (status == NO_FIN)
             no_fin = 1;
         printf("Case #%d: ", count);
         if (win) printf("%c won\n", winner);
         else if (no_fin) printf("Game has not completed\n");
         else printf("Draw\n");
         count++;
     }
     fclose(fp);
 
     return 0;
 }

