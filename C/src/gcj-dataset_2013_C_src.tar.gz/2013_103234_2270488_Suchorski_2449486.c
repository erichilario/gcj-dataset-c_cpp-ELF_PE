#include <stdio.h>
 #include <stdlib.h>
 
 int ok(int l, int c, int tem, int **grama) {
 	int j, k, x, b = 1;
 	if (l == 1 || c == 1) {
 		return 1;
 	}
 	for (j = 0; j < c; ++j) {
 		if (grama[0][j] == 1) {
 			b = 0;
 			break;
 		}
 	}
 	if (b) {
 		for (j = 0; j < l; ++j) {
 			if (grama[j][0] == 1) {
 				b = 0;
 				break;
 			}
 		}
 	}
 	if (b && tem) {
 		return 0;
 	}
 	for (j = 0; j < l; ++j) {
 		for (k = 0; k < c; ++k) {
 			if (grama[j][k] == 1) {
 				for (x = 0; x < c; ++x) {
 					if (grama[j][x] == 2) {
 						for (x = k; x < l; ++x) {
 							if (grama[x][k] == 2) {
 								return 0;
 							}
 						}
 						break;
 					}
 				}
 			}
 		}
 	}
 	return 1;
 }
 
 int main(int argc, char *argv[]) {
 	FILE *fr = fopen("input.txt", "r");
 	FILE *fw = fopen("output.txt", "w");
 	int i, j, k, l, c, total, tem;
 	fscanf(fr, "%d", &total);
 	for (i = 0; i < total; ++i) {
 		int **grama;
 		tem = 0;
 		fscanf(fr, "%d %d", &l, &c);
 		grama = (int**) malloc(l * sizeof(int*));
 		for (j = 0; j < l; ++j) {
 			grama[j] = (int*) malloc(c * sizeof(int));
 		}
 		for (j = 0; j < l; ++j) {
 			for (k = 0; k < c; ++k) {
 				fscanf(fr, "%d", &grama[j][k]);
 				if (grama[j][k] == 1) {
 					tem = 1;
 				}
 			}
 		}
 		fprintf(fw, "Case #%u: %s\n", (i + 1), (ok(l, c, tem, grama)) ? "YES" : "NO");
 	}
 	return 0;
 }

