#include<stdio.h>
 #include<stdlib.h>
 #include<stddef.h>
 
 void status(char** A,int test,FILE* f);
 int diagonal_check(char** A);
 int row_check(char** A);
 int column_check(char** A);
 
 int main(void)
 {
 	 int test_cases,i,j;
 	 char ch;
 	 FILE* fp = fopen("A-small-attempt1.in","r");
 	 fscanf(fp,"%d",&test_cases);
 	 fscanf(fp,"%c",&ch);
 	 char** A;
 	 A = (char**)malloc(4*sizeof(char*));
 	  FILE* f = fopen("output","w");
 	 for(j=1;j<=test_cases;j++)
 	 {
 		 for(i=0;i<4;i++)
 		 {
 		 	A[i] = (char*)malloc(4*sizeof(char));
 		 	fscanf(fp,"%c%c%c%c",&A[i][0],&A[i][1],&A[i][2],&A[i][3]);
 		 	fscanf(fp,"%c",&ch);
 
 		 }
 		 fscanf(fp,"%c",&ch);
 		 status(A,j,f);
 	}
 	free(A);
 
 	 return 0;
 }
 
 
 void status(char** A,int test,FILE* f)
 {
 	int n[3];
 	int h = 0;
 	n[0] = diagonal_check(A);
 	n[1] = row_check(A);
 	n[2] = column_check(A);
 
 	if((n[0] == 1) || (n[1] == 1) || (n[2] == 1))
 	{
 		fprintf(f,"Case #%d: X won\n",test);
 	}
 	else if(n[0] == 2 || n[1] == 2 || n[2] == 2)
 	{
 		fprintf(f,"Case #%d: O won\n",test);
 	}
 	else if((n[1] == 3) && (n[2] == 3))
 	{
 		fprintf(f,"Case #%d: Draw\n",test);
 		//fprintf(f,"Case #%d: Game has not completed\n",test);
 	}
 	else
 	{
 		//fprintf(f,"Case #%d: Draw\n",test);
 		fprintf(f,"Case #%d: Game has not completed\n",test);
 	}
 	return;
 }
 
 int diagonal_check(char** A)
 {
 	char ch[4];
 	char c;
 	int j = 0;
 	int p = 0;
 	int k;
 	ch[0] = A[0][0];
 	ch[1] = A[1][1];
 	ch[2] = A[2][2];
 	ch[3] = A[3][3];
 
 	if(ch[0] != '.' && ch[1] != '.' && ch[2] != '.' && ch[3] != '.')
 	{
 		j = 0;
 		while(j!=4 && A[j][j] == 'T' )
 		{
 			j++;
 		}
 		if(j != 4)	
 			c = A[j][j];
 		else
 			c = A[0][0];
 
 		j = 0;
 		while(j!=4 && (c == A[j][j] || A[j][j] == 'T'))
 		{
 			j++;
 		}
 		if(j == 4)
 		{
 			if(c == 'X')
 				return 1;
 			else if(c == 'O')
 				return 2;
 		}
 	}
 
 	ch[0] = A[0][3];
 	ch[1] = A[1][2];
 	ch[2] = A[2][1];
 	ch[3] = A[3][0];
 	j = 0;
 	if(ch[0] != '.' && ch[1] != '.' && ch[2] != '.' && ch[3] != '.')
 	{
 		
 		j = 0;
 		k = 3;
 		c = A[j][k];
 		while( j!=4 && A[j][k] == 'T' )
 		{
 			j++;
 			k--;
 		}	
 		if(j!=4)
 			c = A[j][k];
 		else
 			c = A[0][3];
 		j = 0;
 		k = 3;
 		while((j!=4) && ((c == A[j][k]) || (A[j][k] == 'T')))
 		{
 			j++;
 			k--;
 		}
 		if(j == 4)
 		{
 			if(c == 'X')
 				return 1;
 			else if(c == 'O')
 				return 2;
 		}
 	}
 	else
 		return 0;
 	
 }
 
 int row_check(char** A)
 {
 	int i,j,m;
 	m = 0;
 	char ch[4];
 	char c;
 	for(i=0;i<4;i++)
 	{
 		ch[0] = A[i][0];
 		ch[1] = A[i][1];
 		ch[2] = A[i][2];
 		ch[3] = A[i][3];
 		if(ch[0] != '.' && ch[1] != '.' && ch[2] != '.' && ch[3] != '.')
 		{
 				j = 0;
 				c = A[i][0];
 				while(j!=4  && A[i][j] == 'T')
 				{
 					j++;
 				}
 				if(j!= 4)
 					c = A[i][j];
 				else
 					c = A[i][0];
 				j = 0;
 				while(j!=4 && (c == A[i][j] || A[i][j] == 'T'))
 				{
 					j++;
 				}
 	
 				if(j==4)
 				{
 					if(c == 'X')
 						return 1;
 					else if(c == 'O')
 						return 2;
 				
 				}
 					m++;
 					if(m==4)
 					{
 						return 3;
 					}
 		}
 		else
 			continue;
 	}
 	return 0;
 }
 
 int column_check(char** A)
 {
 	int i,j,m;
 	m =0;
 	char ch[4];
 	char c;
 	for(i=0;i<4;i++)
 	{
 		ch[0] = A[0][i];
 		ch[1] = A[1][i];
 		ch[2] = A[2][i];
 		ch[3] = A[3][i];
 		if(ch[0] != '.' && ch[1] != '.' && ch[2] != '.' && ch[3] != '.')
 		{
 				j = 0;
 				c = A[0][i];
 				while( j!=4 && A[j][i] == 'T')
 				{
 					j++;
 				}
 
 				if(j != 4)
 					c = A[j][i];
 				else
 					c = A[0][i];
 
 				j = 0;
 				while(j!=4 && (c == A[j][i] || A[j][i] == 'T'))
 				{
 					j++;
 				}
 				if(j==4)
 				{
 					if(c == 'X')
 						return 1;
 					else if(c == 'O')
 						return 2;
 				}
 					m++;
 					if(m==4)
 					{
 						return 3;
 					}
 		}
 		else
 			continue;
 	}
 	return 0;
 }
