#define _CRT_SECURE_NO_DEPRECATE
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #define GAME_NOT_OVER -1
 #define GAME_DRAW  0
 #define GAME_WON  1
 #define DOT  '.'
 #define X  'X'
 #define O  'O'
 #define T  'T'
 
 int A2013(void);
 char a[4][4];
 
 PRINT_ARRAY(int a[100][100], int N, int M)
 { 
     int i=0, j=0;
     for(i=0;i<N;i++)
     {
         for(j=0;j<M;j++)
             printf("%d ", a[i][j]);
         printf("\n");
     }
 }
 char ROW_CHECK(char ch)
 {
     int i = 0;
     int rcount = 0;
     int ccount = 0;
     int dcount = 0;
 
     for (i = 0; i < 4; i++)
     {
         rcount=dcount=ccount=0;
         /* Row wise check */
         if(a[i][0] == ch || a[i][0] == T) rcount++;
         else if( a[i][0] == DOT) dcount++;
         else ccount++;
 
         if(a[i][1] == ch || a[i][1] == T ) rcount++;
         else if( a[i][1] == DOT) dcount++;
         else ccount++;
 
         if(a[i][2] == ch || a[i][2] == T) { rcount++; } 
         else if( a[i][2] == DOT) dcount++;
         else ccount++;
 
         if(a[i][3] == ch || a[i][3] == T) { rcount++; } 
         else if( a[i][3] == DOT) dcount++;
         else ccount++;
 
         if (rcount==4) return GAME_WON;
         if(rcount+dcount == 4)
             return(GAME_NOT_OVER);
     }
     return('C');
 }
 
 
 char COL_CHECK(char ch)
 {
     int i = 0;
     int rcount = 0;
     int ccount = 0;
     int dcount = 0;
 
     for (i = 0; i < 4; i++)
     {
         rcount=dcount=ccount=0;
         /* Row wise check */
         if(a[0][i] == ch || a[0][i] == T) rcount++;
         else if( a[0][i] == DOT) dcount++;
         else ccount++;
 
         if(a[1][i] == ch || a[1][i] == T ) rcount++;
         else if( a[1][i] == DOT) dcount++;
         else ccount++;
 
         if(a[2][i] == ch || a[2][i] == T) { rcount++; } 
         else if( a[2][i] == DOT) dcount++;
         else ccount++;
 
         if(a[3][i] == ch || a[3][i] == T) { rcount++; } 
         else if( a[3][i] == DOT) dcount++;
         else ccount++;
 
         if (rcount==4) return GAME_WON;
         if(rcount+dcount == 4)
             return(GAME_NOT_OVER);
     }
     return('C');
 }
 
 
 
 char DIAG_CHECK(char ch)
 {
     int rcount = 0;
     int ccount = 0;
     int dcount = 0;
 
     {
         rcount=dcount=ccount=0;
         /* Row wise check */
         if(a[0][0] == ch || a[0][0] == T) rcount++;
         else if( a[0][0] == DOT) dcount++;
         else ccount++;
 
         if(a[1][1] == ch || a[1][1] == T ) rcount++;
         else if( a[1][1] == DOT) dcount++;
         else ccount++;
 
         if(a[2][2] == ch || a[2][2] == T) { rcount++; } 
         else if( a[2][2] == DOT) dcount++;
         else ccount++;
 
         if(a[3][3] == ch || a[3][3] == T) { rcount++; } 
         else if( a[3][3] == DOT) dcount++;
         else ccount++;
 
         if (rcount==4) return GAME_WON;
         if(rcount+dcount == 4)
             return(GAME_NOT_OVER);
     }
 
     {
         rcount=dcount=ccount=0;
         /* Row wise check */
         if(a[0][3] == ch || a[0][3] == T) rcount++;
         else if( a[0][3] == DOT) dcount++;
         else ccount++;
 
         if(a[1][2] == ch || a[1][2] == T ) rcount++;
         else if( a[1][2] == DOT) dcount++;
         else ccount++;
 
         if(a[2][1] == ch || a[2][1] == T) { rcount++; } 
         else if( a[2][1] == DOT) dcount++;
         else ccount++;
 
         if(a[3][0] == ch || a[3][0] == T) { rcount++; } 
         else if( a[3][0] == DOT) dcount++;
         else ccount++;
 
         if (rcount==4) return GAME_WON;
         if(rcount+dcount == 4)
             return(GAME_NOT_OVER);
     }
     return('C');
 }
 
 int A2013(void )
 {
     int i=0;
     int TC = 0,t=0;
     char line[5];
     FILE *fp, *fpo;
 
     //    fp = fopen("c:\\sajive\\CODEJAM\\input.txt","r");
     //    fpo = fopen("c:\\sajive\\CODEJAM\\output.txt","w");
 
     fp = fopen("input.txt","r");
     fpo = fopen("output.txt","w");
 
     if (fp == NULL) {perror ("Error opening file");exit(0);}
     else
     {
         fscanf(fp, "%d", &TC);
 
         memset(a, '.', sizeof(a));
         while(!feof(fp))
         {
             if(t<TC)
             {
                 t++;
             }
             else
                 return(1);
 
             for (i = 0; i < 4; i++)
             {
                 //fscanf(fp, "%c%c%c%c", &a[i][0], &a[i][1], &a[i][2], &a[i][3]);
                 fscanf(fp, "%s", line);
                 sscanf(line, "%c%c%c%c", &a[i][0], &a[i][1], &a[i][2], &a[i][3]);
                 //                printf("%c-%c-%c-%c", a[i][0], a[i][1], a[i][2], a[i][3]);
             }
             fprintf(fpo, "Case #%d: ", t);
 
             {
                 char cX; char rX; char dX;
                 char cO; char rO; char dO;
 
                 rX = ROW_CHECK(X);
                 if(rX==GAME_WON)
                 { fprintf(fpo, "X won \n");continue;}
 
                 cX = COL_CHECK(X);
                 if(cX==GAME_WON)
                 { fprintf(fpo, "X won \n");continue;}
 
                 dX = DIAG_CHECK(X);
                 if(dX==GAME_WON)
                 { fprintf(fpo, "X won \n");continue;}
 
                 rO = ROW_CHECK(O);
                 if(rO==GAME_WON)
                 { fprintf(fpo, "O won \n");continue;}
 
                 cO = COL_CHECK(O);
                 if(cO==GAME_WON)
                 { fprintf(fpo, "O won \n");continue;}
 
                 dO = DIAG_CHECK(O);
                 if(dO==GAME_WON)
                 { fprintf(fpo, "O won \n");continue;}
 
                 if(rX == GAME_NOT_OVER || cX == GAME_NOT_OVER || dX == GAME_NOT_OVER
                     || rO == GAME_NOT_OVER || cO == GAME_NOT_OVER || dO == GAME_NOT_OVER)
                     fprintf(fpo, "Game has not completed\n");
                 else
                     fprintf(fpo, "Draw\n");
 
             }
 
         }
 
     }
     fclose (fp);
     fclose (fpo);
 
     return 0;
 }
 
 
 int B2013(void )
 {
     int i=0, j=0, k=0;
     int TC = 0,t=0;
     int N = 0, M = 0;
     int bFlag = 1;
     FILE *fp, *fpo;
     int nCol =0;
 
     //    fp = fopen("input.txt","r");
     //    fpo = fopen("output.txt","w");
 
     fp = fopen("c:\\sajive\\CODEJAM\\input.txt","r");
     fpo = fopen("c:\\sajive\\CODEJAM\\output.txt","w");
 
     if (fp == NULL) {perror ("Error opening file");exit(0);}
     else
     {
         char aa;
         int ref=0;
         int bChanged  = 0;
         
         fscanf(fp, "%d", &TC);
 
         memset(a, '.', sizeof(a));
         while(!feof(fp))
         {
             
             if(t<TC)
             {
                 t++; nCol=0;
             }
             else
                 return(1);
             bFlag = 1;
             fscanf(fp, "%d %d", &N, &M);
 
             aa = fgetc(fp);
             {
                 int a[100][100];
                 int v[100];int c[100];
                 for (i = 0; i < N; i++)
                 {
                     for (j = 0, k=0; j < M+M-1; j++){
                         aa = fgetc(fp);
                         if(aa != 32 && aa!=13){
                             a[i][k]= atoi(&aa);
                             k++;
                         }
                     }
                     aa = getc(fp);
                 }
 
                 PRINT_ARRAY(a, N, M);
                 if(1==N || 1==M)
                    goto print_res;
 
                 for (i = 0; i < N; i++)
                 {
                     bChanged = 0;
                     if(N==1) 
                     {
                         bFlag = 1;
                         break;
                     }
                     c[i]=0;
                     for (j = 0; j < M; j++)
                     {
                         if(j==0) {ref = a[i][j]; /*if(i==0)continue;*/}
 
                         if(ref < a[i][j])
                             bChanged=1;
                         if(ref == a[i][j])
                             c[i] = c[i]+1;
 
                         if(i==0 /*&& ref >= a[i][j]*/)
                         { 
                             /* traverse downwards */
                             for (k = 0; k < N; k++)
                             {
                                 if(a[i][j] != a[k][j]) {
                                     //fprintf(stdout, "NOT POSSIBLE: %d - %d \n", ref, a[k][j]);
                                     v[j] = 0;
                                     break;
                                 }
                                 v[j] = 1;
                             }
                         }
                         else if(i != 0)
                         {
                             if(ref != a[i][j])
                             {
                                 if(v[j] != 1) bFlag = 0;
                             }
                             else if(ref < a[i][j] && c[i-1] == 0)
                             {
                                 bFlag=0;
                             }
                         }
                         if(v[0] == 0 && bChanged == 1){
                             bFlag = 0;break;}
                         /*
                         else if(ref < a[i][j])
                             ref = a[i][j];*/
                     }
                 }
                 for(i=0;i<N;i++) {
                     nCol = nCol + c[i];
                 }
                // if(nCol > 1) bFlag = 0;
                 if(nCol == N-1) bFlag = 1;
             }
 print_res:
             fprintf(fpo, "Case #%d: %s\n", t, bFlag?"YES":"NO");
             fprintf(stdout, "---- Case #%d: %s ------- \n", t, bFlag?"YES":"NO");
 
         }
 
     }
     fclose (fp);
     fclose (fpo);
 
     return 0;
 }
 
 
 int B2013_1(void )
 {
     int i=0, j=0, k=0;
     int TC = 0,t=0;
     int N = 0, M = 0;
     int bFlag = 1;
     FILE *fp, *fpo;
     int nCol =0;
 
     //    fp = fopen("input.txt","r");
     //    fpo = fopen("output.txt","w");
 
     fp = fopen("c:\\sajive\\CODEJAM\\input.txt","r");
     fpo = fopen("c:\\sajive\\CODEJAM\\output.txt","w");
 
     if (fp == NULL) {perror ("Error opening file");exit(0);}
     else
     {
         char aa;
         int ref=0;
         int bChanged  = 0;
 
         fscanf(fp, "%d", &TC);
 
         memset(a, '.', sizeof(a));
         while(!feof(fp))
         {
 
             if(t<TC)
             {
                 t++; nCol=0;
             }
             else
                 return(1);
             bFlag = 1;
             fscanf(fp, "%d %d", &N, &M);
 
             aa = fgetc(fp);
             {
                 int a[100][100];
                 int r[100];int c[100];
                 for (i = 0; i < N; i++)
                 {
                     for (j = 0, k=0; j < M+M-1; j++){
                         aa = fgetc(fp);
                         if(aa != 32 && aa!=13){
                             a[i][k]= atoi(&aa);
                             k++;
                         }
                     }
                     aa = getc(fp);
                 }
 
                 PRINT_ARRAY(a, N, M);
                 if(1==N || 1==M)
                     goto print_res;
 
 
                 for (i = 0; i < 1; i++) {
                     for (j = 0; j < M; j++)
                     {
                         /* traverse downwards 0,0 1,0 2,0 3,0 */
                         for (k = 0; k < N; k++)
                         {
                             if(a[i][j] != a[k][j]) {
                                 c[j] = 0;break;
                             }
                             c[j] = 1;
                         }
                     }
                 }
 
                 for (i = 0; i < 1; i++) {
                     for (j = 0; j < N; j++)
                     {
                         /* traverse right 0,0 1,0 2,0 3,0*/
                         for (k = 0; k < M; k++)
                         {
                             if(a[j][i] != a[j][k]) {
                                 r[j] = 0;
                                 break;
                             }
                             r[j] = 1;
                         }
                     }
                 }
 
                 for (i = 0; i < N; i++) {
                     for (j = 0; j < M; j++)
                     {
                         if(a[i][j] == 1)
                         {
                             if(r[i]==1 || c[j]==1)
                                 bFlag = 1;
                             else{
                                 bFlag = 0;break;}
                         }
                     }
                     if(bFlag ==0) break;
                 }
             }
 print_res:
             fprintf(fpo, "Case #%d: %s\n", t, bFlag?"YES":"NO");
             fprintf(stdout, "---- Case #%d: %s ------- \n", t, bFlag?"YES":"NO");
 
         }
 
     }
     fclose (fp);
     fclose (fpo);
 
     return 0;
 }
 
 
 int main(int argc, char *argv[])
 {
     //    int i = A2013();
     int i = B2013_1();
     return i;
 }
 

