#include <stdio.h>
 #include <stdlib.h>
 
 int lawn[100][100];
 int maxRow[100];
 int maxCol[100];
 
 void solveCase(void);
 
 int main(void){
 	int testCases;
 	int currentCase = 1;
 	
 	scanf("%d", &testCases);
 	
 	while(testCases--){
 		printf("Case #%d: ", currentCase++);
 		solveCase();
 	}
 
 	return 0;
 }
 
 void solveCase(void){
 	int rows;
 	int cols;
 	int i;
 	int k;
 	int solvable = 1;
 	
 	scanf("%d %d", &rows, &cols);
 	
 	for(i = 0; i < rows; i++){
 		int max = 0;
 		for(k = 0; k < cols; k++){
 			scanf("%d", &lawn[i][k]);
 			if (lawn[i][k] > max) max = lawn[i][k];
 		}
 		maxRow[i] = max;
 	}
 
 	for(k = 0; k < cols; k++){
 		int max = 0;
 		for(i = 0; i < rows; i++){
 			if (lawn[i][k] > max) max = lawn[i][k];
 		}
 		maxCol[k] = max;
 	}
 	
 	for(k = 0; k < cols; k++){
 		for(i = 0; i < rows; i++){
 			if (lawn[i][k] < maxRow[i] && lawn[i][k] < maxCol[k]){
 				solvable = 0;
 				goto end;
 			}
 		}
 	}
 
 end:
 	if (solvable){
 		printf("YES\n");
 	}else{
 		printf("NO\n");
 	}
 }
 

