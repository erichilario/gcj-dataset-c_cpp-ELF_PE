#include <stdio.h>
 char board[5][5];
 int check(int x, int y, char c)
 {
 	int ans = 0;
 	int i,j;
 	int k;
 
 	//------>
 	j = y;
 	k = 0;
 	while(j < 4) {
 		if(board[x][j] == c || (k == 3 && board[x][j] == 'T')) {
 			k++;
 		}
 		else{
 			break;
 		}
 		j++;
 	}
 	if(k == 4){
 		return 1;
 	}
 	
 	//<------
 	j = y;
 	k = 0;
 	while(j >= 0) {
 		if(board[x][j] == c || (k == 3 && board[x][j] == 'T')) {
 			k++;
 		}
 		else{
 			break;
 		}
 		j--;
 	}
 	if(k == 4){
 		return 1;
 	}
 
 	// |
 	// |
 	// v
 
 	i = x;
 	k = 0;
 	while(i < 4) {
 		if(board[i][y] == c || (k == 3 && board[i][y] == 'T')) {
 			k++;
 		}
 		else{
 			break;
 		}
 		i++;
 	}
 	if(k == 4){
 		return 1;
 	}
 	// ^
 	// |
 	//
 	i = x;
 	k = 0;
 	while(i >= 0) {
 		if(board[i][y] == c || (k == 3 && board[i][y] == 'T')) {
 			k++;
 		}
 		else{
 			break;
 		}
 		i--;
 	}
 	if(k == 4){
 		return 1;
 	}
 
 	i = x;
 	j = y;
 	k = 0;
 	while(i < 4 && j < 4) {
 		if(board[i][j] == c || (k == 3 && board[i][j] == 'T')) {
 			k++;
 		}
 		else{
 			break;
 		}
 		i++;
 		j++;
 	}
 	if(k == 4){
 		return 1;
 	}
 	i = x;
 	j = y;
 	k = 0;
 	while(i >= 0 && j >= 0) {
 		if(board[i][j] == c || (k == 3 && board[i][j] == 'T')) {
 			k++;
 		}
 		else{
 			break;
 		}
 		i--;
 		j--;
 	}
 	if(k == 4){
 		return 1;
 	}
 
 	i = x;
 	j = y;
 	k = 0;
 	while(i >= 0  && j < 4) {
 		if(board[i][j] == c || (k == 3 && board[i][j] == 'T')) {
 			k++;
 		}
 		else{
 			break;
 		}
 		i--;
 		j++;
 	}
 	if(k == 4){
 		return 1;
 	}
 
 	i = x;
 	j = y;
 	k = 0;
 	while(i < 4  && j >= 0) {
 		if(board[i][j] == c || (k == 3 && board[i][j] == 'T')) {
 			k++;
 		}
 		else{
 			break;
 		}
 		i++;
 		j--;
 	}
 	if(k == 4){
 		return 1;
 	}
 	return 0;
 }
 int main()
 {
 	FILE *in,*out;
 	int i,j;
 	int x,o;
 	int t;
 	int cs = 1;
 	in = fopen("a.in","r");
 	out = fopen("a.ou","w");
 
 	fscanf(in,"%d",&t);
 	char awe;
 	int cc;
 	while (t--) {
 		for(i = 0; i < 4; i++) {
 			fscanf(in,"%s",board[i]);
 		}
 		fscanf(in,"%c",&awe);
 		cc = 0;
 		x = o = 0;
 		for(i = 0; i < 4; i++) {
 			for(j = 0; j < 4; j++) {
 				if(board[i][j] == 'X') {
 					x = check(i,j,'X');
 					if(x) break;
 				}
 				else if(board[i][j] == 'O') {
 					o = check(i,j,'O');
 					if(o) break;
 				}
 				else if(board[i][j] == '.') {
 					cc = 1;
 				}
 			}
 			if(x || o) {
 				break;
 			}
 		}
 		fprintf(out,"Case #%d: ",cs++);
 		if(x) {
 			fprintf(out,"X won\n");
 		}
 		else if(o) {
 			fprintf(out,"O won\n");
 		}
 		else if(cc) {
 			fprintf(out,"Game has not completed\n");
 		}
 		else{
 			fprintf(out,"Draw\n");
 		}
 
 	}
 	return 0;
 }

