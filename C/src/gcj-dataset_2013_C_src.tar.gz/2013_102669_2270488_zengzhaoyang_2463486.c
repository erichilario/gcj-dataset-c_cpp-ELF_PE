#include <stdio.h>
 #include <string.h>
 #include <math.h>
 int fan(int a);
 int main(){
     int t;
     scanf("%d",&t);
     getchar();
     int iiii;
     for(iiii=1;iiii<=t;iiii++){
         int n,m;
         scanf("%d %d",&n,&m);
         int i,j;
         int count=0;
         for(i=n;i<=m;i++){
             if(i==fan(i)){
                 j=sqrt(i);
                 if(j*j==i){
                     if(j==fan(j))
                         count++;
                 }
             }
         }
         printf("Case #%d: ",iiii);
         printf("%d\n",count);
     }
 }
 int fan(int a){
     int b[10];
     int k=0;
     while(a!=0){
         b[k++]=a%10;
         a/=10;
     }
     int i;
     int aa=1;
     int sum=0;
     for(i=k-1;i>=0;i--){
         sum+=b[i]*aa;
         aa*=10;
     }
     return sum;
 }
