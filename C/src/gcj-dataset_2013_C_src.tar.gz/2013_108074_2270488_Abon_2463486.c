#include <stdio.h>
 #include <math.h>
 
 int main(){
 	long long unsigned int n,T,A,B;
 	scanf("%llu",&n);
 
 	T=0;
 	long long unsigned int i,j,reversed,result;
 	while(++T<=n){
 		result=0;
 		scanf("%llu%llu", &A, &B);
 		//lets lower the range to sqrt(A) < x < sqrt(B)
 		B=sqrt(B);
 		i=sqrt(A);
 		if(i*i<A) ++i;
 		while(i<=B){
 			//check if i is an palindrome
 			j=i;
 			reversed=0;
 			do reversed=reversed*10+j%10; while(j/=10);
 			if(i==reversed){
 				//if so, check if i*i is also an palindrome
 				j=i*i;
 				reversed=0;
 				do reversed=reversed*10+j%10; while(j/=10);
 				if(i*i==reversed) ++result;
 						//printf("%llu - %llu\n", i, reversed);
 			}
 			++i;
 		}
 		printf("Case #%llu: %llu\n", T,result);
 	}
 return 0;
 }

