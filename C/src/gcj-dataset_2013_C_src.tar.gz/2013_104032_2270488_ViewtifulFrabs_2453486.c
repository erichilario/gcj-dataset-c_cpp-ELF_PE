#include <stdio.h>
 #include <string.h>
 #include <math.h>
 #include <stdlib.h>
 #define ARCHTXT "C:\\google code jam\\A-large.in"
 #define ARCHTXTOUT "C:\\google code jam\\output.txt"
 #define MAXLINEA 4
 
 short int extraer_matriz (int *matriz, int k)
 {int i=0,j;
 char cadena[25], cuadro[100]={'\0'};
 FILE *archlog;
 archlog=fopen(ARCHTXT,"rt");
 if(!archlog)
     {fclose(archlog);
     return 0;}
 else
     {fgets(cadena,10,archlog);
     if(k>0)
     {for(i=0;i<(k*5);i++)
         {fgets(cadena,10,archlog);}}
     for(i=0;i<4;i++)
         {fgets(cadena,10,archlog);
         if(i<3)
             {cadena[strlen(cadena)-1]='\0';}
         strcat(cuadro,cadena);}
 
     for(i=0;i<16;i++)
         {switch (cuadro[i])
             {case 'X':
                 {*(matriz+i)=1;
                 break;}
              case 'O':
                 {*(matriz+i)=2;
                 break;}
             case '.':
                 {*(matriz+i)=0;
                 break;}
             case 'T':
                 {*(matriz+i)=-1;
                 break;}
             default:
                 {fclose(archlog);
                 return 0;
                 break;}}}
     fclose(archlog);
     return 1;}
 }
 
 short int validar_ganador (int *ap)
 {int i,x;
 for(i=0;i<4;i++)
     {x=(*(ap+i))*(*(ap+i+4))*(*(ap+i+8))*(*(ap+i+12));
     if(x!=0)
         {if((x==1)||(x==-1))
             {return 1;}
         if((x==16)||(x==-8))
             {return 2;}}
     x=(*(ap+(i*4)))*(*(ap+(i*4)+1))*(*(ap+(i*4)+2))*(*(ap+(i*4)+3));
     if(x!=0)
         {if((x==1)||(x==-1))
             {return 1;}
         if((x==16)||(x==-8))
             {return 2;}}}
 x=((*ap)*(*(ap+5))*(*(ap+10))*(*(ap+15)));
 if(x!=0)
         {if((x==1)||(x==-1))
             {return 1;}
         if((x==16)||(x==-8))
             {return 2;}}
 x=*(ap+3)**(ap+6)**(ap+9)**(ap+12);
 if(x!=0)
         {if((x==1)||(x==-1))
             {return 1;}
         if((x==16)||(x==-8))
             {return 2;}}
 x=1;
 for(i=0;i<16;i++)
     {x*=*(ap+i);}
 if(x==0)
     {return 0;}
 else
     {return -1;}
 }
 
 short int obtener_encabezado(int *x)
 {char cadena[10];
 FILE *archlog;
 archlog=fopen(ARCHTXT,"rt");
 if(!archlog)
     {fclose(archlog);
     return 1;}
 else
     {fseek(archlog,0L,SEEK_SET);
     fgets(cadena,10,archlog);
     fclose(archlog);
     cadena[strlen(cadena)-1]='\0';
     *x=atoi(cadena);
     return 1;}}
 
 void main()
 {int matriz[4][4]={0},i,x,j,k;
 int *ap=&matriz[0][0];
 if(!obtener_encabezado(&k))
     {
         printf("\nERROR HEADER NOT FOUND");
     }
 else
     {FILE *archlog;
     archlog=fopen(ARCHTXTOUT,"wt");
     if(!archlog)
         {
          printf("ERROR CANT CREATE OUTPUT FILE");
         }
     else
     {
         for(j=0;j<k;j++)
             {if(!extraer_matriz(ap,j))
                 {
                     printf("\nERROR IN SQUARE %d",j);
                 }
             else
                 {fprintf(archlog,"Case #%d: ",j+1);
                 switch (validar_ganador(ap))
                     {case 1:
                         {fprintf(archlog,"X won");
                         break;}
                      case 2:
                         {fprintf(archlog,"O won");
                         break;}
                     case 0:
                         {fprintf(archlog,"Game has not completed");
                         break;}
                     case -1:
                         {fprintf(archlog,"Draw");
                         break;}}
                 fprintf(archlog,"\n");}}}
     fclose(archlog);}
 
 system("pause");}
 
 

