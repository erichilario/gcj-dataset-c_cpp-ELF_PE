#include <stdio.h>
 #include <string.h>
 #define MAX 4
 int dot;
 int row(char b[][MAX]){
 	int i, j, O, X, other;
 	for (i = 0; i < MAX; ++i){
 		O = X = other = 0;
 		for (j = 0; j < MAX; ++j){
 		    if (b[i][j] == 'X')
 				++X;
 			else if (b[i][j] == 'O')
 			    ++O;
 			else if (b[i][j] == 'T'){
 				++O;
 				++X;
 			}
 			else if (b[i][j] == '.'){
 				other = 1;
 				dot = 1;
 			    break;
 			}
 		}
 		if (other)
 		    continue;
 		else if (X == 4)
 		    return 1;
 		else if (O == 4)
 		    return 2;
 	}
 	return 0;
 }
 int column(char b[][MAX]){
 	int i, j, O, X, other;
 	for (i = 0; i < MAX; ++i){
 		O = X = other = 0;
 		for (j = 0; j < MAX; ++j){
 		    if (b[j][i] == 'X')
 				++X;
 			else if (b[j][i] == 'O')
 			    ++O;
 			else if (b[j][i] == 'T'){
 				++O;
 				++X;
 			}
 			else if (b[j][i] == '.'){
 				other = 1;
 			    break;
 			}
 		}
 		if (other)
 		    continue;
 		else if (X == 4)
 		    return 1;
 		else if (O == 4)
 		    return 2;
 	}
 	return 0;
 }
 int diagonal(char b[][MAX]){
     int i, O, X;
 	O = X = 0;
 	for (i = 0; i < MAX; ++i){
 		if (b[i][i] == 'X')
 			++X;
 		else if (b[i][i] == 'O')
 			++O;
 		else if (b[i][i] == 'T'){
 			++O;
 			++X;
 		}
 		else if (b[i][i] == '.')
 			break;
 	}
 	if (X == 4)
 		return 1;
 	else if (O == 4)
 		return 2;
     O = X = 0;
     for (i = 0; i < MAX; ++i){
 		if (b[MAX-i-1][i] == 'X')
 			++X;
 		else if (b[MAX-i-1][i] == 'O')
 			++O;
 		else if (b[MAX-i-1][i] == 'T'){
 			++O;
 			++X;
 		}
 		else if (b[MAX-i-1][i] == '.')
 			break;
 	}
 	if (X == 4)
 		return 1;
 	else if (O == 4)
 		return 2;
 	return 0;
 }
 int main()
 {
 	FILE *fp = fopen("A-large.in", "r");
 	FILE *out = fopen("A-large.out", "w");
 	int i , T, t, win;
 	char board[MAX][MAX];
 	fscanf(fp, "%d", &T);
 	t = T;
 	while (t--){
 		win = dot = 0;
 		for (i = 0; i < MAX; ++i)
 		    fscanf(fp, "%s", &board[i]);
 		win = row(board);
 		if (!win)
 		    win = column(board);
 		if (!win)
 		    win = diagonal(board);
 		if (win == 1)
 		    fprintf(out, "Case #%d: X won\n", T-t);
 		else if (win == 2)
 		     fprintf(out, "Case #%d: O won\n", T-t);
 		else if (dot)
 		     fprintf(out, "Case #%d: Game has not completed\n", T-t);
 		else fprintf(out, "Case #%d: Draw\n", T-t);
 	}
 	return 0;
 }

