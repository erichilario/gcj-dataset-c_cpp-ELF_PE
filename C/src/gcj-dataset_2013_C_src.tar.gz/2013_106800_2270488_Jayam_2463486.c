#include<stdio.h>
 //#define N 32
 int check(long long int n);
 int main()
 {
 	int t,T,f,g;
 	long long int a,b,i,j=0,count,ans[1000]={},N;
 	N=10000000;
 	for(i=1;i<N;i++)
 	{
 		f=0;
 		g=0;
 		f=check(i);
 		if(f==1)
 		{
 			g=check(i*i);
 			if(g==1)
 				ans[j++]=i*i;
 		}
 	}
 /*	for(i=0;i<j;i++)
 		printf("%lld ",ans[i]);
 	
 	printf("\n");
 */
 	scanf("%d",&T);
 	for(t=1;t<=T;t++)
 	{
 		count = 0;
 		scanf("%lld %lld",&a,&b);
 		for(i=0;i<j;i++)
 			if(ans[i]>=a)
 				break;
 
 		for(;i<j;i++)
 		{
 			if(ans[i]>b)
 				break;
 			count++;
 		}
 //		count--;
 		printf("Case #%d: %lld\n",t,count); 
 	}
 
 	return 0;
 }
 int check(long long int n)
 {
 	long long int a[16],i,j,m;
 	i=0;
 	while(n>0)
 	{
 		a[i]=n%10;
 		n=n/10;
 		i++;
 	}
 	if(i==2)
 		if(a[0]!=a[1])
 			return 0;
 
 	i--;
 	m=i;
 	for(j=0;j<=(m/2);j++,i--)
 		if(a[i]!=a[j])
 			return 0;
 
 	return 1;
 }

