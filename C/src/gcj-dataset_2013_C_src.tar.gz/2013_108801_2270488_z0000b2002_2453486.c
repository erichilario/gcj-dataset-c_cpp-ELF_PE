#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #define LEN 10
 #define STATE_OWIN 1
 #define STATE_XWIN 2
 #define STATE_DRAW 3
 #define STATE_NFIN 4
 
 int tc,tt;
 int nc,nt=4;
 char graph[LEN][LEN];
 int final_state;
 
 void check()
 {
   final_state=STATE_DRAW;
   int i,j;
   /**check O win**/
   for(i=1;i<=4;i++){
     for(j=1;j<=4;j++){
       if(!('O'==graph[i][j]||'T'==graph[i][j]))break;
     }
     if(5==j){
       final_state=STATE_OWIN;
       return;
     }
   }
   for(i=1;i<=4;i++){
     for(j=1;j<=4;j++){
       if(!('O'==graph[j][i]||'T'==graph[j][i]))break;
     }
     if(5==j){
       final_state=STATE_OWIN;
       return;
     }
   }
   for(i=1;i<=4;i++){
     if(!('O'==graph[i][i]||'T'==graph[i][i]))break;
   }
   if(5==i){
       final_state=STATE_OWIN;
       return;
     }
   for(i=1;i<=4;i++){
     if(!('O'==graph[5-i][i]||'T'==graph[5-i][i]))break;
   }
   if(5==i){
       final_state=STATE_OWIN;
       return;
     }
   /**check X win**/
   for(i=1;i<=4;i++){
     for(j=1;j<=4;j++){
       if(!('X'==graph[i][j]||'T'==graph[i][j]))break;
     }
     if(5==j){
       final_state=STATE_XWIN;
       return;
     }
   }
   for(i=1;i<=4;i++){
     for(j=1;j<=4;j++){
       if(!('X'==graph[j][i]||'T'==graph[j][i]))break;
     }
     if(5==j){
       final_state=STATE_XWIN;
       return;
     }
   }
   for(i=1;i<=4;i++){
     if(!('X'==graph[i][i]||'T'==graph[i][i]))break;
   }
   if(5==i){
       final_state=STATE_XWIN;
       return;
     }
   for(i=1;i<=4;i++){
     if(!('X'==graph[5-i][i]||'T'==graph[5-i][i]))break;
   }
   if(5==i){
       final_state=STATE_XWIN;
       return;
     }
   /**draw**/
   for(i=1;i<=4;i++){
     for(j=1;j<=4;j++){
       if('.'==graph[i][j]){
         final_state=STATE_NFIN;
         return;
       }
     }
   }
 }
 
 int main(void)
 {
   scanf("%d",&tt);
   for(tc=1;tc<=tt;++tc){
     memset(graph,0,sizeof(graph));
     for(nc=1;nc<=nt;++nc){
       scanf("%s",graph[nc]+1);
     }
     printf("Case #%d: ",tc);
     check();
     switch(final_state){
       case STATE_OWIN:{
         printf("O won\n");
         break;
       }
       case STATE_XWIN:{
         printf("X won\n");
         break;
       }
       case STATE_DRAW:{
         printf("Draw\n");
         break;
       }
       case STATE_NFIN:{
         printf("Game has not completed\n");
         break;
       }
     }
   }
   return 0;
 }

