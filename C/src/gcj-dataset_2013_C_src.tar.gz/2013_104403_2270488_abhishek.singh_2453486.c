#include <stdio.h>
 
 int checkrow(char s[4][4],int ch)
 {
 	int i,j,flag;
 	//printf("CHECKROW\n");
 	for(i=0;i<4;i++)
 	{
 		flag=0;
 		for(j=0;j<4;j++)
 		{
 			if (s[i][j]!='T' && s[i][j]!=ch)
 			{
 				flag=1;
 				//printf("\n s[%d][%d]=%c",i,j,s[i][j]);
 				//getchar();
 			}
 		}
 		if (flag==0)
 		{
 			//printf("Inside if\n");
 			return 1;
 			//printf("before break\n");			
 		}
 	}
 	return 0;
 }
 
 int checkcol(char s[4][4],int ch)
 {
 	int i,j,flag;
 	//printf("CHECKCOL\n");
 	//printf("ch=%c",ch);
 	for(i=0;i<4;i++)
 	{
 		flag=0;
 		for(j=0;j<4;j++)
 		{
 			if (s[j][i]!='T' && s[j][i]!=ch)
 			{
 				flag=1;
 			}
 		}
 		if (flag==0)
 		{
 			//printf("Inside if\n");
 			return 1;
 			//printf("before break\n");			
 		}
 	}
 	return 0;
 }
 
 int checkd(char s[4][4], char ch)
 {
 	int i,j,flag;
 	flag=0;
 	//printf("CHECKD\n");
 	for(i=0;i<4;i++)
 	{
 		if (s[i][i]!='T' && s[i][i]!=ch)
 		{
 			flag=1;
 		}
 		
 	}
 	
 	if (flag==0)
 	{
 		return 1;
 	}
 	flag=0;
 	for(i=0,j=3;i<4;i++,j--)
 	{
 		if (s[i][j]!='T' && s[i][j]!=ch)
 		{
 			flag=1;
 		}
 	}
 	
 	if (flag==0)
 	{
 		return 1;
 	}
 	return 0;
 }
 int checkfull(char s[4][4])
 {
 	int i,j,flag;
 	flag=0;	
 	//printf("CHECKFULL\n");
 	for(i=0;i<4;i++)
 	{
 		
 		for(j=0;j<4;j++)
 		{
 			if (s[i][j]=='.')
 			{
 				return 0;
 			}
 		}
 	}
 
 	return 1;
 }			
 	
 
 			
 int main()
 {
 	char s[4][4],res[1200][30];
 	int n,i,j;
 	char temp[20];
 	//printf("Enter the number of inputs.\n");
 	scanf("%d",&n);
 	for(i=0;i<n;i++)
 	{
 		//printf("Enter the status.\n");
 		for(j=0;j<4;j++)
 		{
 			scanf("%s",s[j]);
 		}
 		gets(temp);
 		//printf("iNPUT COMPLETED.\n");
 		if(checkrow(s,'X')==1)
 		{
 			//printf("CHECKROW X\n");
 			strcpy(res[i],"X won");
 		}
 		else if(checkrow(s,'O')==1)
 		{
 			//printf("chek row o\n");
 			strcpy(res[i],"O won");
 		}
 		else if(checkcol(s,'X')==1)
 		{
 			//printf("check col x\n");
 			strcpy(res[i],"X won");
 		}
 		else if(checkcol(s,'O')==1)
 		{
 			//printf("check col o\n");
 			strcpy(res[i],"O won");
 		}
 		else if(checkd(s,'X')==1)
 		{
 			//printf("check d x\n");
 			strcpy(res[i],"X won");
 		}
 		else if(checkd(s,'O')==1)
 		{
 			//printf("check d o\n");
 			strcpy(res[i],"O won");
 		}
 		else if(checkfull(s)==1)
 		{
 			//printf("check full\n");
 			strcpy(res[i],"Draw");
 		}
 		else
 		{
 			//printf("none \n");
 			strcpy(res[i],"Game has not completed");
 		}	
 	}
 	for(i=0;i<n;i++)
 	{
 		printf("Case #%d: %s\n",(i+1),res[i]);
 	}
 	return 0;
 }
 		
 	
 	

