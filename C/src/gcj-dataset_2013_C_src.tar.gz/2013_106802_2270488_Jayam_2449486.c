#include<stdio.h>
 int main()
 {
 int T,t,f;
 int a[101][101],lawn[101][101];
 int i,j,l,p,x,y;
 scanf("%d",&T);
 for(t=1;t<=T;t++)
 	{
 	f=0;
 	scanf("%d %d",&x,&y);
 
 	for(i=0;i<x;i++)
 		for(j=0;j<y;j++)
 			{scanf("%d",&a[i][j]);lawn[i][j]=0;}	
 	
 	for(i=0;i<x;i++)
 		{
 		for(j=0;j<y;j++)
 			{
 				p=a[i][j];
 				for(l=0;l<y;l++)
 				{
 					if(p<a[i][l])
 						break;
 				}
 				if(l==y)
 				{
 					for(l=0;l<y;l++)
 					{
 						if(p==a[i][l])
 							lawn[i][l]=1;
 					}
 				}
 				if(lawn[i][j]==1)
 					continue;
 					
 				p=a[i][j];
 				for(l=0;l<x;l++)
 				{
 					if(p<a[l][j])
 						break;
 				}
 				if(l==x)
 				{
 					for(l=0;l<x;l++)
 					{
 						if(p==a[l][j])
 							lawn[l][j]=1;
 					}	
 				}
 				if(lawn[i][j]==1)
 					continue;
 
 				if(lawn[i][j]==0)
 				{
 						i=x;
 						j=y;
 						f=1;
 				}
 			}
 		}
 
 		if(f==1)
 			printf("Case #%d: NO\n",t);	
 		else
 			printf("Case #%d: YES\n",t);
 	}
 	
 	return 0;
 }

