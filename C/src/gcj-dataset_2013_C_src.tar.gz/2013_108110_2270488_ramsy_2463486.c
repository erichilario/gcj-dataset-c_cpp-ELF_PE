#include<stdio.h>
 #include<math.h>
 #include<stdlib.h>
 int generate_pali(int a,int b);
 int is_pali(int num);
 int is_sqaure(int num);
 int main()
 {
 	int a,b,t,i,count;
 	FILE *fp_in,*fp_out;
 	fp_in=fopen("in_file.txt","r");
 	fp_out=fopen("out.txt","w");
 	fscanf(fp_in,"%d",&t);
 	for(i=0;i<t;i++)
 	{
 		fscanf(fp_in,"%d%d",&a,&b);
 		count=generate_pali(a,b);
 		fprintf(fp_out,"Case #%d: %d\n",i+1,count);
 	}
 	fclose(fp_in);
 	fclose(fp_out);
 	return 0;
 }
 
 int generate_pali(int a,int b)
 {
 	int n,flag1=0,flag2=0,flag3=0,count=0;
 	for(n=a;n<=b;n++)
 	{
 		flag1=is_pali(n);
 		if(flag1)
 		{
 			flag2=is_square(n);
 			if(flag2)
 			{
 				flag3=is_pali(flag2);
 				if(flag3)
 					count++;
 			}
 		}
 	}
 	return count;
 }
 
 int is_pali(int num)
 {
 	int rev=0,dig=0,num1=num;
 	while(num1!=0)
 	{
 		dig=num1%10;
 		rev=rev*10+dig;
 		num1=num1/10;	
 	}
 	if(rev==num)
 		return 1;
 	else
 		return 0;
 }
 
 int is_square(int num)
 {
 	float fnum=0.0;
 	int inum=0;
 	fnum=sqrt(num);
 	inum=fnum;
 	if(inum==fnum)
 		return inum;
 	else
 		return 0;
 }
 		
 	
 

