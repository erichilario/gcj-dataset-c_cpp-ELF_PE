#include <stdio.h>
 
 
 int main()
 {
   int T,t;
   int N,M;
   int board[100][100];
   int i,j,k;
   int lin, col; 
 
   scanf("%d", &T);
 
   for (t = 1; t < T+1; t++)
   {
     scanf("%d %d", &N, &M);
     for(i = 0; i < N; i++)
     {
       for(j = 0; j < M; j++)
       {
         scanf("%d",&board[i][j]);
       }
     }
 
     for (i = 0; i < N; i++)
     {
       for (j = 0; j < M; j++)
       {
         col = lin = 1;
         for (k = 0; k < N; k++)
         {
           if (board[k][j] > board[i][j])
             lin = 0;
         }
         for (k = 0; k < M; k++)
         {
           if (board[i][k] > board[i][j])
             col = 0;
         }
 
       if (!col && !lin)
         {
           printf("Case #%d: NO\n",t);
           goto quebra;
         }
 
       }
     }
     printf("Case #%d: YES\n",t);
 
     quebra:
       continue;
 
   }
   return 0;
 }
 

