#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #define MAX_NUM_LEN 15
 
 int is_palindrome (int num) {
 	char buffer[MAX_NUM_LEN];
 	sprintf (buffer, "%d", num);
 
 	int len = strlen (buffer);
 	int idx;
 	for (idx = 0; idx < len/2; ++idx)
 		if (buffer[idx] != buffer[len-1 - idx])
 			return 0;
 
 	if (idx >= len/2)
 		return 1;
 	
 	return 0;
 }
 
 int find_palindromes (const int a, const int b) {
 	int result = 0;
 	int bound_l = (int) sqrt (a);
 	int bound_h = (int) sqrt (b);
 
 	int num;
 	for (num = bound_l; num <= bound_h; ++num) {
 		if (is_palindrome (num))
 			if (num*num >= a && num*num <= b)
 				if (is_palindrome (num*num))
 					result++;
 	}
 
 	return result;
 }
 
 int main () {
 	int test_case;
 	
 	while (EOF != scanf ("%d", &test_case)) {
 		int idx_case;
 		for (idx_case = 1; idx_case <= test_case; ++idx_case) {
 			int a, b;
 			scanf ("%d %d\n", &a, &b);
 			int result = find_palindromes (a, b);
 
 			printf ("Case #%d: %d\n", idx_case, result);
 		}
 	}
 
 	return 0;
 }
 

