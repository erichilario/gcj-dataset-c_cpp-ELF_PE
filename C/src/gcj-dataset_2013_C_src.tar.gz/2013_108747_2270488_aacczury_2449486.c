#include <stdio.h>
 
 int cmp(const void *a, const void *b){
 	return *(int *)b-*(int *)a;
 }
 
 int main(){
 	int i,j,k,l;
 	int T,N,M;
 	int dashBoard[100][100];
 	int sortBoard[10000][3];
 	int check[100][100];
 	FILE *iFile, *oFile;
 	iFile = fopen ("B-small-attempt4.in","r");
 	oFile = fopen ("B-small-attempt4.out","w");
 	fscanf(iFile,"%d",&T);
 	for(k=0;k<T;++k){
 		fscanf(iFile,"%d%d",&N,&M);
 		for(i=0;i<N;++i)
 			for(j=0;j<M;++j)
 				check[i][j]=0;
 		for(i=0;i<N;++i)
 			for(j=0;j<M;++j){
 				fscanf(iFile,"%d",&dashBoard[i][j]);
 				sortBoard[i*M+j][0]=dashBoard[i][j];
 				sortBoard[i*M+j][1]=i;
 				sortBoard[i*M+j][2]=j;
 			}
 		qsort(sortBoard, N*M, sizeof(int)*3, cmp);
 		for(l=0;l<N*M;++l){
 			i=sortBoard[l][1];
 			for(j=0;j<M;++j)
 				if(dashBoard[i][j]>sortBoard[l][0])
 					break;
 			if(j==M)
 				check[sortBoard[l][1]][sortBoard[l][2]]=1;
 			i=sortBoard[l][2];
 			for(j=0;j<N;++j)
 				if(dashBoard[j][i]>sortBoard[l][0])
 					break;
 			if(j==N)
 				check[sortBoard[l][1]][sortBoard[l][2]]=1;
 		}
 		for(l=0;l<N*M;++l)
 			if(!check[l/M][l%M])
 				break;
 		if(l==N*M)
 			fprintf(oFile,"Case #%d: YES\n",k+1,N,M);
 		else 
 			fprintf(oFile,"Case #%d: NO\n",k+1,N,M);
 	}
 	return 0;
 }

