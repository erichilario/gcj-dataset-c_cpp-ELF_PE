#include<stdio.h>
 #include<math.h>
 #include<string.h>
 #include<stdlib.h>
 #include<memory.h>
 #include<malloc.h>
 #include<limits.h>
 #define ll long long
 #define ull unsigned long long
 #define max(a,b) (a)>(b)?(a):(b)
 #define min(a,b) (a)<(b)?(a):(b)
 int gcd(int a,int b){
 	return b?gcd(b,a%b):a;
 }
 ll a[6000],len;
 int palin(int x){
 	int ar[16],i=0,r,j=0,q=x;
 	while(x>0){
 		r=x%10;
 		ar[i++]=r;
 		x=x/10;
 	}
 	i--;
 	while(i>j){
 		if(ar[i]!=ar[j]) return 0;
 		i--;j++;
 	}
 	return 1;
 }
 void solve(){
 	int k=0;
 	ll p,i;
 	for(i=1;i<=10000000;i++){
 		p=i*i;
 		if(palin(i) && palin(p)) a[k++]=p;
 	}
 	len=k;
 }
 int search(ll x){
 	int l=0,r=len-1,mid;
 	while(l<r){
 		mid=(l+r)/2;
 		if(a[mid]==x) return mid;
 		else if(a[mid]>x){
 			r=mid-1;
 			if(a[r]<x) return r+1;
 		}
 		else{
 			l=mid+1;
 			if(a[l]>x) return l-1;
 		}
 	}
 	if(r<=0) return -1;
 	else return len-1;
 }
 int main()
 {
 	int t,k=1,i,j;
 	ll x,y;
 	solve();
 //	printf("len=%lld\n",len);
 //	for(i=0;i<4;i++) printf("%d : %lld\n",i,a[i]);
 	scanf("%d",&t);
 	while(t--){
 		scanf("%lld%lld",&x,&y);
 		printf("Case #%d: ",k);
 		k++;
 		i=search(x-1);
 		j=search(y);
 		printf("%d\n",j-i);
 	}
 	return 0;
 }

