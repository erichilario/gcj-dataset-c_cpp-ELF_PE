#include<stdio.h>
 
 int main()
 {
 int dot,flag,T,z,i,j,x,o;
 char garden[4][4];
 scanf("%d",&T);
 
 for(z=1;z<=T;z++)
 {getchar();
 
   flag=0;
   dot=0;
   
   for(i=0;i<4;i++)
   {
   	for(j=0;j<4;j++)
 	{
 	 garden[i][j]=getchar();	  
 	}
 	getchar();
   }
   
   for(i=0;i<4;i++)
   {
 	x=0;
 	o=0;
   	for(j=0;j<4;j++)
 	{
 	  if (garden[i][j]=='X')x++;
 	  else if (garden[i][j]=='O')o++;
 	  else if (garden[i][j]=='T'){x++;o++;}
 	  else dot=1;	  
 	}
 	
 	if(x==4){printf("Case #%d: X won\n",z);flag=1;break;}
 	else if (o==4){printf("Case #%d: O won\n",z);flag=1;break;}
 	
   }
    
   if(flag==1)continue;
   
     
   for(j=0;j<4;j++)
   {
 	x=0;
 	o=0;
   
 	for(i=0;i<4;i++)
 	{
 	  if (garden[i][j]=='X')x++;
 	  else if (garden[i][j]=='O')o++;
 	  else if (garden[i][j]=='T'){x++;o++;}
 	  	  
 	}
   if(x==4){printf("Case #%d: X won\n",z);flag=1;break;}
   else if (o==4){printf("Case #%d: O won\n",z);flag=1;break;}	
   }
   if(flag==1)continue;
   
   
   x=0;o=0;
   for(i=0;i<4;i++)
   {
 	if (garden[i][i]=='X')x++;
 	  else if (garden[i][i]=='O')o++;
 	  else if (garden[i][i]=='T'){x++;o++;}
 	  
   }
   if(x==4){printf("Case #%d: X won\n",z);continue;}
   else if (o==4){printf("Case #%d: O won\n",z);continue;}	
   
   x=0;o=0;
   for(i=0;i<4;i++)
   {
 	if (garden[i][3-i]=='X')x++;
 	  else if (garden[i][3-i]=='O')o++;
 	  else if (garden[i][3-i]=='T'){x++;o++;}
 	  
   }
   if(x==4){printf("Case #%d: X won\n",z);continue;}
   else if (o==4){printf("Case #%d: O won\n",z);continue;}	
   if(dot==1)printf("Case #%d: Game has not completed\n",z);
   else printf("Case #%d: Draw\n",z);
 }
 }
