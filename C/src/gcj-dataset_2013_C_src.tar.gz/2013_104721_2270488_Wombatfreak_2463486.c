#include <stdio.h>
 #include <stdlib.h>
 
 int pal(long long n) {
   int d[15],i,m;
   for(m=0;n>0;m++) {
     d[m]=n%10LL;
     n/=10LL;
   }
   for(i=0;i<m/2;i++) if(d[i]!=d[m-1-i]) return 0;
   return 1;
 }
 
 long long A[20000];
 
 int fcmp(const void *v1, const void *v2) {
   return A[*(int*)v1]-A[*(int*)v2];
 }
 
 int main() {
   int W, i,j,c;
   long long p;
   int ord[20000], ans[20000];
 
   scanf("%d", &W);
   for(i=0;i<W;i++) {
     scanf("%lld %lld", &A[2*i],&A[2*i+1]);
     A[2*i]--;
   }
   for(i=0;i<2*W;i++) ord[i]=i;
   qsort(ord,2*W,sizeof(int),fcmp);
   c=0;
   i=0;
   for(p=1;p<=10000000;p++) if(pal(p) && pal(p*p)) {
       while(i<2*W && A[ord[i]]<p*p) {
 	ans[ord[i]]=c;
 	i++;
       }
       c++;
     }
   while(i<2*W) {
     ans[ord[i]]=c;
     i++;
   }
   for(i=0;i<W;i++) {
     printf("Case #%d: %d\n",i+1,ans[2*i+1]-ans[2*i]);
   }
   return 0;
 }
     

