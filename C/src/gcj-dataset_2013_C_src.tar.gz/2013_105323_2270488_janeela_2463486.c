#include<stdio.h>
 #include<math.h>
 #include<stdlib.h>
 #define SIZE 14
 char numStringback[SIZE];
 char numString[SIZE];
 void makeString(int x);
 void copyNum();
 int isPalindrome();
 void initializeString();
 int main(){
     //C-small-attempt1.in
     //input.txt
     FILE* in = fopen("C-small-attempt4.in", "r");
     FILE* out= fopen("output.txt", "w");
     
     int T, hi, low, i, j, p, count=0, num=0, sqnum, newnum;
     fscanf(in, "%d", &T);
     double sq, rem;
     for(i = 0; i<T; i++){
                 fscanf(in, "%d %d", &low, &hi);
                 count=0;
                 for(p =low; p<=hi; p++){
                       num=p;
                       initializeString();  
                       makeString(num);
                       copyNum();
                       sq = sqrt(num);
                       rem = fmod(sq, floor(sq));
                       if(isPalindrome() && rem==0){
                                         initializeString(); 
                                         sqnum = (int)sq ; 
                                         makeString(sqnum);
                                         copyNum();
                                         if(isPalindrome()){
                                                  count++; 
                                                     
                                         }
                                                                                              
                       }                   
                 }
               
                  fprintf(out, "Case #%d: %d\n", i+1, count);
                  }
                  system("pause");
                  return 0;
 }
 
 
 
 void initializeString(){
      int i;
      for(i=0; i<SIZE; i++){
               numStringback[i] = '-';
               numString[i] = '-';
      }     
      
 }
 void makeString(int x){
      int i=0, n, num;
      n = x;
      while( n >0){
               num = n%10;
               n = n/10;
               numStringback[i] = num + '0';  
               i++;           
      }   
 }
 
 void copyNum(){
      int i, j=0;;
      
      for(i =SIZE-1; i>=0; i--){
            if(numStringback[i] != '-'){
                                numString[j]=numStringback[i];
                                j++;
            }
 
      }
 }     
      
 int isPalindrome(){
     
     int i;
     for(i = 0; i <strlen(numString); i++){
           if(numStringback[i] != numString[i])return 0;
     }
     return 1;    
 }

