#include <stdio.h>
 #define max 1001
 #define ull unsigned long long
 //#define max 100000000000001;
 int ans[max] = {0};
 int awe[max] = {0};
 int check(ull a)
 {
 	char str[20];
 	int len = 0;
 	while(a) {
 		str[len++] = a%10+'0';
 		a /= 10;
 	}
 	len--;
 	int k = 0;
 	int n = len/2;
 	while(k <= n) {
 		if(str[k] != str[len-k]) {
 			return 0;
 		}
 		k++;
 	}
 }
 void pre()
 {
 	int i = 1;
 	while(i*i < max) {
 		if(check(i) && check(i*i)) {
 			awe[i*i]++;
 		}
 		i++;
 	}
 	for(i = 0; i < max; i++) {
 		ans[i] = ans[i-1]+awe[i];
 	}
 }
 int main()
 {
 	int t;
 	int a,b;
 	int cs = 1;
 	pre();
 	FILE *in,*out;
 
 	in = fopen("c.in","r");
 	out = fopen("c.out","w");
 	fscanf(in,"%d",&t);
 	while (t--) {
 		fscanf(in,"%d%d",&a,&b);
 		fprintf(out,"Case #%d: ",cs++);
 		fprintf(out,"%d\n",ans[b]-ans[a-1]);
 	}
 	fclose(in);
 	fclose(out);
 	return 0;
 }

