#include <stdio.h>
 #include <stdlib.h>
 
 int test, i, flag, n, m, lawn[105][105], j, k, graph[105][105], c1, c2,maxm, cx ,cy;
 char line1[10], line2[10], line3[10], line4[10],temp[1000];
 
 void dfs(int x, int y, int num) {
 
     if(x == 0 || x == n-1 || y == 0 || y == m-1) {
         graph[cx][cy] = 1000;
         return;
     }
 
     graph[x][y] += 1;
 
     if(y + 1 < m)
         if(lawn[x][y+1] <= num &&  !(graph[x+1][y]%10 == 1)) {
             dfs(x, y+1, num);
         }
     if(graph[cx][cy] == 1000)
         return;
     if(x + 1 < n)
         if(lawn[x + 1][y] <= num &&  !(graph[x+1][y]%10 == 1))
             dfs(x+1, y, num);
     if(graph[cx][cy] == 1000)
         return;
     if(y - 1 >= 0 )
         if(lawn[x][y-1] <= num &&  !(graph[x][y-1]%10 ==1))
             dfs(x, y -1, num);
     if(graph[cx][cy] == 1000)
         return;
     if(x -1 >= 0)
         if(lawn[x-1][y] <= num &&  !(graph[x-1][y]%10 == 1))
             dfs(x-1, y, num);
 
 }
 
 int main()
 {
 
     FILE *ifp, *ofp;
     ifp=fopen("problem_b.in", "r");
     ofp=fopen("problem_b.out", "w");
     scanf("%d",&test);
     //fscanf(ifp,"%d",&test);
     for(i = 1; i <= test; i++) {
         flag = 1;
         maxm = 0;
         scanf("%d %d", &n, &m);
 
         for(j = 0; j < n; j++) {
 
             for(k = 0; k < m; k++) {
                 graph[j][k] = 0;
                 scanf("%d", &lawn[j][k]);
                 if(lawn[j][k] > maxm)
                     maxm = lawn[j][k];
             }
 
         }
 
         if(n > 2 && m > 2) {
             /*
             for(j = 0; j < m; j++) {
                 //if(graph[0][j] != 1000)
                 {
                     dfs(0,j, lawn[0][j]);
                     for(c1 = 0; c1 < n; c1++) {
                         for(c2 = 0; c2 < m; c2++) {
                             if(graph[c1][c2] % 10 ==1)
                                 graph[c1][c2] -= 1;
                         }
                     }
                 }
             }
 
             for(j = 0; j < m; j++) {
                 //if(graph[n-1][j] != 1000)
                 {
                     dfs(n-1,j, lawn[n-1][j]);
                     for(c1 = 0; c1 < n; c1++) {
                         for(c2 = 0; c2 < m; c2++) {
                             if(graph[c1][c2] % 10 ==1)
                                 graph[c1][c2] -= 1;
                         }
                     }
                 }
             }
 
             for(j = 1; j < n-1; j++) {
                 //if(graph[j][0] != 1000)
                 {
                     dfs(j,0, lawn[j][0]);
                     for(c1 = 0; c1 < n; c1++) {
                         for(c2 = 0; c2 < m; c2++) {
                             if(graph[c1][c2] % 10 ==1)
                                 graph[c1][c2] -= 1;
                         }
                     }
                 }
             }
 
             for(j = 1; j < n-1; j++) {
                 //if(graph[j][m-1] != 1000)
                 {
                     dfs(j,m-1, lawn[j][m-1]);
                     for(c1 = 0; c1 < n; c1++) {
                         for(c2 = 0; c2 < m; c2++) {
                             if(graph[c1][c2] % 10 ==1)
                                 graph[c1][c2] -= 1;
                         }
                     }
                 }
             }
 
             /*
             for(j = 0; j < n; j++) {
                 for(k = 0; k < m; k++) {
                     if(graph[j][k] != 1000) {
                         dfs(j,k, lawn[j][k]);
                         for(c1 = 0; c1 < n; c1++) {
                             for(c2 = 0; c2 < m; c2++) {
                                 if(graph[c1][c2] % 10 ==1)
                                     graph[c1][c2] -= 1;
                             }
                         }
                     }
                 }
             }
             */
             for(j = 0; j < n; j++) {
                 for(k = 0; k < m; k++) {
                     cx = j;
                     cy = k;
                     dfs(j,k,lawn[j][k]);
                     for(c1 = 0; c1 < n; c1++) {
                         for(c2 = 0; c2 < m; c2++) {
                             if(graph[c1][c2] % 10 ==1)
                                 graph[c1][c2] -= 1;
                         }
                     }
                 }
             }
             for(j = 0; j < n; j++) {
                 for(k = 0; k < m; k++) {
                         //printf("%6d", graph[j][k]);
                     if(graph[j][k] == 0 && lawn[j][k] < maxm)
                     {
                         flag = 0;
                         break;
                     }
                 }
                 //printf("\n");
                 if(flag == 0)
                     break;
             }
         }
 
         if(flag == 1)
             fprintf(ofp,"Case #%d: YES\n", i);
             //printf("Case #%d: YES\n", i);
         else
             fprintf(ofp,"Case #%d: NO\n", i);
             //printf("Case #%d: NO\n", i);
 
     }
 
     return 0;
 }

