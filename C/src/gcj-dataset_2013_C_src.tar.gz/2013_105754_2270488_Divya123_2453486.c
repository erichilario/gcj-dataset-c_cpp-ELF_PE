#include<stdio.h>
 int main()
 {int t,j,k,i;
 scanf("%d",&t);
 scanf("\n");
 for(i=0;i<t;i++)
 {
 int fl=0;
 char A[4][4];
 char l;
 for(j=0;j<4;j++)
 { for(k=0;k<4;k++)
 {  scanf("%c",&A[j][k]);
 //   printf("222222%c %d %d\n",A[j][k],j,k);
   if(A[j][k]=='.') fl=7;
 }
 scanf("%c",&l);
 }
 scanf("%c",&l);
 int r[4][3],c[4][3],d[4][3];
 for(j=0;j<4;j++)
 {  for(k=0;k<3;k++)
 { r[j][k]=0; c[j][k]=0;
   d[j][k]=0;}}
 for(j=0;j<4;j++)
   { for(k=0;k<4;k++)
       {//printf("oooo%c %d %d\n",A[j][k],j,k);
 if(A[j][k]=='X') {r[j][0]++;  c[k][0]++; if(j ==k) d[0][0]++; if(j == 4-k) d[1][0]++;}
         else if(A[j][k]=='O') {r[j][1]++; c[k][1]++; if(j ==k) d[0][1]++; if(j == 3-k) d[1][1]++;}
         else if(A[j][k]=='T') {r[j][2]++; c[k][2]++; if(j ==k) d[0][2]++; if(j == 3-k) d[1][2]++;}
        
      }
   }
 //for(j=0;j<2;j++)
 //{  printf("r%d %d %d\n",d[j][0],d[j][1],d[j][2]);
  //printf("c%d %d %d\n",c[j][0],c[j][1],c[j][2]);
 //}
 for(j=0;j<4;j++) 
 { if((r[j][2]==1 && r[j][0]==3 )|| r[j][0]==4)
                {   fl=1; break;}
   else if((r[j][2]==1 && r[j][1]==3) || r[j][1]==4)
               {fl=4; break;}
  if((c[j][2]==1 && c[j][0]==3 )|| c[j][0]==4)
                {   fl=1; break;}
   else if((c[j][2]==1 && c[j][1]==3) || c[j][1]==4)
               {fl=4; break;}
 if(j<2){
 if((d[j][2]==1 && d[j][0]==3 )|| d[j][0]==4)
                {   fl=1; break;}
   else if((d[j][2]==1 && d[j][1]==3) || d[j][1]==4)
               {fl=4; break;}
 
 }
 }
 if(fl == 0) fl=2;
 else if(fl == 7) fl =3;
 printf("Case #%d: ",i+1);
 if(fl == 1) printf("X won\n");
 else if(fl == 2) printf("Draw\n");
 else if(fl == 3) printf("Game has not completed\n");
 else printf("O won\n");
 }
 return 0;
 }

