#include<stdio.h>
 #include<string.h>
 #include<conio.h>
 
 int main()
 {
     int test;
     int i,j,k,n,m;
     char ch;
     char str[500];
     freopen("B-small-attempt1","r",stdin);
     freopen("out.txt","w",stdout);
   //  scanf("%d",&test);
    // printf("%d",test);
     test=50;
     for(i=1;i<=test;i++)
     {
                         m=0;
                         n=0;
                        // printf("%d",i);
     char str[500];
     
     scanf("%d%c%d",&m,&ch,&n);
    // printf("%d%c%d",m,ch,n);
    // if((m>0)&&(n>0))
 j=0;   
                     str[j]='E';
                     str[j+1]='N';
                     str[j+2]='W';
                     str[j+3]='S';
                     j=j+4;
 
     printf("Case #%d: %s\n",i,str);
     }
     return 0;    
 }

