#include<stdio.h>
 #define N 4
 int check(char a[4][4]);
 int main()
 {
 	int T,t,i,j,k,f;
 	char a[4][4],nl[2];
 	FILE *fin;
 	fin=fopen("in.txt","r");
 	
 	scanf("%d",&T);
 	gets(nl);
 	for(t=1;t<=T;t++)
 	{
 		f=0;
 		for(i=0;i<4;i++)
 		{	
 			gets(a[i]);
 		}
 		gets(nl);
 		f=check(a);
 		
 		if(f==1)
 			printf("Case #%d: X won\n",t);
 		else if(f==2)
 			printf("Case #%d: O won\n",t);
 		else if(f==3)
 			printf("Case #%d: Game has not completed\n",t);
 		else if(f==4)
 			printf("Case #%d: Draw\n",t);
 /*		
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 				printf("%c",a[i][j]);
 			printf("\n");
 		}
 		printf("\n");
 */
 /*		printf("%c %c %c %c\n",a[0][0],a[0][1],a[0][2],a[0][3]);
 		printf("%c %c %c %c\n",a[1][0],a[1][1],a[1][2],a[1][3]);
 		printf("%c %c %c %c\n",a[2][0],a[2][1],a[2][2],a[2][3]);
 		printf("%c %c %c %c\n",a[3][0],a[3][1],a[3][2],a[3][3]);
 		printf("%c %c %c %c\n",a[0][5],a[1][5],a[2][5],a[3][5]);
 */		
 	}
 	return 0;
 }
 int check(char a[4][4])
 {
 	int i,j,k,f=0;
 
 
 		if(a[0][0]=='X')
 		{
 			for(i=1;i<4;i++)
 				if(a[i][i]!='X' && a[i][i]!='T')
 					break;
 			if(i==4)
 				return 1;
 		}
 		if(a[0][0]=='O')
 		{
 			for(i=1;i<4;i++)
 				if(a[i][i]!='O' && a[i][i]!='T')
 					break;
 			if(i==4)
 				return 2;
 		}
 		if(a[0][3]=='X')
 		{
 			for(i=1,j=2;i<4;i++,j--)
 				if(a[i][j]!='X' && a[i][j]!='T')
 					break;
 			if(i==4)
 				return 1;
 		}
 		if(a[0][3]=='O')
 		{
 			for(i=1,j=2;i<4;i++,j--)
 				if(a[i][j]!='O' && a[i][j]!='T')
 					break;
 			if(i==4)
 				return 2;
 		}
 		
 	for(i=0;i<4;i++)
 	{
 //		printf("%c \n",a[i][0]);
 		if(a[i][0]=='X')
 		{
 			for(j=1;j<4;j++)
 				if(a[i][j]!='X' && a[i][j]!='T')
 					break;
 			if(j==4)
 				return 1;
 			else
 				continue;
 		}
 		
 		if(a[i][0]=='O')
 		{
 			for(j=1;j<4;j++)
 				if(a[i][j]!='O' && a[i][j]!='T')
 					break;
 			if(j==4)
 				return 2;
 			else
 				continue;
 		}
 	}
 	
 	for(j=0;j<4;j++)
 	{
 		if(a[0][j]=='X')
 		{
 			for(i=1;i<4;i++)
 				if(a[i][j]!='X' && a[i][j]!='T')
 					break;
 			
 			if(i==4)
 				return 1;
 			else
 				continue;
 		}
 		
 		if(a[0][j]=='O')
 		{
 			for(i=1;i<4;i++)
 				if(a[i][j]!='O' && a[i][j]!='T')
 					break;
 			if(i==4)
 				return 2;
 			else
 				continue;
 		}
 	}
 	f=0;
 	for(i=0;i<4;i++)
 	{
 		for(j=0;j<4;j++)
 			if(a[i][j]=='.')
 				{f=1;break;}
 	}
 	if(f==1)
 		return 3;
 	else
 		return 4;
 }

