#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 #include <string.h>
 
 int digitos(int n){
     int d, a;
     d=1;
     a=pow(10,d);
     while(n-a>0){
         d++;
         a=pow(10,d);
     }
     return d;
 }
 
 int palindromo(int n){
     int dez, x=n;
     int i, d = digitos(n);
     int s[d], inv[d];
 
     for(i=0; i<d; i++){
         dez = pow(10,i+1);
         s[i]=x%dez;
         inv[d-1-i]=x%dez;
         x = n/dez;
     }
 
     for(i=0; i<d; i++){
         if(s[i]!=inv[i])
             return 0;
     }
     return 1;
 }
 
 int inteiro(double n){
     if(fmod(n,1)==0)
         return 1;
     return 0;
 }
 
 void imprime(int i, int p){
 printf("Case #%d: %d\n", i, p);
 }
 
 int main(){
 
 int T, A, B, i, j;
 int n, a1, b1, x1, p1, p2;
 double x, a, b;
 
 scanf("%d\n", &T);
 
 for(i=0; i<T; i++){
     scanf("%d %d\n", &A, &B);
     n = 0;
 
     a = sqrt(A);
     b = sqrt(B);
 
     if(!inteiro(a))
         a = ceil(a);
     if(!inteiro(b))
         b = floor(b);
     a1 = a;
     b1 = b;
 
     for(j=a1; j<=(b1); j++){
         p1 = palindromo(j);
         if(p1){
             x = pow(j,2);
             x1=x;
             p2 = palindromo(x1);
             if(p2)
                 n++;
         }
     }
     imprime(i+1, n);
 }
 return 0;
 }

