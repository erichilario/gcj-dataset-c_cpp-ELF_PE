#include <stdio.h>
 
 int main(){
 	int T,i,j,k;
 	int dashBoard[4][4];
 	char tc;
 	int check,win,draw;
 	FILE *iFile, *oFile;
 	iFile = fopen ("A-small-attempt1.in" , "r");
 	oFile = fopen ("A-small-attempt1.out" , "w");
 	fscanf(iFile,"%d",&T);
 	for(k=0;k<T;++k){
 		win = 0;
 		draw = 0;
 		for(i=0;i<4;++i){
 			fscanf(iFile,"%c",&tc);
 			for(j=0;j<4;++j){
 				fscanf(iFile,"%c",&tc);
 				if(tc=='X')
 					dashBoard[i][j]=1;
 				else if(tc=='O')
 					dashBoard[i][j]=2;
 				else if(tc=='T')
 					dashBoard[i][j]=3;
 				else if(tc=='.'){
 					dashBoard[i][j]=0;
 					draw --;
 				}
 			}
 		}
 		for(i=0;i<4;++i){
 			if(dashBoard[i][0]&&!win){
 				check = dashBoard[i][0];
 				win = check;
 				for(j=1;j<4;++j)
 					if(dashBoard[i][j]!=3&&dashBoard[i][j]!=check)
 						win = 0;
 			}
 		}
 		for(i=0;i<4;++i){
 			if(dashBoard[0][i]&&!win){
 				check = dashBoard[0][i];
 				win = check;
 				for(j=1;j<4;++j)
 					if(dashBoard[j][i]!=3&&dashBoard[j][i]!=check)
 						win = 0;
 			}
 		}
 		if(!win)
 			for(i=0;i<4;++i){
 				if(!i){
 					check = dashBoard[i][i];
 					win = check;
 				}
 				else
 					if(dashBoard[i][i]!=3&&dashBoard[i][i]!=check)
 							win = 0;
 			}
 		if(!win)
 			for(i=0;i<4;++i){
 				if(!i){
 					check = dashBoard[i][3-i];
 					win = check;
 				}
 				else
 					if(dashBoard[i][3-i]!=3&&dashBoard[i][3-i]!=check)
 							win = 0;
 			}
 		if(!win&&!draw)
 			fprintf(oFile,"Case #%d: Draw\n",k+1);
 		else if(!win)
 			fprintf(oFile,"Case #%d: Game has not completed\n",k+1);
 		else if(win == 1)
 			fprintf(oFile,"Case #%d: X won\n",k+1);
 		else if(win == 2)
 			fprintf(oFile,"Case #%d: O won\n",k+1);
 		fscanf(iFile,"%c",&tc);
 			
 	}
 	return 0;
 }

