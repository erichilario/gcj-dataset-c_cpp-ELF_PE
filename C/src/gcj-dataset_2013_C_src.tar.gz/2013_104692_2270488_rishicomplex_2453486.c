#include <stdio.h>
 int fir, sr, tr, fr, fic, sc, tc, fc, tlbr, bltr;
 char arr[4][4];
 
 
 void printResult(int result) {
     switch(result) {
         case 0 : printf("O won\n"); break;
         case 1 : printf("X won\n"); break;
         case 2 : printf("Game has not completed\n"); break;
         case 3 : printf("Draw\n"); break;
     }
 }
 
 void work(int ind) {
     fir = sr = tr = fr = fic = sc = tc = fc = tlbr = bltr = -2;
     int incomp_flag = 0, result = -1;
     printf("Case #%d: ", ind);
     int i, j;
     for(i = 0; i < 4; i++) {
         scanf("%s", arr[i]);
     }
     char temp = 'T';
     //check for rows
     for(i = 0; i < 4; i++) {
 
         temp = 'T';
         for(j = 0; j < 4; j++) {
             if(arr[i][j] == 'T') {
                 continue;
             }
             else if(arr[i][j] == '.') {
                 incomp_flag = 1;
                 break;
             }
             else if(temp == 'T') {
                 temp = arr[i][j];
             }
             else if(temp == arr[i][j]) {
                 continue;
             }
             else {
                 break;
             }
         }
         if(j == 4) {
             result = temp == 'O' ? 0 : 1;
             break;
         }
     }
     if(result != -1) {
         printResult(result);
         return;
     }
 
     //check columns
 
     for(i = 0; i < 4; i++) {
         temp = 'T';
         for(j = 0; j < 4; j++) {
             if(arr[j][i] == 'T') {
                 continue;
             }
             else if(arr[j][i] == '.') {
                 incomp_flag = 1;
                 break;
             }
             else if(temp == 'T') {
                 temp = arr[j][i];
             }
             else if(temp == arr[j][i]) {
                 continue;
             }
             else {
                 break;
             }
         }
         if(j == 4) {
             result = temp == 'O' ? 0 : 1;
             break;
         }
     }
     if(result != -1) {
         printResult(result);
         return;
     }
 
     //check diagonals
     temp = 'T';
     for(i = 0; i < 4; i++) {
         if(arr[i][i] == 'T') {
             continue;
         }
         else if(arr[i][i] == '.') {
             incomp_flag = 1;
             break;
         }
         else if(temp == 'T') {
             temp = arr[i][i];
         }
         else if(temp == arr[i][i]) {
             continue;
         }
         else {
             break;
         }
     }
     if(i == 4) {
         result = temp == 'O' ? 0 : 1;
         printResult(result);
         return;
     }
 
     temp = 'T';
     for(i = 0; i < 4; i++) {
         if(arr[i][3 - i] == 'T') {
             continue;
         }
         else if(arr[i][3 - i] == '.') {
             incomp_flag = 1;
             break;
         }
         else if(temp == 'T') {
             temp = arr[i][3 - i];
         }
         else if(temp == arr[i][3 - i]) {
             continue;
         }
         else {
             break;
         }
     }
     if(i == 4) {
         result = temp == 'O' ? 0 : 1;
         printResult(result);
         return;
     }
 
 
     if(incomp_flag) {
         printResult(2);
     }
     else {
         printResult(3);
     }
 }
 
 
 
 int main() {
     int T;
     scanf("%d", &T);
     int i;
     for(i = 1; i <= T; i++) {
         work(i);
     }
     return 0;
 }

