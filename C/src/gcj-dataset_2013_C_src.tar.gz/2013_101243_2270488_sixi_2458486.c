#include <stdio.h>
 #include <iostream>
 #include <set>
 #include <map>
 #include <vector>
 
 using namespace std;
 
 int K, N;
 int fit_key[201];
 bool is_open[201];
 multiset<int> my_key;
 multiset<int>::iterator my_key_iter;
 map<int, vector<int> > boxes;
 map<int, vector<int> >::iterator boxes_iter;
 vector<int> keys;
 vector<int>::iterator keys_iter;
 vector<int> result;
 int have[201];
 int need[201];
 
 void PrintResult(int index) {
     printf("Case #%d:", index);
     for (keys_iter = result.begin(); keys_iter != result.end(); keys_iter++) {
         printf(" %d", *keys_iter);
     }
     printf("\n");
 }
 
 bool IsWay() {
     int i;
     multiset<int> tmp;
     for (i = 1; i <= N; ++i) {
         if (!is_open[i]) {
             tmp.insert(fit_key[i]);
         }
     }
     for (i = 1; i <= N; ++i) {
         if (!is_open[i] && tmp.count(fit_key[i]) == 1) {
             my_key_iter = my_key.find(fit_key[i]);
             if (my_key_iter == my_key.end()) {
                 int count = 0;
                 keys = (boxes.find(i))->second;
                 for (keys_iter = keys.begin(); keys_iter != keys.end(); keys_iter++) {
                     if (*keys_iter == fit_key[i])
                         ++count;
                 }
                 if (have[fit_key[i]] - count < need[fit_key[i]]) {
                     return false;
                 }
             }
         }
     }
     return true;
 }
 
 bool Check(int step) {
     if (step == N + 1) {
         return true;
     }
     if (my_key.size() == 0) {
         return false;
     }
     int i;
     for (i = 1; i <= N; ++i) {
         if (!is_open[i]) {
             my_key_iter = my_key.find(fit_key[i]);
             if (my_key_iter != my_key.end()) {
                 my_key.erase(my_key_iter);
                 is_open[i] = true;
                 keys = (boxes.find(i))->second;
                 for (keys_iter = keys.begin(); keys_iter != keys.end(); keys_iter++) {
                     my_key.insert(*keys_iter);
                 }
                 result.push_back(i);
                 have[fit_key[i]] -= 1;
                 need[fit_key[i]] -= 1;
 
                 //PrintResult(i);
                 if (IsWay() && Check(step + 1))
                     return true;
 
                 have[fit_key[i]] += 1;
                 need[fit_key[i]] += 1;
                 result.pop_back();
                 keys = (boxes.find(i))->second;
                 for (keys_iter = keys.begin(); keys_iter != keys.end(); keys_iter++) {
                     my_key.erase(my_key.find(*keys_iter));
                 }
                 is_open[i] = false;
                 my_key.insert(fit_key[i]);
             }
         }
     }
 
     return false;
 }
 
 void init() {
     my_key.clear();
     boxes.clear();
     result.clear();
     memset(have, 0, sizeof(have));
     memset(need, 0, sizeof(need));
 }
 
 bool IsValid() {
     int i;
     for (i = 1; i <= 200; ++i) {
         if (have[i] < need[i])
             return false;
     }
     return true;
 }
 
 int main() {
     freopen("D-small-attempt2.in", "r", stdin);
     freopen("D-small-attempt2.out", "w", stdout);
 
     int T, index, i, j, key, key_number;
     scanf("%d", &T);
     for (index = 1; index <= T; ++index) {
         
         init();
 
         scanf("%d %d", &K, &N);
 
         for (i = 1; i <= K; ++i) {
             scanf("%d", &key);
             my_key.insert(key);
             have[key] += 1;
         }
 
         for (i = 1; i <= N; ++i) {
             scanf("%d", &fit_key[i]);
             need[fit_key[i]] += 1;
             is_open[i] = false;
             scanf("%d", &key_number);
             vector<int> keys;
             for (j = 1; j <= key_number; ++j) {
                 scanf("%d", &key);
                 have[key] += 1;
                 keys.push_back(key);
             }
             boxes.insert(pair<int, vector<int> >(i, keys));
         }
 
 
         if (IsValid() && Check(1)) {
             PrintResult(index);
         } else {
             printf("Case #%d: IMPOSSIBLE\n", index);
         }
     }
 
     fclose(stdout);
     fclose(stdin);
 }

