#include <stdio.h>
 
 int main()
 {
   char board[4][4];
   int T,t;
   int i,j;
   int x,o,vazio;
 
   int eq(char a, char b)
   {
     if (a == 'T' || b == 'T')
       return 1;
     return a == b;
   }
 
 
   scanf("%d\n", &T);
   for(t = 1; t < T+1; t++)
   {
     vazio = 0;
     for (i = 0; i<4; i++)
     {
       for (j = 0; j<4; j++)
       {
         scanf(" %c", &board[i][j]);
         if (board[i][j]=='.')
           vazio = 1;
       }
     }
 
     //linhas
     for (i = 0; i<4; i++)
     {
       x = 1;
       o = 1;
       for (j = 0; j<4; j++)
       {
         x = x && eq('X', board[i][j]);
         o = o && eq('O', board[i][j]);
       }
       if (x)
       {
         break;
       }
       if (o)
       {
         break;
       }
     }
     if (x)
     {
       printf("Case #%d: X won\n",t);
       continue;
     }
     if (o)
     {
       printf("Case #%d: O won\n",t);
       continue;
     }
  
     //colunas
     for (i = 0; i<4; i++)
     {
       x = 1;
       o = 1;
       for (j = 0; j<4; j++)
       {
         x = x && eq('X', board[j][i]);
         o = o && eq('O', board[j][i]);
       }
       if (x)
       {
         break;
       }
       if (o)
       {
         break;
       }
     }
     if (x)
     {
       printf("Case #%d: X won\n",t);
       continue;
     }
     if (o)
     {
       printf("Case #%d: O won\n",t);
       continue;
     }
 
     //diagonais
     x = 1;
     o = 1;
     for (i = 0; i<4; i++)
     {
       x = x && eq('X', board[i][i]);
       o = o && eq('O', board[i][i]);
     }
     if (x)
     {
       printf("Case #%d: X won\n",t);
       continue;
     }
     if (o)
     {
       printf("Case #%d: O won\n",t);
       continue;
     }
 
     x = 1;
     o = 1;
     for (i = 0; i<4; i++)
     {
       x = x && eq('X', board[i][4-i-1]);
       o = o && eq('O', board[i][4-i-1]);
     }
     if (x)
     {
       printf("Case #%d: X won\n",t);
       continue;
     }
     if (o)
     {
       printf("Case #%d: O won\n",t);
       continue;
     }
 
   
     if (vazio)
     {
       printf("Case #%d: Game has not completed\n",t);
     }
     else
     {
       printf("Case #%d: Draw\n",t);
     }
  }
   
 
   return 0;
 }

