# include <stdio.h>
 # include <stdlib.h>
 
 int arr[]={1,4,9,121,484};
 int main(){
 	int cas,tc,count,i,a,b;
 	scanf("%d",&cas);
 	for(tc=1;tc<=cas;tc++){
 		count =0;
 		scanf("%d %d",&a,&b);
 		for(i=0;i<5;i++)
 			if(arr[i]>=a && arr[i]<=b)
 				count++;
 		printf("Case #%d: %d\n",tc,count);
 	}
 	return 0;
 }

