#include<stdio.h>
 
 int main()
 {
 	int t,a,b,matrix[5],i,k=0,counter;
 	scanf("%d",&t);
 	matrix[0] = 1;
 	matrix[1] = 4;
 	matrix[2] = 9;
 	matrix[3] = 121;
 	matrix[4] = 484;
 	
 	
 	while(t--)
 	{
 		counter=0;
 		k++;
 		scanf("%d %d",&a,&b);
 		for(i=0;i<5;i++)
 			if((a <= matrix[i]) && (b >= matrix[i]))
 				counter++;
 		printf("Case #%d: %d\n",k,counter);
 	}
 	return 0;
 }

