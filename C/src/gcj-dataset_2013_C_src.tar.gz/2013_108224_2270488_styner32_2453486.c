#include<stdio.h>
 
 char check_horizontal(char map[][4]);
 char check_virtical(char map[][4]);
 char check_digonal(char map[][4]);
 char check_draw(char map[][4]);
 
 int main(void) {
   char map[4][4];
   char tmp[100];
   int i, j, k, case_cnt;
   char winner;
 
   scanf("%d", &case_cnt);
   gets(tmp);
 
   for(k = 0; k < case_cnt; ++k) {
     winner = NULL;
 
     for(j = 0; j < 4; ++j) {
       gets(map[j]);
     }
 
     winner = check_horizontal(map);
     if(winner == NULL) {
       winner = check_virtical(map);  
     }
     if(winner == NULL) {
       winner = check_digonal(map);
     }
     
     if(winner != NULL)
       printf("Case #%d: %c won\n", k+1, winner);
     else if(check_draw(map)) {
       printf("Case #%d: Draw\n", k+1);
     }
     else {
       printf("Case #%d: Game has not completed\n", k+1); 
     }
 
     if(k != case_cnt) {
       gets(tmp);
     }
   }
 
   return 0;
 }
 
 char check_horizontal(char map[][4]) {
   int i, j;
   char winner = NULL;
 
   for(i = 0; i < 4; i++) {
     if(map[i][0] != '.') {
       int x_cnt = 0;
       int t_cnt = 0;
       int o_cnt = 0;
 
       for(j = 0; j < 4; ++j) {
         if(map[i][j] == 'X') x_cnt++;
         if(map[i][j] == 'T') t_cnt++;
         if(map[i][j] == 'O') o_cnt++;
       }
 
       if(x_cnt == 4 || (x_cnt == 3 && t_cnt == 1)) {
         return 'X';
       } else if (o_cnt == 4 || (o_cnt == 3 && t_cnt == 1)) {
         return 'O';
       }
     }
   }
   return NULL;
 }
 
 char check_virtical(char map[][4]) {
   int i, j;
   char winner = NULL;
 
   for(i = 0; i < 4; i++) {
     if(map[0][i] != '.') {
       int x_cnt = 0;
       int t_cnt = 0;
       int o_cnt = 0;
 
       for(j = 0; j < 4; ++j) {
         if(map[j][i] == 'X') x_cnt++;
         if(map[j][i] == 'T') t_cnt++;
         if(map[j][i] == 'O') o_cnt++;
       }
 
       if(x_cnt == 4 || (x_cnt == 3 && t_cnt == 1)) {
         return 'X';
       } else if (o_cnt == 4 || (o_cnt == 3 && t_cnt == 1)) {
         return 'O';
       }
     }
   }
   return NULL;
 }
 
 char check_digonal(char map[][4]) {
   int i, j;
   char winner = NULL;
 
   if(map[0][0] != '.') {
     int x_cnt = 0;
     int t_cnt = 0;
     int o_cnt = 0;
 
     for(i = 0; i < 4; ++i) {
       if(map[i][i] == 'X') x_cnt++;
       if(map[i][i] == 'T') t_cnt++;
       if(map[i][i] == 'O') o_cnt++;
     }
 
     if(x_cnt == 4 || (x_cnt == 3 && t_cnt == 1)) {
       return 'X';
     } else if (o_cnt == 4 || (o_cnt == 3 && t_cnt == 1)) {
       return 'O';
     }
   }
 
   if(map[0][3] != '.') {
     int x_cnt = 0;
     int t_cnt = 0;
     int o_cnt = 0;
 
     for(i = 0; i < 4; ++i) {
       if(map[i][3-i] == 'X') x_cnt++;
       if(map[i][3-i] == 'T') t_cnt++;
       if(map[i][3-i] == 'O') o_cnt++;
     }
 
     if(x_cnt == 4 || (x_cnt == 3 && t_cnt == 1)) {
       return 'X';
     } else if (o_cnt == 4 || (o_cnt == 3 && t_cnt == 1)) {
       return 'O';
     }
   }
 
   return NULL;
 }
 
 char check_draw(char map[][4]) {
   int i, j;
   char winner;
   char map_tmp[4][4];
 
   for(i = 0; i < 4; ++i) {
     memcpy(map_tmp[i], map[i], 4);
   }
 
   for(i = 0; i < 4; ++i) {
     for(j = 0; j < 4; ++j) {
       if(map_tmp[i][j] == '.') {
         map_tmp[i][j] = 'X';
       }
     }
   }
 
   winner = check_horizontal(map_tmp);
   if(winner == NULL) {
     winner = check_virtical(map_tmp);  
   }
   if(winner == NULL) {
     winner = check_digonal(map_tmp);
   }
 
   if(winner == 'X') {
     return 0;
   }
 
   for(i = 0; i < 4; ++i) {
     memcpy(map_tmp[i], map[i], 4);
   }
 
   for(i = 0; i < 4; ++i) {
     for(j = 0; j < 4; ++j) {
       if(map_tmp[i][j] == '.') {
         map_tmp[i][j] = 'O';
       }
     }
   }
 
   winner = check_horizontal(map_tmp);
   if(winner == NULL) {
     winner = check_virtical(map_tmp);  
   }
   if(winner == NULL) {
     winner = check_digonal(map_tmp);
   }
 
   if(winner == 'O') {
     return 0;
   }
 
   return 1;
 }
