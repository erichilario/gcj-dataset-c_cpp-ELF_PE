#include <stdio.h>
 
 int main()
 {
 	int t;
 	scanf("%d",&t);
 	int count=1;
 	while(t--)
 	{
 		int n,m,i,j,flag=1;
 		scanf("%d %d",&n,&m);
 		int a[n][m],sumr[n],sumc[m];
 		for(i=0;i<n;i++)
 			sumr[i] = 0;		
 		for(i=0;i<m;i++)
 			sumc[i] = 0;
 		
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				scanf("%d",&a[i][j]);
 			}
 		}
 		
 		int min=a[0][0];
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				if(a[i][j]<min)
 					min = a[i][j];
 			}
 		}
 		/* printf("%d",min); */
 		
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				a[i][j] = a[i][j] - min;
 			}
 		}
 /* 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				printf("%d ",a[i][j]);
 			}
 			printf("\n");
 		}  */
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				sumr[i] = sumr[i] + a[i][j];
 			}
 		}	
 		for(i=0;i<m;i++)
 		{
 			for(j=0;j<n;j++)
 			{
 				sumc[i] = sumc[i] + a[j][i];
 			}
 		}	
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				if(a[i][j]==0)
 				{
 					if(sumr[i]!=0 && sumc[j]!=0)
 						flag=0;
 				}
 			}
 		}
 		if(flag)
 			printf("Case #%d: YES\n",count);
 		else
 			printf("Case #%d: NO\n",count);
 		count++;
 	}
 	return 0;
 }
