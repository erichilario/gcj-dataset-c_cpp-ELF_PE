/*
  * Google Codejam 2013, 2013/04/13
  * Qualification Round
  * A. Tic-Tac-Toe-Tomek
  */
 
 #include <stdio.h>
 #include <string.h>
 
 #define TEST( r1, c1, r2, c2, r3, c3, r4, c4 )  (board[r1][c1])*(board[r2][c2])*(board[r3][c3])*(board[r4][c4])
 
 typedef struct {
     int row[4];
     int col[4];
 } SET;
 
 SET sets[10] = {
     { { 0, 0, 0, 0 }, {0, 1, 2, 3} },
     { { 1, 1, 1, 1 }, {0, 1, 2, 3} },
     { { 2, 2, 2, 2 }, {0, 1, 2, 3} },
     { { 3, 3, 3, 3 }, {0, 1, 2, 3} },
     { { 0, 1, 2, 3 }, {0, 0, 0, 0} },
     { { 0, 1, 2, 3 }, {1, 1, 1, 1} },
     { { 0, 1, 2, 3 }, {2, 2, 2, 2} },
     { { 0, 1, 2, 3 }, {3, 3, 3, 3} },
     { { 0, 1, 2, 3 }, {0, 1, 2, 3} },
     { { 0, 1, 2, 3 }, {3, 2, 1, 0} }
 };
 
 char *out[4] = {
     "X won",
     "O won",
     "Draw",
     "Game has not completed"
 };
 
 int main( int argc, char *argv[] )
 {
     int     numTest;
     int     board[4][4];
     char    linebuf[5];
     int     t, i, j, result, flag;
 
     scanf( "%d", &numTest );
 
     for( t = 1 ; t <= numTest ; t++ )
     {
         // printf( "***** Test Case #%d : Begin\n", t );
         for( i = 0 ; i < 4 ; i++ )
         {
             // printf( "***** Line #%d : ", i );
             scanf( "%s", linebuf );
             for( j = 0 ; j < 4 ; j++ )
             {
                 switch( linebuf[j] )
                 {
                     case 'X' :
                         board[i][j] = 2;
                         break;
 
                     case 'O' :
                         board[i][j] = 3;
                         break;
 
                     case 'T' :
                         board[i][j] = 5;
                         break;
 
                     case '.' :
                     default :
                         board[i][j] = 0;
                 }
                 // printf( "%d", board[i][j] );
             }
             // printf( "\n" );
         }
 
         flag = 0, result = 2;
         for( i = 0 ; i < 10 ; i++ )
         {
             j = TEST( sets[i].row[0], sets[i].col[0], sets[i].row[1], sets[i].col[1],
                       sets[i].row[2], sets[i].col[2], sets[i].row[3], sets[i].col[3] );
             // printf( "TEST result of case #%d is %d\n", i, j );
             if( j == 16 || j == 40 )
             {
                 result = 0;
                 break;
             }
             if( j == 81 || j == 135 )
             {
                 result = 1;
                 break;
             }
             if( j == 0 )
                 flag = 1;
         }
         if( result == 2 && flag == 1 )
             result = 3;
 
         printf( "Case #%d: %s\n", t, out[result] );
     }
 
     return 0;
 }

