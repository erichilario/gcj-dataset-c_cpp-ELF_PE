#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <math.h>
 
 #define MAX_CHARS_IN_WORD 26
 #define MAX_WORDS_ON_LINE 1000
 
 int parseString(char *s);
 void evaluateAdj(int x, int y, int cutSize);
 
 char wordBuffer[MAX_WORDS_ON_LINE][MAX_CHARS_IN_WORD];
 int theLand[102][102];
 int nearGroundFlag;
 
 int main()
 {
 	FILE *inputFilePointer;
 	FILE *outputFilePointer;
 	char fileBuffer[MAX_CHARS_IN_WORD*MAX_WORDS_ON_LINE];
 	char outputFileBuffer[MAX_CHARS_IN_WORD*MAX_WORDS_ON_LINE];
 	int numberOfCases;
 	int wordsOnLine;
 	int iLoopC1;
 	int iLoopC2;
 	int iLoopC3;
 
 	int keyCount;
 	int chestsToOpen;
 	int superFairFlag;
 
 	int fairSquareCount;
 	char tempWord[MAX_CHARS_IN_WORD];
 	int tempInt;
 	char tempString[MAX_CHARS_IN_WORD];
 
 
 	int theLandWidth;
 	int theLandHeight;
 
 	int passFlag;
 	int failFlag;
 
 	int currentlyCuttingSize;
 
 	inputFilePointer = fopen("input.txt", "r");
     if(inputFilePointer < 0)
     {
     	return -1;
     }
 
     outputFilePointer = fopen("output.txt", "w");
     if(outputFilePointer < 0)
     {
     	return -1;
     }
 
 
     //read first line
     fgets(fileBuffer, MAX_WORDS_ON_LINE*MAX_CHARS_IN_WORD, inputFilePointer);
     parseString(fileBuffer);
     numberOfCases = atoi(wordBuffer[0]);
 
     for(iLoopC1 = 0; iLoopC1 < numberOfCases; iLoopC1++)
     {
     	memset(theLand, 0, 102*102*sizeof(int));
     	fgets(fileBuffer,  MAX_WORDS_ON_LINE*MAX_CHARS_IN_WORD, inputFilePointer);
     	parseString(fileBuffer);
     	theLandHeight = atoi(wordBuffer[0]);
     	theLandWidth = atoi(wordBuffer[1]);
 
         for(iLoopC2 = 0; iLoopC2 < theLandHeight; iLoopC2++)
         {
         	fgets(fileBuffer, MAX_WORDS_ON_LINE*MAX_CHARS_IN_WORD, inputFilePointer);
         	parseString(fileBuffer);
         	for(iLoopC3 = 0; iLoopC3 < theLandWidth; iLoopC3++)
         	{
            		theLand[iLoopC2+1][iLoopC3+1] = atoi(wordBuffer[iLoopC3]);
            	}
         }
 
 
 
         for(iLoopC2 = 1; iLoopC2 < theLandHeight+1; iLoopC2++)
         {
         	for(iLoopC3 = 1; iLoopC3 < theLandWidth+1; iLoopC3++)
         	{
         		if(theLand[iLoopC2][iLoopC3] > 0)
         		{
         			currentlyCuttingSize = theLand[iLoopC2][iLoopC3];
 
         			if( (theLand[iLoopC2][iLoopC3+1] == 0) || (theLand[iLoopC2+1][iLoopC3] == 0) ||
         				(theLand[iLoopC2][iLoopC3-1] == 0) || (theLand[iLoopC2-1][iLoopC3] == 0) )
         			{
         				nearGroundFlag = 1;
         				evaluateAdj(iLoopC2, iLoopC3, currentlyCuttingSize);
         			}
         			nearGroundFlag = 0;
         		}
            	}
         }
 
         sprintf(outputFileBuffer, "Case #%i: ", iLoopC1+1);
         failFlag = 0;
         for(iLoopC2 = 1; iLoopC2 < theLandHeight+1; iLoopC2++)
         {
         	for(iLoopC3 = 1; iLoopC3 < theLandWidth+1; iLoopC3++)
         	{
         		if(theLand[iLoopC2][iLoopC3] > 0)
         		{
         			failFlag = 1;
         		}
            	}
         }
 
         if(failFlag == 1)
         {
         	strcat(outputFileBuffer, "NO\n");
         }
         else
         {
         	strcat(outputFileBuffer, "YES\n");
         }
     	fprintf(outputFilePointer, outputFileBuffer);
     }
     return 0;
 }
 
 
 
 void evaluateAdj(int x, int y, int cutSize)
 {
 	if(nearGroundFlag == 1)
 	{
 		theLand[x][y] = -1;
 		if(theLand[x][y+1] >= cutSize && theLand[x][y+1] > 0)
 		{
 			evaluateAdj(x, y+1, cutSize);
 		}
 		if(theLand[x][y-1] >= cutSize && theLand[x][y-1] > 0)
 		{
 			evaluateAdj(x, y-1, cutSize);
 		}
 		if(theLand[x+1][y] >= cutSize && theLand[x+1][y] > 0)
 		{
 			evaluateAdj(x+1, y, cutSize);
 		}
 		if(theLand[x-1][y] >= cutSize && theLand[x-1][y] > 0)
 		{
 			evaluateAdj(x-1, y, cutSize);
 		}
 	}
 }
 
 
 
 
 
 
 int parseString(char *s)
 {
 	int iLoopC1;
 	int startingIndex;
 	int endingIndex;
 	int exitFlag;
 	int wordCount;
 
 	int x;
 	int y;
 
 	memset(wordBuffer, 0, MAX_WORDS_ON_LINE*MAX_CHARS_IN_WORD);
 	wordCount = 0;
 
 	// Remove any weird characters
 	for(iLoopC1 = 0; iLoopC1 < strlen(s); iLoopC1++)
 	{
 		if(s[iLoopC1] < 0x20)
 		{
 			s[iLoopC1] = ' ';
 		}
 	}
 
 	// Main Parse
 	iLoopC1 = 0;
 	startingIndex = 0;
 	endingIndex = 0;
 
 	while(iLoopC1 < strlen(s))
 	{
 		if(s[iLoopC1] == ' ')
 		{
 			//mark ending
 			endingIndex = iLoopC1;
 
 			//make word
 			y = 0;
 			for(x = startingIndex; x < endingIndex; x++)
 			{
 				wordBuffer[wordCount][y] = s[x];
 				y++;
 			}
 
 			wordCount++;
 			//loop until no whitespace OR strlen exit
 			exitFlag = 0;
 			while(exitFlag == 0)
 			{
 				if(s[iLoopC1] == ' ')
 				{
 					if(iLoopC1 > strlen(s))
 					{
 						exitFlag = 1;
 					}
 					else
 					{
 						iLoopC1++;
 					}
 				}
 				else
 				{
 					startingIndex = iLoopC1;
 					exitFlag = 1;
 				}
 			}
 		}
 
 		iLoopC1++;
 	}
 
 	return wordCount;
 }

