#include <stdio.h>
 #include <string.h>
 
 int a[101][101];
 int row[101];
 int col[101];
 
 int getRowMax(int i, int m)
 {
 	int j = 0;
 	int max = 0;
 	for(j = 0; j < m; j++)
 		if(a[i][j] > max)
 			max = a[i][j];
 	return max;
 }
 
 int getColumnMax(int i, int n)
 {
 	int j = 0;
 	int max = 0;
 	for(j = 0; j < n; j++)
 		if(a[j][i] > max)
 			max = a[j][i];
 	return max;
 }
 
 int main()
 {
 	int i, j, k;
 	int T;
 	int N, M;
 	int flag;
 	
 	freopen("B-small-attempt0.in", "r", stdin);
 	freopen("B-small-attempt0.out", "w", stdout);
 	
 	scanf("%d", &T);
 	for(i = 0; i < T; i++)
 	{
 		printf("Case #%d: ", i+1);
 		scanf("%d%d", &N, &M);
 		flag = 1;
 		
 		memset(a, 0, sizeof(a));
 		memset(row, 0, sizeof(row));
 		memset(col, 0, sizeof(col));
 		
 		for(j = 0; j < N; j++)
 			for(k = 0; k < M; k++)
 				scanf("%d", &a[j][k]);
 		for(j = 0; j < N; j++)
 			row[j] = getRowMax(j, M);
 		for(k = 0; k < M; k++)
 			col[k] = getColumnMax(k, N);
 		for(j = 0; j < N; j++)
 			for(k = 0; k < M; k++)
 			{
 				if(row[j] == a[j][k] || col[k] == a[j][k])
 					continue;
 				else
 				{
 					flag = 0;
 					goto OUT;
 				}
 			}
 OUT:
 			if(flag)
 				printf("YES\n");
 			else
 				printf("NO\n");
 	}
 }
