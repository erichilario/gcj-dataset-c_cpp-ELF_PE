#include <stdio.h>
 #include <stdbool.h>
 #include <stdlib.h>
 
 bool check(char board[4][4], int r, int c) {
   int i,j;
   char x;
   
   x = board[r][c];
   if ( x == '.' )
     return false;
   for ( i=c; i < 4 && (board[r][i] == x || board[r][i] == 'T'); ++i );
   if ( i-c >= 4 ) return true;
   for ( i=r; i < 4 && (board[i][c] == x || board[i][c] == 'T'); ++i );
   if ( i-r >= 4 ) return true;
   for ( i=r,j=c; 
         i < 4 && j < 4 && (board[i][j] == x || board[i][j] == 'T'); 
 	++i,++j );
   if ( i-r >= 4 ) return true;
   for ( i=r,j=c; 
         i < 4 && j >= 0 && (board[i][j] == x || board[i][j] == 'T'); 
 	++i,--j );
   if ( i-r >= 4 ) return true;
 
   return false;
 }
 
 char * solve(char board[4][4]) {
   int i,j;
   bool has_empty = false;
   
   for ( i=0; i < 4; ++i ) {
     for ( j=0; j < 4; ++j ) {
       if ( check(board, i, j) )
 	return board[i][j] == 'X' ? "X won" : "O won";
       has_empty = has_empty || board[i][j] == '.';
     }
   }
   return has_empty ? "Game has not completed" : "Draw" ;
 }
 
 int main() {
   int i,j,k,t;
   char board[4][4];
   
   scanf("%d\n", &t);
   for ( i=0; i < t; ++i ) {
     for ( j=0; j < 4; ++j ) {
       for ( k=0; k < 4; ++k )
         scanf("%c", &board[j][k]);
       scanf("\n");
     }
     printf("Case #%d: %s\n", i+1, solve(board));
   }
   return EXIT_SUCCESS;
 }

