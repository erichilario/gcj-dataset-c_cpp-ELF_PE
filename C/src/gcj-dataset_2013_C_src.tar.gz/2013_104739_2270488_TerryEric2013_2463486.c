#include <stdio.h>
 #include <math.h>
 #include <string.h>
 #include <strings.h>
 
 int isfair(int n);
 
 int main(void)
 {
     FILE *fp;
     FILE *out;
     int loopmax;
   int i;
   int low,high;
   int root;
   float r;
   int sum;
 
   out = fopen ("C-small.out","w");
   if (out==NULL)
   {
      printf("cant open the output file\n");
      getche();
      return 0; 
   }
 
   fp = fopen ("C-small.in","r");
   if (fp==NULL)
   {
      printf("cant open the input file\n");
      getche();
      return 0; 
   }
   fscanf(fp,"%d",&loopmax);
 //  printf("loopmax = %d\n",loopmax);
 
   for(i=0;i<loopmax;i++)
   {
       sum=0;
       fscanf(fp,"%d %d",&low, &high);
       r=sqrt((float)low);
       root=ceil(r);
       while(root*root<=high)
       {
           if(isfair(root) && isfair(root*root))
           {
             sum++;
  //           if(i==1)
  //                 printf("%d\n",root);
           }
           root++;
       }
       fprintf(out,"Case #%d: %d\n",i+1, sum);
   }
 
   fclose(fp);
   fclose(out);
  //      getche();
 
   return 0;
 }
 int isfair(int n)
 {
     char str1[80];
     char str2[80];
     int i,length;
 
    sprintf(str1,"%d",n);
    length=strlen(str1);
    bzero(str2,sizeof(str2));
    for(i=0;i<length;i++)
      str2[length-1-i]=str1[i];
 //  printf("%s  %s\n",str1,str2);
   if(strcmp(str1,str2)==0)
   {
   return 1;
   }
   return 0;
 }
 

