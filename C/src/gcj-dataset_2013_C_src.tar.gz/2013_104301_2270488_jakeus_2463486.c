#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <math.h>
 
 #define MAX_CHARS_IN_WORD 26
 #define MAX_WORDS_ON_LINE 1000
 
 int parseString(char *s);
 
 char wordBuffer[MAX_WORDS_ON_LINE][MAX_CHARS_IN_WORD];
 
 int main()
 {
 	FILE *inputFilePointer;
 	FILE *outputFilePointer;
 	char fileBuffer[MAX_CHARS_IN_WORD*MAX_WORDS_ON_LINE];
 	char outputFileBuffer[MAX_CHARS_IN_WORD*MAX_WORDS_ON_LINE];
 	int numberOfCases;
 	int wordsOnLine;
 	int iLoopC1;
 	int iLoopC2;
 	int iLoopC3;
 
 	int fairFlag;
 	int squareFlag;
 	int superFairFlag;
 
 	int fairSquareCount;
 	char tempWord[MAX_CHARS_IN_WORD];
 	int tempInt;
 	char tempString[MAX_CHARS_IN_WORD];
 
 	int x;
 	int y;
 
 	inputFilePointer = fopen("input.txt", "r");
     if(inputFilePointer < 0)
     {
     	return -1;
     }
 
     outputFilePointer = fopen("output.txt", "w");
     if(outputFilePointer < 0)
     {
     	return -1;
     }
 
 
     //read first line
     fgets(fileBuffer, MAX_WORDS_ON_LINE*MAX_CHARS_IN_WORD, inputFilePointer);
     parseString(fileBuffer);
     numberOfCases = atoi(wordBuffer[0]);
 
     for(iLoopC1 = 0; iLoopC1 < numberOfCases; iLoopC1++)
     {
     	fairSquareCount = 0;
     	memset(outputFileBuffer, 0, MAX_CHARS_IN_WORD*MAX_WORDS_ON_LINE);
     	fgets(fileBuffer, MAX_WORDS_ON_LINE*MAX_CHARS_IN_WORD, inputFilePointer);
 		wordsOnLine = parseString(fileBuffer);
     	sprintf(outputFileBuffer, "Case #%i: ", iLoopC1+1);
 
     	for(iLoopC2 = atoi(wordBuffer[0]); iLoopC2 <= atoi(wordBuffer[1]); iLoopC2++)
     	{
     		if(iLoopC2 == 121)
     		{
     			printf("hi");
     		}
     		fairFlag = 0;
     		squareFlag = 0;
     		superFairFlag = 0;
 
     		//check for square
     		tempInt = sqrt(iLoopC2);
     		if( (tempInt * tempInt) == iLoopC2)
     		{
     			squareFlag = 1;
 
     			//flip the case
     			sprintf(tempString, "%i", tempInt);
     			memset(tempWord, 0, MAX_CHARS_IN_WORD);
     			for(iLoopC3 = 0; iLoopC3 < strlen(tempString); iLoopC3++)
     			{
    	    			tempWord[iLoopC3] = tempString[strlen(tempString)-1-iLoopC3];
     			}
 
     			x = atoi(tempWord);
     			y = tempInt;
     			if(x == y)
     			{
     				superFairFlag = 1;
     			}
     		}
 
     		//check for fair
 
     		//flip the case
     		memset(tempWord, 0, MAX_CHARS_IN_WORD);
     		sprintf(tempString, "%i", iLoopC2);
     		for(iLoopC3 = 0; iLoopC3 < strlen(tempString); iLoopC3++)
     		{
     			tempWord[iLoopC3] = tempString[strlen(tempString)-1-iLoopC3];
     		}
 
     		x = atoi(tempWord);
     		y = iLoopC2;
     		if(x == y)
     		{
     			fairFlag = 1;
     		}
 
     		if(fairFlag == 1 && squareFlag == 1 && superFairFlag)
     		{
     			fairSquareCount++;
     		}
     	}
     	sprintf(tempString, "%i", fairSquareCount);
     	strcat(outputFileBuffer, tempString);
     	strcat(outputFileBuffer, "\n");
     	fprintf(outputFilePointer, outputFileBuffer);
     }
     return 0;
 }
 
 
 
 
 
 
 
 
 
 
 int parseString(char *s)
 {
 	int iLoopC1;
 	int startingIndex;
 	int endingIndex;
 	int exitFlag;
 	int wordCount;
 
 	int x;
 	int y;
 
 	memset(wordBuffer, 0, MAX_WORDS_ON_LINE*MAX_CHARS_IN_WORD);
 	wordCount = 0;
 
 	// Remove any weird characters
 	for(iLoopC1 = 0; iLoopC1 < strlen(s); iLoopC1++)
 	{
 		if(s[iLoopC1] < 0x20)
 		{
 			s[iLoopC1] = ' ';
 		}
 	}
 
 	// Main Parse
 	iLoopC1 = 0;
 	startingIndex = 0;
 	endingIndex = 0;
 
 	while(iLoopC1 < strlen(s))
 	{
 		if(s[iLoopC1] == ' ')
 		{
 			//mark ending
 			endingIndex = iLoopC1;
 
 			//make word
 			y = 0;
 			for(x = startingIndex; x < endingIndex; x++)
 			{
 				wordBuffer[wordCount][y] = s[x];
 				y++;
 			}
 
 			wordCount++;
 			//loop until no whitespace OR strlen exit
 			exitFlag = 0;
 			while(exitFlag == 0)
 			{
 				if(s[iLoopC1] == ' ')
 				{
 					if(iLoopC1 > strlen(s))
 					{
 						exitFlag = 1;
 					}
 					else
 					{
 						iLoopC1++;
 					}
 				}
 				else
 				{
 					startingIndex = iLoopC1;
 					exitFlag = 1;
 				}
 			}
 		}
 
 		iLoopC1++;
 	}
 
 	return wordCount;
 }

