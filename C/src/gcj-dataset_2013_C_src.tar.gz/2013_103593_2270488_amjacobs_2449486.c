#include <stdio.h>
 #include <stdlib.h>
 
 int hasGoodVertNeighbor(int **grid, int width, int height, int x, int y) {
   int current = grid[y][x], above = -1, below = -1;
 
   if(y > 0) {
     above = grid[y - 1][x];
   }
   if(y < height - 1) {
     below = grid[y + 1][x];
   }
 
   return above <= current && below <= current;
 }
 
 int hasGoodHorizNeighbor(int **grid, int width, int height, int x, int y) {
   int current = grid[y][x], left = -1, right = -1;
 
   if(x > 0) {
     left = grid[y][x - 1];
   }
   if(x < width - 1) {
     right = grid[y][x + 1];
   }
 
   return left <= current && right <= current;
 }
 
 int main(int argc, char *argv[]) {
   int numTests, width, height, **grid, i, x, y, possible;
 
   scanf("%d\n", &numTests);
 
   for(i = 0; i < numTests; ++i) {
     possible = 1;
     scanf("%d %d\n", &height, &width);
 
     grid = (int**)malloc(height * sizeof(int*));
     for(y = 0; y < height; ++y) {
       grid[y] = (int*)malloc(width * sizeof(int));
     }
 
     for(y = 0; y < height; ++y) {
       for(x = 0; x < width; ++x) {
         scanf("%d", &grid[y][x]);
       }
       scanf("\n");
     }
 
     for(y = 0; y < height; ++y) {
       for(x = 0; x < width; ++x) {
         if(!hasGoodVertNeighbor(grid, width, height, x, y)
         && !hasGoodHorizNeighbor(grid, width, height, x, y)) {
           possible = 0;
           break;
         }
       }
       if(!possible) {
         break;
       }
     }
 
     if(possible) {
       printf("Case #%d: YES\n", i + 1);
     }
     else {
       printf("Case #%d: NO\n", i + 1);
     }
 
     for(y = 0; y < height; ++y) {
       free(grid[y]);
     }
     free(grid);
   }
 }

