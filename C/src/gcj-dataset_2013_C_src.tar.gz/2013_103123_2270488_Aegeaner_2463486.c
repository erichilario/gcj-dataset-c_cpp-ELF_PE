#include <stdio.h>
 #include <string.h>
 #include <stdbool.h>
 
 int a[15];
 bool flag[1001];
 
 void num2arr(long long n, int a[])
 {
 	int i = 0;
 	while(n != 0)
 	{
 		a[i++] = n % 10;
 		n /= 10;
 	}
 	a[i] = -1;
 }
 
 int check_array(int a[])
 {
 	int begin;
 	int last = 0;
 	while(a[last] != -1)
 		last++;
 	for(begin = 0, last = last - 1; begin <= last; begin++, last--)
 		if(a[begin] != a[last])
 			return 0;
 	return 1;
 }
 
 int check_num(long long n)
 {
 	int i;
 	
 	memset(a, 0, sizeof(a));
 	num2arr(n, a);
 	return check_array(a); 
 }
 
 int main()
 {
 	long long i;
 	int T;
 	int A, B;
 	
 	freopen("C-small-attempt0.in", "r", stdin);
 	freopen("C-small-attempt0.out", "w", stdout);
 	
 	memset(flag, 0, sizeof(flag));
 	
 	for(i = 1; i < 32; i++)
 	{
 		if(check_num(i) && check_num(i*i))
 		{
 			flag[i*i] = 1;
 		}
 	}
 	
 	scanf("%d", &T);
 	for(i = 0; i < T; i++)
 	{
 		int j;
 		int count = 0;
 		scanf("%d%d", &A, &B);
 		printf("Case #%d: ", i+1);
 		for(j = A; j <= B; j++)
 		{
 			if(flag[j])
 				count++;
 		}
 		printf("%d\n", count);
 	}
 	
 }
