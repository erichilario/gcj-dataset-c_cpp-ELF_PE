#include <stdio.h>
 #include <stdlib.h>
 
 char **tabuleiro(int l){
 int i;
 char **tab = (char**)malloc(l *sizeof(char*));
 for(i=0; i<l; i++)
     tab[i]=(char*)malloc(l *sizeof(char));
 return tab;
 }
 
 void carrega(char **tab, int l){
     int i, j;
     char a;
     for(i=0; i<l; i++){
         for(j=0; j<l; j++){
             scanf("%c", &a);
             if(a=='\n')
                 j--;
             else
                 tab[i][j]=a;
         }
     }
 }
 
 int row(char **tab, int l, int x, int y){
     int i;
 
     for(i=0; i<l; i++)
         if(tab[x][i]!=tab[x][y] && tab[x][i]!='T')
         return 0;
     return 1;
 }
 
 int column(char **tab, int l, int x, int y){
     int i;
     for(i=0; i<l; i++)
         if(tab[i][y]!=tab[x][y] && tab[i][y]!='T')
         return 0;
     return 1;
 }
 
 int diagonal(char **tab, int l, int x, int y){
     int i;
 
     if(x==0 && y==0){
         for(i=0; i<l; i++){
             if(tab[x+i][y+i]!=tab[x][y] && tab[x+i][y+i]!='T')
                 return 0;
         }
         return 1;
     }
 
     else if(x==0 && y==l-1){
         for(i=0; i<l; i++){
             if(tab[x+i][y-i]!=tab[x][y] && tab[x+i][y-i]!='T')
                 return 0;
         }
         return 1;
     }
 
     else if(x==l-1 && y==0){
         for(i=0; i<l; i++){
             if(tab[x-i][y+i]!=tab[x][y] && tab[x-i][y+i]!='T')
                 return 0;
         }
         return 1;
     }
 
     else if(x==l-1 && y==l-1){
         for(i=0; i<l; i++){
             if(tab[x-i][y-i]!=tab[x][y] && tab[x-i][y-i]!='T')
                 return 0;
         }
         return 1;
     }
     return 0;
 }
 
 char status(char **tab, int l){
     int i, j;
     int vazio = 0;
     char s;
 
     for(i=0; i<l; i++){
         for(j=0; j<l; j++){
             if(tab[i][j]=='.')
                 vazio=1;
             else if(row(tab, l, i, j) || column(tab, l, i, j) || diagonal(tab, l, i, j))
                 return tab[i][j];
         }
     }
 
     if(vazio==0)
         s='d';
     else
         s='n';
     return s;
 }
 
 void desaloca(char **tab, int l){
 int i;
 for(i=0; i<l; i++)
     free(tab[i]);
 free(tab);
 }
 
 void saida(int x, char s){
     x++;
 if(s=='X')
     printf("Case #%d: X won\n", x);
 else if(s=='O')
     printf("Case #%d: O won\n", x);
 else if(s=='d')
     printf("Case #%d: Draw\n", x);
 else if(s=='n')
     printf("Case #%d: Game has not completed\n", x);
 }
 
 int main(){
 
 int T, i;
 int l=4;
 char **tab = tabuleiro(l);
 char s;
 
 scanf("%d\n", &T);
 
 for(i=0; i<T; i++){
         carrega(tab,l);
         s = status(tab, l);
         saida(i, s);
 }
 desaloca(tab, l);
 return 0;
 }

