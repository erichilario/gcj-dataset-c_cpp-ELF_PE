#include<stdio.h>
 
 int main()
 {
 	int no_test,i,j,k=0,m,n,a,b,p,q,current;
 	scanf("%d",&no_test);
 	int result[no_test];
 	while(k<no_test)
 	{
 		scanf("%d %d",&m,&n);
 		int row[m],col[n],array[m][n];
 		for(i=0;i<m;i++)
 		{
 			row[i]=0;
 			for(j=0;j<n;j++)
 			{
 				col[j]=0;
 				scanf("%d",&array[i][j]);
 			}
 		}
 		result[k]=1;
 		for(i=0;i<m;i++)
 		{
 			for(j=0;j<n;j++)
 			{
 				if(array[i][j]==1)
 				{
 					if(row[i]==0&&col[j]==0)
 					{ //printf("hi\n");
 						p=q=current=0;
 						for(a=0;a<n;a++)
 						{
 							if(array[i][a]==1)
 								p++;
 						}
 						if(p<n)
 						{//printf("hello\n");
 							current=1;
 						}
 						else if(p>=n)
 						{
 							row[i]=1;
 						}
 						p=0;
 						//printf("%d current\n",current);
 						if(current==1)
 						{
 							for(a=0;a<m;a++)
 							{
 								if(array[a][j]==1)
 									p++;
 							}
 							if(p<m)
 							{//printf("sooo sweet\n");
 								result[k]=0;
 								break;
 							}
 							else
 							{
 								col[j]=1;
 							}
 						}
 					}
 				}
 			}
 			if(result[k]==0)
 				break;
 		}
 		//printf("%d result\n",k);
 			/*int y=0,z=0,s=0;
 			a=b=0;
 			for(i=0;i<m;i++)
 			{
 				for(j=0;j<n;j++)
 				{
 					if(result[k]!=0&&array[i][j]==2)
 					{//printf("hema\n");
 						if(array[i][n-1]==2)
 						{
 							s=0;
 							for(p=j;p<=n-2;p++)
 							{
 								if(array[i][p]!=2)
 								{
 									s=1;
 									break;
 								}
 							}
 							if(s!=1)
 								a++;
 						}
 						if(array[i][0]==2&&a==0)
 						{
 							s=0;
 							for(p=1;p<=j-1;p++)
 							{
 								if(array[i][p]!=2)
 								{
 									s=1;
 									break;
 								}
 							}
 							if(s!=1)
 								b++;
 						}
 						if(array[0][j]==2&&a==0&&b==0)
 						{
 							s=0;
 							for(p=0;p<=i-1;p++)
 							{
 								if(array[p][j]!=2)
 								{
 									s=1;
 									break;
 								}
 							}
 							if(s!=1)
 								y++;
 						}
 						if(array[m-1][j]==2&&a==0&&b==0&&y==0)
 						{
 							s=0;
 							for(p=i+1;p<=m-2;p++)
 							{
 								if(array[p][j]!=2)
 								{
 									s=1;
 									break;
 								}
 							}
 							if(s!=1)
 								z++;
 						}
 						if(a==0&&b==0&&y==0&&z==0)
 						{
 							result[k]=0;
 							break;
 						}
 					}
 				}
 				if(result[k]==0)
 					break;
 			}*/
 		
 		k++;
 	}
 	for(i=0;i<no_test;i++)
 	{
 		if(result[i]==0)
 			printf("Case #%d: NO\n",i+1);
 		else
 			printf("Case #%d: YES\n",i+1);
 	}
 }

