#include<stdio.h>
 
 /*
 void intprint(int a[][100],int n, int m)
 {
 	int i,j;
 	printf("\n");
 	for(i=0;i<n;i++)
 	{
 		for(j=0;j<m;j++)
 			printf("%d ",a[i][j]);
 			
 		printf("\n");
 	}
 }
 */
 
 int main()
 {
 	int a[100][100], b[100][100], n, m, t;
 	
 	int i,j,k, max, stat;
 	
 	FILE *ip=fopen("input","r");
 	FILE *op=fopen("output","w");
 	
 	fscanf(ip,"%d",&t);
 	
 	for(i=1;i<=t;i++)
 	{
 		stat=1;
 		
 		fscanf(ip,"%d",&n);
 		fscanf(ip,"%d",&m);
 		
 		
 		for(j=0;j<n;j++)
 		{
 			max=-100;
 			for(k=0;k<m;k++)
 			{
 				fscanf(ip,"%d",&a[j][k]);
 				b[j][k]=0;
 				
 				if(max<a[j][k])
 				{
 					max=a[j][k];
 				}
 				
 			}
 			
 			for(k=0;k<m;k++)
 			{
 				if(max==a[j][k])
 					b[j][k]=1;
 			}
 		}
 		
 		
 		for(k=0;k<m;k++)
 		{
 			max=-100;
 			for(j=0;j<n;j++)
 			{
 				if(max<a[j][k])
 				{
 					max=a[j][k];
 				}
 			}
 			
 			for(j=0;j<n;j++)
 			{
 				if(max==a[j][k])
 					b[j][k]=1;
 			}
 		}
 		
 		
 		//intprint(b,n,m);
 		
 		for(j=0;j<n;j++)
 		{
 			for(k=0;k<m;k++)
 			{
 				if(b[j][k]!=1)
 				{
 					stat=0;
 					break;
 				}
 			}
 			
 			if(stat==0)
 				break;
 		}
 		
 		if(stat==1)
 		{
 			fprintf(op,"Case #%d: YES\n", i);
 		}
 		
 		if(stat==0)
 		{
 			fprintf(op,"Case #%d: NO\n", i);
 		}
 		
 		
 	}
 	
 }

