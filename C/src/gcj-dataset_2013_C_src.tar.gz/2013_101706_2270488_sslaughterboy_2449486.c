#include <stdlib.h>
 #include <stdio.h>
 #include <assert.h>
 
 
 int solve(int caseNo);
 
 
 
 int main(int argc, char* argv[]){
     int cases;
     scanf("%d", &cases);
     int i;
     for(i = 1; i <= cases; i++){
           if(solve(i)){
           	printf("Case #%d: YES", i);
           } else {
           	printf("Case #%d: NO", i);
           }
 		  printf("\n");
     }
     return 0;
 }
 
 int solve(int caseNo){
 	int n, m;
 	scanf("%d %d", &n, &m);
     int board[n][m];
 	int a,b;
 	getchar();
 	for(a = 0; a < n; a++){
 		for(b = 0; b < m; b++){
 			board[a][b] =  getchar();
 			getchar();
 		}
 	}
 	
 		
 	for(a = 0; a < n; a++){
 		for(b = 0; b < m; b++){
 			if(!((board[a][0] <= board[a][b] && board[a][m-1] <= board[a][b]) ||
 			   (board[0][b] <= board[a][b] && board[n-1][b] <= board[a][b]))){
 			       return 0;
 			   }
 		}
 	}
 	
 	return 1;		
 }
 
 
 
 
 
 
 
 
 
 
 
 
 /*
 
 	for(a = 0; a < n; a++){
 		for(b = 0; b < m; b++){
 			printf("%c", board[a][b]);
 		}
 		printf("\n");
 	}
 
 	
 
 */

