#include<stdio.h>
 int main()
 {
 int flag,T,z,i,j,rmax[100],cmax[100],garden[100][100],n,m;
 
 scanf("%d",&T);
 
 for(z=1;z<=T;z++)
 {
   flag=0;
   scanf("%d%d",&n,&m);
   
   for(i=0;i<n;i++)
 	rmax[i]=0;
   
   for(i=0;i<m;i++)
 	cmax[i]=0;
   
   for(i=0;i<n;i++)
   {
 	for(j=0;j<m;j++)
 	{
 	  scanf("%d",&garden[i][j]);
 	  
 	  if(rmax[i]<garden[i][j])rmax[i]=garden[i][j];
 	  
 	}
   }
   
   for(i=0;i<m;i++)
   {
 	for(j=0;j<n;j++)
 	{
 	    
 	  if(cmax[i]<garden[j][i])cmax[i]=garden[j][i];
 	  
 	}
   }
   
   for(i=0;i<n;i++)
   {
 	for(j=0;j<m;j++)
 	{
 	  if(garden[i][j]<rmax[i]&&garden[i][j]<cmax[j])
 	  {
 		printf("Case #%d: NO\n",z);
 		flag=1;
 		break;
 	  }
 	  
 	}
 	if(flag==1)break;
   }
   if(flag==1)continue;
   
   printf("Case #%d: YES\n",z);
 		
 }
 }
