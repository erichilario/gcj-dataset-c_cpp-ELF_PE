#include <stdio.h>
 #include <string.h>
 
 #define MAX(a,b) ((a) > (b) ? (a) : (b))
 
 int main(void) {
 
 	int test_cases;
 	int iter, rows, cols;
 	int o_r, o_d, o_d2;
 	int x_r, x_d, x_d2;
 	int o_c[4];
 	int x_c[4];
 	int d;
 	int o_w;
 	int x_w;
 	char n;
 	char board[4][4];
 	
 	scanf("%d", &test_cases);
 
 	iter = 0;
 	while(iter < test_cases) {
 	
 		memset(o_c, 0, sizeof(o_c[0])*4);
 		memset(x_c, 0, sizeof(x_c[0])*4);
 		o_d = o_d2 = 0;
 		x_d = o_d2 = 0;
 		d = 0;
 		o_w = 0;
 		x_w = 0;
 	
 		// read board configuration
 		for(rows = 0; rows < 4; ++rows) {
 			scanf("%s", &board[rows]);
 			for(cols = 0, o_r = 0, x_r = 0; cols < 4; ++cols) {
 				if(board[rows][cols] == 'O' || board[rows][cols] == 'T') {
 					++o_c[cols];
 					++o_r;
 					o_d = rows == cols ? o_d + 1 : o_d;
 				}
 				if(board[rows][cols] == 'X' || board[rows][cols] == 'T') {
 					++x_c[cols];
 					++x_r;
 					x_d = rows == cols ? x_d + 1 : x_d;
 				}
 				if(board[rows][cols] == '.') ++d;
 			}
 			if(board[rows][3 - rows] == 'X' || board[rows][3 - rows] == 'T') ++x_d2;
 			if(board[rows][3 - rows] == 'O' || board[rows][3 - rows] == 'T') ++o_d2;
 			
 			if(x_r == 4) { x_w = 1; } 
 			else if (o_r == 4) { o_w = 1; }
 		}
 		scanf("%c", &n);
 		
 		if(x_c[0] == 4 || x_c[1] == 4 || x_c[2] == 4 || x_c[3] == 4 || x_d == 4 || x_d2 == 4 || x_w == 1) {
 			printf("Case #%d: %s", iter+1, iter+1 == test_cases ? "X won" : "X won\n");
 		} else if(o_c[0] == 4 || o_c[1] == 4 || o_c[2] == 4 || o_c[3] == 4 || o_d == 4 || o_d2 == 4 || o_w == 1) {
 			printf("Case #%d: %s", iter+1, iter+1 == test_cases ? "O won" : "O won\n");
 		} else {
 			if(iter+1 == test_cases) {
 				printf("Case #%d: %s", iter+1, d == 0 ? "Draw" : "Game has not completed");
 			} else {
 				printf("Case #%d: %s\n", iter+1, d == 0 ? "Draw" : "Game has not completed");
 			}
 		}
 		
 		++iter;
 	}
 	
 	return 0;
 }
