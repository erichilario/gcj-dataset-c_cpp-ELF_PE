#include <stdio.h>
 
 #define XWON    1
 #define OWON    2
 #define DRAW    3
 #define NOTOVER 4
 
 int dx[] = {1,0,1,1,-1,0,-1,-1};
 int dy[] = {0,1,1,-1,0,-1,-1,1};
 char map[5][5];
 char ans[31];
 
 int count(int i, int j, int k)
 {
 	int x = i, y = j, ret = 1;
 	for(;;)
 	{
 		x += dx[k];
 		y += dy[k];
 		if(x < 0 || y < 0) return ret;
 		if(x > 3 || y > 3) return ret;
 		if(map[x][y] != 'T' && map[x][y] != map[i][j]) return ret;
 		++ret;
 	}
 }
 
 int judge()
 {
     int i, j, k;
     for(i = 0; i < 4; ++i)
         for(j = 0; j < 4; ++j) if(map[i][j] == 'X' || map[i][j] == 'O')
             for(k = 0; k < 4; ++k)
                 if(count(i, j, k) + count(i, j, k + 4) > 4)
                     return map[i][j] == 'X' ? XWON : OWON;
     for(i = 0; i < 4; ++i)
         for(j = 0; j < 4; ++j)
             if(map[i][j] == '.')
                 return NOTOVER;
     return DRAW;
 }
 
 int main(int argc, const char *argv[])
 {
 	freopen("input.txt", "r", stdin);
 	freopen("output.txt", "w", stdout);
     int k, o, i, result;
     for(scanf("%d%*c", &o), k = 1; k <= o; ++k)
     {
 		printf("Case #%d: ", k);
         for(i = 0; i < 4; ++i)
         {
             scanf("%s%*c", map[i]);
         }
         result = judge();
         if(result == XWON)
             printf("X won\n");
         else if(result == OWON)
             printf("O won\n");
         else if(result == DRAW)
             printf("Draw\n");
         else if(result == NOTOVER)
             printf("Game has not completed\n");
     }
     return 0;
 }

