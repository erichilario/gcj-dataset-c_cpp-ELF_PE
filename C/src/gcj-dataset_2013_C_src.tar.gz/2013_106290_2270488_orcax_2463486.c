#include <stdio.h>
 #include <math.h>
 #include <string.h>
 
 int num[105];
 
 int isfair(int n)
 {
   int len = 0, tmp = n;
   while(tmp)
   {
     num[len++] = tmp % 10;
     tmp /= 10;
   }
   if(len == 1)
     return 1;
   int i = 0, j = len-1;
   while(i < j)
     if(num[i++] != num[j--])
       return 0;
   return 1;
 }
 
 int main()
 {
   int T, i, j, A, B, count;
   scanf("%d", &T);
   for(i=1;i<=T;i++)
   {
     scanf("%d %d\n", &A, &B);
     A = ceil(sqrt(A));
     B = floor(sqrt(B));
     count = 0;
     for(j=A;j<=B;j++)
       if(isfair(j) && isfair(j*j))
         ++count;
     printf("Case #%d: %d\n", i, count);
   }
   return 0;
 }

