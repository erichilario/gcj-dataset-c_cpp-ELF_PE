#include <stdio.h>
 
 int a[100][100];
 int N, M;
 
 int check() {
   for (int i = 0; i < N; ++i)
   for (int j = 0; j < M; ++j) {
     int mi = 0; for (int k = 0; k < M; ++k) if (a[i][k] > mi && k != j) mi = a[i][k];
     int mj = 0; for (int k = 0; k < N; ++k) if (a[k][j] > mj && k != i) mj = a[k][j];
     if (mi > a[i][j] && mj > a[i][j])
       return 0;
   }    
   return 1;
 }
 
 void doit(int tid) {
   printf("Case #%d: ", tid);
   if (check()) 
     printf("YES\n");
   else
     printf("NO\n");
 }
 
 int main() {
   int tests;
   scanf("%d", &tests);
   for (int test = 1; test <= tests; ++test) {
     scanf("%d%d", &N, &M);
 
     for (int i = 0; i < N; ++i)
     for (int j = 0; j < M; ++j)
       scanf("%d", &a[i][j]);
 
     doit(test);
   }
 
   return 0;
 }
