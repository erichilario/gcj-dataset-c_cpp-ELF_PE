#include <stdio.h>
 #include <strings.h>
 
 int main(void)
 {
   FILE *fp;
   FILE *out;
   int loopmax;
   int i,row,col,r,c,fail;
   int maxrow[100];
   int maxcol[100];
   int array[100][100];
 
   out = fopen ("B-large.out","w");
   if (out==NULL)
   {
      printf("cant open the output file\n");
      getche();
      return 0; 
   }
 
   fp = fopen ("B-large.in","r");
   if (fp==NULL)
   {
      printf("cant open the input file\n");
      getche();
      return 0; 
   }
   fscanf(fp,"%d",&loopmax);
 
   for(i=0;i<loopmax;i++)
   {
      fscanf(fp,"%d %d",&row, &col);
      for(r=0;r<row;r++)
      {
         for(c=0;c<col;c++)
         {
            fscanf(fp,"%d",&array[r][c]);
        }
      }
   bzero(maxrow,sizeof(maxrow));
   bzero(maxcol,sizeof(maxrow));
           
     for(r=0;r<row;r++)
      {
         for(c=0;c<col;c++)
         {
 
             if(maxrow[r]<array[r][c])
               maxrow[r]=array[r][c];
         }
      }
 
     for(c=0;c<col;c++)
      {
         for(r=0;r<row;r++)
         {
             if(maxcol[c]<array[r][c])
               maxcol[c]=array[r][c];
         }
      }
     fail=0;     
    for(r=0;r<row;r++)
      {
         for(c=0;c<col;c++)
         {
             if(array[r][c]<maxrow[r] && array[r][c]<maxcol[c])
             {
               fail=1;
               break;
             }
         }
      }
       fprintf(out,"Case #%d: %s\n",i+1, fail?"NO":"YES");
   }
 
   fclose(fp);
   fclose(out);
 
   return 0;
 }
 

