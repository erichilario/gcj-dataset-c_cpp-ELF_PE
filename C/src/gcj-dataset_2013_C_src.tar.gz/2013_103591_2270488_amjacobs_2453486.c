#include <stdio.h>
 
 #define SIZE 4
 #define EMPTY '.'
 #define TOMEK 'T'
 
 int checkFull(char board[SIZE][SIZE]) {
   int x, y;
   for(y = 0; y < SIZE; ++y) {
     for(x = 0; x < SIZE; ++x) {
       if(board[y][x] == EMPTY) {
         return 0;
       }
     }
   }
 
   return 1;
 }
 
 int checkHoriz(char board[SIZE][SIZE], char player) {
   int x, y, lineMatch;
   for(y = 0; y < SIZE; ++y) {
     lineMatch = 1;
     for(x = 0; x < SIZE; ++x) {
       if(board[y][x] != player && board[y][x] != TOMEK) {
         lineMatch = 0;
         break;
       }
     }
     if(lineMatch) {
       return 1;
     }
   }
 
   return 0;
 }
 
 int checkVert(char board[SIZE][SIZE], char player) {
   int x, y, colMatch;
   for(x = 0; x < SIZE; ++x) {
     colMatch = 1;
     for(y = 0; y < SIZE; ++y) {
       if(board[y][x] != player && board[y][x] != TOMEK) {
         colMatch = 0;
         break;
       }
     }
     if(colMatch) {
       return 1;
     }
   }
 
   return 0;
 }
 
 int checkDiag(char board[SIZE][SIZE], char player) {
   int diag, y, x, diagMatch = 1;
   for(diag = 0; diag < SIZE; ++diag) {
     if(board[diag][diag] != player && board[diag][diag] != TOMEK) {
       diagMatch = 0;
       break;
     }
   }
 
   if(diagMatch) {
     return 1;
   }
 
   diagMatch = 1;
   for(y = 0; y < SIZE; ++y) {
     x = SIZE - y - 1;
     if(board[y][x] != player && board[y][x] != TOMEK) {
       diagMatch = 0;
     }
   }
 
   return diagMatch;
 }
 
 int main(int argc, char *argv[]) {
   int numTests, i, x, y;
   char board[SIZE][SIZE];
   scanf("%d\n", &numTests);
 
   for(i = 0; i < numTests; ++i) {
     for(y = 0; y < SIZE; ++y) {
       for(x = 0; x < SIZE; ++x) {
         scanf("%c", &board[y][x]);
       }
       scanf("\n");
     }
 
     printf("Case #%d: ", i + 1);
     if(checkHoriz(board, 'X') || checkVert(board, 'X') || checkDiag(board, 'X')) {
       printf("X won\n");
     }
     else if(checkHoriz(board, 'O') || checkVert(board, 'O') || checkDiag(board, 'O')) {
       printf("O won\n");
     }
     else if(checkFull(board)) {
       printf("Draw\n");
     }
     else {
       printf("Game has not completed\n");
     }
 
     /*for(y = 0; y < SIZE; ++y) {
       for(x = 0; x < SIZE; ++x) {
         printf("%c ", board[y][x]);
       }
       printf("\n");
     }
     printf("\n");*/
   }
 }

