#include <stdio.h>
 void turn(int);
 int getFirstCol();
 int getFirstRow();
 void init(int,int);
 int delRowCol(int,int,int,int);
 int mem[100][100];
 int nV[100];
 void part(int);
 int mV[100];
 int currentMin=0;
 int main()
 {
     int t,turn=0;
     scanf("%d",&t);
     while(t--)
     {
         part(++turn);
     }
     return 0;
 }
 void part(int turn)
 {
     int n,m;
     int i,j;
     int Frow,Fcol;
     int flag=0;
     currentMin=1;
     scanf("%d",&n);
     scanf("%d",&m);
     init(n,m);
     do
     {
         Frow=getFirstRow();
         Fcol=getFirstCol();
         if(Frow!=-1 && Fcol!=-1)
             flag=delRowCol(n,m,Frow,Fcol);
     }while(Frow!=-1 && Fcol!=-1 && flag!=1);
     if(flag==1)
     {
         printf("Case #%d: NO\n", turn);
     }
     else
     {
         printf("Case #%d: YES\n", turn);
     }
 }
 int delRowCol(int n,int m,int Frow,int Fcol)
 {
     int minRow= mem[Frow][Fcol],minCol= mem[Frow][Fcol];
     int minRowPos=Frow,minColPos=Fcol;
     int i,j;
     for(i=0;i<n;i++)
     {
         if(nV[i]==1 && minRow>mem[i][Fcol])
         {
             minRow=mem[i][Fcol];
             minRowPos=i;
         }
     }
     for(j=0;j<m;j++)
     {
         if(mV[j]==1 && minCol>mem[Frow][j])
         {
             minCol=mem[Frow][j];
             minColPos=j;
         }
     }
     if(minRow==minCol && minColPos==Fcol /*&& minRowPos==Frow*/)
     {
         int flagRow=0, flagCol=0;
         if(currentMin<=minRow)
         {
             currentMin=minRow;
             for(i=0;i<n;i++)
                 if(nV[i]==1 && minRow!=mem[i][Fcol])
                     flagCol=1;
             for(j=0;j<m;j++)
                 if(mV[j]==1 && minCol!=mem[Frow][j])
                     flagRow=1;
             if(flagRow==0)
                 nV[Frow]=0;
             else if(flagCol==0)
                 mV[Fcol]=0;
             else
                 return 1;
         }
         else
         {
             return 1;
         }
     }
     else if(minRow<=minCol)
     {
         if(currentMin<=minRow)
         {
             currentMin=minRow;
             for(j=0;j<m;j++)
                 if(mV[j]==1 && minRow!=mem[minRowPos][j])
                 {
                     return 1;
                 }
             nV[minRowPos]=0;
         }
         else
         {
             return 1;
         }
     }
     else
     {
         if(currentMin<=minCol)
         {
             currentMin=minCol;
             for(i=0;i<m;i++)
                 if(nV[i]==1 && minCol!=mem[i][minColPos])
                 {
                     return 1;
                 }
             mV[minColPos]=0;
         }
         else
         {
             return 1;
         }
     }
     return 0;
 }
 void init(int n,int m)
 {
     int i,j;
     for(i=0;i<100;i++)
     {
         for(j=0;j<100;j++)
         {
             if(i<n && j<m)
                 scanf("%d",&mem[i][j]);
             else
                 mem[i][j]=0;
         }
     }
     for(i=0;i<n;i++)
     {
         nV[i]=1;
     }
     for(;i<100;i++)
     {
         nV[i]=0;
     }
     for(j=0;j<m;j++)
     {
         mV[j]=1;
     }
     for(;j<100;j++)
     {
         mV[j]=0;
     }
 }
 int getFirstRow()
 {
     int i;
     int Frow=-1;
     for(i=0;Frow==-1 && i<100;i++)
     {
         if(nV[i]==1)
         {
            Frow=i;
         }
     }
     return Frow;
 }
 int getFirstCol()
 {
     int i;
     int Fcol=-1;
     for(i=0;Fcol==-1 && i<100;i++)
     {
         if(mV[i]==1)
         {
            Fcol=i;
         }
     }
     return Fcol;
 }

