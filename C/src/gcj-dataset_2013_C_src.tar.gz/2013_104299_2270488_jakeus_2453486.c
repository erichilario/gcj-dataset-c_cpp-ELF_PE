#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <math.h>
 
 #define MAX_CHARS_IN_WORD 26
 #define MAX_WORDS_ON_LINE 1000
 
 int parseString(char *s);
 
 char wordBuffer[MAX_WORDS_ON_LINE][MAX_CHARS_IN_WORD];
 
 int main()
 {
 	FILE *inputFilePointer;
 	FILE *outputFilePointer;
 	char fileBuffer[MAX_CHARS_IN_WORD*MAX_WORDS_ON_LINE];
 	char outputFileBuffer[MAX_CHARS_IN_WORD*MAX_WORDS_ON_LINE];
 	int numberOfCases;
 	int wordsOnLine;
 	int iLoopC1;
 	int iLoopC2;
 	int iLoopC3;
 
 	int keyCount;
 	int chestsToOpen;
 	int superFairFlag;
 
 	int fairSquareCount;
 	char tempWord[MAX_CHARS_IN_WORD];
 	int tempInt;
 	char tempString[MAX_CHARS_IN_WORD];
 
 	int playAreaX[4][4];
 	int playAreaO[4][4];
 	int x;
 	int y;
 
 	int xWinsFlag;
 	int oWinsFlag;
 	int drawFlag;
 
 	inputFilePointer = fopen("input.txt", "r");
     if(inputFilePointer < 0)
     {
     	return -1;
     }
 
     outputFilePointer = fopen("output.txt", "w");
     if(outputFilePointer < 0)
     {
     	return -1;
     }
 
 
     //read first line
     fgets(fileBuffer, MAX_WORDS_ON_LINE*MAX_CHARS_IN_WORD, inputFilePointer);
     parseString(fileBuffer);
     numberOfCases = atoi(wordBuffer[0]);
 
     for(iLoopC1 = 0; iLoopC1 < numberOfCases; iLoopC1++)
     {
         //load key types
         for(iLoopC2 = 0; iLoopC2 < 4; iLoopC2++)
         {
         	fgets(fileBuffer, 6, inputFilePointer);
         	for(iLoopC3 = 0; iLoopC3 < 4; iLoopC3++)
         	{
             	if(fileBuffer[iLoopC3] == 'T')
             	{
             		playAreaX[iLoopC2][iLoopC3] = 'X';
             		playAreaO[iLoopC2][iLoopC3] = 'O';
             	}
             	else
             	{
             		playAreaX[iLoopC2][iLoopC3] = fileBuffer[iLoopC3];
             		playAreaO[iLoopC2][iLoopC3] = fileBuffer[iLoopC3];
             	}
         	}
         }
         fgets(fileBuffer, 4, inputFilePointer);
 
         xWinsFlag = 0;
         oWinsFlag = 0;
         drawFlag = 0;
 
         if(	(playAreaX[0][0] == 'X' && playAreaX[0][1] == 'X'&& playAreaX[0][2] == 'X' && playAreaX[0][3] == 'X') ||
         	(playAreaX[1][0] == 'X' && playAreaX[1][1] == 'X'&& playAreaX[1][2] == 'X' && playAreaX[1][3] == 'X') ||
         	(playAreaX[2][0] == 'X' && playAreaX[2][1] == 'X'&& playAreaX[2][2] == 'X' && playAreaX[2][3] == 'X') ||
         	(playAreaX[3][0] == 'X' && playAreaX[3][1] == 'X'&& playAreaX[3][2] == 'X' && playAreaX[3][3] == 'X') ||
         	(playAreaX[0][0] == 'X' && playAreaX[1][0] == 'X'&& playAreaX[2][0] == 'X' && playAreaX[3][0] == 'X') ||
         	(playAreaX[0][1] == 'X' && playAreaX[1][1] == 'X'&& playAreaX[2][1] == 'X' && playAreaX[3][1] == 'X') ||
         	(playAreaX[0][2] == 'X' && playAreaX[1][2] == 'X'&& playAreaX[2][2] == 'X' && playAreaX[3][2] == 'X') ||
         	(playAreaX[0][3] == 'X' && playAreaX[1][3] == 'X'&& playAreaX[2][3] == 'X' && playAreaX[3][3] == 'X') ||
         	(playAreaX[0][0] == 'X' && playAreaX[1][1] == 'X'&& playAreaX[2][2] == 'X' && playAreaX[3][3] == 'X') ||
         	(playAreaX[3][0] == 'X' && playAreaX[2][1] == 'X'&& playAreaX[1][2] == 'X' && playAreaX[0][3] == 'X') )
         {
         	xWinsFlag = 1;
         }
 
         else if(	(playAreaO[0][0] == 'O' && playAreaO[0][1] == 'O'&& playAreaO[0][2] == 'O' && playAreaO[0][3] == 'O') ||
         	(playAreaO[1][0] == 'O' && playAreaO[1][1] == 'O'&& playAreaO[1][2] == 'O' && playAreaO[1][3] == 'O') ||
         	(playAreaO[2][0] == 'O' && playAreaO[2][1] == 'O'&& playAreaO[2][2] == 'O' && playAreaO[2][3] == 'O') ||
         	(playAreaO[3][0] == 'O' && playAreaO[3][1] == 'O'&& playAreaO[3][2] == 'O' && playAreaO[3][3] == 'O') ||
         	(playAreaO[0][0] == 'O' && playAreaO[1][0] == 'O'&& playAreaO[2][0] == 'O' && playAreaO[3][0] == 'O') ||
         	(playAreaO[0][1] == 'O' && playAreaO[1][1] == 'O'&& playAreaO[2][1] == 'O' && playAreaO[3][1] == 'O') ||
         	(playAreaO[0][2] == 'O' && playAreaO[1][2] == 'O'&& playAreaO[2][2] == 'O' && playAreaO[3][2] == 'O') ||
         	(playAreaO[0][3] == 'O' && playAreaO[1][3] == 'O'&& playAreaO[2][3] == 'O' && playAreaO[3][3] == 'O') ||
         	(playAreaO[0][0] == 'O' && playAreaO[1][1] == 'O'&& playAreaO[2][2] == 'O' && playAreaO[3][3] == 'O') ||
         	(playAreaO[3][0] == 'O' && playAreaO[2][1] == 'O'&& playAreaO[1][2] == 'O' && playAreaO[0][3] == 'O') )
         {
         	oWinsFlag = 1;
         }
 
         else if((playAreaO[0][0] != '.') && (playAreaO[1][0] != '.') && (playAreaO[2][0] != '.') && (playAreaO[3][0] != '.') &&
         		(playAreaO[0][1] != '.') && (playAreaO[1][1] != '.') && (playAreaO[2][1] != '.') && (playAreaO[3][1] != '.') &&
         		(playAreaO[0][2] != '.') && (playAreaO[1][2] != '.') && (playAreaO[2][2] != '.') && (playAreaO[3][2] != '.') &&
         		(playAreaO[0][3] != '.') && (playAreaO[1][3] != '.') && (playAreaO[2][3] != '.') && (playAreaO[3][3] != '.'))
         {
         	drawFlag = 1;
         }
 
     	sprintf(outputFileBuffer, "Case #%i: ", iLoopC1+1);
 
     	if(xWinsFlag == 1)
     	{
     		strcat(outputFileBuffer, "X won\n");
     	}
     	else if(oWinsFlag == 1)
     	{
     		strcat(outputFileBuffer, "O won\n");
     	}
     	else if(drawFlag == 1)
     	{
     		strcat(outputFileBuffer, "Draw\n");
     	}
     	else
     	{
     		strcat(outputFileBuffer, "Game has not completed\n");
     	}
     	fprintf(outputFilePointer, outputFileBuffer);
     }
     return 0;
 }
 
 
 
 
 
 
 
 
 
 int parseString(char *s)
 {
 	int iLoopC1;
 	int startingIndex;
 	int endingIndex;
 	int exitFlag;
 	int wordCount;
 
 	int x;
 	int y;
 
 	memset(wordBuffer, 0, MAX_WORDS_ON_LINE*MAX_CHARS_IN_WORD);
 	wordCount = 0;
 
 	// Remove any weird characters
 	for(iLoopC1 = 0; iLoopC1 < strlen(s); iLoopC1++)
 	{
 		if(s[iLoopC1] < 0x20)
 		{
 			s[iLoopC1] = ' ';
 		}
 	}
 
 	// Main Parse
 	iLoopC1 = 0;
 	startingIndex = 0;
 	endingIndex = 0;
 
 	while(iLoopC1 < strlen(s))
 	{
 		if(s[iLoopC1] == ' ')
 		{
 			//mark ending
 			endingIndex = iLoopC1;
 
 			//make word
 			y = 0;
 			for(x = startingIndex; x < endingIndex; x++)
 			{
 				wordBuffer[wordCount][y] = s[x];
 				y++;
 			}
 
 			wordCount++;
 			//loop until no whitespace OR strlen exit
 			exitFlag = 0;
 			while(exitFlag == 0)
 			{
 				if(s[iLoopC1] == ' ')
 				{
 					if(iLoopC1 > strlen(s))
 					{
 						exitFlag = 1;
 					}
 					else
 					{
 						iLoopC1++;
 					}
 				}
 				else
 				{
 					startingIndex = iLoopC1;
 					exitFlag = 1;
 				}
 			}
 		}
 
 		iLoopC1++;
 	}
 
 	return wordCount;
 }

