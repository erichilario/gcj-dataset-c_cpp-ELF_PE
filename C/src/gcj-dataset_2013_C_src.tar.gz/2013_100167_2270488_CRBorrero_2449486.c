#include <stdio.h>
 #include <stdlib.h>
 
 int m[100][100];
 int N, M;
 
 int check(int x, int y){
 	int i;
 	int h=1;
 	int v=1;
 	for (i=0;i<M;i++){
 		if (m[x][i] > m[x][y]) h=0;
 	}
 	for (i=0;i<N;i++){
 		if (m[i][y] > m[x][y]) v=0;
 	}
 	if (h || v) return 1;
 	else return 0;
 }
 
 int main(){
 
 	int ndc;
 	int caso;
 	scanf("%d\n",&ndc);
 	
 	for(caso=0; caso<ndc; caso++){
 		
 		scanf("%d %d",&N,&M);
 		
 		int i,j;
 		for (i=0; i<N; i++){
 			for (j=0;j<M;j++){
 				if (j<(M-1))	scanf("%d ",&m[i][j]);
 				else 			scanf("%d\n",&m[i][j]);
 			}
 		}
 		
 		int salir = 0;
 		for (i=0;i<N && !salir;i++){
 			for (j=0;j<M && !salir;j++){
 				if (!check(i,j))
 					salir=1;
 			}
 		}
 				
 		// imprimir resultado
 		printf("Case #%d: %s\n",caso+1,salir?"NO":"YES");
 	}
 	return 0;
 }

