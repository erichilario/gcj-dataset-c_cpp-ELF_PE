#include<stdio.h>
 
 char palindrome(int x);
 char square(int n);
 int main(void)
 {
  int line,mi,ma;
  scanf("%d",&line);
  int i;
  for(i=1;i<=line;i++)
  {
     scanf("%d %d\b",&mi,&ma);
     int j;
     int counter=0;
     for(j=mi;j<=ma;j++)
     {
     char check_palindrome=palindrome(j);
     char check_square=square(j);
     if(check_palindrome=='y' && check_square=='y')
               counter++;
     }
     printf("Case #%d: %d \n",i,counter);
  }
  return 0;
 }
 
 char palindrome(int x)
 {
     int y=x;
     int r;
     int s=0;
     if(y>9)
     {
       while(x>0)
       {
         r=x%10;
         s=s*10+r;
         x=x/10;
       }
       if(y==s)
         return 'y';
       else
         return 'n';
 
     }
     else
       return 'y';
 
 }
 
 char square(int n)
 {
    int i;
    for(i=1;i<=n;i++)
    {
        if((float)n/(i*i)==1.0000)
        {
             if(palindrome(i)=='y')
               return 'y';
 
        }
    }
    return 'n';
 }

