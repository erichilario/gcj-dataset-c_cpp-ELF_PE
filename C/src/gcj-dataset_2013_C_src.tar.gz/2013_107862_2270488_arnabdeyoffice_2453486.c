#include <stdio.h>
 
 int main ()
 {
 
         char *a, line[5];
         FILE *fp;
         int i, j, k, flag, T, l, m;
         char c, u, v;
 
         fp=fopen("TICTAC.out", "w");
 
         scanf ("%d",&T);
 
         for (i=0; i<T; i++)
         {
                 a=(char *)malloc(16);
 
                 for (j=0; j<16; j+=4)
                 {
                         scanf ("%s", line);
                         for (k=0; k<4; a[j+k]=line[k], k++);
                 }
 
                 c=getchar();
 
                 l=0; m=0;
                 flag=0;
                 u=(a[0]=='T')?a[5]:a[0];
                 v=(a[3]=='T')?a[6]:a[3];
 
                 for (j=0; j<4; j++)
                 {
                         c=a[j*4];
                         if (c=='T')     c=a[j*4+1];
                         for (k=1; k<4 && (a[j*4+k]==c || a[j*4+k]=='T'); k++);
                         if (k==4)
                         {
                                 if (c=='X') flag=2; else if (c=='O') flag=3; else flag=0;
                                 if (c=='X' || c=='O')   break;
                         }
 
                         c=a[j];
                         if (c=='T')     c=a[j+4];
                         for (k=1; k<4 && (a[k*4+j]==c || a[k*4+j]=='T'); k++);
                         if (k==4)
                         {
                                 if (c=='X') flag=2; else if (c=='O') flag=3; else flag=0;
                                 if (c=='X' || c=='O')   break;
                         }
 
                         if ((a[5*j]==u) || (a[5*j]=='T'))       l++;
                         if ((a[3*j+3]==v) || (a[3*j+3]=='T'))   m++;
                 }
 
                 if (l==4)       { if (u=='X') flag=2; else if (u=='O') flag=3; else flag=0; }
                 else if (m==4)  { if (v=='X') flag=2; else if (v=='O') flag=3; else flag=0; }
 
                 if (flag==0)
                 {
                         for (j=0; j<16 && a[j]!='.'; j++);
                         flag=(j==16)?1:0;
                 }
 
                 switch (flag)
                 {
                         case 0: fprintf (fp, "Case #%d: Game has not completed\n", i+1); break;
                         case 1: fprintf (fp, "Case #%d: Draw\n", i+1); break;
                         case 2: fprintf (fp, "Case #%d: X won\n", i+1); break;
                         case 3: fprintf (fp, "Case #%d: O won\n", i+1); break;
                 }
 
                 free (a);
         }
 
         return 0;
 }
