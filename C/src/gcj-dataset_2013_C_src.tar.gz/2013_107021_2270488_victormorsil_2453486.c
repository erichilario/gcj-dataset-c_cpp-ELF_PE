#include<stdio.h>
 char matriz[8][8];
 main(){
     int t, i, y, x;
     int cont_P, cont_X_h, cont_X_v, cont_X_d, cont_X_d2, cont_O_h, cont_O_v, cont_O_d, cont_O_d2;
 
     scanf("%d", &t);
 
     for(i=0; i<t; i++){
             cont_P=cont_X_h=cont_X_v=cont_X_d=cont_X_d2=cont_O_h=cont_O_v=cont_O_d=cont_O_d2=0;
 
             for(y=0; y<4; y++){
                 for(x=0; x<4; x++){
                         scanf(" %c", &matriz[y][x]);
                 }
             }
 
             for(y=0; y<4; y++){
                 for(x=0; x<4; x++){
                         if(matriz[y][x]=='X' || matriz[y][x]=='T') cont_X_h++;
                         if(matriz[y][x]=='O' || matriz[y][x]=='T') cont_O_h++;
                         if(y==x){
                             if(matriz[y][x]=='X' || matriz[y][x]=='T') cont_X_d++;
                             if(matriz[y][x]=='O' || matriz[y][x]=='T') cont_O_d++;
                         }
                         if(matriz[y][x]=='.') cont_P=1;
                 }
                 if(cont_X_h==4) break;
                 if(cont_O_h==4) break;
                 cont_X_h=0;
                 cont_O_h=0;
             }
 
             for(x=0; x<4; x++){
                 for(y=0; y<4; y++){
                         if(matriz[y][x]=='X' || matriz[y][x]=='T') cont_X_v++;
                         if(matriz[y][x]=='O' || matriz[y][x]=='T') cont_O_v++;
                         if((y+x)==3){
                             if(matriz[y][x]=='X' || matriz[y][x]=='T') cont_X_d2++;
                             if(matriz[y][x]=='O' || matriz[y][x]=='T') cont_O_d2++;
                         }
                 }
                 if(cont_X_v==4) break;
                 if(cont_O_v==4) break;
                 cont_X_v=0;
                 cont_O_v=0;
             }
 
             if(cont_X_h==4 || cont_X_v==4 || cont_X_d==4 || cont_X_d2==4) printf("Case #%d: X won\n", i+1);
             else if(cont_O_h==4 || cont_O_v==4 || cont_O_d==4 || cont_O_d2==4) printf("Case #%d: O won\n", i+1);
             else if(!cont_P) printf("Case #%d: Draw\n", i+1);
             else printf("Case #%d: Game has not completed\n", i+1);
     }
 }

