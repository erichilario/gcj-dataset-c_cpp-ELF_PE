#include<stdio.h>
 #include<math.h>
 #include<stdlib.h>
 int chk_pal(int i)
 {
     int rem,sum=0,temp;
     temp=i;
     while(i)
     {
         rem=i%10;
         sum=(sum*10)+rem;
         i=i/10;
     }
     if(temp==sum)
         return 1;
     else
         return 0;
 }
 int main()
 {
     long long beg,end,count,i;
     int test,j;
     float sqrtl;
     scanf("%d",&test);
     j=0;
     while(j<test)
     {
         count=0;
         scanf("%lld %lld",&beg,&end);
         for(i=beg; i<=end; i++)
         {
             sqrtl=sqrt(i);
             if(sqrtl==(int)sqrtl)
             {
                 if(chk_pal(i) && chk_pal(sqrtl))
                 {
                     count++;
                 }
             }
         }
         printf("Case #%d: %lld\n",j+1,count);
         j++;
     }
     return 0;
 }
 

