#include <stdio.h>
 #include <math.h>
 #include <stdlib.h>
 //#include "quack.h"
 
 #define HEADDATA -99999
 
 
 
 typedef struct node *Quack;
 
 Quack creat_quack(void);
 void push(int data, Quack list);
 int pop(Quack list);
 int is_empty_quack(Quack list);
 void make_empty_quack(Quack list);
 void print_quack(Quack list);
 void qush( int data, Quack list);
 
 
 struct node{
     int data;
     Quack next;
 };
 
 
 Quack creat_quack (void ){
     
     Quack head;
     
     head = malloc(sizeof(struct node));
     
     if( head == NULL ){
         fprintf(stderr, "There was a memory allocation problem\n");
         exit ( 1 );
     }
     
     head->data = HEADDATA;
     head->next = NULL;
     
     return head;
 }
 
 
 
 void push ( int data, Quack head){
     
     Quack new_node;
     
     
     new_node = malloc(sizeof(struct node));
     
     if( head == NULL ){
         fprintf( stderr,"There was a memory allocation problem\n");
         exit ( 1 );
     }
     new_node->data = data;
     new_node->next = head->next;
     head->next = new_node;
     
     
 }
 
 
 void print_quack( Quack head ){
     
     
     
     printf("<<");
     
     while( head->next != NULL ){
         head = head->next;
         printf(" %d",head->data);
         
         if ( head->next != NULL ){
             printf(",");
         }
     }
     
     printf(" >>\n");
     
     return;
 }
 
 
 
 
 void qush( int data, Quack head ){
     
     
     Quack new_node;
     
     while ( head->next != NULL ){
         head = head->next;
     }
 
     
     new_node = malloc(sizeof(struct node));
     
     if( head == NULL ){
         fprintf( stderr,"There was a memory allocation problem\n");
         exit ( 1 );
     }
 
     head->next = new_node;
     new_node->next = NULL;
     new_node->data = data;
     return;
     
     
 }
 
 
 
 
 
 int is_empty_quack ( Quack head ){
     
     int empty = 0;
     if (head == NULL ){
         printf("Quack is not initialised\n");
     }else{
         empty = head->next == NULL;
     }
     return empty;
 }
 
 
 
 void make_empty_quack( Quack head ){
     
     if (head == NULL ){
         
         printf("Quack is not initialised");
     
     }else{
     
         while (!is_empty_quack( head )){
             pop ( head );
         }
     }
     return;
 }
 
 
 int pop ( Quack head ){
     
     int pop_num = 0; 
     Quack temp = head;
     
     if ( head == NULL){
         printf("Quack is not initialised\n");
     }
     else if ( is_empty_quack (head)){
         
         printf("Quack is empty\n");
     }
     else {
         
         temp = head->next;
         pop_num = temp->data; 
         head->next = temp->next;
         free ( temp );
         
     }
     return pop_num;
 }
 
 
 int qop ( Quack head){
 	
     int pop_num = 0; 
     Quack temp = head;
     
     if ( head == NULL){
         printf("Quack is not initialised\n");
     }
     else if ( is_empty_quack (head)){
         
         printf("Quack is empty\n");
     }
     else {
 		
 	    while( head->next != NULL ){
 	    	temp = head;
 		    head = head->next;
 		}
 		pop_num = head->data;
 		temp->next = NULL;
 		free ( head);
 	}
 	return pop_num;
 		
 	
 	
 }
 
 // y means it's nice
 char takeNumber ( int number){
 	
 	
 	int i;
 	int part;
 	Quack myQuack = creat_quack();
 	int size = floor(log10(abs(number))) + 1;
 	// transfering number in Quack
 	
 	
 	
 	for ( i = 1 ; i <= size ; i++){
 		part = number % ( 10);
 		//printf("%d\n", part);
 		push ( part, myQuack);
 		number = number /10;
 	}
 	
 	for ( i =  1 ; i <= size/2 ; i++){
 		
 		if ( pop( myQuack) != qop( myQuack)){
 			return 'n';
 		}
 	}
 	return 'y';
 	
 	
 	make_empty_quack( myQuack);
 	
 }
 	
 	
 
 // y means yeas , n means no
 char isNice ( Quack head, int size){
 	
 	int i;
 	for ( i =  1 ; i <= size/2 ; i++){
 		
 		if ( pop( head) != qop( head)){
 			return 'n';
 		}
 	}
 	return 'y';
 }
 
 
 
 
 
 //////////////////////////////
 
 int main ( void){
 	
 	
 	int UpperLimit, lowerLimit;
 	int count = 0;
 	int number;
 	int i;
 	int j;
 	int sqrtNumber;
 	int numberOfCase;
 	
 	scanf("%d",&numberOfCase);
 	
 	for( j = 1 ; j <= numberOfCase ; j++){
 		count = 0;
 	
 	
 		scanf("%d %d",&lowerLimit,&UpperLimit );
 	
 		for ( i = lowerLimit ; i <= UpperLimit ; i++ ){
 		
 			number = i;
 			sqrtNumber = sqrt( number);
 		
 	
 			if ( takeNumber(number ) == 'y' && takeNumber(sqrtNumber) == 'y' && ( sqrtNumber*sqrtNumber == number) ){
 				count++;
 			}
 		
 		}
 		printf ("Case #%d: %d\n",j ,count);
 	}
 	
 		
 	//seq=((char *)malloc(size)*sizeof(char));
 	  
 	//printf("%d\n", size);
 	
 	return 0;
 	
 }
