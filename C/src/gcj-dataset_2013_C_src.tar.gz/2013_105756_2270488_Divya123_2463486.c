#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <math.h>
 int palin(int number)
 {
 int temp = number,remainder,sum=0; //Value of temp stores unmodified n value
 
   while(number>0)
     {
       remainder=number%10; 
       number/=10;                
      sum=sum*10 + remainder; //Builds value of reversed number
      }
 //if(temp == 11) printf("%d\n",sum);
    if (sum==temp) return 1;
   //   printf ("nThe Number Is A Palindrome ");
    else return 0;
   //   printf ("nThe Number Is Not A Palindrome ");
 
 
 }
 int main()
 {
 int t,i;
 scanf("%d",&t);
 for(i=0;i<t;i++)
 {
 int count=0,k,j,m,n;
 scanf("%d%d",&m,&n);
 int p=(int)sqrt(m);
 int q=(int)sqrt(n);
 for(j=p;j<=q;j++)
 { if(j*j >= m && j*j <= n && palin(j) && palin(j*j) ) count++;}
 printf("Case #%d: ",i+1);
 printf("%d\n",count);
 }
 return 0;
 }

