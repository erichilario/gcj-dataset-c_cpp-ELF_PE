#include <stdio.h>
 #include <math.h>
 
 int is_palindrome(unsigned long long input) {
   unsigned long long reverse_input = 0, iter_input = input, last_digit;
   while (iter_input > 0)
   {
       last_digit = iter_input % 10;
       reverse_input *= 10;
       reverse_input += last_digit;
       iter_input /= 10;
   }
   return input == reverse_input ? 1 : 0;
 }
 
 unsigned count_fair_and_square(char range_start[100], char range_end[100]) {
   unsigned long long num_fair_and_squares = 0;
   unsigned long long start, end, sqrt_start, sqrt_end, check, check_squared;
   sscanf(range_start, "%llu", &start);
   sscanf(range_end, "%llu", &end);
   sqrt_start = sqrt(start);
   sqrt_end   = sqrt(end);
 
   for(check=sqrt_start; check <= sqrt_end; check++) {
     check_squared = check * check;
     if(check_squared >= start && check_squared <= end) {
       if(is_palindrome(check) && is_palindrome(check_squared))
         num_fair_and_squares++;
     } else {
     }
   }
   return num_fair_and_squares;
 }
 
 int main(void) {
   int nb_test_cases;
   int test_counter = 1;
   char range_start[100], range_end[100];
 
   scanf("%d\n", &nb_test_cases);
   while (nb_test_cases - test_counter >= 0) {
     scanf("%s %s\n", range_start, range_end);
     
     printf("Case #%d: %d\n", test_counter,
                              count_fair_and_square(range_start, range_end));
 
     test_counter++;
   }
   return 0;
 }

