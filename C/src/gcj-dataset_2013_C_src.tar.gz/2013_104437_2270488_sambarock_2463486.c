#include<stdio.h>
 #include<math.h>
 
 int main()
 {
 	FILE *ip=fopen("input","r");
 	FILE *op=fopen("output","w");
 	
 	int i, j, k;
 	int a, b, n, t, temp, reverse, reverse1, count;
 	
 	fscanf(ip,"%d",&t);
 	
 	for(i=1;i<=t;i++)
 	{
 		fscanf(ip,"%d",&a);
 		fscanf(ip,"%d",&b);
 		count=0;
 		
 		for(n=a;n<=b;n++)
 		{
 		
 			reverse=0;
 			temp = n;
  
 			while( temp != 0 )
 			{
 				reverse = reverse * 10;
 				reverse = reverse + temp%10;
 				temp = temp/10;
 			}
 			
 			reverse1=0;
 			temp = sqrt(n);
  
 			while( temp != 0 )
 			{
 				reverse1 = reverse1 * 10;
 				reverse1 = reverse1 + temp%10;
 				temp = temp/10;
 			}
 			
 			if(reverse==n && reverse1==sqrt(n))
 			{
 				count++;
 			}
 	
 	
 		}
 		
 		fprintf(op,"Case #%d: %d\n", i, count);
 	}
 	
 }

