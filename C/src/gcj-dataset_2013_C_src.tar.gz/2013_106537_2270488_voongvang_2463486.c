#include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
 
 int test, it, a,b, total, root, num, digits1[20], digits2[20], d1, d2,temp;
 
 
 int main()
 {
 
     FILE *ifp, *ofp;
     ifp=fopen("problem_b.in", "r");
     ofp=fopen("problem_b.out", "w");
     scanf("%d",&test);
     //fscanf(ifp,"%d",&test);
     for(it = 1; it <= test; it++) {
         total = 0;
         scanf("%d %d", &a, &b);
 
         root = (int)sqrt(a);
         num = root*root;
         while(num < a) {
             root++;
 
             num = root * root;
         }
         while(num >= a && num <= b) {
             int flag = 1;
             int i = 0,j;
             temp = root;
             while(temp > 10) {
                 digits1[i] = temp %10;
                 temp /= 10;
                 i++;
             }
             if(temp > 0)
                 digits1[i++] = temp;
             d1 = i;
 
             for(i = 0, j = d1-1; i < d1; i++, j--) {
                 if(digits1[i] != digits1[j]) {
                     flag = 0;
                     break;
                 }
             }
             if(flag == 1) {
                 i = 0;
                 temp = num;
                 while(temp > 10) {
                     digits2[i] = temp %10;
                     temp /= 10;
                     i++;
                 }
                 if(temp > 0)
                     digits2[i++] = temp;
                 d2 = i;
 
                 for(i = 0, j = d2-1; i < d2; i++, j--) {
                     if(digits2[i] != digits2[j]) {
                         flag = 0;
                         break;
                     }
                 }
 
             }
 
             if(flag == 1)
                 total++;
             root++;
             num = root*root;
         }
 
         printf("Case #%d: %d\n",it, total);
 
     }
 
     return 0;
 }

