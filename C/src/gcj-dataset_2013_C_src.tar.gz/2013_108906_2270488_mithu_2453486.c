#include<stdio.h>
 int main()
 {
 	int rowO,rowX,colO,colX,rowT,colT,status,dots;
 	char a[4][4];
 	int i,j,k,t;
 	scanf("%d",&t);
 	for(k=1;k<=t;k++)
 	{
 		getchar();
 		dots=0;
 		for(i=0;i<4;i++)
 		{
 			for(j=0;j<4;j++)
 			{
 				scanf("%c",&a[i][j]);
 				//printf("\na[i][j]=%d",a[i][j]);
 			}
 			getchar();
 		}
 		for(i=0;i<4;i++)
 		{
 			rowO=colO=status=0;
 			for(j=0;j<4;j++)
 			{
 				if(a[i][j]!='.')
 				rowO+=a[i][j];
 				if(a[j][i]!='.')
 				colO+=a[j][i];
 				if(a[i][j]=='.'){dots++;}
 			}
 			if(rowO==4*'X'||rowO==3*'X'+'T'||colO==4*'X'||colO==3*'X'+'T')
 				{status=1;break;}
 			if(colO==4*'O'||colO==3*'O'+'T'||rowO==4*'O'||rowO==3*'O'+'T')
 				{status=2;break;}
 			//printf("WiningX=%d ,%d,WinningO=%d ,%d\n",4*'X',3*'X'+'T',4*'O',3*'O'+'T');
 			//printf("status==%d rowT=%d,colt=%d\n",status,rowO,colO);
 			//getchar();
 		}
 		printf("Case #%d: ",k);
 		rowT=(a[0][0]+a[1][1]+a[2][2]+a[3][3]);
 		colT=(a[0][3]+a[1][2]+a[2][1]+a[3][0]);
 		
 		if(status==1||rowT==4*'X'||rowT==3*'X'+'T'||colT==4*'X'||colT==3*'X'+'T')
 		{
 			printf("X won\n");
 		}
 		else if(status==2||rowT==4*'O'||rowT==3*'O'+'T'||colT==4*'O'||colT==3*'O'+'T')
 		{
 			printf("O won\n");
 		}
 		else if(dots>0)
 		{
 			printf("Game has not completed\n");
 		}
 		else 
 			printf("Draw\n");
 				
 
 	}
 	return 0;
 }
 				
 				

