#include <iostream>
 #include <string>
 #include <sstream>
 #include <algorithm>
 
 using namespace std;
 
 bool isPalidrone(int n) {
    stringstream ss;
    ss << n;
    string n1 = ss.str();
    string n2 = n1;
 
    reverse(n1.begin(), n1.end());
 
    return n1.compare(n2) == 0;
 }
 
 int main() {
    int T;
    cin >> T;
    int A, B;
       
 
    for (int t = 0; t < T; t++) {
       int numPalidrones = 0;
       cout << "Case #" << t + 1 << ": ";
       cin >> A >> B;
 
       for (int n = 0; n * n <= B; n++) {
          if (isPalidrone(n)) {
             // maybe there is a square palidrone above me
             if (isPalidrone(n * n)) {
                if (n*n >= A && n*n <= B) {
                   numPalidrones++;
                }
             }
          }
       }
 
       cout << numPalidrones << endl;
    }
 }

