#include <stdio.h>
 
 char c;
 int main(){
     int T,N,ans;
 
     scanf("%d\n",&T);
     int t;
     char map[4][4];
     int i,j;
     
 
     
     for ( t = 1 ; t <= T ; t++){
         for ( i=0;i<4;i++){
             for (j=0;j<4;j++){
                 scanf("%c", &c);
                 while ( c != '.' && c != 'O' && c != 'X' && c != 'T' ){
                     scanf("%c", &c);                      
                 }
                 map[i][j] = c;
             }
 //            scanf("\n");
         }
 //        scanf("\n");
 
 /*        
         //DEBUG : on
         for ( i=0;i<4;i++){
             for (j=0;j<4;j++){
                 printf("%c", map[i][j]);
             }
             printf("\n");
         }
 */
         
 
 
         printf("Case #%d: ", t);
         c = 'X';
         ans = check_win(map);        
         if (ans == 1){
             printf("X won\n");         
             continue;
         }
         c = 'O';
         ans = check_win(map);        
         if (ans == 1){
             printf("O won\n");         
             continue;
         }
         ans = check_not_complete(map);        
         if (ans == 1){
             printf("Game has not completed\n");         
             continue;
         }
 
         printf("Draw\n"); 
     }
     return 0;
 }
 int check_not_complete (char map[4][4]){
     int i,j;
         for ( i=0;i<4;i++){
 
             for (j=0;j<4;j++){
                 if (map[i][j] == '.' ){
                     return 1;
                     }
             }
         }
         return 0;
                                               
     
 }
 int check_win (char  map[4][4] ){
     int i,j;
 //    printf("c is %c\n", c);
         int win = 0;      
 //        printf("Check row\n"); 
         for ( i=0;i<4;i++){
             win = 1;
 //            printf("Check row [%d]\n",i);
             for (j=0;j<4;j++){
                 if (map[i][j] != c && map[i][j] != 'T' ){
                      win=0;
                 }                
             }
             if (win == 1){
                 return 1;
             }
         }
 //                printf("Check col\n");
         for ( j=0;j<4;j++){
             win = 1;
             for (i=0;i<4;i++){
                 if (map[i][j] != c && map[i][j] != 'T' ){
                      win=0;
                 }                
             }
             if (win == 1){
                 return 1;
             }
         }
 //        printf("Check i==j\n");
         win = 1;
         for ( i=0;i<4;i++){
                 j=i;
                 if (map[i][j] != c && map[i][j] != 'T' ){
 //                      printf("mat match map[%d][%d] is [%c]\n",i,j,map[i][j]);
                      win=0;
                 }                
         }
             if (win == 1){
                 return 1;
             }
 //        printf("Check j=3-i\n");
         win = 1;
         for ( i=0;i<4;i++){
                 j=3-i;
                 if (map[i][j] != c && map[i][j] != 'T' ){
                      win=0;
                 }                
         }
             if (win == 1){
                 return 1;
             }
 
 
         return 0;
 }        
 //void cal_max_inc_num (int* height,int* max_inc_num,int n){
 //void cal_max_inc_num (int[] height,int[] max_inc_num,int n){     
 int cal_max_inc_num (int height[],int max_inc_num[],int n){          
      int i;
      int max = 0;
      for (i=0;i<n;i++){
          if ( height[i] < height[n] && max < max_inc_num[i]){
               max = max_inc_num[i];
          }
      }
      max_inc_num[n] = max + 1;
 //     return max_inc_num+1;
      return 0;  
 }

