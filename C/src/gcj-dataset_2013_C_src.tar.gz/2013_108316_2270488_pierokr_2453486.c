#include <stdio.h>
 
 int main() {
 	int xrow[4],xcol[4],orow[4],ocol[4],dot=0,i,j,flag1,flag2,T,k=0,xdiag[2],odiag[2],flag3,flag4,flag5,flag6;
 	char val,arr[4][4];
 	FILE *fp;
 	
 	fp=fopen("A-small-attempt0.in","r");
 	fscanf(fp,"%d",&T);
 
 	for(k=0;k<T;k++) {
 
 		for(i=0;i<4;i++) {
 		xrow[i]=0; xcol[i]=0; orow[i]=0; ocol[i]=0;
 	}
 	flag1=0;flag2=0;dot=0;flag3=0;flag4=0;flag5=0;flag6=0;
 	
 	for(i=0;i<4;i++) {
 		for(j=0;j<4;j++) {
 			fscanf(fp,"%c",&val);
 			if(val=='\n')
 				j--;
 		else {
 				arr[i][j]=val;
 			  if(val=='X') {
 				orow[i]=1; ocol[j]=1;
 				}
 			  else if(val=='O') {
 				xrow[i]=1; xcol[j]=1;
 			  }
 			  else if(val=='.') {
 				orow[i]=1; ocol[j]=1; xrow[i]=1; xcol[j]=1;
  				dot=1;
 			  }
 		   }
 		}
 	}
 	for(i=0;i<4;i++) {
 		if(arr[i][i]!='T' && arr[i][i]!='X')
 			flag3=1;
 		if(arr[i][i]!='T' && arr[i][i]!='O')
 			flag4=1;
 		}
 	int a=0;
 	for(i=3;i>=0;i--) {
 		if(arr[a][i]!='T' && arr[a][i]!='X')
 			flag5=1;
 		if(arr[a][i]!='T' && arr[a][i]!='O')
 			flag6=1;
 	a++;
 	}
 
 			for(i=0;i<4;i++) {
 			if(xrow[i]==0 || xcol[i]==0 || flag3==0 || flag5==0) {
 				printf("Case #%d: X won\n",k+1); flag1=1; break;
 			}
 			else if(orow[i]==0 || ocol[i]==0 || flag4==0 || flag6==0) {
 				printf("Case #%d: O won\n",k+1); flag2=1; break;
 			}
 		}
 
 		if(flag1==0 && flag2==0 && dot==0)
 			printf("Case #%d: Draw\n",k+1);
 		else if(flag1==0 && flag2==0 && dot==1)
 			printf("Case #%d: Game has not completed\n",k+1);
 }
 			fclose(fp);
 	return 0;
 }
