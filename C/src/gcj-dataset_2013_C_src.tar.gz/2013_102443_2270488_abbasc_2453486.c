#include <stdio.h>
 #include <stdbool.h>
 
 int main()
 {
     freopen("A-small-attempt2.in","r", stdin);
     freopen("ttt.txt","w",stdout);
 
     int t, i;
     scanf("%d", &t);
     for(i = 1;i <= t; i++)
     {
         char ttt[5][5],xno[3] = "XO";
         int countV[4] = {0}, countL[4] = {0};//0 = '.' , 1 = 'X', 2 = 'O', 3 = 'T';
         bool complete = true;
         char winner = ' ';
 
         int j,k,a = 0;
         for(j = 0;j < 4; j++)
             scanf("%s", ttt[j]);
 
         while(a < 2 && winner == ' ')
         {
             for(j = 0,k=0; j < 4;j++,k++)
             {
                 if(ttt[j][k] != xno[a] && ttt[j][k] != 'T')    break;
             }
             if(j == 4)  winner = xno[a];
 
             for(j = 0,k=3; j < 4;j++,k--)
             {
                 if(ttt[j][k] != xno[a] && ttt[j][k] != 'T')    break;
             }
 
             if(j == 4)  winner = xno[a];
             a++;
         }
 
         for(j = 0;j < 4; j++)
         {
             if(winner != ' ')   break;
 
             for(k = 0;k < 4;k++)
             {
                  switch(ttt[j][k])
                  {
                         case 'X':   countL[1]++; break;
                         case 'O':   countL[2]++; break;
                         case 'T':   countL[3]++; break;
                         default :   countL[0]++; complete = false; break;
                  };
                  switch(ttt[k][j])
                  {
                         case 'X':   countV[1]++; break;
                         case 'O':   countV[2]++; break;
                         case 'T':   countV[3]++; break;
                         default :   countV[0]++; complete = false; break;
                  };
 
             }
 
              if(countL[0] == 0)
              {
                  if(countL[1] + countL[3] == 4)
                     winner = 'X';
                  else if(countL[2] + countL[3] == 4)
                     winner = 'O';
              }
              if(countV[0] == 0)
              {
                  if(countV[1] + countV[3] == 4)
                     winner = 'X';
                  else if(countV[2] + countV[3] == 4)
                     winner = 'O';
              }
              for(k = 0; k < 4; k++)
             {
                 countV[k] = 0;
                 countL[k] = 0;
             }
         }
         if(winner == ' ')
         {
             if(complete)
                 printf("Case #%d: Draw\n", i);
             else
                 printf("Case #%d: Game has not completed\n", i);
         }
         else
             printf("Case #%d: %c won\n",i , winner);
         getchar();
     }
     return 0;
 }

