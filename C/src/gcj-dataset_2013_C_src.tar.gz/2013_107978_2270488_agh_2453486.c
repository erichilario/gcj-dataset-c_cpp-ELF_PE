#include <stdio.h>
 
 char a[4][5];
 
 int check(int fr, int fc, int dr, int dc, char P) {
   for (int i = 0; i < 4; ++i) {
     if (a[fr][fc] != P && a[fr][fc] != 'T')
       return 0;
     fr += dr;
     fc += dc;
   }
   return 1;
 }
 
 int checkWin(char P) {
   for (int i = 0; i < 4; ++i) {
     if (check(i, 0, 0, 1, P)) return 1;
     if (check(0, i, 1, 0, P)) return 1;
   }
   if (check(0, 0, 1, 1, P)) return 1;
   if (check(3, 0, -1, 1, P)) return 1;
   return 0;
 }
 
 void doit(int tid) {
   printf("Case #%d: ", tid);
   if (checkWin('X')) {
     printf("X won\n");
     return;
   }
   if (checkWin('O')) {
     printf("O won\n");
     return;
   }
   int dots = 0;
   for (int r = 0; r < 4; ++r)
     for (int c = 0; c < 4; ++c)
       if (a[r][c] == '.')
         ++dots;
   if (dots) {
     printf("Game has not completed\n");
     return;    
   }
   printf("Draw\n");
 }
 
 int main() {
   int tests;
   scanf("%d", &tests);
   for (int test = 1; test <= tests; ++test) {
     scanf("\n");
     for (int r = 0; r < 4; ++r) {
       for (int c = 0; c < 4; ++c)
         scanf("%c", &a[r][c]);
       scanf("\n");
     }
 
 
     doit(test);
   }
 
   return 0;
 }
