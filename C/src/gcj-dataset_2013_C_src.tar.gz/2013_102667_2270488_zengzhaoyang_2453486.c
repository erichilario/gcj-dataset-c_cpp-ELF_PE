#include <stdio.h>
 #include <string.h>
 int main(){
     int t;
     scanf("%d",&t);
     getchar();
     int iiii;
     for(iiii=1;iiii<=t;iiii++){
         char a[4][100];
         int i,j;
         for(i=0;i<4;i++)
             gets(a[i]);
         char b[1000];
         gets(b);
         int hang[2][4],lie[2][4];
         memset(hang,0,sizeof(hang));
         memset(lie,0,sizeof(lie));
         for(i=0;i<4;i++)
             for(j=0;j<4;j++){
                 if(a[i][j]=='X')
                     hang[0][i]++;
                 if(a[i][j]=='O')
                     hang[1][i]++;
                 if(a[i][j]=='T'){
                     hang[0][i]++;
                     hang[1][i]++;
                 }
             }
         for(i=0;i<4;i++)
             for(j=0;j<4;j++){
                 if(a[j][i]=='X')
                     lie[0][i]++;
                 if(a[j][i]=='O')
                     lie[1][i]++;
                 if(a[j][i]=='T'){
                     lie[0][i]++;
                     lie[1][i]++;
                 }
             }
         int count=0;
         for(i=0;i<4;i++)
             for(j=0;j<4;j++)
                 if(a[i][j]!='.')
                     count++;
         int flag=0;
         if((a[0][0])=='X'||(a[0][0]=='T'))
             if((a[1][1])=='X'||(a[1][1]=='T'))
                 if((a[2][2])=='X'||(a[2][2]=='T'))
                     if((a[3][3])=='X'||(a[3][3]=='T'))
                         flag=1;
         if((a[0][0])=='O'||(a[0][0]=='T'))
             if((a[1][1])=='O'||(a[1][1]=='T'))
                 if((a[2][2])=='O'||(a[2][2]=='T'))
                     if((a[3][3])=='O'||(a[3][3]=='T'))
                         flag=2;
         if((a[0][3])=='X'||(a[0][3]=='T'))
             if((a[1][2])=='X'||(a[1][2]=='T'))
                 if((a[2][1])=='X'||(a[2][1]=='T'))
                     if((a[3][0])=='X'||(a[3][0]=='T'))
                         flag=1;
         if((a[0][3])=='O'||(a[0][3]=='T'))
             if((a[1][2])=='O'||(a[1][2]=='T'))
                 if((a[2][1])=='O'||(a[2][1]=='T'))
                     if((a[3][0])=='O'||(a[3][0]=='T'))
                         flag=2;
         for(i=0;i<4;i++)
             if(hang[0][i]==4){
                 flag=1;
                 break;
             }
         for(i=0;i<4;i++)
             if(lie[0][i]==4){
                 flag=1;
                 break;
 
             }
         for(i=0;i<4;i++)
             if(hang[1][i]==4){
                 flag=2;
                 break;
             }
         for(i=0;i<4;i++)
             if(lie[1][i]==4){
                 flag=2;
                 break;
             }
         printf("Case #%d: ",iiii);
         if(flag==1)
             printf("X won");
         if(flag==2)
             printf("O won");
         if(flag==0&&count==16)
             printf("Draw");
         if(flag==0&&count<16)
             printf("Game has not completed");
         if(iiii!=t)
             printf("\n");
     }
 }
