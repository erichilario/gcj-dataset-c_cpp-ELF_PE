#include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
 #include<math.h>
 int main()
 {
 
     int t=1,a,b,x,i,r,p,f=1,g=1;
     char *s,*s1,*s2,*s3;
     FILE *f1,*f2;
     f1=fopen("data.in","r");
     f2=fopen("output.txt","w");
     fscanf(f1,"%d",&r);
   //  fflush(stdin);
     while(t<=r)
     {
         x=0;
         fscanf(f1,"%d %d",&a,&b);
         s=(char*)malloc(sizeof(char)*b);
         s1=(char*)malloc(sizeof(char)*b);
         s2=(char*)malloc(sizeof(char)*b);
         s3=(char*)malloc(sizeof(char)*b);
         for(i=a;i<=b;i++)
         {
             if((int)sqrt(i)== sqrt(i))
             {
                 if(i<10)
                 {
                     x++;
                 }
                 else
                 {
                      itoa(i,s,10);
                     p=abs(sqrt(i));
                     itoa(p,s1,10);
                     s2=strdup(s);
                     s3=strdup(s1);
 
                     f=strcmp(strrev(s),s2);
                     g=strcmp(strrev(s1),s3);
 
                     if(f==0 &&g==0)
                        {
                        x++;
 
                        }
 
                 }
             }
         }
         fprintf(f2,"Case #%d: %d\n",t,x);
 
         t++;
     }
     fclose(f1);fclose(f2);
 
     return 0;
 }

