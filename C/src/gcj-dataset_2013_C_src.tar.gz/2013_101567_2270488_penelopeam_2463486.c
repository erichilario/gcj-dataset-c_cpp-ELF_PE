#include<stdio.h>
 #include<stdlib.h>
 
 int main(int argc, char* argv[])
 {
     int n, a, b, ans;
     int i=1;
     scanf("%d", &n);
     while(i<=n){
         ans=0;
         scanf(" %d %d", &a, &b);
         if( a== 1){
             if(b >=484)
                 ans=4;
             else if (b >= 121)
                 ans=3;
             else if (b>=4)
                 ans=2;
             else ans=1;
         }
         else if (a <=4){
             if(b >=484)
                 ans=3;
             else if (b >= 121)
                 ans=2;
             else if (b>=4)
                 ans=1;
         }
         else if(a<=121){
             if(b >=484)
                 ans=2;
             else if (b >= 121)
                 ans=1;
         }
         else if(a<=484) ans=1;
         if(a==b) ans=0;
         printf("Case #%d: %d\n", i, ans);
         i++;
     }
 
     return 0;
 }

