#include<cstdio>
 
 
 
 char** read_next() {
     char** prob = new char*[4];
     for(int i = 0; i < 4; ++i) {
         prob[i] = new char[4];
         scanf("%s\n", prob[i]);
         //printf("%s", prob[i]);
     }
     scanf("\n");
     return prob;
 }
 
 int check_won(char c, char** prob){
 
     int won = 0;
     // rows
     for(int i = 0; i <  4; ++i) {
         for(int j = 0; j < 4; ++j) {
             if(prob[i][j] != c && prob[i][j] != 'T') {
                 break;
             } else if(j == 3) {
                 return 1;
             }
         }
     }
 
     // cols
     for(int i = 0; i <  4; ++i) {
         for(int j = 0; j < 4; ++j) {
             if(prob[j][i] != c && prob[j][i] != 'T') {
                 break;
             } else if(j == 3) {
                 return 1;
             }
         }
     }
 
     // diag
     for(int i = 0; i <  4; ++i) {
 
         if(prob[i][i] != c && prob[i][i] != 'T') {
             break;
         } else if(i == 3) {
             return 1;
         }
     }
 
     for(int i = 0; i <  4; ++i) {
 
         if(prob[i][3-i] != c && prob[i][3-i] != 'T') {
             break;
         } else if(i == 3) {
             return 1;
         }
     }
 
     return 0;
 }
 
 int eval_prob(char** prob) {
     if(check_won('X', prob) == 1) {
         return 0;
     } else if(check_won('O', prob)==1) {
         return 1;
     }else {
         // draw or incomplete
 
 
         for(int i = 0; i < 4; ++i) {
             for(int j = 0; j < 4; ++j) {
                 if(prob[i][j] == '.') {
                     return 3;
                 }
             }
         }
         return 2;
     }
 
 
 //    return 0;
 }
 
 int main() {
 
     int num_ex;
     scanf("%d", &num_ex);
 
     for(int p = 1; p <= num_ex; ++p) {
         char** prob = read_next();
         int res = eval_prob(prob);
         printf("Case #%d: ", p);
         switch(res) {
             case 0:
                 printf("X won");
                 break;
             case 1:
                 printf("O won");
                 break;
             case 2:
                 printf("Draw");
                 break;
             case 3:
                 printf("Game has not completed");
                 break;
             default:
                 break;
         }
         printf("\n");
 
     }
 }

