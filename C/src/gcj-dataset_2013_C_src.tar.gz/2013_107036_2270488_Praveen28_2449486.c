#include<stdio.h>
 int main()
 {
 	int i,j,k,n,m,t,nomatch,arr[11][11],cnt;
 	FILE *fin,*fo;
 	fin = fopen("inp.in","r");
 	fo = fopen("outp.txt","w");
 	fscanf(fin,"%d",&t);
 	cnt = 1;
 	while(t--)
 	{
 		nomatch=0;
 		fscanf(fin,"%d %d",&n,&m);
 		for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				fscanf(fin,"%d",&arr[i][j]);
 			}
 		}
 		for(i=0;i<n;i++)
 		{
 			nomatch=0;
 			for(j=0;j<m;j++)
 			{
 				if(arr[i][j]==1)
 				{
 					for(k=0;k<m;k++)
 					{
 						if(arr[i][k]==1)
 						{
 							nomatch=0;
 						}
 						else
 						{
 							nomatch=1;
 							break;
 						}
 					}
 					if(nomatch==1)
 					{
                         nomatch=0;
 						for(k=0;k<n;k++)
 						{
 							if(arr[k][j]==1)
 							{
 								nomatch=0;
 							}
 							else
 							{
 								nomatch=1;
 								break;
 							}
 						}
 					}
 					if(nomatch==1)
 					{
 						fprintf(fo,"Case #%d: NO\n",cnt++);
 						break;
 					}
 				}
 			}
 			if(nomatch==1)
 			{
 				break;
 			}	
 		}
 		if(nomatch==0)
 		{
 			fprintf(fo,"Case #%d: YES\n",cnt++);
 		}
 		
 	}
 }

