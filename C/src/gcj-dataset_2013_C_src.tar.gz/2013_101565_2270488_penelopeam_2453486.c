#include<stdio.h>
 #include<stdlib.h>
 
 int main(int argc, char* argv[])
 {
     int i,j,k,n;
     char tab[4][4];
     int ncomp, win, co, ct, cx;
 
     scanf("%d", &n);
     k=1;
     while(k<=n)
     {   win=0;
         ncomp=0;
         for(i=0; i<4; i++)
         {
             co=0;
             ct=0;
             cx=0;
             for(j=0; j<4; j++)
             {
                 scanf(" %c", &tab[i][j]);
                 if(tab[i][j]=='.')
                     ncomp=1;
                 if(tab[i][j]=='X')
                     cx++;
                 if(tab[i][j]=='O')
                     co++;
                 if(tab[i][j]=='T')
                     ct++;
             }
             if(cx==4 || (cx==3 && ct==1))
                 win=1;
             if(co==4 || (co==3 && ct==1))
                 win=2;
         }
 
         for(j=0; j<4; j++)
         {
             co=0;
             ct=0;
             cx=0;
             for(i=0; i<4; i++)
             {   if(tab[i][j]=='.')
                     ncomp=1;
                 if(tab[i][j]=='X')
                     cx++;
                 if(tab[i][j]=='O')
                     co++;
                 if(tab[i][j]=='T')
                     ct++;
             }
             if(cx==4 || (cx==3 && ct==1))
                 win=1;
             if(co==4 || (co==3 && ct==1))
                 win=2;
         }
         co=0;
         ct=0;
         cx=0;
         for(i=0; i<4; i++){
             if(tab[i][i]=='.')
                 ncomp=1;
             if(tab[i][i]=='X')
                 cx++;
             if(tab[i][i]=='O')
                 co++;
             if(tab[i][i]=='T')
                 ct++;
             }
         if(cx==4 || (cx==3 && ct==1))
             win=1;
         if(co==4 || (co==3 && ct==1))
             win=2;
                 co=0;
         ct=0;
         cx=0;
         for(i=0; i<4; i++){
             if(tab[i][3-i]=='.')
                 ncomp=1;
             if(tab[i][3-i]=='X')
                 cx++;
             if(tab[i][3-i]=='O')
                 co++;
             if(tab[i][3-i]=='T')
                 ct++;
             }
         if(cx==4 || (cx==3 && ct==1))
             win=1;
         if(co==4 || (co==3 && ct==1))
             win=2;
 
 
 
         printf("Case #%d: ", k);
         k++;
         if(win==1)
             printf("X won\n");
         else if(win==2)
             printf("O won\n");
         else if( ncomp==1)
             printf("Game has not completed\n");
         else
             printf("Draw\n");
     }
 
     return 0;
 }

