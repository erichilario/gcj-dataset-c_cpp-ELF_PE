#include<stdio.h>
 #include<stdlib.h>
 #include<math.h>
 
 int c,*sol;
 
 int palin(int z)
 {
 	int l,m=0;
 	for(l=z;l!=0;l/=10)
 	{
 		m*=10;
 		m+=(l%10);
 	}
 	
 	if(z==m)
 		return 1;
 	else
 		return 0;
 }
 void input()
 {
 	int a,b,count=0,p;
 	scanf("%d %d",&a,&b);
 	for(p=a;p<=b;p++)
 	{
 		if(!((int)sqrt(p)-sqrt(p)))
 		{
 			if(palin(p) && palin(sqrt(p)))
 			{
 				count++;
 			}
 		}
 	}
 	*(sol+c)=count;
 	return;
 }
 
 	
 int main ()
 {
 	int t;
 	scanf("%d",&t);
 	sol=(int*)malloc(t*sizeof(int));
 	for(c=0;c<t;c++)
 	{
 		*(sol+c)=0;
 		input();
 	}
 	for(c=0;c<t;c++)
 		printf("Case #%d: %d\n",c+1,*(sol+c));
 	return 0;
 }

