#include <assert.h>
 #include <stdbool.h>
 #include <stdio.h>
 
 static bool testBoard(int rows, int cols, int *board);
 
 int main(void)
 {
     int T, x;
     scanf("%d", &T);
     for (x = 1; x <= T; x++) {
         int rows, cols;
         int i, j;
 
         scanf("%d %d", &rows, &cols);
         int board[rows][cols];
         for (i = 0; i < rows; i++)
             for (j = 0; j < cols; j++)
                 scanf("%d", &board[i][j]);
 
         /*
         for (i = 0; i < rows; i++) {
             for (j = 0; j < cols; j++)
                 fprintf(stderr, "%d ", board[i][j]);
             fprintf(stderr, "\n");
         }
         */
 
         bool y = testBoard(rows, cols, &board[0][0]);
         printf("Case #%d: %s\n", x, y ? "YES" : "NO");
     }
 
     return 0;
 }
 
 static bool testBoard(int rows, int cols, int *board)
 {
     assert(rows >= 1);
     assert(cols >= 1);
     #define cell(r,c) board[(r)*cols + (c)]
 
     int i, j;
     int r_min[rows]; // row i must be mowed no lower than r_min[i]
     int c_eq[cols];  // col i must be mowed to exactly c_eq[j],
                      // unless c_eq[j] == -1
     int r_eq[cols];  // row i must be mowed to exactly r_eq[i],
                      // unless r_eq[i] == -1
 
     for (i = 0; i < rows; i++)
         r_min[i] = 100;
     for (j = 0; j < cols; j++)
         c_eq[j] = -1;
     for (i = 0; i < rows; i++)
         r_eq[i] = -1;
 
     for (i = 0; i < rows; i++) {
         // Find max height in this row.
         int m = 0;
         for (j = 0; j < cols; j++)
             if (m < cell(i, j))
                 m = cell(i, j);
 
         // Can't mow this row lower than 'm', or it will clip some of this
         // row's blades too low.
         r_min[i] = m;
 
         for (j = 0; j < cols; j++) {
             int h = cell(i, j);
             if (m > h) {
                 // Column 'j' must be mowed to exactly height 'h'.
                 if (c_eq[j] == -1 || c_eq[j] == h)
                     c_eq[j] = h;
                 else {
                     // Previous row constrained this column to a
                     // different height.
                     // fprintf(stderr, "(%d,%d): Previous row constrained this column to mow height == %d\n", i, j, c_eq[j]);
                     return false;
                 }
             }
         }
     }
 
     for (j = 0; j < cols; j++) {
         // Find max height in this col.
         int m = 0;
         for (i = 0; i < rows; i++)
             if (m < cell(i, j))
                 m = cell(i, j);
 
         // Can't mow this col lower than 'm', or it will clip some of this
         // col's blades too low.
         if (c_eq[j] != -1 && c_eq[j] < m) {
             // fprintf(stderr, "(*,%d): can't mow this column lower than %d\n", j, m);
             return false;
         }
 
         for (i = 0; i < rows; i++) {
             int h = cell(i, j);
             if (m > h) {
                 // Row 'i' must be mowed to exactly height 'h'.
                 if (r_eq[i] == -1 || r_eq[i] == h)
                     r_eq[i] = h;
                 else {
                     // Previous column constrained this row to a
                     // different height.
                     // fprintf(stderr, "(%d,%d): previous column constrained this row to height %d\n", i, j, r_eq[i]);
                     return false;
                 }
 
                 if (h < r_min[i]) {
                     return false;
                 }
             }
         }
     }
 
     #undef cell
     
     return true;
 }

