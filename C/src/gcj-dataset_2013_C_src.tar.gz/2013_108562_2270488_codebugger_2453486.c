/* 
 6															Case #1: X won
 XXXT														Case #2: Draw
 ....														Case #3: Game has not completed
 OO..														Case #4: O won
 ....														Case #5: O won
 															Case #6: O won
 XOXT
 XXOO
 OXOX
 XXOO
 
 XOX.
 OX..
 ....
 ....
 
 OOXX
 OXXX
 OX.T
 O..O
 
 XXXO
 ..O.
 .O..
 T...
 
 OXXX
 XO..
 ..O.
 ...O
 */
 
 # include <stdio.h>
 
 char m[4][4];
 int l, s ;
 int testX () {
 	
 	for (l=0; l<4; ++l) {
 		if ((m[l][0]=='T'||m[l][0]=='X') && 
 			(m[l][1]=='T'||m[l][1]=='X') &&
 			(m[l][2]=='T'||m[l][2]=='X') &&
 			(m[l][3]=='T'||m[l][3]=='X'))
 		{
 			return 1 ;
 		}
 	}
 	
 	if ((m[0][0] == 'T'||m[0][0] == 'X') && 
 		(m[1][1] == 'T'||m[1][1] == 'X') && 
 		(m[2][2] == 'T'||m[2][2] == 'X') && 
 		(m[3][3] == 'T'||m[3][3] == 'X' ))
 	{
 		return 1 ;
 	}
 	
 	if ((m[0][3] == 'T'||m[0][3] == 'X') && 
 		(m[1][2] == 'T'||m[1][2] == 'X') && 
 		(m[2][1] == 'T'||m[2][1] == 'X') && 
 		(m[3][0] == 'T'||m[3][0] == 'X' ))
 	{
 		return 1 ;
 	}
 	
 	for (l=0; l<4; ++l) {
 		//for (s=0; s<4; ++s) {
 			if((m[0][l]=='T'||m[0][l]=='X')&&(m[1][l]=='T'||m[1][l]=='X')&&(m[2][l]=='T'||m[2][l]=='X')&&(m[3][l]=='T'||m[3][l]=='X'))
 			{
 				return 1 ;
 			}
 		//}
 	}
 	
 	return 0 ;
 }
 
 int testO () {
 	 
 	for (l=0; l<4; ++l) {
 		if ((m[l][0] == 'T'||m[l][0] == 'O') && 
 			(m[l][1] == 'T'||m[l][1] == 'O') && 
 			(m[l][2] == 'T'||m[l][2] == 'O') && 
 			(m[l][3] == 'T'||m[l][3] == 'O' ))
 		{
 			return 1 ;
 		}
 	}
 	
 	if ((m[0][0] == 'T'||m[0][0] == 'O') && 
 		(m[1][1] == 'T'||m[1][1] == 'O') && 
 		(m[2][2] == 'T'||m[2][2] == 'O') && 
 		(m[3][3] == 'T'||m[3][3] == 'O' ))
 	{
 		return 1 ;
 	}
 	
 	if ((m[0][3] == 'T'||m[0][3] == 'O') && 
 		(m[1][2] == 'T'||m[1][2] == 'O') && 
 		(m[2][1] == 'T'||m[2][1] == 'O') && 
 		(m[3][0] == 'T'||m[3][0] == 'O' ))
 	{
 		return 1 ;
 	}
 	
 	for (l=0; l<4; ++l) {
 		//for (s=0; s<4; s++) {
 			if ((m[0][l]=='T'||m[0][l]=='O') && 
 			(m[1][l]=='T'||m[1][l]=='O') &&
 			(m[2][l]=='T'||m[2][l]=='O') &&
 			(m[3][l]=='T'||m[3][l]=='O'))
 			{
 				return 1 ;
 			}
 		//}
 	}
 	
 	return 0 ;
 }
 
 int draw () {
 
 	int f=0 ;
 	for (l=0; l<4; ++l){
 		if (f == 1)
 			break ;
 		for (s=0; s<4; ++s) {
 			if (m[l][s] == '.'){
 				f = 1;
 				break ;
 			}
 		}
 	}
 	
 	if (l==4 && s==4)
 		return 1 ;
 	else
 		return 0 ;
 }
 
 
 int main () {
 
 	int casen[1000] ;
 	int t ;
 	int i, j, k ;
 
 	scanf ("%d", &t) ;
 	
 	for (i=0; i<t; i++) {
 		for (j=0; j<4; j++) {
 			//for (k=0; k<4; k++) {
 				fflush (stdin) ;
 				scanf(" %[^\n]",m[j]);
 			//}
 		}
 		
 		if (testX())
 			{casen[i] = 1 ;
 				}
 		else if (testO())
 			casen[i] = 2 ;
 		else if (draw ())
 			casen[i] = 0 ;
 		else
 			casen[i] = -1 ;
 	}
 	
 	for (i=0; i<t; ++i) {
 		if (casen[i] == 1)
 			printf ("Case #%d: X won\n", i+1) ;
 		else if (casen[i] == 2)
 			printf ("Case #%d: O won\n", i+1) ;
 		else if (casen[i] == 0)
 			printf ("Case #%d: Draw\n", i+1) ;
 		else
 			printf ("Case #%d: Game has not completed\n", i+1) ;
 	}
 	
 
 	return 0 ;
 }

