#include <stdio.h>
 #include <stdlib.h>
 
 int kWinX1 = 'X' + 'X' + 'X' + 'X';
 int kWinX2 = 'X' + 'X' + 'X' + 'T';
 int kWinO1 = 'O' + 'O' + 'O' + 'O';
 int kWinO2 = 'T' + 'O' + 'O' + 'O';
 
 int Judge(int x) {
 	if (x == kWinX1 || x == kWinX2) return 1;
 	else if (x == kWinO1 || x == kWinO2) return 2;
 	else return 0;
 }
 
 int main(void) {
 	int T, cnt = 1;
 	int i, j;
 	int res, sum;
 	char board[4][5];
 
     freopen("A-small-attempt0.in", "r", stdin);
     freopen("A-small.out", "w", stdout);
 
 	scanf("%d", &T);
 	while(T--) {
 		res = 4;
 		for (i = 0; i < 4; ++i) scanf("%s", board[i]);
 		for ( i = 0; i < 4; ++i) {
 			sum = board[i][0] + board[i][1] + board[i][2]+ board[i][3];
 			if (Judge(sum))	res = Judge(sum);
 		}
 		for (i = 0; i < 4; ++i) {
 			sum = board[0][i] + board[1][i] + board[2][i]+ board[3][i];
 			if (Judge(sum))	res = Judge(sum);
 		}
 		sum = board[0][0] + board[1][1] + board[2][2]+ board[3][3];
 		if (Judge(sum))	res = Judge(sum);
 		sum = board[0][3] + board[1][2] + board[2][1]+ board[3][0];
 		if (Judge(sum))	res = Judge(sum);
 		if (res == 4) {
 			for (i = 0; i < 4; ++i)
 				for (j = 0; j < 4; ++j)
 					if (board[i][j] == '.')
 						res = 3;
 		}
 		if (res == 4) printf("Case #%d: Draw\n", cnt++);
 		if (res == 3) printf("Case #%d: Game has not completed\n", cnt++);
 		if (res == 2) printf("Case #%d: O won\n", cnt++);
 		if (res == 1) printf("Case #%d: X won\n", cnt++);
 		gets(board[0]);
 	}
 	fclose(stdin);
 	fclose(stdout);
 	return 0;
 }

