#include<stdio.h>
 #include<math.h>
 int palin(long long int);
 void main()
 {
    	long long int j,x2,x3,x5,A,B,x6;FILE *ptr;
    	
    	int T,i,x1,x4;char skip[2];
 	
 	ptr=fopen("a.txt","r");
        //freopen("1.txt","r",stdin);
       freopen("Output.txt","w",stdout);
 	
 	fscanf(ptr,"%d",&T);
 	for(i=1;i<=T;i++)
 	{ x3=0;x5=0;x6=0;
 	   fgets(skip,2,ptr);
 	  fscanf(ptr,"%lld %lld",&A,&B);
 	  x6=sqrt(A)+1;
 	  x3=sqrt(B);
 	  for(j=1;j<=x3;j++)
 	  { 
 	    x1=palin(j);
 	    if(x1==0)
 	    continue;
 	  	x2=j*j;
 	  	x4=palin(x2);
 	  	if(x4==1 && x2>=A)
 	  	{
 	  	   x5++;			  	
 	  	}	  	
 	  }
 	  printf("Case #%d: %lld\n",i,x5);
 	}	
 }
 int palin(long long int a)
 {
 	long long int x1,x2,x3=0;
 	x1=a;
 	while(x1!=0)
 	{
 		x2=x1%10;
 		x3=x2+x3*10;
 		x1=x1/10;
 	}
 	if(x3==a)
 	return 1;
 	else
 	return 0;
 }

