#include <stdio.h>
 #include <stdlib.h>
 #include <stdbool.h>
 
 bool checkSum(int** tab, int size, int sum);
 
 bool checkSum(int** tab, int size, int sum) {
   // check rows and columns
   for (int i = 0; i < size; i++) {
     int rowSum = 0;
     int colSum = 0;
     
     for (int j = 0; j < size; j++) {
       rowSum += tab[i][j];
       colSum += tab[j][i];
     }
     
     if (rowSum == sum || colSum == sum) {
       return true;
     }
   }
 
   // check diagonals
   int sumDiag1 = 0;
   int sumDiag2 = 0;
   
   for (int i = 0; i < size; i++) {
     sumDiag1 += tab[i][i];
     sumDiag2 += tab[i][size - 1 - i];
   }
   
   if (sumDiag1 == sum || sumDiag2 == sum) {
     return true;
   }
 
   return false;
 }
 
 int main(int argc, char **argv) {
   const char* filename = "A-small-attempt0.in";
   FILE *fp;
   fp = fopen(filename, "r");
   char c;
   char s[10];
   fscanf(fp, "%s\n", s);
   const int T = atoi(s);
   const int SIZE = 4;
 
   int ** tabx = malloc(SIZE * sizeof(int*));
   for (int i = 0; i < SIZE; i++) {
     tabx[i] = malloc(SIZE * sizeof(int));
   }
 
   int ** tabo = malloc(SIZE * sizeof(int*));
   for (int i = 0; i < SIZE; i++) {
     tabo[i] = malloc(SIZE * sizeof(int));
   }
 
   for (int t = 1; t <= T; t++) {
 
     bool xWon = false;
     bool oWon = false;
     bool complete = true;
 
     for (int i = 0; i < SIZE; i++) {
       for (int j = 0; j < SIZE; j++) {
 	fscanf(fp, "%c", &c);
 	switch (c) {
 	case '.':
 	  tabx[i][j] = 0;
 	  tabo[i][j] = 0;
 	  complete = false;
 	  break;
 	case 'X':
 	  tabx[i][j] = 1;
 	  tabo[i][j] = 1;
 	  break;
 	case 'O':
 	  tabx[i][j] = SIZE + 1;
 	  tabo[i][j] = SIZE + 1;
 	  break;
 	case 'T':
 	  tabx[i][j] = 1;
 	  tabo[i][j] = SIZE + 1;
 	  break;
 	default:
 	  printf("error\n");
 	}
       }
       fscanf(fp, "\n");
     }
     fscanf(fp, "\n");
     
     xWon = checkSum(tabx, SIZE, SIZE);
     oWon = checkSum(tabo, SIZE, SIZE * (SIZE + 1));
 
     if (!xWon && !oWon && complete) {
       printf("Case #%d: Draw\n", t);
     }
     else if (!xWon && !oWon && !complete) {
       printf("Case #%d: Game has not completed\n", t);
     }
     else if (xWon) {
       printf("Case #%d: X won\n", t);
     }
     else if (oWon) {
       printf("Case #%d: O won\n", t);
     }
     else {
       printf("ERROR\n");
     }
   }
 
   for (int i = 0; i < SIZE; i++) {
     free(tabx[i]);
     free(tabo[i]);
   }
   free(tabx);
   free(tabo);
 
   return 0;
 }

