#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 char verifica(char **t) {
 	int i, j, tP = 0, l = -1, c = -1;
 	for (i = 0; i < 4; ++i) {
 		for (j = 0; j < 4; ++j) {
 			if (t[i][j] == '.') {
 				tP = 1;
 				if (l >= 0) {
 					break;
 				}
 			}
 			if (t[i][j] == 'T') {
 				l = i;
 				c = j;
 				if (tP) {
 					break;
 				}
 			}
 		}
 	}
 	if (l >= 0) { t[l][c] = 'X'; }
 	if (t[0][0] != '.' && t[0][0] == t[1][1] && t[1][1] == t[2][2] && t[2][2] == t[3][3]) { return t[0][0]; }
 	if (t[3][0] != '.' && t[3][0] == t[2][1] && t[2][1] == t[1][2] && t[1][2] == t[0][3]) { return t[3][0]; }
 	for (i = 0; i < 4; ++i) {
 		if (t[i][0] != '.' && t[i][0] == t[i][1] && t[i][1] == t[i][2] && t[i][2] == t[i][3]) { return t[i][0]; }
 	}
 	for (i = 0; i < 4; ++i) {
 		if (t[0][i] != '.' && t[0][i] == t[1][i] && t[1][i] == t[2][i] && t[2][i] == t[3][i]) { return t[0][i]; }
 	}
 	if (l >= 0) { t[l][c] = 'O'; }
 	if (t[0][0] != '.' && t[0][0] == t[1][1] && t[1][1] == t[2][2] && t[2][2] == t[3][3]) { return t[0][0]; }
 	if (t[3][0] != '.' && t[3][0] == t[2][1] && t[2][1] == t[1][2] && t[1][2] == t[0][3]) { return t[3][0]; }
 	for (i = 0; i < 4; ++i) {
 		if (t[i][0] != '.' && t[i][0] == t[i][1] && t[i][1] == t[i][2] && t[i][2] == t[i][3]) { return t[i][0]; }
 	}
 	for (i = 0; i < 4; ++i) {
 		if (t[0][i] != '.' && t[0][i] == t[1][i] && t[1][i] == t[2][i] && t[2][i] == t[3][i]) { return t[0][i]; }
 	}
 	return (tP) ? '-' : 'D';
 }
 
 int main(int argc, char *argv[]) {
 	FILE *fr = fopen("input.txt", "r");
 	FILE *fw = fopen("output.txt", "w");
 	int i, j, total;
 	char resultado[32];
 	fscanf(fr, "%d", &total);
 	fgetc(fr);
 	for (i = 0; i < total; ++i) {
 		char **ttt;
 		ttt = (char**) malloc(4 * sizeof(char*));
 		for (j = 0; j < 4; ++j) {
 			ttt[j] = (char*) malloc(4 * sizeof(char));
 		}
 		for (j = 0; j < 4; ++j) {
 			fscanf(fr, "%c%c%c%c\n", &ttt[j][0], &ttt[j][1], &ttt[j][2], &ttt[j][3]);
 			//printf("%c %c %c %c\n", ttt[j][0], ttt[j][1], ttt[j][2], ttt[j][3]);
 		}
 		switch (verifica(ttt)) {
 			case 'D': strcpy(resultado, "Draw"); break;
 			case '-': strcpy(resultado, "Game has not completed"); break;
 			case 'X': strcpy(resultado, "X won"); break;
 			case 'O': strcpy(resultado, "O won"); break;
 		}
 		fprintf(fw, "Case #%d: %s\n", (i + 1), resultado);
 	}
 	return 0;
 }

