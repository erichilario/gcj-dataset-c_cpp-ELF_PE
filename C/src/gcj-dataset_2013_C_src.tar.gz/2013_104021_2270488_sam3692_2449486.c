# include<stdio.h>
 # include<conio.h>
 # include<string.h>
 # include<math.h>
 int  **a,n,m;
 int *r,*cl,t;
 FILE * out;
 
 void check(int qw )
 {
  int i,j,c=0,d=0,temp=0;
  for(c=0;c<n;c++)
 	{
 	for(d=0;d<m;d++)
 		{
 		if(a[c][d]>temp)
 		temp=a[c][d];
 		}
 	//printf("%d \n",temp);
 	r[c]=temp;
 	temp=0;
    }
  temp=0;
 	for(c=0;c<m;c++)
 	{
 		for(d=0;d<n;d++)
 		{
 		if(a[d][c]>temp)
 		temp=a[d][c];
 		}
 		//printf("%d \n",temp);
 	cl[c]=temp;
 	temp=0;
     }
 	temp=1;
 	for(i=0;i<n;i++)
 	{
 		for(j=0;j<m;j++)
 		{
 			if (a[i][j] != r[i] && a[i][j] != cl[j])
 			{
 				temp=0;
 				break;
 			}
 		}
 	}
 	if(temp==0)
 		//printf("Case #%d: NO\n",qw);
 		fprintf(out, "Case #%d: NO\n",qw);
 	else
 		//printf("Case #%d: YES\n",qw);
 		fprintf(out, "Case #%d: YES\n",qw);
 }
 	
 
 void main()
 {
 int b,i,j,k,l;
 
 FILE * fin = fopen("G:/WORK/SAMARTH JIIT/Placement Study/google/input.in", "r");
 out = fopen("G:/WORK/SAMARTH JIIT/Placement Study/google/out.txt", "w");
 fscanf(fin, "%d\n", &t);
 for(l=0;l<t;l++)
 {
   fscanf(fin,"%d %d\n", &n,&m);
   //printf("%d-%d\n",n,m);
    r = (int*)malloc(n * sizeof(int));
    cl = (int*)malloc(m * sizeof(int));
   a = (int**) malloc(n*sizeof(int*));  
  for (i = 0; i < n; i++)  
    a[i] = (int*) malloc(m*sizeof(int)); 
   for(i=0;i<n;i++)
 		{
 			for(j=0;j<m;j++)
 			{
 				if(j==m-1)
 					fscanf(fin, "%d\n", &a[i][j] );
 				else
 					fscanf(fin, "%d", &a[i][j] );
 			}
 		}
 //for(i=0;i<n;i++){for(j=0;j<m;j++){	printf("%d",a[i][j]);}printf("\n");	}
 check(l+1);
 }
 fclose(fin);
 fclose(out);
 getch();
 }

