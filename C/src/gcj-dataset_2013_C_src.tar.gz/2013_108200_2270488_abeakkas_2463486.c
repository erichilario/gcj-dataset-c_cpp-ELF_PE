#include <stdio.h>
 int ispalindrom(int u){
 	if(u<10) return 1;
 	int k=1;
 	while(u/k!=0){
 		k*=10;
 	}
 	if(u%10 != u/(k/10))
 	return 0;
 	return ispalindrom((u%(k/10)-u%10)/10);
 }
 int main(){
 	FILE *file1;
 	file1=fopen("C-small-attempt0.in","r");
 	FILE *file2;
 	file2=fopen("C-small-attempt0.out","w");
 	int T,A,B,i,k,n;
 	fscanf(file1,"%d",&T);
 	for(i=0;i<T;i++){
 		n=0;
 		fscanf(file1,"%d %d",&A,&B);
 		for(k=1;1;k++){
 			if(k*k<A) continue;
 			if(k*k>B) break;
 			if(ispalindrom(k) && ispalindrom(k*k)) n++;
 		}
 		fprintf(file2,"Case #%d: %d\n",i+1,n);
 	}
 	fclose(file2);
 	return 0;
 }

