#include<stdio.h>
 
 int main()
 {
   int t,i,j,k,n,m,l,o,mr,mc,p=0;
   int array[105][105];
   scanf("%d",&t);
   while(t--)
   {
     p++;
   
    scanf("%d %d",&n,&m);
   for(i=1;i<=n;i++)
    {
      for(j=1;j<=m;j++)
       {
          scanf("%d",&array[i][j]);
       }
    }
 
   for(i=1;i<=n;i++)
    {
      for(j=1;j<=m;j++)
       {
         
            mr=1,mc=1;
            for(l=1;l<=m;l++)
             {
               if(array[i][j]<array[i][l])
                 {
                      mr=0; 
                 }
                  
             }
      
            for(l=1;l<=n;l++)
              {
                if(array[i][j]<array[l][j])
                  {
                    mc=0;
                  }
              }
  
           if(mr==0 && mc==0)
             {
               printf("Case #%d: NO\n",p);
               goto z;
             }
       }
     }
    
 printf("Case #%d: YES\n",p);
 
 z:
 continue;
 }
 return 0;
 }
