/*
  * =====================================================================================
  *
  *       Filename:  problemB.c
  *
  *    Description:  google code jam problem B
  *
  *        Version:  1.0
  *        Created:  2013年04月13日 09时58分56秒
  *       Revision:  none
  *       Compiler:  gcc
  *
  *         Author:  梁涛 (suck_it), liangtao90s@gmail.com
  *   Organization:  
  *
  * =====================================================================================
  */
 
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 
 struct _lawn{
 		int i;
 		int j;
 		int h;
 		int trimed;
 };
 
 static struct _lawn lawn[101][101];
 static struct _lawn *lawnp[10002];
 static char dir[201];
 static int cmp(const void *_a, const void *_b)
 {
 		struct _lawn *a = *(struct _lawn **)_a;
 		struct _lawn *b = *(struct _lawn **)_b;
 		if (a->h != b->h)
 				return b->h - a->h;
 		else
 				return a->i - b->i;
 }
 
 
 static int trim(int m, int n)
 {
 		int i = 0, j, k;
 		int ret = 1;
 		for (i = 0; i < m * n; i++) {
 				struct _lawn *p = lawnp[i];
 				int h = p->h;
 				if (p->trimed)
 						continue;
 				j = p->i;
 				k = p->j;
 				if (dir[j] && dir[m + k]) {
 						ret = 0;
 						break;
 				}
 				if (!dir[j]) {
 						int i;
 						for (i = 0; i < n; i++)
 								if (lawn[j][i].h == h) {
 										lawn[j][i].trimed = 1;
 								}
 						dir[j] = 1;
 				}
 				if (!dir[m + k]) {
 						int i;
 						for (i = 0; i < m; i++)
 								if (lawn[i][k].h == h) {
 										lawn[i][k].trimed = 1;
 								}
 						dir[m + k] = 1;		
 				}
 		}
 		return ret;
 }
 
 int main()
 {
 		int T;
 		int N, M;
 		int i;
 		scanf("%d", &T);
 		for (i = 1; i <= T; i++) {
 				int j, k;
 				memset(dir, 0, sizeof(dir));
 				scanf("%d%d", &N, &M);
 				for (j = 0; j < N; j++) {
 						for (k = 0; k < M; k++) {
 								scanf("%d", &lawn[j][k].h);
 								lawn[j][k].i = j;
 								lawn[j][k].j = k;
 								lawn[j][k].trimed = 0;
 								lawnp[j * M + k] = &lawn[j][k];
 						}
 				}
 				qsort(lawnp, N*M, sizeof(struct _lawn *), cmp);
 				if (trim(N,  M))
 						printf("Case #%d: YES\n", i);
 				else
 						printf("Case #%d: NO\n", i);
 		}
 		return 0;
 }

