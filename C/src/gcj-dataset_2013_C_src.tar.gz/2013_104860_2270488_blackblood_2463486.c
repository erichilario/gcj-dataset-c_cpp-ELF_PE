#include<stdio.h>
 #include<stdlib.h>
 
 int main()
 {
 	FILE *ifp, *ofp;
 
 	int t,z,a,b,i,out;
 	int arr[5] = {1,4,9,121,484};
 
 	ifp = fopen("input.txt", "r");
 	ofp = fopen("output.txt", "w");
 
 	fscanf(ifp,"%d",&t);
 
 	for(z=0;z<t;z++)
 	{
 		fscanf(ifp,"%d%d",&a,&b);
 
 		out = 0;
 		for(i=0;i<5;i++)
 		{
 			if(arr[i]>=a && arr[i]<=b)	out++;
 		}
 		
 		fprintf(ofp,"Case #%d: %d\n",z+1,out);
 	}
 
 	fclose(ifp);
 	fclose(ofp);
 	return 0;
 }

