#include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 int intcmp(const void *a, const void *b) {
     int ai = *(int *)a;
     int bi = *(int *)b;
 
     int ret = 0;
     if (ai < bi) ret = -1;
     else if (ai > bi) ret = 1;
 
     return ret;
 }
 
 int main(int argc, char **argv) {
     int testcases = 0;
     scanf("%d", &testcases);
     int i = 0;
     while (i++ < testcases) {
         int result = 0;
         int result_tmp = 1000000;
         int mote = 0, num = 0;
         scanf("%d%d", &mote, &num);
         int *motes = (int *)calloc(num, sizeof(int));
 
         int j = 0;
         while (j < num) {
             scanf("%d", motes + j);
             j++;
         }
 
         qsort(motes, num, sizeof(int), intcmp);
 
         int nm = mote;
         for (j = 0; j < num; j++) {
             if (nm <= motes[j]) {
                 if (nm == 1) {result += num - j; break;}
                 else {
                 nm = 2 * nm - 1;
                 if (result + num - j < result_tmp) {
                     result_tmp = result + num - j;
                 }
                 result++;
                 j--;
 
                 }
             } else nm += motes[j];
         }
 
         result = result > result_tmp ? result_tmp : result;
         free(motes);
         
         printf("Case #%d: %d\n", i, result);
     }
 }

