#include <iostream>
 
 using namespace std;
 
 int testCases;
 char board[4][4];
 bool complete;
 
 void solve();
 int main() {
 
    cin >> testCases;
 
    for (int t = 0; t < testCases; t++) {
       complete = true; // assume no space left.
       // set up board.
       for (int y = 0; y < 4; y++) {
          for (int x = 0; x < 4; x++) {
             cin >> board[y][x];
             if (board[y][x] == '.') { // not a draw
                complete = false;
             }
          }
       }
 
       cout << "Case #" << t + 1<< ": ";
       solve();
    }
 }
 
 void solve() {
    int inARow = 0;
    // first check for X win
    for (int y = 0; y < 4; y++) {
       for (int x = 0; x < 4; x++) {
          if (board[y][x] == 'X' || board[y][x] == 'T') {
             inARow++;
          }
       }
       if (inARow == 4) {
          cout << "X won" << endl;
          return;
       } else {
          inARow = 0;
       }
    }
 
    for (int x = 0; x < 4; x++) {
       for (int y = 0; y < 4; y++) {
          if (board[y][x] == 'X' || board[y][x] == 'T') {
             inARow++;
          }
       }
       if (inARow == 4) {
          cout << "X won" << endl;
          return;
       } else {
          inARow = 0;
       }
    }
 
    // check diagonal
    if (board[0][0] == 'X' || board[0][0] == 'T') {
       if (board[1][1] == 'X' || board[1][1] == 'T') {
          if (board[2][2] == 'X' || board[2][2] == 'T') {
             if (board[3][3] == 'X' || board[3][3] == 'T') {
                cout << "X won" << endl;
                return;
             }
          }
       }
    }
 
    if (board[0][3] == 'X' || board[0][3] == 'T') {
       if (board[1][2] == 'X' || board[1][2] == 'T') {
          if (board[2][1] == 'X' || board[2][1] == 'T') {
             if (board[3][0] == 'X' || board[3][0] == 'T') {
                cout << "X won" << endl;
                return;
             }
          }
       }
    }
 
    if (board[0][0] == 'O' || board[0][0] == 'T') {
       if (board[1][1] == 'O' || board[1][1] == 'T') {
          if (board[2][2] == 'O' || board[2][2] == 'T') {
             if (board[3][3] == 'O' || board[3][3] == 'T') {
                cout << "O won" << endl;
                return;
             }
          }
       }
    }
 
    if (board[0][3] == 'O' || board[0][3] == 'T') {
       if (board[1][2] == 'O' || board[1][2] == 'T') {
          if (board[2][1] == 'O' || board[2][1] == 'T') {
             if (board[3][0] == 'O' || board[3][0] == 'T') {
                cout << "O won" << endl;
                return;
             }
          }
       }
    }
 
    for (int y = 0; y < 4; y++) {
       for (int x = 0; x < 4; x++) {
          if (board[y][x] == 'O' || board[y][x] == 'T') {
             inARow++;
          }
       }
       if (inARow == 4) {
          cout << "O won" << endl;
          return;
       } else {
          inARow = 0;
       }
    }
 
    for (int x = 0; x < 4; x++) {
       for (int y = 0; y < 4; y++) {
          if (board[y][x] == 'O' || board[y][x] == 'T') {
             inARow++;
          }
       }
       if (inARow == 4) {
          cout << "O won" << endl;
          return;
       } else {
          inARow = 0;
       }
    }
 
    if (complete) {
       cout << "Draw" << endl;
    } else {
       cout << "Game has not completed" << endl;
    }
 }

