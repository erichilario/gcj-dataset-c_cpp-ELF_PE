#include <stdio.h>
 #include <stdbool.h>
 
 int lawn[100][100];
 int N, M;
 char *yes = "YES";
 char *no = "NO";
 
 bool genFromCol(int x, int y) {
     int i;
     for (i = 0; i < N; ++i) {
         if (lawn[x][y] < lawn[i][y]) {
             return false;
         }
     }
     return true;
 }
 
 bool genFromRow(int x, int y) {
     int i;
     for (i = 0; i < M; ++i) {
         if (lawn[x][y] < lawn[x][i]) {
             return false;
         }
     }
     return true;
 }
 
 void PrintResult(int index, char *result) {
     printf("Case #%d: %s\n", index, result);
 }
 
 int main() {
     freopen("B-large.in", "r", stdin);
     freopen("B-large.out", "w", stdout);
     int T, index, i, j;
     bool is_finished;
     scanf("%d", &T);
     for (index = 1; index <= T; ++index) {
         scanf("%d %d", &N, &M);
         for (i = 0; i < N; ++i) {
             for (j = 0; j < M; ++j) {
                 scanf("%d", &lawn[i][j]);
             }
         }
         is_finished = false;
         for (i = 0; i < N; ++i) {
             for (j = 0; j < M; ++j) {
                 if (!genFromRow(i, j) && !genFromCol(i, j)) {
                     is_finished = true;
                     break;
                 }
             }
             if (is_finished) {
                 break;
             }
         }
         if (is_finished) {
             PrintResult(index, no);
         } else {
             PrintResult(index, yes);
         }
     }
     fclose(stdout);
     fclose(stdin);
     return 0;
 }

