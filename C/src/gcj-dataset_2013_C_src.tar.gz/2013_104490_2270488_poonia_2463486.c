#include<stdio.h>
 int main () {
     int arr[5]={1,4,9,121,484},T=0,A,B,i,temp=0,T2;
     scanf("%d",&T);
     T2=T;
     while(T>0){
         temp=0;
       scanf("%d %d",&A,&B);
       for(i=0;i<5;i++){
           if(A<=arr[i] && B>=arr[i])
                 temp++;
       }
       printf("Case #%d: %d\n",T2-T+1,temp);
       T--;
     }
     return 0;
 }
