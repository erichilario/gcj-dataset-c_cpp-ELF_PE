#include <stdio.h>
 #include <math.h>
 
 main(){
     FILE * pFile;
     pFile = fopen ("c.out","w");
     unsigned long long int x , a , b , reverse, temp ,n;
     int  count,result[10001] ;
     scanf("%d",&count);
     for(x=1;x<=count;x++)
         {
             result[x]=0;
             scanf ("%d %d",&a,&b);
                 for (a;a<=b;a++)
                     {
                         reverse = 0;
                         temp = a;
                         while( temp != 0 )
                         {
                             reverse = reverse * 10;
                             reverse = reverse + temp%10;
                             temp = temp/10;
                         }
 
                         if ( a == reverse )
                             for (n=1;n<=a;n++)
                                 if((n*n)==a)
                                     {
                                         reverse = 0;
                                         temp = n;
                                         while( temp != 0 )
                                         {
                                             reverse = reverse * 10;
                                             reverse = reverse + temp%10;
                                             temp = temp/10;
                                         }
                                     if ( n == reverse )
                                     result[x]+=1;}
                     }
         }
     for(x=1;x<=count;x++){
     printf ("Case #%llu: %d\n" ,x,result[x] );
     fprintf (pFile,"Case #%llu: %d\n" ,x,result[x] );}
     return 0;
 }

