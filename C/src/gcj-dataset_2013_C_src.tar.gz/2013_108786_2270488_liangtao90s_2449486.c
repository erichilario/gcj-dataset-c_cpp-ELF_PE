/*
  * =====================================================================================
  *
  *       Filename:  problemB.c
  *
  *    Description:  google code jam problem B
  *
  *        Version:  1.0
  *        Created:  2013年04月13日 09时58分56秒
  *       Revision:  none
  *       Compiler:  gcc
  *
  *         Author:  梁涛 (suck_it), liangtao90s@gmail.com
  *   Organization:  
  *
  * =====================================================================================
  */
 
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 static int h[11][11];
 int main()
 {
 		int T;
 		int N, M;
 		int i;
 		scanf("%d", &T);
 		for (i = 1; i <= T; i++) {
 				int j, k;
 				int ret;
 				scanf("%d%d", &N, &M);
 				for (j = 0; j < N; j++) {
 						for (k = 0; k < M; k++) {
 								scanf("%d", &h[j][k]);
 						}
 				}
 				for (j = 0; j < N; j++) {
 						for (k = 0; k < M; k++) {
 								int l;
 								ret = 0;
 								if (h[j][k] == 1) {
 										for (l = 0; l < M; l++)
 												if (h[j][l] != 1) {
 														ret = 1;
 														break;
 												}
 										for (l = 0; l < N; l++)
 												if (h[l][k] != 1) {
 														ret++;
 														break;
 												}
 								}
 								if (ret == 2) 
 										break;
 						}
 						if (ret == 2)
 								break;
 				}
 				if (ret == 2)
 						printf("Case #%d: NO\n", i);
 				else
 						printf("Case #%d: YES\n", i);
 		}
 		return 0;
 }

