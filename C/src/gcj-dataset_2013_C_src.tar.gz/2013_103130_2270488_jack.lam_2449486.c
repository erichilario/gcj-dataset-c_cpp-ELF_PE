#include <stdio.h>
 #define DEBUG 0
 
 int map[101][101];
 int linemax[101];
 int colmax[101];
 
 int findlinemax(int N, int M, int line)
 {
   int max = -1;
   int i;
   
   for ( i=0; i<M; i++ )
     if ( map[line][i] > max )
       max = map[line][i];
       
   return max;
 }
 
 int findcolmax(int N, int M, int col)
 {
   int max = -1;
   int i;
   
   for ( i=0; i<N; i++ )
     if ( map[i][col] > max )
       max = map[i][col];
       
   return max;
 }
 
 int main(void)
 {
   int T;
   int N, M;
 
   unsigned int xpat;
   unsigned int opat;
   int occupied;
   int t;
   char raw[10];
   int line;
   int cpos;
   int i;
   
   int possible;
   
   scanf("%d", &T);
   
   for ( t=1; t<=T; t++ ) {
     scanf("%d %d", &N, &M);
   
     for ( line=0; line<N; line++ ) {
       for ( cpos=0; cpos<M; cpos++ ) {
         scanf("%d", &(map[line][cpos]));
       }
     }
     
     /* debug */
     if ( DEBUG ) {
       printf("Case #%d:\n", t);
       
       for ( line=0; line<N; line++ ) {
         for ( cpos=0; cpos<M; cpos++ ) {
           printf("%d ", map[line][cpos]);
         }
         printf("\n");
       }
     }
     
     /* find max for each row and each col */
     for ( i=0; i<N; i++ ) {
       linemax[i] = findlinemax(N, M, i);
       if ( DEBUG ) printf("line %d : max = %d\n", i, linemax[i]);
     }
     for ( i=0; i<M; i++ ) {
       colmax[i] = findcolmax(N, M, i);
       if ( DEBUG ) printf("col %d : max = %d\n", i, colmax[i]);
     }
     
     /* check if possible */
     possible = 1;
     for ( line=0; line<N; line++ ) {
       for ( cpos=0; cpos<M; cpos++ ) {
         if ( map[line][cpos] != linemax[line] && map[line][cpos] != colmax[cpos] ) { possible = 0; break; }
       }
     }
     
     if ( possible )
       printf("Case #%d: YES\n", t);
     else
       printf("Case #%d: NO\n", t);
     
   }
 
   return 0;
 }

