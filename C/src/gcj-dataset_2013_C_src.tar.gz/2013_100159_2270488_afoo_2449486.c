#include <stdio.h>
     int map[200][200];
     int chk[200][200];
 char c;
 int main(){
     int T,ans;
 
     scanf("%d\n",&T);
     int t;
 
     int i,j;
     int N,M;
 
     
     for ( t = 1 ; t <= T ; t++){
         scanf("%d %d", &N,&M);
         for ( i=0;i<N ;i++){
             for (j=0;j<M;j++){
                 scanf("%d", &map[i][j]);
                 chk[i][j]=0;
             }
         }
 
 /*        
         //DEBUG : on
         for ( i=0;i<N;i++){
             for (j=0;j<M;j++){
                 printf("%d ", map[i][j]);
             }
             printf("\n");
         }
         //DEBUG : on
         for ( i=0;i<N;i++){
             for (j=0;j<M;j++){
                 printf("%d ", chk[i][j]);
             }
             printf("\n");
         }
 */        
 //        ans = check_possible(map, chk,N,M);        
         ans = check_possible(N,M);        
 /*
         printf("\n");
         //DEBUG : on
         for ( i=0;i<N;i++){
             for (j=0;j<M;j++){
                 printf("%d ", chk[i][j]);
             }
             printf("\n");
         }
 */                
         printf("Case #%d: ", t);
         if (ans == 1){
             printf("YES\n");
         }
         else{
             printf("NO\n");
         }
     }
     return 0;
 }
 //int check_possible(int** map, int** chk, int N, int M){
 int check_possible(int N, int M){    
     //pick smallest value
     int i,j;
     int min_i, min_j, min;
     min_i = min_j = -1;
     min = 1000;
 //    printf("N is [%d], M is [%d]\n", N,M);
 //    return 1;
     for (i=0;i<N;i++){
         for (j=0;j<M;j++){
 /*
             printf("(%d, %d)\n", i,j);
             printf("chk [%d]\n",chk[i][j] );
             printf("map [%d]\n",map[i][j]); 
             printf("min [%d]\n", min);          
             printf(
 */            
 //              return 1;
 
             if ( chk[i][j] == 0 && map[i][j] < min){
                  min = map[i][j];
                  min_i = i;
                  min_j = j;
             }
         }
     }
 //    printf("min i,j (%d, %d): [%d]\n",min_i,min_j,min);
     // all square are filled
     if (min == 1000){
          return 1;
     }
     
     // check col
     for (i=0;i<N;i++){
         if ( map[i][min_j] > min){
              break;
         }
     }
     
     // all column value are min
     if ( i==N){
 //         printf("find col [%d]\n", min_j);
        for (i=0;i<N;i++){
            chk[i][min_j] = min;
        }
 //       return check_possible(map, chk,N,M);  
        return check_possible(N,M);   
     }
 
 
 
     // check row
     for (j=0;j<M;j++){
         if ( map[min_i][j] > min){
              break;
         }
     }
     // all row value are min
     if ( j==M){
 //         printf("find row [%d]\n", min_i);
        for (j=0;j<M;j++){
            chk[min_i][j] = min;
        }
 //       return check_possible(map, chk,N,M);  
        return check_possible(N,M);  
     }
 //    printf("can not find col or row \n");
     return 0;
 }

