#include<stdio.h>
 
 int main()
 {
 int t,a,b,i,j,count,p=0;
 
 int array[6]={1,4,9,121,484};
 scanf("%d",&t);
 
 while(t--)
 {
  p++;
   count=0;
   scanf("%d %d",&a,&b);
   for(i=0;i<5;i++)
    {
      if(array[i]>=a && array[i]<=b)
        {
          count++;
        }
    }
  printf("Case #%d: %d\n",p,count);
 }
 return 0;
 }
