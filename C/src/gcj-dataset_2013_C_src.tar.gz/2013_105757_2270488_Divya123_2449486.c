#include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <math.h>
 int main()
 {
 int t,i,A[100][100];
 scanf("%d",&t);
 for(i=0;i<t;i++)
 {
 int m,n,fl=0,j,k,count=0;
 scanf("%d %d",&m,&n);
 for(j=0;j<m;j++)
 { for(k=0;k<n;k++)
 scanf("%d",&A[j][k]);}
 for(j=0;j<m;j++)
  { for(k=0;k<n;k++)
    { int u;
   for(u=0;u<n;u++) { if(u!=k) 
 { if(A[j][u] > A[j][k])  {fl=1; break;
 }}}
 if(fl==1){
 fl=0;
 for(u=0;u<m;u++) { if(u!=j)
 { if(A[u][k] > A[j][k]) { fl=1; break;}}}
 if(fl==1) count=1;
 }
 if(count ==1) break;
 }
 if(count ==1) break;}
 printf("Case #%d: ",i+1);
 if(count==1) printf("NO\n");
 else printf("YES\n");
 }
 return 0;
 }

