#include <stdio.h>
 #include <stdlib.h>
 
 int main(void) {
 	int i, j, k, l, n, x, o, draw;
 
 	char board[4][5];
 	char buf[5];
 	char piece;
 	scanf("%d", &n);
 
 	i=0;
 	mainloop:
 	for(; i<n; i++) {
 	  printf("Case #%d: ", i+1);
 		//read characters into board
 		for(j=0; j<4; j++)
 			scanf("%s", board[j]);
 		//scanf("%s", buf);
 		draw = 1;
 		//horizontal
 		for(k=0; k<4; k++) {
 			x=0;
 			o=0;
 			for (l=0; l<4; l++) {
 				piece = board[k][l];
 				if (piece == 'X')
 					x++;
 				if (piece == 'O')
 					o++;
 				if (piece == 'T') {
 					x++;
 					o++;
 				}
 				if (piece == '.')
 					draw = 0;
 			}
 			if (x == 4) {
 				printf("X won\n");
 				i++;
 				goto mainloop;
 			}
 			if (o == 4) {
 				printf("O Won\n");
 				i++;
 				goto mainloop;
 			}
 		}
 
 		//vertical
 		for(k=0; k<4; k++) {
 			x=0;
 			o=0;
 			for (l=0; l<4; l++) {
 				piece = board[l][k];
 				if (piece == 'X')
 					x++;
 				if (piece == 'O')
 					o++;
 				if (piece == 'T') {
 					x++;
 					o++;
 				}
 				if (piece == '.')
 					draw = 0;
 			}
 			if (x == 4) {
 				printf("X won\n");
 				i++;
 				goto mainloop;
 			}
 			if (o == 4) {
 				printf("O won\n");
 				i++;
 				goto mainloop;
 			}
 		}
 
 		//diagonal
 		x=0;
 		o=0;
 		for(k=0; k<4; k++) {
 			piece = board[k][k];
 			if (piece == 'X')
 				x++;
 			if (piece == 'O')
 				o++;
 			if (piece == 'T') {
 				x++;
 				o++;
 			}
 			if (piece == '.')
 				draw = 0;
 			if (x == 4) {
 				printf("X won\n");
 				i++;
 				goto mainloop;
 			}
 			if (o == 4) {
 				printf("O won\n");
 				i++;
 				goto mainloop;
 			}
 		}
 
 		//other diagonal
 		x=0;
 		o=0;
 		for(k=0; k<4; k++) {
 			piece = board[k][3-k];
 			if (piece == 'X')
 				x++;
 			if (piece == 'O')
 				o++;
 			if (piece == 'T') {
 				x++;
 				o++;
 			}
 			if (piece == '.')
 				draw = 0;
 			if (x == 4) {
 				printf("X won\n");
 				i++;
 				goto mainloop;
 			}
 			if (o == 4) {
 				printf("O won\n");
 				i++;
 				goto mainloop;
 			}
 		}
 
 		if (draw) {
 			printf("Draw\n");
 		}
 		else {
 			printf("Game has not completed\n");
 		}
 
 	}
 }

