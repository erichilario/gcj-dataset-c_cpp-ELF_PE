#include <stdio.h>
 
 int a[150][150], n, m;
 
 int verify()
 {
     int i, j, k, f, g;
     for(i=0; i<n; i++) for(j=0; j<m; j++)
     {
         f=g=0;
         for(k=0; k<n; k++) if(a[k][j]>a[i][j]) f=1;
         for(k=0; k<m; k++) if(a[i][k]>a[i][j]) g=1;
         if(f && g) return 1;
     }
     return 0;
 }
 
 int main()
 {
     int i, j, aux=1, t;
     scanf("%d", &t);
     while(t--)
     {
         scanf("%d %d", &n, &m);
         for(i=0; i<n; i++) for(j=0; j<m; j++) scanf("%d", &a[i][j]);
         printf("Case #%d: ", aux++);
         printf("%s\n", !verify() ? "YES" : "NO");
     }
     return 0;
 }

