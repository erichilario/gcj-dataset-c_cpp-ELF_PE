//empty: 0, T:1, X:2, O:3
 //draw: 0, not finished:1 , X:2, O:3
 #include <stdio.h>
 int winner(int u[4][4]){
 	int i,ii,ara;
 	for(i=0;i<4;i++){
 		ara=1;
 		for(ii=0;ii<4;ii++){
 			ara*=u[i][ii];
 		}
 		if(ara==16 || ara== 8)
 		return 2;
 		if(ara==81 || ara== 27)
 		return 3;
 		ara=1;
 		for(ii=0;ii<4;ii++){
 			ara*=u[ii][i];
 		}
 		if(ara==16 || ara== 8)
 		return 2;
 		if(ara==81 || ara== 27)
 		return 3;
 	}
 	//diagonal 1
 	ara=1;
 	for(i=0;i<4;i++){
 		ara*=u[i][i];
 	}
 	if(ara==16 || ara== 8)
 	return 2;
 	if(ara==81 || ara== 27)
 	return 3;
 	//diagonal 2
 	ara=1;
 	for(i=0;i<4;i++){
 		ara*=u[3-i][i];
 	}
 	if(ara==16 || ara== 8)
 	return 2;
 	if(ara==81 || ara== 27)
 	return 3;
 	
 	for(i=0;i<4;i++){
 		ara=1;
 		for(ii=0;ii<4;ii++){
 			ara*=u[i][ii];
 		}
 	}
 	if(ara==0)
 	return 1;
 	return 0;
 }
 int main(){
 	int states[4][4];
 	int n,i1,i2,i3;
 	char str[10];
 	FILE *file1;
 	file1=fopen("A-small-attempt0.in","r");
 	FILE *file2;
 	file2=fopen("A-small-attempt0.out","w");
 	fscanf(file1,"%d",&n);	
 			fgets(str,10,file1);
 	for(i1=0;i1<n;i1++){
 		for(i2=0;i2<4;i2++){
 			fgets(str,10,file1);
 			for(i3=0;i3<4;i3++){
 				switch(str[i3]){
 					case '.':
 					states[i2][i3]=0;
 					break;
 					case 'T':
 					states[i2][i3]=1;
 					break;
 					case 'X':
 					states[i2][i3]=2;
 					break;
 					case 'O':
 					states[i2][i3]=3;
 					break;
 				}
 			}
 		}
 		switch(winner(states)){
                                case 0:
                                     fprintf(file2,"Case #%d: Draw\n",i1+1);
                                     break;
                                case 1:
                                     fprintf(file2,"Case #%d: Game has not completed\n",i1+1);
                                     break;
                                case 2:
                                     fprintf(file2,"Case #%d: X won\n",i1+1);
                                     break;
                                case 3:
                                     fprintf(file2,"Case #%d: O won\n",i1+1);
                                     break;
                                }
 		printf("case %d %d\n",i1,winner(states));
 		fgets(str,5,file1);
 	}
 	fclose(file2);
 }

